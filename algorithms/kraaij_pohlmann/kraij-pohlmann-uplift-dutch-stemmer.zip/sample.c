/*******************************   stemmer.c   ********************************
 *
 *  Program to demonstrate and test the Porter stemming function.  This
 *  program takes a single filename on the command line and lists stemmed
 *  terms on stdout.
 *

    Copyright (C) 1995  Wessel Kraaij & Renee Pohlmann

    email: Wessel.Kraaij@let.ruu.nl  Renee.C.Pohlmann@let.ru.nl

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.




 **/

#include <stdio.h>
#include <ctype.h>

#include "stem.h"

/******************************************************************************/
/********************   Private Defines and Data Structures   *****************/

#define EOS                           '\0'

/******************************************************************************/
/************************   Private Function Definitions   ********************/

#ifdef __STDC__

static char * GetNextTerm( FILE *stream, int size, char *term );

#else

static char * GetNextTerm();

#endif

/*FN***************************************************************************

        GetNextTerm( stream, size, term )

   Returns: char * -- buffer with the next input term, NULL at EOF

   Purpose: Grab the next token from an input stream

   Plan:    Part 1: Return NULL immediately if there is no input
            Part 2: Initialize the local variables
            Part 3: Main Loop: Put the next word into the term buffer
            Part 4: Return the output buffer

   Notes:   None.
**/

static char *
GetNextTerm( stream, size, term )
   FILE *stream;  /* in: source of input characters */
   int size;      /* in: bytes in the output buffer */
   char *term;    /* in/out: where the next term in placed */
   {
   char *ptr;  /* for scanning through the term buffer */
   int ch;     /* current character during input scan */

           /* Part 1: Return NULL immediately if there is no input */
   if ( EOF == (ch = getc(stream)) ) return( NULL );

                  /* Part 2: Initialize the local variables */
   *term = EOS;
   ptr = term;

        /* Part 3: Main Loop: Put the next word into the term buffer */
   do
      {
         /* scan past any leading blanks */
      while ( (EOF != ch ) && (' ' == ch )) {
	  printf(" ");ch = getc( stream );
      }

         /* copy input to output while reading alphabetic characters */
      /* lemma program processes word list, it assumes that a lexical analysis
	 has been done wk 9-6-94 */
      while ( (EOF != ch ) && (ch != ' ')&&(ch != '\n'))
         {
         if ( ptr == (term+size-1) ) ptr = term;
         *ptr++ = ch;
         ch = getc( stream );
         }
      if ((ch == '\n') && !*term) {
	  printf("\n");
	  ch =getc(stream);
      }
         /* terminate the output buffer */
      *ptr = EOS;
      }
   while ( (EOF != ch) && !*term );
      if ( Stem(term) ) (void)printf( "%s", term);
      if (ch != EOF) printf("%c",ch);

                    /* Part 4: Return the output buffer */
   return( term );

   } /* GetNextTerm */

/******************************************************************************/
/*FN***************************************************************************

        main( argc, argv )

   Returns: int -- 0 on success, 1 on failure

   Purpose: Program main function

   Plan:    Part 1: Open the input file
            Part 2: Process each word in the file
            Part 3: Close the input file and return

   Notes:
**/

int
main( argc, argv )
   int argc;     /* in: how many arguments */
   char *argv[]; /* in: text of the arguments */
   {
   char term[64];   /* for the next term from the input line */
   char prev[64];
   FILE *stream;    /* where to read characters from */

                       /* Part 1: Open the input file */
   if (argc > 1)
       {
	   if ( !(stream = fopen(argv[1],"r")) ) exit(1);
       }
   else
       stream = stdin;
                  /* Part 2: Process each word in the file */
   while( GetNextTerm(stream,64,term) )
       {
	   /*   strcpy(prev,term);
	   if ( Stem(term) ) (void)printf( "%s", term);*/
       }

                 /* Part 3: Close the input file and return */
   (void)fclose( stream );
   return(0);

   } /* main */
