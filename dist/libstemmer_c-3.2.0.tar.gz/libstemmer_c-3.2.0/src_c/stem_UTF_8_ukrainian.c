/* Generated from ukrainian.sbl by Snowball 3.2.0 - https://snowballstem.org/ */

#include "stem_UTF_8_ukrainian.h"

#include <stddef.h>

#include "../runtime/snowball_runtime.h"

#ifdef SNOWBALL_BIGENDIAN
#define S(W) ((0x##W & 0xff) << 8 | 0x##W >> 8)
#else
#define S(W) (0x##W)
#endif

#ifdef __cplusplus
extern "C" {
#endif
extern int ukrainian_UTF_8_stem(struct SN_env * z);
#ifdef __cplusplus
}
#endif

static int r_professional(struct SN_env * z);

#define s_240 (s_1 + 4)
#define s_232 (s_16 + 6)
#define s_113 (s_17 + 2)
#define s_21 (s_22 + 6)
#define s_242 (s_27 + 4)
#define s_246 (s_30 + 6)
#define s_243 (s_31 + 6)
#define s_40 (s_41 + 8)
#define s_235 (s_47 + 4)
#define s_244 (s_52 + 8)
#define s_85 (s_62 + 2)
#define s_62 (s_73 + 4)
#define s_142 (s_110 + 4)
#define s_5 (s_140 + 6)
#define s_249 (s_175 + 2)
#define s_238 (s_180 + 4)
#define s_241 (s_197 + 8)
#define s_199 (s_208 + 2)
#define s_189 (s_219 + 4)
#define s_157 (s_228 + 2)
#define s_11 (s_230 + 2)
#define s_245 (s_233 + 2)
#define s_248 (s_4 + 6)
#define s_10 (s_177 + 4)
#define s_32 (s_66 + 6)
#define s_206 (s_152 + 10)
#define s_225 (s_203 + 8)
#define s_103 (s_0 + 4)
#define s_143 (s_100 + 4)
#define s_186 (s_236 + 2)
#define s_82 (s_39 + 6)
#define s_51 (s_104 + 4)
#define s_121 (s_106 + 4)
#define s_2 (s_239 + 2)
#define s_14 (s_110 + 6)
#define s_15 (s_111 + 6)
#define s_74 (s_230 + 8)
#define s_162 (s_12 + 8)
#define s_188 (s_53 + 6)
#define s_50 (s_202 + 4)
#define s_97 (s_208 + 4)
#define s_88 (s_34 + 4)
#define s_218 (s_35 + 4)
#define s_98 (s_3 + 10)
#define s_28 (s_109 + 10)
#define s_8 (s_239 + 10)
#define s_215 (s_108 + 10)
#define s_132 (s_66 + 14)
#define s_179 (s_112 + 6)
#define s_61 (s_54 + 6)
#define s_181 (s_114 + 6)
#define s_63 (s_0 + 8)
#define s_146 (s_151 + 12)
#define s_1 (s_133 + 4)
#define s_141 (s_7 + 4)
#define s_237 (s_185 + 4)
#define s_117 (s_220 + 4)
#define s_38 (s_247 + 4)
#define s_222 (s_231 + 4)
#define s_210 (s_226 + 4)
#define s_229 (s_122 + 6)
#define s_205 (s_138 + 5)
#define s_213 (s_127 + 6)
#define s_216 (s_147 + 6)
#define s_176 (s_227 + 4)
#define s_187 (s_9 + 8)
#define s_101 (s_13 + 8)
#define s_107 (s_42 + 8)
#define s_190 (s_207 + 8)
#define s_125 (s_70 + 6)
#define s_211 (s_79 + 6)
#define s_144 (s_6 + 6)
#define s_131 (s_193 + 6)
#define s_139 (s_234 + 6)
#define s_7 (s_23 + 8)
#define s_217 (s_191 + 8)
#define s_220 (s_36 + 8)
#define s_124 (s_204 + 8)
#define s_37 (s_145 + 8)
#define s_57 (s_148 + 8)
#define s_136 (s_221 + 8)
#define s_164 (s_83 + 6)
#define s_175 (s_48 + 8)
#define s_19 (s_58 + 8)
#define s_64 (s_30 + 10)
#define s_52 (s_126 + 8)
#define s_137 (s_196 + 10)
#define s_170 (s_247 + 10)
#define s_185 (s_149 + 10)
#define s_165 (s_195 + 10)
#define s_167 (s_224 + 10)
#define s_233 (s_236 + 10)
#define s_223 (s_201 + 10)
#define s_56 (s_43 + 10)
#define s_72 (s_219 + 10)
#define s_100 (s_44 + 10)
#define s_173 (s_231 + 10)
#define s_106 (s_65 + 8)
#define s_39 (s_159 + 8)
#define s_92 (s_150 + 10)
#define s_26 (s_45 + 10)
#define s_31 (s_55 + 10)
#define s_76 (s_24 + 10)
#define s_120 (s_9 + 12)
#define s_27 (s_226 + 10)
#define s_127 (s_25 + 10)
#define s_29 (s_140 + 10)
#define s_118 (s_60 + 11)
#define s_68 (s_6 + 14)
#define s_20 (s_138 + 11)
#define s_17 (s_207 + 14)
#define s_77 (s_147 + 12)
#define s_228 (s_145 + 16)
#define s_91 (s_46 + 12)
#define s_12 (s_122 + 10)
#define s_148 (s_18 + 12)
#define s_23 (s_200 + 12)
#define s_75 (s_212 + 12)
#define s_152 (s_71 + 8)
#define s_41 (s_104 + 12)
#define s_201 (s_47 + 14)
#define s_9 (s_198 + 12)
#define s_54 (s_49 + 14)
#define s_0 (s_197 + 12)
#define s_151 (s_59 + 14)
#define s_207 (s_202 + 16)
static const symbol s_197[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xB0, 0xD0, 0xBA,
    0xD1, 0x82, 0xD0, 0xB8, 0xD0, 0xBA, 0xD0, 0xB8,
    0xD1, 0x94, 0xD0, 0xB2, 0xD1, 0x80, 0xD0, 0xB5,
    0xD0, 0xB7, 0xD1, 0x83, 0xD0, 0xBB, 0xD1, 0x8C,
    0xD1, 0x82, 0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_196[] = {
    0xD0, 0xB4, 0xD1, 0x96, 0xD0, 0xBB, 0xD1, 0x8F,
    0xD0, 0xBD, 0xD0, 0xBA, 0xD0, 0xBE, 0xD1, 0x80,
    0xD0, 0xB5, 0xD0, 0xBD
};
static const symbol s_166[] = {
    0xD0, 0xB1, 0xD1, 0x80, 0xD0, 0xB5, 0xD1, 0x82,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_3[] = {
    0xD0, 0xB2, 0xD0, 0xB0, 0xD1, 0x80, 0xD1, 0x82,
    0xD0, 0xBE, 0xD1, 0x81, 0xD1, 0x82, 0xD0, 0xB0,
    0xD1, 0x82, 0xD1, 0x82
};
static const symbol s_4[] = {
    0xD1, 0x81, 0xD0, 0xBE, 0xD0, 0xB2, 0xD1, 0x96,
    0xD1, 0x81, 0xD1, 0x82, 0xD1, 0x8C
};
static const symbol s_6[] = {
    0xD0, 0xBE, 0xD1, 0x81, 0xD0, 0xBE, 0xD0, 0xB1,
    0xD1, 0x83, 0xD0, 0xB4, 0xD1, 0x96, 0xD0, 0xB2,
    0xD0, 0xB8, 0xD1, 0x82, 0xD1, 0x80, 0xD0, 0xB0,
    0xD1, 0x82
};
static const symbol s_182[] = {
    0xD0, 0xB1, 0xD0, 0xB0, 0xD1, 0x80, 0xD0, 0xB0,
    0xD0, 0xB1, 0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_195[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xB8, 0xD1, 0x81,
    0xD1, 0x8F, 0xD0, 0xB3, 0xD0, 0xB0, 0xD0, 0xB2,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_134[] = {
    0xD1, 0x81, 0xD1, 0x82, 0xD1, 0x83, 0xD0, 0xBF,
    0xD0, 0xB5, 0xD0, 0xBD
};
static const symbol s_203[] = {
    0xD1, 0x80, 0xD0, 0xBE, 0xD0, 0xB7, 0xD1, 0x80,
    0xD0, 0xBE, 0xD0, 0xB1, 0xD0, 0xBA, 0xD0, 0xBB,
    0xD0, 0xB0, 0xD0, 0xB4, 0xD0, 0xB8, 0xD0, 0xBD,
    0xD0, 0xBA
};
static const symbol s_247[] = {
    0xD1, 0x86, 0xD1, 0x82, 0xD0, 0xB2, 0xD0, 0xB4,
    0xD0, 0xB5, 0xD1, 0x80, 0xD1, 0x8F, 0xD0, 0xB7,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_204[] = {
    0xD0, 0xB7, 0xD0, 0xB0, 0xD1, 0x82, 0xD0, 0xBE,
    0xD0, 0xBA, 0xD0, 0xB2, 0xD1, 0x96, 0xD1, 0x82,
    0xD0, 0xBD
};
static const symbol s_13[] = {
    0xD0, 0xB7, 0xD0, 0xB0, 0xD0, 0xBC, 0xD0, 0xB0,
    0xD0, 0xBB, 0xD1, 0x96, 0xD1, 0x86, 0xD0, 0xB5
};
static const symbol s_224[] = {
    0xD1, 0x84, 0xD0, 0xB0, 0xD0, 0xB1, 0xD1, 0x80,
    0xD0, 0xB8, 0xD0, 0xBA, 0xD1, 0x83, 0xD0, 0xB1,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_174[] = {
    0xD0, 0xB4, 0xD0, 0xBE, 0xD0, 0xB2, 0xD0, 0xB3,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_16[] = {
    0xD0, 0xB4, 0xD0, 0xBE, 0xD1, 0x81, 0xD0, 0xBA,
    0xD0, 0xBE, 0xD0, 0xBD, 0xD0, 0xB0, 0xD0, 0xBB
};
static const symbol s_234[] = {
    0xD0, 0xBF, 0xD0, 0xBB, 0xD0, 0xBE, 0xD0, 0xB4,
    0xD0, 0xB5, 0xD0, 0xB2, '\'', 0xD1, 0x8F, 0xD1,
    0x82
};
static const symbol s_18[] = {
    0xD0, 0xB0, 0xD0, 0xB4, 0xD0, 0xBC, 0xD1, 0x96,
    0xD1, 0x80, 0xD0, 0xB0, 0xD0, 0xBB, 0xD1, 0x8C,
    0xD0, 0xB2, 0xD0, 0xBE, 0xD0, 0xB2, 0xD0, 0xB0,
    0xD0, 0xB4, 0xD0, 0xB8, 0xD0, 0xBC
};
static const symbol s_160[] = {
    0xD1, 0x81, 0xD0, 0xB2, 0xD1, 0x8F, 0xD1, 0x89,
    0xD0, 0xB5, 0xD0, 0xBD
};
static const symbol s_147[] = {
    0xD0, 0xBE, 0xD1, 0x81, 0xD0, 0xB5, 0xD0, 0xBD,
    0xD0, 0xB8, 0xD0, 0xB7, 0xD0, 0xBA, 0xD0, 0xB0,
    0xD0, 0xBD, 0xD0, 0xB4, 0xD0, 0xB8, 0xD0, 0xB4,
    0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_22[] = {
    0xD0, 0xBF, 0xD1, 0x96, 0xD0, 0xB2, 0xD1, 0x84,
    0xD1, 0x96, 0xD0, 0xBD, 0xD0, 0xB0, 0xD0, 0xBB
};
static const symbol s_183[] = {
    0xD1, 0x84, 0xD0, 0xBE, 0xD1, 0x80, 0xD1, 0x82,
    0xD0, 0xB5, 0xD0, 0xBF, 0xD1, 0x96, 0xD0, 0xB0,
    0xD0, 0xBD
};
static const symbol s_24[] = {
    0xD0, 0xB6, 0xD1, 0x83, 0xD1, 0x80, 0xD0, 0xBD,
    0xD0, 0xB0, 0xD0, 0xBB, 0xD0, 0xB0, 0xD1, 0x83,
    0xD1, 0x80, 0xD0, 0xB5, 0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_25[] = {
    0xD1, 0x81, 0xD0, 0xB8, 0xD0, 0xB3, 0xD0, 0xBD,
    0xD0, 0xB0, 0xD0, 0xBB, 0xD0, 0xB8, 0xD0, 0xBF,
    0xD0, 0xBD, 0xD0, 0xB0, 0xD1, 0x83, 0xD0, 0xBA
};
static const symbol s_156[] = {
    0xD0, 0xB1, 0xD0, 0xBE, 0xD1, 0x82, 0xD0, 0xBE,
    0xD1, 0x88, 0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_169[] = {
    0xD0, 0xBF, 0xD0, 0xBE, 0xD0, 0xB7, 0xD0, 0xBD,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_214[] = {
    0xD0, 0xBF, 0xD1, 0x96, 0xD0, 0xB4, 0xD1, 0x82,
    0xD1, 0x80, 0xD0, 0xB8, 0xD0, 0xBC, 0xD0, 0xBA
};
static const symbol s_150[] = {
    0xD1, 0x87, 0xD0, 0xB5, 0xD1, 0x80, 0xD0, 0xBD,
    0xD1, 0x96, 0xD0, 0xB3, 0xD1, 0x80, 0xD0, 0xB0,
    0xD0, 0xBD, 0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_30[] = {
    0xD0, 0xB2, 0xD0, 0xB5, 0xD1, 0x80, 0xD1, 0x81,
    0xD1, 0x82, 0xD0, 0xB2, 0xD1, 0x82, 0xD1, 0x80,
    0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_155[] = {
    0xD0, 0xB0, 0xD1, 0x81, 0xD1, 0x82, 0xD1, 0x80,
    0xD0, 0xB0, 0xD1, 0x85, 0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_236[] = {
    0xD0, 0xB1, 0xD0, 0xBE, 0xD0, 0xBA, 0xD1, 0x80,
    0xD1, 0x83, 0xD0, 0xB3, 0xD0, 0xBE, 0xD1, 0x81,
    0xD1, 0x82, 0xD0, 0xB5, 0xD0, 0xB9
};
static const symbol s_33[] = {
    0xD0, 0xB4, 0xD0, 0xBE, 0xD1, 0x81, 0xD0, 0xB8,
    0xD1, 0x82, 0xD1, 0x8C
};
static const symbol s_34[] = {
    0xD0, 0xB2, 0xD1, 0x82, 0xD0, 0xB5, 0xD0, 0xBA,
    0xD1, 0x81, 0xD0, 0xBF, 0xD0, 0xBE, 0xD0, 0xBD,
    0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_35[] = {
    0xD1, 0x83, 0xD1, 0x82, 0xD0, 0xB5, 0xD0, 0xBA,
    0xD0, 0xBE, 0xD0, 0xBD, 0xD0, 0xBE, 0xD0, 0xBC,
    0xD1, 0x96, 0xD0, 0xBA
};
static const symbol s_36[] = {
    0xD0, 0xBF, 0xD0, 0xBE, 0xD0, 0xBC, 0xD0, 0xB5,
    0xD1, 0x80, 0xD1, 0x83, 0xD0, 0xBA, 0xD0, 0xBB,
    0xD0, 0xB5
};
static const symbol s_178[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xB8, 0xD1, 0x82,
    0xD0, 0xB0, 0xD0, 0xBC, 0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_135[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xBE, 0xD0, 0xBC,
    0xD0, 0xB5, 0xD0, 0xBD
};
static const symbol s_158[] = {
    0xD0, 0xBF, 0xD1, 0x96, 0xD0, 0xB2, 0xD0, 0xB4,
    0xD0, 0xB5, 0xD0, 0xBD
};
static const symbol s_193[] = {
    0xD1, 0x81, 0xD0, 0xBC, 0xD1, 0x83, 0xD0, 0xB3,
    0xD1, 0x80, 0xD1, 0x83, 0xD0, 0xB4, 0xD0, 0xBD
};
static const symbol s_42[] = {
    0xD0, 0xB3, 0xD0, 0xB5, 0xD0, 0xBD, 0xD0, 0xBE,
    0xD0, 0xBC, 0xD0, 0xB0, 0xD1, 0x86, 0xD0, 0xB5
};
static const symbol s_43[] = {
    0xD0, 0xB4, 0xD0, 0xB8, 0xD0, 0xBF, 0xD0, 0xBB,
    0xD0, 0xBE, 0xD0, 0xBC, 0xD0, 0xB0, 0xD0, 0xBA,
    0xD1, 0x81, 0xD0, 0xB8, 0xD0, 0xBC
};
static const symbol s_44[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xB8, 0xD0, 0xB9,
    0xD0, 0xBE, 0xD0, 0xBC, 0xD1, 0x83, 0xD0, 0xB7,
    0xD0, 0xB5, 0xD0, 0xBC, 0xD0, 0xBB
};
static const symbol s_45[] = {
    0xD0, 0xBF, 0xD1, 0x96, 0xD0, 0xB4, 0xD0, 0xB9,
    0xD0, 0xBE, 0xD0, 0xBC, 0xD1, 0x96, 0xD0, 0xBD,
    0xD0, 0xB5, 0xD1, 0x80, 0xD0, 0xB0, 0xD0, 0xBB
};
static const symbol s_46[] = {
    0xD1, 0x81, 0xD0, 0xB8, 0xD0, 0xBD, 0xD0, 0xB4,
    0xD1, 0x80, 0xD0, 0xBE, 0xD0, 0xBC, 0xD0, 0xB0,
    0xD1, 0x80, 0xD0, 0xB3, 0xD0, 0xB0, 0xD1, 0x80,
    0xD0, 0xB8, 0xD1, 0x82
};
static const symbol s_47[] = {
    0xD0, 0xB0, 0xD0, 0xB5, 0xD1, 0x80, 0xD0, 0xBE,
    0xD0, 0xB4, 0xD1, 0x80, 0xD0, 0xBE, 0xD0, 0xBC,
    0xD0, 0xB5, 0xD0, 0xBA, 0xD1, 0x81, 0xD0, 0xB8,
    0xD0, 0xBA, 0xD1, 0x80, 0xD0, 0xB8, 0xD1, 0x82,
    0xD0, 0xB8, 0xD0, 0xBA
};
static const symbol s_48[] = {
    0xD1, 0x88, 0xD0, 0xBE, 0xD0, 0xBB, 0xD0, 0xBE,
    0xD0, 0xBC, 0xD1, 0x96, 0xD1, 0x88, 0xD0, 0xB5,
    0xD0, 0xBD
};
static const symbol s_49[] = {
    0xD0, 0xB0, 0xD1, 0x81, 0xD1, 0x82, 0xD1, 0x80,
    0xD0, 0xBE, 0xD0, 0xBD, 0xD0, 0xBE, 0xD0, 0xBC,
    0xD0, 0xB0, 0xD0, 0xB4, 0xD0, 0xB0, 0xD0, 0xBC,
    0xD1, 0x81, 0xD1, 0x82, 0xD0, 0xB5, 0xD1, 0x80,
    0xD0, 0xB4, 0xD0, 0xB0, 0xD0, 0xBC
};
static const symbol s_219[] = {
    0xD1, 0x81, 0xD1, 0x82, 0xD1, 0x80, 0xD1, 0x96,
    0xD1, 0x87, 0xD0, 0xBA, 0xD1, 0x96, 0xD0, 0xBC,
    0xD0, 0xBD, 0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_227[] = {
    0xD1, 0x85, 0xD0, 0xBE, 0xD0, 0xB4, 0xD0, 0xBE,
    0xD0, 0xBC, 0xD0, 0xB5, 0xD0, 0xBD
};
static const symbol s_171[] = {
    0xD1, 0x8E, 0xD0, 0xBD, 0xD1, 0x8C, 0xD0, 0xBD,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_53[] = {
    0xD1, 0x96, 0xD1, 0x81, 0xD0, 0xBB, 0xD0, 0xB0,
    0xD0, 0xBC, 0xD0, 0xB5, 0xD1, 0x80, 0xD0, 0xB8,
    0xD0, 0xBA
};
static const symbol s_133[] = {
    0xD1, 0x83, 0xD1, 0x87, 0xD0, 0xBD, 0xD0, 0xB0,
    0xD0, 0xB9
};
static const symbol s_55[] = {
    0xD0, 0xB2, 0xD1, 0x96, 0xD0, 0xBB, 0xD1, 0x8C,
    0xD1, 0x8F, 0xD0, 0xBC, 0xD0, 0xB5, 0xD0, 0xBB,
    0xD1, 0x8C, 0xD0, 0xBD, 0xD0, 0xB8, 0xD0, 0xBA
};
static const symbol s_163[] = {
    0xD0, 0xB2, 0xD1, 0x96, 0xD0, 0xB4, 0xD1, 0x81,
    0xD1, 0x82, 0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_177[] = {
    0xD0, 0xB2, 0xD1, 0x96, 0xD0, 0xB4, 0xD0, 0xB0,
    0xD0, 0xBD, 0xD0, 0xB8, 0xD0, 0xBB
};
static const symbol s_58[] = {
    0xD0, 0xB0, 0xD1, 0x80, 0xD1, 0x82, 0xD0, 0xB5,
    0xD0, 0xBC, 0xD0, 0xB0, 0xD1, 0x80, 0xD1, 0x88,
    0xD0, 0xB0, 0xD0, 0xBB
};
static const symbol s_59[] = {
    0xD1, 0x94, 0xD1, 0x80, 0xD1, 0x83, 0xD1, 0x81,
    0xD0, 0xB0, 0xD0, 0xBB, 0xD0, 0xB8, 0xD0, 0xBC,
    0xD0, 0xB8, 0xD0, 0xBA, 0xD0, 0xBE, 0xD0, 0xBB,
    0xD0, 0xB0, 0xD1, 0x94, 0xD0, 0xB2, 0xD0, 0xB0,
    0xD0, 0xBD, 0xD0, 0xB3, 0xD0, 0xB5, 0xD0, 0xBB
};
static const symbol s_60[] = {
    0xD0, 0xB2, '\'', 0xD1, 0x94, 0xD1, 0x82, 0xD0,
    0xBD, 0xD0, 0xB0, 0xD0, 0xBC, 0xD0, 0xB0, 0xD0,
    0xB2, 0xD0, 0xB7, 0xD0, 0xBE, 0xD0, 0xBB, 0xD0,
    0xB5
};
static const symbol s_209[] = {
    0xD0, 0xBF, 0xD1, 0x96, 0xD0, 0xB4, 0xD0, 0xB3,
    0xD0, 0xBE, 0xD1, 0x82, 0xD0, 0xBE, 0xD0, 0xB2,
    0xD0, 0xBA
};
static const symbol s_130[] = {
    0xD0, 0xB6, 0xD0, 0xBE, 0xD0, 0xB2, 0xD1, 0x82,
    0xD0, 0xBD
};
static const symbol s_172[] = {
    0xD1, 0x85, 0xD0, 0xB0, 0xD0, 0xB9, 0xD0, 0xBD,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_65[] = {
    0xD0, 0xBF, 0xD0, 0xB0, 0xD0, 0xBB, 0xD0, 0xB0,
    0xD1, 0x82, 0xD0, 0xB0, 0xD0, 0xB4, 0xD0, 0xB5,
    0xD1, 0x81, 0xD1, 0x8F, 0xD1, 0x82
};
static const symbol s_66[] = {
    0xD0, 0xB3, 0xD0, 0xB0, 0xD1, 0x80, 0xD0, 0xBC,
    0xD0, 0xB0, 0xD1, 0x82, 0xD0, 0xB5, 0xD1, 0x80,
    0xD1, 0x96, 0xD0, 0xB2, 0xD0, 0xBD
};
static const symbol s_67[] = {
    0xD0, 0xB4, 0xD0, 0xB5, 0xD0, 0xBF, 0xD1, 0x83,
    0xD1, 0x82, 0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_140[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xBE, 0xD1, 0x80,
    0xD0, 0xBE, 0xD0, 0xBA, 0xD0, 0xB2, 0xD0, 0xB0,
    0xD1, 0x80, 0xD1, 0x82, 0xD0, 0xB0, 0xD0, 0xBB
};
static const symbol s_69[] = {
    0xD1, 0x81, 0xD0, 0xBE, 0xD0, 0xBB, 0xD0, 0xB4,
    0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_70[] = {
    0xD1, 0x88, 0xD1, 0x82, 0xD0, 0xB0, 0xD1, 0x82,
    0xD1, 0x80, 0xD0, 0xB0, 0xD0, 0xB2, 0xD0, 0xBD
};
static const symbol s_71[] = {
    0xD0, 0xBE, 0xD1, 0x80, 0xD0, 0xB1, 0xD1, 0x96,
    0xD1, 0x82, 0xD0, 0xB5, 0xD1, 0x80, 0xD0, 0xBD,
    0xD0, 0xBE, 0xD0, 0xBF, 0xD0, 0xBE, 0xD0, 0xBB,
    0xD1, 0x96, 0xD1, 0x82, 0xD0, 0xB8, 0xD0, 0xBA
};
static const symbol s_221[] = {
    0xD0, 0xB7, 0xD0, 0xB1, 0xD1, 0x96, 0xD1, 0x80,
    0xD0, 0xBA, 0xD0, 0xB0, 0xD0, 0xBC, 0xD0, 0xB5,
    0xD0, 0xBD
};
static const symbol s_73[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xBE, 0xD1, 0x81,
    0xD0, 0xB2, 0xD1, 0x96, 0xD1, 0x82
};
static const symbol s_200[] = {
    0xD0, 0xB2, 0xD0, 0xB8, 0xD1, 0x81, 0xD1, 0x82,
    0xD0, 0xB0, 0xD0, 0xB2, 0xD0, 0xBA, 0xD0, 0xB0,
    0xD0, 0xBD, 0xD0, 0xB0, 0xD0, 0xBB, 0xD1, 0x8E,
    0xD0, 0xB4, 0xD1, 0x96, 0xD1, 0x82
};
static const symbol s_138[] = {
    0xD0, 0xBF, '\'', 0xD1, 0x8F, 0xD1, 0x82, 0xD0,
    0xBE, 0xD1, 0x87, 0xD0, 0xBA, 0xD0, 0xB0, 0xD1,
    0x80, 0xD0, 0xB4, 0xD0, 0xB8, 0xD0, 0xBD, 0xD0,
    0xB0, 0xD0, 0xBB
};
static const symbol s_154[] = {
    0xD0, 0xB1, 0xD0, 0xB5, 0xD1, 0x80, 0xD0, 0xB5,
    0xD0, 0xB7, 0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_145[] = {
    0xD0, 0xB3, 0xD0, 0xBE, 0xD0, 0xBB, 0xD0, 0xBE,
    0xD0, 0xB2, 0xD0, 0xB8, 0xD0, 0xBC, 0xD0, 0xB5,
    0xD1, 0x80, 0xD0, 0xBE, 0xD1, 0x81, 0xD1, 0x82,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_78[] = {
    0xD1, 0x87, 0xD0, 0xB5, 0xD0, 0xBC, 0xD0, 0xBF,
    0xD1, 0x96, 0xD0, 0xBE, 0xD0, 0xBD, 0xD0, 0xB0,
    0xD1, 0x82
};
static const symbol s_79[] = {
    0xD0, 0xBF, 0xD0, 0xBB, 0xD0, 0xB8, 0xD1, 0x82,
    0xD1, 0x80, 0xD1, 0x96, 0xD0, 0xB9, 0xD0, 0xBA
};
static const symbol s_80[] = {
    0xD0, 0xB0, 0xD0, 0xBF, 0xD0, 0xB0, 0xD1, 0x80,
    0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_81[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xB5, 0xD0, 0xBF,
    0xD0, 0xB0, 0xD1, 0x80, 0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_168[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xB8, 0xD1, 0x81,
    0xD1, 0x82, 0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_83[] = {
    0xD0, 0xB7, 0xD0, 0xB2, 0xD1, 0x96, 0xD1, 0x82,
    0xD0, 0xB0, 0xD0, 0xB9, 0xD0, 0xB2, 0xD0, 0xB0,
    0xD0, 0xBD
};
static const symbol s_84[] = {
    0xD0, 0xBE, 0xD0, 0xBF, 0xD0, 0xBB, 0xD0, 0xB0,
    0xD1, 0x82
};
static const symbol s_86[] = {
    0xD1, 0x81, 0xD0, 0xBF, 0xD0, 0xBB, 0xD0, 0xB0,
    0xD1, 0x82
};
static const symbol s_87[] = {
    0xD0, 0xB2, 0xD0, 0xB8, 0xD0, 0xBF, 0xD0, 0xBB,
    0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_208[] = {
    0xD1, 0x83, 0xD0, 0xB2, 0xD0, 0xB0, 0xD0, 0xB3,
    0xD1, 0x80, 0xD0, 0xB5, 0xD0, 0xB3, 0xD0, 0xB0,
    0xD1, 0x82
};
static const symbol s_89[] = {
    0xD1, 0x96, 0xD1, 0x81, 0xD0, 0xBF, 0xD0, 0xB8,
    0xD1, 0x82
};
static const symbol s_90[] = {
    0xD1, 0x86, 0xD0, 0xB8, 0xD1, 0x82, 0xD0, 0xB0,
    0xD1, 0x82
};
static const symbol s_230[] = {
    0xD1, 0x81, 0xD1, 0x82, 0xD0, 0xBE, 0xD0, 0xBB,
    0xD1, 0x81, 0xD1, 0x82, 0xD1, 0x80, 0xD0, 0xB0,
    0xD1, 0x82
};
static const symbol s_239[] = {
    0xD1, 0x81, 0xD0, 0xBE, 0xD0, 0xBA, 0xD1, 0x80,
    0xD0, 0xB5, 0xD0, 0xBC, 0xD0, 0xBE, 0xD0, 0xB3,
    0xD0, 0xB8, 0xD0, 0xBB
};
static const symbol s_93[] = {
    0xD0, 0xBF, 0xD0, 0xBE, 0xD0, 0xB2, 0xD1, 0x96,
    0xD1, 0x82
};
static const symbol s_94[] = {
    0xD0, 0xB7, 0xD0, 0xB0, 0xD0, 0xBF, 0xD0, 0xB8,
    0xD1, 0x82
};
static const symbol s_95[] = {
    0xD0, 0xB4, 0xD0, 0xB5, 0xD0, 0xBC, 0xD0, 0xBE,
    0xD0, 0xBA, 0xD1, 0x80, 0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_96[] = {
    0xD1, 0x84, 0xD0, 0xBE, 0xD1, 0x80, 0xD0, 0xBC,
    0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_194[] = {
    0xD0, 0xB1, 0xD1, 0x96, 0xD0, 0xB1, 0xD0, 0xBB,
    0xD1, 0x96, 0xD0, 0xBE, 0xD1, 0x82, 0xD0, 0xB5,
    0xD0, 0xBA
};
static const symbol s_212[] = {
    0xD1, 0x81, 0xD1, 0x82, 0xD0, 0xBE, 0xD1, 0x80,
    0xD1, 0x96, 0xD0, 0xBD, 0xD0, 0xBA, 0xD0, 0xBE,
    0xD0, 0xBE, 0xD1, 0x80, 0xD0, 0xB4, 0xD0, 0xB8,
    0xD0, 0xBD, 0xD0, 0xB0, 0xD1, 0x82
};
static const symbol s_99[] = { 0xD1, 0x81, 0xD1, 0x96, 0xD0, 0xBC, '\'' };
static const symbol s_161[] = {
    0xD0, 0xB4, 0xD0, 0xB6, 0xD0, 0xBE, 0xD0, 0xB2,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_191[] = {
    0xD0, 0xB0, 0xD1, 0x84, 0xD1, 0x80, 0xD0, 0xB8,
    0xD0, 0xBA, 0xD0, 0xBB, 0xD0, 0xB0, 0xD0, 0xB4,
    0xD0, 0xBA
};
static const symbol s_102[] = { 0xD1, 0x85, 0xD0, 0xBE, 0xD0, 0xBA, 0xD0, 0xB5 };
static const symbol s_231[] = {
    0xD0, 0xBF, 0xD0, 0xB5, 0xD1, 0x87, 0xD0, 0xB5,
    0xD1, 0x80, 0xD0, 0xB3, 0xD0, 0xBE, 0xD1, 0x80,
    0xD0, 0xB1, 0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_104[] = {
    0xD1, 0x96, 0xD1, 0x94, 0xD1, 0x80, 0xD0, 0xB5,
    0xD0, 0xB6, 0xD0, 0xB8, 0xD0, 0xBC, 0xD1, 0x96,
    0xD0, 0xBD, 0xD1, 0x96, 0xD0, 0xB0, 0xD0, 0xBB,
    0xD1, 0x8C, 0xD0, 0xB1, 0xD0, 0xBE, 0xD0, 0xBC
};
static const symbol s_105[] = { 0xD0, 0xBE, 0xD1, 0x80, 0xD1, 0x84, 0xD0, 0xB5 };
static const symbol s_159[] = {
    0xD1, 0x89, 0xD0, 0xBE, 0xD0, 0xB4, 0xD0, 0xB5,
    0xD0, 0xBD, 0xD0, 0xBE, 0xD0, 0xB2, 0xD0, 0xB5,
    0xD0, 0xBB, 0xD1, 0x96, 0xD1, 0x82
};
static const symbol s_180[] = {
    0xD0, 0xB4, 0xD0, 0xBE, 0xD1, 0x80, 0xD0, 0xBE,
    0xD0, 0xB3, 0xD0, 0xBE, 0xD1, 0x86, 0xD1, 0x96,
    0xD0, 0xBD
};
static const symbol s_108[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xBE, 0xD0, 0xBC,
    0xD0, 0xB5, 0xD1, 0x82, 0xD0, 0xB5, 0xD1, 0x85,
    0xD0, 0xBD, 0xD1, 0x96, 0xD0, 0xBA
};
static const symbol s_109[] = {
    0xD0, 0xBF, 0xD1, 0x82, 0xD0, 0xBE, 0xD0, 0xBB,
    0xD0, 0xB5, 0xD0, 0xBC, 0xD0, 0xB5, 0xD1, 0x82,
    0xD0, 0xB0, 0xD0, 0xBB
};
static const symbol s_110[] = {
    0xD1, 0x81, 0xD1, 0x96, 0xD0, 0xB4, 0xD0, 0xBD,
    0xD0, 0xB5, 0xD0, 0xBC, 0xD0, 0xB0, 0xD0, 0xBB
};
static const symbol s_111[] = {
    0xD0, 0xB4, 0xD1, 0x96, 0xD1, 0x81, 0xD0, 0xBD,
    0xD0, 0xB5, 0xD0, 0xB2, 0xD0, 0xB4, 0xD0, 0xB0,
    0xD0, 0xBB
};
static const symbol s_112[] = {
    0xD0, 0xB1, 0xD1, 0x80, 0xD1, 0x83, 0xD0, 0xBD,
    0xD0, 0xB5, 0xD1, 0x87, 0xD0, 0xB8, 0xD1, 0x81,
    0xD0, 0xBB, 0xD0, 0xB5, 0xD0, 0xBD
};
static const symbol s_114[] = {
    0xD1, 0x96, 0xD1, 0x80, 0xD0, 0xB8, 0xD0, 0xBD,
    0xD0, 0xB5, 0xD1, 0x81, 0xD0, 0xBA, 0xD1, 0x96,
    0xD0, 0xBD, 0xD1, 0x87, 0xD0, 0xB5, 0xD0, 0xBD
};
static const symbol s_115[] = {
    0xD1, 0x8E, 0xD0, 0xB2, 0xD1, 0x96, 0xD0, 0xBB,
    0xD0, 0xB5
};
static const symbol s_116[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xB8, 0xD0, 0xB2,
    0xD1, 0x96, 0xD0, 0xBB, 0xD0, 0xB5
};
static const symbol s_202[] = {
    0xD0, 0xBF, 0xD1, 0x80, 0xD0, 0xB0, 0xD0, 0xB3,
    0xD1, 0x80, 0xD0, 0xBE, 0xD0, 0xBD, 0xD0, 0xBE,
    0xD0, 0xBC, 0xD1, 0x83, 0xD0, 0xB7, 0xD0, 0xB8,
    0xD0, 0xBA, 0xD0, 0xBD, 0xD0, 0xB8, 0xD0, 0xB3,
    0xD0, 0xB5, 0xD0, 0xBD, 0xD0, 0xB5, 0xD1, 0x80,
    0xD0, 0xB0, 0xD0, 0xBB
};
static const symbol s_149[] = {
    0xD1, 0x85, 0xD0, 0xB0, 0xD1, 0x80, 0xD0, 0xBA,
    0xD0, 0xBE, 0xD0, 0xB2, 0xD1, 0x96, 0xD0, 0xBA,
    0xD0, 0xBE, 0xD1, 0x82
};
static const symbol s_119[] = {
    0xD0, 0xB4, 0xD0, 0xB8, 0xD1, 0x81, 0xD0, 0xBF,
    0xD0, 0xBB, 0xD0, 0xB5
};
static const symbol s_153[] = {
    0xD0, 0xB1, 0xD0, 0xBE, 0xD1, 0x80, 0xD0, 0xB8,
    0xD1, 0x81, 0xD0, 0xBF, 0xD0, 0xBE, 0xD0, 0xBB
};
static const symbol s_226[] = {
    0xD1, 0x80, 0xD0, 0xB8, 0xD0, 0xB3, 0xD0, 0xBE,
    0xD0, 0xBD, 0xD0, 0xBA, 0xD1, 0x80, 0xD0, 0xB8,
    0xD1, 0x81, 0xD1, 0x82, 0xD0, 0xB0, 0xD0, 0xBB
};
static const symbol s_122[] = {
    0xD1, 0x81, 0xD1, 0x96, 0xD1, 0x87, 0xD0, 0xBD,
    0xD0, 0xBE, 0xD1, 0x87, 0xD0, 0xB8, 0xD0, 0xBC,
    0xD0, 0xB0, 0xD0, 0xBB, 0xD0, 0xBE, 0xD0, 0xB7,
    0xD0, 0xB0, 0xD0, 0xBD
};
static const symbol s_123[] = {
    0xD0, 0xB1, 0xD0, 0xB5, 0xD1, 0x80, 0xD0, 0xB5,
    0xD0, 0xB7, 0xD0, 0xBD
};
static const symbol s_198[] = {
    0xD1, 0x84, 0xD1, 0x83, 0xD1, 0x82, 0xD0, 0xB1,
    0xD0, 0xBE, 0xD0, 0xBB, 0xD0, 0xBA, 0xD0, 0xB8,
    0xD1, 0x80, 0xD0, 0xB8, 0xD0, 0xBB, 0xD1, 0x96,
    0xD0, 0xB3, 0xD0, 0xB0, 0xD0, 0xBB, 0xD1, 0x96,
    0xD0, 0xBB, 0xD0, 0xB5
};
static const symbol s_192[] = {
    0xD1, 0x80, 0xD0, 0xB5, 0xD1, 0x81, 0xD0, 0xBF,
    0xD1, 0x83, 0xD0, 0xB1, 0xD0, 0xBB, 0xD1, 0x96,
    0xD0, 0xBA
};
static const symbol s_126[] = {
    0xD1, 0x87, 0xD0, 0xB5, 0xD1, 0x80, 0xD0, 0xB2,
    0xD0, 0xBD, 0xD0, 0xB0, 0xD0, 0xBF, 0xD1, 0x80,
    0xD1, 0x8F, 0xD0, 0xBC
};
static const symbol s_184[] = {
    0xD0, 0xBF, 0xD0, 0xBE, 0xD0, 0xB2, 0xD0, 0xBD,
    0xD0, 0xBE, 0xD1, 0x86, 0xD1, 0x96, 0xD0, 0xBD
};
static const symbol s_128[] = {
    0xD1, 0x81, 0xD0, 0xB5, 0xD1, 0x80, 0xD0, 0xBF,
    0xD0, 0xBD
};
static const symbol s_129[] = {
    0xD0, 0xB2, 0xD0, 0xB5, 0xD1, 0x80, 0xD0, 0xB5,
    0xD1, 0x81, 0xD0, 0xBD
};

static const unsigned short a_0[] = {
    0x0000 , 0x8CB8 , 0x0004 , 0x0010 , 0x0000 , 0x0009 , 0x000C , S(B2D0),
    S(88D1), S(B8D0), S(81D1), S(00D1), 0x0001 , 0x0002 , 0xFFFE , S(B8D0),
    0x0000 , 0xD0D0 , 0x0013 , 0x0000 , 0x8788 , 0x0017 , 0x0089 , 0x0000 ,
    0xD1D1 , 0x001A , 0x0000 , 0xB083 , 0x004A , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004D ,
    0x004A , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0086 , 0x0000 , 0xD1D1 , 0xFFFD , 0x0000 , 0xD1D1 , 0x0050 ,
    0x0000 , 0xB083 , 0x0080 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0083 , 0x004A , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004A , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0086 ,
    0x0000 , 0xD1D1 , 0xFFFC , 0x0000 , 0xD1D1 , 0xFFFB , 0x0000 , 0xD0D0 ,
    0xFFFD , 0x0000 , 0x0003 , 0x000C , S(B2D0), S(00D1)
};

static const unsigned short a_1[] = {
    0x0000 , 0x0008 , 0x0007 , S(82D1), S(8CD1), S(81D1), S(8FD1), 0x0000 ,
    0xB88E , 0x0034 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0073 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0070 , 0x0000 , 0x0000 , 0x0070 , 0x0000 , 0xD1D1 , 0x0037 , 0x0000 ,
    0xB083 , 0x0067 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x006A , 0x006D , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0070 , 0x0000 ,
    0xD1D1 , 0xFFFE , 0x0000 , 0xD1D1 , 0xFFFD , 0x0000 , 0xD1D1 , 0xFFFF ,
    0x0000 , 0xD0D0 , 0xFFFF , 0x0000 , 0xD1D1 , 0x0076 , 0x0001 , 0xB083 ,
    0x0067 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x006A , 0x006D , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0070
};

static const unsigned short a_2[] = {
    0x0000 , 0x8C8F , 0x0004 , 0x0021 , 0x0000 , 0x0003 , 0x0009 , S(81D1),
    S(00D1), 0x0001 , 0xB8B0 , 0x0014 , 0x0000 , 0x0019 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x001C , 0x0000 , 0x0003 , 0xFFFF , S(BBD0),
    S(00D0), 0x0000 , 0xD0D0 , 0xFFFF , 0x0000 , 0x0003 , 0xFFFF , S(82D1),
    S(00D0), 0x0000 , 0x0003 , 0x0026 , S(81D1), S(00D1), 0x0001 , 0xB2B8 ,
    0x0019 , 0x001C
};

static const unsigned short a_3[] = {
    0x0000 , 0xBE83 , 0x003E , 0x0000 , 0x00E2 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x012B , 0x0000 , 0x0168 , 0x00E9 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x01B9 , 0x01CA , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x01D1 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x01B4 , 0x0000 , 0x0000 , 0x01D8 ,
    0x01E1 , 0x0000 , 0x0000 , 0x0226 , 0x0000 , 0x025A , 0x0000 , 0xD1D1 ,
    0x0041 , 0x0000 , 0xBCBD , 0x0045 , 0x009E , 0x0000 , 0x0005 , 0x004B ,
    S(BDD0), S(BED0), S(00D0), 0x0000 , 0xB987 , 0x0080 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x008D , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0094 ,
    0x0000 , 0xD1D1 , 0x0083 , 0x0000 , 0x96B8 , 0x0087 , 0x008A , 0x0000 ,
    0xD1D1 , 0xFFFF , 0x0000 , 0xD0D0 , 0xFFFF , 0x0000 , 0x0007 , 0xFFFF ,
    S(83D1), S(B0D0), S(BBD0), S(00D1), 0x0000 , 0x0003 , 0x0099 , S(96D1),
    S(00D0), 0x0001 , 0x0004 , 0xFFFF , S(B0D0), S(86D1), 0x0000 , 0xD0D0 ,
    0x00A1 , 0x0000 , 0xB987 , 0x00D6 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x008D , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00DD , 0x0000 , 0xD1D1 ,
    0x00D9 , 0x0000 , 0x96B8 , 0x0087 , 0x008A , 0x0000 , 0x0003 , 0x0099 ,
    S(96D1), S(00D0), 0x0000 , 0xD1D1 , 0x00E5 , 0x0000 , 0x8FB8 , 0x00E9 ,
    0x00EE , 0x0000 , 0x0003 , 0x0099 , S(96D1), S(00D1), 0x0000 , 0x0003 ,
    0x00F3 , S(BDD0), S(00D0), 0x0000 , 0xB987 , 0x0128 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x008D , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00DD ,
    0x0000 , 0xD1D1 , 0x00D9 , 0x0000 , 0x0009 , 0x0133 , S(BDD0), S(96D1),
    S(81D1), S(82D1), S(00D1), 0x0000 , 0xB987 , 0x0128 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x008D , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00DD ,
    0x0000 , 0xD1D1 , 0x016B , 0x0000 , 0xBE82 , 0x01AA , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00E9 ,
    0x0000 , 0x01B1 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x01B4 , 0x0000 , 0x0007 , 0x0133 , S(BDD0), S(96D1), S(81D1),
    S(00D1), 0x0000 , 0xD1D1 , 0x0099 , 0x0000 , 0x0003 , 0x0133 , S(BDD0),
    S(00D0), 0x0000 , 0xD1D1 , 0x01BC , 0x0000 , 0x82BD , 0x01C0 , 0x01C7 ,
    0x0000 , 0x0007 , 0x0133 , S(BDD0), S(BED0), S(81D1), S(00D1), 0x0000 ,
    0xD0D0 , 0x0133 , 0x0000 , 0xD1D1 , 0x01CD , 0x0000 , 0x96BE , 0x01B1 ,
    0x01B4 , 0x0000 , 0xD0D0 , 0x01D4 , 0x0000 , 0x96BD , 0x0087 , 0x01C7 ,
    0x0000 , 0x0003 , 0x01DD , S(BCD0), S(00D0), 0x0000 , 0x8FB8 , 0x00E9 ,
    0x01B4 , 0x0000 , 0xD0D0 , 0x01E4 , 0x0000 , 0xB896 , 0x0209 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0215 , 0x0000 , 0x0000 ,
    0x01B4 , 0x0000 , 0xD1D1 , 0x020C , 0x0001 , 0x86BD , 0x0210 , 0x01C7 ,
    0x0000 , 0x0003 , 0xFFFF , S(B0D0), S(00D1), 0x0000 , 0x0009 , 0x021D ,
    S(BDD0), S(BED0), S(81D1), S(82D1), S(00D0), 0x0000 , 0x878C , 0x0221 ,
    0x008D , 0x0000 , 0x0003 , 0xFFFF , S(B8D0), S(00D1), 0x0000 , 0xD0D0 ,
    0x0229 , 0x0000 , 0xB88F , 0x00E9 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0255 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x01B4 , 0x0000 , 0x0003 , 0xFFFF ,
    S(96D1), S(00D1), 0x0000 , 0xD0D0 , 0x025D , 0x0000 , 0xB3BD , 0x0261 ,
    0x01C7 , 0x0000 , 0x0005 , 0x0133 , S(BDD0), S(BED0), S(00D0)
};

static const unsigned short a_4[] = {
    0x0000 , 0xBE83 , 0x003E , 0x0000 , 0x0053 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0081 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00B7 , 0x00CF , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00D4 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00E4 , 0x0000 , 0x0000 , 0x00EB ,
    0x0115 , 0x0000 , 0x0000 , 0x0123 , 0x0000 , 0x0126 , 0x0000 , 0xD1D1 ,
    0x0041 , 0x0000 , 0x88BC , 0x0045 , 0x004A , 0x0000 , 0x0003 , 0xFFFF ,
    S(96D1), S(00D1), 0x0000 , 0x0003 , 0x004F , S(BED0), S(00D0), 0x0001 ,
    0x0002 , 0xFFFF , S(8CD1), 0x0000 , 0xD1D1 , 0x0056 , 0x0000 , 0xB896 ,
    0x007B , 0x007B , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x007E , 0x0000 , 0xD1D1 , 0xFFFF , 0x0000 , 0xD0D0 ,
    0xFFFF , 0x0000 , 0xD1D1 , 0x0084 , 0x0000 , 0xBE94 , 0x007B , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00B1 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x00B4 , 0x0000 , 0xD0D0 , 0xFFFE , 0x0000 , 0xD0D0 , 0x004F , 0x0000 ,
    0xD1D1 , 0x00BA , 0x0000 , 0x87BD , 0x00BE , 0x00C5 , 0x0000 , 0xD1D1 ,
    0x00C1 , 0x0000 , 0x838E , 0x007B , 0x007B , 0x0000 , 0x0005 , 0x00CB ,
    S(B2D0), S(B0D0), S(00D0), 0x0000 , 0x83BE , 0x007B , 0x007E , 0x0000 ,
    0x0003 , 0x004F , S(BED0), S(00D1), 0x0000 , 0xD0D0 , 0x00D7 , 0x0000 ,
    0x87BD , 0x00DB , 0x00DE , 0x0000 , 0xD1D1 , 0x00C1 , 0x0000 , 0x0005 ,
    0x00CB , S(B2D0), S(B0D0), S(00D0), 0x0000 , 0xD0D0 , 0x00E7 , 0x0000 ,
    0x87BD , 0x00DB , 0x00DE , 0x0000 , 0x0003 , 0x00F0 , S(BCD0), S(00D0),
    0x0000 , 0xB896 , 0x007B , 0x007B , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x007E , 0x0000 , 0xD0D0 , 0x0118 ,
    0x0000 , 0x96B8 , 0x007B , 0x011C , 0x0000 , 0xD0D0 , 0x011F , 0x0001 ,
    0x87BD , 0x00DB , 0x00DE , 0x0000 , 0xD0D0 , 0x00F0 , 0x0000 , 0xD0D0 ,
    0x0129 , 0x0000 , 0xB3BD , 0x012D , 0x00DE , 0x0000 , 0x0003 , 0x004F ,
    S(BED0), S(00D0)
};

static const unsigned short a_5[] = {
    0x0000 , 0xBE83 , 0x003E , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004E ,
    0x0000 , 0x0000 , 0x0000 , 0x00B4 , 0x0000 , 0x015C , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0163 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0166 ,
    0x0000 , 0x019A , 0x0000 , 0x0000 , 0x01CF , 0x0000 , 0x0000 , 0x0233 ,
    0x0298 , 0x0000 , 0x0000 , 0x029F , 0x0000 , 0x02A4 , 0x0000 , 0xD1D1 ,
    0x0041 , 0x0009 , 0x0006 , 0x0047 , S(82D1), S(B8D0), S(BCD0), 0x0000 ,
    0xB0B8 , 0x004B , 0x004B , 0x0000 , 0xD0D0 , 0xFFFF , 0x0000 , 0xD1D1 ,
    0x0051 , 0x0000 , 0xB894 , 0x0078 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004B , 0x0000 , 0x0000 , 0x004B ,
    0x0000 , 0xD1D1 , 0x007B , 0x0001 , 0xB083 , 0x00AB , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x00AE , 0x00B1 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x004B , 0x0000 , 0xD1D1 , 0xFFFA , 0x0000 , 0xD1D1 ,
    0xFFF9 , 0x0000 , 0xD1D1 , 0xFFFF , 0x0000 , 0x0003 , 0x00B9 , S(82D1),
    S(00D1), 0x0000 , 0xB883 , 0x00F1 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0126 , 0x0159 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00B1 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x004B , 0x0000 , 0xD1D1 , 0x00F4 , 0x0001 , 0x0006 , 0x00FA , S(82D1),
    S(B8D0), S(BCD0), 0x0000 , 0xB88F , 0x00B1 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004B , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004B , 0x0000 , 0xD1D1 ,
    0x0129 , 0x0001 , 0xB083 , 0x00AB , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00AE , 0x00B1 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x004B , 0x0000 , 0xD1D1 , 0xFFFB , 0x0000 , 0xD1D1 , 0x015F , 0x000B ,
    0x0002 , 0xFFFF , S(B0D0), 0x0000 , 0xD1D1 , 0x0129 , 0x0000 , 0x0003 ,
    0x016B , S(BBD0), S(00D0), 0x000A , 0xB88F , 0x00B1 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00B1 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0197 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004B , 0x0000 ,
    0xD0D0 , 0xFFFC , 0x0000 , 0xD0D0 , 0x019D , 0x0008 , 0xB88F , 0x00B1 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x01C9 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x01CC , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x01CC , 0x0000 , 0xD1D1 , 0xFFFD , 0x0000 , 0xD0D0 , 0xFFFD , 0x0000 ,
    0xD0D0 , 0x01D2 , 0x0000 , 0x82BC , 0x01D6 , 0x0201 , 0x0000 , 0xD1D1 ,
    0x01D9 , 0x0000 , 0xB994 , 0x0163 , 0x0000 , 0x00B1 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004B , 0x0000 , 0x0000 , 0x004B ,
    0x004B , 0x0000 , 0x0005 , 0x0207 , S(82D1), S(B8D0), S(00D0), 0x0000 ,
    0xB88F , 0x00B1 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x00B1 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x004B , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x004B , 0x0000 , 0xD0D0 , 0x0236 , 0x0000 , 0x82BB ,
    0x023A , 0x0269 , 0x0000 , 0xD1D1 , 0x023D , 0x000C , 0xB88F , 0x0159 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00B1 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x004B , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x004B , 0x0000 , 0xD0D0 , 0x026C , 0x000A , 0xB88F , 0x00B1 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00B1 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0197 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004B ,
    0x0000 , 0xD0D0 , 0x029B , 0x0001 , 0x0002 , 0xFFFE , S(B5D0), 0x0000 ,
    0x0003 , 0xFFFF , S(94D1), S(00D0), 0x0000 , 0xD0D0 , 0x02A7 , 0x0000 ,
    0xBBBC , 0x02AB , 0x02AE , 0x0000 , 0xD0D0 , 0x026C , 0x0000 , 0xD0D0 ,
    0x02B1 , 0x0000 , 0xB894 , 0x0163 , 0x0000 , 0x00B1 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x02D8 , 0x0000 , 0x0000 , 0x004B ,
    0x0000 , 0xD0D0 , 0x02DB , 0x0001 , 0x0008 , 0xFFFF , S(B0D0), S(82D1),
    S(B8D0), S(BCD0)
};

static const unsigned short a_6[] = {
    0x0000 , 0x968C , 0x000D , 0x0000 , 0x000D , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0014 , 0x0000 , 0x0007 , 0xFFFF ,
    S(96D1), S(81D1), S(82D1), S(00D1), 0x0000 , 0x0005 , 0x001A , S(81D1),
    S(82D1), S(00D1), 0x0000 , 0x96BE , 0x001E , 0x0021 , 0x0000 , 0xD1D1 ,
    0xFFFF , 0x0000 , 0xD0D0 , 0xFFFF
};

static const unsigned short a_7[] = {
    0x0000 , 0xBE83 , 0x003E , 0x0000 , 0x004E , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0061 , 0x0000 , 0x0067 , 0x0048 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x006E , 0x0048 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00BA ,
    0x0000 , 0x00C2 , 0x0000 , 0x0000 , 0x00B7 , 0x0000 , 0x0000 , 0x00C7 ,
    0x0000 , 0x0000 , 0x0000 , 0x00D5 , 0x0000 , 0x010A , 0x0000 , 0x0005 ,
    0x0044 , S(82D1), S(B2D0), S(00D1), 0x0000 , 0x8186 , 0x0048 , 0x004B ,
    0x0000 , 0xD1D1 , 0xFFFD , 0x0000 , 0xD1D1 , 0xFFFE , 0x0000 , 0xD1D1 ,
    0x0051 , 0x0000 , 0x8FB0 , 0x0048 , 0x0055 , 0x0000 , 0xD0D0 , 0x0058 ,
    0x0003 , 0x0004 , 0x005D , S(82D1), S(B2D0), 0x0000 , 0x8186 , 0x0048 ,
    0x004B , 0x0000 , 0x0005 , 0xFFFE , S(B5D0), S(86D1), S(00D1), 0x0000 ,
    0x0007 , 0xFFFF , S(96D1), S(81D1), S(82D1), S(00D1), 0x0000 , 0xD1D1 ,
    0x0071 , 0x0003 , 0x0002 , 0x0075 , S(B2D0), 0x0000 , 0xBE82 , 0x00B4 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x00B7 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x00B7 , 0x0000 , 0xD1D1 , 0x005D , 0x0000 ,
    0xD0D0 , 0xFFFD , 0x0000 , 0xD0D0 , 0x00BD , 0x0003 , 0x0004 , 0x005D ,
    S(82D1), S(B2D0), 0x0000 , 0x0003 , 0x005D , S(82D1), S(00D0), 0x0000 ,
    0xD0D0 , 0x00CA , 0x0003 , 0x0002 , 0x00CE , S(BCD0), 0x0000 , 0x8FB0 ,
    0x0048 , 0x00D2 , 0x0000 , 0xD0D0 , 0x00BD , 0x0000 , 0xD0D0 , 0x00D8 ,
    0x0000 , 0xBE8F , 0x0048 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x00D2 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x00B7 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x00D2 , 0x0000 , 0xD0D0 , 0x010D , 0x0003 , 0x0004 , 0x0112 ,
    S(82D1), S(B2D0), 0x0003 , 0x0002 , 0xFFFD , S(81D1)
};

static const unsigned short a_8[] = {
    0x0000 , 0xBA80 , 0x003D , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x004A , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004F , 0x0000 , 0xD1D1 , 0x0040 ,
    0x0000 , 0x8FB0 , 0x0044 , 0x0047 , 0x0000 , 0xD1D1 , 0xFFFF , 0x0000 ,
    0xD0D0 , 0xFFFE , 0x0000 , 0x0003 , 0xFFFF , S(B0D0), S(00D1), 0x0000 ,
    0x0005 , 0x0055 , S(BDD0), S(B8D0), S(00D0), 0x0001 , 0x8CB2 , 0x0059 ,
    0x0065 , 0x0000 , 0x0003 , 0x005E , S(BBD0), S(00D1), 0x0000 , 0xB0B5 ,
    0x0062 , 0x0062 , 0x0000 , 0xD0D0 , 0xFFFF , 0x0000 , 0x0003 , 0xFFFF ,
    S(96D1), S(00D0)
};

static const unsigned short a_9[] = {
    0x0000 , 0xBE83 , 0x003E , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0046 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004C , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00D4 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0148 ,
    0x0000 , 0x01B2 , 0x0000 , 0x0000 , 0x0000 , 0x01BB , 0x0000 , 0x0009 ,
    0xFFFF , S(B5D0), S(BDD0), S(8CD1), S(BAD0), S(00D1), 0x0000 , 0x0005 ,
    0xFFFF , S(83D1), S(BDD0), S(00D1), 0x0000 , 0x0003 , 0x0051 , S(BAD0),
    S(00D1), 0x0000 , 0x878C , 0x0055 , 0x0091 , 0x0000 , 0xD1D1 , 0x0058 ,
    0x0000 , 0xBE96 , 0x0083 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0086 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x008E , 0x0000 , 0xD1D1 , 0xFFFF , 0x0000 , 0xD0D0 ,
    0x0089 , 0x0001 , 0x0004 , 0xFFFF , S(BED0), S(87D1), 0x0000 , 0xD0D0 ,
    0xFFFF , 0x0000 , 0x0003 , 0x0096 , S(BDD0), S(00D1), 0x0000 , 0xBE96 ,
    0x00C1 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00CC ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x008E , 0x0000 , 0xD1D1 , 0x00C4 , 0x0001 , 0x0002 , 0x00C8 , S(81D1),
    0x0000 , 0x8E96 , 0x0083 , 0x0083 , 0x0000 , 0xD0D0 , 0x00CF , 0x0001 ,
    0x0004 , 0xFFFF , S(B5D0), S(81D1), 0x0000 , 0x0003 , 0x00D9 , S(BAD0),
    S(00D0), 0x0000 , 0x878C , 0x00DD , 0x010E , 0x0000 , 0xD1D1 , 0x00E0 ,
    0x0000 , 0xBE96 , 0x0083 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x010B , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x008E , 0x0000 , 0xD0D0 , 0x0089 , 0x0000 , 0x0003 ,
    0x0113 , S(BDD0), S(00D1), 0x0000 , 0xBE96 , 0x013E , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0145 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x008E , 0x0000 , 0xD1D1 ,
    0x0141 , 0x0001 , 0x0002 , 0x00C8 , S(81D1), 0x0000 , 0xD0D0 , 0x00CF ,
    0x0000 , 0x0003 , 0x014D , S(BAD0), S(00D0), 0x0000 , 0x878C , 0x0151 ,
    0x017F , 0x0000 , 0xD1D1 , 0x0154 , 0x0000 , 0xBE96 , 0x0083 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x010B , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x008E , 0x0000 ,
    0x0003 , 0x0184 , S(BDD0), S(00D1), 0x0000 , 0xBE96 , 0x01AF , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0145 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x008E , 0x0000 ,
    0xD1D1 , 0x0141 , 0x0000 , 0x0003 , 0x01B7 , S(BED0), S(00D0), 0x0002 ,
    0x0002 , 0x0154 , S(87D1), 0x0000 , 0x0003 , 0x01C0 , S(BAD0), S(00D0),
    0x0000 , 0x8C82 , 0x01CD , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x01F4 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x01F7 , 0x0000 , 0xD1D1 , 0x01D0 ,
    0x0000 , 0xB08F , 0x0083 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0083 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x008E , 0x0000 , 0xD1D1 , 0x0154 , 0x0000 ,
    0x0003 , 0x01FC , S(BDD0), S(00D1), 0x0000 , 0xBE96 , 0x01AF , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0145 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x008E
};

static const unsigned short a_10[] = {
    0x0000 , 0x0006 , 0x0006 , S(BDD0), S(8CD1), S(BAD0), 0x0000 , 0xBE96 ,
    0x0031 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x003F ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0047 , 0x0000 , 0xD1D1 , 0x0034 , 0x0001 , 0x0002 , 0x0038 , S(81D1),
    0x0000 , 0x8E96 , 0x003C , 0x003C , 0x0000 , 0xD1D1 , 0xFFFF , 0x0000 ,
    0xD0D0 , 0x0042 , 0x0001 , 0x0004 , 0xFFFF , S(B5D0), S(81D1), 0x0000 ,
    0xD0D0 , 0xFFFF
};

static const unsigned short a_11[] = {
    0x0000 , 0xBC85 , 0x003A , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0042 , 0x0000 , 0x0048 , 0x0048 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0048 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x004F , 0x0000 , 0x0000 ,
    0x0000 , 0x0058 , 0x0000 , 0x0009 , 0xFFFF , S(96D1), S(BDD0), S(BDD0),
    S(8FD1), S(00D1), 0x0000 , 0x0005 , 0xFFFF , S(96D1), S(BDD0), S(00D1),
    0x0000 , 0x0007 , 0xFFFF , S(96D1), S(BDD0), S(BDD0), S(00D1), 0x0000 ,
    0x000B , 0xFFFF , S(96D1), S(BDD0), S(BDD0), S(8FD1), S(BCD0), S(00D0),
    0x0000 , 0x0009 , 0xFFFF , S(96D1), S(BDD0), S(BDD0), S(8FD1), S(00D0)
};

static const unsigned short a_12[] = {
    0x0000 , 0xBC85 , 0x003A , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0070 , 0x0000 , 0x009E , 0x009E , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x009E , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00A4 , 0x0000 , 0x0000 ,
    0x0000 , 0x00AC , 0x0000 , 0x0007 , 0x0041 , S(BDD0), S(BDD0), S(8FD1),
    S(00D1), 0x0000 , 0xB58F , 0x006A , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x006D , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x006D , 0x0000 , 0xD1D1 , 0xFFFF , 0x0000 , 0xD0D0 , 0xFFFF ,
    0x0000 , 0x0003 , 0x0075 , S(BDD0), S(00D1), 0x0000 , 0xB58F , 0x006A ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x006D , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x006D , 0x0000 , 0x0005 ,
    0x0075 , S(BDD0), S(BDD0), S(00D1), 0x0000 , 0x0009 , 0x0075 , S(BDD0),
    S(BDD0), S(8FD1), S(BCD0), S(00D0), 0x0000 , 0x0007 , 0x0075 , S(BDD0),
    S(BDD0), S(8FD1), S(00D0)
};

static const unsigned short a_13[] = {
    0x0000 , 0xBD82 , 0x003E , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0050 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0055 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x00A4 , 0x0000 , 0x00AD , 0x00B3 , 0x0000 , 0xD1D1 ,
    0x0041 , 0x0000 , 0x81B0 , 0x0045 , 0x004A , 0x0000 , 0x0003 , 0xFFFF ,
    S(96D1), S(00D1), 0x0000 , 0x0005 , 0xFFFF , S(83D1), S(B2D0), S(00D0),
    0x0000 , 0x0003 , 0xFFFF , S(B8D0), S(00D1), 0x0000 , 0xD0D0 , 0x0058 ,
    0x0000 , 0xBE83 , 0x0096 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x009E , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00A1 , 0x0000 , 0xD1D1 ,
    0x0099 , 0x0001 , 0x0004 , 0xFFFF , S(BED0), S(B2D0), 0x0000 , 0xD1D1 ,
    0xFFFF , 0x0000 , 0xD0D0 , 0xFFFF , 0x0000 , 0x0003 , 0x00A9 , S(8CD1),
    S(00D0), 0x0000 , 0x81B7 , 0x009E , 0x00A1 , 0x0000 , 0x0005 , 0xFFFF ,
    S(96D1), S(B7D0), S(00D0), 0x0000 , 0xD0D0 , 0x00B6 , 0x0000 , 0xB28C ,
    0x00DF , 0x0000 , 0x0000 , 0x009E , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00F0 , 0x0000 , 0x0135 , 0x0000 ,
    0xD1D1 , 0x00E2 , 0x0001 , 0x0002 , 0x00E6 , S(BBD0), 0x0000 , 0xB0B5 ,
    0x00EA , 0x00ED , 0x0000 , 0xD0D0 , 0xFFFD , 0x0000 , 0xD0D0 , 0xFFFE ,
    0x0000 , 0xD0D0 , 0x00F3 , 0x0004 , 0x0002 , 0x00F7 , S(B2D0), 0x0000 ,
    0xBE83 , 0x009E , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x009E , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00A1 , 0x0000 , 0x0003 , 0xFFFF ,
    S(96D1), S(00D0)
};

static const unsigned short a_14[] = {
    0x0000 , 0xBD88 , 0x0038 , 0x0000 , 0x0000 , 0x0000 , 0x003D , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0040 , 0x0000 , 0x0043 ,
    0x0000 , 0x0003 , 0xFFFF , S(96D1), S(00D1), 0x0000 , 0xD1D1 , 0xFFFC ,
    0x0000 , 0xD0D0 , 0xFFFE , 0x0000 , 0xD0D0 , 0xFFFD
};

static const unsigned short a_15[] = {
    0x0000 , 0xD0D1 , 0x0004 , 0x0BA1 , 0x0000 , 0xBFB0 , 0x0016 , 0x00B4 ,
    0x014A , 0x0310 , 0x038F , 0x04E6 , 0x0512 , 0x0528 , 0x0000 , 0x0000 ,
    0x05AF , 0x06B7 , 0x0742 , 0x0874 , 0x08E5 , 0x095F , 0x0000 , 0xD0D1 ,
    0x001A , 0x007E , 0x0000 , 0xBFB3 , 0x0029 , 0x003F , 0x0048 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0055 , 0x0060 , 0x0000 , 0x0000 ,
    0x0076 , 0x0000 , 0x0003 , 0x002E , S(80D1), S(00D0), 0x0000 , 0xB5BE ,
    0x0032 , 0x0039 , 0x0000 , 0x0008 , 0xFFA0 , S(B3D0), S(B0D0), S(82D1),
    S(B8D0), 0x0000 , 0x0006 , 0xFFCF , S(BDD0), S(BED0), S(BCD0), 0x0000 ,
    0x000C , 0xFFEF , S(BCD0), S(96D1), S(80D1), S(B0D0), S(BBD0), S(B0D0),
    0x0000 , 0x000C , 0x0051 , S(80D1), S(BED0), S(B4D0), S(80D1), S(BED0),
    S(BCD0), 0x002E , 0x0002 , 0xFFD2 , S(83D1), 0x0000 , 0x0008 , 0x005C ,
    S(8CD1), S(B1D0), S(BED0), S(BCD0), 0x0027 , 0x0002 , 0xFFD9 , S(83D1),
    0x0000 , 0xD0D1 , 0x0064 , 0x006C , 0x0000 , 0x0009 , 0xFF44 , S(D1B5),
    S(D080), S(D1B8), S(D186), S(0096), 0x0000 , 0x000D , 0xFFC4 , S(D181),
    S(D082), S(D1B5), S(D080), S(D0B4), S(D0B0), S(00BC), 0x0000 , 0x000A ,
    0xFFB1 , S(B0D0), S(80D1), S(B0D0), S(82D1), S(B8D0), 0x0000 , 0x8480 ,
    0x0085 , 0x0096 , 0x0000 , 0x0000 , 0x00AD , 0x0000 , 0xD1D1 , 0x0088 ,
    0x0000 , 0x8285 , 0x008C , 0x0091 , 0x0000 , 0x0004 , 0xFFC7 , S(B5D0),
    S(BCD0), 0x0000 , 0x0004 , 0xC001 , S(96D1), S(B2D0), 0x0000 , 0x0005 ,
    0x009C , S(82D1), S(80D1), S(00D0), 0x0000 , 0xB0BE , 0x00A0 , 0x00A7 ,
    0x0000 , 0x0008 , 0xFF65 , S(85D1), S(B0D0), S(BDD0), S(8CD1), 0x0000 ,
    0x0006 , 0xFFD0 , S(BDD0), S(BED0), S(BCD0), 0x0000 , 0x0008 , 0xFF41 ,
    S(80D1), S(B8D0), S(86D1), S(96D1), 0x0000 , 0xD0D1 , 0x00B8 , 0x0100 ,
    0x0000 , 0xBEB0 , 0x00C9 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00D3 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x00E8 , 0x0000 , 0x000E , 0xFF4A , S(80D1), S(B0D0), S(B1D0), S(B0D0),
    S(BDD0), S(BDD0), S(96D1), 0x0000 , 0x0007 , 0x00DA , S(80D1), S(B5D0),
    S(B7D0), S(00D0), 0x0000 , 0xB0B5 , 0x00DE , 0x00E3 , 0x0000 , 0x0004 ,
    0xFF66 , S(BDD0), S(8CD1), 0x0000 , 0x0004 , 0xFF85 , S(BDD0), S(8CD1),
    0x0000 , 0xD1D1 , 0x00EB , 0x0000 , 0x8082 , 0x00EF , 0x00F8 , 0x0000 ,
    0x000C , 0xFF67 , S(B8D0), S(81D1), S(BFD0), S(96D1), S(BBD0), S(8CD1),
    0x0000 , 0x000A , 0xFF64 , S(BED0), S(88D1), S(B0D0), S(BDD0), S(8CD1),
    0x0000 , 0x9680 , 0x0119 , 0x0000 , 0x0000 , 0x012C , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0135 , 0x0000 , 0xD0D1 , 0x011D , 0x0125 , 0x0000 , 0x0009 , 0xFF5A ,
    S(D1B5), S(D082), S(D0B0), S(D1BD), S(008C), 0x0000 , 0x0007 , 0xFF90 ,
    S(D083), S(D0BD), S(D0B5), S(00B9), 0x0000 , 0x000C , 0xFF70 , S(B4D0),
    S(96D1), S(B2D0), S(B5D0), S(BBD0), S(8CD1), 0x0000 , 0xD0D0 , 0x0138 ,
    0x0000 , 0xB1BB , 0x013C , 0x0146 , 0x0000 , 0x000E , 0xFF3E , S(BBD0),
    S(96D1), S(BED0), S(82D1), S(B5D0), S(86D1), S(96D1), 0x0000 , 0x0002 ,
    0xC001 , S(8FD1), 0x0000 , 0xD127 , 0x01F7 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x01FF , 0x02BD , 0x0000 ,
    0x000A , 0xFFC5 , S(94D1), S(82D1), S(BDD0), S(B0D0), S(BCD0), 0x0000 ,
    0xBFB0 , 0x0211 , 0x0000 , 0x0000 , 0x0000 , 0x0247 , 0x0250 , 0x0000 ,
    0x0000 , 0x028A , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x02B7 , 0x0000 , 0xD0D1 , 0x0215 , 0x0222 , 0x0000 , 0xB4B7 , 0x0219 ,
    0x021E , 0x0000 , 0x0004 , 0xFFC8 , S(B8D0), S(BCD0), 0x0000 , 0x0002 ,
    0xFF38 , S(96D1), 0x0000 , 0x0003 , 0x0227 , S(D180), S(0082), 0x0000 ,
    0xD0D1 , 0x022B , 0x023D , 0x0000 , 0x0005 , 0x0231 , S(D1BE), S(D181),
    S(0082), 0x0000 , 0xD0D1 , 0x0235 , 0x023A , 0x0000 , 0x0003 , 0xFFFF ,
    S(D0B5), S(00B9), 0x0000 , 0x9696 , 0xFFFF , 0x0000 , 0x0006 , 0x0243 ,
    S(D196), S(D181), S(D182), 0x0000 , 0x8C8E , 0xFFFF , 0xFFFF , 0x0000 ,
    0x000C , 0xFFDB , S(B5D0), S(80D1), S(BBD0), S(B8D0), S(81D1), S(8FD1),
    0x0000 , 0xD1D1 , 0x0253 , 0x0000 , 0x8081 , 0x0257 , 0x0286 , 0x0000 ,
    0xD0D1 , 0x025B , 0x0263 , 0x0000 , 0x0009 , 0xFF7F , S(D1B5), S(D081),
    S(D0B5), S(D1BD), S(008C), 0x0000 , 0x0005 , 0x0269 , S(D181), S(D082),
    S(00B2), 0x001D , 0xD0D1 , 0x026D , 0x0282 , 0x0000 , 0xBEB0 , 0xFFE3 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0xFFE3 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x027E , 0x0000 , 0x0002 ,
    0xFFE3 , S(8ED1), 0x0000 , 0x8396 , 0xFFE3 , 0xFFE3 , 0x0000 , 0x0002 ,
    0xC001 , S(8CD1), 0x0000 , 0xD0D1 , 0x028E , 0x02A4 , 0x0000 , 0xBCBF ,
    0x0292 , 0x029D , 0x0000 , 0x0007 , 0x0299 , S(B5D0), S(80D1), S(BBD0),
    S(00D0), 0x0000 , 0xB0B8 , 0xFFDC , 0xFFDC , 0x0000 , 0x0008 , 0xFFAA ,
    S(BBD0), S(B0D0), S(82D1), S(B8D0), 0x0000 , 0x8182 , 0x02A8 , 0x02B0 ,
    0x0000 , 0x000A , 0xFF37 , S(82D1), S(B0D0), S(B2D0), S(86D1), S(96D1),
    0x0000 , 0x0008 , 0xFFBD , S(80D1), S(B0D0), S(82D1), S(B8D0), 0x0000 ,
    0x0006 , 0xC001 , S(BBD0), S(B8D0), S(B2D0), 0x0000 , 0x8296 , 0x02C1 ,
    0x02D3 , 0x0000 , 0xD0D1 , 0x02C5 , 0x02CC , 0x0000 , 0x0007 , 0xFFDF ,
    S(D0B5), S(D1BA), S(D082), S(00B8), 0x0000 , 0x0007 , 0xFFC1 , S(D080),
    S(D1B0), S(D082), S(00B8), 0x0000 , 0xD0D1 , 0x02D7 , 0x030B , 0x0000 ,
    0xB4BB , 0x02DB , 0x0305 , 0x0000 , 0xD0D1 , 0x02DF , 0x02E9 , 0x0000 ,
    0x0006 , 0x02E5 , S(D0B0), S(D0BD), S(D1BD), 0x0000 , 0x8F96 , 0xFF4F ,
    0xFF4F , 0x0000 , 0x8182 , 0x02ED , 0x02FF , 0x0000 , 0x0006 , 0x02F3 ,
    S(82D1), S(B0D0), S(BDD0), 0x0000 , 0xD0D1 , 0x02F7 , 0x02FC , 0x0000 ,
    0x0003 , 0xFF5D , S(D1BD), S(008E), 0x0000 , 0x8C8C , 0xFF5D , 0x0000 ,
    0x0006 , 0xC001 , S(BED0), S(B4D0), S(96D1), 0x0000 , 0x0006 , 0xFFCA ,
    S(8CD1), S(8FD1), S(BCD0), 0x0000 , 0x0003 , 0xFF47 , S(D186), S(0096),
    0x0000 , 0xD0D1 , 0x0314 , 0x0378 , 0x0000 , 0xBEB0 , 0x0325 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0342 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x035E , 0x0000 , 0xD0D1 , 0x0329 ,
    0x033A , 0x0000 , 0xB2BB , 0x032D , 0x0333 , 0x0000 , 0x0006 , 0xFF5B ,
    S(B0D0), S(BDD0), S(8CD1), 0x0000 , 0x0008 , 0xFF88 , S(96D1), S(BBD0),
    S(B5D0), S(B9D0), 0x0000 , 0x0009 , 0xFFBF , S(D080), S(D0BC), S(D1B0),
    S(D082), S(00B8), 0x0000 , 0x0003 , 0x0347 , S(BDD0), S(00D0), 0x0000 ,
    0xB5BE , 0x034B , 0x0356 , 0x0000 , 0x0007 , 0x0352 , S(80D1), S(B0D0),
    S(BBD0), S(00D0), 0x0000 , 0xB0B8 , 0xFFF0 , 0xFFF0 , 0x0000 , 0x0002 ,
    0x035A , S(BCD0), 0x0029 , 0x0002 , 0xFFD7 , S(83D1), 0x0000 , 0xD0D1 ,
    0x0362 , 0x0370 , 0x0000 , 0xBBBD , 0x0366 , 0x036B , 0x0000 , 0x0004 ,
    0xFF6F , S(96D1), S(B2D0), 0x0000 , 0x0004 , 0xFF2D , S(86D1), S(96D1),
    0x0000 , 0x0009 , 0xFF53 , S(D080), S(D0B1), S(D0B0), S(D1BD), S(008C),
    0x0000 , 0x8080 , 0x037B , 0x0000 , 0xD0D1 , 0x037F , 0x0387 , 0x0000 ,
    0x0009 , 0xFFA5 , S(D0B0), S(D0BD), S(D1B0), S(D082), S(00B8), 0x0000 ,
    0x0009 , 0xFF7D , S(D083), S(D0B4), S(D0B5), S(D1BD), S(008C), 0x0000 ,
    0xD0D1 , 0x0393 , 0x04CA , 0x0000 , 0xBEB0 , 0x03A4 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x03C4 , 0x0413 , 0x0000 , 0x041C , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0454 , 0x047A , 0x0000 , 0xD0D0 , 0x03A7 , 0x0000 ,
    0xBBBD , 0x03AB , 0x03AF , 0x0000 , 0x0002 , 0xC001 , S(96D1), 0x0000 ,
    0x0004 , 0x03B4 , S(B8D0), S(BBD0), 0x0000 , 0xD0D1 , 0x03B8 , 0x03C0 ,
    0x0000 , 0xB0BE , 0xFFF7 , 0x03BC , 0x0009 , 0x0002 , 0xFFF7 , S(BCD0),
    0x0000 , 0x8396 , 0xFFF7 , 0xFFF7 , 0x0000 , 0xD0D1 , 0x03C8 , 0x03F4 ,
    0x0000 , 0xBFB2 , 0x03D8 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x03DF , 0x03E8 , 0x0000 , 0x03EC ,
    0x0000 , 0x0007 , 0xFF75 , S(D127), S(D18F), S(D082), S(00B8), 0x0000 ,
    0x000C , 0xFFA2 , S(BED0), S(BAD0), S(80D1), S(B0D0), S(82D1), S(B8D0),
    0x0000 , 0x0002 , 0xFF72 , S(8CD1), 0x0000 , 0x000A , 0xFFBE , S(83D1),
    S(82D1), S(B0D0), S(82D1), S(B8D0), 0x0000 , 0x8081 , 0x03F8 , 0x03FE ,
    0x0000 , 0x0006 , 0xC001 , S(B6D0), S(B0D0), S(B2D0), 0x0000 , 0xD1D1 ,
    0x0401 , 0x0000 , 0x8C8F , 0xC001 , 0x0405 , 0x0000 , 0x0002 , 0x0409 ,
    S(82D1), 0x0000 , 0xD0D1 , 0x040D , 0x0410 , 0x0000 , 0xB8B8 , 0xFF87 ,
    0x0000 , 0x8C8C , 0xFF87 , 0x0000 , 0x000C , 0xFF5F , S(BED0), S(B2D0),
    S(B0D0), S(BDD0), S(BDD0), S(96D1), 0x0000 , 0xD0D1 , 0x0420 , 0x0427 ,
    0x0000 , 0x0007 , 0xFFD6 , S(D0BF), S(D0BB), S(D0BE), S(00BC), 0x0000 ,
    0x8182 , 0x042B , 0x0432 , 0x0000 , 0x0008 , 0xFF89 , S(BFD0), S(BBD0),
    S(B5D0), S(B9D0), 0x0000 , 0x0004 , 0x0437 , S(B8D0), S(BDD0), 0x0000 ,
    0xD0D1 , 0x043B , 0x0450 , 0x0000 , 0xBEB0 , 0xFF73 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0xFF73 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x044C , 0x0000 , 0x0002 , 0xFF73 , S(8ED1),
    0x0000 , 0x8396 , 0xFF73 , 0xFF73 , 0x0000 , 0xD0D1 , 0x0458 , 0x045D ,
    0x0000 , 0x0003 , 0xFF72 , S(D0B5), S(00BC), 0x0000 , 0x968E , 0xFF72 ,
    0x0468 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0476 ,
    0x008E , 0xD0D1 , 0x046C , 0x0473 , 0x0000 , 0xBCBC , 0x046F , 0x008E ,
    0x0002 , 0xFF72 , S(B8D0), 0x0000 , 0x8585 , 0xFF72 , 0x008E , 0x0002 ,
    0xFF72 , S(B2D0), 0x0000 , 0xD0D1 , 0x047E , 0x0490 , 0x0000 , 0xB2BC ,
    0x0482 , 0x0489 , 0x0000 , 0x0008 , 0xFF52 , S(B3D0), S(B0D0), S(BDD0),
    S(8CD1), 0x0000 , 0x0008 , 0xFF50 , S(B5D0), S(BDD0), S(BDD0), S(96D1),
    0x0000 , 0x8280 , 0x0495 , 0x04AB , 0x04C3 , 0x0000 , 0x0003 , 0x049A ,
    S(BED0), S(00D0), 0x0000 , 0xB3B7 , 0x049E , 0x04A7 , 0x0000 , 0x000C ,
    0xFF4C , S(BED0), S(86D1), S(96D1), S(BDD0), S(BDD0), S(96D1), 0x0000 ,
    0x0002 , 0xFF3C , S(96D1), 0x0000 , 0xD0D1 , 0x04AF , 0x04C0 , 0x0000 ,
    0xB8BA , 0x04B3 , 0x04B8 , 0x0000 , 0x0004 , 0xFFE0 , S(82D1), S(8CD1),
    0x0000 , 0x000A , 0xFFF1 , S(BED0), S(BDD0), S(B0D0), S(BBD0), S(BED0),
    0x0000 , 0x9696 , 0xC001 , 0x0000 , 0x0008 , 0xC001 , S(B5D0), S(BFD0),
    S(B5D0), S(80D1), 0x0000 , 0x8396 , 0x04CE , 0x04D3 , 0x0000 , 0x0004 ,
    0xC001 , S(B6D0), S(B5D0), 0x0000 , 0xD0D1 , 0x04D7 , 0x04DF , 0x0000 ,
    0x0009 , 0xFF3B , S(D1BB), S(D08F), S(D1BD), S(D186), S(0096), 0x0000 ,
    0x0007 , 0xFF91 , S(D081), S(D0BD), S(D0B5), S(00B9), 0x0000 , 0xD0D0 ,
    0x04E9 , 0x0000 , 0xBDBA , 0x04EF , 0x0507 , 0x0000 , 0x050D , 0x0000 ,
    0xD0D1 , 0x04F3 , 0x04FD , 0x0000 , 0x000D , 0xFF25 , S(D0BE), S(D0BD),
    S(D0BE), S(D1BC), S(D196), S(D186), S(0096), 0x0000 , 0x000D , 0xFFA9 ,
    S(D081), S(D0BF), S(D0BE), S(D0BD), S(D1B0), S(D082), S(00B8), 0x0000 ,
    0x0006 , 0xFFAF , S(96D1), S(82D1), S(B8D0), 0x0000 , 0x0004 , 0xFF8F ,
    S(B5D0), S(B9D0), 0x0000 , 0xD0D1 , 0x0516 , 0x051F , 0x0000 , 0x000B ,
    0xFF7E , S(D0BE), S(D1B2), S(D082), S(D0B5), S(D1BD), S(008C), 0x0000 ,
    0x000B , 0xFFE9 , S(D183), S(D080), S(D0BD), S(D0B0), S(D0BB), S(00B8),
    0x0000 , 0xD0D0 , 0x052B , 0x0000 , 0xBDB0 , 0x053B , 0x0573 , 0x057A ,
    0x059B , 0x0000 , 0x05A2 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x05A9 , 0x0000 , 0xD0D1 , 0x053F , 0x056C , 0x0000 ,
    0xBFB2 , 0x054F , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0555 , 0x0000 , 0x0000 , 0x0566 , 0x0000 ,
    0x0006 , 0xC001 , S(B6D0), S(B4D0), S(B8D0), 0x0000 , 0xD0D1 , 0x0559 ,
    0x055F , 0x0000 , 0x0005 , 0xFFF4 , S(D0B0), S(D0BB), S(00BE), 0x0000 ,
    0x0007 , 0xC001 , S(D196), S(D181), S(D182), S(008C), 0x0000 , 0x0006 ,
    0xFFA3 , S(B8D0), S(82D1), S(B8D0), 0x0000 , 0x0007 , 0xFF33 , S(D082),
    S(D1BE), S(D186), S(0096), 0x0000 , 0x0008 , 0xFF22 , S(96D1), S(80D1),
    S(86D1), S(96D1), 0x0000 , 0x0002 , 0x057E , S(96D1), 0x0000 , 0xD0D1 ,
    0x0582 , 0x0596 , 0x0000 , 0xB4B4 , 0x0585 , 0x0000 , 0xD0D1 , 0x0589 ,
    0x058E , 0x0000 , 0x0003 , 0xC001 , S(D0BA), S(00B8), 0x0000 , 0x8182 ,
    0x0592 , 0x0592 , 0x0000 , 0x0002 , 0xC001 , S(B8D0), 0x0000 , 0x0003 ,
    0xFFAE , S(D082), S(00B8), 0x0000 , 0x0008 , 0xC001 , S(BED0), S(B4D0),
    S(BED0), S(BCD0), 0x0000 , 0x0008 , 0xFF71 , S(BCD0), S(B5D0), S(BBD0),
    S(8CD1), 0x0000 , 0x0006 , 0xC001 , S(BED0), S(B2D0), S(83D1), 0x0000 ,
    0xD0D1 , 0x05B3 , 0x066F , 0x0000 , 0xBEB0 , 0x05C4 , 0x0000 , 0x05F0 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0605 , 0x0000 , 0x0000 ,
    0x0624 , 0x0000 , 0x0635 , 0x063B , 0x0000 , 0xD0D1 , 0x05C8 , 0x05E6 ,
    0x0000 , 0xBCBD , 0x05CC , 0x05D2 , 0x0000 , 0x0006 , 0xFF78 , S(96D1),
    S(BDD0), S(8CD1), 0x0000 , 0xD0D0 , 0x05D5 , 0x0000 , 0xB0B4 , 0x05D9 ,
    0x05DE , 0x0000 , 0x0004 , 0xFFEA , S(BBD0), S(B8D0), 0x0000 , 0x000A ,
    0xFFB4 , S(B8D0), S(B4D0), S(B0D0), S(82D1), S(B8D0), 0x0000 , 0x000D ,
    0xFFED , S(D080), S(D0B4), S(D0B8), S(D0BD), S(D0B0), S(D0BB), S(00B0),
    0x0000 , 0xD0D1 , 0x05F4 , 0x05FD , 0x0000 , 0x000B , 0xFFE4 , S(D1B0),
    S(D180), S(D082), S(D0B0), S(D0BB), S(00B8), 0x0000 , 0x0009 , 0xFF84 ,
    S(D196), S(D082), S(D0B5), S(D1BD), S(008C), 0x0000 , 0xD1D1 , 0x0608 ,
    0x0000 , 0x8097 , 0x060C , 0x0620 , 0x0000 , 0x0004 , 0x0611 , S(B8D0),
    S(BBD0), 0x0000 , 0xD0D1 , 0x0615 , 0x061D , 0x0000 , 0xB0BE , 0xFFF8 ,
    0x0619 , 0x0008 , 0x0002 , 0xFFF8 , S(BCD0), 0x0000 , 0x8383 , 0xFFF8 ,
    0x0000 , 0x0002 , 0xFFFC , S(B2D0), 0x0000 , 0xD0D0 , 0x0627 , 0x0000 ,
    0xB0B5 , 0x062B , 0x0631 , 0x0000 , 0x0006 , 0xFF26 , S(B4D0), S(86D1),
    S(96D1), 0x0000 , 0x0002 , 0xFF8B , S(B9D0), 0x0000 , 0x0006 , 0xFF42 ,
    S(B8D0), S(B7D0), S(96D1), 0x0000 , 0xD0D1 , 0x063F , 0x0668 , 0x0000 ,
    0xBEB3 , 0x064D , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0651 , 0x065A , 0x0000 , 0x065E , 0x0000 , 0x0002 , 0xC001 ,
    S(BED0), 0x0000 , 0x0002 , 0x0655 , S(B8D0), 0x3FFF , 0x0004 , 0xC001 ,
    S(81D1), S(8CD1), 0x0000 , 0x0002 , 0xC001 , S(83D1), 0x0000 , 0x000E ,
    0xFFB6 , S(80D1), S(B4D0), S(B8D0), S(BDD0), S(B0D0), S(82D1), S(B8D0),
    0x0000 , 0x0007 , 0xFF77 , S(D180), S(D096), S(D1BD), S(008C), 0x0000 ,
    0x9680 , 0x0688 , 0x0000 , 0x0000 , 0x06A2 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x06AF ,
    0x0000 , 0x0003 , 0x068D , S(B8D0), S(00D1), 0x0000 , 0x8182 , 0x0691 ,
    0x069C , 0x0000 , 0x0007 , 0x0698 , S(82D1), S(B0D0), S(BBD0), S(00D0),
    0x0000 , 0xB0B8 , 0xFFE6 , 0xFFE6 , 0x0000 , 0x0006 , 0xFF20 , S(B8D0),
    S(86D1), S(96D1), 0x0000 , 0xD0D0 , 0x06A5 , 0x0000 , 0xB1B4 , 0x06A9 ,
    0x0592 , 0x0000 , 0x0006 , 0xFF59 , S(B0D0), S(BDD0), S(8CD1), 0x0000 ,
    0x000A , 0xFFB9 , S(BCD0), S(BDD0), S(B0D0), S(82D1), S(B8D0), 0x0000 ,
    0xD0D1 , 0x06BB , 0x06F2 , 0x0000 , 0xBEB0 , 0x06CC , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x06D5 , 0x0000 , 0x0000 , 0x06DA , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x06EA , 0x0000 , 0x000C , 0xFFB5 , S(83D1),
    S(80D1), S(B5D0), S(B0D0), S(82D1), S(B8D0), 0x0000 , 0x0004 , 0xC001 ,
    S(B4D0), S(8CD1), 0x0000 , 0xD0D1 , 0x06DE , 0x06E5 , 0x0000 , 0x0007 ,
    0xFF81 , S(D0BF), S(D0B5), S(D1BD), S(008C), 0x0000 , 0x0003 , 0xC001 ,
    S(D088), S(00B5), 0x0000 , 0x000A , 0xFF5E , S(B7D0), S(B0D0), S(BDD0),
    S(BDD0), S(96D1), 0x0000 , 0x968C , 0x06FF , 0x0000 , 0x0705 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0733 , 0x0000 ,
    0x0006 , 0xFF6C , S(B2D0), S(96D1), S(B2D0), 0x0000 , 0x0003 , 0x070A ,
    S(B4D0), S(00D0), 0x0000 , 0xB5B8 , 0x070E , 0x0712 , 0x0000 , 0x0002 ,
    0xFFFA , S(B9D0), 0x0000 , 0x0002 , 0x0716 , S(BDD0), 0x0000 , 0xD0D1 ,
    0x071A , 0x072F , 0x0000 , 0xBEB0 , 0xFFFA , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0xFFFA , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x072B , 0x0000 , 0x0002 , 0xFFFA , S(8ED1), 0x0000 ,
    0x8396 , 0xFFFA , 0xFFFA , 0x0000 , 0xD0D1 , 0x0737 , 0x073C , 0x0000 ,
    0x0003 , 0xFF45 , S(D1B7), S(0096), 0x0000 , 0x0005 , 0xFF9C , S(D086),
    S(D0B5), S(00B9), 0x0000 , 0xD0D1 , 0x0746 , 0x082B , 0x0000 , 0xBEB0 ,
    0x0757 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x07C1 , 0x0000 , 0x0000 ,
    0x07FF , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0808 , 0x0000 ,
    0xD0D1 , 0x075B , 0x077A , 0x0000 , 0xBBB2 , 0x0767 , 0x0000 , 0x076F ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x04CE , 0x0774 , 0x064D , 0x0000 ,
    0x000A , 0xFF8A , S(B7D0), S(BED0), S(BBD0), S(B5D0), S(B9D0), 0x0000 ,
    0x0004 , 0xFFCB , S(B0D0), S(BCD0), 0x0000 , 0x0006 , 0xFFC9 , S(81D1),
    S(B8D0), S(BCD0), 0x0000 , 0x8680 , 0x0783 , 0x0797 , 0x079C , 0x0000 ,
    0x0000 , 0x0000 , 0x07BC , 0x0000 , 0xD0D1 , 0x0787 , 0x0790 , 0x0000 ,
    0x000B , 0xFFA6 , S(D0B3), S(D1B0), S(D080), S(D1B8), S(D082), S(00B8),
    0x0000 , 0x0007 , 0xFFEE , S(D088), S(D0B0), S(D0BB), S(00B0), 0x0000 ,
    0x0004 , 0xC001 , S(B8D0), S(B2D0), 0x0000 , 0x0002 , 0x07A0 , S(B5D0),
    0x0000 , 0xD0D1 , 0x07A4 , 0x07A7 , 0x0000 , 0xB9B9 , 0xFF94 , 0x0000 ,
    0x0004 , 0x07AC , S(D180), S(D196), 0x0000 , 0x978E , 0xFFE1 , 0xFFE1 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x07B8 , 0x0000 , 0x0000 , 0xFFE1 ,
    0x0000 , 0x0002 , 0xFFE1 , S(8ED1), 0x0000 , 0x0004 , 0xFF96 , S(B5D0),
    S(B9D0), 0x0000 , 0xD0D1 , 0x07C5 , 0x07F8 , 0x0000 , 0xBABB , 0x07C9 ,
    0x07D0 , 0x0000 , 0x0008 , 0xFF36 , S(81D1), S(B8D0), S(86D1), S(96D1),
    0x0000 , 0x0008 , 0x07D7 , S(8CD1), S(BDD0), S(B8D0), S(BAD0), 0x001E ,
    0xD0D1 , 0x07DB , 0x07F0 , 0x0000 , 0xBEB0 , 0xFFE2 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0xFFE2 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x07EC , 0x0000 , 0x0002 , 0xFFE2 , S(BCD0),
    0x0000 , 0x8396 , 0xFFE2 , 0x07F4 , 0x0000 , 0x0002 , 0xFFE2 , S(B2D0),
    0x0000 , 0x0007 , 0xFFE5 , S(D082), S(D0B0), S(D0BB), S(00B8), 0x0000 ,
    0x000C , 0xFF69 , S(BAD0), S(BED0), S(BBD0), S(B0D0), S(97D1), S(B2D0),
    0x0000 , 0x0006 , 0x080E , S(B3D0), S(B8D0), S(BBD0), 0x0000 , 0xD0D1 ,
    0x0812 , 0x0827 , 0x0000 , 0xBEB0 , 0xFFF9 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0xFFF9 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0823 , 0x0000 , 0x0002 , 0xFFF9 , S(8ED1), 0x0000 ,
    0x8396 , 0xFFF9 , 0xFFF9 , 0x0000 , 0x8396 , 0x082F , 0x0841 , 0x0000 ,
    0x0003 , 0x0834 , S(B7D0), S(00D0), 0x0000 , 0xB5B8 , 0x0838 , 0x083C ,
    0x0000 , 0x0002 , 0xFF9D , S(B9D0), 0x0000 , 0x0004 , 0xFF30 , S(86D1),
    S(96D1), 0x0000 , 0xD0D1 , 0x0845 , 0x0862 , 0x0000 , 0xBDBD , 0x0848 ,
    0x0000 , 0xD0D1 , 0x084C , 0x0854 , 0x0000 , 0x0009 , 0xFFE7 , S(D1B5),
    S(D080), S(D0B0), S(D0BB), S(00B8), 0x0000 , 0x000D , 0x085E , S(D096),
    S(D0B0), S(D1BB), S(D08C), S(D0B1), S(D0BE), S(00BC), 0x0028 , 0x0002 ,
    0xFFD8 , S(83D1), 0x0000 , 0x0005 , 0x0868 , S(D088), S(D0B5), S(00BD),
    0x0000 , 0xD0D1 , 0x086C , 0x0871 , 0x0000 , 0x0003 , 0xFF51 , S(D1BD),
    S(008E), 0x0000 , 0x8C8C , 0xFF51 , 0x0000 , 0xD0D1 , 0x0878 , 0x08DD ,
    0x0000 , 0xBEB0 , 0x0889 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x089E ,
    0x0000 , 0x0000 , 0x08CC , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x08D2 , 0x0000 , 0xD0D1 , 0x088D , 0x0898 , 0x0000 , 0x0007 , 0x0894 ,
    S(D1BF), S(D180), S(D08F), S(00BC), 0x0033 , 0x0002 , 0xFFCD , S(B8D0),
    0x0000 , 0x0005 , 0xFF2A , S(D183), S(D186), S(0096), 0x0000 , 0xD0D1 ,
    0x08A2 , 0x08B3 , 0x0000 , 0xB2BC , 0x08A6 , 0x08AD , 0x0000 , 0x0008 ,
    0xFFF2 , S(B4D0), S(B0D0), S(BBD0), S(BED0), 0x0000 , 0x0006 , 0xFFF3 ,
    S(B0D0), S(BBD0), S(BED0), 0x0000 , 0x8187 , 0x08B7 , 0x08C2 , 0x0000 ,
    0x0010 , 0xFF4B , S(BAD0), S(96D1), S(BDD0), S(87D1), S(B5D0), S(BDD0),
    S(BDD0), S(96D1), 0x0000 , 0x000E , 0xFF4D , S(B8D0), S(81D1), S(BBD0),
    S(B5D0), S(BDD0), S(BDD0), S(96D1), 0x0000 , 0x0006 , 0xFF27 , S(B7D0),
    S(86D1), S(96D1), 0x0000 , 0x0007 , 0x08D9 , S(B2D0), S(B5D0), S(BBD0),
    S(00D0), 0x0000 , 0xB0B8 , 0xFFDA , 0xFFDA , 0x0000 , 0x0009 , 0xC001 ,
    S(D196), S(D087), S(D0BE), S(D0B3), S(00BE), 0x0000 , 0xD0D1 , 0x08E9 ,
    0x091E , 0x0000 , 0xBFB1 , 0x08FA , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0905 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0917 , 0x0000 , 0x0010 , 0xFF1E , S(BAD0), S(BBD0), S(B0D0),
    S(B4D0), S(B8D0), S(BDD0), S(86D1), S(96D1), 0x0000 , 0x0003 , 0x090A ,
    S(80D1), S(00D1), 0x0000 , 0x8396 , 0x090E , 0x0913 , 0x0000 , 0x0004 ,
    0xFF46 , S(B7D0), S(96D1), 0x0000 , 0x0002 , 0xC001 , S(BCD0), 0x0000 ,
    0x0008 , 0xFFAD , S(BBD0), S(B0D0), S(82D1), S(B8D0), 0x0000 , 0x8081 ,
    0x0922 , 0x0933 , 0x0000 , 0xD0D1 , 0x0926 , 0x092D , 0x0000 , 0x0007 ,
    0xFFBA , S(D1B1), S(D196), S(D082), S(00B8), 0x0000 , 0x0005 , 0xFF98 ,
    S(D084), S(D0B5), S(00B9), 0x0000 , 0xD0D1 , 0x0937 , 0x093E , 0x0000 ,
    0x0007 , 0xFFC3 , S(D1B2), S(D196), S(D082), S(00B8), 0x0000 , 0x8296 ,
    0x0942 , 0x0954 , 0x0000 , 0x0007 , 0x0949 , S(B0D0), S(BDD0), S(BDD0),
    S(00D1), 0x0000 , 0x968E , 0xFF63 , 0xFF63 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0xFF63 , 0x0000 , 0xD0D0 , 0x0957 , 0x0000 ,
    0xB1BD , 0xFFFB , 0x095B , 0x0000 , 0x0002 , 0xFF6D , S(8CD1), 0x0000 ,
    0xD127 , 0x0A0C , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0A12 , 0x0A90 , 0x0000 , 0x0006 , 0xFF76 , S(8FD1),
    S(82D1), S(B8D0), 0x0000 , 0xBEB0 , 0x0A23 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0A2A ,
    0x0000 , 0x0000 , 0x0A30 , 0x0000 , 0x0008 , 0xFFC0 , S(BBD0), S(B0D0),
    S(82D1), S(B8D0), 0x0000 , 0x0006 , 0xFFB2 , S(B8D0), S(82D1), S(B8D0),
    0x0000 , 0xD0D1 , 0x0A34 , 0x0A87 , 0x0000 , 0xBCB2 , 0x0A41 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0A55 , 0x0000 , 0x0000 , 0x0592 , 0x0A5C ,
    0x0A64 , 0x0000 , 0xD0D1 , 0x0A45 , 0x0A4F , 0x0000 , 0x000D , 0xFF48 ,
    S(D0BD), S(D1BE), S(D186), S(D096), S(D0BD), S(D1BD), S(0096), 0x0000 ,
    0x0005 , 0xFFA4 , S(D196), S(D082), S(00B8), 0x0000 , 0x0008 , 0xFF57 ,
    S(BDD0), S(B0D0), S(BDD0), S(8CD1), 0x0000 , 0x000A , 0xFF31 , S(96D1),
    S(82D1), S(B8D0), S(86D1), S(96D1), 0x0000 , 0x0004 , 0x0A69 , S(B5D0),
    S(80D1), 0x0000 , 0xD0D1 , 0x0A6D , 0x0A82 , 0x0000 , 0x0002 , 0x0A71 ,
    S(D0BB), 0x0000 , 0xBEB0 , 0xFFDD , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0xFFDD , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0xFFDD , 0x0000 , 0x0003 , 0xFFDD , S(D082), S(00B8), 0x0000 ,
    0x8182 , 0x0091 , 0x0A8B , 0x0000 , 0x0004 , 0xC001 , S(96D1), S(BCD0),
    0x0000 , 0x9680 , 0x0AA9 , 0x0000 , 0x0B59 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0B62 , 0x0000 , 0xD0D0 , 0x0AAC , 0x0000 , 0xBEB0 , 0x0ABD , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0ACF , 0x0000 , 0x0000 , 0x0AD8 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0B0F , 0x0000 , 0xD0D0 , 0x0AC0 ,
    0x0000 , 0xB7BA , 0x0AC4 , 0x0AC8 , 0x0000 , 0x0002 , 0xFF35 , S(96D1),
    0x0000 , 0x0008 , 0xFF3A , S(82D1), S(B8D0), S(86D1), S(96D1), 0x0000 ,
    0x000C , 0xFFB0 , S(BFD0), S(B0D0), S(80D1), S(B0D0), S(82D1), S(B8D0),
    0x0000 , 0xD0D1 , 0x0ADC , 0x0AF0 , 0x0000 , 0xB2B9 , 0x0AE0 , 0x0AE7 ,
    0x0000 , 0x0008 , 0xFF8C , S(96D1), S(BBD0), S(B5D0), S(B9D0), 0x0000 ,
    0x0004 , 0x0AEC , S(BED0), S(BCD0), 0x002B , 0x0002 , 0xFFD5 , S(83D1),
    0x0000 , 0x8182 , 0x0AF4 , 0x0B06 , 0x0000 , 0xD1D1 , 0x0AF7 , 0x0000 ,
    0x828F , 0x0AFB , 0x0B01 , 0x0000 , 0x0006 , 0xFF58 , S(B0D0), S(BDD0),
    S(8CD1), 0x0000 , 0x0004 , 0xFF3D , S(B7D0), S(96D1), 0x0000 , 0x000C ,
    0xFF4E , S(B0D0), S(BCD0), S(B0D0), S(BDD0), S(BDD0), S(96D1), 0x0000 ,
    0xD0D1 , 0x0B13 , 0x0B27 , 0x0000 , 0xBCBC , 0x0B16 , 0x0000 , 0xD0D1 ,
    0x0B1A , 0x0B21 , 0x0000 , 0x0007 , 0xFF95 , S(D1B5), S(D082), S(D0B5),
    S(00B9), 0x0000 , 0x0005 , 0xFF79 , S(D096), S(D1BD), S(008C), 0x0000 ,
    0x8280 , 0x0B2C , 0x0B52 , 0x0592 , 0x0000 , 0x0004 , 0x0B31 , S(BED0),
    S(BAD0), 0x008C , 0xD0D1 , 0x0B35 , 0x0B4A , 0x0000 , 0xBEB0 , 0xFF74 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0xFF74 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0B46 , 0x0000 , 0x0002 ,
    0xFF74 , S(BCD0), 0x0000 , 0x8396 , 0xFF74 , 0x0B4E , 0x0000 , 0x0002 ,
    0xFF74 , S(B2D0), 0x0000 , 0x0008 , 0xFFB8 , S(B2D0), S(96D1), S(82D1),
    S(B8D0), 0x0000 , 0x000C , 0xFF93 , S(BED0), S(BBD0), S(B5D0), S(BCD0),
    S(B5D0), S(B9D0), 0x0000 , 0xD0D0 , 0x0B65 , 0x0000 , 0xB2B4 , 0x0B69 ,
    0x0B7E , 0x0000 , 0xD0D1 , 0x0B6D , 0x0B75 , 0x0000 , 0x0009 , 0xFF62 ,
    S(D0B4), S(D0B5), S(D0BD), S(D1BD), S(0096), 0x0000 , 0x000B , 0xFFEB ,
    S(D184), S(D096), S(D0BD), S(D0B0), S(D0BB), S(00B8), 0x0000 , 0xD0D1 ,
    0x0B82 , 0x0B98 , 0x0000 , 0xB3B9 , 0x0B86 , 0x0B8F , 0x0000 , 0x000C ,
    0xFF2E , S(BED0), S(82D1), S(BED0), S(B2D0), S(86D1), S(96D1), 0x0000 ,
    0x0004 , 0x0B94 , S(BED0), S(BCD0), 0x002C , 0x0002 , 0xFFD4 , S(83D1),
    0x0000 , 0x000B , 0xFF29 , S(D182), S(D080), S(D0B8), S(D1BC), S(D186),
    S(0096), 0x0000 , 0x9680 , 0x0BBA , 0x0C48 , 0x0D5B , 0x0DDB , 0x0E02 ,
    0x0E40 , 0x0E60 , 0x0E68 , 0x0EB5 , 0x0EC7 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0EDC , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0EF2 ,
    0x0000 , 0x0F17 , 0x0000 , 0xD0D1 , 0x0BBE , 0x0C12 , 0x0000 , 0xBEB0 ,
    0x0BCF , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0BD5 , 0x0000 , 0x0000 ,
    0x0BFB , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0C00 , 0x0000 ,
    0x0006 , 0xC001 , S(B7D0), S(BED0), S(BCD0), 0x0000 , 0xD0D1 , 0x0BD9 ,
    0x0BF0 , 0x0000 , 0xB6B7 , 0x0BDD , 0x0BE6 , 0x0000 , 0x0004 , 0x0BE2 ,
    S(B8D0), S(BCD0), 0x0032 , 0x0002 , 0xFFCE , S(B8D0), 0x0000 , 0x000E ,
    0xFFC2 , S(83D1), S(BBD0), S(8CD1), S(82D1), S(B0D0), S(82D1), S(B8D0),
    0x0000 , 0x000F , 0xFF40 , S(D081), S(D1BF), S(D083), S(D0B1), S(D1BB),
    S(D196), S(D186), S(0096), 0x0000 , 0x0004 , 0xFF1D , S(B7D0), S(96D1),
    0x0000 , 0xD0D1 , 0x0C04 , 0x0C0D , 0x0000 , 0x000B , 0xFF34 , S(D1B7),
    S(D080), S(D0BE), S(D1B1), S(D186), S(0096), 0x0000 , 0x0003 , 0xFFFD ,
    S(D186), S(0096), 0x0000 , 0x9683 , 0x0C28 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0C2D , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0C34 ,
    0x0000 , 0x0004 , 0xFF23 , S(86D1), S(96D1), 0x0000 , 0x0008 , 0xFF56 ,
    S(B7D0), S(B0D0), S(BDD0), S(8CD1), 0x0000 , 0xD0D1 , 0x0C38 , 0x0C42 ,
    0x0000 , 0xB2BA , 0x0C3C , 0xFFFD , 0x0000 , 0x0006 , 0xFF7C , S(B5D0),
    S(BDD0), S(8CD1), 0x0000 , 0x0005 , 0xFF43 , S(D187), S(D186), S(0096),
    0x0000 , 0xD0D1 , 0x0C4C , 0x0CEF , 0x0000 , 0xBFB0 , 0x0C5E , 0x0000 ,
    0x0C63 , 0x0000 , 0x0000 , 0x0C77 , 0x0000 , 0x0000 , 0x0C88 , 0x0000 ,
    0x0000 , 0x0000 , 0x0CB1 , 0x0000 , 0x0CB7 , 0x0CD9 , 0x0000 , 0x0004 ,
    0xC001 , S(BCD0), S(B5D0), 0x0000 , 0xD1D1 , 0x0C66 , 0x0000 , 0x8F96 ,
    0x0C6A , 0x0C72 , 0x0000 , 0x000A , 0xFF60 , S(89D1), S(B5D0), S(BDD0),
    S(BDD0), S(96D1), 0x0000 , 0x0004 , 0xFFAC , S(82D1), S(B8D0), 0x0000 ,
    0xD0D1 , 0x0C7B , 0x0C80 , 0x0000 , 0x0003 , 0xC001 , S(D0B1), S(00B5),
    0x0000 , 0x0009 , 0xFF80 , S(D080), S(D0BF), S(D0B5), S(D1BD), S(008C),
    0x0000 , 0xD0D0 , 0x0C8B , 0x0000 , 0xBDB1 , 0x0C9A , 0x0000 , 0x0C9F ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0CA6 , 0x0000 , 0x0004 , 0xC001 , S(96D1), S(80D1), 0x0000 ,
    0x0008 , 0xFFE8 , S(BDD0), S(B0D0), S(BBD0), S(B8D0), 0x0000 , 0x0008 ,
    0x0CAD , S(B4D0), S(80D1), S(BED0), S(BCD0), 0x002D , 0x0002 , 0xFFD3 ,
    S(83D1), 0x0000 , 0x0006 , 0xFF3F , S(83D1), S(B7D0), S(96D1), 0x0000 ,
    0xD0D0 , 0x0CBA , 0x0000 , 0xB2BB , 0x0CBE , 0x0CD2 , 0x0000 , 0x0007 ,
    0x0CC5 , S(96D1), S(81D1), S(82D1), S(00D1), 0x0000 , 0x968C , 0xFFFE ,
    0x0000 , 0xFFFE , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0xFFFE , 0x0000 , 0x0008 , 0xFFBC , S(B4D0), S(B0D0), S(82D1),
    S(B8D0), 0x0000 , 0xD0D1 , 0x0CDD , 0x0CE4 , 0x0000 , 0x0007 , 0xFFAB ,
    S(D0BB), S(D1B0), S(D082), S(00B8), 0x0000 , 0x0005 , 0x0CEA , S(D080),
    S(D0B0), S(00B2), 0x3FFF , 0x0004 , 0xC001 , S(B4D0), S(96D1), 0x0000 ,
    0x9682 , 0x0D06 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0D38 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0D41 , 0x0000 , 0xD0D1 ,
    0x0D0A , 0x0D1C , 0x0000 , 0xB0BE , 0x0D0E , 0x0D14 , 0x0000 , 0x0006 ,
    0xFF9F , S(82D1), S(B5D0), S(B9D0), 0x0000 , 0x000A , 0xFF2B , S(80D1),
    S(96D1), S(BDD0), S(86D1), S(96D1), 0x0000 , 0x8083 , 0x0D20 , 0x0D31 ,
    0x0000 , 0xD0D1 , 0x0D24 , 0x0D2A , 0x0000 , 0x0005 , 0xFFB7 , S(D1B0),
    S(D082), S(00B8), 0x0000 , 0x0007 , 0xFF24 , S(D196), S(D187), S(D186),
    S(0096), 0x0000 , 0x0008 , 0xFF7A , S(BFD0), S(96D1), S(BDD0), S(8CD1),
    0x0000 , 0x000C , 0xC001 , S(BED0), S(B3D0), S(BED0), S(B4D0), S(BDD0),
    S(96D1), 0x0000 , 0xD0D1 , 0x0D45 , 0x0D54 , 0x0000 , 0xB4BC , 0x0D49 ,
    0x0D4F , 0x0000 , 0x0006 , 0xFF92 , S(BDD0), S(B5D0), S(B9D0), 0x0000 ,
    0x0004 , 0xFF9E , S(B5D0), S(B9D0), 0x0000 , 0x0007 , 0xFF86 , S(D087),
    S(D0B5), S(D1BD), S(008C), 0x0000 , 0xD0D1 , 0x0D5F , 0x0DB7 , 0x0000 ,
    0xBEB0 , 0x0D70 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0D83 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0D9B ,
    0x0000 , 0xD0D0 , 0x0D73 , 0x0000 , 0xB4B9 , 0x0D77 , 0x0D7C , 0x0000 ,
    0x0004 , 0xFF97 , S(B5D0), S(B9D0), 0x0000 , 0x0008 , 0xFF5C , S(B2D0),
    S(B0D0), S(BDD0), S(8CD1), 0x0000 , 0xD0D1 , 0x0C7B , 0x0D87 , 0x0000 ,
    0x8085 , 0x0D8B , 0x0D94 , 0x0000 , 0x000C , 0xFF68 , S(BDD0), S(BED0),
    S(BFD0), S(96D1), S(BBD0), S(8CD1), 0x0000 , 0x0008 , 0xFF28 , S(BDD0),
    S(96D1), S(86D1), S(96D1), 0x0000 , 0xD0D1 , 0x0D9F , 0x0DB1 , 0x0000 ,
    0xBCB4 , 0x03AB , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0DAA , 0x065A , 0x0000 , 0x0008 , 0xFFF6 , S(81D1), S(82D1), S(BED0),
    S(B9D0), 0x0000 , 0x0005 , 0xFF32 , S(D187), S(D186), S(0096), 0x0000 ,
    0x8083 , 0x0DBB , 0x0DD6 , 0x0000 , 0xD0D1 , 0x0DBF , 0x0DCF , 0x0000 ,
    0xB0B5 , 0x0DC3 , 0x0DCA , 0x0000 , 0x0008 , 0xFF83 , S(B2D0), S(B5D0),
    S(BDD0), S(8CD1), 0x0000 , 0x0004 , 0xC001 , S(B1D0), S(B0D0), 0x0000 ,
    0x0007 , 0xFF2C , S(D096), S(D1B9), S(D186), S(0096), 0x0000 , 0x0004 ,
    0xC001 , S(B4D0), S(B8D0), 0x0000 , 0xD0D1 , 0x0DDF , 0x0DF1 , 0x0000 ,
    0x0002 , 0x0DE3 , S(D0B2), 0x0000 , 0xB0B5 , 0x0DE7 , 0x0DEC , 0x0000 ,
    0x0004 , 0xFF2F , S(B7D0), S(96D1), 0x0000 , 0x0004 , 0xC001 , S(81D1),
    S(8CD1), 0x0000 , 0x8287 , 0x0DF5 , 0x0DFC , 0x0000 , 0x0008 , 0xFFDE ,
    S(B5D0), S(BAD0), S(82D1), S(B8D0), 0x0000 , 0x0006 , 0xFF7B , S(B5D0),
    S(BDD0), S(8CD1), 0x0000 , 0xD0D1 , 0x0E06 , 0x0E2C , 0x0000 , 0xB0BE ,
    0x0E0A , 0x0E12 , 0x0000 , 0x000A , 0xFF1F , S(B1D0), S(80D1), S(B8D0),
    S(86D1), S(96D1), 0x0000 , 0x0002 , 0x0E16 , S(80D1), 0x0000 , 0xD0D1 ,
    0x0E1A , 0x0E21 , 0x0000 , 0x0007 , 0xFFA1 , S(D0BC), S(D1B0), S(D082),
    S(00B8), 0x0000 , 0x000F , 0xFF49 , S(D082), S(D0B5), S(D1BF), S(D096),
    S(D0B0), S(D0BD), S(D1BD), S(0096), 0x0000 , 0x8396 , 0x0E30 , 0x0E39 ,
    0x0000 , 0x000C , 0xFF39 , S(82D1), S(B1D0), S(BED0), S(BBD0), S(86D1),
    S(96D1), 0x0000 , 0x0008 , 0xFFEC , S(BDD0), S(B0D0), S(BBD0), S(B8D0),
    0x0000 , 0xD0D0 , 0x0E43 , 0x0000 , 0xB0BE , 0x0E47 , 0x0E5A , 0x0000 ,
    0xD0D1 , 0x0E4B , 0x0E53 , 0x0000 , 0x0009 , 0xFF54 , S(D0B9), S(D0BD),
    S(D0B0), S(D1BD), S(008C), 0x0000 , 0x0007 , 0xFF6B , S(D080), S(D1BA),
    S(D096), S(00B2), 0x0000 , 0x0006 , 0xFF9B , S(BAD0), S(B5D0), S(B9D0),
    0x0000 , 0x000A , 0xFFA7 , S(B8D0), S(82D1), S(B0D0), S(82D1), S(B8D0),
    0x0000 , 0xD0D0 , 0x0E6B , 0x0000 , 0xBEB5 , 0x0E77 , 0x0000 , 0x0000 ,
    0x0EA9 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0EB0 , 0x0000 ,
    0xD0D1 , 0x0E7B , 0x0E86 , 0x0000 , 0x000F , 0xFFB3 , S(D0BC), S(D1BF),
    S(D096), S(D0BE), S(D0BD), S(D1B0), S(D082), S(00B8), 0x0000 , 0x0002 ,
    0x0E8A , S(D080), 0x0000 , 0xBDB2 , 0x0E98 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0E9E , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0EA2 ,
    0x0000 , 0x0006 , 0xFF82 , S(B5D0), S(BDD0), S(8CD1), 0x0000 , 0x0002 ,
    0xFF21 , S(96D1), 0x0000 , 0x0008 , 0xFF6A , S(96D1), S(B3D0), S(96D1),
    S(B2D0), 0x0000 , 0x0008 , 0xFFF5 , S(BCD0), S(B0D0), S(BBD0), S(BED0),
    0x0000 , 0x0004 , 0xC001 , S(BCD0), S(83D1), 0x0000 , 0xD0D1 , 0x0EB9 ,
    0x0EC0 , 0x0000 , 0x0007 , 0xFFD1 , S(D0BE), S(D0BB), S(D0BE), S(00BC),
    0x0000 , 0x0007 , 0xFFBB , S(D082), S(D1B0), S(D082), S(00B8), 0x0000 ,
    0x0003 , 0x0ECC , S(BED0), S(00D0), 0x0000 , 0xB4B9 , 0x0ED0 , 0x0ED7 ,
    0x0000 , 0x0008 , 0xFF61 , S(B5D0), S(BDD0), S(BDD0), S(96D1), 0x0000 ,
    0x0004 , 0xC001 , S(BDD0), S(BED0), 0x0000 , 0xD0D0 , 0x0EDF , 0x0000 ,
    0xB2BD , 0x0EE3 , 0x0EEA , 0x0000 , 0x0008 , 0xFF8D , S(96D1), S(BBD0),
    S(B5D0), S(B9D0), 0x0000 , 0x000A , 0xFF55 , S(8CD1), S(BDD0), S(B0D0),
    S(BDD0), S(8CD1), 0x0000 , 0xD0D1 , 0x0EF6 , 0x0F0D , 0x0000 , 0xB2B2 ,
    0x0EF9 , 0x0000 , 0xD0D1 , 0x0EFD , 0x0F07 , 0x0000 , 0x000D , 0xFF6E ,
    S(D0B0), S(D0BD), S(D0B3), S(D0B5), S(D1BB), S(D196), S(0094), 0x0000 ,
    0x0005 , 0xFF9A , S(D080), S(D0B5), S(00B9), 0x0000 , 0x000D , 0xFFC6 ,
    S(D180), S(D183), S(D081), S(D0B0), S(D0BB), S(D0B8), S(00BC), 0x0000 ,
    0xD0D1 , 0x0F1B , 0x0F41 , 0x0000 , 0x0002 , 0x0F1F , S(D0BD), 0x0000 ,
    0xBEB0 , 0x0F30 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0F36 , 0x0000 , 0x0000 , 0x0000 , 0x0F3C ,
    0x0000 , 0x0006 , 0xC001 , S(BAD0), S(88D1), S(B5D0), 0x0000 , 0x0006 ,
    0xC001 , S(BED0), S(BBD0), S(B8D0), 0x0000 , 0x0004 , 0xC001 , S(B4D0),
    S(96D1), 0x0000 , 0x9480 , 0x0F58 , 0x0F5F , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0F71 ,
    0x0000 , 0x0008 , 0xFF8E , S(B8D0), S(BDD0), S(B5D0), S(B9D0), 0x0000 ,
    0xD0D0 , 0x0F62 , 0x0000 , 0xBBBF , 0x0F66 , 0x0F6B , 0x0000 , 0x0004 ,
    0xFFCC , S(B0D0), S(BCD0), 0x0000 , 0x0006 , 0xFFA8 , S(B8D0), S(82D1),
    S(B8D0), 0x0000 , 0x0006 , 0xFF99 , S(80D1), S(B5D0), S(B9D0)
};

static const unsigned short a_16[] = {
    0x0000 , 0xBC80 , 0x003F , 0x0000 , 0x0045 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0057 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0066 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00BA , 0x00C0 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x010E , 0x011D , 0x0124 , 0x0000 ,
    0x0005 , 0xFFFE , S(B1D0), S(96D1), S(00D1), 0x0000 , 0xD1D1 , 0x0048 ,
    0x0000 , 0x8196 , 0x004C , 0x0052 , 0x0000 , 0x0005 , 0xFFFD , S(80D1),
    S(96D1), S(00D1), 0x0000 , 0x0003 , 0xFFF2 , S(BAD0), S(00D1), 0x0000 ,
    0x0003 , 0x005C , S(96D1), S(00D1), 0x0000 , 0xBDBF , 0x0060 , 0x0063 ,
    0x0000 , 0xD0D0 , 0xFFFC , 0x0000 , 0xD0D0 , 0xFFF9 , 0x0000 , 0xD1D1 ,
    0x0069 , 0x0000 , 0xBD82 , 0x00A7 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x00AE , 0x0000 , 0x00B4 , 0x0000 ,
    0x0007 , 0xFFF6 , S(B3D0), S(96D1), S(81D1), S(00D1), 0x0000 , 0x0005 ,
    0xFFF8 , S(81D1), S(96D1), S(00D0), 0x0000 , 0x0005 , 0xFFF7 , S(BAD0),
    S(96D1), S(00D0), 0x0000 , 0x0005 , 0xFFF1 , S(80D1), S(96D1), S(00D0),
    0x0000 , 0x0003 , 0x00C5 , S(96D1), S(00D0), 0x0000 , 0xBB80 , 0x0103 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0106 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0109 , 0x0000 , 0xD1D1 , 0xFFF4 , 0x0000 , 0xD1D1 ,
    0xFFFF , 0x0000 , 0x0003 , 0xFFF5 , S(BFD0), S(00D0), 0x0000 , 0x0003 ,
    0x0113 , S(96D1), S(00D0), 0x0000 , 0x81B1 , 0x0117 , 0x011A , 0x0000 ,
    0xD1D1 , 0xFFF0 , 0x0000 , 0xD0D0 , 0xFFF3 , 0x0000 , 0x0007 , 0xFFFA ,
    S(81D1), S(82D1), S(96D1), S(00D0), 0x0000 , 0x0005 , 0xFFFB , S(B4D0),
    S(96D1), S(00D0)
};

static const unsigned short a_17[] = {
    0x0000 , 0x8C8F , 0x0004 , 0x0021 , 0x0000 , 0x0003 , 0x0009 , S(81D1),
    S(00D1), 0x3FFF , 0xB8B0 , 0x0014 , 0x0000 , 0x0019 , 0x0000 , 0x0000 ,
    0x0000 , 0x0000 , 0x0000 , 0x001C , 0x0000 , 0x0003 , 0xC001 , S(BBD0),
    S(00D0), 0x0000 , 0xD0D0 , 0xC001 , 0x0000 , 0x0003 , 0xC001 , S(82D1),
    S(00D0), 0x0000 , 0x0003 , 0x0026 , S(81D1), S(00D1), 0x3FFF , 0xB2B8 ,
    0x0019 , 0x001C
};

static const unsigned char g_v[] = { 33, 65, 8, 192, 208 };

static int r_professional(struct SN_env * z) {
    int among_var;
    z->ket = z->c;
    among_var = find_among_b(z, a_8);
    if (!among_var) return 0;
    z->bra = z->c;
    switch (among_var) {
        case 1:
            {
                int ret = slice_del(z);
                if (ret < 0) return ret;
            }
            break;
        case 2:
            if (!(eq_s_b(z, 2, s_0))) return 0;
            {
                int ret = slice_del(z);
                if (ret < 0) return ret;
            }
            break;
    }
    return 1;
}

extern int ukrainian_UTF_8_stem(struct SN_env * z) {
    int among_var;
    int b_found_ty_noun;
    int b_found_la_noun;
    int b_found_verb;
    int b_found_ia;
    int b_found_professional;
    int b_found_diminutive;
    int i_p2;
    int i_pV;
    {
        int v_1 = z->c;
        z->bra = z->c;
        if (!(eq_s(z, 6, s_1))) goto lab0;
        z->ket = z->c;
        if (z->c >= z->l) goto lab0;
        {
            int ret = slice_del(z);
            if (ret < 0) return ret;
        }
    lab0:
        z->c = v_1;
    }
    do {
        int v_2 = z->c;
        {
            int v_3 = z->c;
            if (!(eq_s(z, 12, s_2))) goto lab1;
            if (z->c < z->l) goto lab1;
            z->c = v_3;
        }
        z->lb = z->c; z->c = z->l;
        z->ket = z->c;
        if (!(eq_s_b(z, 2, s_2))) goto lab1;
        z->bra = z->c;
        {
            int ret = slice_del(z);
            if (ret < 0) return ret;
        }
        z->c = z->lb;
        break;
    lab1:
        z->c = v_2;
        z->bra = z->c;
        among_var = find_among(z, a_15);
        if (!among_var) goto lab2;
        z->ket = z->c;
        if (z->c < z->l) goto lab2;
        switch (among_var) {
            case 1:
                {
                    int ret = slice_from_s(z, 14, s_3);
                    if (ret < 0) return ret;
                }
                break;
            case 2:
                {
                    int ret = slice_from_s(z, 12, s_4);
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                {
                    int ret = slice_from_s(z, 6, s_5);
                    if (ret < 0) return ret;
                }
                break;
            case 4:
                {
                    int ret = slice_from_s(z, 8, s_0);
                    if (ret < 0) return ret;
                }
                break;
            case 5:
                {
                    int ret = slice_from_s(z, 8, s_6);
                    if (ret < 0) return ret;
                }
                break;
            case 6:
                {
                    int ret = slice_from_s(z, 6, s_7);
                    if (ret < 0) return ret;
                }
                break;
            case 7:
                {
                    int ret = slice_from_s(z, 10, s_8);
                    if (ret < 0) return ret;
                }
                break;
            case 8:
                {
                    int ret = slice_from_s(z, 10, s_9);
                    if (ret < 0) return ret;
                }
                break;
            case 9:
                {
                    int ret = slice_from_s(z, 10, s_10);
                    if (ret < 0) return ret;
                }
                break;
            case 10:
                {
                    int ret = slice_from_s(z, 10, s_11);
                    if (ret < 0) return ret;
                }
                break;
            case 11:
                {
                    int ret = slice_from_s(z, 12, s_12);
                    if (ret < 0) return ret;
                }
                break;
            case 12:
                {
                    int ret = slice_from_s(z, 10, s_13);
                    if (ret < 0) return ret;
                }
                break;
            case 13:
                {
                    int ret = slice_from_s(z, 10, s_14);
                    if (ret < 0) return ret;
                }
                break;
            case 14:
                {
                    int ret = slice_from_s(z, 12, s_15);
                    if (ret < 0) return ret;
                }
                break;
            case 15:
                {
                    int ret = slice_from_s(z, 16, s_16);
                    if (ret < 0) return ret;
                }
                break;
            case 16:
                {
                    int ret = slice_from_s(z, 14, s_17);
                    if (ret < 0) return ret;
                }
                break;
            case 17:
                {
                    int ret = slice_from_s(z, 14, s_18);
                    if (ret < 0) return ret;
                }
                break;
            case 18:
                {
                    int ret = slice_from_s(z, 12, s_19);
                    if (ret < 0) return ret;
                }
                break;
            case 19:
                {
                    int ret = slice_from_s(z, 16, s_20);
                    if (ret < 0) return ret;
                }
                break;
            case 20:
                {
                    int ret = slice_from_s(z, 10, s_21);
                    if (ret < 0) return ret;
                }
                break;
            case 21:
                {
                    int ret = slice_from_s(z, 16, s_22);
                    if (ret < 0) return ret;
                }
                break;
            case 22:
                {
                    int ret = slice_from_s(z, 10, s_23);
                    if (ret < 0) return ret;
                }
                break;
            case 23:
                {
                    int ret = slice_from_s(z, 12, s_24);
                    if (ret < 0) return ret;
                }
                break;
            case 24:
                {
                    int ret = slice_from_s(z, 12, s_25);
                    if (ret < 0) return ret;
                }
                break;
            case 25:
                {
                    int ret = slice_from_s(z, 14, s_26);
                    if (ret < 0) return ret;
                }
                break;
            case 26:
                {
                    int ret = slice_from_s(z, 14, s_27);
                    if (ret < 0) return ret;
                }
                break;
            case 27:
                {
                    int ret = slice_from_s(z, 10, s_28);
                    if (ret < 0) return ret;
                }
                break;
            case 28:
                {
                    int ret = slice_from_s(z, 14, s_29);
                    if (ret < 0) return ret;
                }
                break;
            case 29:
                {
                    int ret = slice_from_s(z, 12, s_30);
                    if (ret < 0) return ret;
                }
                break;
            case 30:
                {
                    int ret = slice_from_s(z, 14, s_31);
                    if (ret < 0) return ret;
                }
                break;
            case 31:
                {
                    int ret = slice_from_s(z, 12, s_32);
                    if (ret < 0) return ret;
                }
                break;
            case 32:
                {
                    int ret = slice_from_s(z, 12, s_33);
                    if (ret < 0) return ret;
                }
                break;
            case 33:
                {
                    int ret = slice_from_s(z, 8, s_34);
                    if (ret < 0) return ret;
                }
                break;
            case 34:
                {
                    int ret = slice_from_s(z, 8, s_35);
                    if (ret < 0) return ret;
                }
                break;
            case 35:
                {
                    int ret = slice_from_s(z, 10, s_36);
                    if (ret < 0) return ret;
                }
                break;
            case 36:
                {
                    int ret = slice_from_s(z, 10, s_37);
                    if (ret < 0) return ret;
                }
                break;
            case 37:
                {
                    int ret = slice_from_s(z, 8, s_38);
                    if (ret < 0) return ret;
                }
                break;
            case 38:
                {
                    int ret = slice_from_s(z, 10, s_39);
                    if (ret < 0) return ret;
                }
                break;
            case 39:
                {
                    int ret = slice_from_s(z, 12, s_40);
                    if (ret < 0) return ret;
                }
                break;
            case 40:
                {
                    int ret = slice_from_s(z, 20, s_41);
                    if (ret < 0) return ret;
                }
                break;
            case 41:
                {
                    int ret = slice_from_s(z, 10, s_42);
                    if (ret < 0) return ret;
                }
                break;
            case 42:
                {
                    int ret = slice_from_s(z, 12, s_43);
                    if (ret < 0) return ret;
                }
                break;
            case 43:
                {
                    int ret = slice_from_s(z, 12, s_44);
                    if (ret < 0) return ret;
                }
                break;
            case 44:
                {
                    int ret = slice_from_s(z, 12, s_45);
                    if (ret < 0) return ret;
                }
                break;
            case 45:
                {
                    int ret = slice_from_s(z, 14, s_46);
                    if (ret < 0) return ret;
                }
                break;
            case 46:
                {
                    int ret = slice_from_s(z, 16, s_47);
                    if (ret < 0) return ret;
                }
                break;
            case 47:
                {
                    int ret = slice_from_s(z, 10, s_48);
                    if (ret < 0) return ret;
                }
                break;
            case 48:
                {
                    int ret = slice_from_s(z, 16, s_49);
                    if (ret < 0) return ret;
                }
                break;
            case 49:
                {
                    int ret = slice_from_s(z, 14, s_50);
                    if (ret < 0) return ret;
                }
                break;
            case 50:
                {
                    int ret = slice_from_s(z, 10, s_51);
                    if (ret < 0) return ret;
                }
                break;
            case 51:
                {
                    int ret = slice_from_s(z, 12, s_52);
                    if (ret < 0) return ret;
                }
                break;
            case 52:
                {
                    int ret = slice_from_s(z, 10, s_53);
                    if (ret < 0) return ret;
                }
                break;
            case 53:
                {
                    int ret = slice_from_s(z, 10, s_54);
                    if (ret < 0) return ret;
                }
                break;
            case 54:
                {
                    int ret = slice_from_s(z, 12, s_55);
                    if (ret < 0) return ret;
                }
                break;
            case 55:
                {
                    int ret = slice_from_s(z, 12, s_56);
                    if (ret < 0) return ret;
                }
                break;
            case 56:
                {
                    int ret = slice_from_s(z, 10, s_57);
                    if (ret < 0) return ret;
                }
                break;
            case 57:
                {
                    int ret = slice_from_s(z, 10, s_58);
                    if (ret < 0) return ret;
                }
                break;
            case 58:
                {
                    int ret = slice_from_s(z, 16, s_59);
                    if (ret < 0) return ret;
                }
                break;
            case 59:
                {
                    int ret = slice_from_s(z, 13, s_60);
                    if (ret < 0) return ret;
                }
                break;
            case 60:
                {
                    int ret = slice_from_s(z, 18, s_61);
                    if (ret < 0) return ret;
                }
                break;
            case 61:
                {
                    int ret = slice_from_s(z, 10, s_62);
                    if (ret < 0) return ret;
                }
                break;
            case 62:
                {
                    int ret = slice_from_s(z, 18, s_63);
                    if (ret < 0) return ret;
                }
                break;
            case 63:
                {
                    int ret = slice_from_s(z, 10, s_64);
                    if (ret < 0) return ret;
                }
                break;
            case 64:
                {
                    int ret = slice_from_s(z, 10, s_65);
                    if (ret < 0) return ret;
                }
                break;
            case 65:
                {
                    int ret = slice_from_s(z, 12, s_66);
                    if (ret < 0) return ret;
                }
                break;
            case 66:
                {
                    int ret = slice_from_s(z, 14, s_67);
                    if (ret < 0) return ret;
                }
                break;
            case 67:
                {
                    int ret = slice_from_s(z, 12, s_68);
                    if (ret < 0) return ret;
                }
                break;
            case 68:
                {
                    int ret = slice_from_s(z, 12, s_69);
                    if (ret < 0) return ret;
                }
                break;
            case 69:
                {
                    int ret = slice_from_s(z, 8, s_70);
                    if (ret < 0) return ret;
                }
                break;
            case 70:
                {
                    int ret = slice_from_s(z, 10, s_71);
                    if (ret < 0) return ret;
                }
                break;
            case 71:
                {
                    int ret = slice_from_s(z, 12, s_72);
                    if (ret < 0) return ret;
                }
                break;
            case 72:
                {
                    int ret = slice_from_s(z, 14, s_73);
                    if (ret < 0) return ret;
                }
                break;
            case 73:
                {
                    int ret = slice_from_s(z, 10, s_74);
                    if (ret < 0) return ret;
                }
                break;
            case 74:
                {
                    int ret = slice_from_s(z, 18, s_75);
                    if (ret < 0) return ret;
                }
                break;
            case 75:
                {
                    int ret = slice_from_s(z, 14, s_76);
                    if (ret < 0) return ret;
                }
                break;
            case 76:
                {
                    int ret = slice_from_s(z, 16, s_77);
                    if (ret < 0) return ret;
                }
                break;
            case 77:
                {
                    int ret = slice_from_s(z, 18, s_78);
                    if (ret < 0) return ret;
                }
                break;
            case 78:
                {
                    int ret = slice_from_s(z, 8, s_79);
                    if (ret < 0) return ret;
                }
                break;
            case 79:
                {
                    int ret = slice_from_s(z, 12, s_80);
                    if (ret < 0) return ret;
                }
                break;
            case 80:
                {
                    int ret = slice_from_s(z, 16, s_81);
                    if (ret < 0) return ret;
                }
                break;
            case 81:
                {
                    int ret = slice_from_s(z, 8, s_82);
                    if (ret < 0) return ret;
                }
                break;
            case 82:
                {
                    int ret = slice_from_s(z, 8, s_83);
                    if (ret < 0) return ret;
                }
                break;
            case 83:
                {
                    int ret = slice_from_s(z, 10, s_84);
                    if (ret < 0) return ret;
                }
                break;
            case 84:
                {
                    int ret = slice_from_s(z, 8, s_85);
                    if (ret < 0) return ret;
                }
                break;
            case 85:
                {
                    int ret = slice_from_s(z, 10, s_86);
                    if (ret < 0) return ret;
                }
                break;
            case 86:
                {
                    int ret = slice_from_s(z, 12, s_87);
                    if (ret < 0) return ret;
                }
                break;
            case 87:
                {
                    int ret = slice_from_s(z, 16, s_88);
                    if (ret < 0) return ret;
                }
                break;
            case 88:
                {
                    int ret = slice_from_s(z, 10, s_89);
                    if (ret < 0) return ret;
                }
                break;
            case 89:
                {
                    int ret = slice_from_s(z, 10, s_90);
                    if (ret < 0) return ret;
                }
                break;
            case 90:
                {
                    int ret = slice_from_s(z, 16, s_91);
                    if (ret < 0) return ret;
                }
                break;
            case 91:
                {
                    int ret = slice_from_s(z, 12, s_92);
                    if (ret < 0) return ret;
                }
                break;
            case 92:
                {
                    int ret = slice_from_s(z, 10, s_93);
                    if (ret < 0) return ret;
                }
                break;
            case 93:
                {
                    int ret = slice_from_s(z, 10, s_94);
                    if (ret < 0) return ret;
                }
                break;
            case 94:
                {
                    int ret = slice_from_s(z, 16, s_95);
                    if (ret < 0) return ret;
                }
                break;
            case 95:
                {
                    int ret = slice_from_s(z, 12, s_96);
                    if (ret < 0) return ret;
                }
                break;
            case 96:
                {
                    int ret = slice_from_s(z, 14, s_97);
                    if (ret < 0) return ret;
                }
                break;
            case 97:
                {
                    int ret = slice_from_s(z, 10, s_98);
                    if (ret < 0) return ret;
                }
                break;
            case 98:
                {
                    int ret = slice_from_s(z, 7, s_99);
                    if (ret < 0) return ret;
                }
                break;
            case 99:
                {
                    int ret = slice_from_s(z, 8, s_100);
                    if (ret < 0) return ret;
                }
                break;
            case 100:
                {
                    int ret = slice_from_s(z, 8, s_101);
                    if (ret < 0) return ret;
                }
                break;
            case 101:
                {
                    int ret = slice_from_s(z, 8, s_102);
                    if (ret < 0) return ret;
                }
                break;
            case 102:
                {
                    int ret = slice_from_s(z, 8, s_103);
                    if (ret < 0) return ret;
                }
                break;
            case 103:
                {
                    int ret = slice_from_s(z, 8, s_104);
                    if (ret < 0) return ret;
                }
                break;
            case 104:
                {
                    int ret = slice_from_s(z, 8, s_105);
                    if (ret < 0) return ret;
                }
                break;
            case 105:
                {
                    int ret = slice_from_s(z, 8, s_106);
                    if (ret < 0) return ret;
                }
                break;
            case 106:
                {
                    int ret = slice_from_s(z, 8, s_107);
                    if (ret < 0) return ret;
                }
                break;
            case 107:
                {
                    int ret = slice_from_s(z, 14, s_108);
                    if (ret < 0) return ret;
                }
                break;
            case 108:
                {
                    int ret = slice_from_s(z, 8, s_32);
                    if (ret < 0) return ret;
                }
                break;
            case 109:
                {
                    int ret = slice_from_s(z, 14, s_109);
                    if (ret < 0) return ret;
                }
                break;
            case 110:
                {
                    int ret = slice_from_s(z, 10, s_110);
                    if (ret < 0) return ret;
                }
                break;
            case 111:
                {
                    int ret = slice_from_s(z, 10, s_111);
                    if (ret < 0) return ret;
                }
                break;
            case 112:
                {
                    int ret = slice_from_s(z, 10, s_112);
                    if (ret < 0) return ret;
                }
                break;
            case 113:
                {
                    int ret = slice_from_s(z, 6, s_113);
                    if (ret < 0) return ret;
                }
                break;
            case 114:
                {
                    int ret = slice_from_s(z, 10, s_114);
                    if (ret < 0) return ret;
                }
                break;
            case 115:
                {
                    int ret = slice_from_s(z, 10, s_115);
                    if (ret < 0) return ret;
                }
                break;
            case 116:
                {
                    int ret = slice_from_s(z, 14, s_116);
                    if (ret < 0) return ret;
                }
                break;
            case 117:
                {
                    int ret = slice_from_s(z, 6, s_117);
                    if (ret < 0) return ret;
                }
                break;
            case 118:
                {
                    int ret = slice_from_s(z, 14, s_118);
                    if (ret < 0) return ret;
                }
                break;
            case 119:
                {
                    int ret = slice_from_s(z, 12, s_119);
                    if (ret < 0) return ret;
                }
                break;
            case 120:
                {
                    int ret = slice_from_s(z, 12, s_120);
                    if (ret < 0) return ret;
                }
                break;
            case 121:
                {
                    int ret = slice_from_s(z, 10, s_121);
                    if (ret < 0) return ret;
                }
                break;
            case 122:
                {
                    int ret = slice_from_s(z, 8, s_122);
                    if (ret < 0) return ret;
                }
                break;
            case 123:
                {
                    int ret = slice_from_s(z, 12, s_123);
                    if (ret < 0) return ret;
                }
                break;
            case 124:
                {
                    int ret = slice_from_s(z, 10, s_124);
                    if (ret < 0) return ret;
                }
                break;
            case 125:
                {
                    int ret = slice_from_s(z, 10, s_125);
                    if (ret < 0) return ret;
                }
                break;
            case 126:
                {
                    int ret = slice_from_s(z, 10, s_126);
                    if (ret < 0) return ret;
                }
                break;
            case 127:
                {
                    int ret = slice_from_s(z, 8, s_127);
                    if (ret < 0) return ret;
                }
                break;
            case 128:
                {
                    int ret = slice_from_s(z, 10, s_128);
                    if (ret < 0) return ret;
                }
                break;
            case 129:
                {
                    int ret = slice_from_s(z, 12, s_129);
                    if (ret < 0) return ret;
                }
                break;
            case 130:
                {
                    int ret = slice_from_s(z, 10, s_130);
                    if (ret < 0) return ret;
                }
                break;
            case 131:
                {
                    int ret = slice_from_s(z, 10, s_131);
                    if (ret < 0) return ret;
                }
                break;
            case 132:
                {
                    int ret = slice_from_s(z, 8, s_132);
                    if (ret < 0) return ret;
                }
                break;
            case 133:
                {
                    int ret = slice_from_s(z, 6, s_133);
                    if (ret < 0) return ret;
                }
                break;
            case 134:
                {
                    int ret = slice_from_s(z, 12, s_134);
                    if (ret < 0) return ret;
                }
                break;
            case 135:
                {
                    int ret = slice_from_s(z, 12, s_135);
                    if (ret < 0) return ret;
                }
                break;
            case 136:
                {
                    int ret = slice_from_s(z, 10, s_136);
                    if (ret < 0) return ret;
                }
                break;
            case 137:
                {
                    int ret = slice_from_s(z, 10, s_137);
                    if (ret < 0) return ret;
                }
                break;
            case 138:
                {
                    int ret = slice_from_s(z, 7, s_138);
                    if (ret < 0) return ret;
                }
                break;
            case 139:
                {
                    int ret = slice_from_s(z, 11, s_139);
                    if (ret < 0) return ret;
                }
                break;
            case 140:
                {
                    int ret = slice_from_s(z, 12, s_140);
                    if (ret < 0) return ret;
                }
                break;
            case 141:
                {
                    int ret = slice_from_s(z, 6, s_141);
                    if (ret < 0) return ret;
                }
                break;
            case 142:
                {
                    int ret = slice_from_s(z, 4, s_142);
                    if (ret < 0) return ret;
                }
                break;
            case 143:
                {
                    int ret = slice_from_s(z, 8, s_143);
                    if (ret < 0) return ret;
                }
                break;
            case 144:
                {
                    int ret = slice_from_s(z, 10, s_144);
                    if (ret < 0) return ret;
                }
                break;
            case 145:
                {
                    int ret = slice_from_s(z, 10, s_145);
                    if (ret < 0) return ret;
                }
                break;
            case 146:
                {
                    int ret = slice_from_s(z, 14, s_146);
                    if (ret < 0) return ret;
                }
                break;
            case 147:
                {
                    int ret = slice_from_s(z, 8, s_147);
                    if (ret < 0) return ret;
                }
                break;
            case 148:
                {
                    int ret = slice_from_s(z, 10, s_148);
                    if (ret < 0) return ret;
                }
                break;
            case 149:
                {
                    int ret = slice_from_s(z, 12, s_149);
                    if (ret < 0) return ret;
                }
                break;
            case 150:
                {
                    int ret = slice_from_s(z, 12, s_150);
                    if (ret < 0) return ret;
                }
                break;
            case 151:
                {
                    int ret = slice_from_s(z, 16, s_151);
                    if (ret < 0) return ret;
                }
                break;
            case 152:
                {
                    int ret = slice_from_s(z, 16, s_152);
                    if (ret < 0) return ret;
                }
                break;
            case 153:
                {
                    int ret = slice_from_s(z, 16, s_153);
                    if (ret < 0) return ret;
                }
                break;
            case 154:
                {
                    int ret = slice_from_s(z, 14, s_154);
                    if (ret < 0) return ret;
                }
                break;
            case 155:
                {
                    int ret = slice_from_s(z, 16, s_155);
                    if (ret < 0) return ret;
                }
                break;
            case 156:
                {
                    int ret = slice_from_s(z, 14, s_156);
                    if (ret < 0) return ret;
                }
                break;
            case 157:
                {
                    int ret = slice_from_s(z, 10, s_157);
                    if (ret < 0) return ret;
                }
                break;
            case 158:
                {
                    int ret = slice_from_s(z, 12, s_158);
                    if (ret < 0) return ret;
                }
                break;
            case 159:
                {
                    int ret = slice_from_s(z, 10, s_159);
                    if (ret < 0) return ret;
                }
                break;
            case 160:
                {
                    int ret = slice_from_s(z, 12, s_160);
                    if (ret < 0) return ret;
                }
                break;
            case 161:
                {
                    int ret = slice_from_s(z, 12, s_161);
                    if (ret < 0) return ret;
                }
                break;
            case 162:
                {
                    int ret = slice_from_s(z, 10, s_162);
                    if (ret < 0) return ret;
                }
                break;
            case 163:
                {
                    int ret = slice_from_s(z, 14, s_163);
                    if (ret < 0) return ret;
                }
                break;
            case 164:
                {
                    int ret = slice_from_s(z, 12, s_164);
                    if (ret < 0) return ret;
                }
                break;
            case 165:
                {
                    int ret = slice_from_s(z, 10, s_165);
                    if (ret < 0) return ret;
                }
                break;
            case 166:
                {
                    int ret = slice_from_s(z, 12, s_166);
                    if (ret < 0) return ret;
                }
                break;
            case 167:
                {
                    int ret = slice_from_s(z, 10, s_167);
                    if (ret < 0) return ret;
                }
                break;
            case 168:
                {
                    int ret = slice_from_s(z, 14, s_168);
                    if (ret < 0) return ret;
                }
                break;
            case 169:
                {
                    int ret = slice_from_s(z, 12, s_169);
                    if (ret < 0) return ret;
                }
                break;
            case 170:
                {
                    int ret = slice_from_s(z, 10, s_170);
                    if (ret < 0) return ret;
                }
                break;
            case 171:
                {
                    int ret = slice_from_s(z, 12, s_171);
                    if (ret < 0) return ret;
                }
                break;
            case 172:
                {
                    int ret = slice_from_s(z, 12, s_172);
                    if (ret < 0) return ret;
                }
                break;
            case 173:
                {
                    int ret = slice_from_s(z, 12, s_173);
                    if (ret < 0) return ret;
                }
                break;
            case 174:
                {
                    int ret = slice_from_s(z, 12, s_174);
                    if (ret < 0) return ret;
                }
                break;
            case 175:
                {
                    int ret = slice_from_s(z, 10, s_175);
                    if (ret < 0) return ret;
                }
                break;
            case 176:
                {
                    int ret = slice_from_s(z, 10, s_176);
                    if (ret < 0) return ret;
                }
                break;
            case 177:
                {
                    int ret = slice_from_s(z, 10, s_177);
                    if (ret < 0) return ret;
                }
                break;
            case 178:
                {
                    int ret = slice_from_s(z, 16, s_178);
                    if (ret < 0) return ret;
                }
                break;
            case 179:
                {
                    int ret = slice_from_s(z, 16, s_179);
                    if (ret < 0) return ret;
                }
                break;
            case 180:
                {
                    int ret = slice_from_s(z, 18, s_180);
                    if (ret < 0) return ret;
                }
                break;
            case 181:
                {
                    int ret = slice_from_s(z, 18, s_181);
                    if (ret < 0) return ret;
                }
                break;
            case 182:
                {
                    int ret = slice_from_s(z, 14, s_182);
                    if (ret < 0) return ret;
                }
                break;
            case 183:
                {
                    int ret = slice_from_s(z, 18, s_183);
                    if (ret < 0) return ret;
                }
                break;
            case 184:
                {
                    int ret = slice_from_s(z, 16, s_184);
                    if (ret < 0) return ret;
                }
                break;
            case 185:
                {
                    int ret = slice_from_s(z, 6, s_185);
                    if (ret < 0) return ret;
                }
                break;
            case 186:
                {
                    int ret = slice_from_s(z, 10, s_186);
                    if (ret < 0) return ret;
                }
                break;
            case 187:
                {
                    int ret = slice_from_s(z, 6, s_187);
                    if (ret < 0) return ret;
                }
                break;
            case 188:
                {
                    int ret = slice_from_s(z, 12, s_188);
                    if (ret < 0) return ret;
                }
                break;
            case 189:
                {
                    int ret = slice_from_s(z, 8, s_189);
                    if (ret < 0) return ret;
                }
                break;
            case 190:
                {
                    int ret = slice_from_s(z, 8, s_190);
                    if (ret < 0) return ret;
                }
                break;
            case 191:
                {
                    int ret = slice_from_s(z, 10, s_191);
                    if (ret < 0) return ret;
                }
                break;
            case 192:
                {
                    int ret = slice_from_s(z, 18, s_192);
                    if (ret < 0) return ret;
                }
                break;
            case 193:
                {
                    int ret = slice_from_s(z, 8, s_193);
                    if (ret < 0) return ret;
                }
                break;
            case 194:
                {
                    int ret = slice_from_s(z, 18, s_194);
                    if (ret < 0) return ret;
                }
                break;
            case 195:
                {
                    int ret = slice_from_s(z, 12, s_195);
                    if (ret < 0) return ret;
                }
                break;
            case 196:
                {
                    int ret = slice_from_s(z, 10, s_180);
                    if (ret < 0) return ret;
                }
                break;
            case 197:
                {
                    int ret = slice_from_s(z, 12, s_196);
                    if (ret < 0) return ret;
                }
                break;
            case 198:
                {
                    int ret = slice_from_s(z, 14, s_197);
                    if (ret < 0) return ret;
                }
                break;
            case 199:
                {
                    int ret = slice_from_s(z, 14, s_198);
                    if (ret < 0) return ret;
                }
                break;
            case 200:
                {
                    int ret = slice_from_s(z, 6, s_199);
                    if (ret < 0) return ret;
                }
                break;
            case 201:
                {
                    int ret = slice_from_s(z, 14, s_200);
                    if (ret < 0) return ret;
                }
                break;
            case 202:
                {
                    int ret = slice_from_s(z, 12, s_201);
                    if (ret < 0) return ret;
                }
                break;
            case 203:
                {
                    int ret = slice_from_s(z, 8, s_202);
                    if (ret < 0) return ret;
                }
                break;
            case 204:
                {
                    int ret = slice_from_s(z, 14, s_203);
                    if (ret < 0) return ret;
                }
                break;
            case 205:
                {
                    int ret = slice_from_s(z, 10, s_204);
                    if (ret < 0) return ret;
                }
                break;
            case 206:
                {
                    int ret = slice_from_s(z, 8, s_205);
                    if (ret < 0) return ret;
                }
                break;
            case 207:
                {
                    int ret = slice_from_s(z, 14, s_206);
                    if (ret < 0) return ret;
                }
                break;
            case 208:
                {
                    int ret = slice_from_s(z, 10, s_207);
                    if (ret < 0) return ret;
                }
                break;
            case 209:
                {
                    int ret = slice_from_s(z, 8, s_208);
                    if (ret < 0) return ret;
                }
                break;
            case 210:
                {
                    int ret = slice_from_s(z, 18, s_209);
                    if (ret < 0) return ret;
                }
                break;
            case 211:
                {
                    int ret = slice_from_s(z, 8, s_210);
                    if (ret < 0) return ret;
                }
                break;
            case 212:
                {
                    int ret = slice_from_s(z, 10, s_211);
                    if (ret < 0) return ret;
                }
                break;
            case 213:
                {
                    int ret = slice_from_s(z, 14, s_212);
                    if (ret < 0) return ret;
                }
                break;
            case 214:
                {
                    int ret = slice_from_s(z, 8, s_213);
                    if (ret < 0) return ret;
                }
                break;
            case 215:
                {
                    int ret = slice_from_s(z, 16, s_214);
                    if (ret < 0) return ret;
                }
                break;
            case 216:
                {
                    int ret = slice_from_s(z, 12, s_215);
                    if (ret < 0) return ret;
                }
                break;
            case 217:
                {
                    int ret = slice_from_s(z, 8, s_216);
                    if (ret < 0) return ret;
                }
                break;
            case 218:
                {
                    int ret = slice_from_s(z, 10, s_217);
                    if (ret < 0) return ret;
                }
                break;
            case 219:
                {
                    int ret = slice_from_s(z, 16, s_218);
                    if (ret < 0) return ret;
                }
                break;
            case 220:
                {
                    int ret = slice_from_s(z, 12, s_219);
                    if (ret < 0) return ret;
                }
                break;
            case 221:
                {
                    int ret = slice_from_s(z, 6, s_220);
                    if (ret < 0) return ret;
                }
                break;
            case 222:
                {
                    int ret = slice_from_s(z, 10, s_221);
                    if (ret < 0) return ret;
                }
                break;
            case 223:
                {
                    int ret = slice_from_s(z, 8, s_222);
                    if (ret < 0) return ret;
                }
                break;
            case 224:
                {
                    int ret = slice_from_s(z, 12, s_223);
                    if (ret < 0) return ret;
                }
                break;
            case 225:
                {
                    int ret = slice_from_s(z, 12, s_224);
                    if (ret < 0) return ret;
                }
                break;
            case 226:
                {
                    int ret = slice_from_s(z, 18, s_225);
                    if (ret < 0) return ret;
                }
                break;
            case 227:
                {
                    int ret = slice_from_s(z, 6, s_226);
                    if (ret < 0) return ret;
                }
                break;
        }
        break;
    lab2:
        z->c = v_2;
        {
            int v_4 = z->c;
            z->lb = z->c; z->c = z->l;
            z->ket = z->c;
            among_var = find_among_b(z, a_16);
            if (!among_var) goto lab3;
            z->bra = z->c;
            switch (among_var) {
                case 1:
                    {
                        int ret = slice_from_s(z, 6, s_227);
                        if (ret < 0) return ret;
                    }
                    break;
                case 2:
                    {
                        int ret = slice_from_s(z, 6, s_153);
                        if (ret < 0) return ret;
                    }
                    break;
                case 3:
                    {
                        int ret = slice_from_s(z, 8, s_228);
                        if (ret < 0) return ret;
                    }
                    break;
                case 4:
                    {
                        int ret = slice_from_s(z, 6, s_229);
                        if (ret < 0) return ret;
                    }
                    break;
                case 5:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 6, s_176);
                        if (ret < 0) return ret;
                    }
                    break;
                case 6:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 8, s_230);
                        if (ret < 0) return ret;
                    }
                    break;
                case 7:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 6, s_231);
                        if (ret < 0) return ret;
                    }
                    break;
                case 8:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 6, s_69);
                        if (ret < 0) return ret;
                    }
                    break;
                case 9:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 6, s_232);
                        if (ret < 0) return ret;
                    }
                    break;
                case 10:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 8, s_233);
                        if (ret < 0) return ret;
                    }
                    break;
                case 11:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 8, s_234);
                        if (ret < 0) return ret;
                    }
                    break;
                case 12:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 6, s_235);
                        if (ret < 0) return ret;
                    }
                    break;
                case 13:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 6, s_236);
                        if (ret < 0) return ret;
                    }
                    break;
                case 14:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 6, s_237);
                        if (ret < 0) return ret;
                    }
                    break;
                case 15:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 6, s_238);
                        if (ret < 0) return ret;
                    }
                    break;
                case 16:
                    if (z->c > z->lb) goto lab3;
                    {
                        int ret = slice_from_s(z, 6, s_239);
                        if (ret < 0) return ret;
                    }
                    break;
            }
            z->c = z->lb;
        lab3:
            z->c = v_4;
        }
        b_found_la_noun = 0;
        b_found_ty_noun = 0;
        {
            int v_5 = z->c;
            z->lb = z->c; z->c = z->l;
            {
                int v_6 = z->l - z->c;
                if (z->c - 3 <= z->lb || (z->p[z->c - 1] != 140 && z->p[z->c - 1] != 143)) { z->c = z->l - v_6; goto lab5; }
                if (!find_among_b(z, a_17)) { z->c = z->l - v_6; goto lab5; }
            lab5:
                ;
            }
            do {
                int v_7 = z->l - z->c;
                do {
                    if (!(eq_s_b(z, 4, s_76))) goto lab7;
                    break;
                lab7:
                    if (!(eq_s_b(z, 4, s_127))) goto lab8;
                    break;
                lab8:
                    if (!(eq_s_b(z, 4, s_162))) goto lab6;
                } while (0);
                do {
                    int v_8 = z->l - z->c;
                    if (!(eq_s_b(z, 2, s_2))) goto lab9;
                    if (!(eq_s_b(z, 2, s_5))) goto lab10;
                    goto lab9;
                lab10:
                    break;
                lab9:
                    z->c = z->l - v_8;
                    if (!(eq_s_b(z, 2, s_7))) goto lab11;
                    break;
                lab11:
                    if (!(eq_s_b(z, 2, s_11))) goto lab12;
                    {
                        int v_9 = z->l - z->c;
                        if (!(eq_s_b(z, 2, s_4))) goto lab13;
                        if (z->c > z->lb) goto lab13;
                        goto lab12;
                    lab13:
                        z->c = z->l - v_9;
                    }
                    break;
                lab12:
                    z->c = z->l - v_8;
                    if (!(eq_s_b(z, 2, s_10))) goto lab14;
                    break;
                lab14:
                    if (!(eq_s_b(z, 2, s_3))) goto lab15;
                    break;
                lab15:
                    if (!(eq_s_b(z, 2, s_240))) goto lab16;
                    break;
                lab16:
                    if (!(eq_s_b(z, 2, s_112))) goto lab17;
                    break;
                lab17:
                    if (!(eq_s_b(z, 2, s_22))) goto lab18;
                    break;
                lab18:
                    if (!(eq_s_b(z, 2, s_5))) goto lab19;
                    break;
                lab19:
                    if (!(eq_s_b(z, 2, s_82))) goto lab6;
                    if (!(eq_s_b(z, 2, s_3))) goto lab20;
                    goto lab6;
                lab20:
                    ;
                } while (0);
                b_found_la_noun = 1;
                break;
            lab6:
                z->c = z->l - v_7;
                if (!(eq_s_b(z, 4, s_241))) goto lab4;
                do {
                    if (!(eq_s_b(z, 2, s_1))) goto lab21;
                    break;
                lab21:
                    if (!(eq_s_b(z, 2, s_82))) goto lab22;
                    break;
                lab22:
                    if (!(eq_s_b(z, 2, s_2))) goto lab23;
                    break;
                lab23:
                    if (!(eq_s_b(z, 4, s_53))) goto lab24;
                    break;
                lab24:
                    if (!(eq_s_b(z, 4, s_242))) goto lab25;
                    break;
                lab25:
                    if (!(eq_s_b(z, 2, s_0))) goto lab26;
                    break;
                lab26:
                    if (!(eq_s_b(z, 2, s_5))) goto lab27;
                    break;
                lab27:
                    if (!(eq_s_b(z, 2, s_48))) goto lab28;
                    break;
                lab28:
                    if (!(eq_s_b(z, 2, s_21))) goto lab29;
                    break;
                lab29:
                    if (!(eq_s_b(z, 2, s_102))) goto lab30;
                    break;
                lab30:
                    if (!(eq_s_b(z, 2, s_22))) goto lab31;
                    break;
                lab31:
                    if (!(eq_s_b(z, 2, s_112))) goto lab32;
                    break;
                lab32:
                    if (!(eq_s_b(z, 2, s_3))) goto lab33;
                    break;
                lab33:
                    if (!(eq_s_b(z, 2, s_7))) goto lab34;
                    break;
                lab34:
                    if (!(eq_s_b(z, 2, s_8))) goto lab35;
                    break;
                lab35:
                    if (!(eq_s_b(z, 2, s_11))) goto lab36;
                    break;
                lab36:
                    if (!(eq_s_b(z, 2, s_243))) goto lab37;
                    break;
                lab37:
                    if (!(eq_s_b(z, 2, s_115))) goto lab38;
                    break;
                lab38:
                    if (!(eq_s_b(z, 2, s_59))) goto lab4;
                } while (0);
                b_found_ty_noun = 1;
            } while (0);
            z->c = z->lb;
        lab4:
            z->c = v_5;
        }
        b_found_diminutive = 0;
        b_found_professional = 0;
        b_found_ia = 0;
        b_found_verb = 0;
        i_pV = z->l;
        i_p2 = z->l;
        {
            int v_10 = z->c;
            {
                int ret = out_grouping_U(z, g_v, 1072, 1111, 1);
                if (ret < 0) goto lab39;
                z->c += ret;
            }
            i_pV = z->c;
            {
                int ret = in_grouping_U(z, g_v, 1072, 1111, 1);
                if (ret < 0) goto lab39;
                z->c += ret;
            }
            {
                int ret = out_grouping_U(z, g_v, 1072, 1111, 1);
                if (ret < 0) goto lab39;
                z->c += ret;
            }
            {
                int ret = in_grouping_U(z, g_v, 1072, 1111, 1);
                if (ret < 0) goto lab39;
                z->c += ret;
            }
            i_p2 = z->c;
        lab39:
            z->c = v_10;
        }
        {
            int v_11 = z->c;
            {
                int ret = skip_utf8(z->p, z->c, z->l, 3);
                if (ret < 0) return 0;
                z->c = ret;
            }
            if (i_pV >= z->c) goto lab40;
            i_pV = z->c;
        lab40:
            z->c = v_11;
        }
        z->lb = z->c; z->c = z->l;
        {
            int v_12;
            if (z->c < i_pV) return 0;
            v_12 = z->lb; z->lb = i_pV;
            {
                int v_13 = z->l - z->c;
                do {
                    int v_14 = z->l - z->c;
                    z->ket = z->c;
                    if (z->c - 5 <= z->lb || (z->p[z->c - 1] != 140 && z->p[z->c - 1] != 184)) goto lab42;
                    among_var = find_among_b(z, a_0);
                    if (!among_var) goto lab42;
                    z->bra = z->c;
                    switch (among_var) {
                        case 1:
                            do {
                                if (!(eq_s_b(z, 2, s_18))) goto lab43;
                                break;
                            lab43:
                                if (!(eq_s_b(z, 2, s_244))) goto lab42;
                            } while (0);
                            {
                                int ret = slice_del(z);
                                if (ret < 0) return ret;
                            }
                            break;
                        case 2:
                            {
                                int ret = slice_del(z);
                                if (ret < 0) return ret;
                            }
                            break;
                        case 3:
                            b_found_verb = 1;
                            {
                                int ret = slice_del(z);
                                if (ret < 0) return ret;
                            }
                            break;
                        case 4:
                            b_found_verb = 1;
                            {
                                int ret = slice_from_s(z, 4, s_208);
                                if (ret < 0) return ret;
                            }
                            break;
                        case 5:
                            b_found_verb = 1;
                            {
                                int ret = slice_from_s(z, 4, s_115);
                                if (ret < 0) return ret;
                            }
                            break;
                    }
                    break;
                lab42:
                    z->c = z->l - v_14;
                    z->ket = z->c;
                    if (z->c - 9 <= z->lb || z->p[z->c - 1] != 143) goto lab44;
                    among_var = find_among_b(z, a_1);
                    if (!among_var) goto lab44;
                    z->bra = z->c;
                    switch (among_var) {
                        case 1:
                            {
                                int ret = slice_del(z);
                                if (ret < 0) return ret;
                            }
                            break;
                        case 2:
                            {
                                int ret = slice_from_s(z, 4, s_208);
                                if (ret < 0) return ret;
                            }
                            break;
                        case 3:
                            {
                                int ret = slice_from_s(z, 4, s_115);
                                if (ret < 0) return ret;
                            }
                            break;
                    }
                    b_found_verb = 1;
                    break;
                lab44:
                    z->c = z->l - v_14;
                    {
                        int v_15 = z->l - z->c;
                        z->ket = z->c;
                        if (z->c - 3 <= z->lb || (z->p[z->c - 1] != 140 && z->p[z->c - 1] != 143)) { z->c = z->l - v_15; goto lab45; }
                        if (!find_among_b(z, a_2)) { z->c = z->l - v_15; goto lab45; }
                        z->bra = z->c;
                        {
                            int ret = slice_del(z);
                            if (ret < 0) return ret;
                        }
                        b_found_verb = 1;
                    lab45:
                        ;
                    }
                    do {
                        int v_16 = z->l - z->c;
                        do {
                            int v_17 = z->l - z->c;
                            {
                                int v_18;
                                if (z->c < i_p2) goto lab47;
                                v_18 = z->lb; z->lb = i_p2;
                                z->ket = z->c;
                                if (!find_among_b(z, a_11)) { z->lb = v_18; goto lab47; }
                                z->bra = z->c;
                                z->lb = v_18;
                            }
                            b_found_ia = 1;
                            b_found_verb = 1;
                            {
                                int ret = slice_del(z);
                                if (ret < 0) return ret;
                            }
                            break;
                        lab47:
                            z->c = z->l - v_17;
                            z->ket = z->c;
                            if (!find_among_b(z, a_12)) goto lab46;
                            z->bra = z->c;
                            b_found_ia = 1;
                            b_found_verb = 1;
                            {
                                int ret = slice_del(z);
                                if (ret < 0) return ret;
                            }
                        } while (0);
                        break;
                    lab46:
                        z->c = z->l - v_16;
                        {
                            int v_19 = z->l - z->c;
                            do {
                                int v_20 = z->l - z->c;
                                {
                                    int ret = r_professional(z);
                                    if (ret == 0) goto lab49;
                                    if (ret < 0) return ret;
                                }
                                b_found_professional = 1;
                                break;
                            lab49:
                                z->c = z->l - v_20;
                                z->ket = z->c;
                                among_var = find_among_b(z, a_9);
                                if (!among_var) goto lab48;
                                z->bra = z->c;
                                switch (among_var) {
                                    case 1:
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 2:
                                        {
                                            int ret = slice_from_s(z, 2, s_0);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                }
                                b_found_diminutive = 1;
                            } while (0);
                        lab48:
                            z->c = z->l - v_19;
                        }
                        if (b_found_professional) goto lab41;
                        do {
                            int v_21 = z->l - z->c;
                            do {
                                int v_22 = z->l - z->c;
                                z->ket = z->c;
                                if (!find_among_b(z, a_3)) goto lab51;
                                z->bra = z->c;
                                if (i_p2 > z->c) goto lab51;
                                b_found_ia = 1;
                                {
                                    int ret = slice_del(z);
                                    if (ret < 0) return ret;
                                }
                                break;
                            lab51:
                                z->c = z->l - v_22;
                                z->ket = z->c;
                                among_var = find_among_b(z, a_4);
                                if (!among_var) goto lab50;
                                z->bra = z->c;
                                switch (among_var) {
                                    case 1:
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 2:
                                        do {
                                            if (!(eq_s_b(z, 2, s_24))) goto lab52;
                                            break;
                                        lab52:
                                            if (!(eq_s_b(z, 2, s_12))) goto lab53;
                                            break;
                                        lab53:
                                            if (!(eq_s_b(z, 2, s_48))) goto lab54;
                                            break;
                                        lab54:
                                            if (!(eq_s_b(z, 2, s_159))) goto lab50;
                                        } while (0);
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                }
                            } while (0);
                            break;
                        lab50:
                            z->c = z->l - v_21;
                            do {
                                int v_23 = z->l - z->c;
                                z->ket = z->c;
                                if (!(eq_s_b(z, 10, s_245))) goto lab56;
                                z->bra = z->c;
                                if (z->c <= z->lb) goto lab56;
                                {
                                    int ret = slice_del(z);
                                    if (ret < 0) return ret;
                                }
                                break;
                            lab56:
                                z->c = z->l - v_23;
                                z->ket = z->c;
                                among_var = find_among_b(z, a_5);
                                if (!among_var) goto lab55;
                                z->bra = z->c;
                                switch (among_var) {
                                    case 1:
                                        b_found_ia = 1;
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 2:
                                        b_found_ia = 1;
                                        do {
                                            int v_24 = z->l - z->c;
                                            do {
                                                if (z->c > z->lb) goto lab58;
                                                break;
                                            lab58:
                                                if (!(eq_s_b(z, 2, s_11))) goto lab59;
                                                break;
                                            lab59:
                                                if (!(eq_s_b(z, 2, s_12))) goto lab60;
                                                break;
                                            lab60:
                                                if (!(eq_s_b(z, 2, s_48))) goto lab61;
                                                break;
                                            lab61:
                                                if (!(eq_s_b(z, 2, s_159))) goto lab62;
                                                break;
                                            lab62:
                                                if (!(eq_s_b(z, 2, s_8))) goto lab63;
                                                break;
                                            lab63:
                                                if (!(eq_s_b(z, 2, s_1))) goto lab64;
                                                break;
                                            lab64:
                                                if (!(eq_s_b(z, 2, s_7))) goto lab57;
                                            } while (0);
                                            {
                                                int ret = slice_del(z);
                                                if (ret < 0) return ret;
                                            }
                                            break;
                                        lab57:
                                            z->c = z->l - v_24;
                                            {
                                                int ret = slice_from_s(z, 2, s_82);
                                                if (ret < 0) return ret;
                                            }
                                        } while (0);
                                        break;
                                    case 3:
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 4:
                                        if (in_grouping_b_U(z, g_v, 1072, 1111, 0)) goto lab65;
                                        goto lab55;
                                    lab65:
                                        b_found_ia = 1;
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 5:
                                        {
                                            int v_25 = z->l - z->c;
                                            do {
                                                if (!(eq_s_b(z, 2, s_4))) goto lab67;
                                                break;
                                            lab67:
                                                if (!(eq_s_b(z, 2, s_90))) goto lab68;
                                                break;
                                            lab68:
                                                if (z->c <= z->lb || z->p[z->c - 1] != '\'') goto lab66;
                                                z->c--;
                                            } while (0);
                                            goto lab55;
                                        lab66:
                                            z->c = z->l - v_25;
                                        }
                                        b_found_ia = 1;
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 6:
                                        {
                                            int ret = slice_from_s(z, 4, s_208);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 7:
                                        {
                                            int ret = slice_from_s(z, 4, s_115);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 8:
                                        if (!(eq_s_b(z, 2, s_2))) goto lab69;
                                        goto lab55;
                                    lab69:
                                        do {
                                            if (z->c > z->lb) goto lab70;
                                            break;
                                        lab70:
                                            if (in_grouping_b_U(z, g_v, 1072, 1111, 0)) goto lab55;
                                        } while (0);
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 9:
                                        {
                                            int v_26 = z->l - z->c;
                                            do {
                                                if (!(eq_s_b(z, 6, s_246))) goto lab72;
                                                break;
                                            lab72:
                                                if (!(eq_s_b(z, 6, s_247))) goto lab71;
                                            } while (0);
                                            goto lab55;
                                        lab71:
                                            z->c = z->l - v_26;
                                        }
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 10:
                                        if (b_found_la_noun) goto lab55;
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 11:
                                        if (!(eq_s_b(z, 6, s_248))) goto lab73;
                                        goto lab55;
                                    lab73:
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 12:
                                        if (b_found_ty_noun) goto lab55;
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                }
                            } while (0);
                            b_found_verb = 1;
                            break;
                        lab55:
                            z->c = z->l - v_21;
                            do {
                                int v_27 = z->l - z->c;
                                z->ket = z->c;
                                if (z->c - 7 <= z->lb || z->p[z->c - 1] >> 5 != 4 || !((4214784 >> (z->p[z->c - 1] & 0x1f)) & 1)) goto lab74;
                                if (!find_among_b(z, a_6)) goto lab74;
                                z->bra = z->c;
                                if (z->c <= z->lb) goto lab74;
                                {
                                    int ret = slice_del(z);
                                    if (ret < 0) return ret;
                                }
                                break;
                            lab74:
                                z->c = z->l - v_27;
                                z->ket = z->c;
                                among_var = find_among_b(z, a_7);
                                if (!among_var) goto lab41;
                                z->bra = z->c;
                                switch (among_var) {
                                    case 1:
                                        {
                                            int ret = slice_from_s(z, 8, s_248);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 2:
                                        {
                                            int ret = slice_from_s(z, 2, s_90);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                    case 3:
                                        {
                                            int ret = slice_del(z);
                                            if (ret < 0) return ret;
                                        }
                                        break;
                                }
                            } while (0);
                        } while (0);
                    } while (0);
                } while (0);
            lab41:
                z->c = z->l - v_13;
            }
            {
                int v_28 = z->l - z->c;
                z->ket = z->c;
                if (z->c - 7 <= z->lb || z->p[z->c - 1] != 186) { z->c = z->l - v_28; goto lab75; }
                if (!find_among_b(z, a_10)) { z->c = z->l - v_28; goto lab75; }
                z->bra = z->c;
                {
                    int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
                b_found_diminutive = 1;
            lab75:
                ;
            }
            {
                int v_29 = z->l - z->c;
                if (b_found_diminutive) goto lab76;
                if (b_found_professional) goto lab76;
                if (b_found_ia) goto lab76;
                {
                    int ret = r_professional(z);
                    if (ret == 0) goto lab76;
                    if (ret < 0) return ret;
                }
            lab76:
                z->c = z->l - v_29;
            }
            {
                int v_30 = z->l - z->c;
                if (b_found_verb) goto lab77;
                z->ket = z->c;
                if (!(eq_s_b(z, 4, s_249))) goto lab77;
                z->bra = z->c;
                {
                    int ret = slice_del(z);
                    if (ret < 0) return ret;
                }
            lab77:
                z->c = z->l - v_30;
            }
            {
                int v_31 = z->l - z->c;
                {
                    int v_32;
                    if (z->c < i_p2) goto lab78;
                    v_32 = z->lb; z->lb = i_p2;
                    z->ket = z->c;
                    among_var = find_among_b(z, a_13);
                    if (!among_var) { z->lb = v_32; goto lab78; }
                    z->bra = z->c;
                    z->lb = v_32;
                }
                switch (among_var) {
                    case 1:
                        {
                            int ret = slice_del(z);
                            if (ret < 0) return ret;
                        }
                        break;
                    case 2:
                        do {
                            int v_33 = z->l - z->c;
                            if (!(eq_s_b(z, 2, s_3))) goto lab79;
                            {
                                int ret = slice_del(z);
                                if (ret < 0) return ret;
                            }
                            break;
                        lab79:
                            z->c = z->l - v_33;
                            {
                                int ret = slice_from_s(z, 4, s_82);
                                if (ret < 0) return ret;
                            }
                        } while (0);
                        break;
                    case 3:
                        do {
                            int v_34 = z->l - z->c;
                            do {
                                if (!(eq_s_b(z, 4, s_208))) goto lab81;
                                break;
                            lab81:
                                if (!(eq_s_b(z, 4, s_115))) goto lab80;
                            } while (0);
                            {
                                int ret = slice_del(z);
                                if (ret < 0) return ret;
                            }
                            break;
                        lab80:
                            z->c = z->l - v_34;
                            {
                                int ret = slice_from_s(z, 4, s_40);
                                if (ret < 0) return ret;
                            }
                        } while (0);
                        break;
                    case 4:
                        do {
                            if (!(eq_s_b(z, 4, s_208))) goto lab82;
                            break;
                        lab82:
                            if (!(eq_s_b(z, 4, s_115))) goto lab78;
                        } while (0);
                        {
                            int ret = slice_del(z);
                            if (ret < 0) return ret;
                        }
                        break;
                }
            lab78:
                z->c = z->l - v_31;
            }
            {
                int v_35 = z->l - z->c;
                z->ket = z->c;
                among_var = find_among_b(z, a_14);
                if (!among_var) goto lab83;
                z->bra = z->c;
                switch (among_var) {
                    case 1:
                        if (b_found_verb) goto lab83;
                        {
                            int ret = slice_del(z);
                            if (ret < 0) return ret;
                        }
                        z->ket = z->c;
                        if (!(eq_s_b(z, 2, s_1))) goto lab83;
                        z->bra = z->c;
                        if (!(eq_s_b(z, 2, s_1))) goto lab83;
                        {
                            int ret = slice_del(z);
                            if (ret < 0) return ret;
                        }
                        break;
                    case 2:
                        do {
                            if (!(eq_s_b(z, 2, s_112))) goto lab84;
                            break;
                        lab84:
                            if (!(eq_s_b(z, 2, s_22))) goto lab85;
                            break;
                        lab85:
                            if (!(eq_s_b(z, 2, s_3))) goto lab86;
                            break;
                        lab86:
                            if (!(eq_s_b(z, 2, s_8))) goto lab83;
                        } while (0);
                        {
                            int ret = slice_del(z);
                            if (ret < 0) return ret;
                        }
                        break;
                    case 3:
                        if (!(eq_s_b(z, 2, s_1))) goto lab83;
                        {
                            int ret = slice_del(z);
                            if (ret < 0) return ret;
                        }
                        break;
                    case 4:
                        {
                            int ret = slice_del(z);
                            if (ret < 0) return ret;
                        }
                        break;
                }
            lab83:
                z->c = z->l - v_35;
            }
            z->lb = v_12;
        }
        z->c = z->lb;
    } while (0);
    return 1;
}
