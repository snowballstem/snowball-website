/* Generated from dutch.sbl by Snowball 3.2.0 - https://snowballstem.org/ */

#ifdef __cplusplus
extern "C" {
#endif

struct SN_env;

extern struct SN_env * dutch_UTF_8_create_env(void);
extern void dutch_UTF_8_close_env(struct SN_env * z);

extern int dutch_UTF_8_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif
