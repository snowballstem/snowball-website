/* Generated from dutch_porter.sbl by Snowball 3.2.0 - https://snowballstem.org/ */

#ifdef __cplusplus
extern "C" {
#endif

struct SN_env;

extern struct SN_env * dutch_porter_ISO_8859_1_create_env(void);
#define dutch_porter_ISO_8859_1_close_env SN_delete_env

extern int dutch_porter_ISO_8859_1_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif
