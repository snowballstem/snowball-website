# Generated from finnish.sbl by Snowball 3.2.0 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class FinnishStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from finnish.sbl by Snowball 3.2.0 - https://snowballstem.org/
    '''

    g_AEI = {"a", "e", "i", "ä"}

    g_C = {"b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "z"}

    g_v = {"a", "e", "i", "o", "u", "y", "ä", "ö"}

    g_particle_end = {"a", "e", "i", "n", "o", "t", "u", "y", "ä", "ö"}


    def __r_LV(self):
        return self.find_among_b(FinnishStemmer.a_5) != 0

    def __r_VI(self):
        return self.find_among_b(FinnishStemmer.a_6) != 0

    def __r_A(self):
        while True:
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "a":
                    raise lab0()
                self.cursor -= 1
                break
            except lab0: pass
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "'":
                return False
            self.cursor -= 1
            break
        return True

    def __r_E(self):
        while True:
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "e":
                    raise lab0()
                self.cursor -= 1
                break
            except lab0: pass
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "'":
                return False
            self.cursor -= 1
            break
        return True

    def __r_I(self):
        while True:
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "i":
                    raise lab0()
                self.cursor -= 1
                break
            except lab0: pass
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "'":
                return False
            self.cursor -= 1
            break
        return True

    def __r_O(self):
        while True:
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "o":
                    raise lab0()
                self.cursor -= 1
                break
            except lab0: pass
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "'":
                return False
            self.cursor -= 1
            break
        return True

    def __r_U(self):
        while True:
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "u":
                    raise lab0()
                self.cursor -= 1
                break
            except lab0: pass
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "'":
                return False
            self.cursor -= 1
            break
        return True

    def __r_A_(self):
        while True:
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ä":
                    raise lab0()
                self.cursor -= 1
                break
            except lab0: pass
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "'":
                return False
            self.cursor -= 1
            break
        return True

    def __r_O_(self):
        while True:
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ö":
                    raise lab0()
                self.cursor -= 1
                break
            except lab0: pass
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ø":
                    raise lab0()
                self.cursor -= 1
                break
            except lab0: pass
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "'":
                return False
            self.cursor -= 1
            break
        return True

    def _stem(self):
        v_1 = self.cursor
        try:
            I_p1 = self.limit
            I_p2 = self.limit
            if not self.go_out_grouping(FinnishStemmer.g_v):
                raise lab0()
            self.cursor += 1
            if not self.go_in_grouping(FinnishStemmer.g_v):
                raise lab0()
            self.cursor += 1
            I_p1 = self.cursor
            if not self.go_out_grouping(FinnishStemmer.g_v):
                raise lab0()
            self.cursor += 1
            if not self.go_in_grouping(FinnishStemmer.g_v):
                raise lab0()
            self.cursor += 1
            I_p2 = self.cursor
        except lab0: pass
        self.cursor = v_1
        B_ending_removed = False
        self.limit_backward = self.cursor
        self.cursor = self.limit
        v_2 = self.limit - self.cursor
        try:
            if self.cursor < I_p1:
                raise lab0()
            v_4 = self.limit_backward
            self.limit_backward = I_p1
            self.ket = self.cursor
            among_var = self.find_among_b(FinnishStemmer.a_0)
            if among_var == 0:
                self.limit_backward = v_4
                raise lab0()
            self.bra = self.cursor
            self.limit_backward = v_4
            if among_var == 1:
                if not self.in_grouping_b(FinnishStemmer.g_particle_end):
                    raise lab0()
            else:
                if I_p2 > self.cursor:
                    raise lab0()
            self.slice_del()
        except lab0: pass
        self.cursor = self.limit - v_2
        v_5 = self.limit - self.cursor
        try:
            if self.cursor < I_p1:
                raise lab0()
            v_7 = self.limit_backward
            self.limit_backward = I_p1
            self.ket = self.cursor
            among_var = self.find_among_b(FinnishStemmer.a_4)
            if among_var == 0:
                self.limit_backward = v_7
                raise lab0()
            self.bra = self.cursor
            self.limit_backward = v_7
            if among_var == 1:
                try:
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "k":
                        raise lab1()
                    self.cursor -= 1
                    raise lab0()
                except lab1: pass
                self.slice_del()
            elif among_var == 2:
                self.slice_del()
                self.ket = self.cursor
                if not self.eq_s_b("kse"):
                    raise lab0()
                self.bra = self.cursor
                self.slice_from("ksi")
            elif among_var == 3:
                self.slice_del()
            elif among_var == 4:
                if self.find_among_b(FinnishStemmer.a_1) == 0:
                    raise lab0()
                self.slice_del()
            elif among_var == 5:
                if self.find_among_b(FinnishStemmer.a_2) == 0:
                    raise lab0()
                self.slice_del()
            else:
                if self.find_among_b(FinnishStemmer.a_3) == 0:
                    raise lab0()
                self.slice_del()
        except lab0: pass
        self.cursor = self.limit - v_5
        v_8 = self.limit - self.cursor
        try:
            if self.cursor < I_p1:
                raise lab0()
            v_10 = self.limit_backward
            self.limit_backward = I_p1
            self.ket = self.cursor
            among_var = self.find_among_b(FinnishStemmer.a_7)
            if among_var == 0:
                self.limit_backward = v_10
                raise lab0()
            self.bra = self.cursor
            self.limit_backward = v_10
            if among_var == 1:
                v_11 = self.limit - self.cursor
                try:
                    v_12 = self.limit - self.cursor
                    while True:
                        v_13 = self.limit - self.cursor
                        try:
                            if not self.__r_LV():
                                raise lab2()
                            break
                        except lab2: pass
                        self.cursor = self.limit - v_13
                        if not self.eq_s_b("ie"):
                            self.cursor = self.limit - v_11
                            raise lab1()
                        break
                    self.cursor = self.limit - v_12
                    if self.cursor <= self.limit_backward:
                        self.cursor = self.limit - v_11
                        raise lab1()
                    self.cursor -= 1
                    self.bra = self.cursor
                except lab1: pass
            elif among_var == 2:
                if not self.in_grouping_b(FinnishStemmer.g_v):
                    raise lab0()
                if not self.in_grouping_b(FinnishStemmer.g_C):
                    raise lab0()
            elif among_var == 3:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "e":
                    raise lab0()
                self.cursor -= 1
            self.slice_del()
            B_ending_removed = True
        except lab0: pass
        self.cursor = self.limit - v_8
        v_14 = self.limit - self.cursor
        try:
            if self.cursor < I_p2:
                raise lab0()
            v_16 = self.limit_backward
            self.limit_backward = I_p2
            self.ket = self.cursor
            among_var = self.find_among_b(FinnishStemmer.a_8)
            if among_var == 0:
                self.limit_backward = v_16
                raise lab0()
            self.bra = self.cursor
            self.limit_backward = v_16
            if among_var == 1:
                try:
                    if not self.eq_s_b("po"):
                        raise lab1()
                    raise lab0()
                except lab1: pass
            self.slice_del()
        except lab0: pass
        self.cursor = self.limit - v_14
        while True:
            try:
                if not B_ending_removed:
                    raise lab0()
                v_17 = self.limit - self.cursor
                try:
                    if self.cursor < I_p1:
                        raise lab1()
                    v_19 = self.limit_backward
                    self.limit_backward = I_p1
                    self.ket = self.cursor
                    if self.find_among_b(FinnishStemmer.a_9) == 0:
                        self.limit_backward = v_19
                        raise lab1()
                    self.bra = self.cursor
                    self.limit_backward = v_19
                    self.slice_del()
                except lab1: pass
                self.cursor = self.limit - v_17
                break
            except lab0: pass
            v_20 = self.limit - self.cursor
            try:
                if self.cursor < I_p1:
                    raise lab0()
                v_22 = self.limit_backward
                self.limit_backward = I_p1
                self.ket = self.cursor
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "t":
                    self.limit_backward = v_22
                    raise lab0()
                self.cursor -= 1
                self.bra = self.cursor
                v_23 = self.limit - self.cursor
                if not self.in_grouping_b(FinnishStemmer.g_v):
                    self.limit_backward = v_22
                    raise lab0()
                self.cursor = self.limit - v_23
                self.slice_del()
                self.limit_backward = v_22
                if self.cursor < I_p2:
                    raise lab0()
                v_25 = self.limit_backward
                self.limit_backward = I_p2
                self.ket = self.cursor
                among_var = self.find_among_b(FinnishStemmer.a_10)
                if among_var == 0:
                    self.limit_backward = v_25
                    raise lab0()
                self.bra = self.cursor
                self.limit_backward = v_25
                if among_var == 1:
                    try:
                        if not self.eq_s_b("po"):
                            raise lab1()
                        raise lab0()
                    except lab1: pass
                self.slice_del()
            except lab0: pass
            self.cursor = self.limit - v_20
            break
        v_26 = self.limit - self.cursor
        try:
            if self.cursor < I_p1:
                raise lab0()
            v_28 = self.limit_backward
            self.limit_backward = I_p1
            v_29 = self.limit - self.cursor
            try:
                v_30 = self.limit - self.cursor
                if not self.__r_LV():
                    raise lab1()
                self.cursor = self.limit - v_30
                self.ket = self.cursor
                if self.cursor <= self.limit_backward:
                    raise lab1()
                self.cursor -= 1
                self.bra = self.cursor
                self.slice_del()
            except lab1: pass
            self.cursor = self.limit - v_29
            v_31 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                if not self.in_grouping_b(FinnishStemmer.g_AEI):
                    raise lab1()
                self.bra = self.cursor
                if not self.in_grouping_b(FinnishStemmer.g_C):
                    raise lab1()
                self.slice_del()
            except lab1: pass
            self.cursor = self.limit - v_31
            v_32 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "j":
                    raise lab1()
                self.cursor -= 1
                self.bra = self.cursor
                while True:
                    try:
                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "o":
                            raise lab2()
                        self.cursor -= 1
                        break
                    except lab2: pass
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "u":
                        raise lab1()
                    self.cursor -= 1
                    break
                self.slice_del()
            except lab1: pass
            self.cursor = self.limit - v_32
            v_33 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "o":
                    raise lab1()
                self.cursor -= 1
                self.bra = self.cursor
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "j":
                    raise lab1()
                self.cursor -= 1
                self.slice_del()
            except lab1: pass
            self.cursor = self.limit - v_33
            self.limit_backward = v_28
            v_34 = self.limit - self.cursor
            try:
                if not self.go_in_grouping_b(FinnishStemmer.g_v):
                    raise lab1()
                self.ket = self.cursor
                if not self.in_grouping_b(FinnishStemmer.g_C):
                    raise lab1()
                self.bra = self.cursor
                S_x = self.slice_to()
                if not self.eq_s_b(S_x):
                    raise lab1()
                self.slice_del()
            except lab1: pass
            self.cursor = self.limit - v_34
            self.ket = self.cursor
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "'":
                raise lab0()
            self.cursor -= 1
            self.bra = self.cursor
            self.slice_del()
        except lab0: pass
        self.cursor = self.limit - v_26
        self.cursor = self.limit_backward
        return True

    a_0 = [
        Among("pa", -1, 1),
        Among("sti", -1, 2),
        Among("kaan", -1, 1),
        Among("han", -1, 1),
        Among("kin", -1, 1),
        Among("hän", -1, 1),
        Among("kään", -1, 1),
        Among("ko", -1, 1),
        Among("pä", -1, 1),
        Among("kö", -1, 1)
    ]

    a_1 = [
        Among("lla", -1, -1),
        Among("na", -1, -1),
        Among("ssa", -1, -1),
        Among("ta", -1, -1),
        Among("lta", 3, -1),
        Among("sta", 3, -1)
    ]

    a_2 = [
        Among("llä", -1, -1),
        Among("nä", -1, -1),
        Among("ssä", -1, -1),
        Among("tä", -1, -1),
        Among("ltä", 3, -1),
        Among("stä", 3, -1)
    ]

    a_3 = [
        Among("lle", -1, -1),
        Among("ine", -1, -1)
    ]

    a_4 = [
        Among("nsa", -1, 3),
        Among("mme", -1, 3),
        Among("nne", -1, 3),
        Among("ni", -1, 2),
        Among("si", -1, 1),
        Among("an", -1, 4),
        Among("en", -1, 6),
        Among("än", -1, 5),
        Among("nsä", -1, 3)
    ]

    a_5 = [
        Among("aa", -1, -1),
        Among("ee", -1, -1),
        Among("ii", -1, -1),
        Among("oo", -1, -1),
        Among("uu", -1, -1),
        Among("ää", -1, -1),
        Among("öö", -1, -1)
    ]

    a_6 = [
        Among("'", -1, -1),
        Among("ai", -1, -1),
        Among("ei", -1, -1),
        Among("ii", -1, -1),
        Among("oi", -1, -1),
        Among("ui", -1, -1),
        Among("äi", -1, -1),
        Among("öi", -1, -1)
    ]

    a_7 = [
        Among("a", -1, 2),
        Among("lla", 0, -1),
        Among("na", 0, -1),
        Among("ssa", 0, -1),
        Among("ta", 0, -1),
        Among("lta", 4, -1),
        Among("sta", 4, -1),
        Among("tta", 4, 3),
        Among("lle", -1, -1),
        Among("ine", -1, -1),
        Among("ksi", -1, -1),
        Among("n", -1, 1),
        Among("han", 11, -1, __r_A),
        Among("den", 11, -1, __r_VI),
        Among("seen", 11, -1, __r_LV),
        Among("hen", 11, -1, __r_E),
        Among("tten", 11, -1, __r_VI),
        Among("hin", 11, -1, __r_I),
        Among("siin", 11, -1, __r_VI),
        Among("hon", 11, -1, __r_O),
        Among("hun", 11, -1, __r_U),
        Among("hän", 11, -1, __r_A_),
        Among("hön", 11, -1, __r_O_),
        Among("ä", -1, 2),
        Among("llä", 23, -1),
        Among("nä", 23, -1),
        Among("ssä", 23, -1),
        Among("tä", 23, -1),
        Among("ltä", 27, -1),
        Among("stä", 27, -1),
        Among("ttä", 27, 3)
    ]

    a_8 = [
        Among("eja", -1, -1),
        Among("mma", -1, 1),
        Among("imma", 1, -1),
        Among("mpa", -1, 1),
        Among("impa", 3, -1),
        Among("mmi", -1, 1),
        Among("immi", 5, -1),
        Among("mpi", -1, 1),
        Among("impi", 7, -1),
        Among("ejä", -1, -1),
        Among("mmä", -1, 1),
        Among("immä", 10, -1),
        Among("mpä", -1, 1),
        Among("impä", 12, -1)
    ]

    a_9 = [
        Among("i", -1, -1),
        Among("j", -1, -1)
    ]

    a_10 = [
        Among("mma", -1, 1),
        Among("imma", 0, -1)
    ]


class lab0(BaseException): pass


class lab1(BaseException): pass


class lab2(BaseException): pass
