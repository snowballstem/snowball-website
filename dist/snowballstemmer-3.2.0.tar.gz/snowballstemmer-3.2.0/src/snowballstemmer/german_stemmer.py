# Generated from german.sbl by Snowball 3.2.0 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class GermanStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from german.sbl by Snowball 3.2.0 - https://snowballstem.org/
    '''

    g_v = {"a", "e", "i", "o", "u", "y", "ä", "ö", "ü"}

    g_et_ending = {"U", "d", "f", "g", "k", "l", "m", "n", "r", "s", "t", "z", "ä"}

    g_s_ending = {"b", "d", "f", "g", "h", "k", "l", "m", "n", "r", "t"}

    g_st_ending = {"b", "d", "f", "g", "h", "k", "l", "m", "n", "t"}


    def _stem(self):
        v_1 = self.cursor
        try:
            v_2 = self.cursor
            while True:
                v_3 = self.cursor
                try:
                    while True:
                        v_4 = self.cursor
                        try:
                            if not self.in_grouping(GermanStemmer.g_v):
                                raise lab2()
                            self.bra = self.cursor
                            while True:
                                v_5 = self.cursor
                                try:
                                    if self.cursor == self.limit or self.current[self.cursor] != "u":
                                        raise lab3()
                                    self.cursor += 1
                                    self.ket = self.cursor
                                    if not self.in_grouping(GermanStemmer.g_v):
                                        raise lab3()
                                    self.slice_from("U")
                                    break
                                except lab3: pass
                                self.cursor = v_5
                                if self.cursor == self.limit or self.current[self.cursor] != "y":
                                    raise lab2()
                                self.cursor += 1
                                self.ket = self.cursor
                                if not self.in_grouping(GermanStemmer.g_v):
                                    raise lab2()
                                self.slice_from("Y")
                                break
                            self.cursor = v_4
                            break
                        except lab2: pass
                        self.cursor = v_4
                        if self.cursor >= self.limit:
                            raise lab1()
                        self.cursor += 1
                    continue
                except lab1: pass
                self.cursor = v_3
                break
            self.cursor = v_2
            while True:
                v_6 = self.cursor
                try:
                    self.bra = self.cursor
                    among_var = self.find_among(GermanStemmer.a_0)
                    self.ket = self.cursor
                    if among_var == 1:
                        self.slice_from("ss")
                    elif among_var == 2:
                        self.slice_from("ä")
                    elif among_var == 3:
                        self.slice_from("ö")
                    elif among_var == 4:
                        self.slice_from("ü")
                    elif among_var == 5:
                        if self.cursor >= self.limit:
                            raise lab1()
                        self.cursor += 1
                    continue
                except lab1: pass
                self.cursor = v_6
                break
        except lab0: pass
        self.cursor = v_1
        v_7 = self.cursor
        try:
            I_p1 = self.limit
            I_p2 = self.limit
            v_8 = self.cursor
            if self.cursor + 3 > self.limit:
                raise lab0()
            self.cursor += 3
            I_x = self.cursor
            self.cursor = v_8
            if not self.go_out_grouping(GermanStemmer.g_v):
                raise lab0()
            self.cursor += 1
            if not self.go_in_grouping(GermanStemmer.g_v):
                raise lab0()
            self.cursor += 1
            I_p1 = self.cursor
            try:
                if I_p1 >= I_x:
                    raise lab1()
                I_p1 = I_x
            except lab1: pass
            if not self.go_out_grouping(GermanStemmer.g_v):
                raise lab0()
            self.cursor += 1
            if not self.go_in_grouping(GermanStemmer.g_v):
                raise lab0()
            self.cursor += 1
            I_p2 = self.cursor
        except lab0: pass
        self.cursor = v_7
        self.limit_backward = self.cursor
        self.cursor = self.limit
        try:
            v_9 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                among_var = self.find_among_b(GermanStemmer.a_2)
                if among_var == 0:
                    raise lab1()
                self.bra = self.cursor
                if I_p1 > self.cursor:
                    raise lab1()
                if among_var == 1:
                    try:
                        if not self.eq_s_b("syst"):
                            raise lab2()
                        raise lab1()
                    except lab2: pass
                    self.slice_del()
                elif among_var == 2:
                    self.slice_del()
                elif among_var == 3:
                    self.slice_del()
                    v_10 = self.limit - self.cursor
                    try:
                        self.ket = self.cursor
                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "s":
                            self.cursor = self.limit - v_10
                            raise lab2()
                        self.cursor -= 1
                        self.bra = self.cursor
                        if not self.eq_s_b("nis"):
                            self.cursor = self.limit - v_10
                            raise lab2()
                        self.slice_del()
                    except lab2: pass
                elif among_var == 4:
                    if not self.in_grouping_b(GermanStemmer.g_s_ending):
                        raise lab1()
                    self.slice_del()
                else:
                    self.slice_from("l")
            except lab1: pass
            self.cursor = self.limit - v_9
            v_11 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                among_var = self.find_among_b(GermanStemmer.a_4)
                if among_var == 0:
                    raise lab1()
                self.bra = self.cursor
                if I_p1 > self.cursor:
                    raise lab1()
                if among_var == 1:
                    self.slice_del()
                elif among_var == 2:
                    if not self.in_grouping_b(GermanStemmer.g_st_ending):
                        raise lab1()
                    if self.cursor - 3 < self.limit_backward:
                        raise lab1()
                    self.cursor -= 3
                    self.slice_del()
                else:
                    v_12 = self.limit - self.cursor
                    if not self.in_grouping_b(GermanStemmer.g_et_ending):
                        raise lab1()
                    self.cursor = self.limit - v_12
                    v_13 = self.limit - self.cursor
                    try:
                        if self.find_among_b(GermanStemmer.a_3) == 0:
                            raise lab2()
                        raise lab1()
                    except lab2: pass
                    self.cursor = self.limit - v_13
                    self.slice_del()
            except lab1: pass
            self.cursor = self.limit - v_11
            v_14 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                among_var = self.find_among_b(GermanStemmer.a_6)
                if among_var == 0:
                    raise lab1()
                self.bra = self.cursor
                if I_p2 > self.cursor:
                    raise lab1()
                if among_var == 1:
                    self.slice_del()
                    v_15 = self.limit - self.cursor
                    try:
                        self.ket = self.cursor
                        if not self.eq_s_b("ig"):
                            self.cursor = self.limit - v_15
                            raise lab2()
                        self.bra = self.cursor
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "e":
                                raise lab3()
                            self.cursor -= 1
                            self.cursor = self.limit - v_15
                            raise lab2()
                        except lab3: pass
                        if I_p2 > self.cursor:
                            self.cursor = self.limit - v_15
                            raise lab2()
                        self.slice_del()
                    except lab2: pass
                elif among_var == 2:
                    try:
                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "e":
                            raise lab2()
                        self.cursor -= 1
                        raise lab1()
                    except lab2: pass
                    self.slice_del()
                elif among_var == 3:
                    self.slice_del()
                    v_16 = self.limit - self.cursor
                    try:
                        self.ket = self.cursor
                        while True:
                            try:
                                if not self.eq_s_b("er"):
                                    raise lab3()
                                break
                            except lab3: pass
                            if not self.eq_s_b("en"):
                                self.cursor = self.limit - v_16
                                raise lab2()
                            break
                        self.bra = self.cursor
                        if I_p1 > self.cursor:
                            self.cursor = self.limit - v_16
                            raise lab2()
                        self.slice_del()
                    except lab2: pass
                else:
                    self.slice_del()
                    v_17 = self.limit - self.cursor
                    try:
                        self.ket = self.cursor
                        if self.find_among_b(GermanStemmer.a_5) == 0:
                            self.cursor = self.limit - v_17
                            raise lab2()
                        self.bra = self.cursor
                        if I_p2 > self.cursor:
                            self.cursor = self.limit - v_17
                            raise lab2()
                        self.slice_del()
                    except lab2: pass
            except lab1: pass
            self.cursor = self.limit - v_14
            v_18 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                if self.find_among_b(GermanStemmer.a_7) == 0:
                    raise lab1()
                self.bra = self.cursor
                if self.cursor <= self.limit_backward:
                    raise lab1()
                self.cursor -= 1
                if self.cursor <= self.limit_backward:
                    raise lab1()
                self.slice_del()
            except lab1: pass
            self.cursor = self.limit - v_18
        except lab0: pass
        self.cursor = self.limit_backward
        v_19 = self.cursor
        try:
            while True:
                v_20 = self.cursor
                try:
                    self.bra = self.cursor
                    among_var = self.find_among(GermanStemmer.a_1)
                    self.ket = self.cursor
                    if among_var == 1:
                        self.slice_from("y")
                    elif among_var == 2:
                        self.slice_from("u")
                    elif among_var == 3:
                        self.slice_from("a")
                    elif among_var == 4:
                        self.slice_from("o")
                    else:
                        if self.cursor >= self.limit:
                            raise lab1()
                        self.cursor += 1
                    continue
                except lab1: pass
                self.cursor = v_20
                break
        except lab0: pass
        self.cursor = v_19
        return True

    a_0 = [
        Among("", -1, 5),
        Among("ae", 0, 2),
        Among("oe", 0, 3),
        Among("qu", 0, -1),
        Among("ue", 0, 4),
        Among("ß", 0, 1)
    ]

    a_1 = [
        Among("", -1, 5),
        Among("U", 0, 2),
        Among("Y", 0, 1),
        Among("ä", 0, 3),
        Among("ö", 0, 4),
        Among("ü", 0, 2)
    ]

    a_2 = [
        Among("e", -1, 3),
        Among("em", -1, 1),
        Among("en", -1, 3),
        Among("erinnen", 2, 2),
        Among("erin", -1, 2),
        Among("ln", -1, 5),
        Among("ern", -1, 2),
        Among("er", -1, 2),
        Among("s", -1, 4),
        Among("es", 8, 3),
        Among("lns", 8, 5)
    ]

    a_3 = [
        Among("tick", -1, -1),
        Among("plan", -1, -1),
        Among("geordn", -1, -1),
        Among("intern", -1, -1),
        Among("tr", -1, -1)
    ]

    a_4 = [
        Among("en", -1, 1),
        Among("er", -1, 1),
        Among("et", -1, 3),
        Among("st", -1, 2),
        Among("est", 3, 1)
    ]

    a_5 = [
        Among("ig", -1, 1),
        Among("lich", -1, 1)
    ]

    a_6 = [
        Among("end", -1, 1),
        Among("ig", -1, 2),
        Among("ung", -1, 1),
        Among("lich", -1, 3),
        Among("isch", -1, 2),
        Among("ik", -1, 2),
        Among("heit", -1, 3),
        Among("keit", -1, 4)
    ]

    a_7 = [
        Among("'", -1, 1),
        Among("'sch", -1, 1),
        Among("'s", -1, 1)
    ]


class lab0(BaseException): pass


class lab1(BaseException): pass


class lab2(BaseException): pass


class lab3(BaseException): pass
