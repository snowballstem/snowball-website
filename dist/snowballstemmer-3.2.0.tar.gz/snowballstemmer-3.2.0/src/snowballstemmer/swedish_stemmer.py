# Generated from swedish.sbl by Snowball 3.2.0 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class SwedishStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from swedish.sbl by Snowball 3.2.0 - https://snowballstem.org/
    '''

    g_v = {"a", "e", "i", "o", "u", "y", "ä", "å", "ö"}

    g_s_ending = {"b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "o", "p", "r", "t", "v", "y"}

    g_ost_ending = {"i", "k", "l", "n", "p", "r", "t", "u", "v"}


    def __r_et_condition(self):
        v_1 = self.limit - self.cursor
        if not self.out_grouping_b(SwedishStemmer.g_v):
            return False
        if not self.in_grouping_b(SwedishStemmer.g_v):
            return False
        if self.cursor <= self.limit_backward:
            return False
        self.cursor = self.limit - v_1
        v_2 = self.limit - self.cursor
        try:
            if self.find_among_b(SwedishStemmer.a_0) == 0:
                raise lab0()
            return False
        except lab0: pass
        self.cursor = self.limit - v_2
        return True

    def _stem(self):
        v_1 = self.cursor
        try:
            I_p1 = self.limit
            v_2 = self.cursor
            if self.cursor + 3 > self.limit:
                raise lab0()
            self.cursor += 3
            I_x = self.cursor
            self.cursor = v_2
            if not self.go_out_grouping(SwedishStemmer.g_v):
                raise lab0()
            self.cursor += 1
            if not self.go_in_grouping(SwedishStemmer.g_v):
                raise lab0()
            self.cursor += 1
            I_p1 = self.cursor
            try:
                if I_p1 >= I_x:
                    raise lab1()
                I_p1 = I_x
            except lab1: pass
        except lab0: pass
        self.cursor = v_1
        self.limit_backward = self.cursor
        self.cursor = self.limit
        v_3 = self.limit - self.cursor
        try:
            if self.cursor < I_p1:
                raise lab0()
            v_5 = self.limit_backward
            self.limit_backward = I_p1
            self.ket = self.cursor
            among_var = self.find_among_b(SwedishStemmer.a_1)
            if among_var == 0:
                self.limit_backward = v_5
                raise lab0()
            self.bra = self.cursor
            self.limit_backward = v_5
            if among_var == 1:
                self.slice_del()
            elif among_var == 2:
                while True:
                    v_6 = self.limit - self.cursor
                    try:
                        if not self.eq_s_b("et"):
                            raise lab1()
                        if not self.__r_et_condition():
                            raise lab1()
                        self.bra = self.cursor
                        break
                    except lab1: pass
                    self.cursor = self.limit - v_6
                    if not self.in_grouping_b(SwedishStemmer.g_s_ending):
                        raise lab0()
                    break
                self.slice_del()
            else:
                if not self.__r_et_condition():
                    raise lab0()
                self.slice_del()
        except lab0: pass
        self.cursor = self.limit - v_3
        v_7 = self.limit - self.cursor
        try:
            if self.cursor < I_p1:
                raise lab0()
            v_9 = self.limit_backward
            self.limit_backward = I_p1
            v_10 = self.limit - self.cursor
            if self.find_among_b(SwedishStemmer.a_2) == 0:
                self.limit_backward = v_9
                raise lab0()
            self.cursor = self.limit - v_10
            self.ket = self.cursor
            if self.cursor <= self.limit_backward:
                self.limit_backward = v_9
                raise lab0()
            self.cursor -= 1
            self.bra = self.cursor
            self.slice_del()
            self.limit_backward = v_9
        except lab0: pass
        self.cursor = self.limit - v_7
        v_11 = self.limit - self.cursor
        try:
            if self.cursor < I_p1:
                raise lab0()
            v_13 = self.limit_backward
            self.limit_backward = I_p1
            self.ket = self.cursor
            among_var = self.find_among_b(SwedishStemmer.a_3)
            if among_var == 0:
                self.limit_backward = v_13
                raise lab0()
            self.bra = self.cursor
            self.limit_backward = v_13
            if among_var == 1:
                self.slice_del()
            elif among_var == 2:
                if not self.in_grouping_b(SwedishStemmer.g_ost_ending):
                    raise lab0()
                self.slice_from("ös")
            else:
                self.slice_from("full")
        except lab0: pass
        self.cursor = self.limit - v_11
        self.cursor = self.limit_backward
        return True

    a_0 = [
        Among("fab", -1, -1),
        Among("h", -1, -1),
        Among("pak", -1, -1),
        Among("rak", -1, -1),
        Among("stak", -1, -1),
        Among("kom", -1, -1),
        Among("iet", -1, -1),
        Among("cit", -1, -1),
        Among("dit", -1, -1),
        Among("alit", -1, -1),
        Among("ilit", -1, -1),
        Among("mit", -1, -1),
        Among("nit", -1, -1),
        Among("pit", -1, -1),
        Among("rit", -1, -1),
        Among("sit", -1, -1),
        Among("tit", -1, -1),
        Among("uit", -1, -1),
        Among("ivit", -1, -1),
        Among("kvit", -1, -1),
        Among("xit", -1, -1)
    ]

    a_1 = [
        Among("a", -1, 1),
        Among("arna", 0, 1),
        Among("erna", 0, 1),
        Among("heterna", 2, 1),
        Among("orna", 0, 1),
        Among("ad", -1, 1),
        Among("e", -1, 1),
        Among("ade", 6, 1),
        Among("ande", 6, 1),
        Among("arne", 6, 1),
        Among("are", 6, 1),
        Among("aste", 6, 1),
        Among("en", -1, 1),
        Among("anden", 12, 1),
        Among("aren", 12, 1),
        Among("heten", 12, 1),
        Among("ern", -1, 1),
        Among("ar", -1, 1),
        Among("er", -1, 1),
        Among("heter", 18, 1),
        Among("or", -1, 1),
        Among("s", -1, 2),
        Among("as", 21, 1),
        Among("arnas", 22, 1),
        Among("ernas", 22, 1),
        Among("ornas", 22, 1),
        Among("es", 21, 1),
        Among("ades", 26, 1),
        Among("andes", 26, 1),
        Among("ens", 21, 1),
        Among("arens", 29, 1),
        Among("hetens", 29, 1),
        Among("erns", 21, 1),
        Among("at", -1, 1),
        Among("et", -1, 3),
        Among("andet", 34, 1),
        Among("het", 34, 1),
        Among("ast", -1, 1)
    ]

    a_2 = [
        Among("dd", -1, -1),
        Among("gd", -1, -1),
        Among("nn", -1, -1),
        Among("dt", -1, -1),
        Among("gt", -1, -1),
        Among("kt", -1, -1),
        Among("tt", -1, -1)
    ]

    a_3 = [
        Among("ig", -1, 1),
        Among("lig", 0, 1),
        Among("els", -1, 1),
        Among("fullt", -1, 3),
        Among("öst", -1, 2)
    ]


class lab0(BaseException): pass


class lab1(BaseException): pass
