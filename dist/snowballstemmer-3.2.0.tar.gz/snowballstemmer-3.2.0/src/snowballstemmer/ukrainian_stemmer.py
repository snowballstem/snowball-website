# Generated from ukrainian.sbl by Snowball 3.2.0 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class UkrainianStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from ukrainian.sbl by Snowball 3.2.0 - https://snowballstem.org/
    '''

    g_v = {"а", "е", "и", "о", "у", "ю", "я", "є", "і", "ї"}


    def __r_professional(self):
        self.ket = self.cursor
        among_var = self.find_among_b(UkrainianStemmer.a_8)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if among_var == 1:
            self.slice_del()
        else:
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "к":
                return False
            self.cursor -= 1
            self.slice_del()
        return True

    def _stem(self):
        v_1 = self.cursor
        try:
            self.bra = self.cursor
            if not self.eq_s("най"):
                raise lab0()
            self.ket = self.cursor
            if self.cursor >= self.limit:
                raise lab0()
            self.slice_del()
        except lab0: pass
        self.cursor = v_1
        while True:
            v_2 = self.cursor
            try:
                v_3 = self.cursor
                if not self.eq_s("окремо"):
                    raise lab0()
                if self.cursor < self.limit:
                    raise lab0()
                self.cursor = v_3
                self.limit_backward = self.cursor
                self.cursor = self.limit
                self.ket = self.cursor
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "о":
                    raise lab0()
                self.cursor -= 1
                self.bra = self.cursor
                self.slice_del()
                self.cursor = self.limit_backward
                break
            except lab0: pass
            self.cursor = v_2
            try:
                self.bra = self.cursor
                among_var = self.find_among(UkrainianStemmer.a_15)
                if among_var == 0:
                    raise lab0()
                self.ket = self.cursor
                if self.cursor < self.limit:
                    raise lab0()
                if among_var > 0:
                    self.slice_from(UkrainianStemmer.as_15[among_var - 1])
                break
            except lab0: pass
            self.cursor = v_2
            v_4 = self.cursor
            try:
                self.limit_backward = self.cursor
                self.cursor = self.limit
                self.ket = self.cursor
                among_var = self.find_among_b(UkrainianStemmer.a_16)
                if among_var == 0:
                    raise lab0()
                self.bra = self.cursor
                if among_var == 1:
                    self.slice_from("ход")
                elif among_var == 2:
                    self.slice_from("бор")
                elif among_var == 3:
                    self.slice_from("рост")
                elif among_var == 4:
                    self.slice_from("ноч")
                elif among_var == 5:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("дом")
                elif among_var == 6:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("стол")
                elif among_var == 7:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("печ")
                elif among_var == 8:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("сол")
                elif among_var == 9:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("кон")
                elif among_var == 10:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("гост")
                elif among_var == 11:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("плод")
                elif among_var == 12:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("род")
                elif among_var == 13:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("бок")
                elif among_var == 14:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("кот")
                elif among_var == 15:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("рог")
                else:
                    if self.cursor > self.limit_backward:
                        raise lab0()
                    self.slice_from("сок")
                self.cursor = self.limit_backward
            except lab0: pass
            self.cursor = v_4
            B_found_la_noun = False
            B_found_ty_noun = False
            v_5 = self.cursor
            try:
                self.limit_backward = self.cursor
                self.cursor = self.limit
                v_6 = self.limit - self.cursor
                try:
                    if self.find_among_b(UkrainianStemmer.a_17) == 0:
                        self.cursor = self.limit - v_6
                        raise lab1()
                except lab1: pass
                while True:
                    v_7 = self.limit - self.cursor
                    try:
                        while True:
                            try:
                                if not self.eq_s_b("ла"):
                                    raise lab2()
                                break
                            except lab2: pass
                            try:
                                if not self.eq_s_b("ли"):
                                    raise lab2()
                                break
                            except lab2: pass
                            if not self.eq_s_b("ло"):
                                raise lab1()
                            break
                        while True:
                            v_8 = self.limit - self.cursor
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "о":
                                    raise lab2()
                                self.cursor -= 1
                                try:
                                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "р":
                                        raise lab3()
                                    self.cursor -= 1
                                    raise lab2()
                                except lab3: pass
                                break
                            except lab2: pass
                            self.cursor = self.limit - v_8
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "л":
                                    raise lab2()
                                self.cursor -= 1
                                break
                            except lab2: pass
                            self.cursor = self.limit - v_8
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "т":
                                    raise lab2()
                                self.cursor -= 1
                                v_9 = self.limit - self.cursor
                                try:
                                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "с":
                                        raise lab3()
                                    self.cursor -= 1
                                    if self.cursor > self.limit_backward:
                                        raise lab3()
                                    raise lab2()
                                except lab3: pass
                                self.cursor = self.limit - v_9
                                break
                            except lab2: pass
                            self.cursor = self.limit - v_8
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "д":
                                    raise lab2()
                                self.cursor -= 1
                                break
                            except lab2: pass
                            self.cursor = self.limit - v_8
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "в":
                                    raise lab2()
                                self.cursor -= 1
                                break
                            except lab2: pass
                            self.cursor = self.limit - v_8
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "й":
                                    raise lab2()
                                self.cursor -= 1
                                break
                            except lab2: pass
                            self.cursor = self.limit - v_8
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "б":
                                    raise lab2()
                                self.cursor -= 1
                                break
                            except lab2: pass
                            self.cursor = self.limit - v_8
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "п":
                                    raise lab2()
                                self.cursor -= 1
                                break
                            except lab2: pass
                            self.cursor = self.limit - v_8
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "р":
                                    raise lab2()
                                self.cursor -= 1
                                break
                            except lab2: pass
                            self.cursor = self.limit - v_8
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "е":
                                raise lab1()
                            self.cursor -= 1
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "в":
                                    raise lab2()
                                self.cursor -= 1
                                raise lab1()
                            except lab2: pass
                            break
                        B_found_la_noun = True
                        break
                    except lab1: pass
                    self.cursor = self.limit - v_7
                    if not self.eq_s_b("ти"):
                        raise lab0()
                    while True:
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "н":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "е":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "о":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if not self.eq_s_b("іс"):
                                raise lab1()
                            break
                        except lab1: pass
                        try:
                            if not self.eq_s_b("ис"):
                                raise lab1()
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "к":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "р":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ш":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ф":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "х":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "п":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "б":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "в":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "л":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "м":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "т":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ь":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ю":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "є":
                            raise lab0()
                        self.cursor -= 1
                        break
                    B_found_ty_noun = True
                    break
                self.cursor = self.limit_backward
            except lab0: pass
            self.cursor = v_5
            B_found_diminutive = False
            B_found_professional = False
            B_found_ia = False
            B_found_verb = False
            I_pV = self.limit
            I_p2 = self.limit
            v_10 = self.cursor
            try:
                if not self.go_out_grouping(UkrainianStemmer.g_v):
                    raise lab0()
                self.cursor += 1
                I_pV = self.cursor
                if not self.go_in_grouping(UkrainianStemmer.g_v):
                    raise lab0()
                self.cursor += 1
                if not self.go_out_grouping(UkrainianStemmer.g_v):
                    raise lab0()
                self.cursor += 1
                if not self.go_in_grouping(UkrainianStemmer.g_v):
                    raise lab0()
                self.cursor += 1
                I_p2 = self.cursor
            except lab0: pass
            self.cursor = v_10
            v_11 = self.cursor
            if self.cursor + 3 > self.limit:
                return False
            self.cursor += 3
            try:
                if I_pV >= self.cursor:
                    raise lab0()
                I_pV = self.cursor
            except lab0: pass
            self.cursor = v_11
            self.limit_backward = self.cursor
            self.cursor = self.limit
            if self.cursor < I_pV:
                return False
            v_13 = self.limit_backward
            self.limit_backward = I_pV
            v_14 = self.limit - self.cursor
            try:
                while True:
                    v_15 = self.limit - self.cursor
                    try:
                        self.ket = self.cursor
                        among_var = self.find_among_b(UkrainianStemmer.a_0)
                        if among_var == 0:
                            raise lab1()
                        self.bra = self.cursor
                        if among_var == 1:
                            while True:
                                try:
                                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "а":
                                        raise lab2()
                                    self.cursor -= 1
                                    break
                                except lab2: pass
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "я":
                                    raise lab1()
                                self.cursor -= 1
                                break
                            self.slice_del()
                        elif among_var == 2:
                            self.slice_del()
                        elif among_var == 3:
                            B_found_verb = True
                            self.slice_del()
                        elif among_var == 4:
                            B_found_verb = True
                            self.slice_from("ув")
                        else:
                            B_found_verb = True
                            self.slice_from("юв")
                        break
                    except lab1: pass
                    self.cursor = self.limit - v_15
                    try:
                        self.ket = self.cursor
                        among_var = self.find_among_b(UkrainianStemmer.a_1)
                        if among_var == 0:
                            raise lab1()
                        self.bra = self.cursor
                        self.slice_from(UkrainianStemmer.as_1[among_var - 1])
                        B_found_verb = True
                        break
                    except lab1: pass
                    self.cursor = self.limit - v_15
                    v_16 = self.limit - self.cursor
                    try:
                        self.ket = self.cursor
                        if self.find_among_b(UkrainianStemmer.a_2) == 0:
                            self.cursor = self.limit - v_16
                            raise lab1()
                        self.bra = self.cursor
                        self.slice_del()
                        B_found_verb = True
                    except lab1: pass
                    while True:
                        v_17 = self.limit - self.cursor
                        try:
                            while True:
                                v_18 = self.limit - self.cursor
                                try:
                                    if self.cursor < I_p2:
                                        raise lab2()
                                    v_20 = self.limit_backward
                                    self.limit_backward = I_p2
                                    self.ket = self.cursor
                                    if self.find_among_b(UkrainianStemmer.a_11) == 0:
                                        self.limit_backward = v_20
                                        raise lab2()
                                    self.bra = self.cursor
                                    self.limit_backward = v_20
                                    B_found_ia = True
                                    B_found_verb = True
                                    self.slice_del()
                                    break
                                except lab2: pass
                                self.cursor = self.limit - v_18
                                self.ket = self.cursor
                                if self.find_among_b(UkrainianStemmer.a_12) == 0:
                                    raise lab1()
                                self.bra = self.cursor
                                B_found_ia = True
                                B_found_verb = True
                                self.slice_del()
                                break
                            break
                        except lab1: pass
                        self.cursor = self.limit - v_17
                        v_21 = self.limit - self.cursor
                        try:
                            while True:
                                v_22 = self.limit - self.cursor
                                try:
                                    if not self.__r_professional():
                                        raise lab2()
                                    B_found_professional = True
                                    break
                                except lab2: pass
                                self.cursor = self.limit - v_22
                                self.ket = self.cursor
                                among_var = self.find_among_b(UkrainianStemmer.a_9)
                                if among_var == 0:
                                    raise lab1()
                                self.bra = self.cursor
                                self.slice_from(UkrainianStemmer.as_9[among_var - 1])
                                B_found_diminutive = True
                                break
                        except lab1: pass
                        self.cursor = self.limit - v_21
                        if B_found_professional:
                            raise lab0()
                        while True:
                            v_23 = self.limit - self.cursor
                            try:
                                while True:
                                    v_24 = self.limit - self.cursor
                                    try:
                                        self.ket = self.cursor
                                        if self.find_among_b(UkrainianStemmer.a_3) == 0:
                                            raise lab2()
                                        self.bra = self.cursor
                                        if I_p2 > self.cursor:
                                            raise lab2()
                                        B_found_ia = True
                                        self.slice_del()
                                        break
                                    except lab2: pass
                                    self.cursor = self.limit - v_24
                                    self.ket = self.cursor
                                    among_var = self.find_among_b(UkrainianStemmer.a_4)
                                    if among_var == 0:
                                        raise lab1()
                                    self.bra = self.cursor
                                    if among_var == 1:
                                        self.slice_del()
                                    else:
                                        while True:
                                            try:
                                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ж":
                                                    raise lab2()
                                                self.cursor -= 1
                                                break
                                            except lab2: pass
                                            try:
                                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ч":
                                                    raise lab2()
                                                self.cursor -= 1
                                                break
                                            except lab2: pass
                                            try:
                                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ш":
                                                    raise lab2()
                                                self.cursor -= 1
                                                break
                                            except lab2: pass
                                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "щ":
                                                raise lab1()
                                            self.cursor -= 1
                                            break
                                        self.slice_del()
                                    break
                                break
                            except lab1: pass
                            self.cursor = self.limit - v_23
                            try:
                                while True:
                                    v_25 = self.limit - self.cursor
                                    try:
                                        self.ket = self.cursor
                                        if not self.eq_s_b("остей"):
                                            raise lab2()
                                        self.bra = self.cursor
                                        if self.cursor <= self.limit_backward:
                                            raise lab2()
                                        self.slice_del()
                                        break
                                    except lab2: pass
                                    self.cursor = self.limit - v_25
                                    self.ket = self.cursor
                                    among_var = self.find_among_b(UkrainianStemmer.a_5)
                                    if among_var == 0:
                                        raise lab1()
                                    self.bra = self.cursor
                                    if among_var == 1:
                                        B_found_ia = True
                                        self.slice_del()
                                    elif among_var == 2:
                                        B_found_ia = True
                                        while True:
                                            v_26 = self.limit - self.cursor
                                            try:
                                                while True:
                                                    try:
                                                        if self.cursor > self.limit_backward:
                                                            raise lab3()
                                                        break
                                                    except lab3: pass
                                                    try:
                                                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "т":
                                                            raise lab3()
                                                        self.cursor -= 1
                                                        break
                                                    except lab3: pass
                                                    try:
                                                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ч":
                                                            raise lab3()
                                                        self.cursor -= 1
                                                        break
                                                    except lab3: pass
                                                    try:
                                                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ш":
                                                            raise lab3()
                                                        self.cursor -= 1
                                                        break
                                                    except lab3: pass
                                                    try:
                                                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "щ":
                                                            raise lab3()
                                                        self.cursor -= 1
                                                        break
                                                    except lab3: pass
                                                    try:
                                                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "м":
                                                            raise lab3()
                                                        self.cursor -= 1
                                                        break
                                                    except lab3: pass
                                                    try:
                                                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "н":
                                                            raise lab3()
                                                        self.cursor -= 1
                                                        break
                                                    except lab3: pass
                                                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "л":
                                                        raise lab2()
                                                    self.cursor -= 1
                                                    break
                                                self.slice_del()
                                                break
                                            except lab2: pass
                                            self.cursor = self.limit - v_26
                                            self.slice_from("е")
                                            break
                                    elif among_var == 3:
                                        self.slice_del()
                                    elif among_var == 4:
                                        try:
                                            if not self.in_grouping_b(UkrainianStemmer.g_v):
                                                raise lab2()
                                            raise lab1()
                                        except lab2: pass
                                        B_found_ia = True
                                        self.slice_del()
                                    elif among_var == 5:
                                        v_27 = self.limit - self.cursor
                                        try:
                                            while True:
                                                try:
                                                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "с":
                                                        raise lab3()
                                                    self.cursor -= 1
                                                    break
                                                except lab3: pass
                                                try:
                                                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "ц":
                                                        raise lab3()
                                                    self.cursor -= 1
                                                    break
                                                except lab3: pass
                                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "'":
                                                    raise lab2()
                                                self.cursor -= 1
                                                break
                                            raise lab1()
                                        except lab2: pass
                                        self.cursor = self.limit - v_27
                                        B_found_ia = True
                                        self.slice_del()
                                    elif among_var == 6:
                                        self.slice_from("ув")
                                    elif among_var == 7:
                                        self.slice_from("юв")
                                    elif among_var == 8:
                                        try:
                                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "о":
                                                raise lab2()
                                            self.cursor -= 1
                                            raise lab1()
                                        except lab2: pass
                                        while True:
                                            try:
                                                if self.cursor > self.limit_backward:
                                                    raise lab2()
                                                break
                                            except lab2: pass
                                            if not self.in_grouping_b(UkrainianStemmer.g_v):
                                                raise lab1()
                                            break
                                        self.slice_del()
                                    elif among_var == 9:
                                        v_28 = self.limit - self.cursor
                                        try:
                                            while True:
                                                try:
                                                    if not self.eq_s_b("ств"):
                                                        raise lab3()
                                                    break
                                                except lab3: pass
                                                if not self.eq_s_b("цтв"):
                                                    raise lab2()
                                                break
                                            raise lab1()
                                        except lab2: pass
                                        self.cursor = self.limit - v_28
                                        self.slice_del()
                                    elif among_var == 10:
                                        if B_found_la_noun:
                                            raise lab1()
                                        self.slice_del()
                                    elif among_var == 11:
                                        try:
                                            if not self.eq_s_b("іст"):
                                                raise lab2()
                                            raise lab1()
                                        except lab2: pass
                                        self.slice_del()
                                    else:
                                        if B_found_ty_noun:
                                            raise lab1()
                                        self.slice_del()
                                    break
                                B_found_verb = True
                                break
                            except lab1: pass
                            self.cursor = self.limit - v_23
                            while True:
                                v_29 = self.limit - self.cursor
                                try:
                                    self.ket = self.cursor
                                    if self.find_among_b(UkrainianStemmer.a_6) == 0:
                                        raise lab1()
                                    self.bra = self.cursor
                                    if self.cursor <= self.limit_backward:
                                        raise lab1()
                                    self.slice_del()
                                    break
                                except lab1: pass
                                self.cursor = self.limit - v_29
                                self.ket = self.cursor
                                among_var = self.find_among_b(UkrainianStemmer.a_7)
                                if among_var == 0:
                                    raise lab0()
                                self.bra = self.cursor
                                self.slice_from(UkrainianStemmer.as_7[among_var - 1])
                                break
                            break
                        break
                    break
            except lab0: pass
            self.cursor = self.limit - v_14
            v_30 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                if self.find_among_b(UkrainianStemmer.a_10) == 0:
                    self.cursor = self.limit - v_30
                    raise lab0()
                self.bra = self.cursor
                self.slice_del()
                B_found_diminutive = True
            except lab0: pass
            v_31 = self.limit - self.cursor
            try:
                if B_found_diminutive:
                    raise lab0()
                if B_found_professional:
                    raise lab0()
                if B_found_ia:
                    raise lab0()
                if not self.__r_professional():
                    raise lab0()
            except lab0: pass
            self.cursor = self.limit - v_31
            v_32 = self.limit - self.cursor
            try:
                if B_found_verb:
                    raise lab0()
                self.ket = self.cursor
                if not self.eq_s_b("іш"):
                    raise lab0()
                self.bra = self.cursor
                self.slice_del()
            except lab0: pass
            self.cursor = self.limit - v_32
            v_33 = self.limit - self.cursor
            try:
                if self.cursor < I_p2:
                    raise lab0()
                v_35 = self.limit_backward
                self.limit_backward = I_p2
                self.ket = self.cursor
                among_var = self.find_among_b(UkrainianStemmer.a_13)
                if among_var == 0:
                    self.limit_backward = v_35
                    raise lab0()
                self.bra = self.cursor
                self.limit_backward = v_35
                if among_var == 1:
                    self.slice_del()
                elif among_var == 2:
                    while True:
                        v_36 = self.limit - self.cursor
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "в":
                                raise lab1()
                            self.cursor -= 1
                            self.slice_del()
                            break
                        except lab1: pass
                        self.cursor = self.limit - v_36
                        self.slice_from("ел")
                        break
                elif among_var == 3:
                    while True:
                        v_37 = self.limit - self.cursor
                        try:
                            while True:
                                try:
                                    if not self.eq_s_b("ув"):
                                        raise lab2()
                                    break
                                except lab2: pass
                                if not self.eq_s_b("юв"):
                                    raise lab1()
                                break
                            self.slice_del()
                            break
                        except lab1: pass
                        self.cursor = self.limit - v_37
                        self.slice_from("ал")
                        break
                else:
                    while True:
                        try:
                            if not self.eq_s_b("ув"):
                                raise lab1()
                            break
                        except lab1: pass
                        if not self.eq_s_b("юв"):
                            raise lab0()
                        break
                    self.slice_del()
            except lab0: pass
            self.cursor = self.limit - v_33
            v_38 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                among_var = self.find_among_b(UkrainianStemmer.a_14)
                if among_var == 0:
                    raise lab0()
                self.bra = self.cursor
                if among_var == 1:
                    if B_found_verb:
                        raise lab0()
                    self.slice_del()
                    self.ket = self.cursor
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "н":
                        raise lab0()
                    self.cursor -= 1
                    self.bra = self.cursor
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "н":
                        raise lab0()
                    self.cursor -= 1
                    self.slice_del()
                elif among_var == 2:
                    while True:
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "б":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "п":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "в":
                                raise lab1()
                            self.cursor -= 1
                            break
                        except lab1: pass
                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "м":
                            raise lab0()
                        self.cursor -= 1
                        break
                    self.slice_del()
                elif among_var == 3:
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "н":
                        raise lab0()
                    self.cursor -= 1
                    self.slice_del()
                else:
                    self.slice_del()
            except lab0: pass
            self.cursor = self.limit - v_38
            self.limit_backward = v_13
            self.cursor = self.limit_backward
            break
        return True

    a_0 = [
        Among("ачи", -1, 3),
        Among("учи", -1, 3),
        Among("аючи", -1, 3),
        Among("уючи", -1, 4),
        Among("юючи", -1, 5),
        Among("яючи", -1, 3),
        Among("іючи", -1, 3),
        Among("ячи", -1, 3),
        Among("вши", -1, 1),
        Among("ивши", 8, 2),
        Among("вшись", -1, 1),
        Among("ившись", 10, 2)
    ]

    a_1 = [
        Among("еться", -1, 1),
        Among("иться", -1, 1),
        Among("аються", -1, 1),
        Among("уються", -1, 2),
        Among("юються", -1, 3),
        Among("яються", -1, 1),
        Among("ється", -1, 1),
        Among("ається", 6, 1),
        Among("ується", 6, 2),
        Among("юється", 6, 3),
        Among("яється", 6, 1)
    ]
    as_1 = ("", "ув", "юв")

    a_2 = [
        Among("сь", -1, 1),
        Among("лась", 0, 1),
        Among("всь", 0, 1),
        Among("тись", 0, 1),
        Among("ся", -1, 1),
        Among("вся", 4, 1),
        Among("тися", 4, 1)
    ]

    a_3 = [
        Among("ійна", -1, 1),
        Among("аційна", 0, 1),
        Among("ична", -1, 1),
        Among("ічна", -1, 1),
        Among("уальна", -1, 1),
        Among("іа", -1, 1),
        Among("ійне", -1, 1),
        Among("аційне", 6, 1),
        Among("ичне", -1, 1),
        Among("ічне", -1, 1),
        Among("уальне", -1, 1),
        Among("ійними", -1, 1),
        Among("аційними", 11, 1),
        Among("ичними", -1, 1),
        Among("ічними", -1, 1),
        Among("уальними", -1, 1),
        Among("іями", -1, 1),
        Among("аціями", 16, 1),
        Among("ичностей", -1, 1),
        Among("уальностей", -1, 1),
        Among("ійний", -1, 1),
        Among("аційний", 20, 1),
        Among("ичний", -1, 1),
        Among("ічний", -1, 1),
        Among("уальний", -1, 1),
        Among("ій", -1, 1),
        Among("ійній", 25, 1),
        Among("аційній", 26, 1),
        Among("ичній", 25, 1),
        Among("ічній", 25, 1),
        Among("уальній", 25, 1),
        Among("ацій", 25, 1),
        Among("ійним", -1, 1),
        Among("аційним", 32, 1),
        Among("ичним", -1, 1),
        Among("ічним", -1, 1),
        Among("уальним", -1, 1),
        Among("іям", -1, 1),
        Among("аціям", 37, 1),
        Among("ієм", -1, 1),
        Among("ійного", -1, 1),
        Among("аційного", 40, 1),
        Among("ичного", -1, 1),
        Among("ічного", -1, 1),
        Among("уального", -1, 1),
        Among("ійно", -1, 1),
        Among("аційно", 45, 1),
        Among("ично", -1, 1),
        Among("ічно", -1, 1),
        Among("уально", -1, 1),
        Among("ійному", -1, 1),
        Among("аційному", 50, 1),
        Among("ичному", -1, 1),
        Among("ічному", -1, 1),
        Among("уальному", -1, 1),
        Among("ійну", -1, 1),
        Among("аційну", 55, 1),
        Among("ичну", -1, 1),
        Among("ічну", -1, 1),
        Among("уальну", -1, 1),
        Among("ійних", -1, 1),
        Among("аційних", 60, 1),
        Among("ичних", -1, 1),
        Among("ічних", -1, 1),
        Among("уальних", -1, 1),
        Among("іях", -1, 1),
        Among("аціях", 65, 1),
        Among("ійність", -1, 1),
        Among("аційність", 67, 1),
        Among("ичність", -1, 1),
        Among("ічність", -1, 1),
        Among("уальність", -1, 1),
        Among("ійною", -1, 1),
        Among("аційною", 72, 1),
        Among("ичною", -1, 1),
        Among("ічною", -1, 1),
        Among("уальною", -1, 1),
        Among("ійністю", -1, 1),
        Among("аційністю", 77, 1),
        Among("ичністю", -1, 1),
        Among("ічністю", -1, 1),
        Among("уальністю", -1, 1),
        Among("ією", -1, 1),
        Among("ацією", 82, 1),
        Among("ію", -1, 1),
        Among("ацію", 84, 1),
        Among("ія", -1, 1),
        Among("ація", 86, 1),
        Among("ійні", -1, 1),
        Among("аційні", 88, 1),
        Among("ичні", -1, 1),
        Among("ічні", -1, 1),
        Among("уальні", -1, 1),
        Among("ійності", -1, 1),
        Among("аційності", 93, 1),
        Among("ичності", -1, 1),
        Among("ічності", -1, 1),
        Among("уальності", -1, 1),
        Among("ійної", -1, 1),
        Among("аційної", 98, 1),
        Among("ичної", -1, 1),
        Among("ічної", -1, 1),
        Among("уальної", -1, 1),
        Among("ії", -1, 1),
        Among("ації", 103, 1)
    ]

    a_4 = [
        Among("ована", -1, 1),
        Among("увана", -1, 1),
        Among("уча", -1, 1),
        Among("юча", -1, 1),
        Among("оване", -1, 1),
        Among("уване", -1, 1),
        Among("уче", -1, 1),
        Among("юче", -1, 1),
        Among("ими", -1, 1),
        Among("іми", -1, 1),
        Among("їми", -1, 1),
        Among("ий", -1, 1),
        Among("ований", 11, 1),
        Among("уваний", 11, 1),
        Among("учий", 11, 1),
        Among("ючий", 11, 1),
        Among("ій", -1, 1),
        Among("им", -1, 1),
        Among("ім", -1, 1),
        Among("їм", -1, 1),
        Among("ого", -1, 1),
        Among("ього", 20, 1),
        Among("овано", -1, 1),
        Among("увано", -1, 1),
        Among("ому", -1, 1),
        Among("ьому", 24, 1),
        Among("ішу", -1, 1),
        Among("их", -1, 1),
        Among("іх", -1, 1),
        Among("їх", -1, 1),
        Among("ею", -1, 2),
        Among("ою", -1, 1),
        Among("ьою", 31, 1),
        Among("єю", -1, 1),
        Among("овані", -1, 1),
        Among("увані", -1, 1),
        Among("учі", -1, 1),
        Among("ючі", -1, 1),
        Among("ої", -1, 1),
        Among("ьої", 38, 1)
    ]

    a_5 = [
        Among("ла", -1, 10),
        Among("ала", 0, 4),
        Among("ила", 0, 1),
        Among("яла", 0, 1),
        Among("іла", 0, 1),
        Among("в", -1, 8),
        Among("ав", 5, 3),
        Among("ив", 5, 3),
        Among("яв", 5, 1),
        Among("ів", 5, 3),
        Among("атиме", -1, 1),
        Among("итиме", -1, 1),
        Among("ятиме", -1, 1),
        Among("ітиме", -1, 1),
        Among("ете", -1, 1),
        Among("ите", -1, 1),
        Among("йте", -1, 1),
        Among("єте", -1, 1),
        Among("аєте", 17, 1),
        Among("уєте", 17, 6),
        Among("юєте", 17, 7),
        Among("яєте", 17, 1),
        Among("іте", -1, 1),
        Among("ли", -1, 10),
        Among("али", 23, 4),
        Among("или", 23, 1),
        Among("яли", 23, 1),
        Among("іли", 23, 1),
        Among("ти", -1, 12),
        Among("ати", 28, 1),
        Among("ити", 28, 1),
        Among("яти", 28, 5),
        Among("іти", 28, 1),
        Among("й", -1, 1),
        Among("ей", 33, 2),
        Among("єм", -1, 1),
        Among("ло", -1, 10),
        Among("ало", 36, 4),
        Among("ило", 36, 1),
        Among("яло", 36, 1),
        Among("іло", 36, 1),
        Among("емо", -1, 1),
        Among("атимемо", 41, 1),
        Among("имо", -1, 1),
        Among("ємо", -1, 1),
        Among("аємо", 44, 1),
        Among("уємо", 44, 6),
        Among("юємо", 44, 7),
        Among("яємо", 44, 1),
        Among("імо", -1, 1),
        Among("у", -1, 9),
        Among("атиму", 50, 1),
        Among("итиму", 50, 1),
        Among("еш", -1, 1),
        Among("иш", -1, 1),
        Among("єш", -1, 1),
        Among("аєш", 55, 1),
        Among("уєш", 55, 6),
        Among("юєш", 55, 7),
        Among("яєш", 55, 1),
        Among("ить", -1, 1),
        Among("уть", -1, 1),
        Among("атимуть", 61, 1),
        Among("итимуть", 61, 1),
        Among("ятимуть", 61, 1),
        Among("ють", -1, 1),
        Among("ають", 65, 1),
        Among("ують", 65, 6),
        Among("юють", 65, 7),
        Among("яють", 65, 1),
        Among("ять", -1, 5),
        Among("їть", -1, 1),
        Among("ю", -1, 11),
        Among("аю", 72, 1),
        Among("є", -1, 1),
        Among("ає", 74, 1),
        Among("ує", 74, 6),
        Among("ює", 74, 7),
        Among("яє", 74, 1)
    ]

    a_6 = [
        Among("ість", -1, 1),
        Among("істю", -1, 1),
        Among("ості", -1, 1),
        Among("істі", -1, 1)
    ]

    a_7 = [
        Among("а", -1, 3),
        Among("ства", 0, 3),
        Among("цтва", 0, 2),
        Among("ств", -1, 3),
        Among("цтв", -1, 2),
        Among("е", -1, 3),
        Among("и", -1, 3),
        Among("ами", 6, 3),
        Among("ствами", 7, 3),
        Among("цтвами", 7, 2),
        Among("ями", 6, 3),
        Among("ам", -1, 3),
        Among("ствам", 11, 3),
        Among("цтвам", 11, 2),
        Among("ем", -1, 3),
        Among("ом", -1, 3),
        Among("ством", 15, 3),
        Among("цтвом", 15, 2),
        Among("ям", -1, 3),
        Among("о", -1, 3),
        Among("тво", 19, 3),
        Among("ство", 20, 3),
        Among("ству", -1, 3),
        Among("цтву", -1, 2),
        Among("ах", -1, 3),
        Among("ствах", 24, 3),
        Among("цтвах", 24, 2),
        Among("ях", -1, 3),
        Among("ець", -1, 2),
        Among("істю", -1, 1),
        Among("я", -1, 3),
        Among("і", -1, 3),
        Among("еві", 31, 3),
        Among("ові", 31, 3),
        Among("стві", 31, 3),
        Among("цтві", 31, 2),
        Among("ї", -1, 3)
    ]
    as_7 = ("ість", "ц", "")

    a_8 = [
        Among("ник", -1, 1),
        Among("івник", 0, 1),
        Among("альник", 0, 1),
        Among("ельник", 0, 1),
        Among("ар", -1, 2),
        Among("яр", -1, 1),
        Among("ач", -1, 1)
    ]

    a_9 = [
        Among("ечка", -1, 1),
        Among("очечка", 0, 1),
        Among("очка", -1, 1),
        Among("ічка", -1, 1),
        Among("енька", -1, 1),
        Among("есенька", 4, 1),
        Among("онька", -1, 1),
        Among("інька", -1, 1),
        Among("юсінька", 7, 1),
        Among("ісінька", 7, 1),
        Among("ечки", -1, 1),
        Among("очечки", 10, 1),
        Among("очки", -1, 1),
        Among("ічки", -1, 1),
        Among("еньки", -1, 1),
        Among("есеньки", 14, 1),
        Among("оньки", -1, 1),
        Among("іньки", -1, 1),
        Among("юсіньки", 17, 1),
        Among("ісіньки", 17, 1),
        Among("ок", -1, 2),
        Among("ечок", 20, 1),
        Among("очечок", 21, 1),
        Among("очок", 20, 1),
        Among("ічок", 20, 1),
        Among("атко", -1, 1),
        Among("ятко", -1, 1),
        Among("ітко", -1, 1),
        Among("ечко", -1, 1),
        Among("очечко", 28, 1),
        Among("очко", -1, 1),
        Among("ічко", -1, 1),
        Among("енько", -1, 1),
        Among("есенько", 32, 1),
        Among("онько", -1, 1),
        Among("інько", -1, 1),
        Among("юсінько", 35, 1),
        Among("ісінько", 35, 1),
        Among("еньку", -1, 1),
        Among("унь", -1, 1),
        Among("ечкі", -1, 1),
        Among("очечкі", 40, 1),
        Among("очкі", -1, 1),
        Among("ічкі", -1, 1),
        Among("енькі", -1, 1),
        Among("есенькі", 44, 1),
        Among("онькі", -1, 1),
        Among("інькі", -1, 1),
        Among("юсінькі", 47, 1),
        Among("ісінькі", 47, 1)
    ]
    as_9 = ("", "к")

    a_10 = [
        Among("еньк", -1, 1),
        Among("есеньк", 0, 1),
        Among("оньк", -1, 1),
        Among("іньк", -1, 1),
        Among("юсіньк", 3, 1),
        Among("ісіньк", 3, 1)
    ]

    a_11 = [
        Among("іннями", -1, 1),
        Among("інням", -1, 1),
        Among("іннях", -1, 1),
        Among("інь", -1, 1),
        Among("інню", -1, 1),
        Among("іння", -1, 1),
        Among("інні", -1, 1)
    ]

    a_12 = [
        Among("аннями", -1, 1),
        Among("еннями", -1, 1),
        Among("яннями", -1, 1),
        Among("анням", -1, 1),
        Among("енням", -1, 1),
        Among("янням", -1, 1),
        Among("аннях", -1, 1),
        Among("еннях", -1, 1),
        Among("яннях", -1, 1),
        Among("ань", -1, 1),
        Among("ень", -1, 1),
        Among("янь", -1, 1),
        Among("анню", -1, 1),
        Among("енню", -1, 1),
        Among("янню", -1, 1),
        Among("ання", -1, 1),
        Among("ення", -1, 1),
        Among("яння", -1, 1),
        Among("анні", -1, 1),
        Among("енні", -1, 1),
        Among("янні", -1, 1)
    ]

    a_13 = [
        Among("ов", -1, 1),
        Among("ув", -1, 1),
        Among("овув", 1, 1),
        Among("юв", -1, 1),
        Among("зьк", -1, 1),
        Among("ськ", -1, 1),
        Among("ізм", -1, 1),
        Among("ан", -1, 4),
        Among("ован", 7, 1),
        Among("уван", 7, 1),
        Among("юван", 7, 1),
        Among("івн", -1, 1),
        Among("ьн", -1, 1),
        Among("альн", 12, 3),
        Among("ельн", 12, 2),
        Among("ян", -1, 1),
        Among("уват", -1, 1),
        Among("іст", -1, 1),
        Among("ищ", -1, 1)
    ]

    a_14 = [
        Among("л", -1, 2),
        Among("н", -1, 3),
        Among("іш", -1, 1),
        Among("ь", -1, 4)
    ]

    a_15 = [
        Among("агрегати", -1, 96),
        Among("агроном", -1, 49),
        Among("адмірала", -1, 17),
        Among("аеродром", -1, 46),
        Among("аеродрому", 3, 46),
        Among("альбом", -1, 39),
        Among("альбому", 5, 39),
        Among("америці", -1, 188),
        Among("амстердам", -1, 60),
        Among("апарати", -1, 79),
        Among("артем", -1, 57),
        Among("архів", -1, -1),
        Among("астрахань", -1, 155),
        Among("астроном", -1, 48),
        Among("африці", -1, 191),
        Among("барабанні", -1, 182),
        Among("березань", -1, 154),
        Among("березень", -1, 123),
        Among("бориспіль", -1, 153),
        Among("ботошань", -1, 156),
        Among("бретань", -1, 166),
        Among("бруней", -1, 112),
        Among("будівель", -1, 144),
        Among("бібліотеці", -1, 194),
        Among("біля", -1, -1),
        Among("в'єтнам", -1, 59),
        Among("вадим", -1, 56),
        Among("вазі", -1, 200),
        Among("вартостей", -1, 1),
        Among("вартості", -1, 1),
        Among("вартість", -1, 1),
        Among("вартістю", -1, 1),
        Among("вдерлися", -1, 37),
        Among("вересень", -1, 129),
        Among("верств", -1, 29),
        Among("верства", 34, 29),
        Among("верстви", 34, 29),
        Among("верствою", 34, 29),
        Among("верству", 34, 29),
        Among("верстві", 34, 29),
        Among("весь", -1, -1),
        Among("вимерла", -1, 36),
        Among("вимерли", -1, 36),
        Among("виплати", -1, 86),
        Among("виставці", -1, 201),
        Among("витрати", -1, 67),
        Among("вплив", -1, -1),
        Among("втекти", -1, 33),
        Among("втрати", -1, 63),
        Among("відання", -1, 177),
        Among("віданні", -1, 177),
        Among("відстанню", -1, 163),
        Among("відстань", -1, 163),
        Among("відтоді", -1, -1),
        Among("вільям", -1, 54),
        Among("віці", -1, 185),
        Among("гавань", -1, 165),
        Among("галілей", -1, 120),
        Among("гармати", -1, 65),
        Among("генерала", -1, 16),
        Among("генерали", -1, 16),
        Among("геном", -1, 41),
        Among("геному", 61, 41),
        Among("голів", -1, 145),
        Among("гонці", -1, 211),
        Among("горбань", -1, 173),
        Among("гранати", -1, 91),
        Among("грудень", -1, 131),
        Among("далі", -1, -1),
        Among("данила", -1, 9),
        Among("данило", -1, 9),
        Among("данилом", 70, 9),
        Among("данилу", -1, 9),
        Among("данилі", -1, 9),
        Among("дев'яти", -1, 139),
        Among("демократи", -1, 94),
        Among("день", -1, 142),
        Among("депутати", -1, 66),
        Among("держав", -1, -1),
        Among("десь", -1, -1),
        Among("десяти", -1, 121),
        Among("десять", -1, 121),
        Among("джованні", -1, 161),
        Among("диплом", -1, 42),
        Among("дисплей", -1, 119),
        Among("дитина", -1, 141),
        Among("дитини", -1, 141),
        Among("дитиною", -1, 141),
        Among("дитину", -1, 141),
        Among("дитині", -1, 141),
        Among("днем", -1, 142),
        Among("дню", -1, 142),
        Among("дня", -1, 142),
        Among("дням", 92, 142),
        Among("днями", 93, 142),
        Among("днях", 92, 142),
        Among("дні", -1, 142),
        Among("днів", 96, 142),
        Among("довгань", -1, 174),
        Among("доменні", -1, 176),
        Among("дорогоцінні", -1, 180),
        Among("дорозі", -1, 196),
        Among("досить", -1, 32),
        Among("досконало", -1, 15),
        Among("досі", -1, -1),
        Among("дотепер", -1, -1),
        Among("дуже", -1, -1),
        Among("ділянці", -1, 197),
        Among("дісней", -1, 111),
        Among("економіці", -1, 219),
        Among("експонати", -1, 87),
        Among("еліти", -1, 81),
        Among("еней", -1, 113),
        Among("жовтень", -1, 130),
        Among("журнали", -1, 23),
        Among("завжди", -1, -1),
        Among("замало", -1, 12),
        Among("замість", -1, -1),
        Among("запити", -1, 93),
        Among("затоці", -1, 205),
        Among("збірці", -1, 222),
        Among("звідки", -1, -1),
        Among("звідси", -1, -1),
        Among("звідти", -1, -1),
        Among("звіти", -1, 82),
        Among("згодом", -1, -1),
        Among("земель", -1, 143),
        Among("знову", -1, -1),
        Among("камінь", -1, 136),
        Among("канали", -1, 22),
        Among("кандидати", -1, 76),
        Among("кардинала", -1, 19),
        Among("квартали", -1, 28),
        Among("квітень", -1, 124),
        Among("кирила", -1, 8),
        Among("кирило", -1, 8),
        Among("кирилом", 135, 8),
        Among("кирилу", -1, 8),
        Among("київ", -1, 4),
        Among("кладці", -1, 218),
        Among("клей", -1, 117),
        Among("книзі", -1, 190),
        Among("кого", -1, -1),
        Among("коли", -1, -1),
        Among("колись", 143, -1),
        Among("кому", -1, -1),
        Among("координати", -1, 74),
        Among("корінь", -1, 137),
        Among("кристала", -1, 26),
        Among("кристали", -1, 26),
        Among("критиці", -1, 224),
        Among("кубань", -1, 167),
        Among("куди", -1, -1),
        Among("кімнати", -1, 71),
        Among("лауреати", -1, 75),
        Among("ледь", -1, -1),
        Among("липень", -1, 127),
        Among("лише", -1, -1),
        Among("лозанні", -1, 162),
        Among("львів", -1, 148),
        Among("людей", -1, 6),
        Among("людина", -1, 6),
        Among("людини", -1, 6),
        Among("людиною", -1, 6),
        Among("людину", -1, 6),
        Among("людині", -1, 6),
        Among("лізі", -1, 187),
        Among("ліцей", -1, 100),
        Among("мавзолей", -1, 118),
        Among("мадам", -1, 53),
        Among("майже", -1, -1),
        Among("максим", -1, 55),
        Among("мало", -1, -1),
        Among("маргарити", -1, 90),
        Among("маршала", -1, 18),
        Among("масив", -1, -1),
        Among("матей", -1, 108),
        Among("матерію", -1, 31),
        Among("матерія", -1, 31),
        Among("матерією", -1, 31),
        Among("матерії", -1, 31),
        Among("мацей", -1, 106),
        Among("мексиці", -1, 202),
        Among("мельник", -1, 30),
        Among("мельника", 183, 30),
        Among("мельники", 183, 30),
        Among("мельником", 183, 30),
        Among("мельнику", 183, 30),
        Among("мельників", 183, 30),
        Among("метали", -1, 27),
        Among("миколаїв", -1, 151),
        Among("могила", -1, 7),
        Among("могили", -1, 7),
        Among("могилою", -1, 7),
        Among("могилу", -1, 7),
        Among("могилі", -1, 7),
        Among("музей", -1, 99),
        Among("музиці", -1, 208),
        Among("мінерали", -1, 25),
        Among("мініальбом", -1, 40),
        Among("мініальбому", 199, 40),
        Among("мішенню", -1, 175),
        Among("мішень", -1, 175),
        Among("напрям", -1, 51),
        Among("напрями", 203, 51),
        Among("науці", -1, 214),
        Among("невдало", -1, 14),
        Among("немало", -1, 13),
        Among("нескінченні", -1, 181),
        Among("нечисленні", -1, 179),
        Among("низці", -1, 217),
        Among("новела", -1, 38),
        Among("новели", -1, 38),
        Among("нічого", -1, -1),
        Among("обкладинці", -1, 226),
        Among("окрузі", -1, 186),
        Among("окрім", -1, -1),
        Among("оплати", -1, 83),
        Among("орбіти", -1, 70),
        Among("орфей", -1, 104),
        Among("освіти", -1, 61),
        Among("останню", -1, 157),
        Among("остання", -1, 157),
        Among("останні", -1, 157),
        Among("осіб", -1, 5),
        Among("осінь", -1, 147),
        Among("п'яти", -1, 138),
        Among("палати", -1, 64),
        Among("плити", -1, 78),
        Among("повноцінні", -1, 184),
        Among("повіти", -1, 92),
        Among("познань", -1, 169),
        Among("поки", -1, -1),
        Among("політиці", -1, 207),
        Among("померла", -1, 35),
        Among("померли", -1, 35),
        Among("померло", -1, 35),
        Among("померти", -1, 35),
        Among("посів", -1, -1),
        Among("потім", -1, -1),
        Among("празі", -1, 203),
        Among("практиці", -1, 198),
        Among("препарати", -1, 80),
        Among("привілей", -1, 116),
        Among("прийом", -1, 43),
        Among("прийому", 244, 43),
        Among("пристань", -1, 168),
        Among("присязі", -1, 195),
        Among("притаманні", -1, 178),
        Among("прометей", -1, 107),
        Among("промінь", -1, 135),
        Among("пророк", -1, 140),
        Among("пророка", 251, 140),
        Among("пророки", 251, 140),
        Among("пророком", 251, 140),
        Among("пророку", 251, 140),
        Among("пророків", 251, 140),
        Among("просвіти", -1, 72),
        Among("проти", -1, -1),
        Among("птолемей", -1, 109),
        Among("південні", -1, 158),
        Among("півфінали", -1, 21),
        Among("підготовці", -1, 210),
        Among("підйом", -1, 44),
        Among("підйому", 263, 44),
        Among("підтримці", -1, 215),
        Among("разом", -1, -1),
        Among("режим", -1, 50),
        Among("режими", 267, 50),
        Among("результати", -1, 62),
        Among("республіці", -1, 192),
        Among("ризі", -1, 227),
        Among("розробці", -1, 204),
        Among("році", -1, 3),
        Among("руці", -1, 221),
        Among("рязань", -1, 170),
        Among("рівень", -1, 132),
        Among("рік", -1, 3),
        Among("річці", -1, 189),
        Among("саме", -1, -1),
        Among("священні", -1, 160),
        Among("світи", -1, 84),
        Among("себе", -1, -1),
        Among("серпень", -1, 128),
        Among("сибір", -1, -1),
        Among("сигнали", -1, 24),
        Among("синдром", -1, 45),
        Among("синдрому", 286, 45),
        Among("смузі", -1, 193),
        Among("совість", -1, 2),
        Among("совістю", -1, 2),
        Among("совісті", -1, 2),
        Among("солдати", -1, 68),
        Among("сплати", -1, 85),
        Among("справ", -1, -1),
        Among("справді", 294, -1),
        Among("статей", -1, 97),
        Among("сторінці", -1, 213),
        Among("страти", -1, 73),
        Among("стрічці", -1, 220),
        Among("ступінь", -1, 134),
        Among("сьогодні", -1, -1),
        Among("сідней", -1, 110),
        Among("сімей", -1, 98),
        Among("січень", -1, 122),
        Among("тадей", -1, 105),
        Among("тайвань", -1, 164),
        Among("тебе", -1, -1),
        Among("тернопіль", -1, 152),
        Among("техніці", -1, 216),
        Among("тоді", -1, -1),
        Among("толстой", -1, 10),
        Among("тому", -1, -1),
        Among("точці", -1, 206),
        Among("травень", -1, 125),
        Among("треба", -1, -1),
        Among("трійці", -1, 212),
        Among("туди", -1, -1),
        Among("увазі", -1, 209),
        Among("увесь", -1, -1),
        Among("утекти", -1, 34),
        Among("учень", -1, 133),
        Among("фабриці", -1, 225),
        Among("формати", -1, 95),
        Among("фортепіанні", -1, 183),
        Among("футболці", -1, 199),
        Among("фінали", -1, 20),
        Among("хайнань", -1, 172),
        Among("харків", -1, 149),
        Among("хокей", -1, 101),
        Among("цитати", -1, 89),
        Among("чемпіонати", -1, 77),
        Among("червень", -1, 126),
        Among("черзі", -1, 223),
        Among("чернігів", -1, 150),
        Among("чимало", -1, 11),
        Among("чому", -1, -1),
        Among("шолом", -1, 47),
        Among("штати", -1, 69),
        Among("щоденні", -1, 159),
        Among("щойно", -1, -1),
        Among("ювілей", -1, 115),
        Among("юньнань", -1, 171),
        Among("євангеліє", -1, 146),
        Among("єврей", -1, 102),
        Among("єрусалим", -1, 58),
        Among("інакше", -1, -1),
        Among("інколи", -1, -1),
        Among("іноді", -1, -1),
        Among("іриней", -1, 114),
        Among("іслам", -1, 52),
        Among("іспити", -1, 88),
        Among("ієрей", -1, 103)
    ]
    as_15 = ("вартост", "совіст", "рок", "києв", "особ", "люд", "могил", "кирил", "данил", "толст", "чимало", "замал", "немал", "невдал", "досконал", "генерал", "адмірал", "маршал", "кардинал", "фінал", "півфінал", "канал", "журнал", "сигнал", "мінерал", "кристал", "метал", "квартал", "верств", "мельник", "матері", "досить", "втек", "утек", "помер", "вимер", "вдер", "новел", "альбом", "мініальбом", "геном", "диплом", "прийом", "підйом", "синдром", "аеродром", "шолом", "астроном", "агроном", "режим", "напрям", "іслам", "мадам", "вільям", "максим", "вадим", "артем", "єрусалим", "в'єтнам", "амстердам", "освіт", "результат", "втрат", "палат", "гармат", "депутат", "витрат", "солдат", "штат", "орбіт", "кімнат", "просвіт", "страт", "координат", "лауреат", "кандидат", "чемпіонат", "плит", "апарат", "препарат", "еліт", "звіт", "оплат", "світ", "сплат", "виплат", "експонат", "іспит", "цитат", "маргарит", "гранат", "повіт", "запит", "демократ", "формат", "агрегат", "статт", "сім'", "музе", "ліце", "хоке", "євре", "ієре", "орфе", "таде", "маце", "промете", "мате", "птолеме", "сідне", "дісне", "бруне", "ене", "ірине", "ювіле", "привіле", "кле", "мавзоле", "диспле", "галіле", "десят", "січн", "березн", "квітн", "травн", "червн", "липн", "серпн", "вересн", "жовтн", "грудн", "рівн", "учн", "ступен", "промен", "камен", "корен", "п'ят", "дев'ят", "пророк", "діт", "дн", "земл", "будів", "голов", "євангел", "осен", "львов", "харков", "черніг", "миколаєв", "тернопол", "бориспол", "березан", "астрахан", "ботошан", "остан", "півден", "щоден", "священ", "джован", "лозан", "відстан", "тайван", "гаван", "бретан", "кубан", "пристан", "познан", "рязан", "юньнан", "хайнан", "горбан", "довган", "мішен", "домен", "відан", "притаман", "нечислен", "дорогоцін", "нескінчен", "барабан", "фортепіан", "повноцін", "вік", "округ", "ліг", "америк", "річк", "книг", "африк", "республік", "смуг", "бібліотек", "присяг", "дорог", "ділянк", "практик", "футболк", "ваг", "виставк", "мексик", "праг", "розробк", "заток", "точк", "політик", "музик", "уваг", "підготовк", "гонк", "трійк", "сторінк", "наук", "підтримк", "технік", "низк", "кладк", "економік", "стрічк", "рук", "збірк", "черг", "критик", "фабрик", "обкладинк", "риг")

    a_16 = [
        Among("ріг", -1, 15),
        Among("плід", -1, 11),
        Among("рід", -1, 12),
        Among("хід", -1, 1),
        Among("бік", -1, 13),
        Among("сік", -1, 16),
        Among("стіл", -1, 6),
        Among("дім", -1, 5),
        Among("бір", -1, 2),
        Among("ріст", -1, 3),
        Among("кіт", -1, 14),
        Among("ніч", -1, 4),
        Among("піч", -1, 7),
        Among("сіль", -1, 8),
        Among("кінь", -1, 9),
        Among("гість", -1, 10)
    ]

    a_17 = [
        Among("сь", -1, -1),
        Among("лась", 0, -1),
        Among("всь", 0, -1),
        Among("тись", 0, -1),
        Among("ся", -1, -1),
        Among("вся", 4, -1),
        Among("тися", 4, -1)
    ]


class lab0(BaseException): pass


class lab1(BaseException): pass


class lab2(BaseException): pass


class lab3(BaseException): pass
