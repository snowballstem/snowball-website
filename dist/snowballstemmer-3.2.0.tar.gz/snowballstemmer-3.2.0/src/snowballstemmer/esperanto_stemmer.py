# Generated from esperanto.sbl by Snowball 3.2.0 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class EsperantoStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from esperanto.sbl by Snowball 3.2.0 - https://snowballstem.org/
    '''

    g_vowel = {"a", "e", "i", "o", "u"}

    g_aou = "aou"
    g_digit = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"}


    def _stem(self):
        v_1 = self.cursor
        B_foreign = False
        while True:
            v_2 = self.cursor
            try:
                self.bra = self.cursor
                among_var = self.find_among(EsperantoStemmer.a_0)
                self.ket = self.cursor
                if among_var == 1:
                    self.slice_from("ĉ")
                elif among_var == 2:
                    self.slice_from("ĝ")
                elif among_var == 3:
                    self.slice_from("ĥ")
                elif among_var == 4:
                    self.slice_from("ĵ")
                elif among_var == 5:
                    self.slice_from("ŝ")
                elif among_var == 6:
                    self.slice_from("ŭ")
                elif among_var == 7:
                    self.slice_from("a")
                    B_foreign = True
                elif among_var == 8:
                    self.slice_from("e")
                    B_foreign = True
                elif among_var == 9:
                    self.slice_from("i")
                    B_foreign = True
                elif among_var == 10:
                    self.slice_from("o")
                    B_foreign = True
                elif among_var == 11:
                    self.slice_from("u")
                    B_foreign = True
                elif among_var == 12:
                    B_foreign = True
                elif among_var == 13:
                    B_foreign = False
                else:
                    if self.cursor >= self.limit:
                        raise lab0()
                    self.cursor += 1
                continue
            except lab0: pass
            self.cursor = v_2
            break
        if B_foreign:
            return False
        self.cursor = v_1
        v_3 = self.cursor
        try:
            self.bra = self.cursor
            if self.cursor == self.limit or self.current[self.cursor] != "'":
                raise lab0()
            self.cursor += 1
            self.ket = self.cursor
            if not self.eq_s("st"):
                raise lab0()
            if self.find_among(EsperantoStemmer.a_1) == 0:
                raise lab0()
            if self.cursor < self.limit:
                raise lab0()
            self.slice_from("e")
        except lab0: pass
        self.cursor = v_3
        self.limit_backward = self.cursor
        self.cursor = self.limit
        v_4 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            v_5 = self.limit - self.cursor
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "n":
                    self.cursor = self.limit - v_5
                    raise lab1()
                self.cursor -= 1
            except lab1: pass
            self.bra = self.cursor
            if self.find_among_b(EsperantoStemmer.a_2) == 0:
                raise lab0()
            while True:
                try:
                    if self.cursor > self.limit_backward:
                        raise lab1()
                    break
                except lab1: pass
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "-":
                    raise lab0()
                self.cursor -= 1
                break
            self.slice_del()
            return False
        except lab0: pass
        self.cursor = self.limit - v_4
        v_6 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "'":
                raise lab0()
            self.cursor -= 1
            self.bra = self.cursor
            while True:
                v_7 = self.limit - self.cursor
                try:
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "l":
                        raise lab1()
                    self.cursor -= 1
                    if self.cursor > self.limit_backward:
                        raise lab1()
                    self.slice_from("a")
                    break
                except lab1: pass
                self.cursor = self.limit - v_7
                try:
                    if not self.eq_s_b("un"):
                        raise lab1()
                    if self.cursor > self.limit_backward:
                        raise lab1()
                    self.slice_from("u")
                    break
                except lab1: pass
                self.cursor = self.limit - v_7
                try:
                    if self.find_among_b(EsperantoStemmer.a_3) == 0:
                        raise lab1()
                    while True:
                        try:
                            if self.cursor > self.limit_backward:
                                raise lab2()
                            break
                        except lab2: pass
                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "-":
                            raise lab1()
                        self.cursor -= 1
                        break
                    self.slice_from("aŭ")
                    break
                except lab1: pass
                self.cursor = self.limit - v_7
                self.slice_from("o")
                break
        except lab0: pass
        self.cursor = self.limit - v_6
        v_8 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            self.bra = self.cursor
            v_9 = self.limit - self.cursor
            while True:
                v_10 = self.limit - self.cursor
                try:
                    v_11 = self.limit - self.cursor
                    try:
                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "n":
                            self.cursor = self.limit - v_11
                            raise lab2()
                        self.cursor -= 1
                    except lab2: pass
                    self.bra = self.cursor
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "e":
                        raise lab1()
                    self.cursor -= 1
                    break
                except lab1: pass
                self.cursor = self.limit - v_10
                v_12 = self.limit - self.cursor
                try:
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "n":
                        self.cursor = self.limit - v_12
                        raise lab1()
                    self.cursor -= 1
                except lab1: pass
                v_13 = self.limit - self.cursor
                try:
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "j":
                        self.cursor = self.limit - v_13
                        raise lab1()
                    self.cursor -= 1
                except lab1: pass
                self.bra = self.cursor
                if not self.in_grouping_b(EsperantoStemmer.g_aou):
                    raise lab0()
                break
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "i":
                raise lab0()
            self.cursor -= 1
            v_14 = self.limit - self.cursor
            try:
                if self.find_among_b(EsperantoStemmer.a_8) == 0:
                    self.cursor = self.limit - v_14
                    raise lab1()
            except lab1: pass
            while True:
                try:
                    if self.cursor > self.limit_backward:
                        raise lab1()
                    break
                except lab1: pass
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "-":
                    raise lab0()
                self.cursor -= 1
                break
            self.cursor = self.limit - v_9
            self.slice_del()
            return False
        except lab0: pass
        self.cursor = self.limit - v_8
        v_15 = self.limit - self.cursor
        try:
            if self.find_among_b(EsperantoStemmer.a_5) == 0:
                raise lab0()
            while True:
                try:
                    if self.cursor > self.limit_backward:
                        raise lab1()
                    break
                except lab1: pass
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "-":
                    raise lab0()
                self.cursor -= 1
                break
            return False
        except lab0: pass
        self.cursor = self.limit - v_15
        v_16 = self.limit - self.cursor
        try:
            if self.find_among_b(EsperantoStemmer.a_6) == 0:
                raise lab0()
            if self.find_among_b(EsperantoStemmer.a_7) == 0:
                raise lab0()
            return False
        except lab0: pass
        self.cursor = self.limit - v_16
        v_17 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            v_18 = self.limit - self.cursor
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "n":
                    self.cursor = self.limit - v_18
                    raise lab1()
                self.cursor -= 1
            except lab1: pass
            v_19 = self.limit - self.cursor
            try:
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "j":
                    self.cursor = self.limit - v_19
                    raise lab1()
                self.cursor -= 1
            except lab1: pass
            self.bra = self.cursor
            if self.find_among_b(EsperantoStemmer.a_4) == 0:
                raise lab0()
            while True:
                try:
                    if self.cursor > self.limit_backward:
                        raise lab1()
                    break
                except lab1: pass
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "-":
                    raise lab0()
                self.cursor -= 1
                break
            self.slice_del()
            return False
        except lab0: pass
        self.cursor = self.limit - v_17
        v_20 = self.limit - self.cursor
        while True:
            v_21 = self.limit - self.cursor
            try:
                for _ in 0, 0:
                    if not self.go_out_grouping_b(EsperantoStemmer.g_vowel):
                        raise lab0()
                    self.cursor -= 1
                break
            except lab0: pass
            self.cursor = self.limit - v_21
            try:
                while True:
                    try:
                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "-":
                            raise lab1()
                        self.cursor -= 1
                        break
                    except lab1: pass
                    if self.cursor <= self.limit_backward:
                        raise lab0()
                    self.cursor -= 1
                if self.cursor <= self.limit_backward:
                    raise lab0()
                self.cursor -= 1
                break
            except lab0: pass
            self.cursor = self.limit - v_21
            if not self.go_out_grouping_b(EsperantoStemmer.g_digit):
                return False
            self.cursor -= 1
            break
        self.cursor = self.limit - v_20
        self.ket = self.cursor
        among_var = self.find_among_b(EsperantoStemmer.a_9)
        if among_var == 0:
            return False
        if among_var == 1:
            v_22 = self.limit - self.cursor
            while True:
                try:
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "-":
                        raise lab0()
                    self.cursor -= 1
                    break
                except lab0: pass
                if not self.in_grouping_b(EsperantoStemmer.g_digit):
                    return False
                break
            self.cursor = self.limit - v_22
        v_23 = self.limit - self.cursor
        try:
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "-":
                self.cursor = self.limit - v_23
                raise lab0()
            self.cursor -= 1
        except lab0: pass
        self.bra = self.cursor
        self.slice_del()
        self.cursor = self.limit_backward
        return True

    a_0 = [
        Among("", -1, 14),
        Among("-", 0, 13),
        Among("cx", 0, 1),
        Among("gx", 0, 2),
        Among("hx", 0, 3),
        Among("jx", 0, 4),
        Among("q", 0, 12),
        Among("sx", 0, 5),
        Among("ux", 0, 6),
        Among("w", 0, 12),
        Among("x", 0, 12),
        Among("y", 0, 12),
        Among("á", 0, 7),
        Among("é", 0, 8),
        Among("í", 0, 9),
        Among("ó", 0, 10),
        Among("ú", 0, 11)
    ]

    a_1 = [
        Among("as", -1, -1),
        Among("i", -1, -1),
        Among("is", 1, -1),
        Among("os", -1, -1),
        Among("u", -1, -1),
        Among("us", 4, -1)
    ]

    a_2 = [
        Among("ci", -1, -1),
        Among("gi", -1, -1),
        Among("hi", -1, -1),
        Among("li", -1, -1),
        Among("ili", 3, -1),
        Among("ŝli", 3, -1),
        Among("mi", -1, -1),
        Among("ni", -1, -1),
        Among("oni", 7, -1),
        Among("ri", -1, -1),
        Among("si", -1, -1),
        Among("vi", -1, -1),
        Among("ivi", 11, -1),
        Among("ĝi", -1, -1),
        Among("ŝi", -1, -1),
        Among("iŝi", 14, -1),
        Among("malŝi", 14, -1)
    ]

    a_3 = [
        Among("amb", -1, -1),
        Among("bald", -1, -1),
        Among("malbald", 1, -1),
        Among("morg", -1, -1),
        Among("postmorg", 3, -1),
        Among("adi", -1, -1),
        Among("hodi", -1, -1),
        Among("ank", -1, -1),
        Among("ĉirk", -1, -1),
        Among("tutĉirk", 8, -1),
        Among("presk", -1, -1),
        Among("almen", -1, -1),
        Among("apen", -1, -1),
        Among("hier", -1, -1),
        Among("antaŭhier", 13, -1),
        Among("malgr", -1, -1),
        Among("ankor", -1, -1),
        Among("kontr", -1, -1),
        Among("anstat", -1, -1),
        Among("kvaz", -1, -1)
    ]

    a_4 = [
        Among("aliu", -1, -1),
        Among("unu", -1, -1)
    ]

    a_5 = [
        Among("aha", -1, -1),
        Among("haha", 0, -1),
        Among("haleluja", -1, -1),
        Among("hola", -1, -1),
        Among("hosana", -1, -1),
        Among("maltra", -1, -1),
        Among("hura", -1, -1),
        Among("ĥaĥa", -1, -1),
        Among("ekde", -1, -1),
        Among("elde", -1, -1),
        Among("disde", -1, -1),
        Among("ehe", -1, -1),
        Among("maltre", -1, -1),
        Among("dirlididi", -1, -1),
        Among("malpli", -1, -1),
        Among("malĉi", -1, -1),
        Among("malkaj", -1, -1),
        Among("amen", -1, -1),
        Among("tamen", 17, -1),
        Among("oho", -1, -1),
        Among("maltro", -1, -1),
        Among("minus", -1, -1),
        Among("uhu", -1, -1),
        Among("muu", -1, -1)
    ]

    a_6 = [
        Among("tri", -1, -1),
        Among("du", -1, -1),
        Among("unu", -1, -1)
    ]

    a_7 = [
        Among("dek", -1, -1),
        Among("cent", -1, -1)
    ]

    a_8 = [
        Among("k", -1, -1),
        Among("kelk", 0, -1),
        Among("nen", -1, -1),
        Among("t", -1, -1),
        Among("mult", 3, -1),
        Among("samt", 3, -1),
        Among("ĉ", -1, -1)
    ]

    a_9 = [
        Among("a", -1, -1),
        Among("e", -1, -1),
        Among("i", -1, -1),
        Among("j", -1, 1),
        Among("aj", 3, -1),
        Among("oj", 3, -1),
        Among("n", -1, 1),
        Among("an", 6, -1),
        Among("en", 6, -1),
        Among("jn", 6, 1),
        Among("ajn", 9, -1),
        Among("ojn", 9, -1),
        Among("on", 6, -1),
        Among("o", -1, -1),
        Among("as", -1, -1),
        Among("is", -1, -1),
        Among("os", -1, -1),
        Among("us", -1, -1),
        Among("u", -1, -1)
    ]


class lab0(BaseException): pass


class lab1(BaseException): pass


class lab2(BaseException): pass
