# Generated from tamil.sbl by Snowball 3.2.0 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class TamilStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from tamil.sbl by Snowball 3.2.0 - https://snowballstem.org/
    '''

    B_found_vetrumai_urupu = False

    def __r_fix_va_start(self):
        self.bra = self.cursor
        among_var = self.find_among(TamilStemmer.a_0)
        if among_var == 0:
            return False
        self.ket = self.cursor
        self.slice_from(TamilStemmer.as_0[among_var - 1])
        return True

    def __r_fix_endings(self):
        v_1 = self.cursor
        try:
            while True:
                v_2 = self.cursor
                try:
                    if not self.__r_fix_ending():
                        raise lab1()
                    continue
                except lab1: pass
                self.cursor = v_2
                break
        except lab0: pass
        self.cursor = v_1
        return True

    def __r_fix_ending(self):
        if len(self.current) < 4:
            return False
        self.limit_backward = self.cursor
        self.cursor = self.limit
        while True:
            v_1 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                among_var = self.find_among_b(TamilStemmer.a_5)
                if among_var == 0:
                    raise lab0()
                self.bra = self.cursor
                if among_var == 1:
                    self.slice_del()
                elif among_var == 2:
                    v_2 = self.limit - self.cursor
                    if self.find_among_b(TamilStemmer.a_2) == 0:
                        raise lab0()
                    self.cursor = self.limit - v_2
                    self.slice_del()
                elif among_var == 3:
                    self.slice_from("\u0BB3\u0BCD")
                elif among_var == 4:
                    self.slice_from("\u0BB2\u0BCD")
                elif among_var == 5:
                    self.slice_from("\u0B9F\u0BC1")
                elif among_var == 6:
                    if not self.B_found_vetrumai_urupu:
                        raise lab0()
                    try:
                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u0BC8":
                            raise lab1()
                        self.cursor -= 1
                        raise lab0()
                    except lab1: pass
                    self.slice_from("\u0BAE\u0BCD")
                elif among_var == 7:
                    self.slice_from("\u0BCD")
                elif among_var == 8:
                    v_3 = self.limit - self.cursor
                    try:
                        if self.find_among_b(TamilStemmer.a_3) == 0:
                            raise lab1()
                        raise lab0()
                    except lab1: pass
                    self.cursor = self.limit - v_3
                    self.slice_del()
                else:
                    among_var = self.find_among_b(TamilStemmer.a_4)
                    self.slice_from(TamilStemmer.as_4[among_var - 1])
                break
            except lab0: pass
            self.cursor = self.limit - v_1
            self.ket = self.cursor
            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u0BCD":
                return False
            self.cursor -= 1
            while True:
                v_4 = self.limit - self.cursor
                try:
                    if self.find_among_b(TamilStemmer.a_6) == 0:
                        raise lab0()
                    v_5 = self.limit - self.cursor
                    try:
                        if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u0BCD":
                            self.cursor = self.limit - v_5
                            raise lab1()
                        self.cursor -= 1
                        if self.find_among_b(TamilStemmer.a_6) == 0:
                            self.cursor = self.limit - v_5
                            raise lab1()
                    except lab1: pass
                    self.bra = self.cursor
                    self.slice_del()
                    break
                except lab0: pass
                self.cursor = self.limit - v_4
                try:
                    if self.find_among_b(TamilStemmer.a_7) == 0:
                        raise lab0()
                    self.bra = self.cursor
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u0BCD":
                        raise lab0()
                    self.cursor -= 1
                    self.slice_del()
                    break
                except lab0: pass
                self.cursor = self.limit - v_4
                v_6 = self.limit - self.cursor
                if self.find_among_b(TamilStemmer.a_8) == 0:
                    return False
                self.cursor = self.limit - v_6
                self.bra = self.cursor
                self.slice_del()
                break
            break
        self.cursor = self.limit_backward
        return True

    def _stem(self):
        self.B_found_vetrumai_urupu = False
        v_1 = self.cursor
        self.__r_fix_ending()
        self.cursor = v_1
        if len(self.current) < 5:
            return False
        v_2 = self.cursor
        try:
            self.bra = self.cursor
            if self.cursor == self.limit or self.current[self.cursor] != "\u0B8E":
                raise lab0()
            self.cursor += 1
            if self.find_among(TamilStemmer.a_1) == 0:
                raise lab0()
            if self.cursor == self.limit or self.current[self.cursor] != "\u0BCD":
                raise lab0()
            self.cursor += 1
            self.ket = self.cursor
            self.slice_del()
            v_3 = self.cursor
            self.__r_fix_va_start()
            self.cursor = v_3
        except lab0: pass
        self.cursor = v_2
        v_4 = self.cursor
        try:
            self.bra = self.cursor
            if self.find_among(TamilStemmer.a_9) == 0:
                raise lab0()
            if self.find_among(TamilStemmer.a_1) == 0:
                raise lab0()
            if self.cursor == self.limit or self.current[self.cursor] != "\u0BCD":
                raise lab0()
            self.cursor += 1
            self.ket = self.cursor
            self.slice_del()
            v_5 = self.cursor
            self.__r_fix_va_start()
            self.cursor = v_5
        except lab0: pass
        self.cursor = v_4
        try:
            if len(self.current) < 5:
                raise lab0()
            self.limit_backward = self.cursor
            self.cursor = self.limit
            v_6 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                if self.find_among_b(TamilStemmer.a_11) == 0:
                    raise lab1()
                self.bra = self.cursor
                self.slice_from("\u0BCD")
            except lab1: pass
            self.cursor = self.limit - v_6
            self.cursor = self.limit_backward
            self.__r_fix_endings()
        except lab0: pass
        v_7 = self.cursor
        try:
            if len(self.current) < 5:
                raise lab0()
            self.limit_backward = self.cursor
            self.cursor = self.limit
            self.ket = self.cursor
            if not self.eq_s_b("\u0BC1\u0BAE\u0BCD"):
                raise lab0()
            self.bra = self.cursor
            self.slice_from("\u0BCD")
            self.cursor = self.limit_backward
            v_8 = self.cursor
            self.__r_fix_ending()
            self.cursor = v_8
        except lab0: pass
        self.cursor = v_7
        v_9 = self.cursor
        try:
            if len(self.current) < 5:
                raise lab0()
            self.limit_backward = self.cursor
            self.cursor = self.limit
            self.ket = self.cursor
            among_var = self.find_among_b(TamilStemmer.a_13)
            if among_var == 0:
                raise lab0()
            self.bra = self.cursor
            if among_var == 1:
                self.slice_from("\u0BCD")
            elif among_var == 2:
                v_10 = self.limit - self.cursor
                try:
                    if self.find_among_b(TamilStemmer.a_3) == 0:
                        raise lab1()
                    raise lab0()
                except lab1: pass
                self.cursor = self.limit - v_10
                self.slice_from("\u0BCD")
            else:
                self.slice_del()
            self.cursor = self.limit_backward
            self.__r_fix_endings()
        except lab0: pass
        self.cursor = v_9
        v_11 = self.cursor
        try:
            self.B_found_vetrumai_urupu = False
            if len(self.current) < 5:
                raise lab0()
            self.limit_backward = self.cursor
            self.cursor = self.limit
            while True:
                v_12 = self.limit - self.cursor
                try:
                    v_13 = self.limit - self.cursor
                    self.ket = self.cursor
                    among_var = self.find_among_b(TamilStemmer.a_14)
                    if among_var == 0:
                        raise lab1()
                    self.bra = self.cursor
                    if among_var == 1:
                        self.slice_del()
                    elif among_var == 2:
                        self.slice_from("\u0BCD")
                    elif among_var == 3:
                        try:
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u0BAE":
                                raise lab2()
                            self.cursor -= 1
                            raise lab1()
                        except lab2: pass
                        self.slice_from("\u0BCD")
                    elif among_var == 4:
                        if len(self.current) < 7:
                            raise lab1()
                        self.slice_from("\u0BCD")
                    elif among_var == 5:
                        v_14 = self.limit - self.cursor
                        try:
                            if self.find_among_b(TamilStemmer.a_3) == 0:
                                raise lab2()
                            raise lab1()
                        except lab2: pass
                        self.cursor = self.limit - v_14
                        self.slice_from("\u0BCD")
                    elif among_var == 6:
                        v_15 = self.limit - self.cursor
                        try:
                            if self.find_among_b(TamilStemmer.a_3) == 0:
                                raise lab2()
                            raise lab1()
                        except lab2: pass
                        self.cursor = self.limit - v_15
                        self.slice_del()
                    else:
                        self.slice_from("\u0BBF")
                    self.cursor = self.limit - v_13
                    break
                except lab1: pass
                self.cursor = self.limit - v_12
                v_16 = self.limit - self.cursor
                self.ket = self.cursor
                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u0BC8":
                    raise lab0()
                self.cursor -= 1
                while True:
                    v_17 = self.limit - self.cursor
                    try:
                        v_18 = self.limit - self.cursor
                        try:
                            if self.find_among_b(TamilStemmer.a_6) == 0:
                                raise lab2()
                            raise lab1()
                        except lab2: pass
                        self.cursor = self.limit - v_18
                        break
                    except lab1: pass
                    self.cursor = self.limit - v_17
                    v_19 = self.limit - self.cursor
                    if self.find_among_b(TamilStemmer.a_6) == 0:
                        raise lab0()
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u0BCD":
                        raise lab0()
                    self.cursor -= 1
                    self.cursor = self.limit - v_19
                    break
                self.bra = self.cursor
                self.slice_from("\u0BCD")
                self.cursor = self.limit - v_16
                break
            self.B_found_vetrumai_urupu = True
            v_20 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                if not self.eq_s_b("\u0BBF\u0BA9\u0BCD"):
                    raise lab1()
                self.bra = self.cursor
                self.slice_from("\u0BCD")
            except lab1: pass
            self.cursor = self.limit - v_20
            self.cursor = self.limit_backward
            self.__r_fix_endings()
        except lab0: pass
        self.cursor = v_11
        v_21 = self.cursor
        try:
            self.limit_backward = self.cursor
            self.cursor = self.limit
            self.ket = self.cursor
            among_var = self.find_among_b(TamilStemmer.a_10)
            if among_var == 0:
                raise lab0()
            self.bra = self.cursor
            if among_var == 1:
                while True:
                    v_22 = self.limit - self.cursor
                    try:
                        if self.find_among_b(TamilStemmer.a_6) == 0:
                            raise lab1()
                        self.slice_from("\u0BC1\u0B99\u0BCD")
                        break
                    except lab1: pass
                    self.cursor = self.limit - v_22
                    self.slice_from("\u0BCD")
                    break
            elif among_var == 2:
                self.slice_from("\u0BB2\u0BCD")
            elif among_var == 3:
                self.slice_from("\u0BB3\u0BCD")
            else:
                self.slice_del()
            self.cursor = self.limit_backward
        except lab0: pass
        self.cursor = v_21
        v_23 = self.cursor
        try:
            if len(self.current) < 5:
                raise lab0()
            self.limit_backward = self.cursor
            self.cursor = self.limit
            self.ket = self.cursor
            if self.find_among_b(TamilStemmer.a_12) == 0:
                raise lab0()
            self.bra = self.cursor
            self.slice_del()
            self.cursor = self.limit_backward
        except lab0: pass
        self.cursor = v_23
        v_24 = self.cursor
        try:
            while True:
                v_25 = self.cursor
                try:
                    B_found_a_match = False
                    if len(self.current) < 5:
                        raise lab1()
                    self.limit_backward = self.cursor
                    self.cursor = self.limit
                    v_26 = self.limit - self.cursor
                    try:
                        v_27 = self.limit - self.cursor
                        self.ket = self.cursor
                        among_var = self.find_among_b(TamilStemmer.a_16)
                        if among_var == 0:
                            raise lab2()
                        self.bra = self.cursor
                        if among_var == 1:
                            self.slice_del()
                        elif among_var == 2:
                            v_28 = self.limit - self.cursor
                            try:
                                if self.find_among_b(TamilStemmer.a_15) == 0:
                                    raise lab3()
                                raise lab2()
                            except lab3: pass
                            self.cursor = self.limit - v_28
                            self.slice_del()
                        elif among_var == 3:
                            v_29 = self.limit - self.cursor
                            try:
                                if self.find_among_b(TamilStemmer.a_3) == 0:
                                    raise lab3()
                                raise lab2()
                            except lab3: pass
                            self.cursor = self.limit - v_29
                            self.slice_del()
                        elif among_var == 4:
                            try:
                                if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u0B9A":
                                    raise lab3()
                                self.cursor -= 1
                                raise lab2()
                            except lab3: pass
                            self.slice_from("\u0BCD")
                        elif among_var == 5:
                            self.slice_from("\u0BCD")
                        else:
                            v_30 = self.limit - self.cursor
                            if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u0BCD":
                                raise lab2()
                            self.cursor -= 1
                            self.cursor = self.limit - v_30
                            self.slice_del()
                        B_found_a_match = True
                        self.cursor = self.limit - v_27
                    except lab2: pass
                    self.cursor = self.limit - v_26
                    v_31 = self.limit - self.cursor
                    try:
                        self.ket = self.cursor
                        if self.find_among_b(TamilStemmer.a_17) == 0:
                            raise lab2()
                        self.bra = self.cursor
                        self.slice_del()
                        B_found_a_match = True
                    except lab2: pass
                    self.cursor = self.limit - v_31
                    self.cursor = self.limit_backward
                    self.__r_fix_endings()
                    if not B_found_a_match:
                        raise lab1()
                    continue
                except lab1: pass
                self.cursor = v_25
                break
        except lab0: pass
        self.cursor = v_24
        return True

    a_0 = [
        Among("\u0BB5\u0BC1", -1, 3),
        Among("\u0BB5\u0BC2", -1, 4),
        Among("\u0BB5\u0BCA", -1, 2),
        Among("\u0BB5\u0BCB", -1, 1)
    ]
    as_0 = ("\u0B93", "\u0B92", "\u0B89", "\u0B8A")

    a_1 = [
        Among("\u0B95", -1, -1),
        Among("\u0B99", -1, -1),
        Among("\u0B9A", -1, -1),
        Among("\u0B9E", -1, -1),
        Among("\u0BA4", -1, -1),
        Among("\u0BA8", -1, -1),
        Among("\u0BAA", -1, -1),
        Among("\u0BAE", -1, -1),
        Among("\u0BAF", -1, -1),
        Among("\u0BB5", -1, -1)
    ]

    a_2 = [
        Among("\u0BBF", -1, -1),
        Among("\u0BC0", -1, -1),
        Among("\u0BC8", -1, -1)
    ]

    a_3 = [
        Among("\u0BBE", -1, -1),
        Among("\u0BBF", -1, -1),
        Among("\u0BC0", -1, -1),
        Among("\u0BC1", -1, -1),
        Among("\u0BC2", -1, -1),
        Among("\u0BC6", -1, -1),
        Among("\u0BC7", -1, -1),
        Among("\u0BC8", -1, -1)
    ]

    a_4 = [
        Among("", -1, 2),
        Among("\u0BC8", 0, 1),
        Among("\u0BCD", 0, 1)
    ]
    as_4 = ("", "\u0BAE\u0BCD")

    a_5 = [
        Among("\u0BA8\u0BCD\u0BA4", -1, 1),
        Among("\u0BAF", -1, 1),
        Among("\u0BB5", -1, 1),
        Among("\u0BA9\u0BC1", -1, 8),
        Among("\u0BC1\u0B95\u0BCD", -1, 7),
        Among("\u0BC1\u0B95\u0BCD\u0B95\u0BCD", -1, 7),
        Among("\u0B9F\u0BCD\u0B95\u0BCD", -1, 3),
        Among("\u0BB1\u0BCD\u0B95\u0BCD", -1, 4),
        Among("\u0B99\u0BCD", -1, 9),
        Among("\u0B9F\u0BCD\u0B9F\u0BCD", -1, 5),
        Among("\u0BA4\u0BCD\u0BA4\u0BCD", -1, 6),
        Among("\u0BA8\u0BCD\u0BA4\u0BCD", -1, 1),
        Among("\u0BA8\u0BCD", -1, 1),
        Among("\u0B9F\u0BCD\u0BAA\u0BCD", -1, 3),
        Among("\u0BAF\u0BCD", -1, 2),
        Among("\u0BA9\u0BCD\u0BB1\u0BCD", -1, 4),
        Among("\u0BB5\u0BCD", -1, 1)
    ]

    a_6 = [
        Among("\u0B95", -1, -1),
        Among("\u0B9A", -1, -1),
        Among("\u0B9F", -1, -1),
        Among("\u0BA4", -1, -1),
        Among("\u0BAA", -1, -1),
        Among("\u0BB1", -1, -1)
    ]

    a_7 = [
        Among("\u0B9E", -1, -1),
        Among("\u0BA3", -1, -1),
        Among("\u0BA8", -1, -1),
        Among("\u0BA9", -1, -1),
        Among("\u0BAE", -1, -1),
        Among("\u0BAF", -1, -1),
        Among("\u0BB0", -1, -1),
        Among("\u0BB2", -1, -1),
        Among("\u0BB3", -1, -1),
        Among("\u0BB4", -1, -1),
        Among("\u0BB5", -1, -1)
    ]

    a_8 = [
        Among("\u0BBE", -1, -1),
        Among("\u0BBF", -1, -1),
        Among("\u0BC0", -1, -1),
        Among("\u0BC1", -1, -1),
        Among("\u0BC2", -1, -1),
        Among("\u0BC6", -1, -1),
        Among("\u0BC7", -1, -1),
        Among("\u0BC8", -1, -1),
        Among("\u0BCD", -1, -1)
    ]

    a_9 = [
        Among("\u0B85", -1, -1),
        Among("\u0B87", -1, -1),
        Among("\u0B89", -1, -1)
    ]

    a_10 = [
        Among("\u0B95\u0BB3\u0BCD", -1, 4),
        Among("\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD", 0, 1),
        Among("\u0B9F\u0BCD\u0B95\u0BB3\u0BCD", 0, 3),
        Among("\u0BB1\u0BCD\u0B95\u0BB3\u0BCD", 0, 2)
    ]

    a_11 = [
        Among("\u0BBE", -1, -1),
        Among("\u0BC7", -1, -1),
        Among("\u0BCB", -1, -1)
    ]

    a_12 = [
        Among("\u0BAA\u0BBF", -1, -1),
        Among("\u0BB5\u0BBF", -1, -1)
    ]

    a_13 = [
        Among("\u0BAA\u0B9F\u0BCD\u0B9F", -1, 3),
        Among("\u0BAA\u0B9F\u0BCD\u0B9F\u0BA3", -1, 3),
        Among("\u0BA4\u0BBE\u0BA9", -1, 3),
        Among("\u0BAA\u0B9F\u0BBF\u0BA4\u0BBE\u0BA9", 2, 3),
        Among("\u0BC6\u0BA9", -1, 1),
        Among("\u0BBE\u0B95\u0BBF\u0BAF", -1, 1),
        Among("\u0B95\u0BC1\u0BB0\u0BBF\u0BAF", -1, 3),
        Among("\u0BC1\u0B9F\u0BC8\u0BAF", -1, 1),
        Among("\u0BB2\u0BCD\u0BB2", -1, 2),
        Among("\u0BC1\u0BB3\u0BCD\u0BB3", -1, 1),
        Among("\u0BBE\u0B95\u0BBF", -1, 1),
        Among("\u0BAA\u0B9F\u0BBF", -1, 3),
        Among("\u0BBF\u0BA9\u0BCD\u0BB1\u0BBF", -1, 1),
        Among("\u0BAA\u0BB1\u0BCD\u0BB1\u0BBF", -1, 3),
        Among("\u0BAA\u0B9F\u0BC1", -1, 3),
        Among("\u0BB5\u0BBF\u0B9F\u0BC1", -1, 3),
        Among("\u0BAA\u0B9F\u0BCD\u0B9F\u0BC1", -1, 3),
        Among("\u0BB5\u0BBF\u0B9F\u0BCD\u0B9F\u0BC1", -1, 3),
        Among("\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1", -1, 3),
        Among("\u0BC6\u0BA9\u0BCD\u0BB1\u0BC1", -1, 1),
        Among("\u0BC1\u0B9F\u0BC8", -1, 1),
        Among("\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8", -1, 1),
        Among("\u0BC1\u0B9F\u0BA9\u0BCD", -1, 1),
        Among("\u0BBF\u0B9F\u0BAE\u0BCD", -1, 1),
        Among("\u0BC6\u0BB2\u0BCD\u0BB2\u0BBE\u0BAE\u0BCD", -1, 3),
        Among("\u0BC6\u0BA9\u0BC1\u0BAE\u0BCD", -1, 1)
    ]

    a_14 = [
        Among("\u0BB5\u0BBF\u0B9F", -1, 2),
        Among("\u0BC0", -1, 7),
        Among("\u0BCA\u0B9F\u0BC1", -1, 2),
        Among("\u0BCB\u0B9F\u0BC1", -1, 2),
        Among("\u0BA4\u0BC1", -1, 6),
        Among("\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1", 4, 2),
        Among("\u0BBF\u0BA9\u0BCD\u0BB1\u0BC1", -1, 2),
        Among("\u0BC1\u0B9F\u0BC8", -1, 2),
        Among("\u0BA9\u0BC8", -1, 1),
        Among("\u0B95\u0BA3\u0BCD", -1, 1),
        Among("\u0BBF\u0BA9\u0BCD", -1, 3),
        Among("\u0BAE\u0BC1\u0BA9\u0BCD", -1, 1),
        Among("\u0BBF\u0B9F\u0BAE\u0BCD", -1, 4),
        Among("\u0BBF\u0BB1\u0BCD", -1, 2),
        Among("\u0BAE\u0BC7\u0BB1\u0BCD", -1, 1),
        Among("\u0BB2\u0BCD", -1, 5),
        Among("\u0BBE\u0BAE\u0BB2\u0BCD", 15, 2),
        Among("\u0BBE\u0BB2\u0BCD", 15, 2),
        Among("\u0BBF\u0BB2\u0BCD", 15, 2),
        Among("\u0BAE\u0BC7\u0BB2\u0BCD", 15, 1),
        Among("\u0BC1\u0BB3\u0BCD", -1, 2),
        Among("\u0B95\u0BC0\u0BB4\u0BCD", -1, 1)
    ]

    a_15 = [
        Among("\u0B85", -1, -1),
        Among("\u0B86", -1, -1),
        Among("\u0B87", -1, -1),
        Among("\u0B88", -1, -1),
        Among("\u0B89", -1, -1),
        Among("\u0B8A", -1, -1),
        Among("\u0B8E", -1, -1),
        Among("\u0B8F", -1, -1),
        Among("\u0B90", -1, -1),
        Among("\u0B92", -1, -1),
        Among("\u0B93", -1, -1),
        Among("\u0B94", -1, -1)
    ]

    a_16 = [
        Among("\u0B95", -1, 1),
        Among("\u0BA4", -1, 1),
        Among("\u0BA9", -1, 1),
        Among("\u0BAA", -1, 1),
        Among("\u0BAF", -1, 1),
        Among("\u0BBE", -1, 5),
        Among("\u0B95\u0BC1", -1, 6),
        Among("\u0BAA\u0B9F\u0BC1", -1, 1),
        Among("\u0BA4\u0BC1", -1, 3),
        Among("\u0BBF\u0BB1\u0BCD\u0BB1\u0BC1", -1, 1),
        Among("\u0BA9\u0BC8", -1, 1),
        Among("\u0BB5\u0BC8", -1, 1),
        Among("\u0BA9\u0BA9\u0BCD", -1, 1),
        Among("\u0BAA\u0BA9\u0BCD", -1, 1),
        Among("\u0BB5\u0BA9\u0BCD", -1, 2),
        Among("\u0BBE\u0BA9\u0BCD", -1, 4),
        Among("\u0BA9\u0BBE\u0BA9\u0BCD", 15, 1),
        Among("\u0BAE\u0BBF\u0BA9\u0BCD", -1, 1),
        Among("\u0BA9\u0BC6\u0BA9\u0BCD", -1, 1),
        Among("\u0BC7\u0BA9\u0BCD", -1, 5),
        Among("\u0BA9\u0BAE\u0BCD", -1, 1),
        Among("\u0BAA\u0BAE\u0BCD", -1, 1),
        Among("\u0BBE\u0BAE\u0BCD", -1, 5),
        Among("\u0B95\u0BC1\u0BAE\u0BCD", -1, 1),
        Among("\u0B9F\u0BC1\u0BAE\u0BCD", -1, 5),
        Among("\u0BA4\u0BC1\u0BAE\u0BCD", -1, 1),
        Among("\u0BB1\u0BC1\u0BAE\u0BCD", -1, 1),
        Among("\u0BC6\u0BAE\u0BCD", -1, 5),
        Among("\u0BC7\u0BAE\u0BCD", -1, 5),
        Among("\u0BCB\u0BAE\u0BCD", -1, 5),
        Among("\u0BBE\u0BAF\u0BCD", -1, 5),
        Among("\u0BA9\u0BB0\u0BCD", -1, 1),
        Among("\u0BAA\u0BB0\u0BCD", -1, 1),
        Among("\u0BC0\u0BAF\u0BB0\u0BCD", -1, 5),
        Among("\u0BB5\u0BB0\u0BCD", -1, 1),
        Among("\u0BBE\u0BB0\u0BCD", -1, 5),
        Among("\u0BA9\u0BBE\u0BB0\u0BCD", 35, 1),
        Among("\u0BAE\u0BBE\u0BB0\u0BCD", 35, 1),
        Among("\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BCD", -1, 1),
        Among("\u0BA9\u0BBF\u0BB0\u0BCD", -1, 5),
        Among("\u0BC0\u0BB0\u0BCD", -1, 5),
        Among("\u0BA9\u0BB3\u0BCD", -1, 1),
        Among("\u0BAA\u0BB3\u0BCD", -1, 1),
        Among("\u0BB5\u0BB3\u0BCD", -1, 1),
        Among("\u0BBE\u0BB3\u0BCD", -1, 5),
        Among("\u0BA9\u0BBE\u0BB3\u0BCD", 44, 1)
    ]

    a_17 = [
        Among("\u0B95\u0BBF\u0BB1", -1, -1),
        Among("\u0B95\u0BBF\u0BA9\u0BCD\u0BB1", -1, -1),
        Among("\u0BBE\u0BA8\u0BBF\u0BA9\u0BCD\u0BB1", -1, -1),
        Among("\u0B95\u0BBF\u0BB1\u0BCD", -1, -1),
        Among("\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BCD", -1, -1),
        Among("\u0BBE\u0BA8\u0BBF\u0BA9\u0BCD\u0BB1\u0BCD", -1, -1)
    ]


class lab0(BaseException): pass


class lab1(BaseException): pass


class lab2(BaseException): pass


class lab3(BaseException): pass
