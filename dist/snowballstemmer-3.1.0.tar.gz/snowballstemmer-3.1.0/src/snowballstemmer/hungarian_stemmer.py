# Generated from hungarian.sbl by Snowball 3.1.0 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class HungarianStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from hungarian.sbl by Snowball 3.1.0 - https://snowballstem.org/
    '''

    g_v = {"a", "e", "i", "o", "u", "á", "é", "í", "ó", "ö", "ú", "ü", "ő", "ű"}

    I_p1 = 0

    def __r_mark_regions(self):
        self.I_p1 = self.limit
        while True:
            v_1 = self.cursor
            try:
                if not self.in_grouping(HungarianStemmer.g_v):
                    raise lab0()
                v_2 = self.cursor
                try:
                    if not self.go_in_grouping(HungarianStemmer.g_v):
                        raise lab1()
                    self.cursor += 1
                    self.I_p1 = self.cursor
                except lab1: pass
                self.cursor = v_2
                break
            except lab0: pass
            self.cursor = v_1
            if not self.go_out_grouping(HungarianStemmer.g_v):
                return False
            self.cursor += 1
            self.I_p1 = self.cursor
            break
        return True

    def __r_R1(self):
        return self.I_p1 <= self.cursor

    def __r_v_ending(self):
        self.ket = self.cursor
        among_var = self.find_among_b(HungarianStemmer.a_0)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        self.slice_from(HungarianStemmer.as_0[among_var - 1])
        return True

    def __r_double(self):
        v_1 = self.limit - self.cursor
        if self.find_among_b(HungarianStemmer.a_1) == 0:
            return False
        self.cursor = self.limit - v_1
        return True

    def __r_undouble(self):
        if self.cursor <= self.limit_backward:
            return False
        self.cursor -= 1
        self.ket = self.cursor
        if self.cursor <= self.limit_backward:
            return False
        self.cursor -= 1
        self.bra = self.cursor
        self.slice_del()
        return True

    def __r_instrum(self):
        self.ket = self.cursor
        if self.find_among_b(HungarianStemmer.a_2) == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        if not self.__r_double():
            return False
        self.slice_del()
        return self.__r_undouble()

    def __r_case(self):
        self.ket = self.cursor
        if self.find_among_b(HungarianStemmer.a_3) == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        self.slice_del()
        return self.__r_v_ending()

    def __r_case_special(self):
        self.ket = self.cursor
        among_var = self.find_among_b(HungarianStemmer.a_4)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        self.slice_from(HungarianStemmer.as_4[among_var - 1])
        return True

    def __r_case_other(self):
        self.ket = self.cursor
        among_var = self.find_among_b(HungarianStemmer.a_5)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        if among_var == 1:
            self.slice_del()
        elif among_var == 2:
            self.slice_from("a")
        else:
            self.slice_from("e")
        return True

    def __r_factive(self):
        self.ket = self.cursor
        if self.find_among_b(HungarianStemmer.a_6) == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        if not self.__r_double():
            return False
        self.slice_del()
        return self.__r_undouble()

    def __r_plural(self):
        self.ket = self.cursor
        among_var = self.find_among_b(HungarianStemmer.a_7)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        if among_var == 1:
            self.slice_from("a")
        elif among_var == 2:
            self.slice_from("e")
        else:
            self.slice_del()
        return True

    def __r_owned(self):
        self.ket = self.cursor
        among_var = self.find_among_b(HungarianStemmer.a_8)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        if among_var == 1:
            self.slice_del()
        elif among_var == 2:
            self.slice_from("e")
        else:
            self.slice_from("a")
        return True

    def __r_sing_owner(self):
        self.ket = self.cursor
        among_var = self.find_among_b(HungarianStemmer.a_9)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        if among_var == 1:
            self.slice_del()
        elif among_var == 2:
            self.slice_from("a")
        else:
            self.slice_from("e")
        return True

    def __r_plur_owner(self):
        self.ket = self.cursor
        among_var = self.find_among_b(HungarianStemmer.a_10)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        if among_var == 1:
            self.slice_del()
        elif among_var == 2:
            self.slice_from("a")
        else:
            self.slice_from("e")
        return True

    def _stem(self):
        v_1 = self.cursor
        self.__r_mark_regions()
        self.cursor = v_1
        self.limit_backward = self.cursor
        self.cursor = self.limit
        v_2 = self.limit - self.cursor
        self.__r_instrum()
        self.cursor = self.limit - v_2
        v_3 = self.limit - self.cursor
        self.__r_case()
        self.cursor = self.limit - v_3
        v_4 = self.limit - self.cursor
        self.__r_case_special()
        self.cursor = self.limit - v_4
        v_5 = self.limit - self.cursor
        self.__r_case_other()
        self.cursor = self.limit - v_5
        v_6 = self.limit - self.cursor
        self.__r_factive()
        self.cursor = self.limit - v_6
        v_7 = self.limit - self.cursor
        self.__r_owned()
        self.cursor = self.limit - v_7
        v_8 = self.limit - self.cursor
        self.__r_sing_owner()
        self.cursor = self.limit - v_8
        v_9 = self.limit - self.cursor
        self.__r_plur_owner()
        self.cursor = self.limit - v_9
        v_10 = self.limit - self.cursor
        self.__r_plural()
        self.cursor = self.limit - v_10
        self.cursor = self.limit_backward
        return True

    a_0 = [
        Among("á", -1, 1),
        Among("é", -1, 2)
    ]
    as_0 = ("a", "e")

    a_1 = [
        Among("bb", -1, -1),
        Among("cc", -1, -1),
        Among("dd", -1, -1),
        Among("ff", -1, -1),
        Among("gg", -1, -1),
        Among("jj", -1, -1),
        Among("kk", -1, -1),
        Among("ll", -1, -1),
        Among("mm", -1, -1),
        Among("nn", -1, -1),
        Among("pp", -1, -1),
        Among("rr", -1, -1),
        Among("ccs", -1, -1),
        Among("ss", -1, -1),
        Among("zzs", -1, -1),
        Among("tt", -1, -1),
        Among("vv", -1, -1),
        Among("ggy", -1, -1),
        Among("lly", -1, -1),
        Among("nny", -1, -1),
        Among("tty", -1, -1),
        Among("ssz", -1, -1),
        Among("zz", -1, -1)
    ]

    a_2 = [
        Among("al", -1, 1),
        Among("el", -1, 1)
    ]

    a_3 = [
        Among("ba", -1, -1),
        Among("ra", -1, -1),
        Among("be", -1, -1),
        Among("re", -1, -1),
        Among("ig", -1, -1),
        Among("nak", -1, -1),
        Among("nek", -1, -1),
        Among("val", -1, -1),
        Among("vel", -1, -1),
        Among("ul", -1, -1),
        Among("nál", -1, -1),
        Among("nél", -1, -1),
        Among("ból", -1, -1),
        Among("ról", -1, -1),
        Among("tól", -1, -1),
        Among("ül", -1, -1),
        Among("ből", -1, -1),
        Among("ről", -1, -1),
        Among("től", -1, -1),
        Among("n", -1, -1),
        Among("an", 19, -1),
        Among("ban", 20, -1),
        Among("en", 19, -1),
        Among("ben", 22, -1),
        Among("képpen", 22, -1),
        Among("on", 19, -1),
        Among("ön", 19, -1),
        Among("képp", -1, -1),
        Among("kor", -1, -1),
        Among("t", -1, -1),
        Among("at", 29, -1),
        Among("et", 29, -1),
        Among("ként", 29, -1),
        Among("anként", 32, -1),
        Among("enként", 32, -1),
        Among("onként", 32, -1),
        Among("ot", 29, -1),
        Among("ért", 29, -1),
        Among("öt", 29, -1),
        Among("hez", -1, -1),
        Among("hoz", -1, -1),
        Among("höz", -1, -1),
        Among("vá", -1, -1),
        Among("vé", -1, -1)
    ]

    a_4 = [
        Among("án", -1, 2),
        Among("én", -1, 1),
        Among("ánként", -1, 2)
    ]
    as_4 = ("e", "a")

    a_5 = [
        Among("stul", -1, 1),
        Among("astul", 0, 1),
        Among("ástul", 0, 2),
        Among("stül", -1, 1),
        Among("estül", 3, 1),
        Among("éstül", 3, 3)
    ]

    a_6 = [
        Among("á", -1, 1),
        Among("é", -1, 1)
    ]

    a_7 = [
        Among("k", -1, 3),
        Among("ak", 0, 3),
        Among("ek", 0, 3),
        Among("ok", 0, 3),
        Among("ák", 0, 1),
        Among("ék", 0, 2),
        Among("ök", 0, 3)
    ]

    a_8 = [
        Among("éi", -1, 1),
        Among("áéi", 0, 3),
        Among("ééi", 0, 2),
        Among("é", -1, 1),
        Among("ké", 3, 1),
        Among("aké", 4, 1),
        Among("eké", 4, 1),
        Among("oké", 4, 1),
        Among("áké", 4, 3),
        Among("éké", 4, 2),
        Among("öké", 4, 1),
        Among("éé", 3, 2)
    ]

    a_9 = [
        Among("a", -1, 1),
        Among("ja", 0, 1),
        Among("d", -1, 1),
        Among("ad", 2, 1),
        Among("ed", 2, 1),
        Among("od", 2, 1),
        Among("ád", 2, 2),
        Among("éd", 2, 3),
        Among("öd", 2, 1),
        Among("e", -1, 1),
        Among("je", 9, 1),
        Among("nk", -1, 1),
        Among("unk", 11, 1),
        Among("ánk", 11, 2),
        Among("énk", 11, 3),
        Among("ünk", 11, 1),
        Among("uk", -1, 1),
        Among("juk", 16, 1),
        Among("ájuk", 17, 2),
        Among("ük", -1, 1),
        Among("jük", 19, 1),
        Among("éjük", 20, 3),
        Among("m", -1, 1),
        Among("am", 22, 1),
        Among("em", 22, 1),
        Among("om", 22, 1),
        Among("ám", 22, 2),
        Among("ém", 22, 3),
        Among("o", -1, 1),
        Among("á", -1, 2),
        Among("é", -1, 3)
    ]

    a_10 = [
        Among("id", -1, 1),
        Among("aid", 0, 1),
        Among("jaid", 1, 1),
        Among("eid", 0, 1),
        Among("jeid", 3, 1),
        Among("áid", 0, 2),
        Among("éid", 0, 3),
        Among("i", -1, 1),
        Among("ai", 7, 1),
        Among("jai", 8, 1),
        Among("ei", 7, 1),
        Among("jei", 10, 1),
        Among("ái", 7, 2),
        Among("éi", 7, 3),
        Among("itek", -1, 1),
        Among("eitek", 14, 1),
        Among("jeitek", 15, 1),
        Among("éitek", 14, 3),
        Among("ik", -1, 1),
        Among("aik", 18, 1),
        Among("jaik", 19, 1),
        Among("eik", 18, 1),
        Among("jeik", 21, 1),
        Among("áik", 18, 2),
        Among("éik", 18, 3),
        Among("ink", -1, 1),
        Among("aink", 25, 1),
        Among("jaink", 26, 1),
        Among("eink", 25, 1),
        Among("jeink", 28, 1),
        Among("áink", 25, 2),
        Among("éink", 25, 3),
        Among("aitok", -1, 1),
        Among("jaitok", 32, 1),
        Among("áitok", -1, 2),
        Among("im", -1, 1),
        Among("aim", 35, 1),
        Among("jaim", 36, 1),
        Among("eim", 35, 1),
        Among("jeim", 38, 1),
        Among("áim", 35, 2),
        Among("éim", 35, 3)
    ]


class lab0(BaseException): pass


class lab1(BaseException): pass
