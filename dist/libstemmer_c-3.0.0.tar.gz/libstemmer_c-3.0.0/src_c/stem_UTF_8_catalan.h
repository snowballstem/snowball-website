/* Generated from catalan.sbl by Snowball 3.0.0 - https://snowballstem.org/ */

#ifdef __cplusplus
extern "C" {
#endif

extern struct SN_env * catalan_UTF_8_create_env(void);
extern void catalan_UTF_8_close_env(struct SN_env * z);

extern int catalan_UTF_8_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif

