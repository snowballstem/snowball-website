/* Generated from turkish.sbl by Snowball 3.0.0 - https://snowballstem.org/ */

#ifdef __cplusplus
extern "C" {
#endif

extern struct SN_env * turkish_UTF_8_create_env(void);
extern void turkish_UTF_8_close_env(struct SN_env * z);

extern int turkish_UTF_8_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif

