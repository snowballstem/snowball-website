#include <assert.h>
#include <ctype.h> /* for toupper */
#include <stdio.h> /* for fprintf etc */
#include <stdlib.h> /* for exit */
#include <string.h> /* for strlen */
#include "header.h"

/* prototype functions for recursive use: */

static void generate(struct generator * g, struct node * p);
static void w(struct generator * g, const char * s);
static void writef(struct generator * g, const char * s, struct node * p);

/* Write routines for items from the syntax tree */

static void write_relop(struct generator * g, int relop) {
    // Relational operators are the same as C.
    write_c_relop(g, relop);
}

static void write_varname(struct generator * g, struct name * p) {
    // We use the same naming scheme for both global and local variables.
    write_char(g, "SbirrG"[p->type]);
    write_char(g, '_');
    write_s(g, p->s);
}

/* Reference to variable, e.g. when assigning to or using in an expression. */
static void write_varref(struct generator * g, struct name * p) {
    if (p->type >= t_routine || p->local_to == NULL) {
        write_string(g, "context.");
    }
    write_varname(g, p);
}

static void write_literal_string(struct generator * g, symbol * p) {
    int i = 0;
    write_char(g, '"');
    while (i < SIZE(p)) {
        int ch;
        i += get_utf8(p + i, &ch);
        // Write out ASCII and lower Unicode printables as literal characters.
        // Use escapes for anything over 0x590 as a crude way to avoid LTR
        // characters affecting the rendering of source character order in
        // confusing ways.
        if ((32 <= ch && ch < 127) || (0xa0 < ch && ch < 0x590)) {
            if (ch == '"' || ch == '\\') write_char(g, '\\');
            write_wchar_as_utf8(g, ch);
        } else {
            write_string(g, "\\u");
            write_hex4(g, ch);
        }
    }
    write_char(g, '"');
}

static void write_comment(struct generator * g, struct node * p) {
    if (!g->options->comments) return;
    /* FIXME could use Go //line syntax if we had original filename */
    write_margin(g);
    write_string(g, "// ");
    write_comment_content(g, p, NULL);
    write_newline(g);
}

static void write_block_start(struct generator * g) {
    w(g, "~+{~N");
}

static void write_block_end(struct generator * g) {
    w(g, "~-~M}~N");
}

static void write_savecursor(struct generator * g, struct node * p,
                             struct str * savevar) {
    g->B[0] = str_data(savevar);
    g->S[1] = "";
    if (p->mode != m_forward) g->S[1] = "env.Limit - ";
    writef(g, "~Mvar ~B0 = ~S1env.Cursor~N", p);
}

static void append_restore_string(struct node * p, struct str * out, struct str * savevar) {
    str_append_string(out, "env.Cursor = ");
    if (p->mode != m_forward) str_append_string(out, "env.Limit - ");
    str_append(out, savevar);
}

static void write_restorecursor(struct generator * g, struct node * p, struct str * savevar) {
    write_margin(g);
    append_restore_string(p, g->outbuf, savevar);
    write_newline(g);
}

static void write_inc_cursor(struct generator * g, struct node * p) {
    write_margin(g);
    write_string(g, p->mode == m_forward ? "env.NextChar()" : "env.PrevChar()");
    write_newline(g);
}

static void wsetlab_begin(struct generator * g, int n) {
    g->I[0] = n;
    w(g, "~-~Mlab~I0:~N~+~Mfor {~N~+");
}

static void wsetlab_end(struct generator * g, int n) {
    if (!g->unreachable) {
        g->I[0] = n;
        w(g, "~Mbreak lab~I0~N");
    }
    w(g, "~-~M}~N");
}

static void wgotol(struct generator * g, int n) {
    g->I[0] = n;
    w(g, "~Mbreak lab~I0~N");
    g->unreachable = true;
}

static void write_failure(struct generator * g) {
    if (str_len(g->failure_str) != 0) {
        write_margin(g);
        write_str(g, g->failure_str);
        write_newline(g);
    }
    switch (g->failure_label) {
        case x_return:
            w(g, "~Mreturn false");
            break;
        default:
            w(g, "~Mbreak lab");
            write_int(g, g->failure_label);
    }
    write_newline(g);
    g->unreachable = true;
}

static void write_failure_if(struct generator * g, const char * s, struct node * p) {
    writef(g, "~Mif ", p);
    writef(g, s, p);
    writef(g, " ", p);
    write_block_start(g);
    write_failure(g);
    write_block_end(g);
    g->unreachable = false;
}

/* if at limit fail */
static void write_check_limit(struct generator * g, struct node * p) {
    if (p->mode == m_forward) {
        write_failure_if(g, "env.Cursor >= env.Limit", p);
    } else {
        write_failure_if(g, "env.Cursor <= env.LimitBackward", p);
    }
}

/* Formatted write. */
static void writef(struct generator * g, const char * input, struct node * p) {
    int i = 0;

    while (input[i]) {
        int ch = input[i++];
        if (ch != '~') {
            write_char(g, ch);
            continue;
        }
        ch = input[i++];
        switch (ch) {
            case '~': write_char(g, '~'); continue;
            case 'f': write_block_start(g);
                      write_failure(g);
                      g->unreachable = false;
                      write_block_end(g);
                      continue;
            case 'M': write_margin(g); continue;
            case 'N': write_newline(g); continue;
            case '{': write_block_start(g); continue;
            case '}': write_block_end(g); continue;
            case 'S': {
                int j = input[i++] - '0';
                if (j < 0 || j > (int)(sizeof(g->S) / sizeof(g->S[0]))) {
                    printf("Invalid escape sequence ~%c%c in writef(g, \"%s\", p)\n",
                           ch, input[i - 1], input);
                    exit(1);
                }
                write_string(g, g->S[j]);
                continue;
            }
            case 'B': {
                int j = input[i++] - '0';
                if (j < 0 || j > (int)(sizeof(g->B) / sizeof(g->B[0])))
                    goto invalid_escape2;
                write_s(g, g->B[j]);
                continue;
            }
            case 'I': {
                int j = input[i++] - '0';
                if (j < 0 || j > (int)(sizeof(g->I) / sizeof(g->I[0])))
                    goto invalid_escape2;
                write_int(g, g->I[j]);
                continue;
            }
            case 'E': {
                // Write an external name.
                if (g->options->externals_prefix) {
                    write_string(g, g->options->externals_prefix);
                }
                char save_initial = p->name->s[0];
                p->name->s[0] = toupper(save_initial);
                write_s(g, p->name->s);
                p->name->s[0] = save_initial;
                continue;
            }
            case 'V':
                write_varref(g, p->name);
                continue;
            case 'W':
                write_varname(g, p->name);
                continue;
            case 'L':
                write_literal_string(g, p->literalstring);
                continue;
            case '+': g->margin++; continue;
            case '-': g->margin--; continue;
            case 'n': write_s(g, g->options->name); continue;
            default:
                printf("Invalid escape sequence ~%c in writef(g, \"%s\", p)\n",
                       ch, input);
                exit(1);
            invalid_escape2:
                printf("Invalid escape sequence ~%c%c in writef(g, \"%s\", p)\n",
                       ch, input[i - 1], input);
                exit(1);
        }
    }
}

static void w(struct generator * g, const char * s) {
    writef(g, s, NULL);
}

static void generate_AE(struct generator * g, struct node * p) {
    const char * s;
    switch (p->type) {
        case c_name:
            write_varref(g, p->name);
            break;
        case c_number:
            write_int(g, p->number);
            break;
        case c_maxint:
            write_string(g, "snowballRuntime.MaxInt");
            break;
        case c_minint:
            write_string(g, "snowballRuntime.MinInt");
            break;
        case c_neg:
            write_char(g, '-');
            generate_AE(g, p->right);
            break;
        case c_multiply:
            s = " * ";
            goto label0;
        case c_divide:
            s = " / ";
            goto label0;
        case c_plus:
            s = " + ";
            goto label0;
        case c_minus:
            s = " - ";
        label0:
            write_char(g, '(');
            generate_AE(g, p->left);
            write_string(g, s);
            generate_AE(g, p->right);
            write_char(g, ')');
            break;
        case c_cursor:
            w(g, "env.Cursor");
            break;
        case c_limit:
            w(g, p->mode == m_forward ? "env.Limit" : "env.LimitBackward");
            break;
        case c_len:
            w(g, "snowballRuntime.RuneCountInString(env.Current())");
            break;
        case c_size:
            w(g, "len(env.Current())");
            break;
        case c_lenof:
            writef(g, "snowballRuntime.RuneCountInString(~V)", p);
            break;
        case c_sizeof:
            writef(g, "len(~V)", p);
            break;
    }
}

static void generate_bra(struct generator * g, struct node * p) {
    write_comment(g, p);
    p = p->left;
    while (p) {
        generate(g, p);
        p = p->right;
    }
}

static void generate_and(struct generator * g, struct node * p) {
    struct str * savevar = NULL;
    if (K_needed_for_and(p->left)) {
        savevar = vars_newname(g);
    }

    write_comment(g, p);

    if (savevar) {
        write_savecursor(g, p, savevar);
    }

    p = p->left;
    while (p) {
        generate(g, p);
        if (g->unreachable) break;
        if (savevar && p->right != NULL) write_restorecursor(g, p, savevar);
        p = p->right;
    }

    if (savevar) {
        str_delete(savevar);
    }
}

static void generate_or(struct generator * g, struct node * p) {
    struct str * savevar = NULL;
    if (K_needed_for_or(p->left)) {
        savevar = vars_newname(g);
    }

    int a0 = g->failure_label;
    struct str * a1 = str_copy(g->failure_str);

    int out_lab = new_label(g);
    bool end_unreachable = true;

    write_comment(g, p);
    wsetlab_begin(g, out_lab);

    if (savevar && K_needed_node_on_f(p)) {
        write_savecursor(g, p, savevar);
    }

    p = p->left;
    str_clear(g->failure_str);

    if (p == NULL) {
        /* p should never be NULL after an or: there should be at least two
         * sub nodes. */
        fprintf(stderr, "Error: \"or\" node without children nodes.");
        exit(1);
    }
    while (p->right != NULL) {
        int label = new_label(g);
        g->failure_label = label;
        wsetlab_begin(g, label);
        generate(g, p);
        if (!g->unreachable) {
            wgotol(g, out_lab);
            end_unreachable = false;
        }

        wsetlab_end(g, label);
        g->unreachable = false;
        if (savevar) {
            write_restorecursor(g, p, savevar);
        }
        p = p->right;
    }

    g->failure_label = a0;
    str_delete(g->failure_str);
    g->failure_str = a1;

    generate(g, p);

    wsetlab_end(g, out_lab);
    if (!end_unreachable) {
        g->unreachable = false;
    }

    if (savevar) {
        str_delete(savevar);
    }
}

static void generate_backwards(struct generator * g, struct node * p) {
    write_comment(g, p);
    writef(g,"~Menv.LimitBackward = env.Cursor~N"
             "~Menv.Cursor = env.Limit~N", p);
    generate(g, p->left);
    w(g, "~Menv.Cursor = env.LimitBackward~N");
}

static void generate_not(struct generator * g, struct node * p) {
    struct str * savevar = NULL;
    if (K_needed_node_on_f(p->left)) {
        savevar = vars_newname(g);
    }

    int a0 = g->failure_label;
    struct str * a1 = str_copy(g->failure_str);
    int label = new_label(g);
    g->failure_label = label;

    write_comment(g, p);
    if (savevar) {
        write_savecursor(g, p, savevar);
    }

    str_clear(g->failure_str);

    wsetlab_begin(g, label);

    generate(g, p->left);

    g->failure_label = a0;
    str_delete(g->failure_str);
    g->failure_str = a1;

    if (!g->unreachable) write_failure(g);

    wsetlab_end(g, label);

    g->unreachable = false;

    if (savevar) {
        write_restorecursor(g, p, savevar);
        str_delete(savevar);
    }
}

static void generate_try(struct generator * g, struct node * p) {
    struct str * savevar = NULL;
    if (K_needed(p->left)) {
        savevar = vars_newname(g);
    }

    int label = new_label(g);
    g->failure_label = label;
    str_clear(g->failure_str);

    write_comment(g, p);
    if (savevar) {
        write_savecursor(g, p, savevar);
        append_restore_string(p, g->failure_str, savevar);
    }

    wsetlab_begin(g, label);
    generate(g, p->left);
    wsetlab_end(g, label);
    g->unreachable = false;

    if (savevar) {
        str_delete(savevar);
    }
}

static void generate_set(struct generator * g, struct node * p) {
    write_comment(g, p);
    writef(g, "~M~V = true~N", p);
}

static void generate_unset(struct generator * g, struct node * p) {
    write_comment(g, p);
    writef(g, "~M~V = false~N", p);
}

static void generate_fail(struct generator * g, struct node * p) {
    write_comment(g, p);
    generate(g, p->left);
    if (!g->unreachable) write_failure(g);
}

/* generate_test() also implements 'reverse' */
static void generate_test(struct generator * g, struct node * p) {
    struct str * savevar = NULL;
    if (K_needed(p->left)) {
        savevar = vars_newname(g);
    }

    write_comment(g, p);

    if (savevar) {
        write_savecursor(g, p, savevar);
    }

    generate(g, p->left);

    if (savevar) {
        if (!g->unreachable) {
            write_restorecursor(g, p, savevar);
        }
        str_delete(savevar);
    }
}

static void generate_do(struct generator * g, struct node * p) {
    struct str * savevar = NULL;
    if (K_needed(p->left)) {
        savevar = vars_newname(g);
    }

    write_comment(g, p);
    if (savevar) {
        write_savecursor(g, p, savevar);
    }

    if (p->left->type == c_call) {
        /* Optimise do <call> */
        write_comment(g, p->left);
        writef(g, "~M~W(env, context)~N", p->left);
    } else {
        int label = new_label(g);
        g->failure_label = label;
        str_clear(g->failure_str);

        wsetlab_begin(g, label);
        generate(g, p->left);

        wsetlab_end(g, label);
        g->unreachable = false;
    }

    if (savevar) {
        write_restorecursor(g, p, savevar);
        str_delete(savevar);
    }
}

static void generate_next(struct generator * g, struct node * p) {
    write_comment(g, p);
    write_check_limit(g, p);
    write_inc_cursor(g, p);
}

static void generate_GO_grouping(struct generator * g, struct node * p, int is_goto, int complement) {
    write_comment(g, p);

    struct grouping * q = p->name->grouping;
    g->S[0] = p->mode == m_forward ? "" : "B";
    g->S[1] = complement ? "In" : "Out";
    g->I[0] = q->smallest_ch;
    g->I[1] = q->largest_ch;
    write_failure_if(g, "!env.Go~S1Grouping~S0(~W, ~I0, ~I1)", p);
    if (!is_goto) {
        w(g, p->mode == m_forward ? "~Menv.NextChar()~N" : "~Menv.PrevChar()~N");
    }
}

static void generate_GO(struct generator * g, struct node * p, int is_goto) {
    write_comment(g, p);

    int a0 = g->failure_label;
    struct str * a1 = str_copy(g->failure_str);

    bool end_unreachable = false;

    int golab = new_label(g);
    g->I[0] = golab;
    w(g, "~-~Mgolab~I0:~N~+~Mfor {~N~+");

    struct str * savevar = NULL;
    if (is_goto || repeat_restore(p->left)) {
        savevar = vars_newname(g);
        write_savecursor(g, p, savevar);
    }

    int label = new_label(g);
    g->failure_label = label;
    str_clear(g->failure_str);
    wsetlab_begin(g, g->failure_label);
    generate(g, p->left);

    if (g->unreachable) {
        /* Cannot break out of this loop: therefore the code after the
         * end of the loop is unreachable.*/
        end_unreachable = true;
    } else {
        /* include for goto; omit for gopast */
        if (is_goto) write_restorecursor(g, p, savevar);
        g->I[0] = golab;
        w(g, "~Mbreak golab~I0~N");
        g->unreachable = true;
    }
    wsetlab_end(g, g->failure_label);
    g->unreachable = false;
    if (savevar) {
        write_restorecursor(g, p, savevar);
        str_delete(savevar);
    }

    g->failure_label = a0;
    str_delete(g->failure_str);
    g->failure_str = a1;

    write_check_limit(g, p);
    write_inc_cursor(g, p);
    write_block_end(g);
    g->unreachable = end_unreachable;
}

static void generate_loop(struct generator * g, struct node * p) {
    write_comment(g, p);
    struct str * loopvar = vars_newname(g);
    w(g, "~Mfor _ = range make([]struct{}, ");
    generate_AE(g, p->AE);
    writef(g, ") {~N~+", p);

    generate(g, p->left);

    w(g, "~}");
    str_delete(loopvar);
    g->unreachable = false;
}

static void generate_repeat_or_atleast(struct generator * g, struct node * p, struct str * loopvar) {
    int replab = new_label(g);
    g->I[0] = replab;
    writef(g, "~-~Mreplab~I0:~N~+~Mfor {~N~+", p);

    struct str * savevar = NULL;
    if (repeat_restore(p->left)) {
        savevar = vars_newname(g);
        write_savecursor(g, p, savevar);
    }

    int label = new_label(g);
    g->failure_label = label;
    str_clear(g->failure_str);
    g->I[0] = g->failure_label;
    w(g, "~-~Mlab~I0:~N~+~Mfor range [2]struct{}{} {~N~+");
    generate(g, p->left);

    if (!g->unreachable) {
        if (loopvar != NULL) {
            g->B[0] = str_data(loopvar);
            w(g, "~M~B0--~N");
        }

        g->I[0] = replab;
        w(g, "~Mcontinue replab~I0~N");
    }
    w(g, "~-~M}~N");
    g->unreachable = false;

    if (savevar) {
        write_restorecursor(g, p, savevar);
        str_delete(savevar);
    }

    g->I[0] = replab;
    w(g, "~Mbreak replab~I0~N~-~M}~N");
}

static void generate_repeat(struct generator * g, struct node * p) {
    write_comment(g, p);
    generate_repeat_or_atleast(g, p, NULL);
}

static void generate_atleast(struct generator * g, struct node * p) {
    write_comment(g, p);

    struct str * loopvar = vars_newname(g);
    g->B[0] = str_data(loopvar);
    w(g, "~Mvar ~B0 = ");
    generate_AE(g, p->AE);
    w(g, "~N");
    {
        int a0 = g->failure_label;
        struct str * a1 = str_copy(g->failure_str);

        generate_repeat_or_atleast(g, p, loopvar);

        g->failure_label = a0;
        str_delete(g->failure_str);
        g->failure_str = a1;
    }
    g->B[0] = str_data(loopvar);
    write_failure_if(g, "~B0 > 0", p);
    str_delete(loopvar);
}

static void generate_tomark(struct generator * g, struct node * p) {
    write_comment(g, p);
    g->S[0] = p->mode == m_forward ? ">" : "<";

    w(g, "~Mif env.Cursor ~S0 "); generate_AE(g, p->AE); writef(g, " ", p);
    write_block_start(g);
    write_failure(g);
    write_block_end(g);
    g->unreachable = false;
    w(g, "~Menv.Cursor = "); generate_AE(g, p->AE); writef(g, "~N", p);
}

static void generate_hop(struct generator * g, struct node * p) {
    write_comment(g, p);
    // Generate the AE to a temporary block so we can substitute it in
    // write_failure_if().
    struct str * ae = str_new();
    struct str * s = g->outbuf;
    g->outbuf = ae;
    generate_AE(g, p->AE);
    g->outbuf = s;
    g->B[0] = str_data(ae);
    g->S[0] = p->mode == m_forward ? "" : "Back";
    g->S[1] = p->AE->type == c_number ? "" : "Checked";
    write_failure_if(g, "!env.Hop~S0~S1(~B0)", p);
    str_delete(ae);
}

static void generate_delete(struct generator * g, struct node * p) {
    write_comment(g, p);
    writef(g, "~Menv.SliceDel()~N", p);
}

static void generate_tolimit(struct generator * g, struct node * p) {
    write_comment(g, p);
    g->S[0] = p->mode == m_forward ? "env.Limit" : "env.LimitBackward";
    writef(g, "~Menv.Cursor = ~S0~N", p);
}

static void generate_leftslice(struct generator * g, struct node * p) {
    write_comment(g, p);
    g->S[0] = p->mode == m_forward ? "env.Bra" : "env.Ket";
    writef(g, "~M~S0 = env.Cursor~N", p);
}

static void generate_rightslice(struct generator * g, struct node * p) {
    write_comment(g, p);
    g->S[0] = p->mode == m_forward ? "env.Ket" : "env.Bra";
    writef(g, "~M~S0 = env.Cursor~N", p);
}

static void generate_assignto(struct generator * g, struct node * p) {
    write_comment(g, p);
    writef(g, "~M~V = env.AssignTo()~N", p);
}

static void generate_sliceto(struct generator * g, struct node * p) {
    write_comment(g, p);
    writef(g, "~M~V = env.SliceTo()~N", p);
}

static void generate_address(struct generator * g, struct node * p) {
    symbol * b = p->literalstring;
    if (b != NULL) {
        write_literal_string(g, b);
    } else {
        write_varref(g, p->name);
    }
}

static void generate_insert(struct generator * g, struct node * p, int style) {
    write_margin(g);
    write_block_start(g);
    write_comment(g, p);
    int keep_c = style == c_attach;
    if (p->mode == m_backward) keep_c = !keep_c;
    if (keep_c) w(g, "~Mvar c = env.Cursor~N");
    w(g, "~Mbra, ket := env.Cursor, env.Cursor~N");
    writef(g, "~Menv.Insert(bra, ket, ", p);
    generate_address(g, p);
    writef(g, ")~N", p);
    if (keep_c) w(g, "~Menv.Cursor = c~N");
    write_block_end(g);
}

static void generate_stringassign(struct generator * g, struct node * p) {
    write_margin(g);
    write_block_start(g);
    write_comment(g, p);
    int keep_c = p->mode == m_forward; /* like 'attach' */
    if (keep_c) {
        writef(g, "~Mvar c = env.Cursor~N", p);
    }
    if (p->mode == m_forward) {
        writef(g, "~Menv.Insert(env.Cursor, env.Limit, ", p);
    } else {
        writef(g, "~Menv.Insert(env.LimitBackward, env.Cursor, ", p);
    }
    generate_address(g, p);
    writef(g, ")~N", p);
    if (keep_c) {
        w(g, "~Menv.Cursor = c~N");
    }
    write_block_end(g);
}

static void generate_slicefrom(struct generator * g, struct node * p) {
    write_comment(g, p);
    w(g, "~Menv.SliceFrom(");
    generate_address(g, p);
    writef(g, ")~N", p);
}

static void generate_setlimit(struct generator * g, struct node * p) {
    write_comment(g, p);
    struct str * varname = vars_newname(g);

    if (p->left && p->left->type == c_tomark) {
        /* Special case for:
         *
         *   setlimit tomark AE for C
         *
         * All uses of setlimit in the current stemmers we ship follow this
         * pattern, and by special-casing we can avoid having to save and
         * restore c.
         */
        struct node * q = p->left;
        write_comment(g, q);

        g->S[0] = q->mode == m_forward ? ">" : "<";
        w(g, "~Mif env.Cursor ~S0 "); generate_AE(g, q->AE); w(g, " ");
        write_block_start(g);
        write_failure(g);
        write_block_end(g);
        g->unreachable = false;

        g->B[0] = str_data(varname);
        if (p->mode == m_forward) {
            w(g, "~Mvar ~B0 = env.Limit~N");
            w(g, "~Menv.Limit = ");
            generate_AE(g, q->AE);
            w(g, "~N");
            w(g, "~M~B0 -= env.Limit~N");
        } else {
            w(g, "~Mvar ~B0 = env.LimitBackward~N");
            w(g, "~Menv.LimitBackward = ");
            generate_AE(g, q->AE);
            w(g, "~N");
        }

        if (p->mode == m_forward) {
            str_assign(g->failure_str, "env.Limit += ");
            str_append(g->failure_str, varname);
        } else {
            str_assign(g->failure_str, "env.LimitBackward = ");
            str_append(g->failure_str, varname);
        }
    } else {
        struct str * savevar = vars_newname(g);
        write_savecursor(g, p, savevar);

        generate(g, p->left);

        if (!g->unreachable) {
            g->B[0] = str_data(varname);
            if (p->mode == m_forward) {
                w(g, "~Mvar ~B0 = env.Limit - env.Cursor~N");
                w(g, "~Menv.Limit = env.Cursor~N");
            } else {
                w(g, "~Mvar ~B0 = env.LimitBackward~N");
                w(g, "~Menv.LimitBackward = env.Cursor~N");
            }
            write_restorecursor(g, p, savevar);

            if (p->mode == m_forward) {
                str_assign(g->failure_str, "env.Limit += ");
                str_append(g->failure_str, varname);
            } else {
                str_assign(g->failure_str, "env.LimitBackward = ");
                str_append(g->failure_str, varname);
            }
        }
        str_delete(savevar);
    }

    if (!g->unreachable) {
        generate(g, p->aux);

        if (!g->unreachable) {
            write_margin(g);
            write_str(g, g->failure_str);
            write_newline(g);
        }
    }
    str_delete(varname);
}

/* dollar sets snowball up to operate on a string variable as if it were the
 * current string */
static void generate_dollar(struct generator * g, struct node * p) {
    write_comment(g, p);

    int a0 = g->failure_label;
    struct str * a1 = str_copy(g->failure_str);
    int label = new_label(g);
    g->failure_label = label;
    str_clear(g->failure_str);

    struct str * savevar = vars_newname(g);
    g->B[0] = str_data(savevar);
    writef(g, "~Mvar ~B0 = env.Clone()~N"
              "~Menv.SetCurrent(~V)~N", p);
    if (p->left->possible_signals == -1) {
        /* Assume failure. */
        w(g, "~Mvar ~B0_f = true~N");
    }

    wsetlab_begin(g, g->failure_label);

    generate(g, p->left);

    if (!g->unreachable && p->left->possible_signals == -1) {
        /* Mark success. */
        g->B[0] = str_data(savevar);
        w(g, "~M~B0_f = false~N");
    }

    wsetlab_end(g, g->failure_label);

    g->failure_label = a0;
    str_delete(g->failure_str);
    g->failure_str = a1;

    g->B[0] = str_data(savevar);
    /* Update string variable; restore env. */
    writef(g, "~M~V = env.Current()~N"
              "~M*env = *~B0~N", p);

    if (p->left->possible_signals == 0) {
        // p->left always signals f.
        write_failure(g);
    } else if (p->left->possible_signals == -1) {
        write_failure_if(g, "~B0_f", p);
    }

    str_delete(savevar);
}

static void generate_integer_assign(struct generator * g, struct node * p, const char * s) {
    write_comment(g, p);
    g->S[0] = s;
    writef(g, "~M~V ~S0 ", p);
    generate_AE(g, p->AE);
    w(g, "~N");
}

static void generate_integer_test(struct generator * g, struct node * p) {
    write_comment(g, p);
    int relop = p->type;
    int optimise_to_return = tailcallable(g, p);
    if (optimise_to_return) {
        w(g, "~Mreturn ");
        p->right = NULL;
    } else {
        w(g, "~Mif ");
        // We want the inverse of the snowball test here.
        relop ^= 1;
    }
    generate_AE(g, p->left);
    write_relop(g, relop);
    generate_AE(g, p->AE);
    if (optimise_to_return) {
        w(g, "~N");
    } else {
        write_char(g, ' ');
        write_block_start(g);
        write_failure(g);
        write_block_end(g);
        g->unreachable = false;
    }
}

static void generate_call(struct generator * g, struct node * p) {
    int signals = p->name->definition->possible_signals;
    write_comment(g, p);
    if (tailcallable(g, p)) {
        /* Tail call. */
        writef(g, "~Mreturn ~W(env, context)~N", p);
        p->right = NULL;
        return;
    }
    if (just_return_on_fail(g) && signals == 0) {
        /* Always fails. */
        writef(g, "~Mreturn ~W(env, context)~N", p);
        return;
    }
    if (signals == 1) {
        /* Always succeeds. */
        writef(g, "~M~W(env, context)~N", p);
    } else if (signals == 0) {
        /* Always fails. */
        writef(g, "~M~W(env, context)~N", p);
        write_failure(g);
    } else {
        write_failure_if(g, "!~W(env, context)", p);
    }
}

static void generate_grouping(struct generator * g, struct node * p, int complement) {
    write_comment(g, p);

    struct grouping * q = p->name->grouping;
    g->S[0] = p->mode == m_forward ? "" : "B";
    g->S[1] = complement ? "Out" : "In";
    g->I[0] = q->smallest_ch;
    g->I[1] = q->largest_ch;
    if (tailcallable(g, p)) {
        writef(g, "~Mreturn env.~S1Grouping~S0(~W, ~I0, ~I1);~N", p);
        p->right = NULL;
    } else {
        write_failure_if(g, "!env.~S1Grouping~S0(~W, ~I0, ~I1)", p);
    }
}

static void generate_namedstring(struct generator * g, struct node * p) {
    write_comment(g, p);
    g->S[0] = p->mode == m_forward ? "" : "B";
    if (tailcallable(g, p)) {
        writef(g, "~Mreturn env.EqS~S0(~V)~N", p);
        p->right = NULL;
    } else {
        write_failure_if(g, "!env.EqS~S0(~V)", p);
    }
}

static void generate_literalstring(struct generator * g, struct node * p) {
    write_comment(g, p);
    g->S[0] = p->mode == m_forward ? "" : "B";
    if (tailcallable(g, p)) {
        writef(g, "~Mreturn env.EqS~S0(~L)~N", p);
        p->right = NULL;
    } else {
        write_failure_if(g, "!env.EqS~S0(~L)", p);
    }
}

static void generate_setup_context(struct generator * g) {
    if (g->analyser->variable_count == 0) {
        w(g, "~Mvar context = &Context{}~N");
        w(g, "~M_ = context~N");
        return;
    }

    w(g, "~Mvar context = &Context{~+~N");
    for (struct name * q = g->analyser->names; q; q = q->next) {
        if (q->local_to) continue;
        switch (q->type) {
            case t_string:
                write_margin(g);
                write_varname(g, q);
                w(g, ": \"\",~N");
                break;
            case t_integer:
                write_margin(g);
                write_varname(g, q);
                w(g, ": 0,~N");
                break;
            case t_boolean:
                write_margin(g);
                write_varname(g, q);
                w(g, ": false,~N");
                break;
        }
    }
    w(g, "~-~M}~N");
    w(g, "~M_ = context~N");
}

static void generate_define(struct generator * g, struct node * p) {
    write_newline(g);
    write_comment(g, p);

    struct name * q = p->name;
    if (q->type == t_routine) {
        writef(g, "~Mfunc ~W(env *snowballRuntime.Env, ctx interface{}) bool {~+~N", p);
        w(g, "~Mcontext := ctx.(*Context)~N");
        w(g, "~M_ = context~N");
    } else {
        writef(g, "~Mfunc ~E(env *snowballRuntime.Env) bool {~+~N", p);
        generate_setup_context(g);
        if (q->used != q->definition) {
            // This external needs to be callable as a routine, so generate
            // the actual code like a routine with an external which just
            // forwards to that.
            writef(g, "~Mreturn ~W(env, context)~N", p);
            w(g, "~-~M}~N");
            writef(g, "~Mfunc ~W(env *snowballRuntime.Env, ctx interface{}) bool {~+~N", p);
            w(g, "~Mcontext := ctx.(*Context)~N");
            w(g, "~M_ = context~N");
        }
    }

    if (q->amongvar_needed) {
        w(g, "~Mvar among_var int32~N");
    }

    /* Declare localised variables. */
    for (struct name * name = g->analyser->names; name; name = name->next) {
        if (name->local_to == q) {
            switch (name->type) {
                case t_string:
                    w(g, "~Mvar ");
                    write_varname(g, name);
                    w(g, " string~N");
                    break;
                case t_integer:
                    w(g, "~Mvar ");
                    write_varname(g, name);
                    w(g, " int~N");
                    break;
                case t_boolean:
                    w(g, "~Mvar ");
                    write_varname(g, name);
                    w(g, " bool~N");
                    break;
            }
        }
    }

    g->next_label = 0;
    g->var_number = 0;

    str_clear(g->failure_str);
    g->failure_label = x_return;
    g->unreachable = false;

    /* Generate function body. */
    generate(g, p->left);
    if (p->left->right) {
        assert(p->left->right->type == c_functionend);
        if (p->left->possible_signals) {
            generate(g, p->left->right);
        }
    }
    w(g, "~-~M}~N");
}

static void generate_functionend(struct generator * g, struct node * p) {
    (void)p;
    w(g, "~Mreturn true~N");
}

static void generate_substring(struct generator * g, struct node * p) {
    write_comment(g, p);

    struct among * x = p->among;

    g->S[0] = p->mode == m_forward ? "" : "B";
    g->I[0] = x->number;

    if (x->amongvar_needed) {
        writef(g, "~Mamong_var = env.FindAmong~S0(A_~I0, context)~N", p);
        if (!x->always_matches) {
            write_failure_if(g, "among_var == 0", p);
        }
    } else if (x->always_matches) {
        writef(g, "~Menv.FindAmong~S0(A_~I0, context)~N", p);
    } else if (x->command_count == 0 && tailcallable(g, p)) {
        writef(g, "~Mreturn env.FindAmong~S0(A_~I0, context) != 0~N", p);
        x->node->right = NULL;
        g->unreachable = true;
    } else {
        write_failure_if(g, "env.FindAmong~S0(A_~I0, context) == 0", p);
    }
}

static void generate_among(struct generator * g, struct node * p) {
    struct among * x = p->among;

    if (x->substring == NULL) {
        generate_substring(g, p);
    } else {
        write_comment(g, p);
    }

    if (x->command_count == 1 && x->nocommand_count == 0) {
        /* Only one outcome ("no match" already handled). */
        generate(g, x->commands[0]);
    } else if (x->command_count > 0) {
        w(g, "~Mswitch among_var {~N");
        for (int i = 1; i <= x->command_count; i++) {
            g->I[0] = i;
            w(g, "~Mcase ~I0:~N~+");
            generate(g, x->commands[i - 1]);
            w(g, "~-");
            g->unreachable = false;
        }
        w(g, "~M}~N");
    }
}

static void generate_booltest(struct generator * g, struct node * p, int inverted) {
    write_comment(g, p);
    if (tailcallable(g, p)) {
        // Optimise at end of function.
        if (inverted) {
            writef(g, "~Mreturn !~V~N", p);
        } else {
            writef(g, "~Mreturn ~V~N", p);
        }
        p->right = NULL;
        return;
    }
    if (inverted) {
        write_failure_if(g, "~V", p);
    } else {
        write_failure_if(g, "!~V", p);
    }
}

static void generate_false(struct generator * g, struct node * p) {
    write_comment(g, p);
    write_failure(g);
}

static void generate_debug(struct generator * g, struct node * p) {
    write_comment(g, p);
    g->I[0] = g->debug_count++;
    g->I[1] = p->line_number;
    writef(g, "~Menv.Debug(~I0, ~I1)~N", p);
}

static void generate(struct generator * g, struct node * p) {
    if (g->unreachable) return;

    int a0 = g->failure_label;
    struct str * a1 = str_copy(g->failure_str);

    switch (p->type) {
        case c_define:        generate_define(g, p); break;
        case c_bra:           generate_bra(g, p); break;
        case c_and:           generate_and(g, p); break;
        case c_or:            generate_or(g, p); break;
        case c_backwards:     generate_backwards(g, p); break;
        case c_not:           generate_not(g, p); break;
        case c_set:           generate_set(g, p); break;
        case c_unset:         generate_unset(g, p); break;
        case c_try:           generate_try(g, p); break;
        case c_fail:          generate_fail(g, p); break;
        case c_reverse:
        case c_test:          generate_test(g, p); break;
        case c_do:            generate_do(g, p); break;
        case c_goto:          generate_GO(g, p, 1); break;
        case c_gopast:        generate_GO(g, p, 0); break;
        case c_goto_grouping: generate_GO_grouping(g, p, 1, 0); break;
        case c_gopast_grouping:
                              generate_GO_grouping(g, p, 0, 0); break;
        case c_goto_non:      generate_GO_grouping(g, p, 1, 1); break;
        case c_gopast_non:    generate_GO_grouping(g, p, 0, 1); break;
        case c_repeat:        generate_repeat(g, p); break;
        case c_loop:          generate_loop(g, p); break;
        case c_atleast:       generate_atleast(g, p); break;
        case c_tomark:        generate_tomark(g, p); break;
        case c_hop:           generate_hop(g, p); break;
        case c_delete:        generate_delete(g, p); break;
        case c_next:          generate_next(g, p); break;
        case c_tolimit:       generate_tolimit(g, p); break;
        case c_leftslice:     generate_leftslice(g, p); break;
        case c_rightslice:    generate_rightslice(g, p); break;
        case c_assignto:      generate_assignto(g, p); break;
        case c_sliceto:       generate_sliceto(g, p); break;
        case c_stringassign:  generate_stringassign(g, p); break;
        case c_insert:
        case c_attach:        generate_insert(g, p, p->type); break;
        case c_slicefrom:     generate_slicefrom(g, p); break;
        case c_setlimit:      generate_setlimit(g, p); break;
        case c_dollar:        generate_dollar(g, p); break;
        case c_assign:        generate_integer_assign(g, p, "="); break;
        case c_plusassign:    generate_integer_assign(g, p, "+="); break;
        case c_minusassign:   generate_integer_assign(g, p, "-="); break;
        case c_multiplyassign:generate_integer_assign(g, p, "*="); break;
        case c_divideassign:  generate_integer_assign(g, p, "/="); break;
        case c_eq:
        case c_ne:
        case c_gt:
        case c_ge:
        case c_lt:
        case c_le:
            generate_integer_test(g, p);
            break;
        case c_call:          generate_call(g, p); break;
        case c_grouping:      generate_grouping(g, p, false); break;
        case c_non:           generate_grouping(g, p, true); break;
        case c_name:          generate_namedstring(g, p); break;
        case c_literalstring: generate_literalstring(g, p); break;
        case c_among:         generate_among(g, p); break;
        case c_substring:     generate_substring(g, p); break;
        case c_booltest:      generate_booltest(g, p, false); break;
        case c_not_booltest:  generate_booltest(g, p, true); break;
        case c_false:         generate_false(g, p); break;
        case c_true:          break;
        case c_debug:         generate_debug(g, p); break;
        case c_functionend:   generate_functionend(g, p); break;
        default: fprintf(stderr, "%d encountered\n", p->type);
                 exit(1);
    }

    g->failure_label = a0;
    str_delete(g->failure_str);
    g->failure_str = a1;
}

static void generate_class_begin(struct generator * g) {
    w(g, "package ");
    write_string(g, g->options->package);
    w(g, "~N~N");

    w(g, "import (~N");
    w(g, "~+~MsnowballRuntime \"");
    write_string(g, g->options->go_snowball_runtime);
    w(g, "\"~N~-)~N~N");
}

static void generate_among_table(struct generator * g, struct among * x) {
    write_comment(g, x->node);

    struct amongvec * v = x->b;

    g->I[0] = x->number;
    w(g, "~Mvar A_~I0 = []*snowballRuntime.Among{~N~+");

    for (int i = 0; i < x->literalstring_count; i++) {
        g->I[0] = v[i].i;
        g->I[1] = v[i].result;

        w(g, "~M&snowballRuntime.Among{Str: ");
        write_literal_string(g, v[i].b);
        w(g, ", A: ~I0, B: ~I1, F: ");

        if (v[i].function != NULL) {
            write_varname(g, v[i].function);
        } else {
            w(g, "nil");
        }
        w(g, "},~N");
    }
    w(g, "~-~M}~N~N");
}

static void generate_amongs(struct generator * g) {
    for (struct among * x = g->analyser->amongs; x; x = x->next) {
        generate_among_table(g, x);
    }
}

static void set_bit(symbol * b, int i) { b[i >> 3] |= 1 << (i & 7); }

static void generate_grouping_table(struct generator * g, struct grouping * q) {
    int range = q->largest_ch - q->smallest_ch + 1;
    int size = (range + 7) / 8;  /* assume 8 bits per symbol */
    symbol * b = q->b;
    symbol * map = create_b(size);

    for (int i = 0; i < size; i++) map[i] = 0;

    for (int i = 0; i < SIZE(b); i++) set_bit(map, b[i] - q->smallest_ch);

    w(g, "~Mvar ");
    write_varname(g, q->name);
    w(g, " = []byte{");
    for (int i = 0; i < size; i++) {
        if (i) w(g, ", ");
        write_int(g, map[i]);
    }
    w(g, "}~N~N");

    lose_b(map);
}

static void generate_groupings(struct generator * g) {
    for (struct grouping * q = g->analyser->groupings; q; q = q->next) {
        generate_grouping_table(g, q);
    }
}

static void generate_members(struct generator * g) {
    w(g, "type Context struct {~+~N");
    for (struct name * q = g->analyser->names; q; q = q->next) {
        if (q->local_to) continue;
        switch (q->type) {
            case t_string:
                write_margin(g);
                write_varname(g, q);
                w(g, " string~N");
                break;
            case t_integer:
                write_margin(g);
                write_varname(g, q);
                w(g, " int~N");
                break;
            case t_boolean:
                write_margin(g);
                write_varname(g, q);
                w(g, " bool~N");
                break;
        }
    }
    w(g, "~-}~N");
}

static void generate_methods(struct generator * g) {
    for (struct node * p = g->analyser->program; p; p = p->right) {
        generate(g, p);
        g->unreachable = false;
    }
}

extern void generate_program_go(struct generator * g) {
    g->margin_indent = "\t";

    g->outbuf = str_new();
    g->failure_str = str_new();

    write_start_comment(g, "//! ", NULL);
    generate_class_begin(g);

    generate_amongs(g);
    generate_groupings(g);

    generate_members(g);
    generate_methods(g);

    output_str(g->options->output_src, g->outbuf);
    str_delete(g->failure_str);
    str_delete(g->outbuf);
}
