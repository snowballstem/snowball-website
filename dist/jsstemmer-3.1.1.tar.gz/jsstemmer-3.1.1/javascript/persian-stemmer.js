// Generated from persian.sbl by Snowball 3.1.1 - https://snowballstem.org/

// deno-lint-ignore-file ban-unused-ignore no-constant-condition no-empty prefer-const

const a_0 = [
    ["", 7],
    [" ", 6, 1],
    ["\u0623", 4, 2],
    ["\u0624", 5, 3],
    ["\u0625", 4, 4],
    ["\u0626", 2, 5],
    ["\u0629", 3, 6],
    ["\u0643", 1, 7],
    ["\u064A", 2, 8],
    ["\u06C1", 3, 9],
    ["\u200D", 6, 10]
];

const a_1 = [
    ["\u0645\u06CC\u200C", 2],
    ["\u0646\u0645\u06CC\u200C", 1]
];

const a_2 = [
    ["\u0633\u062A\u0627\u0646", -1],
    ["\u0631\u0627\u0646", -1],
    ["\u0633\u0627\u0646", -1],
    ["\u0648\u0627\u0646", -1]
];

const a_3 = [
    ["\u0622\u0630\u0631\u0628\u0627\u06CC\u062C\u0627\u0646", 1],
    ["\u0647\u0645\u062F\u0627\u0646", 1],
    ["\u062E\u0627\u0646\u062F\u0627\u0646", 1],
    ["\u0632\u0646\u062F\u0627\u0646", 1],
    ["\u0645\u06CC\u0632\u0627\u0646", 1],
    ["\u062F\u0631\u062E\u0634\u0627\u0646", 1],
    ["\u0622\u062A\u0634\u0641\u0634\u0627\u0646", 1],
    ["\u0646\u0634\u0627\u0646", 1],
    ["\u06A9\u0647\u06A9\u0634\u0627\u0646", 1],
    ["\u0627\u06CC\u0634\u0627\u0646", 1],
    ["\u067E\u0631\u06CC\u0634\u0627\u0646", 1],
    ["\u0633\u0644\u0637\u0627\u0646", 1],
    ["\u06AF\u06CC\u0644\u0627\u0646", 1],
    ["\u0633\u0627\u062E\u062A\u0645\u0627\u0646", 1],
    ["\u0631\u0645\u0627\u0646", 1],
    ["\u062F\u0631\u0645\u0627\u0646", 1, 1],
    ["\u0642\u0647\u0631\u0645\u0627\u0646", 1, 2],
    ["\u06A9\u0631\u0645\u0627\u0646", 1, 3],
    ["\u0633\u0627\u0632\u0645\u0627\u0646", 1],
    ["\u0647\u0645\u0632\u0645\u0627\u0646", 1],
    ["\u0622\u0633\u0645\u0627\u0646", 1],
    ["\u0622\u0644\u0645\u0627\u0646", 1],
    ["\u0645\u0633\u0644\u0645\u0627\u0646", 1],
    ["\u0627\u06CC\u0645\u0627\u0646", 1],
    ["\u0633\u0644\u06CC\u0645\u0627\u0646", 1],
    ["\u067E\u06CC\u0645\u0627\u0646", 1],
    ["\u0644\u0628\u0646\u0627\u0646", 1],
    ["\u06CC\u0648\u0646\u0627\u0646", 1],
    ["\u0627\u0635\u0641\u0647\u0627\u0646", 1],
    ["\u0627\u0645\u06A9\u0627\u0646", 1],
    ["\u067E\u0627\u06CC\u0627\u0646", 1],
    ["\u0628\u06CC\u0627\u0646", 1],
    ["\u062C\u0631\u06CC\u0627\u0646", 1]
];

const a_4 = [
    ["\u0627\u0633\u0627\u062A\u06CC\u062F", 2],
    ["\u0627\u062E\u0628\u0627\u0631", 1]
];

const /** Array<string> */ as_4 = ["\u062E\u0628\u0631", "\u0627\u0633\u062A\u0627\u062F"];

const a_5 = [
    ["\u0647\u0627", 1],
    ["\u0627\u062A", 1],
    ["\u06CC\u062A", 1],
    ["\u0645\u0646\u062F", 1],
    ["\u0648\u0627\u0631", 1],
    ["\u06AF\u0627\u0631", 1],
    ["\u062A\u0631", 2],
    ["\u0627\u0634", 1],
    ["\u0627\u0645", 1],
    ["\u0627\u0646", 1],
    ["\u0628\u0627\u0646", 1, 1],
    ["\u06AF\u0627\u0646", 1, 2],
    ["\u06CC\u0627\u0646", 1, 3],
    ["\u06CC\u0646", 1],
    ["\u062A\u0631\u06CC\u0646", 1, 1],
    ["\u06AF\u0627\u0647", 1],
    ["\u0627\u0646\u0647", 1],
    ["\u0646\u0627\u06A9", 1],
    ["\u0647\u0627\u06CC", 1],
    ["\u0627\u0646\u06CC", 1],
    ["\u06AF\u06CC", 1],
    ["\u06CC\u06CC", 1]
];

const a_6 = [
    ["\u0627\u0633\u062A", 1],
    ["\u0627\u0646\u062F", 1],
    ["\u06CC\u062F", 1],
    ["\u0627\u06CC\u062F", 1, 1],
    ["\u0627\u0633", 1],
    ["\u06CC\u0645", 1],
    ["\u0627\u06CC\u0645", 1, 1],
    ["\u0627\u06CC", 1]
];

const a_7 = [
    ["\u062F", 1],
    ["\u0627\u0646\u062F", 1, 1],
    ["\u0631\u0641\u062A\u0627\u0646\u062F", 2, 1],
    ["\u06CC\u062F", 1, 3],
    ["\u0631\u0641\u062A\u06CC\u062F", 2, 1],
    ["\u0645", 1],
    ["\u0627\u0645", 1, 1],
    ["\u0631\u0641\u062A\u0645", 2, 2],
    ["\u06CC\u0645", 1, 3],
    ["\u0631\u0641\u062A\u06CC\u0645", 2, 1],
    ["\u0627\u0646", 3],
    ["\u062A\u0647", 5],
    ["\u062F\u0647", 4],
    ["\u0646\u062F\u0647", 3, 1],
    ["\u0631\u0641\u062A\u06CC", 2]
];

import B from './base-stemmer.js'

export default class extends B {

    #I_p1/** number */ = 0;
    #B_remove_verb_person_endings/** boolean */ = false;
    #B_saw_present_prefix/** boolean */ = false;


    /** @return {boolean} */
    #r_Normalize_Characters() {
        let /** number */ a;
        while (true) {
            const /** number */ v_1 = this.c;
            // deno-lint-ignore no-unused-labels
            lab0: {
                this.bra = this.c;
                a = this.find_among(a_0);
                this.ket = this.c;
                switch (a) {
                    case 1: {
                        this.slice_from("\u06A9");
                        break;
                    }
                    case 2: {
                        this.slice_from("\u06CC");
                        break;
                    }
                    case 3: {
                        this.slice_from("\u0647");
                        break;
                    }
                    case 4: {
                        this.slice_from("\u0627");
                        break;
                    }
                    case 5: {
                        this.slice_from("\u0648");
                        break;
                    }
                    case 6: {
                        this.slice_del();
                        break;
                    }
                    case 7: {
                        if (this.c >= this.limit) break lab0;
                        this.c++;
                        break;
                    }
                }
                continue;
            }
            this.c = v_1;
            break;
        }
        return true;
    }

    /** @return {boolean} */
    #r_Prefixes() {
        let /** number */ a;
        this.bra = this.c;
        a = this.find_among(a_1);
        if (a === 0) return false;
        this.ket = this.c;
        switch (a) {
            case 1: {
                if (this.c + 2 > this.limit) return false;
                this.c += 2;
                this.#B_saw_present_prefix = true;
                break;
            }
            case 2: {
                if (this.c + 2 > this.limit) return false;
                this.c += 2;
                this.slice_del();
                this.#B_saw_present_prefix = true;
                break;
            }
        }
        return true;
    }

    /** @return {boolean} */
    #r_Delete_ZWNJ() {
        while (true) {
            const /** number */ v_1 = this.c;
            // deno-lint-ignore no-unused-labels
            lab0: {
                // deno-lint-ignore no-unused-labels
                golab1: while (true)
                {
                    const /** number */ v_2 = this.c;
                    // deno-lint-ignore no-unused-labels
                    lab2: {
                        this.bra = this.c;
                        if (!(this.eq_s("\u200C"))) break lab2;
                        this.ket = this.c;
                        this.slice_del();
                        this.c = v_2;
                        break golab1;
                    }
                    this.c = v_2;
                    if (this.c >= this.limit) break lab0;
                    this.c++;
                }
                continue;
            }
            this.c = v_1;
            break;
        }
        return true;
    }

    /** @return {boolean} */
    #r_R1() {
        return this.#I_p1 <= this.c;
    }

    /** @return {boolean} */
    #r_Protect_Lexical_AN() {
        {
            const /** number */ v_1 = this.limit - this.c;
            // deno-lint-ignore no-unused-labels
            lab0: {
                if (!this.#r_AN_Exception()) break lab0;
                return false;
            }
            this.c = this.limit - v_1;
        }
        {
            const /** number */ v_2 = this.limit - this.c;
            // deno-lint-ignore no-unused-labels
            lab1: {
                if (this.find_among_b(a_2) === 0) break lab1;
                return false;
            }
            this.c = this.limit - v_2;
        }
        return true;
    }

    /** @return {boolean} */
    #r_AN_Exception() {
        if (this.find_among_b(a_3) === 0) return false;
        if (this.c > this.limit_backward) return false;
        return true;
    }

    /** @return {boolean} */
    #r_Irregular_Noun() {
        let /** number */ a;
        this.ket = this.c;
        a = this.find_among_b(a_4);
        if (a === 0) return false;
        this.bra = this.c;
        this.slice_from(as_4[a - 1]);
        return true;
    }

    /** @return {boolean} */
    #r_Stem_Noun_or_Adjective() {
        let /** number */ a;
        // deno-lint-ignore no-unused-labels
        lab0: {
            const /** number */ v_1 = this.limit - this.c;
            // deno-lint-ignore no-unused-labels
            lab1: {
                if (!this.#r_Irregular_Noun()) break lab1;
                break lab0;
            }
            this.c = this.limit - v_1;
            if (this.c < this.#I_p1) return false;
            const /** number */ v_2 = this.limit_backward;
            this.limit_backward = this.#I_p1;
            this.ket = this.c;
            a = this.find_among_b(a_5);
            if (a === 0) {
                this.limit_backward = v_2;
                return false;
            }
            this.bra = this.c;
            switch (a) {
                case 1: {
                    this.slice_del();
                    break;
                }
                case 2: {
                    if (this.c <= this.limit_backward) {
                        this.limit_backward = v_2;
                        return false;
                    }
                    this.slice_del();
                    break;
                }
            }
            this.limit_backward = v_2;
        }
        return true;
    }

    /** @return {boolean} */
    #r_Stem_Verb() {
        let /** number */ a;
        // deno-lint-ignore no-unused-labels
        lab0: {
            const /** number */ v_1 = this.limit - this.c;
            // deno-lint-ignore no-unused-labels
            lab1: {
                this.ket = this.c;
                if (this.find_among_b(a_6) === 0) break lab1;
                this.bra = this.c;
                if (!this.#r_R1()) break lab1;
                this.slice_del();
                break lab0;
            }
            this.c = this.limit - v_1;
            this.ket = this.c;
            a = this.find_among_b(a_7);
            if (a === 0) return false;
            this.bra = this.c;
            switch (a) {
                case 1: {
                    if (!this.#B_remove_verb_person_endings) return false;
                    if (!this.#r_R1()) return false;
                    this.slice_del();
                    break;
                }
                case 2: {
                    this.slice_from("\u0631\u0641\u062A");
                    break;
                }
                case 3: {
                    if (!this.#r_R1()) return false;
                    this.slice_del();
                    this.#B_remove_verb_person_endings = true;
                    break;
                }
                case 4: {
                    if (this.c <= this.limit_backward) return false;
                    this.slice_from("\u062F");
                    this.#B_remove_verb_person_endings = true;
                    break;
                }
                case 5: {
                    if (this.c <= this.limit_backward) return false;
                    this.slice_from("\u062A");
                    this.#B_remove_verb_person_endings = true;
                    break;
                }
            }
        }
        return true;
    }

    /** @return {boolean} */
    #stem() {
        this.#B_saw_present_prefix = false;
        const /** number */ v_1 = this.c;
        this.#r_Normalize_Characters();
        this.c = v_1;
        const /** number */ v_2 = this.c;
        this.#r_Prefixes();
        this.c = v_2;
        const /** number */ v_3 = this.c;
        this.#r_Delete_ZWNJ();
        this.c = v_3;
        this.#I_p1 = this.limit;
        const /** number */ v_4 = this.c;
        // deno-lint-ignore no-unused-labels
        lab0: {
            if (this.c + 3 > this.limit) break lab0;
            this.c += 3;
            this.#I_p1 = this.c;
        }
        this.c = v_4;
        this.limit_backward = this.c; this.c = this.limit;
        while (true) {
            const /** number */ v_5 = this.limit - this.c;
            // deno-lint-ignore no-unused-labels
            lab1: {
                const /** number */ v_6 = this.limit - this.c;
                this.#B_remove_verb_person_endings = false;
                // deno-lint-ignore no-unused-labels
                lab2: {
                    if (!this.#B_saw_present_prefix) break lab2;
                    this.#B_remove_verb_person_endings = true;
                }
                if (!this.#r_Protect_Lexical_AN()) break lab1;
                // deno-lint-ignore no-unused-labels
                lab3: {
                    const /** number */ v_7 = this.limit - this.c;
                    // deno-lint-ignore no-unused-labels
                    lab4: {
                        if (!this.#r_Stem_Noun_or_Adjective()) break lab4;
                        break lab3;
                    }
                    this.c = this.limit - v_7;
                    if (!this.#r_Stem_Verb()) break lab1;
                }
                this.c = this.limit - v_6;
                continue;
            }
            this.c = this.limit - v_5;
            break;
        }
        this.c = this.limit_backward;
        return true;
    }

    /**@return{string}*/
    stem(/**string*/input) {
        this.setCurrent(input);
        this.#stem();
        return this.getCurrent();
    }

    stemWord = this.stem;
}

