// Generated from porter.sbl by Snowball 3.1.1 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from porter.sbl by Snowball 3.1.1 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class porterStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("s", -1, 3),
        new Among("ies", 0, 2),
        new Among("sses", 0, 1),
        new Among("ss", 0, -1)
    };

    private final static Among[] a_1 = {
        new Among("", -1, 3),
        new Among("bb", 0, 2),
        new Among("dd", 0, 2),
        new Among("ff", 0, 2),
        new Among("gg", 0, 2),
        new Among("bl", 0, 1),
        new Among("mm", 0, 2),
        new Among("nn", 0, 2),
        new Among("pp", 0, 2),
        new Among("rr", 0, 2),
        new Among("at", 0, 1),
        new Among("tt", 0, 2),
        new Among("iz", 0, 1)
    };

    private final static Among[] a_2 = {
        new Among("ed", -1, 2),
        new Among("eed", 0, 1),
        new Among("ing", -1, 2)
    };

    private final static Among[] a_3 = {
        new Among("anci", -1, 3),
        new Among("enci", -1, 2),
        new Among("abli", -1, 4),
        new Among("eli", -1, 6),
        new Among("alli", -1, 9),
        new Among("ousli", -1, 11),
        new Among("entli", -1, 5),
        new Among("aliti", -1, 9),
        new Among("biliti", -1, 13),
        new Among("iviti", -1, 12),
        new Among("tional", -1, 1),
        new Among("ational", 10, 8),
        new Among("alism", -1, 9),
        new Among("ation", -1, 8),
        new Among("ization", 13, 7),
        new Among("izer", -1, 7),
        new Among("ator", -1, 8),
        new Among("iveness", -1, 12),
        new Among("fulness", -1, 10),
        new Among("ousness", -1, 11)
    };

    private final static Among[] a_4 = {
        new Among("icate", -1, 2),
        new Among("ative", -1, 3),
        new Among("alize", -1, 1),
        new Among("iciti", -1, 2),
        new Among("ical", -1, 2),
        new Among("ful", -1, 3),
        new Among("ness", -1, 3)
    };

    private final static Among[] a_5 = {
        new Among("ic", -1, 1),
        new Among("ance", -1, 1),
        new Among("ence", -1, 1),
        new Among("able", -1, 1),
        new Among("ible", -1, 1),
        new Among("ate", -1, 1),
        new Among("ive", -1, 1),
        new Among("ize", -1, 1),
        new Among("iti", -1, 1),
        new Among("al", -1, 1),
        new Among("ism", -1, 1),
        new Among("ion", -1, 2),
        new Among("er", -1, 1),
        new Among("ous", -1, 1),
        new Among("ant", -1, 1),
        new Among("ent", -1, 1),
        new Among("ment", 15, 1),
        new Among("ement", 16, 1),
        new Among("ou", -1, 1)
    };

    private static final char[] g_v = {17, 65, 16, 1 };

    private static final char[] g_v_WXY = {1, 17, 65, 208, 1 };

    private int I_p2;
    private int I_p1;


    private boolean r_shortv() {
        if (!(out_grouping_b(g_v_WXY, 89, 121)))
        {
            return false;
        }
        if (!(in_grouping_b(g_v, 97, 121)))
        {
            return false;
        }
        return out_grouping_b(g_v, 97, 121);
    }

    private boolean r_R1() {
        return I_p1 <= cursor;
    }

    private boolean r_R2() {
        return I_p2 <= cursor;
    }

    private boolean r_Step_1a() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_0);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("ss");
                break;
            case 2:
                slice_from("i");
                break;
            case 3:
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_Step_1b() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("ee");
                break;
            case 2:
                int v_1 = limit - cursor;
                if (!go_out_grouping_b(g_v, 97, 121))
                {
                    return false;
                }
                cursor--;
                cursor = limit - v_1;
                slice_del();
                int v_2 = limit - cursor;
                among_var = find_among_b(a_1);
                cursor = limit - v_2;
                switch (among_var) {
                    case 1:
                        {
                            int c = cursor;
                            insert(cursor, cursor, "e");
                            cursor = c;
                        }
                        break;
                    case 2:
                        ket = cursor;
                        if (cursor <= limit_backward)
                        {
                            return false;
                        }
                        cursor--;
                        bra = cursor;
                        slice_del();
                        break;
                    case 3:
                        if (cursor != I_p1)
                        {
                            return false;
                        }
                        int v_3 = limit - cursor;
                        if (!r_shortv())
                        {
                            return false;
                        }
                        cursor = limit - v_3;
                        {
                            int c = cursor;
                            insert(cursor, cursor, "e");
                            cursor = c;
                        }
                        break;
                }
                break;
        }
        return true;
    }

    private boolean r_Step_1c() {
        ket = cursor;
        lab0: {
            lab1: {
                if (!(eq_s_b("y")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("Y")))
            {
                return false;
            }
        }
        bra = cursor;
        if (!go_out_grouping_b(g_v, 97, 121))
        {
            return false;
        }
        cursor--;
        slice_from("i");
        return true;
    }

    private boolean r_Step_2() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_3);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("tion");
                break;
            case 2:
                slice_from("ence");
                break;
            case 3:
                slice_from("ance");
                break;
            case 4:
                slice_from("able");
                break;
            case 5:
                slice_from("ent");
                break;
            case 6:
                slice_from("e");
                break;
            case 7:
                slice_from("ize");
                break;
            case 8:
                slice_from("ate");
                break;
            case 9:
                slice_from("al");
                break;
            case 10:
                slice_from("ful");
                break;
            case 11:
                slice_from("ous");
                break;
            case 12:
                slice_from("ive");
                break;
            case 13:
                slice_from("ble");
                break;
        }
        return true;
    }

    private boolean r_Step_3() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_4);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("al");
                break;
            case 2:
                slice_from("ic");
                break;
            case 3:
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_Step_4() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_5);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R2())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                lab0: {
                    lab1: {
                        if (!(eq_s_b("s")))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    if (!(eq_s_b("t")))
                    {
                        return false;
                    }
                }
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_Step_5a() {
        ket = cursor;
        if (!(eq_s_b("e")))
        {
            return false;
        }
        bra = cursor;
        lab0: {
            lab1: {
                if (!r_R2())
                {
                    break lab1;
                }
                break lab0;
            }
            if (!r_R1())
            {
                return false;
            }
            {
                int v_1 = limit - cursor;
                lab2: {
                    if (!r_shortv())
                    {
                        break lab2;
                    }
                    return false;
                }
                cursor = limit - v_1;
            }
        }
        slice_del();
        return true;
    }

    private boolean r_Step_5b() {
        ket = cursor;
        if (!(eq_s_b("l")))
        {
            return false;
        }
        bra = cursor;
        if (!r_R2())
        {
            return false;
        }
        if (!(eq_s_b("l")))
        {
            return false;
        }
        slice_del();
        return true;
    }

    @Override
    public boolean stem() {
        boolean B_Y_found;
        B_Y_found = false;
        int v_1 = cursor;
        lab0: {
            bra = cursor;
            if (!(eq_s("y")))
            {
                break lab0;
            }
            ket = cursor;
            slice_from("Y");
            B_Y_found = true;
        }
        cursor = v_1;
        int v_2 = cursor;
        lab1: {
            while (true)
            {
                int v_3 = cursor;
                lab2: {
                    golab3: while (true)
                    {
                        int v_4 = cursor;
                        lab4: {
                            if (!(in_grouping(g_v, 97, 121)))
                            {
                                break lab4;
                            }
                            bra = cursor;
                            if (!(eq_s("y")))
                            {
                                break lab4;
                            }
                            ket = cursor;
                            cursor = v_4;
                            break golab3;
                        }
                        cursor = v_4;
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    slice_from("Y");
                    B_Y_found = true;
                    continue;
                }
                cursor = v_3;
                break;
            }
        }
        cursor = v_2;
        I_p1 = limit;
        I_p2 = limit;
        int v_5 = cursor;
        lab5: {
            if (!go_out_grouping(g_v, 97, 121))
            {
                break lab5;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 121))
            {
                break lab5;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 121))
            {
                break lab5;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 121))
            {
                break lab5;
            }
            cursor++;
            I_p2 = cursor;
        }
        cursor = v_5;
        limit_backward = cursor;
        cursor = limit;
        int v_6 = limit - cursor;
        r_Step_1a();
        cursor = limit - v_6;
        int v_7 = limit - cursor;
        r_Step_1b();
        cursor = limit - v_7;
        int v_8 = limit - cursor;
        r_Step_1c();
        cursor = limit - v_8;
        int v_9 = limit - cursor;
        r_Step_2();
        cursor = limit - v_9;
        int v_10 = limit - cursor;
        r_Step_3();
        cursor = limit - v_10;
        int v_11 = limit - cursor;
        r_Step_4();
        cursor = limit - v_11;
        int v_12 = limit - cursor;
        r_Step_5a();
        cursor = limit - v_12;
        int v_13 = limit - cursor;
        r_Step_5b();
        cursor = limit - v_13;
        cursor = limit_backward;
        int v_14 = cursor;
        lab6: {
            if (!B_Y_found)
            {
                break lab6;
            }
            while (true)
            {
                int v_15 = cursor;
                lab7: {
                    golab8: while (true)
                    {
                        int v_16 = cursor;
                        lab9: {
                            bra = cursor;
                            if (!(eq_s("Y")))
                            {
                                break lab9;
                            }
                            ket = cursor;
                            cursor = v_16;
                            break golab8;
                        }
                        cursor = v_16;
                        if (cursor >= limit)
                        {
                            break lab7;
                        }
                        cursor++;
                    }
                    slice_from("y");
                    continue;
                }
                cursor = v_15;
                break;
            }
        }
        cursor = v_14;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof porterStemmer;
    }

    @Override
    public int hashCode() {
        return porterStemmer.class.getName().hashCode();
    }

}
