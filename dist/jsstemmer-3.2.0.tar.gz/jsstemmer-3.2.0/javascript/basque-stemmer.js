// Generated from basque.sbl by Snowball 3.2.0 - https://snowballstem.org/

// deno-lint-ignore-file ban-unused-ignore no-constant-condition no-empty prefer-const

const a_0 = [
    ["idea", 1],
    ["bidea", 1, 1],
    ["kidea", 1, 2],
    ["pidea", 1, 3],
    ["kundea", 1],
    ["galea", 1],
    ["tailea", 1],
    ["tzailea", 1],
    ["gunea", 1],
    ["kunea", 1],
    ["tzaga", 1],
    ["gaia", 1],
    ["aldia", 1],
    ["taldia", 1, 1],
    ["karia", 1],
    ["garria", 2],
    ["karria", 1],
    ["ka", 1],
    ["tzaka", 1, 1],
    ["la", 1],
    ["mena", 1],
    ["pena", 1],
    ["kina", 1],
    ["ezina", 1],
    ["tezina", 1, 1],
    ["kuna", 1],
    ["tuna", 1],
    ["kizuna", 1],
    ["era", 1],
    ["bera", 1, 1],
    ["arabera", -1, 1],
    ["kera", 1, 3],
    ["pera", 1, 4],
    ["orra", 1],
    ["korra", 1, 1],
    ["dura", 1],
    ["gura", 1],
    ["kura", 1],
    ["tura", 1],
    ["eta", 1],
    ["keta", 1, 1],
    ["gailua", 1],
    ["eza", 1],
    ["erreza", 1, 1],
    ["tza", 2],
    ["gaitza", 1, 1],
    ["kaitza", 1, 2],
    ["kuntza", 1, 3],
    ["ide", 1],
    ["bide", 1, 1],
    ["kide", 1, 2],
    ["pide", 1, 3],
    ["kunde", 1],
    ["tzake", 1],
    ["tzeke", 1],
    ["le", 1],
    ["gale", 1, 1],
    ["taile", 1, 2],
    ["tzaile", 1, 3],
    ["gune", 1],
    ["kune", 1],
    ["tze", 1],
    ["atze", 1, 1],
    ["gai", 1],
    ["aldi", 1],
    ["taldi", 1, 1],
    ["ki", 1],
    ["ari", 1],
    ["kari", 1, 1],
    ["lari", 1, 2],
    ["tari", 1, 3],
    ["etari", 1, 1],
    ["garri", 2],
    ["karri", 1],
    ["arazi", 1],
    ["tarazi", 1, 1],
    ["an", 1],
    ["ean", 1, 1],
    ["rean", 1, 1],
    ["kan", 1, 3],
    ["etan", 1, 4],
    ["atseden", -1],
    ["men", 1],
    ["pen", 1],
    ["kin", 1],
    ["rekin", 1, 1],
    ["ezin", 1],
    ["tezin", 1, 1],
    ["tun", 1],
    ["kizun", 1],
    ["go", 1],
    ["ago", 1, 1],
    ["tio", 1],
    ["dako", 1],
    ["or", 1],
    ["kor", 1, 1],
    ["tzat", 1],
    ["du", 1],
    ["gailu", 1],
    ["tu", 1],
    ["atu", 1, 1],
    ["aldatu", 1, 1],
    ["tatu", 1, 2],
    ["baditu", -1, 4],
    ["ez", 1],
    ["errez", 1, 1],
    ["tzez", 1, 2],
    ["gaitz", 1],
    ["kaitz", 1]
];

const a_1 = [
    ["ada", 1],
    ["kada", 1, 1],
    ["anda", 1],
    ["denda", 1],
    ["gabea", 1],
    ["kabea", 1],
    ["aldea", 1],
    ["kaldea", 1, 1],
    ["taldea", 1, 2],
    ["ordea", 1],
    ["zalea", 1],
    ["tzalea", 1, 1],
    ["gilea", 1],
    ["emea", 1],
    ["kumea", 1],
    ["nea", 1],
    ["enea", 1, 1],
    ["zionea", 1, 2],
    ["unea", 1, 3],
    ["gunea", 1, 1],
    ["pea", 1],
    ["aurrea", 1],
    ["tea", 1],
    ["kotea", 1, 1],
    ["artea", 1, 2],
    ["ostea", 1, 3],
    ["etxea", 1],
    ["ga", 1],
    ["anga", 1, 1],
    ["gaia", 1],
    ["aldia", 1],
    ["taldia", 1, 1],
    ["handia", 1],
    ["mendia", 1],
    ["geia", 1],
    ["egia", 1],
    ["degia", 1, 1],
    ["tegia", 1, 2],
    ["nahia", 1],
    ["ohia", 1],
    ["kia", 1],
    ["tokia", 1, 1],
    ["oia", 1],
    ["koia", 1, 1],
    ["aria", 1],
    ["karia", 1, 1],
    ["laria", 1, 2],
    ["taria", 1, 3],
    ["eria", 1],
    ["keria", 1, 1],
    ["teria", 1, 2],
    ["garria", 2],
    ["larria", 1],
    ["kirria", 1],
    ["duria", 1],
    ["asia", 1],
    ["tia", 1],
    ["ezia", 1],
    ["bizia", 1],
    ["ontzia", 1],
    ["ka", 1],
    ["joka", 3, 1],
    ["aurka", -1, 2],
    ["ska", 1, 3],
    ["xka", 1, 4],
    ["zka", 1, 5],
    ["gibela", 1],
    ["gela", 1],
    ["kaila", 1],
    ["skila", 1],
    ["tila", 1],
    ["ola", 1],
    ["na", 1],
    ["kana", 1, 1],
    ["ena", 1, 2],
    ["garrena", 1, 1],
    ["gerrena", 1, 2],
    ["urrena", 1, 3],
    ["zaina", 1, 6],
    ["tzaina", 1, 1],
    ["kina", 1, 8],
    ["mina", 1, 9],
    ["garna", 1, 10],
    ["una", 1, 11],
    ["duna", 1, 1],
    ["asuna", 1, 2],
    ["tasuna", 1, 1],
    ["ondoa", 1],
    ["kondoa", 1, 1],
    ["ngoa", 1],
    ["zioa", 1],
    ["koa", 1],
    ["takoa", 1, 1],
    ["zkoa", 1, 2],
    ["noa", 1],
    ["zinoa", 1, 1],
    ["aroa", 1],
    ["taroa", 1, 1],
    ["zaroa", 1, 2],
    ["eroa", 1],
    ["oroa", 1],
    ["osoa", 1],
    ["toa", 1],
    ["ttoa", 1, 1],
    ["ztoa", 1, 2],
    ["txoa", 1],
    ["tzoa", 1],
    ["\u00F1oa", 1],
    ["ra", 1],
    ["ara", 1, 1],
    ["dara", 1, 1],
    ["liara", 1, 2],
    ["tiara", 1, 3],
    ["tara", 1, 4],
    ["etara", 1, 1],
    ["tzara", 1, 6],
    ["bera", 1, 8],
    ["kera", 1, 9],
    ["pera", 1, 10],
    ["ora", 2, 11],
    ["tzarra", 1, 12],
    ["korra", 1, 13],
    ["tra", 1, 14],
    ["sa", 1],
    ["osa", 1, 1],
    ["ta", 1],
    ["eta", 1, 1],
    ["keta", 1, 1],
    ["sta", 1, 3],
    ["dua", 1],
    ["mendua", 1, 1],
    ["ordua", 1, 2],
    ["lekua", 1],
    ["burua", 1],
    ["durua", 1],
    ["tsua", 1],
    ["tua", 1],
    ["mentua", 1, 1],
    ["estua", 1, 2],
    ["txua", 1],
    ["zua", 1],
    ["tzua", 1, 1],
    ["za", 1],
    ["eza", 1, 1],
    ["eroza", 1, 2],
    ["tza", 2, 3],
    ["koitza", 1, 1],
    ["antza", 1, 2],
    ["gintza", 1, 3],
    ["kintza", 1, 4],
    ["kuntza", 1, 5],
    ["gabe", 1],
    ["kabe", 1],
    ["kide", 1],
    ["alde", 1],
    ["kalde", 1, 1],
    ["talde", 1, 2],
    ["orde", 1],
    ["ge", 1],
    ["zale", 1],
    ["tzale", 1, 1],
    ["gile", 1],
    ["eme", 1],
    ["kume", 1],
    ["ne", 1],
    ["zione", 1, 1],
    ["une", 1, 2],
    ["gune", 1, 1],
    ["pe", 1],
    ["aurre", 1],
    ["te", 1],
    ["kote", 1, 1],
    ["arte", 1, 2],
    ["oste", 1, 3],
    ["etxe", 1],
    ["gai", 1],
    ["di", 1],
    ["aldi", 1, 1],
    ["taldi", 1, 1],
    ["geldi", -1, 3],
    ["handi", 1, 4],
    ["mendi", 1, 5],
    ["gei", 1],
    ["egi", 1],
    ["degi", 1, 1],
    ["tegi", 1, 2],
    ["nahi", 1],
    ["ohi", 1],
    ["ki", 1],
    ["toki", 1, 1],
    ["oi", 1],
    ["goi", 1, 1],
    ["koi", 1, 2],
    ["ari", 1],
    ["kari", 1, 1],
    ["lari", 1, 2],
    ["tari", 1, 3],
    ["garri", 2],
    ["larri", 1],
    ["kirri", 1],
    ["duri", 1],
    ["asi", 1],
    ["ti", 1],
    ["ontzi", 1],
    ["\u00F1i", 1],
    ["ak", 1],
    ["ek", 1],
    ["tarik", 1],
    ["gibel", 1],
    ["ail", 1],
    ["kail", 1, 1],
    ["kan", 1],
    ["tan", 1],
    ["etan", 1, 1],
    ["en", 4],
    ["ren", 2, 1],
    ["garren", 1, 1],
    ["gerren", 1, 2],
    ["urren", 1, 3],
    ["ten", 4, 5],
    ["tzen", 4, 6],
    ["zain", 1],
    ["tzain", 1, 1],
    ["kin", 1],
    ["min", 1],
    ["dun", 1],
    ["asun", 1],
    ["tasun", 1, 1],
    ["aizun", 1],
    ["ondo", 1],
    ["kondo", 1, 1],
    ["go", 1],
    ["ngo", 1, 1],
    ["zio", 1],
    ["ko", 1],
    ["trako", 5, 1],
    ["tako", 1, 2],
    ["etako", 1, 1],
    ["eko", 1, 4],
    ["tariko", 1, 5],
    ["sko", 1, 6],
    ["tuko", 1, 7],
    ["minutuko", 6, 1],
    ["zko", 1, 9],
    ["no", 1],
    ["zino", 1, 1],
    ["ro", 1],
    ["aro", 1, 1],
    ["igaro", -1, 1],
    ["taro", 1, 2],
    ["zaro", 1, 3],
    ["ero", 1, 5],
    ["giro", 1, 6],
    ["oro", 1, 7],
    ["oso", 1],
    ["to", 1],
    ["tto", 1, 1],
    ["zto", 1, 2],
    ["txo", 1],
    ["tzo", 1],
    ["gintzo", 1, 1],
    ["\u00F1o", 1],
    ["zp", 1],
    ["ar", 1],
    ["dar", 1, 1],
    ["behar", 1, 2],
    ["zehar", -1, 3],
    ["liar", 1, 4],
    ["tiar", 1, 5],
    ["tar", 1, 6],
    ["tzar", 1, 7],
    ["or", 2],
    ["kor", 1, 1],
    ["os", 1],
    ["ket", 1],
    ["du", 1],
    ["mendu", 1, 1],
    ["ordu", 1, 2],
    ["leku", 1],
    ["buru", 2],
    ["duru", 1],
    ["tsu", 1],
    ["tu", 1],
    ["tatu", 4, 1],
    ["mentu", 1, 2],
    ["estu", 1, 3],
    ["txu", 1],
    ["zu", 1],
    ["tzu", 1, 1],
    ["gintzu", 1, 1],
    ["z", 1],
    ["ez", 1, 1],
    ["eroz", 1, 2],
    ["tz", 1, 3],
    ["koitz", 1, 1]
];

const a_2 = [
    ["zlea", 2],
    ["keria", 1],
    ["la", 1],
    ["era", 1],
    ["dade", 1],
    ["tade", 1],
    ["date", 1],
    ["tate", 1],
    ["gi", 1],
    ["ki", 1],
    ["ik", 1],
    ["lanik", 1, 1],
    ["rik", 1, 2],
    ["larik", 1, 1],
    ["ztik", 1, 4],
    ["go", 1],
    ["ro", 1],
    ["ero", 1, 1],
    ["to", 1]
];

const /**@type {Array<number>}*/ g_v = [17, 65, 16];

import B from './base-stemmer.js'

export default class extends B {


    /** @return {boolean} */
    #stem() {
        let /**@type {number}*/ a;
        let /**@type {number}*/ I_p2;
        let /**@type {number}*/ I_p1;
        let /**@type {number}*/ I_pV;
        // deno-lint-ignore no-unused-labels
        lab0: {
            I_pV = this.limit;
            I_p1 = this.limit;
            I_p2 = this.limit;
            const /**@type {number}*/ v_1 = this.c;
            // deno-lint-ignore no-unused-labels
            lab1: {
                // deno-lint-ignore no-unused-labels
                lab2: {
                    const /**@type {number}*/ v_2 = this.c;
                    // deno-lint-ignore no-unused-labels
                    lab3: {
                        if (!(this.in_grouping(g_v, 97, 117))) break lab3;
                        // deno-lint-ignore no-unused-labels
                        lab4: {
                            const /**@type {number}*/ v_3 = this.c;
                            // deno-lint-ignore no-unused-labels
                            lab5: {
                                if (!(this.out_grouping(g_v, 97, 117))) break lab5;
                                if (!this.go_out_grouping(g_v, 97, 117)) break lab5;
                                this.c++;
                                break lab4;
                            }
                            this.c = v_3;
                            if (!(this.in_grouping(g_v, 97, 117))) break lab3;
                            if (!this.go_in_grouping(g_v, 97, 117)) break lab3;
                            this.c++;
                        }
                        break lab2;
                    }
                    this.c = v_2;
                    if (!(this.out_grouping(g_v, 97, 117))) break lab1;
                    // deno-lint-ignore no-unused-labels
                    lab6: {
                        const /**@type {number}*/ v_4 = this.c;
                        // deno-lint-ignore no-unused-labels
                        lab7: {
                            if (!(this.out_grouping(g_v, 97, 117))) break lab7;
                            if (!this.go_out_grouping(g_v, 97, 117)) break lab7;
                            this.c++;
                            break lab6;
                        }
                        this.c = v_4;
                        if (!(this.in_grouping(g_v, 97, 117))) break lab1;
                        if (this.c >= this.limit) break lab1;
                        this.c++;
                    }
                }
                I_pV = this.c;
            }
            this.c = v_1;
            const /**@type {number}*/ v_5 = this.c;
            // deno-lint-ignore no-unused-labels
            lab8: {
                if (!this.go_out_grouping(g_v, 97, 117)) break lab8;
                this.c++;
                if (!this.go_in_grouping(g_v, 97, 117)) break lab8;
                this.c++;
                I_p1 = this.c;
                if (!this.go_out_grouping(g_v, 97, 117)) break lab8;
                this.c++;
                if (!this.go_in_grouping(g_v, 97, 117)) break lab8;
                this.c++;
                I_p2 = this.c;
            }
            this.c = v_5;
        }
        this.limit_backward = this.c; this.c = this.limit;
        while (true) {
            const /**@type {number}*/ v_6 = this.limit - this.c;
            // deno-lint-ignore no-unused-labels
            lab9: {
                this.ket = this.c;
                a = this.find_among_b(a_0);
                if (a === 0) break lab9;
                this.bra = this.c;
                switch (a) {
                    case 1: {
                        if (/**@type {boolean}*/(I_pV > this.c)) break lab9;
                        this.slice_del();
                        break;
                    }
                    case 2: {
                        if (/**@type {boolean}*/(I_p2 > this.c)) break lab9;
                        this.slice_del();
                        break;
                    }
                }
                continue;
            }
            this.c = this.limit - v_6;
            break;
        }
        while (true) {
            const /**@type {number}*/ v_7 = this.limit - this.c;
            // deno-lint-ignore no-unused-labels
            lab10: {
                this.ket = this.c;
                a = this.find_among_b(a_1);
                if (a === 0) break lab10;
                this.bra = this.c;
                switch (a) {
                    case 1: {
                        if (/**@type {boolean}*/(I_pV > this.c)) break lab10;
                        this.slice_del();
                        break;
                    }
                    case 2: {
                        if (/**@type {boolean}*/(I_p2 > this.c)) break lab10;
                        this.slice_del();
                        break;
                    }
                    case 3: {
                        this.slice_from("jok");
                        break;
                    }
                    case 4: {
                        if (/**@type {boolean}*/(I_p1 > this.c)) break lab10;
                        this.slice_del();
                        break;
                    }
                    case 5: {
                        this.slice_from("tra");
                        break;
                    }
                    case 6: {
                        this.slice_from("minutu");
                        break;
                    }
                }
                continue;
            }
            this.c = this.limit - v_7;
            break;
        }
        const /**@type {number}*/ v_8 = this.limit - this.c;
        // deno-lint-ignore no-unused-labels
        lab11: {
            this.ket = this.c;
            a = this.find_among_b(a_2);
            if (a === 0) break lab11;
            this.bra = this.c;
            switch (a) {
                case 1: {
                    if (/**@type {boolean}*/(I_pV > this.c)) break lab11;
                    this.slice_del();
                    break;
                }
                case 2: {
                    this.slice_from("z");
                    break;
                }
            }
        }
        this.c = this.limit - v_8;
        this.c = this.limit_backward;
        return true;
    }

    /**@return{string}*/
    stem(/**@type {string}*/input) {
        this.setCurrent(input);
        this.#stem();
        return this.getCurrent();
    }

    stemWord = this.stem;
}

