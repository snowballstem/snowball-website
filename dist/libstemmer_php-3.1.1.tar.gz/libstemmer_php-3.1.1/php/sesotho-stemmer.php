<?php
// Generated from sesotho.sbl by Snowball 3.1.1 - https://snowballstem.org/

class SnowballSesothoStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["ba", -1, -1],
        ["boi", -1, -1],
        ["le", -1, -1],
        ["li", -1, -1],
        ["ma", -1, -1],
        ["me", -1, -1],
        ["mo", -1, -1],
        ["se", -1, -1]
    ];

    private const array A_1 = [
        ["a", -1, 1],
        ["ela", 0, 1],
        ["isa", 0, 1],
        ["wa", 0, 1],
        ["ile", -1, 1],
        ["etse", -1, 1],
        ["ang", -1, 1],
        ["eng", -1, 1],
        ["ong", -1, 1]
    ];

    private const array A_2 = [
        ["ana", -1, 1],
        ["nyana", 0, 1],
        ["oa", -1, 1],
        ["i", -1, 1],
        ["ano", -1, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true];

    private int $I_pV = 0;



    protected function r_mark_regions(): bool
    {
        $v_1 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            return false;
        }
        $this->inc_cursor();
        $this->I_pV = $this->cursor;
        $this->cursor = $v_1;
        $v_2 = $this->cursor;
        if (!$this->hop(2)) {
            return false;
        }
        if ($this->cursor <= $this->I_pV) {
            goto lab0;
        }
        $this->I_pV = $this->cursor;
    lab0:
        $this->cursor = $v_2;
        return true;
    }


    protected function r_remove_noun_prefixes(): bool
    {
        $this->bra = $this->cursor;
        if ($this->find_among(self::A_0) === 0) {
            return false;
        }
        $this->ket = $this->cursor;
        $v_1 = $this->cursor;
        if ($this->cursor >= $this->limit) {
            return false;
        }
        $this->inc_cursor();
        if ($this->cursor >= $this->limit) {
            return false;
        }
        $this->cursor = $v_1;
        if (!$this->go_out_grouping(self::G_v)) {
            return false;
        }
        $this->inc_cursor();
        $this->slice_del();
        return true;
    }


    protected function r_remove_verb_suffixes(): bool
    {
        if ($this->cursor < $this->I_pV) {
            return false;
        }
        $v_1 = $this->limit_backward;
        $this->limit_backward = $this->I_pV;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_1) === 0) {
            $this->limit_backward = $v_1;
            return false;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->limit_backward = $v_1;
        return true;
    }


    protected function r_remove_nominal_suffixes(): bool
    {
        if ($this->cursor < $this->I_pV) {
            return false;
        }
        $v_1 = $this->limit_backward;
        $this->limit_backward = $this->I_pV;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_2) === 0) {
            $this->limit_backward = $v_1;
            return false;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->limit_backward = $v_1;
        return true;
    }


    public function stem(): bool
    {
        if (!$this->r_mark_regions()) {
            return false;
        }
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_1 = $this->limit - $this->cursor;
        $this->r_remove_nominal_suffixes();
        $this->cursor = $this->limit - $v_1;
        $v_2 = $this->limit - $this->cursor;
        $this->r_remove_verb_suffixes();
        $this->cursor = $this->limit - $v_2;
        $this->cursor = $this->limit_backward;
        $v_3 = $this->cursor;
        $this->r_remove_noun_prefixes();
        $this->cursor = $v_3;
        return true;
    }
}
