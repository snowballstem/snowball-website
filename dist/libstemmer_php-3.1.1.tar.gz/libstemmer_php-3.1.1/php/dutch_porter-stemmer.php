<?php
// Generated from dutch_porter.sbl by Snowball 3.1.1 - https://snowballstem.org/

class SnowballDutchPorterStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["", -1, 6],
        ["\u{00E1}", 0, 1],
        ["\u{00E4}", 0, 1],
        ["\u{00E9}", 0, 2],
        ["\u{00EB}", 0, 2],
        ["\u{00ED}", 0, 3],
        ["\u{00EF}", 0, 3],
        ["\u{00F3}", 0, 4],
        ["\u{00F6}", 0, 4],
        ["\u{00FA}", 0, 5],
        ["\u{00FC}", 0, 5]
    ];

    private const array A_1 = [
        ["", -1, 3],
        ["I", 0, 2],
        ["Y", 0, 1]
    ];

    private const array A_2 = [
        ["dd", -1, -1],
        ["kk", -1, -1],
        ["tt", -1, -1]
    ];

    private const array A_3 = [
        ["ene", -1, 2],
        ["se", -1, 3],
        ["en", -1, 2],
        ["heden", 2, 1],
        ["s", -1, 3]
    ];

    private const array A_4 = [
        ["end", -1, 1],
        ["ig", -1, 2],
        ["ing", -1, 1],
        ["lijk", -1, 3],
        ["baar", -1, 4],
        ["bar", -1, 5]
    ];

    private const array A_5 = [
        ["aa", -1, -1],
        ["ee", -1, -1],
        ["oo", -1, -1],
        ["uu", -1, -1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{00E8}"=>true];

    private const array G_v_I = ["I"=>true, "a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{00E8}"=>true];

    private const array G_v_j = ["a"=>true, "e"=>true, "i"=>true, "j"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{00E8}"=>true];

    private int $I_p2 = 0;
    private int $I_p1 = 0;
    private bool $B_e_found = false;



    protected function r_prelude(): bool
    {
        $v_1 = $this->cursor;
        while (true) {
            $v_2 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_0);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("a");
                    break;
                case 2:
                    $this->slice_from("e");
                    break;
                case 3:
                    $this->slice_from("i");
                    break;
                case 4:
                    $this->slice_from("o");
                    break;
                case 5:
                    $this->slice_from("u");
                    break;
                case 6:
                    if ($this->cursor >= $this->limit) {
                        goto lab0;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab0:
            $this->cursor = $v_2;
            break;
        }
        $this->cursor = $v_1;
        $v_3 = $this->cursor;
        $this->bra = $this->cursor;
        if (!($this->eq_s("y"))) {
            $this->cursor = $v_3;
            goto lab1;
        }
        $this->ket = $this->cursor;
        $this->slice_from("Y");
    lab1:
        while (true) {
            $v_4 = $this->cursor;
            if (!$this->go_out_grouping(self::G_v)) {
                goto lab2;
            }
            $this->inc_cursor();
            $v_5 = $this->cursor;
            $this->bra = $this->cursor;
            $v_6 = $this->cursor;
            if (!($this->eq_s("i"))) {
                goto lab4;
            }
            $this->ket = $this->cursor;
            $v_7 = $this->cursor;
            if (!($this->in_grouping(self::G_v))) {
                goto lab5;
            }
            $this->slice_from("I");
        lab5:
            $this->cursor = $v_7;
            goto lab6;
        lab4:
            $this->cursor = $v_6;
            if (!($this->eq_s("y"))) {
                $this->cursor = $v_5;
                goto lab3;
            }
            $this->ket = $this->cursor;
            $this->slice_from("Y");
        lab6:
        lab3:
            continue;
        lab2:
            $this->cursor = $v_4;
            break;
        }
        return true;
    }


    protected function r_mark_regions(): bool
    {
        $this->I_p1 = $this->limit;
        $this->I_p2 = $this->limit;
        $v_1 = $this->cursor;
        if (!$this->hop(3)) {
            return false;
        }
        $I_x = $this->cursor;
        $this->cursor = $v_1;
        if (!$this->go_out_grouping(self::G_v)) {
            return false;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            return false;
        }
        $this->inc_cursor();
        $this->I_p1 = $this->cursor;
        if ($this->I_p1 >= $I_x) {
            goto lab0;
        }
        $this->I_p1 = $I_x;
    lab0:
        if (!$this->go_out_grouping(self::G_v)) {
            return false;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            return false;
        }
        $this->inc_cursor();
        $this->I_p2 = $this->cursor;
        return true;
    }


    protected function r_postlude(): bool
    {
        while (true) {
            $v_1 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_1);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("y");
                    break;
                case 2:
                    $this->slice_from("i");
                    break;
                case 3:
                    if ($this->cursor >= $this->limit) {
                        goto lab0;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab0:
            $this->cursor = $v_1;
            break;
        }
        return true;
    }


    protected function r_R1(): bool
    {
        return $this->I_p1 <= $this->cursor;
    }


    protected function r_R2(): bool
    {
        return $this->I_p2 <= $this->cursor;
    }


    protected function r_undouble(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_2) === 0) {
            return false;
        }
        $this->cursor = $this->limit - $v_1;
        $this->ket = $this->cursor;
        if ($this->cursor <= $this->limit_backward) {
            return false;
        }
        $this->dec_cursor();
        $this->bra = $this->cursor;
        $this->slice_del();
        return true;
    }


    protected function r_e_ending(): bool
    {
        $this->B_e_found = false;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("e"))) {
            return false;
        }
        $this->bra = $this->cursor;
        if (!$this->r_R1()) {
            return false;
        }
        $v_1 = $this->limit - $this->cursor;
        if (!($this->out_grouping_b(self::G_v))) {
            return false;
        }
        $this->cursor = $this->limit - $v_1;
        $this->slice_del();
        $this->B_e_found = true;
        return $this->r_undouble();
    }


    protected function r_en_ending(): bool
    {
        if (!$this->r_R1()) {
            return false;
        }
        $v_1 = $this->limit - $this->cursor;
        if (!($this->out_grouping_b(self::G_v))) {
            return false;
        }
        $this->cursor = $this->limit - $v_1;
        if (!($this->eq_s_b("gem"))) {
            goto lab0;
        }
        return false;
    lab0:
        $this->slice_del();
        return $this->r_undouble();
    }


    protected function r_standard_suffix(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_3);
        if (0 === $among_var) {
            goto lab0;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if (!$this->r_R1()) {
                    goto lab0;
                }
                $this->slice_from("heid");
                break;
            case 2:
                if (!$this->r_en_ending()) {
                    goto lab0;
                }
                break;
            case 3:
                if (!$this->r_R1()) {
                    goto lab0;
                }
                if (!($this->out_grouping_b(self::G_v_j))) {
                    goto lab0;
                }
                $this->slice_del();
                break;
        }
    lab0:
        $this->cursor = $this->limit - $v_1;
        $v_2 = $this->limit - $this->cursor;
        $this->r_e_ending();
        $this->cursor = $this->limit - $v_2;
        $v_3 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("heid"))) {
            goto lab1;
        }
        $this->bra = $this->cursor;
        if (!$this->r_R2()) {
            goto lab1;
        }
        if (!($this->eq_s_b("c"))) {
            goto lab2;
        }
        goto lab1;
    lab2:
        $this->slice_del();
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("en"))) {
            goto lab1;
        }
        $this->bra = $this->cursor;
        if (!$this->r_en_ending()) {
            goto lab1;
        }
    lab1:
        $this->cursor = $this->limit - $v_3;
        $v_4 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab3;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if (!$this->r_R2()) {
                    goto lab3;
                }
                $this->slice_del();
                $v_5 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("ig"))) {
                    goto lab4;
                }
                $this->bra = $this->cursor;
                if (!$this->r_R2()) {
                    goto lab4;
                }
                if (!($this->eq_s_b("e"))) {
                    goto lab5;
                }
                goto lab4;
            lab5:
                $this->slice_del();
                goto lab6;
            lab4:
                $this->cursor = $this->limit - $v_5;
                if (!$this->r_undouble()) {
                    goto lab3;
                }
            lab6:
                break;
            case 2:
                if (!$this->r_R2()) {
                    goto lab3;
                }
                if (!($this->eq_s_b("e"))) {
                    goto lab7;
                }
                goto lab3;
            lab7:
                $this->slice_del();
                break;
            case 3:
                if (!$this->r_R2()) {
                    goto lab3;
                }
                $this->slice_del();
                if (!$this->r_e_ending()) {
                    goto lab3;
                }
                break;
            case 4:
                if (!$this->r_R2()) {
                    goto lab3;
                }
                $this->slice_del();
                break;
            case 5:
                if (!$this->r_R2()) {
                    goto lab3;
                }
                if (!$this->B_e_found) {
                    goto lab3;
                }
                $this->slice_del();
                break;
        }
    lab3:
        $this->cursor = $this->limit - $v_4;
        $v_6 = $this->limit - $this->cursor;
        if (!($this->out_grouping_b(self::G_v_I))) {
            goto lab8;
        }
        $v_7 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_5) === 0) {
            goto lab8;
        }
        if (!($this->out_grouping_b(self::G_v))) {
            goto lab8;
        }
        $this->cursor = $this->limit - $v_7;
        $this->ket = $this->cursor;
        if ($this->cursor <= $this->limit_backward) {
            goto lab8;
        }
        $this->dec_cursor();
        $this->bra = $this->cursor;
        $this->slice_del();
    lab8:
        $this->cursor = $this->limit - $v_6;
        return true;
    }


    public function stem(): bool
    {
        $v_1 = $this->cursor;
        $this->r_prelude();
        $this->cursor = $v_1;
        $v_2 = $this->cursor;
        $this->r_mark_regions();
        $this->cursor = $v_2;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $this->r_standard_suffix();
        $this->cursor = $this->limit_backward;
        $v_3 = $this->cursor;
        $this->r_postlude();
        $this->cursor = $v_3;
        return true;
    }
}
