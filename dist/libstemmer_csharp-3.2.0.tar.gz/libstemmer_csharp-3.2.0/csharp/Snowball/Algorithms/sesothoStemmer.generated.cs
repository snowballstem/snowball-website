// Generated from sesotho.sbl by Snowball 3.2.0 - https://snowballstem.org/

#pragma warning disable 0164
#pragma warning disable 0162

namespace Snowball
{
    using System;
    using System.Text;

    ///<summary>
    ///  This class implements the stemming algorithm defined by a snowball script.
    ///  Generated from sesotho.sbl by Snowball 3.2.0 - https://snowballstem.org/
    ///</summary>
    ///
    [System.CodeDom.Compiler.GeneratedCode("Snowball", "3.2.0")]
    public partial class SesothoStemmer : Stemmer
    {
        private const string g_v = "aeiou";

        private static readonly Among[] a_0 = new[]
        {
            new Among("ba", -1, -1, 0),
            new Among("boi", -1, -1, 0),
            new Among("le", -1, -1, 0),
            new Among("li", -1, -1, 0),
            new Among("ma", -1, -1, 0),
            new Among("me", -1, -1, 0),
            new Among("mo", -1, -1, 0),
            new Among("se", -1, -1, 0)
        };

        private static readonly Among[] a_1 = new[]
        {
            new Among("a", -1, 1, 0),
            new Among("ela", 0, 1, 0),
            new Among("isa", 0, 1, 0),
            new Among("wa", 0, 1, 0),
            new Among("ile", -1, 1, 0),
            new Among("etse", -1, 1, 0),
            new Among("ang", -1, 1, 0),
            new Among("eng", -1, 1, 0),
            new Among("ong", -1, 1, 0)
        };

        private static readonly Among[] a_2 = new[]
        {
            new Among("ana", -1, 1, 0),
            new Among("nyana", 0, 1, 0),
            new Among("oa", -1, 1, 0),
            new Among("i", -1, 1, 0),
            new Among("ano", -1, 1, 0)
        };


        protected override bool stem()
        {
            int I_pV;
            {
                int c1 = cursor;
                {

                    int ret = out_grouping(g_v, 97, 117, true);
                    if (ret < 0)
                    {
                        return false;
                    }

                    cursor += ret;
                }
                I_pV = cursor;
                cursor = c1;
            }
            {
                int c2 = cursor;
                {
                    int c = cursor + 2;
                    if (c > limit)
                    {
                        return false;
                    }
                    cursor = c;
                }
                if (cursor <= I_pV)
                {
                    goto lab0;
                }
                I_pV = cursor;
            lab0: ;
                cursor = c2;
            }
            limit_backward = cursor;
            cursor = limit;
            {
                int c3 = limit - cursor;
                if (cursor < I_pV)
                {
                    goto lab1;
                }
                int c4 = limit_backward;
                limit_backward = I_pV;
                ket = cursor;
                if (find_among_b(a_2, null) == 0)
                {
                    {
                        limit_backward = c4;
                        goto lab1;
                    }
                }
                bra = cursor;
                slice_del();
                limit_backward = c4;
            lab1: ;
                cursor = limit - c3;
            }
            {
                int c5 = limit - cursor;
                if (cursor < I_pV)
                {
                    goto lab2;
                }
                int c6 = limit_backward;
                limit_backward = I_pV;
                ket = cursor;
                if (find_among_b(a_1, null) == 0)
                {
                    {
                        limit_backward = c6;
                        goto lab2;
                    }
                }
                bra = cursor;
                slice_del();
                limit_backward = c6;
            lab2: ;
                cursor = limit - c5;
            }
            cursor = limit_backward;
            {
                int c7 = cursor;
                bra = cursor;
                if (find_among(a_0, null) == 0)
                {
                    goto lab3;
                }
                ket = cursor;
                {
                    int c8 = cursor;
                    if (cursor >= limit)
                    {
                        goto lab3;
                    }
                    cursor++;
                    if (cursor >= limit)
                    {
                        goto lab3;
                    }
                    cursor = c8;
                }
                {

                    int ret = out_grouping(g_v, 97, 117, true);
                    if (ret < 0)
                    {
                        goto lab3;
                    }

                    cursor += ret;
                }
                slice_del();
            lab3: ;
                cursor = c7;
            }
            return true;
        }

    }
}

