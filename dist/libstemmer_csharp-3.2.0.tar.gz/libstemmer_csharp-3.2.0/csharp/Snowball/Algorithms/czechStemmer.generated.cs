// Generated from czech.sbl by Snowball 3.2.0 - https://snowballstem.org/

#pragma warning disable 0164
#pragma warning disable 0162

namespace Snowball
{
    using System;
    using System.Text;

    ///<summary>
    ///  This class implements the stemming algorithm defined by a snowball script.
    ///  Generated from czech.sbl by Snowball 3.2.0 - https://snowballstem.org/
    ///</summary>
    ///
    [System.CodeDom.Compiler.GeneratedCode("Snowball", "3.2.0")]
    public partial class CzechStemmer : Stemmer
    {
        private const string g_v = "aeiouyáéíóúýěů";
        private const string g_v_or_syllabic_c = "aeiloruyáéíóúýěů";
        private const string g_ev_ending = "hknrtz";
        private const string g_env_ending = "bcdhkprstvzčšž";

        private static readonly Among[] a_0 = new[]
        {
            new Among("c", -1, 1, 0),
            new Among("nc", 0, -1, 0),
            new Among("ínc", 1, 2, 0),
            new Among("avc", 0, -1, 0),
            new Among("ovc", 0, -1, 0)
        };

        private static readonly Among[] a_1 = new[]
        {
            new Among("c", -1, 1, 0),
            new Among("nc", 0, -1, 0),
            new Among("ínc", 1, 2, 0),
            new Among("avc", 0, -1, 0),
            new Among("ovc", 0, -1, 0),
            new Among("čt", -1, 3, 0),
            new Among("št", -1, 4, 0),
            new Among("dešt", 6, -1, 0),
            new Among("lešt", 6, -1, 0),
            new Among("išt", 6, -1, 0),
            new Among("poušt", 6, -1, 0),
            new Among("ášt", 6, -1, 0),
            new Among("íšt", 6, -1, 0)
        };

        private static readonly Among[] a_2 = new[]
        {
            new Among("in", -1, 2, 0),
            new Among("ov", -1, 1, 0),
            new Among("ův", -1, 1, 0)
        };

        private static readonly Among[] a_3 = new[]
        {
            new Among("", -1, 2, 0),
            new Among("l", 0, 1, 0),
            new Among("tl", 1, 2, 0),
            new Among("s", 0, 1, 0),
            new Among("es", 3, 2, 0),
            new Among("č", 0, 1, 0),
            new Among("eč", 5, 2, 0),
            new Among("ř", 0, 1, 0),
            new Among("ž", 0, 1, 0)
        };

        private static readonly Among[] a_4 = new[]
        {
            new Among("obl", -1, -1, 0),
            new Among("sn", -1, -1, 0),
            new Among("dot", -1, -1, 0)
        };

        private static readonly Among[] a_5 = new[]
        {
            new Among("uc", -1, -1, 0),
            new Among("h", -1, -1, 0),
            new Among("ok", -1, -1, 0),
            new Among("kar", -1, -1, 0),
            new Among("č", -1, -1, 0)
        };

        private static readonly Among[] a_6 = new[]
        {
            new Among("a", -1, 1, 0),
            new Among("ama", 0, 1, 0),
            new Among("ata", 0, 1, 0),
            new Among("eb", -1, 4, 0),
            new Among("ec", -1, 5, 0),
            new Among("e", -1, 2, 0),
            new Among("ete", 5, 3, 0),
            new Among("ěte", 5, 1, 0),
            new Among("ech", -1, 2, 0),
            new Among("atech", 8, 1, 0),
            new Among("ách", -1, 1, 0),
            new Among("ích", -1, 12, 0),
            new Among("ých", -1, 1, 0),
            new Among("i", -1, 12, 0),
            new Among("mi", 13, 1, 0),
            new Among("ami", 14, 1, 0),
            new Among("emi", 14, 2, 0),
            new Among("ími", 14, 12, 0),
            new Among("ými", 14, 1, 0),
            new Among("ěmi", 14, 1, 0),
            new Among("ťmi", 14, 11, 0),
            new Among("eti", 13, 3, 0),
            new Among("ěti", 13, 1, 0),
            new Among("ovi", 13, 1, 0),
            new Among("ek", -1, 6, 0),
            new Among("ěk", -1, 7, 0),
            new Among("em", -1, 2, 0),
            new Among("etem", 26, 3, 0),
            new Among("ětem", 26, 1, 0),
            new Among("ám", -1, 1, 0),
            new Among("ém", -1, 1, 0),
            new Among("ím", -1, 12, 0),
            new Among("ým", -1, 1, 0),
            new Among("ěm", -1, 1, 0),
            new Among("ům", -1, 1, 0),
            new Among("atům", 34, 1, 0),
            new Among("o", -1, 1, 0),
            new Among("ého", 36, 1, 0),
            new Among("ího", 36, 12, 0),
            new Among("us", -1, 1, 0),
            new Among("at", -1, 1, 0),
            new Among("et", -1, 9, 0),
            new Among("u", -1, 1, 0),
            new Among("ému", 42, 1, 0),
            new Among("ímu", 42, 12, 0),
            new Among("ou", 42, 1, 0),
            new Among("ev", -1, 10, 0),
            new Among("y", -1, 1, 0),
            new Among("aty", 47, 1, 0),
            new Among("á", -1, 1, 0),
            new Among("é", -1, 1, 0),
            new Among("ové", 50, 1, 0),
            new Among("í", -1, 12, 0),
            new Among("ý", -1, 1, 0),
            new Among("ě", -1, 1, 0),
            new Among("eň", -1, 8, 0),
            new Among("ť", -1, 11, 0),
            new Among("ů", -1, 1, 0)
        };


        private bool r_palatalise_e()
        {
            int among_var;
            ket = cursor;
            among_var = find_among_b(a_0, null);
            if (among_var == 0)
            {
                return false;
            }
            bra = cursor;
            switch (among_var) {
                case 1: {
                    slice_from("k");
                    break;
                }
                case 2: {
                    slice_from("ínk");
                    break;
                }
            }
            return true;
        }

        private bool r_palatalise_i()
        {
            int among_var;
            ket = cursor;
            among_var = find_among_b(a_1, null);
            if (among_var == 0)
            {
                return false;
            }
            bra = cursor;
            switch (among_var) {
                case 1: {
                    slice_from("k");
                    break;
                }
                case 2: {
                    slice_from("ínk");
                    break;
                }
                case 3: {
                    slice_from("ck");
                    break;
                }
                case 4: {
                    slice_from("sk");
                    break;
                }
            }
            return true;
        }

        protected override bool stem()
        {
            int among_var;
            int I_x;
            int I_p1;
            {
                int c1 = cursor;
                {
                    int c = cursor + 3;
                    if (c > limit)
                    {
                        return false;
                    }
                    cursor = c;
                }
                I_x = cursor;
                cursor = c1;
            }
            I_p1 = limit;
            {
                int c2 = cursor;
                if (in_grouping(g_v, 97, 367, false) != 0)
                {
                    goto lab2;
                }
                goto lab1;
            lab2: ;
                if (cursor >= limit)
                {
                    goto lab0;
                }
                cursor++;
                {

                    int ret = out_grouping(g_v_or_syllabic_c, 97, 367, true);
                    if (ret < 0)
                    {
                        goto lab0;
                    }

                    cursor += ret;
                }
            lab1: ;
                {

                    int ret = in_grouping(g_v, 97, 367, true);
                    if (ret < 0)
                    {
                        goto lab0;
                    }

                    cursor += ret;
                }
                I_p1 = cursor;
                if (I_p1 >= I_x)
                {
                    goto lab3;
                }
                I_p1 = I_x;
            lab3: ;
            lab0: ;
                cursor = c2;
            }
            limit_backward = cursor;
            cursor = limit;
            {
                int c3 = limit - cursor;
                if (cursor < I_p1)
                {
                    goto lab4;
                }
                int c4 = limit_backward;
                limit_backward = I_p1;
                ket = cursor;
                among_var = find_among_b(a_6, null);
                if (among_var == 0)
                {
                    {
                        limit_backward = c4;
                        goto lab4;
                    }
                }
                bra = cursor;
                limit_backward = c4;
                switch (among_var) {
                    case 1: {
                        slice_del();
                        break;
                    }
                    case 2: {
                        slice_del();
                        {
                            int c5 = limit - cursor;
                            if (!r_palatalise_e())
                                {
                                    cursor = limit - c5;
                                    goto lab5;
                                }
                        lab5: ;
                        }
                        break;
                    }
                    case 3: {
                        among_var = find_among_b(a_3, null);
                        switch (among_var) {
                            case 1: {
                                slice_del();
                                break;
                            }
                            case 2: {
                                slice_from("et");
                                break;
                            }
                        }
                        break;
                    }
                    case 4: {
                        {
                            int c6 = limit - cursor;
                            if (out_grouping_b(g_v, 97, 367, false) != 0)
                            {
                                goto lab4;
                            }
                            cursor = limit - c6;
                        }
                        if (!(eq_s_b("tř")))
                        {
                            goto lab6;
                        }
                        goto lab4;
                    lab6: ;
                        slice_from("b");
                        break;
                    }
                    case 5: {
                        {
                            int c7 = limit - cursor;
                            if (out_grouping_b(g_v, 97, 367, false) != 0)
                            {
                                goto lab4;
                            }
                            cursor = limit - c7;
                        }
                        slice_del();
                        insert(cursor, cursor, "c");
                        {
                            int c8 = limit - cursor;
                            if (!r_palatalise_e())
                                {
                                    cursor = limit - c8;
                                    goto lab7;
                                }
                        lab7: ;
                        }
                        break;
                    }
                    case 6: {
                        {
                            int c9 = limit - cursor;
                            if (out_grouping_b(g_v, 97, 367, false) != 0)
                            {
                                goto lab4;
                            }
                            cursor = limit - c9;
                        }
                        {
                            int c10 = limit - cursor;
                            if (find_among_b(a_4, null) == 0)
                            {
                                goto lab8;
                            }
                            goto lab4;
                        lab8: ;
                            cursor = limit - c10;
                        }
                        slice_from("k");
                        break;
                    }
                    case 7: {
                        if (!(eq_s_b("n")))
                        {
                            goto lab4;
                        }
                        bra = cursor;
                        slice_from("ňk");
                        break;
                    }
                    case 8: {
                        {
                            int c11 = limit - cursor;
                            if (in_grouping_b(g_env_ending, 98, 382, false) != 0)
                            {
                                goto lab4;
                            }
                            cursor = limit - c11;
                        }
                        slice_from("n");
                        break;
                    }
                    case 9: {
                        if (find_among_b(a_5, null) == 0)
                        {
                            goto lab4;
                        }
                        slice_from("t");
                        break;
                    }
                    case 10: {
                        if (in_grouping_b(g_ev_ending, 104, 122, false) != 0)
                        {
                            goto lab4;
                        }
                        slice_from("v");
                        break;
                    }
                    case 11: {
                        slice_from("t");
                        break;
                    }
                    case 12: {
                        slice_del();
                        {
                            int c12 = limit - cursor;
                            if (!r_palatalise_i())
                                {
                                    cursor = limit - c12;
                                    goto lab9;
                                }
                        lab9: ;
                        }
                        break;
                    }
                }
            lab4: ;
                cursor = limit - c3;
            }
            {
                int c13 = limit - cursor;
                ket = cursor;
                among_var = find_among_b(a_2, null);
                if (among_var == 0)
                {
                    goto lab10;
                }
                bra = cursor;
                if (I_p1 > cursor)
                {
                    goto lab10;
                }
                switch (among_var) {
                    case 1: {
                        slice_del();
                        break;
                    }
                    case 2: {
                        slice_del();
                        {
                            int c14 = limit - cursor;
                            if (!r_palatalise_i())
                                {
                                    cursor = limit - c14;
                                    goto lab11;
                                }
                        lab11: ;
                        }
                        break;
                    }
                }
            lab10: ;
                cursor = limit - c13;
            }
            cursor = limit_backward;
            return true;
        }

    }
}

