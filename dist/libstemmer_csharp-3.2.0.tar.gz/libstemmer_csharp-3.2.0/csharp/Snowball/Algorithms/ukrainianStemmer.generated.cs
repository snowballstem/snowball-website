// Generated from ukrainian.sbl by Snowball 3.2.0 - https://snowballstem.org/

#pragma warning disable 0164
#pragma warning disable 0162

namespace Snowball
{
    using System;
    using System.Text;

    ///<summary>
    ///  This class implements the stemming algorithm defined by a snowball script.
    ///  Generated from ukrainian.sbl by Snowball 3.2.0 - https://snowballstem.org/
    ///</summary>
    ///
    [System.CodeDom.Compiler.GeneratedCode("Snowball", "3.2.0")]
    public partial class UkrainianStemmer : Stemmer
    {
        private const string g_v = "аеиоуюяєії";

        private static readonly Among[] a_0 = new[]
        {
            new Among("ачи", -1, 3, 0),
            new Among("учи", -1, 3, 0),
            new Among("аючи", -1, 3, 0),
            new Among("уючи", -1, 4, 0),
            new Among("юючи", -1, 5, 0),
            new Among("яючи", -1, 3, 0),
            new Among("іючи", -1, 3, 0),
            new Among("ячи", -1, 3, 0),
            new Among("вши", -1, 1, 0),
            new Among("ивши", 8, 2, 0),
            new Among("вшись", -1, 1, 0),
            new Among("ившись", 10, 2, 0)
        };

        private static readonly Among[] a_1 = new[]
        {
            new Among("еться", -1, 1, 0),
            new Among("иться", -1, 1, 0),
            new Among("аються", -1, 1, 0),
            new Among("уються", -1, 2, 0),
            new Among("юються", -1, 3, 0),
            new Among("яються", -1, 1, 0),
            new Among("ється", -1, 1, 0),
            new Among("ається", 6, 1, 0),
            new Among("ується", 6, 2, 0),
            new Among("юється", 6, 3, 0),
            new Among("яється", 6, 1, 0)
        };

        private static readonly Among[] a_2 = new[]
        {
            new Among("сь", -1, 1, 0),
            new Among("лась", 0, 1, 0),
            new Among("всь", 0, 1, 0),
            new Among("тись", 0, 1, 0),
            new Among("ся", -1, 1, 0),
            new Among("вся", 4, 1, 0),
            new Among("тися", 4, 1, 0)
        };

        private static readonly Among[] a_3 = new[]
        {
            new Among("ійна", -1, 1, 0),
            new Among("аційна", 0, 1, 0),
            new Among("ична", -1, 1, 0),
            new Among("ічна", -1, 1, 0),
            new Among("уальна", -1, 1, 0),
            new Among("іа", -1, 1, 0),
            new Among("ійне", -1, 1, 0),
            new Among("аційне", 6, 1, 0),
            new Among("ичне", -1, 1, 0),
            new Among("ічне", -1, 1, 0),
            new Among("уальне", -1, 1, 0),
            new Among("ійними", -1, 1, 0),
            new Among("аційними", 11, 1, 0),
            new Among("ичними", -1, 1, 0),
            new Among("ічними", -1, 1, 0),
            new Among("уальними", -1, 1, 0),
            new Among("іями", -1, 1, 0),
            new Among("аціями", 16, 1, 0),
            new Among("ичностей", -1, 1, 0),
            new Among("уальностей", -1, 1, 0),
            new Among("ійний", -1, 1, 0),
            new Among("аційний", 20, 1, 0),
            new Among("ичний", -1, 1, 0),
            new Among("ічний", -1, 1, 0),
            new Among("уальний", -1, 1, 0),
            new Among("ій", -1, 1, 0),
            new Among("ійній", 25, 1, 0),
            new Among("аційній", 26, 1, 0),
            new Among("ичній", 25, 1, 0),
            new Among("ічній", 25, 1, 0),
            new Among("уальній", 25, 1, 0),
            new Among("ацій", 25, 1, 0),
            new Among("ійним", -1, 1, 0),
            new Among("аційним", 32, 1, 0),
            new Among("ичним", -1, 1, 0),
            new Among("ічним", -1, 1, 0),
            new Among("уальним", -1, 1, 0),
            new Among("іям", -1, 1, 0),
            new Among("аціям", 37, 1, 0),
            new Among("ієм", -1, 1, 0),
            new Among("ійного", -1, 1, 0),
            new Among("аційного", 40, 1, 0),
            new Among("ичного", -1, 1, 0),
            new Among("ічного", -1, 1, 0),
            new Among("уального", -1, 1, 0),
            new Among("ійно", -1, 1, 0),
            new Among("аційно", 45, 1, 0),
            new Among("ично", -1, 1, 0),
            new Among("ічно", -1, 1, 0),
            new Among("уально", -1, 1, 0),
            new Among("ійному", -1, 1, 0),
            new Among("аційному", 50, 1, 0),
            new Among("ичному", -1, 1, 0),
            new Among("ічному", -1, 1, 0),
            new Among("уальному", -1, 1, 0),
            new Among("ійну", -1, 1, 0),
            new Among("аційну", 55, 1, 0),
            new Among("ичну", -1, 1, 0),
            new Among("ічну", -1, 1, 0),
            new Among("уальну", -1, 1, 0),
            new Among("ійних", -1, 1, 0),
            new Among("аційних", 60, 1, 0),
            new Among("ичних", -1, 1, 0),
            new Among("ічних", -1, 1, 0),
            new Among("уальних", -1, 1, 0),
            new Among("іях", -1, 1, 0),
            new Among("аціях", 65, 1, 0),
            new Among("ійність", -1, 1, 0),
            new Among("аційність", 67, 1, 0),
            new Among("ичність", -1, 1, 0),
            new Among("ічність", -1, 1, 0),
            new Among("уальність", -1, 1, 0),
            new Among("ійною", -1, 1, 0),
            new Among("аційною", 72, 1, 0),
            new Among("ичною", -1, 1, 0),
            new Among("ічною", -1, 1, 0),
            new Among("уальною", -1, 1, 0),
            new Among("ійністю", -1, 1, 0),
            new Among("аційністю", 77, 1, 0),
            new Among("ичністю", -1, 1, 0),
            new Among("ічністю", -1, 1, 0),
            new Among("уальністю", -1, 1, 0),
            new Among("ією", -1, 1, 0),
            new Among("ацією", 82, 1, 0),
            new Among("ію", -1, 1, 0),
            new Among("ацію", 84, 1, 0),
            new Among("ія", -1, 1, 0),
            new Among("ація", 86, 1, 0),
            new Among("ійні", -1, 1, 0),
            new Among("аційні", 88, 1, 0),
            new Among("ичні", -1, 1, 0),
            new Among("ічні", -1, 1, 0),
            new Among("уальні", -1, 1, 0),
            new Among("ійності", -1, 1, 0),
            new Among("аційності", 93, 1, 0),
            new Among("ичності", -1, 1, 0),
            new Among("ічності", -1, 1, 0),
            new Among("уальності", -1, 1, 0),
            new Among("ійної", -1, 1, 0),
            new Among("аційної", 98, 1, 0),
            new Among("ичної", -1, 1, 0),
            new Among("ічної", -1, 1, 0),
            new Among("уальної", -1, 1, 0),
            new Among("ії", -1, 1, 0),
            new Among("ації", 103, 1, 0)
        };

        private static readonly Among[] a_4 = new[]
        {
            new Among("ована", -1, 1, 0),
            new Among("увана", -1, 1, 0),
            new Among("уча", -1, 1, 0),
            new Among("юча", -1, 1, 0),
            new Among("оване", -1, 1, 0),
            new Among("уване", -1, 1, 0),
            new Among("уче", -1, 1, 0),
            new Among("юче", -1, 1, 0),
            new Among("ими", -1, 1, 0),
            new Among("іми", -1, 1, 0),
            new Among("їми", -1, 1, 0),
            new Among("ий", -1, 1, 0),
            new Among("ований", 11, 1, 0),
            new Among("уваний", 11, 1, 0),
            new Among("учий", 11, 1, 0),
            new Among("ючий", 11, 1, 0),
            new Among("ій", -1, 1, 0),
            new Among("им", -1, 1, 0),
            new Among("ім", -1, 1, 0),
            new Among("їм", -1, 1, 0),
            new Among("ого", -1, 1, 0),
            new Among("ього", 20, 1, 0),
            new Among("овано", -1, 1, 0),
            new Among("увано", -1, 1, 0),
            new Among("ому", -1, 1, 0),
            new Among("ьому", 24, 1, 0),
            new Among("ішу", -1, 1, 0),
            new Among("их", -1, 1, 0),
            new Among("іх", -1, 1, 0),
            new Among("їх", -1, 1, 0),
            new Among("ею", -1, 2, 0),
            new Among("ою", -1, 1, 0),
            new Among("ьою", 31, 1, 0),
            new Among("єю", -1, 1, 0),
            new Among("овані", -1, 1, 0),
            new Among("увані", -1, 1, 0),
            new Among("учі", -1, 1, 0),
            new Among("ючі", -1, 1, 0),
            new Among("ої", -1, 1, 0),
            new Among("ьої", 38, 1, 0)
        };

        private static readonly Among[] a_5 = new[]
        {
            new Among("ла", -1, 10, 0),
            new Among("ала", 0, 4, 0),
            new Among("ила", 0, 1, 0),
            new Among("яла", 0, 1, 0),
            new Among("іла", 0, 1, 0),
            new Among("в", -1, 8, 0),
            new Among("ав", 5, 3, 0),
            new Among("ив", 5, 3, 0),
            new Among("яв", 5, 1, 0),
            new Among("ів", 5, 3, 0),
            new Among("атиме", -1, 1, 0),
            new Among("итиме", -1, 1, 0),
            new Among("ятиме", -1, 1, 0),
            new Among("ітиме", -1, 1, 0),
            new Among("ете", -1, 1, 0),
            new Among("ите", -1, 1, 0),
            new Among("йте", -1, 1, 0),
            new Among("єте", -1, 1, 0),
            new Among("аєте", 17, 1, 0),
            new Among("уєте", 17, 6, 0),
            new Among("юєте", 17, 7, 0),
            new Among("яєте", 17, 1, 0),
            new Among("іте", -1, 1, 0),
            new Among("ли", -1, 10, 0),
            new Among("али", 23, 4, 0),
            new Among("или", 23, 1, 0),
            new Among("яли", 23, 1, 0),
            new Among("іли", 23, 1, 0),
            new Among("ти", -1, 12, 0),
            new Among("ати", 28, 1, 0),
            new Among("ити", 28, 1, 0),
            new Among("яти", 28, 5, 0),
            new Among("іти", 28, 1, 0),
            new Among("й", -1, 1, 0),
            new Among("ей", 33, 2, 0),
            new Among("єм", -1, 1, 0),
            new Among("ло", -1, 10, 0),
            new Among("ало", 36, 4, 0),
            new Among("ило", 36, 1, 0),
            new Among("яло", 36, 1, 0),
            new Among("іло", 36, 1, 0),
            new Among("емо", -1, 1, 0),
            new Among("атимемо", 41, 1, 0),
            new Among("имо", -1, 1, 0),
            new Among("ємо", -1, 1, 0),
            new Among("аємо", 44, 1, 0),
            new Among("уємо", 44, 6, 0),
            new Among("юємо", 44, 7, 0),
            new Among("яємо", 44, 1, 0),
            new Among("імо", -1, 1, 0),
            new Among("у", -1, 9, 0),
            new Among("атиму", 50, 1, 0),
            new Among("итиму", 50, 1, 0),
            new Among("еш", -1, 1, 0),
            new Among("иш", -1, 1, 0),
            new Among("єш", -1, 1, 0),
            new Among("аєш", 55, 1, 0),
            new Among("уєш", 55, 6, 0),
            new Among("юєш", 55, 7, 0),
            new Among("яєш", 55, 1, 0),
            new Among("ить", -1, 1, 0),
            new Among("уть", -1, 1, 0),
            new Among("атимуть", 61, 1, 0),
            new Among("итимуть", 61, 1, 0),
            new Among("ятимуть", 61, 1, 0),
            new Among("ють", -1, 1, 0),
            new Among("ають", 65, 1, 0),
            new Among("ують", 65, 6, 0),
            new Among("юють", 65, 7, 0),
            new Among("яють", 65, 1, 0),
            new Among("ять", -1, 5, 0),
            new Among("їть", -1, 1, 0),
            new Among("ю", -1, 11, 0),
            new Among("аю", 72, 1, 0),
            new Among("є", -1, 1, 0),
            new Among("ає", 74, 1, 0),
            new Among("ує", 74, 6, 0),
            new Among("ює", 74, 7, 0),
            new Among("яє", 74, 1, 0)
        };

        private static readonly Among[] a_6 = new[]
        {
            new Among("ість", -1, 1, 0),
            new Among("істю", -1, 1, 0),
            new Among("ості", -1, 1, 0),
            new Among("істі", -1, 1, 0)
        };

        private static readonly Among[] a_7 = new[]
        {
            new Among("а", -1, 3, 0),
            new Among("ства", 0, 3, 0),
            new Among("цтва", 0, 2, 0),
            new Among("ств", -1, 3, 0),
            new Among("цтв", -1, 2, 0),
            new Among("е", -1, 3, 0),
            new Among("и", -1, 3, 0),
            new Among("ами", 6, 3, 0),
            new Among("ствами", 7, 3, 0),
            new Among("цтвами", 7, 2, 0),
            new Among("ями", 6, 3, 0),
            new Among("ам", -1, 3, 0),
            new Among("ствам", 11, 3, 0),
            new Among("цтвам", 11, 2, 0),
            new Among("ем", -1, 3, 0),
            new Among("ом", -1, 3, 0),
            new Among("ством", 15, 3, 0),
            new Among("цтвом", 15, 2, 0),
            new Among("ям", -1, 3, 0),
            new Among("о", -1, 3, 0),
            new Among("тво", 19, 3, 0),
            new Among("ство", 20, 3, 0),
            new Among("ству", -1, 3, 0),
            new Among("цтву", -1, 2, 0),
            new Among("ах", -1, 3, 0),
            new Among("ствах", 24, 3, 0),
            new Among("цтвах", 24, 2, 0),
            new Among("ях", -1, 3, 0),
            new Among("ець", -1, 2, 0),
            new Among("істю", -1, 1, 0),
            new Among("я", -1, 3, 0),
            new Among("і", -1, 3, 0),
            new Among("еві", 31, 3, 0),
            new Among("ові", 31, 3, 0),
            new Among("стві", 31, 3, 0),
            new Among("цтві", 31, 2, 0),
            new Among("ї", -1, 3, 0)
        };

        private static readonly Among[] a_8 = new[]
        {
            new Among("ник", -1, 1, 0),
            new Among("івник", 0, 1, 0),
            new Among("альник", 0, 1, 0),
            new Among("ельник", 0, 1, 0),
            new Among("ар", -1, 2, 0),
            new Among("яр", -1, 1, 0),
            new Among("ач", -1, 1, 0)
        };

        private static readonly Among[] a_9 = new[]
        {
            new Among("ечка", -1, 1, 0),
            new Among("очечка", 0, 1, 0),
            new Among("очка", -1, 1, 0),
            new Among("ічка", -1, 1, 0),
            new Among("енька", -1, 1, 0),
            new Among("есенька", 4, 1, 0),
            new Among("онька", -1, 1, 0),
            new Among("інька", -1, 1, 0),
            new Among("юсінька", 7, 1, 0),
            new Among("ісінька", 7, 1, 0),
            new Among("ечки", -1, 1, 0),
            new Among("очечки", 10, 1, 0),
            new Among("очки", -1, 1, 0),
            new Among("ічки", -1, 1, 0),
            new Among("еньки", -1, 1, 0),
            new Among("есеньки", 14, 1, 0),
            new Among("оньки", -1, 1, 0),
            new Among("іньки", -1, 1, 0),
            new Among("юсіньки", 17, 1, 0),
            new Among("ісіньки", 17, 1, 0),
            new Among("ок", -1, 2, 0),
            new Among("ечок", 20, 1, 0),
            new Among("очечок", 21, 1, 0),
            new Among("очок", 20, 1, 0),
            new Among("ічок", 20, 1, 0),
            new Among("атко", -1, 1, 0),
            new Among("ятко", -1, 1, 0),
            new Among("ітко", -1, 1, 0),
            new Among("ечко", -1, 1, 0),
            new Among("очечко", 28, 1, 0),
            new Among("очко", -1, 1, 0),
            new Among("ічко", -1, 1, 0),
            new Among("енько", -1, 1, 0),
            new Among("есенько", 32, 1, 0),
            new Among("онько", -1, 1, 0),
            new Among("інько", -1, 1, 0),
            new Among("юсінько", 35, 1, 0),
            new Among("ісінько", 35, 1, 0),
            new Among("еньку", -1, 1, 0),
            new Among("унь", -1, 1, 0),
            new Among("ечкі", -1, 1, 0),
            new Among("очечкі", 40, 1, 0),
            new Among("очкі", -1, 1, 0),
            new Among("ічкі", -1, 1, 0),
            new Among("енькі", -1, 1, 0),
            new Among("есенькі", 44, 1, 0),
            new Among("онькі", -1, 1, 0),
            new Among("інькі", -1, 1, 0),
            new Among("юсінькі", 47, 1, 0),
            new Among("ісінькі", 47, 1, 0)
        };

        private static readonly Among[] a_10 = new[]
        {
            new Among("еньк", -1, 1, 0),
            new Among("есеньк", 0, 1, 0),
            new Among("оньк", -1, 1, 0),
            new Among("іньк", -1, 1, 0),
            new Among("юсіньк", 3, 1, 0),
            new Among("ісіньк", 3, 1, 0)
        };

        private static readonly Among[] a_11 = new[]
        {
            new Among("іннями", -1, 1, 0),
            new Among("інням", -1, 1, 0),
            new Among("іннях", -1, 1, 0),
            new Among("інь", -1, 1, 0),
            new Among("інню", -1, 1, 0),
            new Among("іння", -1, 1, 0),
            new Among("інні", -1, 1, 0)
        };

        private static readonly Among[] a_12 = new[]
        {
            new Among("аннями", -1, 1, 0),
            new Among("еннями", -1, 1, 0),
            new Among("яннями", -1, 1, 0),
            new Among("анням", -1, 1, 0),
            new Among("енням", -1, 1, 0),
            new Among("янням", -1, 1, 0),
            new Among("аннях", -1, 1, 0),
            new Among("еннях", -1, 1, 0),
            new Among("яннях", -1, 1, 0),
            new Among("ань", -1, 1, 0),
            new Among("ень", -1, 1, 0),
            new Among("янь", -1, 1, 0),
            new Among("анню", -1, 1, 0),
            new Among("енню", -1, 1, 0),
            new Among("янню", -1, 1, 0),
            new Among("ання", -1, 1, 0),
            new Among("ення", -1, 1, 0),
            new Among("яння", -1, 1, 0),
            new Among("анні", -1, 1, 0),
            new Among("енні", -1, 1, 0),
            new Among("янні", -1, 1, 0)
        };

        private static readonly Among[] a_13 = new[]
        {
            new Among("ов", -1, 1, 0),
            new Among("ув", -1, 1, 0),
            new Among("овув", 1, 1, 0),
            new Among("юв", -1, 1, 0),
            new Among("зьк", -1, 1, 0),
            new Among("ськ", -1, 1, 0),
            new Among("ізм", -1, 1, 0),
            new Among("ан", -1, 4, 0),
            new Among("ован", 7, 1, 0),
            new Among("уван", 7, 1, 0),
            new Among("юван", 7, 1, 0),
            new Among("івн", -1, 1, 0),
            new Among("ьн", -1, 1, 0),
            new Among("альн", 12, 3, 0),
            new Among("ельн", 12, 2, 0),
            new Among("ян", -1, 1, 0),
            new Among("уват", -1, 1, 0),
            new Among("іст", -1, 1, 0),
            new Among("ищ", -1, 1, 0)
        };

        private static readonly Among[] a_14 = new[]
        {
            new Among("л", -1, 2, 0),
            new Among("н", -1, 3, 0),
            new Among("іш", -1, 1, 0),
            new Among("ь", -1, 4, 0)
        };

        private static readonly Among[] a_15 = new[]
        {
            new Among("агрегати", -1, 96, 0),
            new Among("агроном", -1, 49, 0),
            new Among("адмірала", -1, 17, 0),
            new Among("аеродром", -1, 46, 0),
            new Among("аеродрому", 3, 46, 0),
            new Among("альбом", -1, 39, 0),
            new Among("альбому", 5, 39, 0),
            new Among("америці", -1, 188, 0),
            new Among("амстердам", -1, 60, 0),
            new Among("апарати", -1, 79, 0),
            new Among("артем", -1, 57, 0),
            new Among("архів", -1, -1, 0),
            new Among("астрахань", -1, 155, 0),
            new Among("астроном", -1, 48, 0),
            new Among("африці", -1, 191, 0),
            new Among("барабанні", -1, 182, 0),
            new Among("березань", -1, 154, 0),
            new Among("березень", -1, 123, 0),
            new Among("бориспіль", -1, 153, 0),
            new Among("ботошань", -1, 156, 0),
            new Among("бретань", -1, 166, 0),
            new Among("бруней", -1, 112, 0),
            new Among("будівель", -1, 144, 0),
            new Among("бібліотеці", -1, 194, 0),
            new Among("біля", -1, -1, 0),
            new Among("в'єтнам", -1, 59, 0),
            new Among("вадим", -1, 56, 0),
            new Among("вазі", -1, 200, 0),
            new Among("вартостей", -1, 1, 0),
            new Among("вартості", -1, 1, 0),
            new Among("вартість", -1, 1, 0),
            new Among("вартістю", -1, 1, 0),
            new Among("вдерлися", -1, 37, 0),
            new Among("вересень", -1, 129, 0),
            new Among("верств", -1, 29, 0),
            new Among("верства", 34, 29, 0),
            new Among("верстви", 34, 29, 0),
            new Among("верствою", 34, 29, 0),
            new Among("верству", 34, 29, 0),
            new Among("верстві", 34, 29, 0),
            new Among("весь", -1, -1, 0),
            new Among("вимерла", -1, 36, 0),
            new Among("вимерли", -1, 36, 0),
            new Among("виплати", -1, 86, 0),
            new Among("виставці", -1, 201, 0),
            new Among("витрати", -1, 67, 0),
            new Among("вплив", -1, -1, 0),
            new Among("втекти", -1, 33, 0),
            new Among("втрати", -1, 63, 0),
            new Among("відання", -1, 177, 0),
            new Among("віданні", -1, 177, 0),
            new Among("відстанню", -1, 163, 0),
            new Among("відстань", -1, 163, 0),
            new Among("відтоді", -1, -1, 0),
            new Among("вільям", -1, 54, 0),
            new Among("віці", -1, 185, 0),
            new Among("гавань", -1, 165, 0),
            new Among("галілей", -1, 120, 0),
            new Among("гармати", -1, 65, 0),
            new Among("генерала", -1, 16, 0),
            new Among("генерали", -1, 16, 0),
            new Among("геном", -1, 41, 0),
            new Among("геному", 61, 41, 0),
            new Among("голів", -1, 145, 0),
            new Among("гонці", -1, 211, 0),
            new Among("горбань", -1, 173, 0),
            new Among("гранати", -1, 91, 0),
            new Among("грудень", -1, 131, 0),
            new Among("далі", -1, -1, 0),
            new Among("данила", -1, 9, 0),
            new Among("данило", -1, 9, 0),
            new Among("данилом", 70, 9, 0),
            new Among("данилу", -1, 9, 0),
            new Among("данилі", -1, 9, 0),
            new Among("дев'яти", -1, 139, 0),
            new Among("демократи", -1, 94, 0),
            new Among("день", -1, 142, 0),
            new Among("депутати", -1, 66, 0),
            new Among("держав", -1, -1, 0),
            new Among("десь", -1, -1, 0),
            new Among("десяти", -1, 121, 0),
            new Among("десять", -1, 121, 0),
            new Among("джованні", -1, 161, 0),
            new Among("диплом", -1, 42, 0),
            new Among("дисплей", -1, 119, 0),
            new Among("дитина", -1, 141, 0),
            new Among("дитини", -1, 141, 0),
            new Among("дитиною", -1, 141, 0),
            new Among("дитину", -1, 141, 0),
            new Among("дитині", -1, 141, 0),
            new Among("днем", -1, 142, 0),
            new Among("дню", -1, 142, 0),
            new Among("дня", -1, 142, 0),
            new Among("дням", 92, 142, 0),
            new Among("днями", 93, 142, 0),
            new Among("днях", 92, 142, 0),
            new Among("дні", -1, 142, 0),
            new Among("днів", 96, 142, 0),
            new Among("довгань", -1, 174, 0),
            new Among("доменні", -1, 176, 0),
            new Among("дорогоцінні", -1, 180, 0),
            new Among("дорозі", -1, 196, 0),
            new Among("досить", -1, 32, 0),
            new Among("досконало", -1, 15, 0),
            new Among("досі", -1, -1, 0),
            new Among("дотепер", -1, -1, 0),
            new Among("дуже", -1, -1, 0),
            new Among("ділянці", -1, 197, 0),
            new Among("дісней", -1, 111, 0),
            new Among("економіці", -1, 219, 0),
            new Among("експонати", -1, 87, 0),
            new Among("еліти", -1, 81, 0),
            new Among("еней", -1, 113, 0),
            new Among("жовтень", -1, 130, 0),
            new Among("журнали", -1, 23, 0),
            new Among("завжди", -1, -1, 0),
            new Among("замало", -1, 12, 0),
            new Among("замість", -1, -1, 0),
            new Among("запити", -1, 93, 0),
            new Among("затоці", -1, 205, 0),
            new Among("збірці", -1, 222, 0),
            new Among("звідки", -1, -1, 0),
            new Among("звідси", -1, -1, 0),
            new Among("звідти", -1, -1, 0),
            new Among("звіти", -1, 82, 0),
            new Among("згодом", -1, -1, 0),
            new Among("земель", -1, 143, 0),
            new Among("знову", -1, -1, 0),
            new Among("камінь", -1, 136, 0),
            new Among("канали", -1, 22, 0),
            new Among("кандидати", -1, 76, 0),
            new Among("кардинала", -1, 19, 0),
            new Among("квартали", -1, 28, 0),
            new Among("квітень", -1, 124, 0),
            new Among("кирила", -1, 8, 0),
            new Among("кирило", -1, 8, 0),
            new Among("кирилом", 135, 8, 0),
            new Among("кирилу", -1, 8, 0),
            new Among("київ", -1, 4, 0),
            new Among("кладці", -1, 218, 0),
            new Among("клей", -1, 117, 0),
            new Among("книзі", -1, 190, 0),
            new Among("кого", -1, -1, 0),
            new Among("коли", -1, -1, 0),
            new Among("колись", 143, -1, 0),
            new Among("кому", -1, -1, 0),
            new Among("координати", -1, 74, 0),
            new Among("корінь", -1, 137, 0),
            new Among("кристала", -1, 26, 0),
            new Among("кристали", -1, 26, 0),
            new Among("критиці", -1, 224, 0),
            new Among("кубань", -1, 167, 0),
            new Among("куди", -1, -1, 0),
            new Among("кімнати", -1, 71, 0),
            new Among("лауреати", -1, 75, 0),
            new Among("ледь", -1, -1, 0),
            new Among("липень", -1, 127, 0),
            new Among("лише", -1, -1, 0),
            new Among("лозанні", -1, 162, 0),
            new Among("львів", -1, 148, 0),
            new Among("людей", -1, 6, 0),
            new Among("людина", -1, 6, 0),
            new Among("людини", -1, 6, 0),
            new Among("людиною", -1, 6, 0),
            new Among("людину", -1, 6, 0),
            new Among("людині", -1, 6, 0),
            new Among("лізі", -1, 187, 0),
            new Among("ліцей", -1, 100, 0),
            new Among("мавзолей", -1, 118, 0),
            new Among("мадам", -1, 53, 0),
            new Among("майже", -1, -1, 0),
            new Among("максим", -1, 55, 0),
            new Among("мало", -1, -1, 0),
            new Among("маргарити", -1, 90, 0),
            new Among("маршала", -1, 18, 0),
            new Among("масив", -1, -1, 0),
            new Among("матей", -1, 108, 0),
            new Among("матерію", -1, 31, 0),
            new Among("матерія", -1, 31, 0),
            new Among("матерією", -1, 31, 0),
            new Among("матерії", -1, 31, 0),
            new Among("мацей", -1, 106, 0),
            new Among("мексиці", -1, 202, 0),
            new Among("мельник", -1, 30, 0),
            new Among("мельника", 183, 30, 0),
            new Among("мельники", 183, 30, 0),
            new Among("мельником", 183, 30, 0),
            new Among("мельнику", 183, 30, 0),
            new Among("мельників", 183, 30, 0),
            new Among("метали", -1, 27, 0),
            new Among("миколаїв", -1, 151, 0),
            new Among("могила", -1, 7, 0),
            new Among("могили", -1, 7, 0),
            new Among("могилою", -1, 7, 0),
            new Among("могилу", -1, 7, 0),
            new Among("могилі", -1, 7, 0),
            new Among("музей", -1, 99, 0),
            new Among("музиці", -1, 208, 0),
            new Among("мінерали", -1, 25, 0),
            new Among("мініальбом", -1, 40, 0),
            new Among("мініальбому", 199, 40, 0),
            new Among("мішенню", -1, 175, 0),
            new Among("мішень", -1, 175, 0),
            new Among("напрям", -1, 51, 0),
            new Among("напрями", 203, 51, 0),
            new Among("науці", -1, 214, 0),
            new Among("невдало", -1, 14, 0),
            new Among("немало", -1, 13, 0),
            new Among("нескінченні", -1, 181, 0),
            new Among("нечисленні", -1, 179, 0),
            new Among("низці", -1, 217, 0),
            new Among("новела", -1, 38, 0),
            new Among("новели", -1, 38, 0),
            new Among("нічого", -1, -1, 0),
            new Among("обкладинці", -1, 226, 0),
            new Among("окрузі", -1, 186, 0),
            new Among("окрім", -1, -1, 0),
            new Among("оплати", -1, 83, 0),
            new Among("орбіти", -1, 70, 0),
            new Among("орфей", -1, 104, 0),
            new Among("освіти", -1, 61, 0),
            new Among("останню", -1, 157, 0),
            new Among("остання", -1, 157, 0),
            new Among("останні", -1, 157, 0),
            new Among("осіб", -1, 5, 0),
            new Among("осінь", -1, 147, 0),
            new Among("п'яти", -1, 138, 0),
            new Among("палати", -1, 64, 0),
            new Among("плити", -1, 78, 0),
            new Among("повноцінні", -1, 184, 0),
            new Among("повіти", -1, 92, 0),
            new Among("познань", -1, 169, 0),
            new Among("поки", -1, -1, 0),
            new Among("політиці", -1, 207, 0),
            new Among("померла", -1, 35, 0),
            new Among("померли", -1, 35, 0),
            new Among("померло", -1, 35, 0),
            new Among("померти", -1, 35, 0),
            new Among("посів", -1, -1, 0),
            new Among("потім", -1, -1, 0),
            new Among("празі", -1, 203, 0),
            new Among("практиці", -1, 198, 0),
            new Among("препарати", -1, 80, 0),
            new Among("привілей", -1, 116, 0),
            new Among("прийом", -1, 43, 0),
            new Among("прийому", 244, 43, 0),
            new Among("пристань", -1, 168, 0),
            new Among("присязі", -1, 195, 0),
            new Among("притаманні", -1, 178, 0),
            new Among("прометей", -1, 107, 0),
            new Among("промінь", -1, 135, 0),
            new Among("пророк", -1, 140, 0),
            new Among("пророка", 251, 140, 0),
            new Among("пророки", 251, 140, 0),
            new Among("пророком", 251, 140, 0),
            new Among("пророку", 251, 140, 0),
            new Among("пророків", 251, 140, 0),
            new Among("просвіти", -1, 72, 0),
            new Among("проти", -1, -1, 0),
            new Among("птолемей", -1, 109, 0),
            new Among("південні", -1, 158, 0),
            new Among("півфінали", -1, 21, 0),
            new Among("підготовці", -1, 210, 0),
            new Among("підйом", -1, 44, 0),
            new Among("підйому", 263, 44, 0),
            new Among("підтримці", -1, 215, 0),
            new Among("разом", -1, -1, 0),
            new Among("режим", -1, 50, 0),
            new Among("режими", 267, 50, 0),
            new Among("результати", -1, 62, 0),
            new Among("республіці", -1, 192, 0),
            new Among("ризі", -1, 227, 0),
            new Among("розробці", -1, 204, 0),
            new Among("році", -1, 3, 0),
            new Among("руці", -1, 221, 0),
            new Among("рязань", -1, 170, 0),
            new Among("рівень", -1, 132, 0),
            new Among("рік", -1, 3, 0),
            new Among("річці", -1, 189, 0),
            new Among("саме", -1, -1, 0),
            new Among("священні", -1, 160, 0),
            new Among("світи", -1, 84, 0),
            new Among("себе", -1, -1, 0),
            new Among("серпень", -1, 128, 0),
            new Among("сибір", -1, -1, 0),
            new Among("сигнали", -1, 24, 0),
            new Among("синдром", -1, 45, 0),
            new Among("синдрому", 286, 45, 0),
            new Among("смузі", -1, 193, 0),
            new Among("совість", -1, 2, 0),
            new Among("совістю", -1, 2, 0),
            new Among("совісті", -1, 2, 0),
            new Among("солдати", -1, 68, 0),
            new Among("сплати", -1, 85, 0),
            new Among("справ", -1, -1, 0),
            new Among("справді", 294, -1, 0),
            new Among("статей", -1, 97, 0),
            new Among("сторінці", -1, 213, 0),
            new Among("страти", -1, 73, 0),
            new Among("стрічці", -1, 220, 0),
            new Among("ступінь", -1, 134, 0),
            new Among("сьогодні", -1, -1, 0),
            new Among("сідней", -1, 110, 0),
            new Among("сімей", -1, 98, 0),
            new Among("січень", -1, 122, 0),
            new Among("тадей", -1, 105, 0),
            new Among("тайвань", -1, 164, 0),
            new Among("тебе", -1, -1, 0),
            new Among("тернопіль", -1, 152, 0),
            new Among("техніці", -1, 216, 0),
            new Among("тоді", -1, -1, 0),
            new Among("толстой", -1, 10, 0),
            new Among("тому", -1, -1, 0),
            new Among("точці", -1, 206, 0),
            new Among("травень", -1, 125, 0),
            new Among("треба", -1, -1, 0),
            new Among("трійці", -1, 212, 0),
            new Among("туди", -1, -1, 0),
            new Among("увазі", -1, 209, 0),
            new Among("увесь", -1, -1, 0),
            new Among("утекти", -1, 34, 0),
            new Among("учень", -1, 133, 0),
            new Among("фабриці", -1, 225, 0),
            new Among("формати", -1, 95, 0),
            new Among("фортепіанні", -1, 183, 0),
            new Among("футболці", -1, 199, 0),
            new Among("фінали", -1, 20, 0),
            new Among("хайнань", -1, 172, 0),
            new Among("харків", -1, 149, 0),
            new Among("хокей", -1, 101, 0),
            new Among("цитати", -1, 89, 0),
            new Among("чемпіонати", -1, 77, 0),
            new Among("червень", -1, 126, 0),
            new Among("черзі", -1, 223, 0),
            new Among("чернігів", -1, 150, 0),
            new Among("чимало", -1, 11, 0),
            new Among("чому", -1, -1, 0),
            new Among("шолом", -1, 47, 0),
            new Among("штати", -1, 69, 0),
            new Among("щоденні", -1, 159, 0),
            new Among("щойно", -1, -1, 0),
            new Among("ювілей", -1, 115, 0),
            new Among("юньнань", -1, 171, 0),
            new Among("євангеліє", -1, 146, 0),
            new Among("єврей", -1, 102, 0),
            new Among("єрусалим", -1, 58, 0),
            new Among("інакше", -1, -1, 0),
            new Among("інколи", -1, -1, 0),
            new Among("іноді", -1, -1, 0),
            new Among("іриней", -1, 114, 0),
            new Among("іслам", -1, 52, 0),
            new Among("іспити", -1, 88, 0),
            new Among("ієрей", -1, 103, 0)
        };

        private static readonly Among[] a_16 = new[]
        {
            new Among("ріг", -1, 15, 0),
            new Among("плід", -1, 11, 0),
            new Among("рід", -1, 12, 0),
            new Among("хід", -1, 1, 0),
            new Among("бік", -1, 13, 0),
            new Among("сік", -1, 16, 0),
            new Among("стіл", -1, 6, 0),
            new Among("дім", -1, 5, 0),
            new Among("бір", -1, 2, 0),
            new Among("ріст", -1, 3, 0),
            new Among("кіт", -1, 14, 0),
            new Among("ніч", -1, 4, 0),
            new Among("піч", -1, 7, 0),
            new Among("сіль", -1, 8, 0),
            new Among("кінь", -1, 9, 0),
            new Among("гість", -1, 10, 0)
        };

        private static readonly Among[] a_17 = new[]
        {
            new Among("сь", -1, -1, 0),
            new Among("лась", 0, -1, 0),
            new Among("всь", 0, -1, 0),
            new Among("тись", 0, -1, 0),
            new Among("ся", -1, -1, 0),
            new Among("вся", 4, -1, 0),
            new Among("тися", 4, -1, 0)
        };


        private bool r_professional()
        {
            int among_var;
            ket = cursor;
            among_var = find_among_b(a_8, null);
            if (among_var == 0)
            {
                return false;
            }
            bra = cursor;
            switch (among_var) {
                case 1: {
                    slice_del();
                    break;
                }
                case 2: {
                    if (!(eq_s_b("к")))
                    {
                        return false;
                    }
                    slice_del();
                    break;
                }
            }
            return true;
        }

        protected override bool stem()
        {
            int among_var;
            bool B_found_ty_noun;
            bool B_found_la_noun;
            bool B_found_verb;
            bool B_found_ia;
            bool B_found_professional;
            bool B_found_diminutive;
            int I_p2;
            int I_pV;
            {
                int c1 = cursor;
                bra = cursor;
                if (!(eq_s("най")))
                {
                    goto lab0;
                }
                ket = cursor;
                if (cursor >= limit)
                {
                    goto lab0;
                }
                slice_del();
            lab0: ;
                cursor = c1;
            }
            {
                int c2 = cursor;
                {
                    int c3 = cursor;
                    if (!(eq_s("окремо")))
                    {
                        goto lab2;
                    }
                    if (cursor < limit)
                    {
                        goto lab2;
                    }
                    cursor = c3;
                }
                limit_backward = cursor;
                cursor = limit;
                ket = cursor;
                if (!(eq_s_b("о")))
                {
                    goto lab2;
                }
                bra = cursor;
                slice_del();
                cursor = limit_backward;
                goto lab1;
            lab2: ;
                cursor = c2;
                bra = cursor;
                among_var = find_among(a_15, null);
                if (among_var == 0)
                {
                    goto lab3;
                }
                ket = cursor;
                if (cursor < limit)
                {
                    goto lab3;
                }
                switch (among_var) {
                    case 1: {
                        slice_from("вартост");
                        break;
                    }
                    case 2: {
                        slice_from("совіст");
                        break;
                    }
                    case 3: {
                        slice_from("рок");
                        break;
                    }
                    case 4: {
                        slice_from("києв");
                        break;
                    }
                    case 5: {
                        slice_from("особ");
                        break;
                    }
                    case 6: {
                        slice_from("люд");
                        break;
                    }
                    case 7: {
                        slice_from("могил");
                        break;
                    }
                    case 8: {
                        slice_from("кирил");
                        break;
                    }
                    case 9: {
                        slice_from("данил");
                        break;
                    }
                    case 10: {
                        slice_from("толст");
                        break;
                    }
                    case 11: {
                        slice_from("чимало");
                        break;
                    }
                    case 12: {
                        slice_from("замал");
                        break;
                    }
                    case 13: {
                        slice_from("немал");
                        break;
                    }
                    case 14: {
                        slice_from("невдал");
                        break;
                    }
                    case 15: {
                        slice_from("досконал");
                        break;
                    }
                    case 16: {
                        slice_from("генерал");
                        break;
                    }
                    case 17: {
                        slice_from("адмірал");
                        break;
                    }
                    case 18: {
                        slice_from("маршал");
                        break;
                    }
                    case 19: {
                        slice_from("кардинал");
                        break;
                    }
                    case 20: {
                        slice_from("фінал");
                        break;
                    }
                    case 21: {
                        slice_from("півфінал");
                        break;
                    }
                    case 22: {
                        slice_from("канал");
                        break;
                    }
                    case 23: {
                        slice_from("журнал");
                        break;
                    }
                    case 24: {
                        slice_from("сигнал");
                        break;
                    }
                    case 25: {
                        slice_from("мінерал");
                        break;
                    }
                    case 26: {
                        slice_from("кристал");
                        break;
                    }
                    case 27: {
                        slice_from("метал");
                        break;
                    }
                    case 28: {
                        slice_from("квартал");
                        break;
                    }
                    case 29: {
                        slice_from("верств");
                        break;
                    }
                    case 30: {
                        slice_from("мельник");
                        break;
                    }
                    case 31: {
                        slice_from("матері");
                        break;
                    }
                    case 32: {
                        slice_from("досить");
                        break;
                    }
                    case 33: {
                        slice_from("втек");
                        break;
                    }
                    case 34: {
                        slice_from("утек");
                        break;
                    }
                    case 35: {
                        slice_from("помер");
                        break;
                    }
                    case 36: {
                        slice_from("вимер");
                        break;
                    }
                    case 37: {
                        slice_from("вдер");
                        break;
                    }
                    case 38: {
                        slice_from("новел");
                        break;
                    }
                    case 39: {
                        slice_from("альбом");
                        break;
                    }
                    case 40: {
                        slice_from("мініальбом");
                        break;
                    }
                    case 41: {
                        slice_from("геном");
                        break;
                    }
                    case 42: {
                        slice_from("диплом");
                        break;
                    }
                    case 43: {
                        slice_from("прийом");
                        break;
                    }
                    case 44: {
                        slice_from("підйом");
                        break;
                    }
                    case 45: {
                        slice_from("синдром");
                        break;
                    }
                    case 46: {
                        slice_from("аеродром");
                        break;
                    }
                    case 47: {
                        slice_from("шолом");
                        break;
                    }
                    case 48: {
                        slice_from("астроном");
                        break;
                    }
                    case 49: {
                        slice_from("агроном");
                        break;
                    }
                    case 50: {
                        slice_from("режим");
                        break;
                    }
                    case 51: {
                        slice_from("напрям");
                        break;
                    }
                    case 52: {
                        slice_from("іслам");
                        break;
                    }
                    case 53: {
                        slice_from("мадам");
                        break;
                    }
                    case 54: {
                        slice_from("вільям");
                        break;
                    }
                    case 55: {
                        slice_from("максим");
                        break;
                    }
                    case 56: {
                        slice_from("вадим");
                        break;
                    }
                    case 57: {
                        slice_from("артем");
                        break;
                    }
                    case 58: {
                        slice_from("єрусалим");
                        break;
                    }
                    case 59: {
                        slice_from("в'єтнам");
                        break;
                    }
                    case 60: {
                        slice_from("амстердам");
                        break;
                    }
                    case 61: {
                        slice_from("освіт");
                        break;
                    }
                    case 62: {
                        slice_from("результат");
                        break;
                    }
                    case 63: {
                        slice_from("втрат");
                        break;
                    }
                    case 64: {
                        slice_from("палат");
                        break;
                    }
                    case 65: {
                        slice_from("гармат");
                        break;
                    }
                    case 66: {
                        slice_from("депутат");
                        break;
                    }
                    case 67: {
                        slice_from("витрат");
                        break;
                    }
                    case 68: {
                        slice_from("солдат");
                        break;
                    }
                    case 69: {
                        slice_from("штат");
                        break;
                    }
                    case 70: {
                        slice_from("орбіт");
                        break;
                    }
                    case 71: {
                        slice_from("кімнат");
                        break;
                    }
                    case 72: {
                        slice_from("просвіт");
                        break;
                    }
                    case 73: {
                        slice_from("страт");
                        break;
                    }
                    case 74: {
                        slice_from("координат");
                        break;
                    }
                    case 75: {
                        slice_from("лауреат");
                        break;
                    }
                    case 76: {
                        slice_from("кандидат");
                        break;
                    }
                    case 77: {
                        slice_from("чемпіонат");
                        break;
                    }
                    case 78: {
                        slice_from("плит");
                        break;
                    }
                    case 79: {
                        slice_from("апарат");
                        break;
                    }
                    case 80: {
                        slice_from("препарат");
                        break;
                    }
                    case 81: {
                        slice_from("еліт");
                        break;
                    }
                    case 82: {
                        slice_from("звіт");
                        break;
                    }
                    case 83: {
                        slice_from("оплат");
                        break;
                    }
                    case 84: {
                        slice_from("світ");
                        break;
                    }
                    case 85: {
                        slice_from("сплат");
                        break;
                    }
                    case 86: {
                        slice_from("виплат");
                        break;
                    }
                    case 87: {
                        slice_from("експонат");
                        break;
                    }
                    case 88: {
                        slice_from("іспит");
                        break;
                    }
                    case 89: {
                        slice_from("цитат");
                        break;
                    }
                    case 90: {
                        slice_from("маргарит");
                        break;
                    }
                    case 91: {
                        slice_from("гранат");
                        break;
                    }
                    case 92: {
                        slice_from("повіт");
                        break;
                    }
                    case 93: {
                        slice_from("запит");
                        break;
                    }
                    case 94: {
                        slice_from("демократ");
                        break;
                    }
                    case 95: {
                        slice_from("формат");
                        break;
                    }
                    case 96: {
                        slice_from("агрегат");
                        break;
                    }
                    case 97: {
                        slice_from("статт");
                        break;
                    }
                    case 98: {
                        slice_from("сім'");
                        break;
                    }
                    case 99: {
                        slice_from("музе");
                        break;
                    }
                    case 100: {
                        slice_from("ліце");
                        break;
                    }
                    case 101: {
                        slice_from("хоке");
                        break;
                    }
                    case 102: {
                        slice_from("євре");
                        break;
                    }
                    case 103: {
                        slice_from("ієре");
                        break;
                    }
                    case 104: {
                        slice_from("орфе");
                        break;
                    }
                    case 105: {
                        slice_from("таде");
                        break;
                    }
                    case 106: {
                        slice_from("маце");
                        break;
                    }
                    case 107: {
                        slice_from("промете");
                        break;
                    }
                    case 108: {
                        slice_from("мате");
                        break;
                    }
                    case 109: {
                        slice_from("птолеме");
                        break;
                    }
                    case 110: {
                        slice_from("сідне");
                        break;
                    }
                    case 111: {
                        slice_from("дісне");
                        break;
                    }
                    case 112: {
                        slice_from("бруне");
                        break;
                    }
                    case 113: {
                        slice_from("ене");
                        break;
                    }
                    case 114: {
                        slice_from("ірине");
                        break;
                    }
                    case 115: {
                        slice_from("ювіле");
                        break;
                    }
                    case 116: {
                        slice_from("привіле");
                        break;
                    }
                    case 117: {
                        slice_from("кле");
                        break;
                    }
                    case 118: {
                        slice_from("мавзоле");
                        break;
                    }
                    case 119: {
                        slice_from("диспле");
                        break;
                    }
                    case 120: {
                        slice_from("галіле");
                        break;
                    }
                    case 121: {
                        slice_from("десят");
                        break;
                    }
                    case 122: {
                        slice_from("січн");
                        break;
                    }
                    case 123: {
                        slice_from("березн");
                        break;
                    }
                    case 124: {
                        slice_from("квітн");
                        break;
                    }
                    case 125: {
                        slice_from("травн");
                        break;
                    }
                    case 126: {
                        slice_from("червн");
                        break;
                    }
                    case 127: {
                        slice_from("липн");
                        break;
                    }
                    case 128: {
                        slice_from("серпн");
                        break;
                    }
                    case 129: {
                        slice_from("вересн");
                        break;
                    }
                    case 130: {
                        slice_from("жовтн");
                        break;
                    }
                    case 131: {
                        slice_from("грудн");
                        break;
                    }
                    case 132: {
                        slice_from("рівн");
                        break;
                    }
                    case 133: {
                        slice_from("учн");
                        break;
                    }
                    case 134: {
                        slice_from("ступен");
                        break;
                    }
                    case 135: {
                        slice_from("промен");
                        break;
                    }
                    case 136: {
                        slice_from("камен");
                        break;
                    }
                    case 137: {
                        slice_from("корен");
                        break;
                    }
                    case 138: {
                        slice_from("п'ят");
                        break;
                    }
                    case 139: {
                        slice_from("дев'ят");
                        break;
                    }
                    case 140: {
                        slice_from("пророк");
                        break;
                    }
                    case 141: {
                        slice_from("діт");
                        break;
                    }
                    case 142: {
                        slice_from("дн");
                        break;
                    }
                    case 143: {
                        slice_from("земл");
                        break;
                    }
                    case 144: {
                        slice_from("будів");
                        break;
                    }
                    case 145: {
                        slice_from("голов");
                        break;
                    }
                    case 146: {
                        slice_from("євангел");
                        break;
                    }
                    case 147: {
                        slice_from("осен");
                        break;
                    }
                    case 148: {
                        slice_from("львов");
                        break;
                    }
                    case 149: {
                        slice_from("харков");
                        break;
                    }
                    case 150: {
                        slice_from("черніг");
                        break;
                    }
                    case 151: {
                        slice_from("миколаєв");
                        break;
                    }
                    case 152: {
                        slice_from("тернопол");
                        break;
                    }
                    case 153: {
                        slice_from("бориспол");
                        break;
                    }
                    case 154: {
                        slice_from("березан");
                        break;
                    }
                    case 155: {
                        slice_from("астрахан");
                        break;
                    }
                    case 156: {
                        slice_from("ботошан");
                        break;
                    }
                    case 157: {
                        slice_from("остан");
                        break;
                    }
                    case 158: {
                        slice_from("півден");
                        break;
                    }
                    case 159: {
                        slice_from("щоден");
                        break;
                    }
                    case 160: {
                        slice_from("священ");
                        break;
                    }
                    case 161: {
                        slice_from("джован");
                        break;
                    }
                    case 162: {
                        slice_from("лозан");
                        break;
                    }
                    case 163: {
                        slice_from("відстан");
                        break;
                    }
                    case 164: {
                        slice_from("тайван");
                        break;
                    }
                    case 165: {
                        slice_from("гаван");
                        break;
                    }
                    case 166: {
                        slice_from("бретан");
                        break;
                    }
                    case 167: {
                        slice_from("кубан");
                        break;
                    }
                    case 168: {
                        slice_from("пристан");
                        break;
                    }
                    case 169: {
                        slice_from("познан");
                        break;
                    }
                    case 170: {
                        slice_from("рязан");
                        break;
                    }
                    case 171: {
                        slice_from("юньнан");
                        break;
                    }
                    case 172: {
                        slice_from("хайнан");
                        break;
                    }
                    case 173: {
                        slice_from("горбан");
                        break;
                    }
                    case 174: {
                        slice_from("довган");
                        break;
                    }
                    case 175: {
                        slice_from("мішен");
                        break;
                    }
                    case 176: {
                        slice_from("домен");
                        break;
                    }
                    case 177: {
                        slice_from("відан");
                        break;
                    }
                    case 178: {
                        slice_from("притаман");
                        break;
                    }
                    case 179: {
                        slice_from("нечислен");
                        break;
                    }
                    case 180: {
                        slice_from("дорогоцін");
                        break;
                    }
                    case 181: {
                        slice_from("нескінчен");
                        break;
                    }
                    case 182: {
                        slice_from("барабан");
                        break;
                    }
                    case 183: {
                        slice_from("фортепіан");
                        break;
                    }
                    case 184: {
                        slice_from("повноцін");
                        break;
                    }
                    case 185: {
                        slice_from("вік");
                        break;
                    }
                    case 186: {
                        slice_from("округ");
                        break;
                    }
                    case 187: {
                        slice_from("ліг");
                        break;
                    }
                    case 188: {
                        slice_from("америк");
                        break;
                    }
                    case 189: {
                        slice_from("річк");
                        break;
                    }
                    case 190: {
                        slice_from("книг");
                        break;
                    }
                    case 191: {
                        slice_from("африк");
                        break;
                    }
                    case 192: {
                        slice_from("республік");
                        break;
                    }
                    case 193: {
                        slice_from("смуг");
                        break;
                    }
                    case 194: {
                        slice_from("бібліотек");
                        break;
                    }
                    case 195: {
                        slice_from("присяг");
                        break;
                    }
                    case 196: {
                        slice_from("дорог");
                        break;
                    }
                    case 197: {
                        slice_from("ділянк");
                        break;
                    }
                    case 198: {
                        slice_from("практик");
                        break;
                    }
                    case 199: {
                        slice_from("футболк");
                        break;
                    }
                    case 200: {
                        slice_from("ваг");
                        break;
                    }
                    case 201: {
                        slice_from("виставк");
                        break;
                    }
                    case 202: {
                        slice_from("мексик");
                        break;
                    }
                    case 203: {
                        slice_from("праг");
                        break;
                    }
                    case 204: {
                        slice_from("розробк");
                        break;
                    }
                    case 205: {
                        slice_from("заток");
                        break;
                    }
                    case 206: {
                        slice_from("точк");
                        break;
                    }
                    case 207: {
                        slice_from("політик");
                        break;
                    }
                    case 208: {
                        slice_from("музик");
                        break;
                    }
                    case 209: {
                        slice_from("уваг");
                        break;
                    }
                    case 210: {
                        slice_from("підготовк");
                        break;
                    }
                    case 211: {
                        slice_from("гонк");
                        break;
                    }
                    case 212: {
                        slice_from("трійк");
                        break;
                    }
                    case 213: {
                        slice_from("сторінк");
                        break;
                    }
                    case 214: {
                        slice_from("наук");
                        break;
                    }
                    case 215: {
                        slice_from("підтримк");
                        break;
                    }
                    case 216: {
                        slice_from("технік");
                        break;
                    }
                    case 217: {
                        slice_from("низк");
                        break;
                    }
                    case 218: {
                        slice_from("кладк");
                        break;
                    }
                    case 219: {
                        slice_from("економік");
                        break;
                    }
                    case 220: {
                        slice_from("стрічк");
                        break;
                    }
                    case 221: {
                        slice_from("рук");
                        break;
                    }
                    case 222: {
                        slice_from("збірк");
                        break;
                    }
                    case 223: {
                        slice_from("черг");
                        break;
                    }
                    case 224: {
                        slice_from("критик");
                        break;
                    }
                    case 225: {
                        slice_from("фабрик");
                        break;
                    }
                    case 226: {
                        slice_from("обкладинк");
                        break;
                    }
                    case 227: {
                        slice_from("риг");
                        break;
                    }
                }
                goto lab1;
            lab3: ;
                cursor = c2;
                {
                    int c4 = cursor;
                    limit_backward = cursor;
                    cursor = limit;
                    ket = cursor;
                    among_var = find_among_b(a_16, null);
                    if (among_var == 0)
                    {
                        goto lab4;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1: {
                            slice_from("ход");
                            break;
                        }
                        case 2: {
                            slice_from("бор");
                            break;
                        }
                        case 3: {
                            slice_from("рост");
                            break;
                        }
                        case 4: {
                            slice_from("ноч");
                            break;
                        }
                        case 5: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("дом");
                            break;
                        }
                        case 6: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("стол");
                            break;
                        }
                        case 7: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("печ");
                            break;
                        }
                        case 8: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("сол");
                            break;
                        }
                        case 9: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("кон");
                            break;
                        }
                        case 10: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("гост");
                            break;
                        }
                        case 11: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("плод");
                            break;
                        }
                        case 12: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("род");
                            break;
                        }
                        case 13: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("бок");
                            break;
                        }
                        case 14: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("кот");
                            break;
                        }
                        case 15: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("рог");
                            break;
                        }
                        case 16: {
                            if (cursor > limit_backward)
                            {
                                goto lab4;
                            }
                            slice_from("сок");
                            break;
                        }
                    }
                    cursor = limit_backward;
                lab4: ;
                    cursor = c4;
                }
                B_found_la_noun = false;
                B_found_ty_noun = false;
                {
                    int c5 = cursor;
                    limit_backward = cursor;
                    cursor = limit;
                    {
                        int c6 = limit - cursor;
                        if (find_among_b(a_17, null) == 0)
                        {
                            {
                                cursor = limit - c6;
                                goto lab6;
                            }
                        }
                    lab6: ;
                    }
                    {
                        int c7 = limit - cursor;
                        if (!(eq_s_b("ла")))
                        {
                            goto lab10;
                        }
                        goto lab9;
                    lab10: ;
                        if (!(eq_s_b("ли")))
                        {
                            goto lab11;
                        }
                        goto lab9;
                    lab11: ;
                        if (!(eq_s_b("ло")))
                        {
                            goto lab8;
                        }
                    lab9: ;
                        {
                            int c8 = limit - cursor;
                            if (!(eq_s_b("о")))
                            {
                                goto lab13;
                            }
                            if (!(eq_s_b("р")))
                            {
                                goto lab14;
                            }
                            goto lab13;
                        lab14: ;
                            goto lab12;
                        lab13: ;
                            cursor = limit - c8;
                            if (!(eq_s_b("л")))
                            {
                                goto lab15;
                            }
                            goto lab12;
                        lab15: ;
                            cursor = limit - c8;
                            if (!(eq_s_b("т")))
                            {
                                goto lab16;
                            }
                            {
                                int c9 = limit - cursor;
                                if (!(eq_s_b("с")))
                                {
                                    goto lab17;
                                }
                                if (cursor > limit_backward)
                                {
                                    goto lab17;
                                }
                                goto lab16;
                            lab17: ;
                                cursor = limit - c9;
                            }
                            goto lab12;
                        lab16: ;
                            cursor = limit - c8;
                            if (!(eq_s_b("д")))
                            {
                                goto lab18;
                            }
                            goto lab12;
                        lab18: ;
                            cursor = limit - c8;
                            if (!(eq_s_b("в")))
                            {
                                goto lab19;
                            }
                            goto lab12;
                        lab19: ;
                            cursor = limit - c8;
                            if (!(eq_s_b("й")))
                            {
                                goto lab20;
                            }
                            goto lab12;
                        lab20: ;
                            cursor = limit - c8;
                            if (!(eq_s_b("б")))
                            {
                                goto lab21;
                            }
                            goto lab12;
                        lab21: ;
                            cursor = limit - c8;
                            if (!(eq_s_b("п")))
                            {
                                goto lab22;
                            }
                            goto lab12;
                        lab22: ;
                            cursor = limit - c8;
                            if (!(eq_s_b("р")))
                            {
                                goto lab23;
                            }
                            goto lab12;
                        lab23: ;
                            cursor = limit - c8;
                            if (!(eq_s_b("е")))
                            {
                                goto lab8;
                            }
                            if (!(eq_s_b("в")))
                            {
                                goto lab24;
                            }
                            goto lab8;
                        lab24: ;
                        }
                    lab12: ;
                        B_found_la_noun = true;
                        goto lab7;
                    lab8: ;
                        cursor = limit - c7;
                        if (!(eq_s_b("ти")))
                        {
                            goto lab5;
                        }
                        if (!(eq_s_b("н")))
                        {
                            goto lab26;
                        }
                        goto lab25;
                    lab26: ;
                        if (!(eq_s_b("е")))
                        {
                            goto lab27;
                        }
                        goto lab25;
                    lab27: ;
                        if (!(eq_s_b("о")))
                        {
                            goto lab28;
                        }
                        goto lab25;
                    lab28: ;
                        if (!(eq_s_b("іс")))
                        {
                            goto lab29;
                        }
                        goto lab25;
                    lab29: ;
                        if (!(eq_s_b("ис")))
                        {
                            goto lab30;
                        }
                        goto lab25;
                    lab30: ;
                        if (!(eq_s_b("к")))
                        {
                            goto lab31;
                        }
                        goto lab25;
                    lab31: ;
                        if (!(eq_s_b("р")))
                        {
                            goto lab32;
                        }
                        goto lab25;
                    lab32: ;
                        if (!(eq_s_b("ш")))
                        {
                            goto lab33;
                        }
                        goto lab25;
                    lab33: ;
                        if (!(eq_s_b("ф")))
                        {
                            goto lab34;
                        }
                        goto lab25;
                    lab34: ;
                        if (!(eq_s_b("х")))
                        {
                            goto lab35;
                        }
                        goto lab25;
                    lab35: ;
                        if (!(eq_s_b("п")))
                        {
                            goto lab36;
                        }
                        goto lab25;
                    lab36: ;
                        if (!(eq_s_b("б")))
                        {
                            goto lab37;
                        }
                        goto lab25;
                    lab37: ;
                        if (!(eq_s_b("в")))
                        {
                            goto lab38;
                        }
                        goto lab25;
                    lab38: ;
                        if (!(eq_s_b("л")))
                        {
                            goto lab39;
                        }
                        goto lab25;
                    lab39: ;
                        if (!(eq_s_b("м")))
                        {
                            goto lab40;
                        }
                        goto lab25;
                    lab40: ;
                        if (!(eq_s_b("т")))
                        {
                            goto lab41;
                        }
                        goto lab25;
                    lab41: ;
                        if (!(eq_s_b("ь")))
                        {
                            goto lab42;
                        }
                        goto lab25;
                    lab42: ;
                        if (!(eq_s_b("ю")))
                        {
                            goto lab43;
                        }
                        goto lab25;
                    lab43: ;
                        if (!(eq_s_b("є")))
                        {
                            goto lab5;
                        }
                    lab25: ;
                        B_found_ty_noun = true;
                    }
                lab7: ;
                    cursor = limit_backward;
                lab5: ;
                    cursor = c5;
                }
                B_found_diminutive = false;
                B_found_professional = false;
                B_found_ia = false;
                B_found_verb = false;
                I_pV = limit;
                I_p2 = limit;
                {
                    int c10 = cursor;
                    {

                        int ret = out_grouping(g_v, 1072, 1111, true);
                        if (ret < 0)
                        {
                            goto lab44;
                        }

                        cursor += ret;
                    }
                    I_pV = cursor;
                    {

                        int ret = in_grouping(g_v, 1072, 1111, true);
                        if (ret < 0)
                        {
                            goto lab44;
                        }

                        cursor += ret;
                    }
                    {

                        int ret = out_grouping(g_v, 1072, 1111, true);
                        if (ret < 0)
                        {
                            goto lab44;
                        }

                        cursor += ret;
                    }
                    {

                        int ret = in_grouping(g_v, 1072, 1111, true);
                        if (ret < 0)
                        {
                            goto lab44;
                        }

                        cursor += ret;
                    }
                    I_p2 = cursor;
                lab44: ;
                    cursor = c10;
                }
                {
                    int c11 = cursor;
                    {
                        int c = cursor + 3;
                        if (c > limit)
                        {
                            return false;
                        }
                        cursor = c;
                    }
                    if (I_pV >= cursor)
                    {
                        goto lab45;
                    }
                    I_pV = cursor;
                lab45: ;
                    cursor = c11;
                }
                limit_backward = cursor;
                cursor = limit;
                if (cursor < I_pV)
                {
                    return false;
                }
                int c12 = limit_backward;
                limit_backward = I_pV;
                {
                    int c13 = limit - cursor;
                    {
                        int c14 = limit - cursor;
                        ket = cursor;
                        among_var = find_among_b(a_0, null);
                        if (among_var == 0)
                        {
                            goto lab48;
                        }
                        bra = cursor;
                        switch (among_var) {
                            case 1: {
                                if (!(eq_s_b("а")))
                                {
                                    goto lab50;
                                }
                                goto lab49;
                            lab50: ;
                                if (!(eq_s_b("я")))
                                {
                                    goto lab48;
                                }
                            lab49: ;
                                slice_del();
                                break;
                            }
                            case 2: {
                                slice_del();
                                break;
                            }
                            case 3: {
                                B_found_verb = true;
                                slice_del();
                                break;
                            }
                            case 4: {
                                B_found_verb = true;
                                slice_from("ув");
                                break;
                            }
                            case 5: {
                                B_found_verb = true;
                                slice_from("юв");
                                break;
                            }
                        }
                        goto lab47;
                    lab48: ;
                        cursor = limit - c14;
                        ket = cursor;
                        among_var = find_among_b(a_1, null);
                        if (among_var == 0)
                        {
                            goto lab51;
                        }
                        bra = cursor;
                        switch (among_var) {
                            case 1: {
                                slice_del();
                                break;
                            }
                            case 2: {
                                slice_from("ув");
                                break;
                            }
                            case 3: {
                                slice_from("юв");
                                break;
                            }
                        }
                        B_found_verb = true;
                        goto lab47;
                    lab51: ;
                        cursor = limit - c14;
                        {
                            int c15 = limit - cursor;
                            ket = cursor;
                            if (find_among_b(a_2, null) == 0)
                            {
                                {
                                    cursor = limit - c15;
                                    goto lab52;
                                }
                            }
                            bra = cursor;
                            slice_del();
                            B_found_verb = true;
                        lab52: ;
                        }
                        {
                            int c16 = limit - cursor;
                            {
                                int c17 = limit - cursor;
                                if (cursor < I_p2)
                                {
                                    goto lab56;
                                }
                                int c18 = limit_backward;
                                limit_backward = I_p2;
                                ket = cursor;
                                if (find_among_b(a_11, null) == 0)
                                {
                                    {
                                        limit_backward = c18;
                                        goto lab56;
                                    }
                                }
                                bra = cursor;
                                limit_backward = c18;
                                B_found_ia = true;
                                B_found_verb = true;
                                slice_del();
                                goto lab55;
                            lab56: ;
                                cursor = limit - c17;
                                ket = cursor;
                                if (find_among_b(a_12, null) == 0)
                                {
                                    goto lab54;
                                }
                                bra = cursor;
                                B_found_ia = true;
                                B_found_verb = true;
                                slice_del();
                            }
                        lab55: ;
                            goto lab53;
                        lab54: ;
                            cursor = limit - c16;
                            {
                                int c19 = limit - cursor;
                                {
                                    int c20 = limit - cursor;
                                    if (!r_professional())
                                        goto lab59;
                                    B_found_professional = true;
                                    goto lab58;
                                lab59: ;
                                    cursor = limit - c20;
                                    ket = cursor;
                                    among_var = find_among_b(a_9, null);
                                    if (among_var == 0)
                                    {
                                        goto lab57;
                                    }
                                    bra = cursor;
                                    switch (among_var) {
                                        case 1: {
                                            slice_del();
                                            break;
                                        }
                                        case 2: {
                                            slice_from("к");
                                            break;
                                        }
                                    }
                                    B_found_diminutive = true;
                                }
                            lab58: ;
                            lab57: ;
                                cursor = limit - c19;
                            }
                            if (B_found_professional)
                            {
                                goto lab46;
                            }
                            {
                                int c21 = limit - cursor;
                                {
                                    int c22 = limit - cursor;
                                    ket = cursor;
                                    if (find_among_b(a_3, null) == 0)
                                    {
                                        goto lab63;
                                    }
                                    bra = cursor;
                                    if (I_p2 > cursor)
                                    {
                                        goto lab63;
                                    }
                                    B_found_ia = true;
                                    slice_del();
                                    goto lab62;
                                lab63: ;
                                    cursor = limit - c22;
                                    ket = cursor;
                                    among_var = find_among_b(a_4, null);
                                    if (among_var == 0)
                                    {
                                        goto lab61;
                                    }
                                    bra = cursor;
                                    switch (among_var) {
                                        case 1: {
                                            slice_del();
                                            break;
                                        }
                                        case 2: {
                                            if (!(eq_s_b("ж")))
                                            {
                                                goto lab65;
                                            }
                                            goto lab64;
                                        lab65: ;
                                            if (!(eq_s_b("ч")))
                                            {
                                                goto lab66;
                                            }
                                            goto lab64;
                                        lab66: ;
                                            if (!(eq_s_b("ш")))
                                            {
                                                goto lab67;
                                            }
                                            goto lab64;
                                        lab67: ;
                                            if (!(eq_s_b("щ")))
                                            {
                                                goto lab61;
                                            }
                                        lab64: ;
                                            slice_del();
                                            break;
                                        }
                                    }
                                }
                            lab62: ;
                                goto lab60;
                            lab61: ;
                                cursor = limit - c21;
                                {
                                    int c23 = limit - cursor;
                                    ket = cursor;
                                    if (!(eq_s_b("остей")))
                                    {
                                        goto lab70;
                                    }
                                    bra = cursor;
                                    if (cursor <= limit_backward)
                                    {
                                        goto lab70;
                                    }
                                    slice_del();
                                    goto lab69;
                                lab70: ;
                                    cursor = limit - c23;
                                    ket = cursor;
                                    among_var = find_among_b(a_5, null);
                                    if (among_var == 0)
                                    {
                                        goto lab68;
                                    }
                                    bra = cursor;
                                    switch (among_var) {
                                        case 1: {
                                            B_found_ia = true;
                                            slice_del();
                                            break;
                                        }
                                        case 2: {
                                            B_found_ia = true;
                                            {
                                                int c24 = limit - cursor;
                                                if (cursor > limit_backward)
                                                {
                                                    goto lab74;
                                                }
                                                goto lab73;
                                            lab74: ;
                                                if (!(eq_s_b("т")))
                                                {
                                                    goto lab75;
                                                }
                                                goto lab73;
                                            lab75: ;
                                                if (!(eq_s_b("ч")))
                                                {
                                                    goto lab76;
                                                }
                                                goto lab73;
                                            lab76: ;
                                                if (!(eq_s_b("ш")))
                                                {
                                                    goto lab77;
                                                }
                                                goto lab73;
                                            lab77: ;
                                                if (!(eq_s_b("щ")))
                                                {
                                                    goto lab78;
                                                }
                                                goto lab73;
                                            lab78: ;
                                                if (!(eq_s_b("м")))
                                                {
                                                    goto lab79;
                                                }
                                                goto lab73;
                                            lab79: ;
                                                if (!(eq_s_b("н")))
                                                {
                                                    goto lab80;
                                                }
                                                goto lab73;
                                            lab80: ;
                                                if (!(eq_s_b("л")))
                                                {
                                                    goto lab72;
                                                }
                                            lab73: ;
                                                slice_del();
                                                goto lab71;
                                            lab72: ;
                                                cursor = limit - c24;
                                                slice_from("е");
                                            }
                                        lab71: ;
                                            break;
                                        }
                                        case 3: {
                                            slice_del();
                                            break;
                                        }
                                        case 4: {
                                            if (in_grouping_b(g_v, 1072, 1111, false) != 0)
                                            {
                                                goto lab81;
                                            }
                                            goto lab68;
                                        lab81: ;
                                            B_found_ia = true;
                                            slice_del();
                                            break;
                                        }
                                        case 5: {
                                            {
                                                int c25 = limit - cursor;
                                                if (!(eq_s_b("с")))
                                                {
                                                    goto lab84;
                                                }
                                                goto lab83;
                                            lab84: ;
                                                if (!(eq_s_b("ц")))
                                                {
                                                    goto lab85;
                                                }
                                                goto lab83;
                                            lab85: ;
                                                if (!(eq_s_b("'")))
                                                {
                                                    goto lab82;
                                                }
                                            lab83: ;
                                                goto lab68;
                                            lab82: ;
                                                cursor = limit - c25;
                                            }
                                            B_found_ia = true;
                                            slice_del();
                                            break;
                                        }
                                        case 6: {
                                            slice_from("ув");
                                            break;
                                        }
                                        case 7: {
                                            slice_from("юв");
                                            break;
                                        }
                                        case 8: {
                                            if (!(eq_s_b("о")))
                                            {
                                                goto lab86;
                                            }
                                            goto lab68;
                                        lab86: ;
                                            if (cursor > limit_backward)
                                            {
                                                goto lab88;
                                            }
                                            goto lab87;
                                        lab88: ;
                                            if (in_grouping_b(g_v, 1072, 1111, false) != 0)
                                            {
                                                goto lab68;
                                            }
                                        lab87: ;
                                            slice_del();
                                            break;
                                        }
                                        case 9: {
                                            {
                                                int c26 = limit - cursor;
                                                if (!(eq_s_b("ств")))
                                                {
                                                    goto lab91;
                                                }
                                                goto lab90;
                                            lab91: ;
                                                if (!(eq_s_b("цтв")))
                                                {
                                                    goto lab89;
                                                }
                                            lab90: ;
                                                goto lab68;
                                            lab89: ;
                                                cursor = limit - c26;
                                            }
                                            slice_del();
                                            break;
                                        }
                                        case 10: {
                                            if (B_found_la_noun)
                                            {
                                                goto lab68;
                                            }
                                            slice_del();
                                            break;
                                        }
                                        case 11: {
                                            if (!(eq_s_b("іст")))
                                            {
                                                goto lab92;
                                            }
                                            goto lab68;
                                        lab92: ;
                                            slice_del();
                                            break;
                                        }
                                        case 12: {
                                            if (B_found_ty_noun)
                                            {
                                                goto lab68;
                                            }
                                            slice_del();
                                            break;
                                        }
                                    }
                                }
                            lab69: ;
                                B_found_verb = true;
                                goto lab60;
                            lab68: ;
                                cursor = limit - c21;
                                {
                                    int c27 = limit - cursor;
                                    ket = cursor;
                                    if (find_among_b(a_6, null) == 0)
                                    {
                                        goto lab94;
                                    }
                                    bra = cursor;
                                    if (cursor <= limit_backward)
                                    {
                                        goto lab94;
                                    }
                                    slice_del();
                                    goto lab93;
                                lab94: ;
                                    cursor = limit - c27;
                                    ket = cursor;
                                    among_var = find_among_b(a_7, null);
                                    if (among_var == 0)
                                    {
                                        goto lab46;
                                    }
                                    bra = cursor;
                                    switch (among_var) {
                                        case 1: {
                                            slice_from("ість");
                                            break;
                                        }
                                        case 2: {
                                            slice_from("ц");
                                            break;
                                        }
                                        case 3: {
                                            slice_del();
                                            break;
                                        }
                                    }
                                }
                            lab93: ;
                            }
                        lab60: ;
                        }
                    lab53: ;
                    }
                lab47: ;
                lab46: ;
                    cursor = limit - c13;
                }
                {
                    int c28 = limit - cursor;
                    ket = cursor;
                    if (find_among_b(a_10, null) == 0)
                    {
                        {
                            cursor = limit - c28;
                            goto lab95;
                        }
                    }
                    bra = cursor;
                    slice_del();
                    B_found_diminutive = true;
                lab95: ;
                }
                {
                    int c29 = limit - cursor;
                    if (B_found_diminutive)
                    {
                        goto lab96;
                    }
                    if (B_found_professional)
                    {
                        goto lab96;
                    }
                    if (B_found_ia)
                    {
                        goto lab96;
                    }
                    if (!r_professional())
                        goto lab96;
                lab96: ;
                    cursor = limit - c29;
                }
                {
                    int c30 = limit - cursor;
                    if (B_found_verb)
                    {
                        goto lab97;
                    }
                    ket = cursor;
                    if (!(eq_s_b("іш")))
                    {
                        goto lab97;
                    }
                    bra = cursor;
                    slice_del();
                lab97: ;
                    cursor = limit - c30;
                }
                {
                    int c31 = limit - cursor;
                    if (cursor < I_p2)
                    {
                        goto lab98;
                    }
                    int c32 = limit_backward;
                    limit_backward = I_p2;
                    ket = cursor;
                    among_var = find_among_b(a_13, null);
                    if (among_var == 0)
                    {
                        {
                            limit_backward = c32;
                            goto lab98;
                        }
                    }
                    bra = cursor;
                    limit_backward = c32;
                    switch (among_var) {
                        case 1: {
                            slice_del();
                            break;
                        }
                        case 2: {
                            {
                                int c33 = limit - cursor;
                                if (!(eq_s_b("в")))
                                {
                                    goto lab100;
                                }
                                slice_del();
                                goto lab99;
                            lab100: ;
                                cursor = limit - c33;
                                slice_from("ел");
                            }
                        lab99: ;
                            break;
                        }
                        case 3: {
                            {
                                int c34 = limit - cursor;
                                if (!(eq_s_b("ув")))
                                {
                                    goto lab104;
                                }
                                goto lab103;
                            lab104: ;
                                if (!(eq_s_b("юв")))
                                {
                                    goto lab102;
                                }
                            lab103: ;
                                slice_del();
                                goto lab101;
                            lab102: ;
                                cursor = limit - c34;
                                slice_from("ал");
                            }
                        lab101: ;
                            break;
                        }
                        case 4: {
                            if (!(eq_s_b("ув")))
                            {
                                goto lab106;
                            }
                            goto lab105;
                        lab106: ;
                            if (!(eq_s_b("юв")))
                            {
                                goto lab98;
                            }
                        lab105: ;
                            slice_del();
                            break;
                        }
                    }
                lab98: ;
                    cursor = limit - c31;
                }
                {
                    int c35 = limit - cursor;
                    ket = cursor;
                    among_var = find_among_b(a_14, null);
                    if (among_var == 0)
                    {
                        goto lab107;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1: {
                            if (B_found_verb)
                            {
                                goto lab107;
                            }
                            slice_del();
                            ket = cursor;
                            if (!(eq_s_b("н")))
                            {
                                goto lab107;
                            }
                            bra = cursor;
                            if (!(eq_s_b("н")))
                            {
                                goto lab107;
                            }
                            slice_del();
                            break;
                        }
                        case 2: {
                            if (!(eq_s_b("б")))
                            {
                                goto lab109;
                            }
                            goto lab108;
                        lab109: ;
                            if (!(eq_s_b("п")))
                            {
                                goto lab110;
                            }
                            goto lab108;
                        lab110: ;
                            if (!(eq_s_b("в")))
                            {
                                goto lab111;
                            }
                            goto lab108;
                        lab111: ;
                            if (!(eq_s_b("м")))
                            {
                                goto lab107;
                            }
                        lab108: ;
                            slice_del();
                            break;
                        }
                        case 3: {
                            if (!(eq_s_b("н")))
                            {
                                goto lab107;
                            }
                            slice_del();
                            break;
                        }
                        case 4: {
                            slice_del();
                            break;
                        }
                    }
                lab107: ;
                    cursor = limit - c35;
                }
                limit_backward = c12;
                cursor = limit_backward;
            }
        lab1: ;
            return true;
        }

    }
}

