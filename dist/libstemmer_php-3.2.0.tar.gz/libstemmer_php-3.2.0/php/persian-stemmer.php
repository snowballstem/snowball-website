<?php
// Generated from persian.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballPersianStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["", -1, 7],
        [" ", 0, 6],
        ["\u{623}", 0, 4],
        ["\u{624}", 0, 5],
        ["\u{625}", 0, 4],
        ["\u{626}", 0, 2],
        ["\u{629}", 0, 3],
        ["\u{643}", 0, 1],
        ["\u{64A}", 0, 2],
        ["\u{6C1}", 0, 3],
        ["\u{200D}", 0, 6]
    ];

    private const array A_1 = [
        ["\u{645}\u{6CC}\u{200C}", -1, 2],
        ["\u{646}\u{645}\u{6CC}\u{200C}", -1, 1]
    ];

    private const array A_2 = [
        ["\u{648}\u{627}\u{646}", -1, -1],
        ["\u{633}\u{62A}\u{627}\u{646}", -1, -1],
        ["\u{631}\u{627}\u{646}", -1, -1],
        ["\u{633}\u{627}\u{646}", -1, -1]
    ];

    private const array A_3 = [
        ["\u{6AF}\u{6CC}\u{644}\u{627}\u{646}", -1, 1],
        ["\u{622}\u{644}\u{645}\u{627}\u{646}", -1, 1],
        ["\u{645}\u{633}\u{644}\u{645}\u{627}\u{646}", -1, 1],
        ["\u{633}\u{644}\u{6CC}\u{645}\u{627}\u{646}", -1, 1],
        ["\u{627}\u{6CC}\u{645}\u{627}\u{646}", -1, 1],
        ["\u{67E}\u{6CC}\u{645}\u{627}\u{646}", -1, 1],
        ["\u{633}\u{627}\u{62E}\u{62A}\u{645}\u{627}\u{646}", -1, 1],
        ["\u{631}\u{645}\u{627}\u{646}", -1, 1],
        ["\u{642}\u{647}\u{631}\u{645}\u{627}\u{646}", 7, 1],
        ["\u{6A9}\u{631}\u{645}\u{627}\u{646}", 7, 1],
        ["\u{62F}\u{631}\u{645}\u{627}\u{646}", 7, 1],
        ["\u{647}\u{645}\u{632}\u{645}\u{627}\u{646}", -1, 1],
        ["\u{633}\u{627}\u{632}\u{645}\u{627}\u{646}", -1, 1],
        ["\u{622}\u{633}\u{645}\u{627}\u{646}", -1, 1],
        ["\u{6CC}\u{648}\u{646}\u{627}\u{646}", -1, 1],
        ["\u{644}\u{628}\u{646}\u{627}\u{646}", -1, 1],
        ["\u{627}\u{635}\u{641}\u{647}\u{627}\u{646}", -1, 1],
        ["\u{67E}\u{627}\u{6CC}\u{627}\u{646}", -1, 1],
        ["\u{628}\u{6CC}\u{627}\u{646}", -1, 1],
        ["\u{62C}\u{631}\u{6CC}\u{627}\u{646}", -1, 1],
        ["\u{627}\u{645}\u{6A9}\u{627}\u{646}", -1, 1],
        ["\u{622}\u{630}\u{631}\u{628}\u{627}\u{6CC}\u{62C}\u{627}\u{646}", -1, 1],
        ["\u{647}\u{645}\u{62F}\u{627}\u{646}", -1, 1],
        ["\u{62E}\u{627}\u{646}\u{62F}\u{627}\u{646}", -1, 1],
        ["\u{632}\u{646}\u{62F}\u{627}\u{646}", -1, 1],
        ["\u{645}\u{6CC}\u{632}\u{627}\u{646}", -1, 1],
        ["\u{622}\u{62A}\u{634}\u{641}\u{634}\u{627}\u{646}", -1, 1],
        ["\u{646}\u{634}\u{627}\u{646}", -1, 1],
        ["\u{627}\u{6CC}\u{634}\u{627}\u{646}", -1, 1],
        ["\u{67E}\u{631}\u{6CC}\u{634}\u{627}\u{646}", -1, 1],
        ["\u{6A9}\u{647}\u{6A9}\u{634}\u{627}\u{646}", -1, 1],
        ["\u{62F}\u{631}\u{62E}\u{634}\u{627}\u{646}", -1, 1],
        ["\u{633}\u{644}\u{637}\u{627}\u{646}", -1, 1]
    ];

    private const array A_4 = [
        ["\u{627}\u{633}\u{627}\u{62A}\u{6CC}\u{62F}", -1, 2],
        ["\u{627}\u{62E}\u{628}\u{627}\u{631}", -1, 1]
    ];

    private const array AS_4 = ["\u{62E}\u{628}\u{631}", "\u{627}\u{633}\u{62A}\u{627}\u{62F}"];

    private const array A_5 = [
        ["\u{627}\u{645}", -1, 1],
        ["\u{6CC}\u{646}", -1, 1],
        ["\u{62A}\u{631}\u{6CC}\u{646}", 1, 1],
        ["\u{627}\u{646}", -1, 1],
        ["\u{6CC}\u{627}\u{646}", 3, 1],
        ["\u{628}\u{627}\u{646}", 3, 1],
        ["\u{6AF}\u{627}\u{646}", 3, 1],
        ["\u{627}\u{646}\u{647}", -1, 1],
        ["\u{6AF}\u{627}\u{647}", -1, 1],
        ["\u{627}\u{646}\u{6CC}", -1, 1],
        ["\u{6CC}\u{6CC}", -1, 1],
        ["\u{647}\u{627}\u{6CC}", -1, 1],
        ["\u{6AF}\u{6CC}", -1, 1],
        ["\u{647}\u{627}", -1, 1],
        ["\u{646}\u{627}\u{6A9}", -1, 1],
        ["\u{6CC}\u{62A}", -1, 1],
        ["\u{627}\u{62A}", -1, 1],
        ["\u{645}\u{646}\u{62F}", -1, 1],
        ["\u{648}\u{627}\u{631}", -1, 1],
        ["\u{6AF}\u{627}\u{631}", -1, 1],
        ["\u{62A}\u{631}", -1, 2],
        ["\u{627}\u{634}", -1, 1]
    ];

    private const array A_6 = [
        ["\u{6CC}\u{645}", -1, 1],
        ["\u{627}\u{6CC}\u{645}", 0, 1],
        ["\u{627}\u{6CC}", -1, 1],
        ["\u{627}\u{633}\u{62A}", -1, 1],
        ["\u{627}\u{646}\u{62F}", -1, 1],
        ["\u{6CC}\u{62F}", -1, 1],
        ["\u{627}\u{6CC}\u{62F}", 5, 1],
        ["\u{627}\u{633}", -1, 1]
    ];

    private const array A_7 = [
        ["\u{645}", -1, 1],
        ["\u{6CC}\u{645}", 0, 1],
        ["\u{631}\u{641}\u{62A}\u{6CC}\u{645}", 1, 2],
        ["\u{627}\u{645}", 0, 1],
        ["\u{631}\u{641}\u{62A}\u{645}", 0, 2],
        ["\u{627}\u{646}", -1, 3],
        ["\u{62A}\u{647}", -1, 5],
        ["\u{62F}\u{647}", -1, 4],
        ["\u{646}\u{62F}\u{647}", 7, 3],
        ["\u{631}\u{641}\u{62A}\u{6CC}", -1, 2],
        ["\u{62F}", -1, 1],
        ["\u{627}\u{646}\u{62F}", 10, 1],
        ["\u{631}\u{641}\u{62A}\u{627}\u{646}\u{62F}", 11, 2],
        ["\u{6CC}\u{62F}", 10, 1],
        ["\u{631}\u{641}\u{62A}\u{6CC}\u{62F}", 13, 2]
    ];



    public function stem(): bool
    {
        $B_saw_present_prefix = false;
        $v_1 = $this->cursor;
        while (true) {
            $v_2 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_0);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("\u{6A9}");
                    break;
                case 2:
                    $this->slice_from("\u{6CC}");
                    break;
                case 3:
                    $this->slice_from("\u{647}");
                    break;
                case 4:
                    $this->slice_from("\u{627}");
                    break;
                case 5:
                    $this->slice_from("\u{648}");
                    break;
                case 6:
                    $this->slice_del();
                    break;
                case 7:
                    if ($this->cursor >= $this->limit) {
                        goto lab1;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab1:
            $this->cursor = $v_2;
            break;
        }
    lab0:
        $this->cursor = $v_1;
        $v_3 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_1);
        if (0 === $among_var) {
            goto lab2;
        }
        $this->ket = $this->cursor;
        switch ($among_var) {
            case 1:
                if (!$this->hop(2)) {
                    goto lab2;
                }
                $B_saw_present_prefix = true;
                break;
            case 2:
                if (!$this->hop(2)) {
                    goto lab2;
                }
                $this->slice_del();
                $B_saw_present_prefix = true;
                break;
        }
    lab2:
        $this->cursor = $v_3;
        $v_4 = $this->cursor;
        while (true) {
            $v_5 = $this->cursor;
            while (true) {
                $v_6 = $this->cursor;
                $this->bra = $this->cursor;
                if (!($this->eq_s("\u{200C}"))) {
                    goto lab5;
                }
                $this->ket = $this->cursor;
                $this->slice_del();
                $this->cursor = $v_6;
                break;
            lab5:
                $this->cursor = $v_6;
                if ($this->cursor >= $this->limit) {
                    goto lab4;
                }
                $this->inc_cursor();
            }
            continue;
        lab4:
            $this->cursor = $v_5;
            break;
        }
    lab3:
        $this->cursor = $v_4;
        $I_p1 = $this->limit;
        $v_7 = $this->cursor;
        if (!$this->hop(3)) {
            goto lab6;
        }
        $I_p1 = $this->cursor;
    lab6:
        $this->cursor = $v_7;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        while (true) {
            $v_8 = $this->limit - $this->cursor;
            $v_9 = $this->limit - $this->cursor;
            $B_remove_verb_person_endings = false;
            if (!$B_saw_present_prefix) {
                goto lab8;
            }
            $B_remove_verb_person_endings = true;
        lab8:
            $v_10 = $this->limit - $this->cursor;
            if ($this->find_among_b(self::A_3) === 0) {
                goto lab9;
            }
            if ($this->cursor > $this->limit_backward) {
                goto lab9;
            }
            goto lab7;
        lab9:
            $this->cursor = $this->limit - $v_10;
            $v_11 = $this->limit - $this->cursor;
            if ($this->find_among_b(self::A_2) === 0) {
                goto lab10;
            }
            goto lab7;
        lab10:
            $this->cursor = $this->limit - $v_11;
            $v_12 = $this->limit - $this->cursor;
            $v_13 = $this->limit - $this->cursor;
            $this->ket = $this->cursor;
            $among_var = $this->find_among_b(self::A_4);
            if (0 === $among_var) {
                goto lab12;
            }
            $this->bra = $this->cursor;
            $this->slice_from(self::AS_4[$among_var - 1]);
            goto lab13;
        lab12:
            $this->cursor = $this->limit - $v_13;
            if ($this->cursor < $I_p1) {
                goto lab11;
            }
            $v_14 = $this->limit_backward;
            $this->limit_backward = $I_p1;
            $this->ket = $this->cursor;
            $among_var = $this->find_among_b(self::A_5);
            if (0 === $among_var) {
                $this->limit_backward = $v_14;
                goto lab11;
            }
            $this->bra = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_del();
                    break;
                case 2:
                    if ($this->cursor <= $this->limit_backward) {
                        $this->limit_backward = $v_14;
                        goto lab11;
                    }
                    $this->slice_del();
                    break;
            }
            $this->limit_backward = $v_14;
        lab13:
            goto lab14;
        lab11:
            $this->cursor = $this->limit - $v_12;
            $v_15 = $this->limit - $this->cursor;
            $this->ket = $this->cursor;
            if ($this->find_among_b(self::A_6) === 0) {
                goto lab15;
            }
            $this->bra = $this->cursor;
            if ($I_p1 > $this->cursor) {
                goto lab15;
            }
            $this->slice_del();
            goto lab16;
        lab15:
            $this->cursor = $this->limit - $v_15;
            $this->ket = $this->cursor;
            $among_var = $this->find_among_b(self::A_7);
            if (0 === $among_var) {
                goto lab7;
            }
            $this->bra = $this->cursor;
            switch ($among_var) {
                case 1:
                    if (!$B_remove_verb_person_endings) {
                        goto lab7;
                    }
                    if ($I_p1 > $this->cursor) {
                        goto lab7;
                    }
                    $this->slice_del();
                    break;
                case 2:
                    $this->slice_from("\u{631}\u{641}\u{62A}");
                    break;
                case 3:
                    if ($I_p1 > $this->cursor) {
                        goto lab7;
                    }
                    $this->slice_del();
                    $B_remove_verb_person_endings = true;
                    break;
                case 4:
                    if ($this->cursor <= $this->limit_backward) {
                        goto lab7;
                    }
                    $this->slice_from("\u{62F}");
                    $B_remove_verb_person_endings = true;
                    break;
                case 5:
                    if ($this->cursor <= $this->limit_backward) {
                        goto lab7;
                    }
                    $this->slice_from("\u{62A}");
                    $B_remove_verb_person_endings = true;
                    break;
            }
        lab16:
        lab14:
            $this->cursor = $this->limit - $v_9;
            continue;
        lab7:
            $this->cursor = $this->limit - $v_8;
            break;
        }
        $this->cursor = $this->limit_backward;
        return true;
    }
}
