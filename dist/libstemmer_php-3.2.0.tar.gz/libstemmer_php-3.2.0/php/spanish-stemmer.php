<?php
// Generated from spanish.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballSpanishStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["", -1, 6],
        ["\u{E1}", 0, 1],
        ["\u{E9}", 0, 2],
        ["\u{ED}", 0, 3],
        ["\u{F3}", 0, 4],
        ["\u{FA}", 0, 5]
    ];

    private const array A_1 = [
        ["la", -1, -1],
        ["sela", 0, -1],
        ["le", -1, -1],
        ["me", -1, -1],
        ["se", -1, -1],
        ["lo", -1, -1],
        ["selo", 5, -1],
        ["las", -1, -1],
        ["selas", 7, -1],
        ["les", -1, -1],
        ["los", -1, -1],
        ["selos", 10, -1],
        ["nos", -1, -1]
    ];

    private const array A_2 = [
        ["ando", -1, 6],
        ["iendo", -1, 6],
        ["yendo", -1, 7],
        ["\u{E1}ndo", -1, 2],
        ["i\u{E9}ndo", -1, 1],
        ["ar", -1, 6],
        ["er", -1, 6],
        ["ir", -1, 6],
        ["\u{E1}r", -1, 3],
        ["\u{E9}r", -1, 4],
        ["\u{ED}r", -1, 5]
    ];

    private const array A_3 = [
        ["ic", -1, -1],
        ["ad", -1, -1],
        ["os", -1, -1],
        ["iv", -1, 1]
    ];

    private const array A_4 = [
        ["able", -1, 1],
        ["ible", -1, 1],
        ["ante", -1, 1]
    ];

    private const array A_5 = [
        ["ic", -1, 1],
        ["abil", -1, 1],
        ["iv", -1, 1]
    ];

    private const array A_6 = [
        ["ica", -1, 1],
        ["ancia", -1, 2],
        ["encia", -1, 5],
        ["adora", -1, 2],
        ["osa", -1, 1],
        ["ista", -1, 1],
        ["iva", -1, 9],
        ["anza", -1, 1],
        ["log\u{ED}a", -1, 3],
        ["idad", -1, 8],
        ["able", -1, 1],
        ["ible", -1, 1],
        ["ante", -1, 2],
        ["mente", -1, 7],
        ["amente", 13, 6],
        ["acion", -1, 2],
        ["ucion", -1, 4],
        ["aci\u{F3}n", -1, 2],
        ["uci\u{F3}n", -1, 4],
        ["ico", -1, 1],
        ["ismo", -1, 1],
        ["oso", -1, 1],
        ["amiento", -1, 1],
        ["imiento", -1, 1],
        ["ivo", -1, 9],
        ["ador", -1, 2],
        ["icas", -1, 1],
        ["ancias", -1, 2],
        ["encias", -1, 5],
        ["adoras", -1, 2],
        ["osas", -1, 1],
        ["istas", -1, 1],
        ["ivas", -1, 9],
        ["anzas", -1, 1],
        ["log\u{ED}as", -1, 3],
        ["idades", -1, 8],
        ["ables", -1, 1],
        ["ibles", -1, 1],
        ["aciones", -1, 2],
        ["uciones", -1, 4],
        ["adores", -1, 2],
        ["antes", -1, 2],
        ["icos", -1, 1],
        ["ismos", -1, 1],
        ["osos", -1, 1],
        ["amientos", -1, 1],
        ["imientos", -1, 1],
        ["ivos", -1, 9]
    ];

    private const array A_7 = [
        ["ya", -1, 1],
        ["ye", -1, 1],
        ["yan", -1, 1],
        ["yen", -1, 1],
        ["yeron", -1, 1],
        ["yendo", -1, 1],
        ["yo", -1, 1],
        ["yas", -1, 1],
        ["yes", -1, 1],
        ["yais", -1, 1],
        ["yamos", -1, 1],
        ["y\u{F3}", -1, 1]
    ];

    private const array A_8 = [
        ["aba", -1, 2],
        ["ada", -1, 2],
        ["ida", -1, 2],
        ["ara", -1, 2],
        ["iera", -1, 2],
        ["\u{ED}a", -1, 2],
        ["ar\u{ED}a", 5, 2],
        ["er\u{ED}a", 5, 2],
        ["ir\u{ED}a", 5, 2],
        ["ad", -1, 2],
        ["ed", -1, 2],
        ["id", -1, 2],
        ["ase", -1, 2],
        ["iese", -1, 2],
        ["aste", -1, 2],
        ["iste", -1, 2],
        ["an", -1, 2],
        ["aban", 16, 2],
        ["aran", 16, 2],
        ["ieran", 16, 2],
        ["\u{ED}an", 16, 2],
        ["ar\u{ED}an", 20, 2],
        ["er\u{ED}an", 20, 2],
        ["ir\u{ED}an", 20, 2],
        ["en", -1, 1],
        ["asen", 24, 2],
        ["iesen", 24, 2],
        ["aron", -1, 2],
        ["ieron", -1, 2],
        ["ar\u{E1}n", -1, 2],
        ["er\u{E1}n", -1, 2],
        ["ir\u{E1}n", -1, 2],
        ["ado", -1, 2],
        ["ido", -1, 2],
        ["ando", -1, 2],
        ["iendo", -1, 2],
        ["ar", -1, 2],
        ["er", -1, 2],
        ["ir", -1, 2],
        ["as", -1, 2],
        ["abas", 39, 2],
        ["adas", 39, 2],
        ["idas", 39, 2],
        ["aras", 39, 2],
        ["ieras", 39, 2],
        ["\u{ED}as", 39, 2],
        ["ar\u{ED}as", 45, 2],
        ["er\u{ED}as", 45, 2],
        ["ir\u{ED}as", 45, 2],
        ["es", -1, 1],
        ["ases", 49, 2],
        ["ieses", 49, 2],
        ["abais", -1, 2],
        ["arais", -1, 2],
        ["ierais", -1, 2],
        ["\u{ED}ais", -1, 2],
        ["ar\u{ED}ais", 55, 2],
        ["er\u{ED}ais", 55, 2],
        ["ir\u{ED}ais", 55, 2],
        ["aseis", -1, 2],
        ["ieseis", -1, 2],
        ["asteis", -1, 2],
        ["isteis", -1, 2],
        ["\u{E1}is", -1, 2],
        ["\u{E9}is", -1, 1],
        ["ar\u{E9}is", 64, 2],
        ["er\u{E9}is", 64, 2],
        ["ir\u{E9}is", 64, 2],
        ["ados", -1, 2],
        ["idos", -1, 2],
        ["amos", -1, 2],
        ["\u{E1}bamos", 70, 2],
        ["\u{E1}ramos", 70, 2],
        ["i\u{E9}ramos", 70, 2],
        ["\u{ED}amos", 70, 2],
        ["ar\u{ED}amos", 74, 2],
        ["er\u{ED}amos", 74, 2],
        ["ir\u{ED}amos", 74, 2],
        ["emos", -1, 1],
        ["aremos", 78, 2],
        ["eremos", 78, 2],
        ["iremos", 78, 2],
        ["\u{E1}semos", 78, 2],
        ["i\u{E9}semos", 78, 2],
        ["imos", -1, 2],
        ["ar\u{E1}s", -1, 2],
        ["er\u{E1}s", -1, 2],
        ["ir\u{E1}s", -1, 2],
        ["\u{ED}s", -1, 2],
        ["ar\u{E1}", -1, 2],
        ["er\u{E1}", -1, 2],
        ["ir\u{E1}", -1, 2],
        ["ar\u{E9}", -1, 2],
        ["er\u{E9}", -1, 2],
        ["ir\u{E9}", -1, 2],
        ["i\u{F3}", -1, 2]
    ];

    private const array A_9 = [
        ["a", -1, 1],
        ["e", -1, 2],
        ["o", -1, 1],
        ["os", -1, 1],
        ["\u{E1}", -1, 1],
        ["\u{E9}", -1, 2],
        ["\u{ED}", -1, 1],
        ["\u{F3}", -1, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "\u{E1}"=>true, "\u{E9}"=>true, "\u{ED}"=>true, "\u{F3}"=>true, "\u{FA}"=>true, "\u{FC}"=>true];



    public function stem(): bool
    {
        $I_pV = $this->limit;
        $I_p1 = $this->limit;
        $I_p2 = $this->limit;
        $v_1 = $this->cursor;
        $v_2 = $this->cursor;
        if (!($this->in_grouping(self::G_v))) {
            goto lab2;
        }
        $v_3 = $this->cursor;
        if (!($this->out_grouping(self::G_v))) {
            goto lab3;
        }
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab3;
        }
        $this->inc_cursor();
        goto lab4;
    lab3:
        $this->cursor = $v_3;
        if (!($this->in_grouping(self::G_v))) {
            goto lab2;
        }
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab2;
        }
        $this->inc_cursor();
    lab4:
        goto lab5;
    lab2:
        $this->cursor = $v_2;
        if (!($this->out_grouping(self::G_v))) {
            goto lab1;
        }
        $v_4 = $this->cursor;
        if (!($this->out_grouping(self::G_v))) {
            goto lab6;
        }
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab6;
        }
        $this->inc_cursor();
        goto lab7;
    lab6:
        $this->cursor = $v_4;
        if (!($this->in_grouping(self::G_v))) {
            goto lab1;
        }
        if ($this->cursor >= $this->limit) {
            goto lab1;
        }
        $this->inc_cursor();
    lab7:
    lab5:
        $I_pV = $this->cursor;
    lab1:
        $this->cursor = $v_1;
        $v_5 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab8;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab8;
        }
        $this->inc_cursor();
        $I_p1 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab8;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab8;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab8:
        $this->cursor = $v_5;
    lab0:
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_6 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_1) === 0) {
            goto lab9;
        }
        $this->bra = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            goto lab9;
        }
        if ($I_pV > $this->cursor) {
            goto lab9;
        }
        switch ($among_var) {
            case 1:
                $this->bra = $this->cursor;
                $this->slice_from("iendo");
                break;
            case 2:
                $this->bra = $this->cursor;
                $this->slice_from("ando");
                break;
            case 3:
                $this->bra = $this->cursor;
                $this->slice_from("ar");
                break;
            case 4:
                $this->bra = $this->cursor;
                $this->slice_from("er");
                break;
            case 5:
                $this->bra = $this->cursor;
                $this->slice_from("ir");
                break;
            case 6:
                $this->slice_del();
                break;
            case 7:
                if (!($this->eq_s_b("u"))) {
                    goto lab9;
                }
                $this->slice_del();
                break;
        }
    lab9:
        $this->cursor = $this->limit - $v_6;
        $v_7 = $this->limit - $this->cursor;
        $v_8 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_6);
        if (0 === $among_var) {
            goto lab11;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p2 > $this->cursor) {
                    goto lab11;
                }
                $this->slice_del();
                break;
            case 2:
                if ($I_p2 > $this->cursor) {
                    goto lab11;
                }
                $this->slice_del();
                $v_9 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("ic"))) {
                    $this->cursor = $this->limit - $v_9;
                    goto lab12;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_9;
                    goto lab12;
                }
                $this->slice_del();
            lab12:
                break;
            case 3:
                if ($I_p2 > $this->cursor) {
                    goto lab11;
                }
                $this->slice_from("log");
                break;
            case 4:
                if ($I_p2 > $this->cursor) {
                    goto lab11;
                }
                $this->slice_from("u");
                break;
            case 5:
                if ($I_p2 > $this->cursor) {
                    goto lab11;
                }
                $this->slice_from("ente");
                break;
            case 6:
                if ($I_p1 > $this->cursor) {
                    goto lab11;
                }
                $this->slice_del();
                $v_10 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                $among_var = $this->find_among_b(self::A_3);
                if (0 === $among_var) {
                    $this->cursor = $this->limit - $v_10;
                    goto lab13;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_10;
                    goto lab13;
                }
                $this->slice_del();
                switch ($among_var) {
                    case 1:
                        $this->ket = $this->cursor;
                        if (!($this->eq_s_b("at"))) {
                            $this->cursor = $this->limit - $v_10;
                            goto lab13;
                        }
                        $this->bra = $this->cursor;
                        if ($I_p2 > $this->cursor) {
                            $this->cursor = $this->limit - $v_10;
                            goto lab13;
                        }
                        $this->slice_del();
                        break;
                }
            lab13:
                break;
            case 7:
                if ($I_p2 > $this->cursor) {
                    goto lab11;
                }
                $this->slice_del();
                $v_11 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if ($this->find_among_b(self::A_4) === 0) {
                    $this->cursor = $this->limit - $v_11;
                    goto lab14;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_11;
                    goto lab14;
                }
                $this->slice_del();
            lab14:
                break;
            case 8:
                if ($I_p2 > $this->cursor) {
                    goto lab11;
                }
                $this->slice_del();
                $v_12 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if ($this->find_among_b(self::A_5) === 0) {
                    $this->cursor = $this->limit - $v_12;
                    goto lab15;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_12;
                    goto lab15;
                }
                $this->slice_del();
            lab15:
                break;
            case 9:
                if ($I_p2 > $this->cursor) {
                    goto lab11;
                }
                $this->slice_del();
                $v_13 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("at"))) {
                    $this->cursor = $this->limit - $v_13;
                    goto lab16;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_13;
                    goto lab16;
                }
                $this->slice_del();
            lab16:
                break;
        }
        goto lab17;
    lab11:
        $this->cursor = $this->limit - $v_8;
        if ($this->cursor < $I_pV) {
            goto lab18;
        }
        $v_14 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_7) === 0) {
            $this->limit_backward = $v_14;
            goto lab18;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_14;
        if (!($this->eq_s_b("u"))) {
            goto lab18;
        }
        $this->slice_del();
        goto lab17;
    lab18:
        $this->cursor = $this->limit - $v_8;
        if ($this->cursor < $I_pV) {
            goto lab10;
        }
        $v_15 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_8);
        if (0 === $among_var) {
            $this->limit_backward = $v_15;
            goto lab10;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_15;
        switch ($among_var) {
            case 1:
                $v_16 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("u"))) {
                    $this->cursor = $this->limit - $v_16;
                    goto lab19;
                }
                $v_17 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("g"))) {
                    $this->cursor = $this->limit - $v_16;
                    goto lab19;
                }
                $this->cursor = $this->limit - $v_17;
            lab19:
                $this->bra = $this->cursor;
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                break;
        }
    lab17:
    lab10:
        $this->cursor = $this->limit - $v_7;
        $v_18 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_9);
        if (0 === $among_var) {
            goto lab20;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_pV > $this->cursor) {
                    goto lab20;
                }
                $this->slice_del();
                break;
            case 2:
                if ($I_pV > $this->cursor) {
                    goto lab20;
                }
                $this->slice_del();
                $v_19 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("u"))) {
                    $this->cursor = $this->limit - $v_19;
                    goto lab21;
                }
                $this->bra = $this->cursor;
                $v_20 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("g"))) {
                    $this->cursor = $this->limit - $v_19;
                    goto lab21;
                }
                $this->cursor = $this->limit - $v_20;
                if ($I_pV > $this->cursor) {
                    $this->cursor = $this->limit - $v_19;
                    goto lab21;
                }
                $this->slice_del();
            lab21:
                break;
        }
    lab20:
        $this->cursor = $this->limit - $v_18;
        $this->cursor = $this->limit_backward;
        $v_21 = $this->cursor;
        while (true) {
            $v_22 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_0);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("a");
                    break;
                case 2:
                    $this->slice_from("e");
                    break;
                case 3:
                    $this->slice_from("i");
                    break;
                case 4:
                    $this->slice_from("o");
                    break;
                case 5:
                    $this->slice_from("u");
                    break;
                case 6:
                    if ($this->cursor >= $this->limit) {
                        goto lab23;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab23:
            $this->cursor = $v_22;
            break;
        }
    lab22:
        $this->cursor = $v_21;
        return true;
    }
}
