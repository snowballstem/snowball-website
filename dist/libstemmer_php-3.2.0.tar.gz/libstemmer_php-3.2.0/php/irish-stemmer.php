<?php
// Generated from irish.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballIrishStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["b'", -1, 1],
        ["bh", -1, 4],
        ["bhf", 1, 2],
        ["bp", -1, 8],
        ["ch", -1, 5],
        ["d'", -1, 1],
        ["d'fh", 5, 2],
        ["dh", -1, 6],
        ["dt", -1, 9],
        ["fh", -1, 2],
        ["gc", -1, 5],
        ["gh", -1, 7],
        ["h-", -1, 1],
        ["m'", -1, 1],
        ["mb", -1, 4],
        ["mh", -1, 10],
        ["n-", -1, 1],
        ["nd", -1, 6],
        ["ng", -1, 7],
        ["ph", -1, 8],
        ["sh", -1, 3],
        ["t-", -1, 1],
        ["th", -1, 9],
        ["ts", -1, 3]
    ];

    private const array AS_0 = ["", "f", "s", "b", "c", "d", "g", "p", "t", "m"];

    private const array A_1 = [
        ["\u{ED}ochta", -1, 1],
        ["a\u{ED}ochta", 0, 1],
        ["ire", -1, 2],
        ["aire", 2, 2],
        ["abh", -1, 1],
        ["eabh", 4, 1],
        ["ibh", -1, 1],
        ["aibh", 6, 1],
        ["amh", -1, 1],
        ["eamh", 8, 1],
        ["imh", -1, 1],
        ["aimh", 10, 1],
        ["\u{ED}ocht", -1, 1],
        ["a\u{ED}ocht", 12, 1],
        ["ir\u{ED}", -1, 2],
        ["air\u{ED}", 14, 2]
    ];

    private const array A_2 = [
        ["\u{F3}ideacha", -1, 6],
        ["patacha", -1, 5],
        ["achta", -1, 1],
        ["arcachta", 2, 2],
        ["eachta", 2, 1],
        ["grafa\u{ED}ochta", -1, 4],
        ["paite", -1, 5],
        ["ach", -1, 1],
        ["each", 7, 1],
        ["\u{F3}ideach", 8, 6],
        ["gineach", 8, 3],
        ["patach", 7, 5],
        ["grafa\u{ED}och", -1, 4],
        ["pataigh", -1, 5],
        ["\u{F3}idigh", -1, 6],
        ["acht\u{FA}il", -1, 1],
        ["eacht\u{FA}il", 15, 1],
        ["gineas", -1, 3],
        ["ginis", -1, 3],
        ["acht", -1, 1],
        ["arcacht", 19, 2],
        ["eacht", 19, 1],
        ["grafa\u{ED}ocht", -1, 4],
        ["arcachta\u{ED}", -1, 2],
        ["grafa\u{ED}ochta\u{ED}", -1, 4]
    ];

    private const array A_3 = [
        ["imid", -1, 1],
        ["aimid", 0, 1],
        ["\u{ED}mid", -1, 1],
        ["a\u{ED}mid", 2, 1],
        ["adh", -1, 2],
        ["eadh", 4, 2],
        ["faidh", -1, 1],
        ["fidh", -1, 1],
        ["\u{E1}il", -1, 2],
        ["ain", -1, 2],
        ["tear", -1, 2],
        ["tar", -1, 2]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "\u{E1}"=>true, "\u{E9}"=>true, "\u{ED}"=>true, "\u{F3}"=>true, "\u{FA}"=>true];



    public function stem(): bool
    {
        $v_1 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_0);
        if (0 === $among_var) {
            goto lab0;
        }
        $this->ket = $this->cursor;
        $this->slice_from(self::AS_0[$among_var - 1]);
    lab0:
        $this->cursor = $v_1;
        $I_pV = $this->limit;
        $I_p1 = $this->limit;
        $I_p2 = $this->limit;
        $v_2 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab2;
        }
        $this->inc_cursor();
        $I_pV = $this->cursor;
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab2;
        }
        $this->inc_cursor();
        $I_p1 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab2;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab2;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab2:
        $this->cursor = $v_2;
    lab1:
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_3 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_1);
        if (0 === $among_var) {
            goto lab3;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p1 > $this->cursor) {
                    goto lab3;
                }
                $this->slice_del();
                break;
            case 2:
                if ($I_p2 > $this->cursor) {
                    goto lab3;
                }
                $this->slice_del();
                break;
        }
    lab3:
        $this->cursor = $this->limit - $v_3;
        $v_4 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            goto lab4;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p2 > $this->cursor) {
                    goto lab4;
                }
                $this->slice_del();
                break;
            case 2:
                $this->slice_from("arc");
                break;
            case 3:
                $this->slice_from("gin");
                break;
            case 4:
                $this->slice_from("graf");
                break;
            case 5:
                $this->slice_from("paite");
                break;
            case 6:
                $this->slice_from("\u{F3}id");
                break;
        }
    lab4:
        $this->cursor = $this->limit - $v_4;
        $v_5 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_3);
        if (0 === $among_var) {
            goto lab5;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_pV > $this->cursor) {
                    goto lab5;
                }
                $this->slice_del();
                break;
            case 2:
                if ($I_p1 > $this->cursor) {
                    goto lab5;
                }
                $this->slice_del();
                break;
        }
    lab5:
        $this->cursor = $this->limit - $v_5;
        $this->cursor = $this->limit_backward;
        return true;
    }
}
