<?php
// Generated from russian.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballRussianStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["\u{432}\u{448}\u{438}\u{441}\u{44C}", -1, 1],
        ["\u{44B}\u{432}\u{448}\u{438}\u{441}\u{44C}", 0, 2],
        ["\u{438}\u{432}\u{448}\u{438}\u{441}\u{44C}", 0, 2],
        ["\u{432}", -1, 1],
        ["\u{44B}\u{432}", 3, 2],
        ["\u{438}\u{432}", 3, 2],
        ["\u{432}\u{448}\u{438}", -1, 1],
        ["\u{44B}\u{432}\u{448}\u{438}", 6, 2],
        ["\u{438}\u{432}\u{448}\u{438}", 6, 2]
    ];

    private const array A_1 = [
        ["\u{435}\u{43C}\u{443}", -1, 1],
        ["\u{43E}\u{43C}\u{443}", -1, 1],
        ["\u{44B}\u{445}", -1, 1],
        ["\u{438}\u{445}", -1, 1],
        ["\u{443}\u{44E}", -1, 1],
        ["\u{44E}\u{44E}", -1, 1],
        ["\u{435}\u{44E}", -1, 1],
        ["\u{43E}\u{44E}", -1, 1],
        ["\u{44F}\u{44F}", -1, 1],
        ["\u{430}\u{44F}", -1, 1],
        ["\u{44B}\u{435}", -1, 1],
        ["\u{435}\u{435}", -1, 1],
        ["\u{438}\u{435}", -1, 1],
        ["\u{43E}\u{435}", -1, 1],
        ["\u{44B}\u{43C}\u{438}", -1, 1],
        ["\u{438}\u{43C}\u{438}", -1, 1],
        ["\u{44B}\u{439}", -1, 1],
        ["\u{435}\u{439}", -1, 1],
        ["\u{438}\u{439}", -1, 1],
        ["\u{43E}\u{439}", -1, 1],
        ["\u{44B}\u{43C}", -1, 1],
        ["\u{435}\u{43C}", -1, 1],
        ["\u{438}\u{43C}", -1, 1],
        ["\u{43E}\u{43C}", -1, 1],
        ["\u{435}\u{433}\u{43E}", -1, 1],
        ["\u{43E}\u{433}\u{43E}", -1, 1]
    ];

    private const array A_2 = [
        ["\u{432}\u{448}", -1, 1],
        ["\u{44B}\u{432}\u{448}", 0, 2],
        ["\u{438}\u{432}\u{448}", 0, 2],
        ["\u{449}", -1, 1],
        ["\u{44E}\u{449}", 3, 1],
        ["\u{443}\u{44E}\u{449}", 4, 2],
        ["\u{435}\u{43C}", -1, 1],
        ["\u{43D}\u{43D}", -1, 1]
    ];

    private const array A_3 = [
        ["\u{441}\u{44C}", -1, 1],
        ["\u{441}\u{44F}", -1, 1]
    ];

    private const array A_4 = [
        ["\u{44B}\u{442}", -1, 2],
        ["\u{44E}\u{442}", -1, 1],
        ["\u{443}\u{44E}\u{442}", 1, 2],
        ["\u{44F}\u{442}", -1, 2],
        ["\u{435}\u{442}", -1, 1],
        ["\u{443}\u{435}\u{442}", 4, 2],
        ["\u{438}\u{442}", -1, 2],
        ["\u{43D}\u{44B}", -1, 1],
        ["\u{435}\u{43D}\u{44B}", 7, 2],
        ["\u{442}\u{44C}", -1, 1],
        ["\u{44B}\u{442}\u{44C}", 9, 2],
        ["\u{438}\u{442}\u{44C}", 9, 2],
        ["\u{435}\u{448}\u{44C}", -1, 1],
        ["\u{438}\u{448}\u{44C}", -1, 2],
        ["\u{44E}", -1, 2],
        ["\u{443}\u{44E}", 14, 2],
        ["\u{43B}\u{430}", -1, 1],
        ["\u{44B}\u{43B}\u{430}", 16, 2],
        ["\u{438}\u{43B}\u{430}", 16, 2],
        ["\u{43D}\u{430}", -1, 1],
        ["\u{435}\u{43D}\u{430}", 19, 2],
        ["\u{435}\u{442}\u{435}", -1, 1],
        ["\u{438}\u{442}\u{435}", -1, 2],
        ["\u{439}\u{442}\u{435}", -1, 1],
        ["\u{443}\u{439}\u{442}\u{435}", 23, 2],
        ["\u{435}\u{439}\u{442}\u{435}", 23, 2],
        ["\u{43B}\u{438}", -1, 1],
        ["\u{44B}\u{43B}\u{438}", 26, 2],
        ["\u{438}\u{43B}\u{438}", 26, 2],
        ["\u{439}", -1, 1],
        ["\u{443}\u{439}", 29, 2],
        ["\u{435}\u{439}", 29, 2],
        ["\u{43B}", -1, 1],
        ["\u{44B}\u{43B}", 32, 2],
        ["\u{438}\u{43B}", 32, 2],
        ["\u{44B}\u{43C}", -1, 2],
        ["\u{435}\u{43C}", -1, 1],
        ["\u{438}\u{43C}", -1, 2],
        ["\u{43D}", -1, 1],
        ["\u{435}\u{43D}", 38, 2],
        ["\u{43B}\u{43E}", -1, 1],
        ["\u{44B}\u{43B}\u{43E}", 40, 2],
        ["\u{438}\u{43B}\u{43E}", 40, 2],
        ["\u{43D}\u{43E}", -1, 1],
        ["\u{435}\u{43D}\u{43E}", 43, 2],
        ["\u{43D}\u{43D}\u{43E}", 43, 1]
    ];

    private const array A_5 = [
        ["\u{443}", -1, 1],
        ["\u{44F}\u{445}", -1, 1],
        ["\u{438}\u{44F}\u{445}", 1, 1],
        ["\u{430}\u{445}", -1, 1],
        ["\u{44B}", -1, 1],
        ["\u{44C}", -1, 1],
        ["\u{44E}", -1, 1],
        ["\u{44C}\u{44E}", 6, 1],
        ["\u{438}\u{44E}", 6, 1],
        ["\u{44F}", -1, 1],
        ["\u{44C}\u{44F}", 9, 1],
        ["\u{438}\u{44F}", 9, 1],
        ["\u{430}", -1, 1],
        ["\u{435}\u{432}", -1, 1],
        ["\u{43E}\u{432}", -1, 1],
        ["\u{435}", -1, 1],
        ["\u{44C}\u{435}", 15, 1],
        ["\u{438}\u{435}", 15, 1],
        ["\u{438}", -1, 1],
        ["\u{435}\u{438}", 18, 1],
        ["\u{438}\u{438}", 18, 1],
        ["\u{44F}\u{43C}\u{438}", 18, 1],
        ["\u{438}\u{44F}\u{43C}\u{438}", 21, 1],
        ["\u{430}\u{43C}\u{438}", 18, 1],
        ["\u{439}", -1, 1],
        ["\u{435}\u{439}", 24, 1],
        ["\u{438}\u{435}\u{439}", 25, 1],
        ["\u{438}\u{439}", 24, 1],
        ["\u{43E}\u{439}", 24, 1],
        ["\u{44F}\u{43C}", -1, 1],
        ["\u{438}\u{44F}\u{43C}", 29, 1],
        ["\u{430}\u{43C}", -1, 1],
        ["\u{435}\u{43C}", -1, 1],
        ["\u{438}\u{435}\u{43C}", 32, 1],
        ["\u{43E}\u{43C}", -1, 1],
        ["\u{43E}", -1, 1]
    ];

    private const array A_6 = [
        ["\u{43E}\u{441}\u{442}", -1, 1],
        ["\u{43E}\u{441}\u{442}\u{44C}", -1, 1]
    ];

    private const array A_7 = [
        ["\u{435}\u{439}\u{448}", -1, 1],
        ["\u{44C}", -1, 3],
        ["\u{435}\u{439}\u{448}\u{435}", -1, 1],
        ["\u{43D}", -1, 2]
    ];

    private const array G_v = ["\u{430}"=>true, "\u{435}"=>true, "\u{438}"=>true, "\u{43E}"=>true, "\u{443}"=>true, "\u{44B}"=>true, "\u{44D}"=>true, "\u{44E}"=>true, "\u{44F}"=>true];



    public function stem(): bool
    {
        $v_1 = $this->cursor;
        while (true) {
            $v_2 = $this->cursor;
            while (true) {
                $v_3 = $this->cursor;
                $this->bra = $this->cursor;
                if (!($this->eq_s("\u{451}"))) {
                    goto lab2;
                }
                $this->ket = $this->cursor;
                $this->cursor = $v_3;
                break;
            lab2:
                $this->cursor = $v_3;
                if ($this->cursor >= $this->limit) {
                    goto lab1;
                }
                $this->inc_cursor();
            }
            $this->slice_from("\u{435}");
            continue;
        lab1:
            $this->cursor = $v_2;
            break;
        }
    lab0:
        $this->cursor = $v_1;
        $I_pV = $this->limit;
        $I_p2 = $this->limit;
        $v_4 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab4;
        }
        $this->inc_cursor();
        $I_pV = $this->cursor;
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab4;
        }
        $this->inc_cursor();
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab4;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab4;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab4:
        $this->cursor = $v_4;
    lab3:
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        if ($this->cursor < $I_pV) {
            return false;
        }
        $v_5 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $v_6 = $this->limit - $this->cursor;
        $v_7 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_0);
        if (0 === $among_var) {
            goto lab6;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if (!($this->eq_s_b("\u{430}"))) {
                    goto lab7;
                }
                goto lab8;
            lab7:
                if (!($this->eq_s_b("\u{44F}"))) {
                    goto lab6;
                }
            lab8:
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                break;
        }
        goto lab9;
    lab6:
        $this->cursor = $this->limit - $v_7;
        $v_8 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_3) === 0) {
            $this->cursor = $this->limit - $v_8;
            goto lab10;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
    lab10:
        $v_9 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_1) === 0) {
            goto lab11;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $v_10 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            $this->cursor = $this->limit - $v_10;
            goto lab12;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if (!($this->eq_s_b("\u{430}"))) {
                    goto lab13;
                }
                goto lab14;
            lab13:
                if (!($this->eq_s_b("\u{44F}"))) {
                    $this->cursor = $this->limit - $v_10;
                    goto lab12;
                }
            lab14:
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                break;
        }
    lab12:
        goto lab15;
    lab11:
        $this->cursor = $this->limit - $v_9;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab16;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if (!($this->eq_s_b("\u{430}"))) {
                    goto lab17;
                }
                goto lab18;
            lab17:
                if (!($this->eq_s_b("\u{44F}"))) {
                    goto lab16;
                }
            lab18:
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                break;
        }
        goto lab15;
    lab16:
        $this->cursor = $this->limit - $v_9;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_5) === 0) {
            goto lab5;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
    lab15:
    lab9:
    lab5:
        $this->cursor = $this->limit - $v_6;
        $v_11 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{438}"))) {
            $this->cursor = $this->limit - $v_11;
            goto lab19;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
    lab19:
        $v_12 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_6) === 0) {
            goto lab20;
        }
        $this->bra = $this->cursor;
        if ($I_p2 > $this->cursor) {
            goto lab20;
        }
        $this->slice_del();
    lab20:
        $this->cursor = $this->limit - $v_12;
        $v_13 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_7);
        if (0 === $among_var) {
            goto lab21;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("\u{43D}"))) {
                    goto lab21;
                }
                $this->bra = $this->cursor;
                if (!($this->eq_s_b("\u{43D}"))) {
                    goto lab21;
                }
                $this->slice_del();
                break;
            case 2:
                if (!($this->eq_s_b("\u{43D}"))) {
                    goto lab21;
                }
                $this->slice_del();
                break;
            case 3:
                $this->slice_del();
                break;
        }
    lab21:
        $this->cursor = $this->limit - $v_13;
        $this->limit_backward = $v_5;
        $this->cursor = $this->limit_backward;
        return true;
    }
}
