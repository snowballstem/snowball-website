<?php
// Generated from dutch_porter.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballDutchPorterStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["", -1, 6],
        ["\u{E1}", 0, 1],
        ["\u{E4}", 0, 1],
        ["\u{E9}", 0, 2],
        ["\u{EB}", 0, 2],
        ["\u{ED}", 0, 3],
        ["\u{EF}", 0, 3],
        ["\u{F3}", 0, 4],
        ["\u{F6}", 0, 4],
        ["\u{FA}", 0, 5],
        ["\u{FC}", 0, 5]
    ];

    private const array A_1 = [
        ["", -1, 3],
        ["I", 0, 2],
        ["Y", 0, 1]
    ];

    private const array A_2 = [
        ["dd", -1, -1],
        ["kk", -1, -1],
        ["tt", -1, -1]
    ];

    private const array A_3 = [
        ["ene", -1, 2],
        ["se", -1, 3],
        ["en", -1, 2],
        ["heden", 2, 1],
        ["s", -1, 3]
    ];

    private const array A_4 = [
        ["end", -1, 1],
        ["ig", -1, 2],
        ["ing", -1, 1],
        ["lijk", -1, 3],
        ["baar", -1, 4],
        ["bar", -1, 5]
    ];

    private const array A_5 = [
        ["aa", -1, -1],
        ["ee", -1, -1],
        ["oo", -1, -1],
        ["uu", -1, -1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{E8}"=>true];

    private const array G_v_I = ["I"=>true, "a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{E8}"=>true];

    private const array G_v_j = ["a"=>true, "e"=>true, "i"=>true, "j"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{E8}"=>true];

    private int $I_p1 = 0;
    private bool $B_e_found = false;



    protected function r_undouble(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_2) === 0) {
            return false;
        }
        $this->cursor = $this->limit - $v_1;
        $this->ket = $this->cursor;
        if ($this->cursor <= $this->limit_backward) {
            return false;
        }
        $this->dec_cursor();
        $this->bra = $this->cursor;
        $this->slice_del();
        return true;
    }


    protected function r_e_ending(): bool
    {
        $this->B_e_found = false;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("e"))) {
            return false;
        }
        $this->bra = $this->cursor;
        if ($this->I_p1 > $this->cursor) {
            return false;
        }
        $v_1 = $this->limit - $this->cursor;
        if (!($this->out_grouping_b(self::G_v))) {
            return false;
        }
        $this->cursor = $this->limit - $v_1;
        $this->slice_del();
        $this->B_e_found = true;
        return $this->r_undouble();
    }


    protected function r_en_ending(): bool
    {
        if ($this->I_p1 > $this->cursor) {
            return false;
        }
        $v_1 = $this->limit - $this->cursor;
        if (!($this->out_grouping_b(self::G_v))) {
            return false;
        }
        $this->cursor = $this->limit - $v_1;
        if (!($this->eq_s_b("gem"))) {
            goto lab0;
        }
        return false;
    lab0:
        $this->slice_del();
        return $this->r_undouble();
    }


    public function stem(): bool
    {
        $v_1 = $this->cursor;
        $v_2 = $this->cursor;
        while (true) {
            $v_3 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_0);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("a");
                    break;
                case 2:
                    $this->slice_from("e");
                    break;
                case 3:
                    $this->slice_from("i");
                    break;
                case 4:
                    $this->slice_from("o");
                    break;
                case 5:
                    $this->slice_from("u");
                    break;
                case 6:
                    if ($this->cursor >= $this->limit) {
                        goto lab1;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab1:
            $this->cursor = $v_3;
            break;
        }
        $this->cursor = $v_2;
        $v_4 = $this->cursor;
        $this->bra = $this->cursor;
        if (!($this->eq_s("y"))) {
            $this->cursor = $v_4;
            goto lab2;
        }
        $this->ket = $this->cursor;
        $this->slice_from("Y");
    lab2:
        while (true) {
            $v_5 = $this->cursor;
            if (!$this->go_out_grouping(self::G_v)) {
                goto lab3;
            }
            $this->inc_cursor();
            $v_6 = $this->cursor;
            $this->bra = $this->cursor;
            $v_7 = $this->cursor;
            if (!($this->eq_s("i"))) {
                goto lab5;
            }
            $this->ket = $this->cursor;
            $v_8 = $this->cursor;
            if (!($this->in_grouping(self::G_v))) {
                goto lab6;
            }
            $this->slice_from("I");
        lab6:
            $this->cursor = $v_8;
            goto lab7;
        lab5:
            $this->cursor = $v_7;
            if (!($this->eq_s("y"))) {
                $this->cursor = $v_6;
                goto lab4;
            }
            $this->ket = $this->cursor;
            $this->slice_from("Y");
        lab7:
        lab4:
            continue;
        lab3:
            $this->cursor = $v_5;
            break;
        }
    lab0:
        $this->cursor = $v_1;
        $v_9 = $this->cursor;
        $this->I_p1 = $this->limit;
        $I_p2 = $this->limit;
        $v_10 = $this->cursor;
        if (!$this->hop(3)) {
            goto lab8;
        }
        $I_x = $this->cursor;
        $this->cursor = $v_10;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab8;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab8;
        }
        $this->inc_cursor();
        $this->I_p1 = $this->cursor;
        if ($this->I_p1 >= $I_x) {
            goto lab9;
        }
        $this->I_p1 = $I_x;
    lab9:
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab8;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab8;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab8:
        $this->cursor = $v_9;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_11 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_3);
        if (0 === $among_var) {
            goto lab11;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($this->I_p1 > $this->cursor) {
                    goto lab11;
                }
                $this->slice_from("heid");
                break;
            case 2:
                if (!$this->r_en_ending()) {
                    goto lab11;
                }
                break;
            case 3:
                if ($this->I_p1 > $this->cursor) {
                    goto lab11;
                }
                if (!($this->out_grouping_b(self::G_v_j))) {
                    goto lab11;
                }
                $this->slice_del();
                break;
        }
    lab11:
        $this->cursor = $this->limit - $v_11;
        $v_12 = $this->limit - $this->cursor;
        $this->r_e_ending();
        $this->cursor = $this->limit - $v_12;
        $v_13 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("heid"))) {
            goto lab12;
        }
        $this->bra = $this->cursor;
        if ($I_p2 > $this->cursor) {
            goto lab12;
        }
        if (!($this->eq_s_b("c"))) {
            goto lab13;
        }
        goto lab12;
    lab13:
        $this->slice_del();
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("en"))) {
            goto lab12;
        }
        $this->bra = $this->cursor;
        if (!$this->r_en_ending()) {
            goto lab12;
        }
    lab12:
        $this->cursor = $this->limit - $v_13;
        $v_14 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab14;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p2 > $this->cursor) {
                    goto lab14;
                }
                $this->slice_del();
                $v_15 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("ig"))) {
                    goto lab15;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    goto lab15;
                }
                if (!($this->eq_s_b("e"))) {
                    goto lab16;
                }
                goto lab15;
            lab16:
                $this->slice_del();
                goto lab17;
            lab15:
                $this->cursor = $this->limit - $v_15;
                if (!$this->r_undouble()) {
                    goto lab14;
                }
            lab17:
                break;
            case 2:
                if ($I_p2 > $this->cursor) {
                    goto lab14;
                }
                if (!($this->eq_s_b("e"))) {
                    goto lab18;
                }
                goto lab14;
            lab18:
                $this->slice_del();
                break;
            case 3:
                if ($I_p2 > $this->cursor) {
                    goto lab14;
                }
                $this->slice_del();
                if (!$this->r_e_ending()) {
                    goto lab14;
                }
                break;
            case 4:
                if ($I_p2 > $this->cursor) {
                    goto lab14;
                }
                $this->slice_del();
                break;
            case 5:
                if ($I_p2 > $this->cursor) {
                    goto lab14;
                }
                if (!$this->B_e_found) {
                    goto lab14;
                }
                $this->slice_del();
                break;
        }
    lab14:
        $this->cursor = $this->limit - $v_14;
        $v_16 = $this->limit - $this->cursor;
        if (!($this->out_grouping_b(self::G_v_I))) {
            goto lab19;
        }
        $v_17 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_5) === 0) {
            goto lab19;
        }
        if (!($this->out_grouping_b(self::G_v))) {
            goto lab19;
        }
        $this->cursor = $this->limit - $v_17;
        $this->ket = $this->cursor;
        if ($this->cursor <= $this->limit_backward) {
            goto lab19;
        }
        $this->dec_cursor();
        $this->bra = $this->cursor;
        $this->slice_del();
    lab19:
        $this->cursor = $this->limit - $v_16;
    lab10:
        $this->cursor = $this->limit_backward;
        $v_18 = $this->cursor;
        while (true) {
            $v_19 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_1);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("y");
                    break;
                case 2:
                    $this->slice_from("i");
                    break;
                case 3:
                    if ($this->cursor >= $this->limit) {
                        goto lab21;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab21:
            $this->cursor = $v_19;
            break;
        }
    lab20:
        $this->cursor = $v_18;
        return true;
    }
}
