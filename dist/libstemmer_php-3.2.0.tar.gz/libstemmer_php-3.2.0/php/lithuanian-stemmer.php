<?php
// Generated from lithuanian.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballLithuanianStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["a", -1, -1],
        ["ia", 0, -1],
        ["osna", 0, -1],
        ["iosna", 2, -1],
        ["uosna", 2, -1],
        ["iuosna", 4, -1],
        ["ysna", 0, -1],
        ["\u{117}sna", 0, -1],
        ["e", -1, -1],
        ["ie", 8, -1],
        ["enie", 9, -1],
        ["oje", 8, -1],
        ["ioje", 11, -1],
        ["uje", 8, -1],
        ["iuje", 13, -1],
        ["yje", 8, -1],
        ["enyje", 15, -1],
        ["\u{117}je", 8, -1],
        ["ame", 8, -1],
        ["iame", 18, -1],
        ["sime", 8, -1],
        ["ome", 8, -1],
        ["\u{117}me", 8, -1],
        ["tum\u{117}me", 22, -1],
        ["ose", 8, -1],
        ["iose", 24, -1],
        ["uose", 24, -1],
        ["iuose", 26, -1],
        ["yse", 8, -1],
        ["enyse", 28, -1],
        ["\u{117}se", 8, -1],
        ["ate", 8, -1],
        ["iate", 31, -1],
        ["ite", 8, -1],
        ["kite", 33, -1],
        ["site", 33, -1],
        ["ote", 8, -1],
        ["tute", 8, -1],
        ["\u{117}te", 8, -1],
        ["tum\u{117}te", 38, -1],
        ["i", -1, -1],
        ["ai", 40, -1],
        ["iai", 41, -1],
        ["ei", 40, -1],
        ["tumei", 43, -1],
        ["ki", 40, -1],
        ["imi", 40, -1],
        ["umi", 40, -1],
        ["iumi", 47, -1],
        ["si", 40, -1],
        ["asi", 49, -1],
        ["iasi", 50, -1],
        ["esi", 49, -1],
        ["iesi", 52, -1],
        ["siesi", 53, -1],
        ["isi", 49, -1],
        ["aisi", 55, -1],
        ["eisi", 55, -1],
        ["tumeisi", 57, -1],
        ["uisi", 55, -1],
        ["osi", 49, -1],
        ["\u{117}josi", 60, -1],
        ["uosi", 60, -1],
        ["iuosi", 62, -1],
        ["siuosi", 63, -1],
        ["usi", 49, -1],
        ["ausi", 65, -1],
        ["\u{10D}iausi", 66, -1],
        ["\u{105}si", 49, -1],
        ["\u{117}si", 49, -1],
        ["\u{173}si", 49, -1],
        ["t\u{173}si", 70, -1],
        ["ti", 40, -1],
        ["enti", 72, -1],
        ["inti", 72, -1],
        ["oti", 72, -1],
        ["ioti", 75, -1],
        ["uoti", 75, -1],
        ["iuoti", 77, -1],
        ["auti", 72, -1],
        ["iauti", 79, -1],
        ["yti", 72, -1],
        ["\u{117}ti", 72, -1],
        ["tel\u{117}ti", 82, -1],
        ["in\u{117}ti", 82, -1],
        ["ter\u{117}ti", 82, -1],
        ["ui", 40, -1],
        ["iui", 86, -1],
        ["eniui", 87, -1],
        ["oj", -1, -1],
        ["\u{117}j", -1, -1],
        ["k", -1, -1],
        ["am", -1, -1],
        ["iam", 92, -1],
        ["iem", -1, -1],
        ["im", -1, -1],
        ["sim", 95, -1],
        ["om", -1, -1],
        ["tum", -1, -1],
        ["\u{117}m", -1, -1],
        ["tum\u{117}m", 99, -1],
        ["an", -1, -1],
        ["on", -1, -1],
        ["ion", 102, -1],
        ["un", -1, -1],
        ["iun", 104, -1],
        ["\u{117}n", -1, -1],
        ["o", -1, -1],
        ["io", 107, -1],
        ["enio", 108, -1],
        ["\u{117}jo", 107, -1],
        ["uo", 107, -1],
        ["s", -1, -1],
        ["as", 112, -1],
        ["ias", 113, -1],
        ["es", 112, -1],
        ["ies", 115, -1],
        ["is", 112, -1],
        ["ais", 117, -1],
        ["iais", 118, -1],
        ["tumeis", 117, -1],
        ["imis", 117, -1],
        ["enimis", 121, -1],
        ["omis", 117, -1],
        ["iomis", 123, -1],
        ["umis", 117, -1],
        ["\u{117}mis", 117, -1],
        ["enis", 117, -1],
        ["asis", 117, -1],
        ["ysis", 117, -1],
        ["ams", 112, -1],
        ["iams", 130, -1],
        ["iems", 112, -1],
        ["ims", 112, -1],
        ["enims", 133, -1],
        ["oms", 112, -1],
        ["ioms", 135, -1],
        ["ums", 112, -1],
        ["\u{117}ms", 112, -1],
        ["ens", 112, -1],
        ["os", 112, -1],
        ["ios", 140, -1],
        ["uos", 140, -1],
        ["iuos", 142, -1],
        ["us", 112, -1],
        ["aus", 144, -1],
        ["iaus", 145, -1],
        ["ius", 144, -1],
        ["ys", 112, -1],
        ["enys", 148, -1],
        ["\u{105}s", 112, -1],
        ["i\u{105}s", 150, -1],
        ["\u{117}s", 112, -1],
        ["am\u{117}s", 152, -1],
        ["iam\u{117}s", 153, -1],
        ["im\u{117}s", 152, -1],
        ["kim\u{117}s", 155, -1],
        ["sim\u{117}s", 155, -1],
        ["om\u{117}s", 152, -1],
        ["\u{117}m\u{117}s", 152, -1],
        ["tum\u{117}m\u{117}s", 159, -1],
        ["at\u{117}s", 152, -1],
        ["iat\u{117}s", 161, -1],
        ["sit\u{117}s", 152, -1],
        ["ot\u{117}s", 152, -1],
        ["\u{117}t\u{117}s", 152, -1],
        ["tum\u{117}t\u{117}s", 165, -1],
        ["\u{16B}s", 112, -1],
        ["\u{12F}s", 112, -1],
        ["t\u{173}s", 112, -1],
        ["at", -1, -1],
        ["iat", 170, -1],
        ["it", -1, -1],
        ["sit", 172, -1],
        ["ot", -1, -1],
        ["\u{117}t", -1, -1],
        ["tum\u{117}t", 175, -1],
        ["u", -1, -1],
        ["au", 177, -1],
        ["iau", 178, -1],
        ["\u{10D}iau", 179, -1],
        ["iu", 177, -1],
        ["eniu", 181, -1],
        ["siu", 181, -1],
        ["y", -1, -1],
        ["\u{105}", -1, -1],
        ["i\u{105}", 185, -1],
        ["\u{117}", -1, -1],
        ["\u{119}", -1, -1],
        ["\u{12F}", -1, -1],
        ["en\u{12F}", 189, -1],
        ["\u{173}", -1, -1],
        ["i\u{173}", 191, -1]
    ];

    private const array A_1 = [
        ["ing", -1, -1],
        ["aj", -1, -1],
        ["iaj", 1, -1],
        ["iej", -1, -1],
        ["oj", -1, -1],
        ["ioj", 4, -1],
        ["uoj", 4, -1],
        ["iuoj", 6, -1],
        ["auj", -1, -1],
        ["\u{105}j", -1, -1],
        ["i\u{105}j", 9, -1],
        ["\u{117}j", -1, -1],
        ["\u{173}j", -1, -1],
        ["i\u{173}j", 12, -1],
        ["ok", -1, -1],
        ["iok", 14, -1],
        ["iuk", -1, -1],
        ["uliuk", 16, -1],
        ["u\u{10D}iuk", 16, -1],
        ["i\u{161}k", -1, -1],
        ["iul", -1, -1],
        ["yl", -1, -1],
        ["\u{117}l", -1, -1],
        ["am", -1, -1],
        ["dam", 23, -1],
        ["jam", 23, -1],
        ["zgan", -1, -1],
        ["ain", -1, -1],
        ["esn", -1, -1],
        ["op", -1, -1],
        ["iop", 29, -1],
        ["ias", -1, -1],
        ["ies", -1, -1],
        ["ais", -1, -1],
        ["iais", 33, -1],
        ["os", -1, -1],
        ["ios", 35, -1],
        ["uos", 35, -1],
        ["iuos", 37, -1],
        ["aus", -1, -1],
        ["iaus", 39, -1],
        ["\u{105}s", -1, -1],
        ["i\u{105}s", 41, -1],
        ["\u{119}s", -1, -1],
        ["ut\u{117}ait", -1, -1],
        ["ant", -1, -1],
        ["iant", 45, -1],
        ["siant", 46, -1],
        ["int", -1, -1],
        ["ot", -1, -1],
        ["uot", 49, -1],
        ["iuot", 50, -1],
        ["yt", -1, -1],
        ["\u{117}t", -1, -1],
        ["yk\u{161}t", -1, -1],
        ["iau", -1, -1],
        ["dav", -1, -1],
        ["sv", -1, -1],
        ["\u{161}v", -1, -1],
        ["yk\u{161}\u{10D}", -1, -1],
        ["\u{119}", -1, -1],
        ["\u{117}j\u{119}", 60, -1]
    ];

    private const array A_2 = [
        ["ojime", -1, 7],
        ["\u{117}jime", -1, 3],
        ["avime", -1, 6],
        ["okate", -1, 8],
        ["aite", -1, 1],
        ["uote", -1, 2],
        ["asius", -1, 5],
        ["okat\u{117}s", -1, 8],
        ["ait\u{117}s", -1, 1],
        ["uot\u{117}s", -1, 2],
        ["esiu", -1, 4]
    ];

    private const array AS_2 = ["ait\u{117}", "uot\u{117}", "\u{117}jimas", "esys", "asys", "avimas", "ojimas", "okat\u{117}"];

    private const array A_3 = [
        ["\u{10D}", -1, 1],
        ["d\u{17E}", -1, 2]
    ];

    private const array AS_3 = ["t", "d"];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{105}"=>true, "\u{117}"=>true, "\u{119}"=>true, "\u{12F}"=>true, "\u{16B}"=>true, "\u{173}"=>true];



    protected function r_fix_chdz(): bool
    {
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_3);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        $this->slice_from(self::AS_3[$among_var - 1]);
        return true;
    }


    public function stem(): bool
    {
        $I_p1 = $this->limit;
        $v_1 = $this->cursor;
        $v_2 = $this->cursor;
        if (!($this->eq_s("a"))) {
            $this->cursor = $v_2;
            goto lab1;
        }
        if (mb_strlen($this->current, 'UTF-8') < 7) {
            $this->cursor = $v_2;
            goto lab1;
        }
    lab1:
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab0;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab0;
        }
        $this->inc_cursor();
        $I_p1 = $this->cursor;
    lab0:
        $this->cursor = $v_1;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_3 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            goto lab2;
        }
        $this->bra = $this->cursor;
        $this->slice_from(self::AS_2[$among_var - 1]);
    lab2:
        $this->cursor = $this->limit - $v_3;
        $v_4 = $this->limit - $this->cursor;
        if ($this->cursor < $I_p1) {
            goto lab3;
        }
        $v_5 = $this->limit_backward;
        $this->limit_backward = $I_p1;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_0) === 0) {
            $this->limit_backward = $v_5;
            goto lab3;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_5;
        $this->slice_del();
    lab3:
        $this->cursor = $this->limit - $v_4;
        $v_6 = $this->limit - $this->cursor;
        $this->r_fix_chdz();
        $this->cursor = $this->limit - $v_6;
        $v_7 = $this->limit - $this->cursor;
        while (true) {
            $v_8 = $this->limit - $this->cursor;
            if ($this->cursor < $I_p1) {
                goto lab5;
            }
            $v_9 = $this->limit_backward;
            $this->limit_backward = $I_p1;
            $this->ket = $this->cursor;
            if ($this->find_among_b(self::A_1) === 0) {
                $this->limit_backward = $v_9;
                goto lab5;
            }
            $this->bra = $this->cursor;
            $this->limit_backward = $v_9;
            $this->slice_del();
            continue;
        lab5:
            $this->cursor = $this->limit - $v_8;
            break;
        }
    lab4:
        $this->cursor = $this->limit - $v_7;
        $v_10 = $this->limit - $this->cursor;
        $this->r_fix_chdz();
        $this->cursor = $this->limit - $v_10;
        $v_11 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("gd"))) {
            goto lab6;
        }
        $this->bra = $this->cursor;
        $this->slice_from("g");
    lab6:
        $this->cursor = $this->limit - $v_11;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("'"))) {
            return false;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->cursor = $this->limit_backward;
        return true;
    }
}
