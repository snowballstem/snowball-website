<?php
// Generated from romanian.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballRomanianStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["\u{15F}", -1, 1],
        ["\u{163}", -1, 2]
    ];

    private const array AS_0 = ["\u{219}", "\u{21B}"];

    private const array A_1 = [
        ["", -1, 3],
        ["I", 0, 1],
        ["U", 0, 2]
    ];

    private const array A_2 = [
        ["ea", -1, 3],
        ["a\u{21B}ia", -1, 7],
        ["aua", -1, 2],
        ["iua", -1, 4],
        ["a\u{21B}ie", -1, 7],
        ["ele", -1, 3],
        ["ile", -1, 5],
        ["iile", 6, 4],
        ["iei", -1, 4],
        ["atei", -1, 6],
        ["ii", -1, 4],
        ["ului", -1, 1],
        ["ul", -1, 1],
        ["elor", -1, 3],
        ["ilor", -1, 4],
        ["iilor", 14, 4]
    ];

    private const array A_3 = [
        ["icala", -1, 4],
        ["iciva", -1, 4],
        ["ativa", -1, 5],
        ["itiva", -1, 6],
        ["icale", -1, 4],
        ["a\u{21B}iune", -1, 5],
        ["i\u{21B}iune", -1, 6],
        ["atoare", -1, 5],
        ["itoare", -1, 6],
        ["\u{103}toare", -1, 5],
        ["icitate", -1, 4],
        ["abilitate", -1, 1],
        ["ibilitate", -1, 2],
        ["ivitate", -1, 3],
        ["icive", -1, 4],
        ["ative", -1, 5],
        ["itive", -1, 6],
        ["icali", -1, 4],
        ["atori", -1, 5],
        ["icatori", 18, 4],
        ["itori", -1, 6],
        ["\u{103}tori", -1, 5],
        ["icitati", -1, 4],
        ["abilitati", -1, 1],
        ["ivitati", -1, 3],
        ["icivi", -1, 4],
        ["ativi", -1, 5],
        ["itivi", -1, 6],
        ["icit\u{103}i", -1, 4],
        ["abilit\u{103}i", -1, 1],
        ["ivit\u{103}i", -1, 3],
        ["icit\u{103}\u{21B}i", -1, 4],
        ["abilit\u{103}\u{21B}i", -1, 1],
        ["ivit\u{103}\u{21B}i", -1, 3],
        ["ical", -1, 4],
        ["ator", -1, 5],
        ["icator", 35, 4],
        ["itor", -1, 6],
        ["\u{103}tor", -1, 5],
        ["iciv", -1, 4],
        ["ativ", -1, 5],
        ["itiv", -1, 6],
        ["ical\u{103}", -1, 4],
        ["iciv\u{103}", -1, 4],
        ["ativ\u{103}", -1, 5],
        ["itiv\u{103}", -1, 6]
    ];

    private const array AS_3 = ["abil", "ibil", "iv", "ic", "at", "it"];

    private const array A_4 = [
        ["ica", -1, 1],
        ["abila", -1, 1],
        ["ibila", -1, 1],
        ["oasa", -1, 1],
        ["ata", -1, 1],
        ["ita", -1, 1],
        ["anta", -1, 1],
        ["ista", -1, 3],
        ["uta", -1, 1],
        ["iva", -1, 1],
        ["ic", -1, 1],
        ["ice", -1, 1],
        ["abile", -1, 1],
        ["ibile", -1, 1],
        ["isme", -1, 3],
        ["iune", -1, 2],
        ["oase", -1, 1],
        ["ate", -1, 1],
        ["itate", 17, 1],
        ["ite", -1, 1],
        ["ante", -1, 1],
        ["iste", -1, 3],
        ["ute", -1, 1],
        ["ive", -1, 1],
        ["ici", -1, 1],
        ["abili", -1, 1],
        ["ibili", -1, 1],
        ["iuni", -1, 2],
        ["atori", -1, 1],
        ["osi", -1, 1],
        ["ati", -1, 1],
        ["itati", 30, 1],
        ["iti", -1, 1],
        ["anti", -1, 1],
        ["isti", -1, 3],
        ["uti", -1, 1],
        ["i\u{219}ti", -1, 3],
        ["ivi", -1, 1],
        ["it\u{103}i", -1, 1],
        ["o\u{219}i", -1, 1],
        ["it\u{103}\u{21B}i", -1, 1],
        ["abil", -1, 1],
        ["ibil", -1, 1],
        ["ism", -1, 3],
        ["ator", -1, 1],
        ["os", -1, 1],
        ["at", -1, 1],
        ["it", -1, 1],
        ["ant", -1, 1],
        ["ist", -1, 3],
        ["ut", -1, 1],
        ["iv", -1, 1],
        ["ic\u{103}", -1, 1],
        ["abil\u{103}", -1, 1],
        ["ibil\u{103}", -1, 1],
        ["oas\u{103}", -1, 1],
        ["at\u{103}", -1, 1],
        ["it\u{103}", -1, 1],
        ["ant\u{103}", -1, 1],
        ["ist\u{103}", -1, 3],
        ["ut\u{103}", -1, 1],
        ["iv\u{103}", -1, 1]
    ];

    private const array A_5 = [
        ["ea", -1, 1],
        ["ia", -1, 1],
        ["esc", -1, 1],
        ["\u{103}sc", -1, 1],
        ["ind", -1, 1],
        ["\u{E2}nd", -1, 1],
        ["are", -1, 1],
        ["ere", -1, 1],
        ["ire", -1, 1],
        ["\u{E2}re", -1, 1],
        ["se", -1, 2],
        ["ase", 10, 1],
        ["sese", 10, 2],
        ["ise", 10, 1],
        ["use", 10, 1],
        ["\u{E2}se", 10, 1],
        ["e\u{219}te", -1, 1],
        ["\u{103}\u{219}te", -1, 1],
        ["eze", -1, 1],
        ["ai", -1, 1],
        ["eai", 19, 1],
        ["iai", 19, 1],
        ["sei", -1, 2],
        ["e\u{219}ti", -1, 1],
        ["\u{103}\u{219}ti", -1, 1],
        ["ui", -1, 1],
        ["ezi", -1, 1],
        ["a\u{219}i", -1, 1],
        ["se\u{219}i", -1, 2],
        ["ase\u{219}i", 28, 1],
        ["sese\u{219}i", 28, 2],
        ["ise\u{219}i", 28, 1],
        ["use\u{219}i", 28, 1],
        ["\u{E2}se\u{219}i", 28, 1],
        ["i\u{219}i", -1, 1],
        ["u\u{219}i", -1, 1],
        ["\u{E2}\u{219}i", -1, 1],
        ["a\u{21B}i", -1, 2],
        ["ea\u{21B}i", 37, 1],
        ["ia\u{21B}i", 37, 1],
        ["e\u{21B}i", -1, 2],
        ["i\u{21B}i", -1, 2],
        ["ar\u{103}\u{21B}i", -1, 1],
        ["ser\u{103}\u{21B}i", -1, 2],
        ["aser\u{103}\u{21B}i", 43, 1],
        ["seser\u{103}\u{21B}i", 43, 2],
        ["iser\u{103}\u{21B}i", 43, 1],
        ["user\u{103}\u{21B}i", 43, 1],
        ["\u{E2}ser\u{103}\u{21B}i", 43, 1],
        ["ir\u{103}\u{21B}i", -1, 1],
        ["ur\u{103}\u{21B}i", -1, 1],
        ["\u{E2}r\u{103}\u{21B}i", -1, 1],
        ["\u{E2}\u{21B}i", -1, 2],
        ["\u{E2}i", -1, 1],
        ["am", -1, 1],
        ["eam", 54, 1],
        ["iam", 54, 1],
        ["em", -1, 2],
        ["asem", 57, 1],
        ["sesem", 57, 2],
        ["isem", 57, 1],
        ["usem", 57, 1],
        ["\u{E2}sem", 57, 1],
        ["im", -1, 2],
        ["\u{103}m", -1, 2],
        ["ar\u{103}m", 64, 1],
        ["ser\u{103}m", 64, 2],
        ["aser\u{103}m", 66, 1],
        ["seser\u{103}m", 66, 2],
        ["iser\u{103}m", 66, 1],
        ["user\u{103}m", 66, 1],
        ["\u{E2}ser\u{103}m", 66, 1],
        ["ir\u{103}m", 64, 1],
        ["ur\u{103}m", 64, 1],
        ["\u{E2}r\u{103}m", 64, 1],
        ["\u{E2}m", -1, 2],
        ["au", -1, 1],
        ["eau", 76, 1],
        ["iau", 76, 1],
        ["indu", -1, 1],
        ["\u{E2}ndu", -1, 1],
        ["ez", -1, 1],
        ["easc\u{103}", -1, 1],
        ["ar\u{103}", -1, 1],
        ["ser\u{103}", -1, 2],
        ["aser\u{103}", 84, 1],
        ["seser\u{103}", 84, 2],
        ["iser\u{103}", 84, 1],
        ["user\u{103}", 84, 1],
        ["\u{E2}ser\u{103}", 84, 1],
        ["ir\u{103}", -1, 1],
        ["ur\u{103}", -1, 1],
        ["\u{E2}r\u{103}", -1, 1],
        ["eaz\u{103}", -1, 1]
    ];

    private const array A_6 = [
        ["a", -1, 1],
        ["e", -1, 1],
        ["ie", 1, 1],
        ["i", -1, 1],
        ["\u{103}", -1, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "\u{E2}"=>true, "\u{EE}"=>true, "\u{103}"=>true];



    public function stem(): bool
    {
        $v_1 = $this->cursor;
        while (true) {
            $v_2 = $this->cursor;
            while (true) {
                $v_3 = $this->cursor;
                $this->bra = $this->cursor;
                $among_var = $this->find_among(self::A_0);
                if (0 === $among_var) {
                    goto lab3;
                }
                $this->ket = $this->cursor;
                $this->slice_from(self::AS_0[$among_var - 1]);
                $this->cursor = $v_3;
                break;
            lab3:
                $this->cursor = $v_3;
                if ($this->cursor >= $this->limit) {
                    goto lab2;
                }
                $this->inc_cursor();
            }
            continue;
        lab2:
            $this->cursor = $v_2;
            break;
        }
    lab1:
        $this->cursor = $v_1;
    lab0:
        $v_4 = $this->cursor;
        while (true) {
            $v_5 = $this->cursor;
            while (true) {
                $v_6 = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab6;
                }
                $this->bra = $this->cursor;
                $v_7 = $this->cursor;
                if (!($this->eq_s("u"))) {
                    goto lab7;
                }
                $this->ket = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab7;
                }
                $this->slice_from("U");
                goto lab8;
            lab7:
                $this->cursor = $v_7;
                if (!($this->eq_s("i"))) {
                    goto lab6;
                }
                $this->ket = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab6;
                }
                $this->slice_from("I");
            lab8:
                $this->cursor = $v_6;
                break;
            lab6:
                $this->cursor = $v_6;
                if ($this->cursor >= $this->limit) {
                    goto lab5;
                }
                $this->inc_cursor();
            }
            continue;
        lab5:
            $this->cursor = $v_5;
            break;
        }
    lab4:
        $this->cursor = $v_4;
        $I_pV = $this->limit;
        $I_p1 = $this->limit;
        $I_p2 = $this->limit;
        $v_8 = $this->cursor;
        $v_9 = $this->cursor;
        if (!($this->in_grouping(self::G_v))) {
            goto lab11;
        }
        $v_10 = $this->cursor;
        if (!($this->out_grouping(self::G_v))) {
            goto lab12;
        }
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab12;
        }
        $this->inc_cursor();
        goto lab13;
    lab12:
        $this->cursor = $v_10;
        if (!($this->in_grouping(self::G_v))) {
            goto lab11;
        }
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab11;
        }
        $this->inc_cursor();
    lab13:
        goto lab14;
    lab11:
        $this->cursor = $v_9;
        if (!($this->out_grouping(self::G_v))) {
            goto lab10;
        }
        $v_11 = $this->cursor;
        if (!($this->out_grouping(self::G_v))) {
            goto lab15;
        }
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab15;
        }
        $this->inc_cursor();
        goto lab16;
    lab15:
        $this->cursor = $v_11;
        if (!($this->in_grouping(self::G_v))) {
            goto lab10;
        }
        if ($this->cursor >= $this->limit) {
            goto lab10;
        }
        $this->inc_cursor();
    lab16:
    lab14:
        $I_pV = $this->cursor;
    lab10:
        $this->cursor = $v_8;
        $v_12 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab17;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab17;
        }
        $this->inc_cursor();
        $I_p1 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab17;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab17;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab17:
        $this->cursor = $v_12;
    lab9:
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_13 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            goto lab18;
        }
        $this->bra = $this->cursor;
        if ($I_p1 > $this->cursor) {
            goto lab18;
        }
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                $this->slice_from("a");
                break;
            case 3:
                $this->slice_from("e");
                break;
            case 4:
                $this->slice_from("i");
                break;
            case 5:
                if (!($this->eq_s_b("ab"))) {
                    goto lab19;
                }
                goto lab18;
            lab19:
                $this->slice_from("i");
                break;
            case 6:
                $this->slice_from("at");
                break;
            case 7:
                $this->slice_from("a\u{21B}i");
                break;
        }
    lab18:
        $this->cursor = $this->limit - $v_13;
        $v_14 = $this->limit - $this->cursor;
        $B_standard_suffix_removed = false;
        while (true) {
            $v_15 = $this->limit - $this->cursor;
            $v_16 = $this->limit - $this->cursor;
            $this->ket = $this->cursor;
            $among_var = $this->find_among_b(self::A_3);
            if (0 === $among_var) {
                goto lab21;
            }
            $this->bra = $this->cursor;
            if ($I_p1 > $this->cursor) {
                goto lab21;
            }
            $this->slice_from(self::AS_3[$among_var - 1]);
            $B_standard_suffix_removed = true;
            $this->cursor = $this->limit - $v_16;
            continue;
        lab21:
            $this->cursor = $this->limit - $v_15;
            break;
        }
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab20;
        }
        $this->bra = $this->cursor;
        if ($I_p2 > $this->cursor) {
            goto lab20;
        }
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                if (!($this->eq_s_b("\u{21B}"))) {
                    goto lab20;
                }
                $this->bra = $this->cursor;
                $this->slice_from("t");
                break;
            case 3:
                $this->slice_from("ist");
                break;
        }
        $B_standard_suffix_removed = true;
    lab20:
        $this->cursor = $this->limit - $v_14;
        $v_17 = $this->limit - $this->cursor;
        if (!$B_standard_suffix_removed) {
            goto lab23;
        }
        goto lab24;
    lab23:
        if ($this->cursor < $I_pV) {
            goto lab22;
        }
        $v_18 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_5);
        if (0 === $among_var) {
            $this->limit_backward = $v_18;
            goto lab22;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if (!($this->out_grouping_b(self::G_v))) {
                    goto lab25;
                }
                goto lab26;
            lab25:
                if (!($this->eq_s_b("u"))) {
                    $this->limit_backward = $v_18;
                    goto lab22;
                }
            lab26:
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                break;
        }
        $this->limit_backward = $v_18;
    lab24:
    lab22:
        $this->cursor = $this->limit - $v_17;
        $v_19 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_6) === 0) {
            goto lab27;
        }
        $this->bra = $this->cursor;
        if ($I_pV > $this->cursor) {
            goto lab27;
        }
        $this->slice_del();
    lab27:
        $this->cursor = $this->limit - $v_19;
        $this->cursor = $this->limit_backward;
        $v_20 = $this->cursor;
        while (true) {
            $v_21 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_1);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("i");
                    break;
                case 2:
                    $this->slice_from("u");
                    break;
                case 3:
                    if ($this->cursor >= $this->limit) {
                        goto lab29;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab29:
            $this->cursor = $v_21;
            break;
        }
    lab28:
        $this->cursor = $v_20;
        return true;
    }
}
