<?php
// Generated from czech.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballCzechStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["c", -1, 1],
        ["nc", 0, -1],
        ["\u{ED}nc", 1, 2],
        ["avc", 0, -1],
        ["ovc", 0, -1]
    ];

    private const array AS_0 = ["k", "\u{ED}nk"];

    private const array A_1 = [
        ["c", -1, 1],
        ["nc", 0, -1],
        ["\u{ED}nc", 1, 2],
        ["avc", 0, -1],
        ["ovc", 0, -1],
        ["\u{10D}t", -1, 3],
        ["\u{161}t", -1, 4],
        ["de\u{161}t", 6, -1],
        ["le\u{161}t", 6, -1],
        ["i\u{161}t", 6, -1],
        ["pou\u{161}t", 6, -1],
        ["\u{E1}\u{161}t", 6, -1],
        ["\u{ED}\u{161}t", 6, -1]
    ];

    private const array AS_1 = ["k", "\u{ED}nk", "ck", "sk"];

    private const array A_2 = [
        ["in", -1, 2],
        ["ov", -1, 1],
        ["\u{16F}v", -1, 1]
    ];

    private const array A_3 = [
        ["", -1, 2],
        ["l", 0, 1],
        ["tl", 1, 2],
        ["s", 0, 1],
        ["es", 3, 2],
        ["\u{10D}", 0, 1],
        ["e\u{10D}", 5, 2],
        ["\u{159}", 0, 1],
        ["\u{17E}", 0, 1]
    ];

    private const array AS_3 = ["", "et"];

    private const array A_4 = [
        ["obl", -1, -1],
        ["sn", -1, -1],
        ["dot", -1, -1]
    ];

    private const array A_5 = [
        ["uc", -1, -1],
        ["h", -1, -1],
        ["ok", -1, -1],
        ["kar", -1, -1],
        ["\u{10D}", -1, -1]
    ];

    private const array A_6 = [
        ["a", -1, 1],
        ["ama", 0, 1],
        ["ata", 0, 1],
        ["eb", -1, 4],
        ["ec", -1, 5],
        ["e", -1, 2],
        ["ete", 5, 3],
        ["\u{11B}te", 5, 1],
        ["ech", -1, 2],
        ["atech", 8, 1],
        ["\u{E1}ch", -1, 1],
        ["\u{ED}ch", -1, 12],
        ["\u{FD}ch", -1, 1],
        ["i", -1, 12],
        ["mi", 13, 1],
        ["ami", 14, 1],
        ["emi", 14, 2],
        ["\u{11B}mi", 14, 1],
        ["\u{165}mi", 14, 11],
        ["\u{ED}mi", 14, 12],
        ["\u{FD}mi", 14, 1],
        ["eti", 13, 3],
        ["\u{11B}ti", 13, 1],
        ["ovi", 13, 1],
        ["ek", -1, 6],
        ["\u{11B}k", -1, 7],
        ["em", -1, 2],
        ["etem", 26, 3],
        ["\u{11B}tem", 26, 1],
        ["\u{11B}m", -1, 1],
        ["\u{E1}m", -1, 1],
        ["\u{E9}m", -1, 1],
        ["\u{ED}m", -1, 12],
        ["\u{16F}m", -1, 1],
        ["at\u{16F}m", 33, 1],
        ["\u{FD}m", -1, 1],
        ["o", -1, 1],
        ["\u{E9}ho", 36, 1],
        ["\u{ED}ho", 36, 12],
        ["us", -1, 1],
        ["at", -1, 1],
        ["et", -1, 9],
        ["u", -1, 1],
        ["\u{E9}mu", 42, 1],
        ["\u{ED}mu", 42, 12],
        ["ou", 42, 1],
        ["ev", -1, 10],
        ["y", -1, 1],
        ["aty", 47, 1],
        ["e\u{148}", -1, 8],
        ["\u{11B}", -1, 1],
        ["\u{E1}", -1, 1],
        ["\u{165}", -1, 11],
        ["\u{E9}", -1, 1],
        ["ov\u{E9}", 53, 1],
        ["\u{ED}", -1, 12],
        ["\u{16F}", -1, 1],
        ["\u{FD}", -1, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{E1}"=>true, "\u{E9}"=>true, "\u{ED}"=>true, "\u{F3}"=>true, "\u{FA}"=>true, "\u{FD}"=>true, "\u{11B}"=>true, "\u{16F}"=>true];

    private const array G_v_or_syllabic_c = ["a"=>true, "e"=>true, "i"=>true, "l"=>true, "o"=>true, "r"=>true, "u"=>true, "y"=>true, "\u{E1}"=>true, "\u{E9}"=>true, "\u{ED}"=>true, "\u{F3}"=>true, "\u{FA}"=>true, "\u{FD}"=>true, "\u{11B}"=>true, "\u{16F}"=>true];

    private const array G_ev_ending = ["h"=>true, "k"=>true, "n"=>true, "r"=>true, "t"=>true, "z"=>true];

    private const array G_env_ending = ["b"=>true, "c"=>true, "d"=>true, "h"=>true, "k"=>true, "p"=>true, "r"=>true, "s"=>true, "t"=>true, "v"=>true, "z"=>true, "\u{10D}"=>true, "\u{161}"=>true, "\u{17E}"=>true];



    protected function r_palatalise_e(): bool
    {
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_0);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        if ($among_var > 0) {
            $this->slice_from(self::AS_0[$among_var - 1]);
        }
        return true;
    }


    protected function r_palatalise_i(): bool
    {
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_1);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        if ($among_var > 0) {
            $this->slice_from(self::AS_1[$among_var - 1]);
        }
        return true;
    }


    public function stem(): bool
    {
        $v_1 = $this->cursor;
        if (!$this->hop(3)) {
            return false;
        }
        $I_x = $this->cursor;
        $this->cursor = $v_1;
        $I_p1 = $this->limit;
        $v_2 = $this->cursor;
        if (!($this->in_grouping(self::G_v))) {
            goto lab1;
        }
        goto lab2;
    lab1:
        if ($this->cursor >= $this->limit) {
            goto lab0;
        }
        $this->inc_cursor();
        if (!$this->go_out_grouping(self::G_v_or_syllabic_c)) {
            goto lab0;
        }
        $this->inc_cursor();
    lab2:
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab0;
        }
        $this->inc_cursor();
        $I_p1 = $this->cursor;
        if ($I_p1 >= $I_x) {
            goto lab3;
        }
        $I_p1 = $I_x;
    lab3:
    lab0:
        $this->cursor = $v_2;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_3 = $this->limit - $this->cursor;
        if ($this->cursor < $I_p1) {
            goto lab4;
        }
        $v_4 = $this->limit_backward;
        $this->limit_backward = $I_p1;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_6);
        if (0 === $among_var) {
            $this->limit_backward = $v_4;
            goto lab4;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_4;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                $v_5 = $this->limit - $this->cursor;
                if (!$this->r_palatalise_e()) {
                    $this->cursor = $this->limit - $v_5;
                    goto lab5;
                }
            lab5:
                break;
            case 3:
                $among_var = $this->find_among_b(self::A_3);
                $this->slice_from(self::AS_3[$among_var - 1]);
                break;
            case 4:
                $v_6 = $this->limit - $this->cursor;
                if (!($this->out_grouping_b(self::G_v))) {
                    goto lab4;
                }
                $this->cursor = $this->limit - $v_6;
                if (!($this->eq_s_b("t\u{159}"))) {
                    goto lab6;
                }
                goto lab4;
            lab6:
                $this->slice_from("b");
                break;
            case 5:
                $v_7 = $this->limit - $this->cursor;
                if (!($this->out_grouping_b(self::G_v))) {
                    goto lab4;
                }
                $this->cursor = $this->limit - $v_7;
                $this->slice_del();
                $this->insert($this->cursor, $this->cursor, "c");
                $v_8 = $this->limit - $this->cursor;
                if (!$this->r_palatalise_e()) {
                    $this->cursor = $this->limit - $v_8;
                    goto lab7;
                }
            lab7:
                break;
            case 6:
                $v_9 = $this->limit - $this->cursor;
                if (!($this->out_grouping_b(self::G_v))) {
                    goto lab4;
                }
                $this->cursor = $this->limit - $v_9;
                $v_10 = $this->limit - $this->cursor;
                if ($this->find_among_b(self::A_4) === 0) {
                    goto lab8;
                }
                goto lab4;
            lab8:
                $this->cursor = $this->limit - $v_10;
                $this->slice_from("k");
                break;
            case 7:
                if (!($this->eq_s_b("n"))) {
                    goto lab4;
                }
                $this->bra = $this->cursor;
                $this->slice_from("\u{148}k");
                break;
            case 8:
                $v_11 = $this->limit - $this->cursor;
                if (!($this->in_grouping_b(self::G_env_ending))) {
                    goto lab4;
                }
                $this->cursor = $this->limit - $v_11;
                $this->slice_from("n");
                break;
            case 9:
                if ($this->find_among_b(self::A_5) === 0) {
                    goto lab4;
                }
                $this->slice_from("t");
                break;
            case 10:
                if (!($this->in_grouping_b(self::G_ev_ending))) {
                    goto lab4;
                }
                $this->slice_from("v");
                break;
            case 11:
                $this->slice_from("t");
                break;
            case 12:
                $this->slice_del();
                $v_12 = $this->limit - $this->cursor;
                if (!$this->r_palatalise_i()) {
                    $this->cursor = $this->limit - $v_12;
                    goto lab9;
                }
            lab9:
                break;
        }
    lab4:
        $this->cursor = $this->limit - $v_3;
        $v_13 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            goto lab10;
        }
        $this->bra = $this->cursor;
        if ($I_p1 > $this->cursor) {
            goto lab10;
        }
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                $v_14 = $this->limit - $this->cursor;
                if (!$this->r_palatalise_i()) {
                    $this->cursor = $this->limit - $v_14;
                    goto lab11;
                }
            lab11:
                break;
        }
    lab10:
        $this->cursor = $this->limit - $v_13;
        $this->cursor = $this->limit_backward;
        return true;
    }
}
