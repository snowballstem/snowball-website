<?php
// Generated from french.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballFrenchStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["col", -1, -1],
        ["ni", -1, 1],
        ["par", -1, -1],
        ["tap", -1, -1]
    ];

    private const array A_1 = [
        ["", -1, 7],
        ["H", 0, 6],
        ["He", 1, 4],
        ["Hi", 1, 5],
        ["I", 0, 1],
        ["U", 0, 2],
        ["Y", 0, 3]
    ];

    private const array A_2 = [
        ["iqU", -1, 3],
        ["abl", -1, 3],
        ["I\u{E8}r", -1, 4],
        ["i\u{E8}r", -1, 4],
        ["eus", -1, 2],
        ["iv", -1, 1]
    ];

    private const array A_3 = [
        ["ic", -1, 2],
        ["abil", -1, 1],
        ["iv", -1, 3]
    ];

    private const array A_4 = [
        ["iqUe", -1, 1],
        ["atrice", -1, 2],
        ["ance", -1, 1],
        ["ence", -1, 5],
        ["logie", -1, 3],
        ["able", -1, 1],
        ["isme", -1, 1],
        ["euse", -1, 12],
        ["iste", -1, 1],
        ["ive", -1, 8],
        ["if", -1, 8],
        ["usion", -1, 4],
        ["ation", -1, 2],
        ["ution", -1, 4],
        ["ateur", -1, 2],
        ["iqUes", -1, 1],
        ["atrices", -1, 2],
        ["ances", -1, 1],
        ["ences", -1, 5],
        ["logies", -1, 3],
        ["ables", -1, 1],
        ["ismes", -1, 1],
        ["euses", -1, 12],
        ["istes", -1, 1],
        ["ives", -1, 8],
        ["ifs", -1, 8],
        ["usions", -1, 4],
        ["ations", -1, 2],
        ["utions", -1, 4],
        ["ateurs", -1, 2],
        ["ments", -1, 16],
        ["ements", 30, 6],
        ["issements", 31, 13],
        ["it\u{E9}s", -1, 7],
        ["ment", -1, 16],
        ["ement", 34, 6],
        ["issement", 35, 13],
        ["amment", 34, 14],
        ["emment", 34, 15],
        ["aux", -1, 10],
        ["eaux", 39, 9],
        ["eux", -1, 1],
        ["oux", -1, 11],
        ["it\u{E9}", -1, 7]
    ];

    private const array A_5 = [
        ["ira", -1, 1],
        ["ie", -1, 1],
        ["isse", -1, 1],
        ["issante", -1, 1],
        ["i", -1, 1],
        ["irai", 4, 1],
        ["ir", -1, 1],
        ["iras", -1, 1],
        ["ies", -1, 1],
        ["\u{EE}mes", -1, 1],
        ["isses", -1, 1],
        ["issantes", -1, 1],
        ["\u{EE}tes", -1, 1],
        ["is", -1, 1],
        ["irais", 13, 1],
        ["issais", 13, 1],
        ["irions", -1, 1],
        ["issions", -1, 1],
        ["irons", -1, 1],
        ["issons", -1, 1],
        ["issants", -1, 1],
        ["it", -1, 1],
        ["irait", 21, 1],
        ["issait", 21, 1],
        ["issant", -1, 1],
        ["iraIent", -1, 1],
        ["issaIent", -1, 1],
        ["irent", -1, 1],
        ["issent", -1, 1],
        ["iront", -1, 1],
        ["\u{EE}t", -1, 1],
        ["iriez", -1, 1],
        ["issiez", -1, 1],
        ["irez", -1, 1],
        ["issez", -1, 1]
    ];

    private const array A_6 = [
        ["al", -1, 1],
        ["\u{E9}pl", -1, -1],
        ["auv", -1, -1]
    ];

    private const array A_7 = [
        ["a", -1, 3],
        ["era", 0, 2],
        ["aise", -1, 4],
        ["asse", -1, 3],
        ["ante", -1, 3],
        ["\u{E9}e", -1, 2],
        ["ai", -1, 3],
        ["erai", 6, 2],
        ["er", -1, 2],
        ["as", -1, 3],
        ["eras", 9, 2],
        ["\u{E2}mes", -1, 3],
        ["aises", -1, 4],
        ["asses", -1, 3],
        ["antes", -1, 3],
        ["\u{E2}tes", -1, 3],
        ["\u{E9}es", -1, 2],
        ["ais", -1, 4],
        ["eais", 17, 2],
        ["erais", 17, 2],
        ["ions", -1, 1],
        ["erions", 20, 2],
        ["assions", 20, 3],
        ["erons", -1, 2],
        ["ants", -1, 3],
        ["\u{E9}s", -1, 2],
        ["ait", -1, 3],
        ["erait", 26, 2],
        ["ant", -1, 3],
        ["aIent", -1, 3],
        ["eraIent", 29, 2],
        ["\u{E8}rent", -1, 2],
        ["assent", -1, 3],
        ["eront", -1, 2],
        ["\u{E2}t", -1, 3],
        ["ez", -1, 2],
        ["iez", 35, 2],
        ["eriez", 36, 2],
        ["assiez", 36, 3],
        ["erez", 35, 2],
        ["\u{E9}", -1, 2]
    ];

    private const array A_8 = [
        ["e", -1, 3],
        ["I\u{E8}re", 0, 2],
        ["i\u{E8}re", 0, 2],
        ["ion", -1, 1],
        ["Ier", -1, 2],
        ["ier", -1, 2]
    ];

    private const array A_9 = [
        ["ell", -1, -1],
        ["eill", -1, -1],
        ["enn", -1, -1],
        ["onn", -1, -1],
        ["ett", -1, -1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{E0}"=>true, "\u{E2}"=>true, "\u{E8}"=>true, "\u{E9}"=>true, "\u{EA}"=>true, "\u{EB}"=>true, "\u{EE}"=>true, "\u{EF}"=>true, "\u{F4}"=>true, "\u{F9}"=>true, "\u{FB}"=>true];

    private const array G_oux_ending = ["b"=>true, "h"=>true, "j"=>true, "l"=>true, "n"=>true, "p"=>true];

    private const array G_elision_char = ["c"=>true, "d"=>true, "j"=>true, "l"=>true, "m"=>true, "n"=>true, "s"=>true, "t"=>true, "z"=>true];

    private const array G_keep_with_s = ["a"=>true, "i"=>true, "o"=>true, "s"=>true, "u"=>true, "\u{E8}"=>true];



    public function stem(): bool
    {
        $v_1 = $this->cursor;
        $this->bra = $this->cursor;
        if (!($this->in_grouping(self::G_elision_char))) {
            goto lab1;
        }
        goto lab2;
    lab1:
        if (!($this->eq_s("qu"))) {
            goto lab0;
        }
    lab2:
        if (!($this->eq_s("'"))) {
            goto lab0;
        }
        $this->ket = $this->cursor;
        if ($this->cursor >= $this->limit) {
            goto lab0;
        }
        $this->slice_del();
    lab0:
        $this->cursor = $v_1;
        $v_2 = $this->cursor;
        while (true) {
            $v_3 = $this->cursor;
            while (true) {
                $v_4 = $this->cursor;
                $v_5 = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab6;
                }
                $this->bra = $this->cursor;
                $v_6 = $this->cursor;
                if (!($this->eq_s("u"))) {
                    goto lab7;
                }
                $this->ket = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab7;
                }
                $this->slice_from("U");
                goto lab8;
            lab7:
                $this->cursor = $v_6;
                if (!($this->eq_s("i"))) {
                    goto lab9;
                }
                $this->ket = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab9;
                }
                $this->slice_from("I");
                goto lab8;
            lab9:
                $this->cursor = $v_6;
                if (!($this->eq_s("y"))) {
                    goto lab6;
                }
                $this->ket = $this->cursor;
                $this->slice_from("Y");
            lab8:
                goto lab10;
            lab6:
                $this->cursor = $v_5;
                $this->bra = $this->cursor;
                if (!($this->eq_s("\u{EB}"))) {
                    goto lab11;
                }
                $this->ket = $this->cursor;
                $this->slice_from("He");
                goto lab10;
            lab11:
                $this->cursor = $v_5;
                $this->bra = $this->cursor;
                if (!($this->eq_s("\u{EF}"))) {
                    goto lab12;
                }
                $this->ket = $this->cursor;
                $this->slice_from("Hi");
                goto lab10;
            lab12:
                $this->cursor = $v_5;
                $this->bra = $this->cursor;
                if (!($this->eq_s("y"))) {
                    goto lab13;
                }
                $this->ket = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab13;
                }
                $this->slice_from("Y");
                goto lab10;
            lab13:
                $this->cursor = $v_5;
                if (!($this->eq_s("q"))) {
                    goto lab5;
                }
                $this->bra = $this->cursor;
                if (!($this->eq_s("u"))) {
                    goto lab5;
                }
                $this->ket = $this->cursor;
                $this->slice_from("U");
            lab10:
                $this->cursor = $v_4;
                break;
            lab5:
                $this->cursor = $v_4;
                if ($this->cursor >= $this->limit) {
                    goto lab4;
                }
                $this->inc_cursor();
            }
            continue;
        lab4:
            $this->cursor = $v_3;
            break;
        }
    lab3:
        $this->cursor = $v_2;
        $I_pV = $this->limit;
        $I_p1 = $this->limit;
        $I_p2 = $this->limit;
        $v_7 = $this->cursor;
        $v_8 = $this->cursor;
        if (!($this->in_grouping(self::G_v))) {
            goto lab16;
        }
        if (!($this->in_grouping(self::G_v))) {
            goto lab16;
        }
        if ($this->cursor >= $this->limit) {
            goto lab16;
        }
        $this->inc_cursor();
        goto lab17;
    lab16:
        $this->cursor = $v_8;
        $among_var = $this->find_among(self::A_0);
        if (0 === $among_var) {
            goto lab18;
        }
        switch ($among_var) {
            case 1:
                if (!($this->in_grouping(self::G_v))) {
                    goto lab18;
                }
                break;
        }
        goto lab17;
    lab18:
        $this->cursor = $v_8;
        if ($this->cursor >= $this->limit) {
            goto lab15;
        }
        $this->inc_cursor();
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab15;
        }
        $this->inc_cursor();
    lab17:
        $I_pV = $this->cursor;
    lab15:
        $this->cursor = $v_7;
        $v_9 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab19;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab19;
        }
        $this->inc_cursor();
        $I_p1 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab19;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab19;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab19:
        $this->cursor = $v_9;
    lab14:
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_10 = $this->limit - $this->cursor;
        $v_11 = $this->limit - $this->cursor;
        $v_12 = $this->limit - $this->cursor;
        $v_13 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab22;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p2 > $this->cursor) {
                    goto lab22;
                }
                $this->slice_del();
                break;
            case 2:
                if ($I_p2 > $this->cursor) {
                    goto lab22;
                }
                $this->slice_del();
                $v_14 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("ic"))) {
                    $this->cursor = $this->limit - $v_14;
                    goto lab23;
                }
                $this->bra = $this->cursor;
                $v_15 = $this->limit - $this->cursor;
                if ($I_p2 > $this->cursor) {
                    goto lab24;
                }
                $this->slice_del();
                goto lab25;
            lab24:
                $this->cursor = $this->limit - $v_15;
                $this->slice_from("iqU");
            lab25:
            lab23:
                break;
            case 3:
                if ($I_p2 > $this->cursor) {
                    goto lab22;
                }
                $this->slice_from("log");
                break;
            case 4:
                if ($I_p2 > $this->cursor) {
                    goto lab22;
                }
                $this->slice_from("u");
                break;
            case 5:
                if ($I_p2 > $this->cursor) {
                    goto lab22;
                }
                $this->slice_from("ent");
                break;
            case 6:
                if ($I_pV > $this->cursor) {
                    goto lab22;
                }
                $this->slice_del();
                $v_16 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                $among_var = $this->find_among_b(self::A_2);
                if (0 === $among_var) {
                    $this->cursor = $this->limit - $v_16;
                    goto lab26;
                }
                $this->bra = $this->cursor;
                switch ($among_var) {
                    case 1:
                        if ($I_p2 > $this->cursor) {
                            $this->cursor = $this->limit - $v_16;
                            goto lab26;
                        }
                        $this->slice_del();
                        $this->ket = $this->cursor;
                        if (!($this->eq_s_b("at"))) {
                            $this->cursor = $this->limit - $v_16;
                            goto lab26;
                        }
                        $this->bra = $this->cursor;
                        if ($I_p2 > $this->cursor) {
                            $this->cursor = $this->limit - $v_16;
                            goto lab26;
                        }
                        $this->slice_del();
                        break;
                    case 2:
                        $v_17 = $this->limit - $this->cursor;
                        if ($I_p2 > $this->cursor) {
                            goto lab27;
                        }
                        $this->slice_del();
                        goto lab28;
                    lab27:
                        $this->cursor = $this->limit - $v_17;
                        if ($I_p1 > $this->cursor) {
                            $this->cursor = $this->limit - $v_16;
                            goto lab26;
                        }
                        $this->slice_from("eux");
                    lab28:
                        break;
                    case 3:
                        if ($I_p2 > $this->cursor) {
                            $this->cursor = $this->limit - $v_16;
                            goto lab26;
                        }
                        $this->slice_del();
                        break;
                    case 4:
                        if ($I_pV > $this->cursor) {
                            $this->cursor = $this->limit - $v_16;
                            goto lab26;
                        }
                        $this->slice_from("i");
                        break;
                }
            lab26:
                break;
            case 7:
                if ($I_p2 > $this->cursor) {
                    goto lab22;
                }
                $this->slice_del();
                $v_18 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                $among_var = $this->find_among_b(self::A_3);
                if (0 === $among_var) {
                    $this->cursor = $this->limit - $v_18;
                    goto lab29;
                }
                $this->bra = $this->cursor;
                switch ($among_var) {
                    case 1:
                        $v_19 = $this->limit - $this->cursor;
                        if ($I_p2 > $this->cursor) {
                            goto lab30;
                        }
                        $this->slice_del();
                        goto lab31;
                    lab30:
                        $this->cursor = $this->limit - $v_19;
                        $this->slice_from("abl");
                    lab31:
                        break;
                    case 2:
                        $v_20 = $this->limit - $this->cursor;
                        if ($I_p2 > $this->cursor) {
                            goto lab32;
                        }
                        $this->slice_del();
                        goto lab33;
                    lab32:
                        $this->cursor = $this->limit - $v_20;
                        $this->slice_from("iqU");
                    lab33:
                        break;
                    case 3:
                        if ($I_p2 > $this->cursor) {
                            $this->cursor = $this->limit - $v_18;
                            goto lab29;
                        }
                        $this->slice_del();
                        break;
                }
            lab29:
                break;
            case 8:
                if ($I_p2 > $this->cursor) {
                    goto lab22;
                }
                $this->slice_del();
                $v_21 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("at"))) {
                    $this->cursor = $this->limit - $v_21;
                    goto lab34;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_21;
                    goto lab34;
                }
                $this->slice_del();
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("ic"))) {
                    $this->cursor = $this->limit - $v_21;
                    goto lab34;
                }
                $this->bra = $this->cursor;
                $v_22 = $this->limit - $this->cursor;
                if ($I_p2 > $this->cursor) {
                    goto lab35;
                }
                $this->slice_del();
                goto lab36;
            lab35:
                $this->cursor = $this->limit - $v_22;
                $this->slice_from("iqU");
            lab36:
            lab34:
                break;
            case 9:
                $this->slice_from("eau");
                break;
            case 10:
                if ($I_p1 > $this->cursor) {
                    goto lab22;
                }
                $this->slice_from("al");
                break;
            case 11:
                if (!($this->in_grouping_b(self::G_oux_ending))) {
                    goto lab22;
                }
                $this->slice_from("ou");
                break;
            case 12:
                $v_23 = $this->limit - $this->cursor;
                if ($I_p2 > $this->cursor) {
                    goto lab37;
                }
                $this->slice_del();
                goto lab38;
            lab37:
                $this->cursor = $this->limit - $v_23;
                if ($I_p1 > $this->cursor) {
                    goto lab22;
                }
                $this->slice_from("eux");
            lab38:
                break;
            case 13:
                if ($I_p1 > $this->cursor) {
                    goto lab22;
                }
                if (!($this->out_grouping_b(self::G_v))) {
                    goto lab22;
                }
                $this->slice_del();
                break;
            case 14:
                if ($I_pV > $this->cursor) {
                    goto lab22;
                }
                $this->slice_from("ant");
                goto lab22;
            case 15:
                if ($I_pV > $this->cursor) {
                    goto lab22;
                }
                $this->slice_from("ent");
                goto lab22;
            case 16:
                $v_24 = $this->limit - $this->cursor;
                if (!($this->in_grouping_b(self::G_v))) {
                    goto lab22;
                }
                if ($I_pV > $this->cursor) {
                    goto lab22;
                }
                $this->cursor = $this->limit - $v_24;
                $this->slice_del();
                goto lab22;
        }
        goto lab39;
    lab22:
        $this->cursor = $this->limit - $v_13;
        if ($this->cursor < $I_pV) {
            goto lab40;
        }
        $v_25 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_5) === 0) {
            $this->limit_backward = $v_25;
            goto lab40;
        }
        $this->bra = $this->cursor;
        if (!($this->eq_s_b("H"))) {
            goto lab41;
        }
        $this->limit_backward = $v_25;
        goto lab40;
    lab41:
        if (!($this->out_grouping_b(self::G_v))) {
            $this->limit_backward = $v_25;
            goto lab40;
        }
        $this->slice_del();
        $this->limit_backward = $v_25;
        goto lab39;
    lab40:
        $this->cursor = $this->limit - $v_13;
        if ($this->cursor < $I_pV) {
            goto lab21;
        }
        $v_26 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_7);
        if (0 === $among_var) {
            $this->limit_backward = $v_26;
            goto lab21;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_26;
        switch ($among_var) {
            case 1:
                if ($I_p2 > $this->cursor) {
                    goto lab21;
                }
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                break;
            case 3:
                $v_27 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("e"))) {
                    $this->cursor = $this->limit - $v_27;
                    goto lab42;
                }
                if ($I_pV > $this->cursor) {
                    $this->cursor = $this->limit - $v_27;
                    goto lab42;
                }
                $this->bra = $this->cursor;
            lab42:
                $this->slice_del();
                break;
            case 4:
                $v_28 = $this->limit - $this->cursor;
                $among_var = $this->find_among_b(self::A_6);
                if (0 === $among_var) {
                    goto lab43;
                }
                switch ($among_var) {
                    case 1:
                        if ($this->cursor <= $this->limit_backward) {
                            goto lab43;
                        }
                        $this->dec_cursor();
                        if ($this->cursor > $this->limit_backward) {
                            goto lab43;
                        }
                        break;
                }
                goto lab21;
            lab43:
                $this->cursor = $this->limit - $v_28;
                $this->slice_del();
                break;
        }
    lab39:
        $this->cursor = $this->limit - $v_12;
        $v_29 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $v_30 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("Y"))) {
            goto lab45;
        }
        $this->bra = $this->cursor;
        $this->slice_from("i");
        goto lab46;
    lab45:
        $this->cursor = $this->limit - $v_30;
        if (!($this->eq_s_b("\u{E7}"))) {
            $this->cursor = $this->limit - $v_29;
            goto lab44;
        }
        $this->bra = $this->cursor;
        $this->slice_from("c");
    lab46:
    lab44:
        goto lab47;
    lab21:
        $this->cursor = $this->limit - $v_11;
        $v_31 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("s"))) {
            $this->cursor = $this->limit - $v_31;
            goto lab48;
        }
        $this->bra = $this->cursor;
        $v_32 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("Hi"))) {
            goto lab49;
        }
        goto lab50;
    lab49:
        if (!($this->out_grouping_b(self::G_keep_with_s))) {
            $this->cursor = $this->limit - $v_31;
            goto lab48;
        }
    lab50:
        $this->cursor = $this->limit - $v_32;
        $this->slice_del();
    lab48:
        if ($this->cursor < $I_pV) {
            goto lab20;
        }
        $v_33 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_8);
        if (0 === $among_var) {
            $this->limit_backward = $v_33;
            goto lab20;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p2 > $this->cursor) {
                    $this->limit_backward = $v_33;
                    goto lab20;
                }
                if (!($this->eq_s_b("s"))) {
                    goto lab51;
                }
                goto lab52;
            lab51:
                if (!($this->eq_s_b("t"))) {
                    $this->limit_backward = $v_33;
                    goto lab20;
                }
            lab52:
                $this->slice_del();
                break;
            case 2:
                $this->slice_from("i");
                break;
            case 3:
                $this->slice_del();
                break;
        }
        $this->limit_backward = $v_33;
    lab47:
    lab20:
        $this->cursor = $this->limit - $v_10;
        $v_34 = $this->limit - $this->cursor;
        $v_35 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_9) === 0) {
            goto lab53;
        }
        $this->cursor = $this->limit - $v_35;
        $this->ket = $this->cursor;
        if ($this->cursor <= $this->limit_backward) {
            goto lab53;
        }
        $this->dec_cursor();
        $this->bra = $this->cursor;
        $this->slice_del();
    lab53:
        $this->cursor = $this->limit - $v_34;
        $v_36 = $this->limit - $this->cursor;
        $v_37 = 1;
        while (true) {
            if (!($this->out_grouping_b(self::G_v))) {
                goto lab55;
            }
            $v_37--;
            continue;
        lab55:
            break;
        }
        if ($v_37 > 0) {
            goto lab54;
        }
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{E9}"))) {
            goto lab56;
        }
        goto lab57;
    lab56:
        if (!($this->eq_s_b("\u{E8}"))) {
            goto lab54;
        }
    lab57:
        $this->bra = $this->cursor;
        $this->slice_from("e");
    lab54:
        $this->cursor = $this->limit - $v_36;
        $this->cursor = $this->limit_backward;
        $v_38 = $this->cursor;
        while (true) {
            $v_39 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_1);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("i");
                    break;
                case 2:
                    $this->slice_from("u");
                    break;
                case 3:
                    $this->slice_from("y");
                    break;
                case 4:
                    $this->slice_from("\u{EB}");
                    break;
                case 5:
                    $this->slice_from("\u{EF}");
                    break;
                case 6:
                    $this->slice_del();
                    break;
                case 7:
                    if ($this->cursor >= $this->limit) {
                        goto lab59;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab59:
            $this->cursor = $v_39;
            break;
        }
    lab58:
        $this->cursor = $v_38;
        return true;
    }
}
