<?php
// Generated from norwegian.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballNorwegianStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["", -1, 1],
        ["ind", 0, -1],
        ["kk", 0, -1],
        ["nk", 0, -1],
        ["amm", 0, -1],
        ["omm", 0, -1],
        ["kap", 0, -1],
        ["skap", 6, 1],
        ["pp", 0, -1],
        ["lt", 0, -1],
        ["ast", 0, -1],
        ["\u{F8}st", 0, -1],
        ["v", 0, -1],
        ["hav", 12, 1],
        ["giv", 12, 1]
    ];

    private const array A_1 = [
        ["a", -1, 1],
        ["e", -1, 1],
        ["ede", 1, 1],
        ["ande", 1, 1],
        ["ende", 1, 1],
        ["ane", 1, 1],
        ["ene", 1, 1],
        ["hetene", 6, 1],
        ["erte", 1, 4],
        ["en", -1, 1],
        ["heten", 9, 1],
        ["ar", -1, 1],
        ["er", -1, 1],
        ["heter", 12, 1],
        ["s", -1, 3],
        ["as", 14, 1],
        ["es", 14, 1],
        ["edes", 16, 1],
        ["endes", 16, 1],
        ["enes", 16, 1],
        ["hetenes", 19, 1],
        ["ens", 14, 1],
        ["hetens", 21, 1],
        ["ers", 14, 2],
        ["ets", 14, 1],
        ["et", -1, 1],
        ["het", 25, 1],
        ["ert", -1, 4],
        ["ast", -1, 1]
    ];

    private const array A_2 = [
        ["dt", -1, -1],
        ["vt", -1, -1]
    ];

    private const array A_3 = [
        ["leg", -1, 1],
        ["eleg", 0, 1],
        ["ig", -1, 1],
        ["eig", 2, 1],
        ["lig", 2, 1],
        ["elig", 4, 1],
        ["els", -1, 1],
        ["lov", -1, 1],
        ["elov", 7, 1],
        ["slov", 7, 1],
        ["hetslov", 9, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{E5}"=>true, "\u{E6}"=>true, "\u{EA}"=>true, "\u{F2}"=>true, "\u{F3}"=>true, "\u{F4}"=>true, "\u{F8}"=>true];

    private const array G_s_ending = ["b"=>true, "c"=>true, "d"=>true, "f"=>true, "g"=>true, "h"=>true, "j"=>true, "l"=>true, "m"=>true, "n"=>true, "o"=>true, "p"=>true, "t"=>true, "v"=>true, "y"=>true, "z"=>true];



    public function stem(): bool
    {
        $I_p1 = $this->limit;
        $v_1 = $this->cursor;
        $v_2 = $this->cursor;
        while (true) {
            if (!($this->eq_s("'"))) {
                goto lab2;
            }
            break;
        lab2:
            if ($this->cursor >= $this->limit) {
                goto lab1;
            }
            $this->inc_cursor();
        }
        goto lab3;
    lab1:
        $this->cursor = $v_2;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab0;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab0;
        }
        $this->inc_cursor();
    lab3:
        $I_p1 = $this->cursor;
    lab0:
        $this->cursor = $v_1;
        $v_3 = $this->cursor;
        if (!$this->hop(3)) {
            return false;
        }
        if ($I_p1 >= $this->cursor) {
            goto lab4;
        }
        $I_p1 = $this->cursor;
    lab4:
        $this->cursor = $v_3;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_4 = $this->limit - $this->cursor;
        if ($this->cursor < $I_p1) {
            goto lab5;
        }
        $v_5 = $this->limit_backward;
        $this->limit_backward = $I_p1;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_1);
        if (0 === $among_var) {
            $this->limit_backward = $v_5;
            goto lab5;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_5;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                $among_var = $this->find_among_b(self::A_0);
                switch ($among_var) {
                    case 1:
                        $this->slice_del();
                        break;
                }
                break;
            case 3:
                $v_6 = $this->limit - $this->cursor;
                if (!($this->in_grouping_b(self::G_s_ending))) {
                    goto lab6;
                }
                goto lab7;
            lab6:
                $this->cursor = $this->limit - $v_6;
                if (!($this->eq_s_b("r"))) {
                    goto lab8;
                }
                if (!($this->eq_s_b("e"))) {
                    goto lab9;
                }
                goto lab8;
            lab9:
                goto lab7;
            lab8:
                $this->cursor = $this->limit - $v_6;
                if (!($this->eq_s_b("k"))) {
                    goto lab5;
                }
                if (!($this->out_grouping_b(self::G_v))) {
                    goto lab5;
                }
            lab7:
                $this->slice_del();
                break;
            case 4:
                $this->slice_from("er");
                break;
        }
    lab5:
        $this->cursor = $this->limit - $v_4;
        $v_7 = $this->limit - $this->cursor;
        $v_8 = $this->limit - $this->cursor;
        if ($this->cursor < $I_p1) {
            goto lab10;
        }
        $v_9 = $this->limit_backward;
        $this->limit_backward = $I_p1;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_2) === 0) {
            $this->limit_backward = $v_9;
            goto lab10;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_9;
        $this->cursor = $this->limit - $v_8;
        if ($this->cursor <= $this->limit_backward) {
            goto lab10;
        }
        $this->dec_cursor();
        $this->bra = $this->cursor;
        $this->slice_del();
    lab10:
        $this->cursor = $this->limit - $v_7;
        $v_10 = $this->limit - $this->cursor;
        if ($this->cursor < $I_p1) {
            goto lab11;
        }
        $v_11 = $this->limit_backward;
        $this->limit_backward = $I_p1;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_3) === 0) {
            $this->limit_backward = $v_11;
            goto lab11;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_11;
        $this->slice_del();
    lab11:
        $this->cursor = $this->limit - $v_10;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("'"))) {
            return false;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->cursor = $this->limit_backward;
        return true;
    }
}
