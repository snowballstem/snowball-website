<?php
// Generated from portuguese.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballPortugueseStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["", -1, 3],
        ["\u{E3}", 0, 1],
        ["\u{F5}", 0, 2]
    ];

    private const array A_1 = [
        ["", -1, 3],
        ["a~", 0, 1],
        ["o~", 0, 2]
    ];

    private const array A_2 = [
        ["ic", -1, -1],
        ["ad", -1, -1],
        ["os", -1, -1],
        ["iv", -1, 1]
    ];

    private const array A_3 = [
        ["ante", -1, 1],
        ["avel", -1, 1],
        ["\u{ED}vel", -1, 1]
    ];

    private const array A_4 = [
        ["ic", -1, 1],
        ["abil", -1, 1],
        ["iv", -1, 1]
    ];

    private const array A_5 = [
        ["ica", -1, 1],
        ["\u{E2}ncia", -1, 1],
        ["\u{EA}ncia", -1, 4],
        ["logia", -1, 2],
        ["ira", -1, 9],
        ["adora", -1, 1],
        ["osa", -1, 1],
        ["ista", -1, 1],
        ["iva", -1, 8],
        ["eza", -1, 1],
        ["idade", -1, 7],
        ["ante", -1, 1],
        ["mente", -1, 6],
        ["amente", 12, 5],
        ["\u{E1}vel", -1, 1],
        ["\u{ED}vel", -1, 1],
        ["ico", -1, 1],
        ["ismo", -1, 1],
        ["oso", -1, 1],
        ["amento", -1, 1],
        ["imento", -1, 1],
        ["ivo", -1, 8],
        ["a\u{E7}a~o", -1, 1],
        ["u\u{E7}a~o", -1, 3],
        ["ador", -1, 1],
        ["icas", -1, 1],
        ["\u{EA}ncias", -1, 4],
        ["logias", -1, 2],
        ["iras", -1, 9],
        ["adoras", -1, 1],
        ["osas", -1, 1],
        ["istas", -1, 1],
        ["ivas", -1, 8],
        ["ezas", -1, 1],
        ["idades", -1, 7],
        ["adores", -1, 1],
        ["antes", -1, 1],
        ["a\u{E7}o~es", -1, 1],
        ["u\u{E7}o~es", -1, 3],
        ["icos", -1, 1],
        ["ismos", -1, 1],
        ["osos", -1, 1],
        ["amentos", -1, 1],
        ["imentos", -1, 1],
        ["ivos", -1, 8]
    ];

    private const array A_6 = [
        ["ada", -1, 1],
        ["ida", -1, 1],
        ["ia", -1, 1],
        ["aria", 2, 1],
        ["eria", 2, 1],
        ["iria", 2, 1],
        ["ara", -1, 1],
        ["era", -1, 1],
        ["ira", -1, 1],
        ["ava", -1, 1],
        ["asse", -1, 1],
        ["esse", -1, 1],
        ["isse", -1, 1],
        ["aste", -1, 1],
        ["este", -1, 1],
        ["iste", -1, 1],
        ["ei", -1, 1],
        ["arei", 16, 1],
        ["erei", 16, 1],
        ["irei", 16, 1],
        ["am", -1, 1],
        ["iam", 20, 1],
        ["ariam", 21, 1],
        ["eriam", 21, 1],
        ["iriam", 21, 1],
        ["aram", 20, 1],
        ["eram", 20, 1],
        ["iram", 20, 1],
        ["avam", 20, 1],
        ["em", -1, 1],
        ["arem", 29, 1],
        ["erem", 29, 1],
        ["irem", 29, 1],
        ["assem", 29, 1],
        ["essem", 29, 1],
        ["issem", 29, 1],
        ["ado", -1, 1],
        ["ido", -1, 1],
        ["ando", -1, 1],
        ["endo", -1, 1],
        ["indo", -1, 1],
        ["ara~o", -1, 1],
        ["era~o", -1, 1],
        ["ira~o", -1, 1],
        ["ar", -1, 1],
        ["er", -1, 1],
        ["ir", -1, 1],
        ["as", -1, 1],
        ["adas", 47, 1],
        ["idas", 47, 1],
        ["ias", 47, 1],
        ["arias", 50, 1],
        ["erias", 50, 1],
        ["irias", 50, 1],
        ["aras", 47, 1],
        ["eras", 47, 1],
        ["iras", 47, 1],
        ["avas", 47, 1],
        ["es", -1, 1],
        ["ardes", 58, 1],
        ["erdes", 58, 1],
        ["irdes", 58, 1],
        ["ares", 58, 1],
        ["eres", 58, 1],
        ["ires", 58, 1],
        ["asses", 58, 1],
        ["esses", 58, 1],
        ["isses", 58, 1],
        ["astes", 58, 1],
        ["estes", 58, 1],
        ["istes", 58, 1],
        ["is", -1, 1],
        ["ais", 71, 1],
        ["eis", 71, 1],
        ["areis", 73, 1],
        ["ereis", 73, 1],
        ["ireis", 73, 1],
        ["\u{E1}reis", 73, 1],
        ["\u{E9}reis", 73, 1],
        ["\u{ED}reis", 73, 1],
        ["\u{E1}sseis", 73, 1],
        ["\u{E9}sseis", 73, 1],
        ["\u{ED}sseis", 73, 1],
        ["\u{E1}veis", 73, 1],
        ["\u{ED}eis", 73, 1],
        ["ar\u{ED}eis", 84, 1],
        ["er\u{ED}eis", 84, 1],
        ["ir\u{ED}eis", 84, 1],
        ["ados", -1, 1],
        ["idos", -1, 1],
        ["amos", -1, 1],
        ["\u{E1}ramos", 90, 1],
        ["\u{E9}ramos", 90, 1],
        ["\u{ED}ramos", 90, 1],
        ["\u{E1}vamos", 90, 1],
        ["\u{ED}amos", 90, 1],
        ["ar\u{ED}amos", 95, 1],
        ["er\u{ED}amos", 95, 1],
        ["ir\u{ED}amos", 95, 1],
        ["emos", -1, 1],
        ["aremos", 99, 1],
        ["eremos", 99, 1],
        ["iremos", 99, 1],
        ["\u{E1}ssemos", 99, 1],
        ["\u{EA}ssemos", 99, 1],
        ["\u{ED}ssemos", 99, 1],
        ["imos", -1, 1],
        ["armos", -1, 1],
        ["ermos", -1, 1],
        ["irmos", -1, 1],
        ["\u{E1}mos", -1, 1],
        ["ar\u{E1}s", -1, 1],
        ["er\u{E1}s", -1, 1],
        ["ir\u{E1}s", -1, 1],
        ["eu", -1, 1],
        ["iu", -1, 1],
        ["ou", -1, 1],
        ["ar\u{E1}", -1, 1],
        ["er\u{E1}", -1, 1],
        ["ir\u{E1}", -1, 1]
    ];

    private const array A_7 = [
        ["a", -1, 1],
        ["i", -1, 1],
        ["o", -1, 1],
        ["os", -1, 1],
        ["\u{E1}", -1, 1],
        ["\u{ED}", -1, 1],
        ["\u{F3}", -1, 1]
    ];

    private const array A_8 = [
        ["e", -1, 1],
        ["\u{E7}", -1, 2],
        ["\u{E9}", -1, 1],
        ["\u{EA}", -1, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "\u{E1}"=>true, "\u{E2}"=>true, "\u{E9}"=>true, "\u{EA}"=>true, "\u{ED}"=>true, "\u{F3}"=>true, "\u{F4}"=>true, "\u{FA}"=>true];



    public function stem(): bool
    {
        $v_1 = $this->cursor;
        while (true) {
            $v_2 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_0);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("a~");
                    break;
                case 2:
                    $this->slice_from("o~");
                    break;
                case 3:
                    if ($this->cursor >= $this->limit) {
                        goto lab1;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab1:
            $this->cursor = $v_2;
            break;
        }
    lab0:
        $this->cursor = $v_1;
        $I_pV = $this->limit;
        $I_p1 = $this->limit;
        $I_p2 = $this->limit;
        $v_3 = $this->cursor;
        $v_4 = $this->cursor;
        if (!($this->in_grouping(self::G_v))) {
            goto lab4;
        }
        $v_5 = $this->cursor;
        if (!($this->out_grouping(self::G_v))) {
            goto lab5;
        }
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab5;
        }
        $this->inc_cursor();
        goto lab6;
    lab5:
        $this->cursor = $v_5;
        if (!($this->in_grouping(self::G_v))) {
            goto lab4;
        }
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab4;
        }
        $this->inc_cursor();
    lab6:
        goto lab7;
    lab4:
        $this->cursor = $v_4;
        if (!($this->out_grouping(self::G_v))) {
            goto lab3;
        }
        $v_6 = $this->cursor;
        if (!($this->out_grouping(self::G_v))) {
            goto lab8;
        }
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab8;
        }
        $this->inc_cursor();
        goto lab9;
    lab8:
        $this->cursor = $v_6;
        if (!($this->in_grouping(self::G_v))) {
            goto lab3;
        }
        if ($this->cursor >= $this->limit) {
            goto lab3;
        }
        $this->inc_cursor();
    lab9:
    lab7:
        $I_pV = $this->cursor;
    lab3:
        $this->cursor = $v_3;
        $v_7 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab10;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab10;
        }
        $this->inc_cursor();
        $I_p1 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab10;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab10;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab10:
        $this->cursor = $v_7;
    lab2:
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_8 = $this->limit - $this->cursor;
        $v_9 = $this->limit - $this->cursor;
        $v_10 = $this->limit - $this->cursor;
        $v_11 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_5);
        if (0 === $among_var) {
            goto lab13;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p2 > $this->cursor) {
                    goto lab13;
                }
                $this->slice_del();
                break;
            case 2:
                if ($I_p2 > $this->cursor) {
                    goto lab13;
                }
                $this->slice_from("log");
                break;
            case 3:
                if ($I_p2 > $this->cursor) {
                    goto lab13;
                }
                $this->slice_from("u");
                break;
            case 4:
                if ($I_p2 > $this->cursor) {
                    goto lab13;
                }
                $this->slice_from("ente");
                break;
            case 5:
                if ($I_p1 > $this->cursor) {
                    goto lab13;
                }
                $this->slice_del();
                $v_12 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                $among_var = $this->find_among_b(self::A_2);
                if (0 === $among_var) {
                    $this->cursor = $this->limit - $v_12;
                    goto lab14;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_12;
                    goto lab14;
                }
                $this->slice_del();
                switch ($among_var) {
                    case 1:
                        $this->ket = $this->cursor;
                        if (!($this->eq_s_b("at"))) {
                            $this->cursor = $this->limit - $v_12;
                            goto lab14;
                        }
                        $this->bra = $this->cursor;
                        if ($I_p2 > $this->cursor) {
                            $this->cursor = $this->limit - $v_12;
                            goto lab14;
                        }
                        $this->slice_del();
                        break;
                }
            lab14:
                break;
            case 6:
                if ($I_p2 > $this->cursor) {
                    goto lab13;
                }
                $this->slice_del();
                $v_13 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if ($this->find_among_b(self::A_3) === 0) {
                    $this->cursor = $this->limit - $v_13;
                    goto lab15;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_13;
                    goto lab15;
                }
                $this->slice_del();
            lab15:
                break;
            case 7:
                if ($I_p2 > $this->cursor) {
                    goto lab13;
                }
                $this->slice_del();
                $v_14 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if ($this->find_among_b(self::A_4) === 0) {
                    $this->cursor = $this->limit - $v_14;
                    goto lab16;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_14;
                    goto lab16;
                }
                $this->slice_del();
            lab16:
                break;
            case 8:
                if ($I_p2 > $this->cursor) {
                    goto lab13;
                }
                $this->slice_del();
                $v_15 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("at"))) {
                    $this->cursor = $this->limit - $v_15;
                    goto lab17;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_15;
                    goto lab17;
                }
                $this->slice_del();
            lab17:
                break;
            case 9:
                if ($I_pV > $this->cursor) {
                    goto lab13;
                }
                if (!($this->eq_s_b("e"))) {
                    goto lab13;
                }
                $this->slice_from("ir");
                break;
        }
        goto lab18;
    lab13:
        $this->cursor = $this->limit - $v_11;
        if ($this->cursor < $I_pV) {
            goto lab12;
        }
        $v_16 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_6) === 0) {
            $this->limit_backward = $v_16;
            goto lab12;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->limit_backward = $v_16;
    lab18:
        $this->cursor = $this->limit - $v_10;
        $v_17 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("i"))) {
            goto lab19;
        }
        $this->bra = $this->cursor;
        $v_18 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("c"))) {
            goto lab19;
        }
        $this->cursor = $this->limit - $v_18;
        if ($I_pV > $this->cursor) {
            goto lab19;
        }
        $this->slice_del();
    lab19:
        $this->cursor = $this->limit - $v_17;
        goto lab20;
    lab12:
        $this->cursor = $this->limit - $v_9;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_7) === 0) {
            goto lab11;
        }
        $this->bra = $this->cursor;
        if ($I_pV > $this->cursor) {
            goto lab11;
        }
        $this->slice_del();
    lab20:
    lab11:
        $this->cursor = $this->limit - $v_8;
        $v_19 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_8);
        if (0 === $among_var) {
            goto lab21;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_pV > $this->cursor) {
                    goto lab21;
                }
                $this->slice_del();
                $this->ket = $this->cursor;
                $v_20 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("u"))) {
                    goto lab22;
                }
                $this->bra = $this->cursor;
                $v_21 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("g"))) {
                    goto lab22;
                }
                $this->cursor = $this->limit - $v_21;
                goto lab23;
            lab22:
                $this->cursor = $this->limit - $v_20;
                if (!($this->eq_s_b("i"))) {
                    goto lab21;
                }
                $this->bra = $this->cursor;
                $v_22 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("c"))) {
                    goto lab21;
                }
                $this->cursor = $this->limit - $v_22;
            lab23:
                if ($I_pV > $this->cursor) {
                    goto lab21;
                }
                $this->slice_del();
                break;
            case 2:
                $this->slice_from("c");
                break;
        }
    lab21:
        $this->cursor = $this->limit - $v_19;
        $this->cursor = $this->limit_backward;
        $v_23 = $this->cursor;
        while (true) {
            $v_24 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_1);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("\u{E3}");
                    break;
                case 2:
                    $this->slice_from("\u{F5}");
                    break;
                case 3:
                    if ($this->cursor >= $this->limit) {
                        goto lab25;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab25:
            $this->cursor = $v_24;
            break;
        }
    lab24:
        $this->cursor = $v_23;
        return true;
    }
}
