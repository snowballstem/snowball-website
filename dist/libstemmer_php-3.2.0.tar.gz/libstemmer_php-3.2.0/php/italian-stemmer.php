<?php
// Generated from italian.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballItalianStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["all'", -1, -1],
        ["d'", -1, -1],
        ["dall'", -1, -1],
        ["dell'", -1, -1],
        ["gl'", -1, -1],
        ["l'", -1, -1],
        ["m'", -1, -1],
        ["nell'", -1, -1],
        ["quell'", -1, -1],
        ["quest'", -1, -1],
        ["s'", -1, -1],
        ["sull'", -1, -1],
        ["t'", -1, -1],
        ["tutt'", -1, -1],
        ["un'", -1, -1],
        ["v'", -1, -1]
    ];

    private const array A_1 = [
        ["", -1, 7],
        ["qu", 0, 6],
        ["\u{E1}", 0, 1],
        ["\u{E9}", 0, 2],
        ["\u{ED}", 0, 3],
        ["\u{F3}", 0, 4],
        ["\u{FA}", 0, 5]
    ];

    private const array A_2 = [
        ["", -1, 3],
        ["I", 0, 1],
        ["U", 0, 2]
    ];

    private const array A_3 = [
        ["la", -1, -1],
        ["cela", 0, -1],
        ["gliela", 0, -1],
        ["mela", 0, -1],
        ["tela", 0, -1],
        ["vela", 0, -1],
        ["le", -1, -1],
        ["cele", 6, -1],
        ["gliele", 6, -1],
        ["mele", 6, -1],
        ["tele", 6, -1],
        ["vele", 6, -1],
        ["ne", -1, -1],
        ["cene", 12, -1],
        ["gliene", 12, -1],
        ["mene", 12, -1],
        ["sene", 12, -1],
        ["tene", 12, -1],
        ["vene", 12, -1],
        ["ci", -1, -1],
        ["li", -1, -1],
        ["celi", 20, -1],
        ["glieli", 20, -1],
        ["meli", 20, -1],
        ["teli", 20, -1],
        ["veli", 20, -1],
        ["gli", 20, -1],
        ["mi", -1, -1],
        ["si", -1, -1],
        ["ti", -1, -1],
        ["vi", -1, -1],
        ["lo", -1, -1],
        ["celo", 31, -1],
        ["glielo", 31, -1],
        ["melo", 31, -1],
        ["telo", 31, -1],
        ["velo", 31, -1]
    ];

    private const array A_4 = [
        ["ando", -1, 1],
        ["endo", -1, 1],
        ["ar", -1, 2],
        ["er", -1, 2],
        ["ir", -1, 2]
    ];

    private const array AS_4 = ["", "e"];

    private const array A_5 = [
        ["ic", -1, -1],
        ["abil", -1, -1],
        ["os", -1, -1],
        ["iv", -1, 1]
    ];

    private const array A_6 = [
        ["ic", -1, 1],
        ["abil", -1, 1],
        ["iv", -1, 1]
    ];

    private const array A_7 = [
        ["ica", -1, 1],
        ["logia", -1, 3],
        ["osa", -1, 1],
        ["ista", -1, 1],
        ["iva", -1, 9],
        ["anza", -1, 1],
        ["enza", -1, 5],
        ["ice", -1, 1],
        ["atrice", 7, 1],
        ["iche", -1, 1],
        ["logie", -1, 3],
        ["abile", -1, 1],
        ["ibile", -1, 1],
        ["usione", -1, 4],
        ["azione", -1, 2],
        ["uzione", -1, 4],
        ["atore", -1, 2],
        ["ose", -1, 1],
        ["ante", -1, 1],
        ["mente", -1, 1],
        ["amente", 19, 7],
        ["iste", -1, 1],
        ["ive", -1, 9],
        ["anze", -1, 1],
        ["enze", -1, 5],
        ["ici", -1, 1],
        ["atrici", 25, 1],
        ["ichi", -1, 1],
        ["abili", -1, 1],
        ["ibili", -1, 1],
        ["ismi", -1, 1],
        ["usioni", -1, 4],
        ["azioni", -1, 2],
        ["uzioni", -1, 4],
        ["atori", -1, 2],
        ["osi", -1, 1],
        ["anti", -1, 1],
        ["amenti", -1, 6],
        ["imenti", -1, 6],
        ["isti", -1, 1],
        ["ivi", -1, 9],
        ["ico", -1, 1],
        ["ismo", -1, 1],
        ["oso", -1, 1],
        ["amento", -1, 6],
        ["imento", -1, 6],
        ["ivo", -1, 9],
        ["it\u{E0}", -1, 8],
        ["ist\u{E0}", -1, 1],
        ["ist\u{E8}", -1, 1],
        ["ist\u{EC}", -1, 1]
    ];

    private const array A_8 = [
        ["isca", -1, 1],
        ["enda", -1, 1],
        ["ata", -1, 1],
        ["ita", -1, 1],
        ["uta", -1, 1],
        ["ava", -1, 1],
        ["eva", -1, 1],
        ["iva", -1, 1],
        ["erebbe", -1, 1],
        ["irebbe", -1, 1],
        ["isce", -1, 1],
        ["ende", -1, 1],
        ["are", -1, 1],
        ["ere", -1, 1],
        ["ire", -1, 1],
        ["asse", -1, 1],
        ["ate", -1, 1],
        ["avate", 16, 1],
        ["evate", 16, 1],
        ["ivate", 16, 1],
        ["ete", -1, 1],
        ["erete", 20, 1],
        ["irete", 20, 1],
        ["ite", -1, 1],
        ["ereste", -1, 1],
        ["ireste", -1, 1],
        ["ute", -1, 1],
        ["erai", -1, 1],
        ["irai", -1, 1],
        ["isci", -1, 1],
        ["endi", -1, 1],
        ["erei", -1, 1],
        ["irei", -1, 1],
        ["assi", -1, 1],
        ["ati", -1, 1],
        ["iti", -1, 1],
        ["eresti", -1, 1],
        ["iresti", -1, 1],
        ["uti", -1, 1],
        ["avi", -1, 1],
        ["evi", -1, 1],
        ["ivi", -1, 1],
        ["isco", -1, 1],
        ["ando", -1, 1],
        ["endo", -1, 1],
        ["Yamo", -1, 1],
        ["iamo", -1, 1],
        ["avamo", -1, 1],
        ["evamo", -1, 1],
        ["ivamo", -1, 1],
        ["eremo", -1, 1],
        ["iremo", -1, 1],
        ["assimo", -1, 1],
        ["ammo", -1, 1],
        ["emmo", -1, 1],
        ["eremmo", 54, 1],
        ["iremmo", 54, 1],
        ["immo", -1, 1],
        ["ano", -1, 1],
        ["iscano", 58, 1],
        ["avano", 58, 1],
        ["evano", 58, 1],
        ["ivano", 58, 1],
        ["eranno", -1, 1],
        ["iranno", -1, 1],
        ["ono", -1, 1],
        ["iscono", 65, 1],
        ["arono", 65, 1],
        ["erono", 65, 1],
        ["irono", 65, 1],
        ["erebbero", -1, 1],
        ["irebbero", -1, 1],
        ["assero", -1, 1],
        ["essero", -1, 1],
        ["issero", -1, 1],
        ["ato", -1, 1],
        ["ito", -1, 1],
        ["uto", -1, 1],
        ["avo", -1, 1],
        ["evo", -1, 1],
        ["ivo", -1, 1],
        ["ar", -1, 1],
        ["ir", -1, 1],
        ["er\u{E0}", -1, 1],
        ["ir\u{E0}", -1, 1],
        ["er\u{F2}", -1, 1],
        ["ir\u{F2}", -1, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "\u{E0}"=>true, "\u{E8}"=>true, "\u{EC}"=>true, "\u{F2}"=>true, "\u{F9}"=>true];

    private const array G_AEIO = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "\u{E0}"=>true, "\u{E8}"=>true, "\u{EC}"=>true, "\u{F2}"=>true];

    private const array G_CG = ["c"=>true, "g"=>true];



    public function stem(): bool
    {
        $v_1 = $this->cursor;
        $this->bra = $this->cursor;
        if ($this->find_among(self::A_0) === 0) {
            goto lab0;
        }
        $this->ket = $this->cursor;
        if ($this->cursor >= $this->limit) {
            goto lab0;
        }
        $this->slice_del();
    lab0:
        $this->cursor = $v_1;
        $v_2 = $this->cursor;
        $v_3 = $this->cursor;
        while (true) {
            $v_4 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_1);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("\u{E0}");
                    break;
                case 2:
                    $this->slice_from("\u{E8}");
                    break;
                case 3:
                    $this->slice_from("\u{EC}");
                    break;
                case 4:
                    $this->slice_from("\u{F2}");
                    break;
                case 5:
                    $this->slice_from("\u{F9}");
                    break;
                case 6:
                    $this->slice_from("qU");
                    break;
                case 7:
                    if ($this->cursor >= $this->limit) {
                        goto lab2;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab2:
            $this->cursor = $v_4;
            break;
        }
        $this->cursor = $v_3;
        while (true) {
            $v_5 = $this->cursor;
            while (true) {
                $v_6 = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab4;
                }
                $this->bra = $this->cursor;
                $v_7 = $this->cursor;
                if (!($this->eq_s("u"))) {
                    goto lab5;
                }
                $this->ket = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab5;
                }
                $this->slice_from("U");
                goto lab6;
            lab5:
                $this->cursor = $v_7;
                if (!($this->eq_s("i"))) {
                    goto lab4;
                }
                $this->ket = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab4;
                }
                $this->slice_from("I");
            lab6:
                $this->cursor = $v_6;
                break;
            lab4:
                $this->cursor = $v_6;
                if ($this->cursor >= $this->limit) {
                    goto lab3;
                }
                $this->inc_cursor();
            }
            continue;
        lab3:
            $this->cursor = $v_5;
            break;
        }
    lab1:
        $this->cursor = $v_2;
        $I_pV = $this->limit;
        $I_p1 = $this->limit;
        $I_p2 = $this->limit;
        $v_8 = $this->cursor;
        $v_9 = $this->cursor;
        if (!($this->in_grouping(self::G_v))) {
            goto lab9;
        }
        $v_10 = $this->cursor;
        if (!($this->out_grouping(self::G_v))) {
            goto lab10;
        }
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab10;
        }
        $this->inc_cursor();
        goto lab11;
    lab10:
        $this->cursor = $v_10;
        if (!($this->in_grouping(self::G_v))) {
            goto lab9;
        }
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab9;
        }
        $this->inc_cursor();
    lab11:
        goto lab12;
    lab9:
        $this->cursor = $v_9;
        if (!($this->eq_s("divan"))) {
            goto lab13;
        }
        goto lab12;
    lab13:
        $this->cursor = $v_9;
        if (!($this->out_grouping(self::G_v))) {
            goto lab8;
        }
        $v_11 = $this->cursor;
        if (!($this->out_grouping(self::G_v))) {
            goto lab14;
        }
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab14;
        }
        $this->inc_cursor();
        goto lab15;
    lab14:
        $this->cursor = $v_11;
        if (!($this->in_grouping(self::G_v))) {
            goto lab8;
        }
        if ($this->cursor >= $this->limit) {
            goto lab8;
        }
        $this->inc_cursor();
    lab15:
    lab12:
        $I_pV = $this->cursor;
    lab8:
        $this->cursor = $v_8;
        $v_12 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab16;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab16;
        }
        $this->inc_cursor();
        $I_p1 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab16;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab16;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab16:
        $this->cursor = $v_12;
    lab7:
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_13 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_3) === 0) {
            goto lab17;
        }
        $this->bra = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab17;
        }
        if ($I_pV > $this->cursor) {
            goto lab17;
        }
        $this->slice_from(self::AS_4[$among_var - 1]);
    lab17:
        $this->cursor = $this->limit - $v_13;
        $v_14 = $this->limit - $this->cursor;
        $v_15 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_7);
        if (0 === $among_var) {
            goto lab19;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p2 > $this->cursor) {
                    goto lab19;
                }
                $this->slice_del();
                break;
            case 2:
                if ($I_p2 > $this->cursor) {
                    goto lab19;
                }
                $this->slice_del();
                $v_16 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("ic"))) {
                    $this->cursor = $this->limit - $v_16;
                    goto lab20;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_16;
                    goto lab20;
                }
                $this->slice_del();
            lab20:
                break;
            case 3:
                if ($I_p2 > $this->cursor) {
                    goto lab19;
                }
                $this->slice_from("log");
                break;
            case 4:
                if ($I_p2 > $this->cursor) {
                    goto lab19;
                }
                $this->slice_from("u");
                break;
            case 5:
                if ($I_p2 > $this->cursor) {
                    goto lab19;
                }
                $this->slice_from("ente");
                break;
            case 6:
                if ($I_pV > $this->cursor) {
                    goto lab19;
                }
                $this->slice_del();
                break;
            case 7:
                if ($I_p1 > $this->cursor) {
                    goto lab19;
                }
                $this->slice_del();
                $v_17 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                $among_var = $this->find_among_b(self::A_5);
                if (0 === $among_var) {
                    $this->cursor = $this->limit - $v_17;
                    goto lab21;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_17;
                    goto lab21;
                }
                $this->slice_del();
                switch ($among_var) {
                    case 1:
                        $this->ket = $this->cursor;
                        if (!($this->eq_s_b("at"))) {
                            $this->cursor = $this->limit - $v_17;
                            goto lab21;
                        }
                        $this->bra = $this->cursor;
                        if ($I_p2 > $this->cursor) {
                            $this->cursor = $this->limit - $v_17;
                            goto lab21;
                        }
                        $this->slice_del();
                        break;
                }
            lab21:
                break;
            case 8:
                if ($I_p2 > $this->cursor) {
                    goto lab19;
                }
                $this->slice_del();
                $v_18 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if ($this->find_among_b(self::A_6) === 0) {
                    $this->cursor = $this->limit - $v_18;
                    goto lab22;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_18;
                    goto lab22;
                }
                $this->slice_del();
            lab22:
                break;
            case 9:
                if ($I_p2 > $this->cursor) {
                    goto lab19;
                }
                $this->slice_del();
                $v_19 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("at"))) {
                    $this->cursor = $this->limit - $v_19;
                    goto lab23;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_19;
                    goto lab23;
                }
                $this->slice_del();
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("ic"))) {
                    $this->cursor = $this->limit - $v_19;
                    goto lab23;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_19;
                    goto lab23;
                }
                $this->slice_del();
            lab23:
                break;
        }
        goto lab24;
    lab19:
        $this->cursor = $this->limit - $v_15;
        if ($this->cursor < $I_pV) {
            goto lab18;
        }
        $v_20 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_8) === 0) {
            $this->limit_backward = $v_20;
            goto lab18;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->limit_backward = $v_20;
    lab24:
    lab18:
        $this->cursor = $this->limit - $v_14;
        $v_21 = $this->limit - $this->cursor;
        $v_22 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->in_grouping_b(self::G_AEIO))) {
            $this->cursor = $this->limit - $v_22;
            goto lab26;
        }
        $this->bra = $this->cursor;
        if ($I_pV > $this->cursor) {
            $this->cursor = $this->limit - $v_22;
            goto lab26;
        }
        $this->slice_del();
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("i"))) {
            $this->cursor = $this->limit - $v_22;
            goto lab26;
        }
        $this->bra = $this->cursor;
        if ($I_pV > $this->cursor) {
            $this->cursor = $this->limit - $v_22;
            goto lab26;
        }
        $this->slice_del();
    lab26:
        $v_23 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("h"))) {
            $this->cursor = $this->limit - $v_23;
            goto lab27;
        }
        $this->bra = $this->cursor;
        if (!($this->in_grouping_b(self::G_CG))) {
            $this->cursor = $this->limit - $v_23;
            goto lab27;
        }
        if ($I_pV > $this->cursor) {
            $this->cursor = $this->limit - $v_23;
            goto lab27;
        }
        $this->slice_del();
    lab27:
    lab25:
        $this->cursor = $this->limit - $v_21;
        $this->cursor = $this->limit_backward;
        $v_24 = $this->cursor;
        while (true) {
            $v_25 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_2);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("i");
                    break;
                case 2:
                    $this->slice_from("u");
                    break;
                case 3:
                    if ($this->cursor >= $this->limit) {
                        goto lab29;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab29:
            $this->cursor = $v_25;
            break;
        }
    lab28:
        $this->cursor = $v_24;
        return true;
    }
}
