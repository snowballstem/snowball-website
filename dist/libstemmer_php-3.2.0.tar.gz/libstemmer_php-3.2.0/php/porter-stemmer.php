<?php
// Generated from porter.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballPorterStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["s", -1, 3],
        ["ies", 0, 2],
        ["sses", 0, 1],
        ["ss", 0, -1]
    ];

    private const array AS_0 = ["ss", "i", ""];

    private const array A_1 = [
        ["", -1, 3],
        ["bb", 0, 2],
        ["dd", 0, 2],
        ["ff", 0, 2],
        ["gg", 0, 2],
        ["bl", 0, 1],
        ["mm", 0, 2],
        ["nn", 0, 2],
        ["pp", 0, 2],
        ["rr", 0, 2],
        ["at", 0, 1],
        ["tt", 0, 2],
        ["iz", 0, 1]
    ];

    private const array A_2 = [
        ["ed", -1, 2],
        ["eed", 0, 1],
        ["ing", -1, 2]
    ];

    private const array A_3 = [
        ["anci", -1, 3],
        ["enci", -1, 2],
        ["abli", -1, 4],
        ["eli", -1, 6],
        ["alli", -1, 9],
        ["ousli", -1, 11],
        ["entli", -1, 5],
        ["aliti", -1, 9],
        ["biliti", -1, 13],
        ["iviti", -1, 12],
        ["tional", -1, 1],
        ["ational", 10, 8],
        ["alism", -1, 9],
        ["ation", -1, 8],
        ["ization", 13, 7],
        ["izer", -1, 7],
        ["ator", -1, 8],
        ["iveness", -1, 12],
        ["fulness", -1, 10],
        ["ousness", -1, 11]
    ];

    private const array AS_3 = ["tion", "ence", "ance", "able", "ent", "e", "ize", "ate", "al", "ful", "ous", "ive", "ble"];

    private const array A_4 = [
        ["icate", -1, 2],
        ["ative", -1, 3],
        ["alize", -1, 1],
        ["iciti", -1, 2],
        ["ical", -1, 2],
        ["ful", -1, 3],
        ["ness", -1, 3]
    ];

    private const array AS_4 = ["al", "ic", ""];

    private const array A_5 = [
        ["ic", -1, 1],
        ["ance", -1, 1],
        ["ence", -1, 1],
        ["able", -1, 1],
        ["ible", -1, 1],
        ["ate", -1, 1],
        ["ive", -1, 1],
        ["ize", -1, 1],
        ["iti", -1, 1],
        ["al", -1, 1],
        ["ism", -1, 1],
        ["ion", -1, 2],
        ["er", -1, 1],
        ["ous", -1, 1],
        ["ant", -1, 1],
        ["ent", -1, 1],
        ["ment", 15, 1],
        ["ement", 16, 1],
        ["ou", -1, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true];

    private const array G_v_WXY = ["Y"=>true, "a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "w"=>true, "x"=>true, "y"=>true];



    protected function r_shortv(): bool
    {
        if (!($this->out_grouping_b(self::G_v_WXY))) {
            return false;
        }
        if (!($this->in_grouping_b(self::G_v))) {
            return false;
        }
        return $this->out_grouping_b(self::G_v);
    }


    public function stem(): bool
    {
        $B_Y_found = false;
        $v_1 = $this->cursor;
        $this->bra = $this->cursor;
        if (!($this->eq_s("y"))) {
            goto lab0;
        }
        $this->ket = $this->cursor;
        $this->slice_from("Y");
        $B_Y_found = true;
    lab0:
        $this->cursor = $v_1;
        $v_2 = $this->cursor;
        while (true) {
            $v_3 = $this->cursor;
            while (true) {
                $v_4 = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab3;
                }
                $this->bra = $this->cursor;
                if (!($this->eq_s("y"))) {
                    goto lab3;
                }
                $this->ket = $this->cursor;
                $this->cursor = $v_4;
                break;
            lab3:
                $this->cursor = $v_4;
                if ($this->cursor >= $this->limit) {
                    goto lab2;
                }
                $this->inc_cursor();
            }
            $this->slice_from("Y");
            $B_Y_found = true;
            continue;
        lab2:
            $this->cursor = $v_3;
            break;
        }
    lab1:
        $this->cursor = $v_2;
        $I_p1 = $this->limit;
        $I_p2 = $this->limit;
        $v_5 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab4;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab4;
        }
        $this->inc_cursor();
        $I_p1 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab4;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab4;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab4:
        $this->cursor = $v_5;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_6 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_0);
        if (0 === $among_var) {
            goto lab5;
        }
        $this->bra = $this->cursor;
        if ($among_var > 0) {
            $this->slice_from(self::AS_0[$among_var - 1]);
        }
    lab5:
        $this->cursor = $this->limit - $v_6;
        $v_7 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            goto lab6;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p1 > $this->cursor) {
                    goto lab6;
                }
                $this->slice_from("ee");
                break;
            case 2:
                $v_8 = $this->limit - $this->cursor;
                if (!$this->go_out_grouping_b(self::G_v)) {
                    goto lab6;
                }
                $this->dec_cursor();
                $this->cursor = $this->limit - $v_8;
                $this->slice_del();
                $v_9 = $this->limit - $this->cursor;
                $among_var = $this->find_among_b(self::A_1);
                $this->cursor = $this->limit - $v_9;
                switch ($among_var) {
                    case 1:
                        $c = $this->cursor;
                        $this->insert($c, $c, "e");
                        $this->cursor = $c;
                        break;
                    case 2:
                        $this->ket = $this->cursor;
                        if ($this->cursor <= $this->limit_backward) {
                            goto lab6;
                        }
                        $this->dec_cursor();
                        $this->bra = $this->cursor;
                        $this->slice_del();
                        break;
                    case 3:
                        if ($this->cursor !== $I_p1) {
                            goto lab6;
                        }
                        $v_10 = $this->limit - $this->cursor;
                        if (!$this->r_shortv()) {
                            goto lab6;
                        }
                        $this->cursor = $this->limit - $v_10;
                        $c = $this->cursor;
                        $this->insert($c, $c, "e");
                        $this->cursor = $c;
                        break;
                }
                break;
        }
    lab6:
        $this->cursor = $this->limit - $v_7;
        $v_11 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("y"))) {
            goto lab8;
        }
        goto lab9;
    lab8:
        if (!($this->eq_s_b("Y"))) {
            goto lab7;
        }
    lab9:
        $this->bra = $this->cursor;
        if (!$this->go_out_grouping_b(self::G_v)) {
            goto lab7;
        }
        $this->dec_cursor();
        $this->slice_from("i");
    lab7:
        $this->cursor = $this->limit - $v_11;
        $v_12 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_3);
        if (0 === $among_var) {
            goto lab10;
        }
        $this->bra = $this->cursor;
        if ($I_p1 > $this->cursor) {
            goto lab10;
        }
        $this->slice_from(self::AS_3[$among_var - 1]);
    lab10:
        $this->cursor = $this->limit - $v_12;
        $v_13 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab11;
        }
        $this->bra = $this->cursor;
        if ($I_p1 > $this->cursor) {
            goto lab11;
        }
        $this->slice_from(self::AS_4[$among_var - 1]);
    lab11:
        $this->cursor = $this->limit - $v_13;
        $v_14 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_5);
        if (0 === $among_var) {
            goto lab12;
        }
        $this->bra = $this->cursor;
        if ($I_p2 > $this->cursor) {
            goto lab12;
        }
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                if (!($this->eq_s_b("s"))) {
                    goto lab13;
                }
                goto lab14;
            lab13:
                if (!($this->eq_s_b("t"))) {
                    goto lab12;
                }
            lab14:
                $this->slice_del();
                break;
        }
    lab12:
        $this->cursor = $this->limit - $v_14;
        $v_15 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("e"))) {
            goto lab15;
        }
        $this->bra = $this->cursor;
        if ($I_p2 > $this->cursor) {
            goto lab16;
        }
        goto lab17;
    lab16:
        if ($I_p1 > $this->cursor) {
            goto lab15;
        }
        $v_16 = $this->limit - $this->cursor;
        if (!$this->r_shortv()) {
            goto lab18;
        }
        goto lab15;
    lab18:
        $this->cursor = $this->limit - $v_16;
    lab17:
        $this->slice_del();
    lab15:
        $this->cursor = $this->limit - $v_15;
        $v_17 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("l"))) {
            goto lab19;
        }
        $this->bra = $this->cursor;
        if ($I_p2 > $this->cursor) {
            goto lab19;
        }
        if (!($this->eq_s_b("l"))) {
            goto lab19;
        }
        $this->slice_del();
    lab19:
        $this->cursor = $this->limit - $v_17;
        $this->cursor = $this->limit_backward;
        $v_18 = $this->cursor;
        if (!$B_Y_found) {
            goto lab20;
        }
        while (true) {
            $v_19 = $this->cursor;
            while (true) {
                $v_20 = $this->cursor;
                $this->bra = $this->cursor;
                if (!($this->eq_s("Y"))) {
                    goto lab22;
                }
                $this->ket = $this->cursor;
                $this->cursor = $v_20;
                break;
            lab22:
                $this->cursor = $v_20;
                if ($this->cursor >= $this->limit) {
                    goto lab21;
                }
                $this->inc_cursor();
            }
            $this->slice_from("y");
            continue;
        lab21:
            $this->cursor = $v_19;
            break;
        }
    lab20:
        $this->cursor = $v_18;
        return true;
    }
}
