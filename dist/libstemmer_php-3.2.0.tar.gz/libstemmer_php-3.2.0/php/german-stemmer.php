<?php
// Generated from german.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballGermanStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["", -1, 5],
        ["ae", 0, 2],
        ["oe", 0, 3],
        ["qu", 0, -1],
        ["ue", 0, 4],
        ["\u{DF}", 0, 1]
    ];

    private const array A_1 = [
        ["", -1, 5],
        ["U", 0, 2],
        ["Y", 0, 1],
        ["\u{E4}", 0, 3],
        ["\u{F6}", 0, 4],
        ["\u{FC}", 0, 2]
    ];

    private const array A_2 = [
        ["e", -1, 3],
        ["em", -1, 1],
        ["en", -1, 3],
        ["erinnen", 2, 2],
        ["erin", -1, 2],
        ["ln", -1, 5],
        ["ern", -1, 2],
        ["er", -1, 2],
        ["s", -1, 4],
        ["es", 8, 3],
        ["lns", 8, 5]
    ];

    private const array A_3 = [
        ["tick", -1, -1],
        ["plan", -1, -1],
        ["geordn", -1, -1],
        ["intern", -1, -1],
        ["tr", -1, -1]
    ];

    private const array A_4 = [
        ["en", -1, 1],
        ["er", -1, 1],
        ["et", -1, 3],
        ["st", -1, 2],
        ["est", 3, 1]
    ];

    private const array A_5 = [
        ["ig", -1, 1],
        ["lich", -1, 1]
    ];

    private const array A_6 = [
        ["end", -1, 1],
        ["ig", -1, 2],
        ["ung", -1, 1],
        ["lich", -1, 3],
        ["isch", -1, 2],
        ["ik", -1, 2],
        ["heit", -1, 3],
        ["keit", -1, 4]
    ];

    private const array A_7 = [
        ["'", -1, 1],
        ["'sch", -1, 1],
        ["'s", -1, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{E4}"=>true, "\u{F6}"=>true, "\u{FC}"=>true];

    private const array G_et_ending = ["U"=>true, "d"=>true, "f"=>true, "g"=>true, "k"=>true, "l"=>true, "m"=>true, "n"=>true, "r"=>true, "s"=>true, "t"=>true, "z"=>true, "\u{E4}"=>true];

    private const array G_s_ending = ["b"=>true, "d"=>true, "f"=>true, "g"=>true, "h"=>true, "k"=>true, "l"=>true, "m"=>true, "n"=>true, "r"=>true, "t"=>true];

    private const array G_st_ending = ["b"=>true, "d"=>true, "f"=>true, "g"=>true, "h"=>true, "k"=>true, "l"=>true, "m"=>true, "n"=>true, "t"=>true];



    public function stem(): bool
    {
        $v_1 = $this->cursor;
        $v_2 = $this->cursor;
        while (true) {
            $v_3 = $this->cursor;
            while (true) {
                $v_4 = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab2;
                }
                $this->bra = $this->cursor;
                $v_5 = $this->cursor;
                if (!($this->eq_s("u"))) {
                    goto lab3;
                }
                $this->ket = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab3;
                }
                $this->slice_from("U");
                goto lab4;
            lab3:
                $this->cursor = $v_5;
                if (!($this->eq_s("y"))) {
                    goto lab2;
                }
                $this->ket = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab2;
                }
                $this->slice_from("Y");
            lab4:
                $this->cursor = $v_4;
                break;
            lab2:
                $this->cursor = $v_4;
                if ($this->cursor >= $this->limit) {
                    goto lab1;
                }
                $this->inc_cursor();
            }
            continue;
        lab1:
            $this->cursor = $v_3;
            break;
        }
        $this->cursor = $v_2;
        while (true) {
            $v_6 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_0);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("ss");
                    break;
                case 2:
                    $this->slice_from("\u{E4}");
                    break;
                case 3:
                    $this->slice_from("\u{F6}");
                    break;
                case 4:
                    $this->slice_from("\u{FC}");
                    break;
                case 5:
                    if ($this->cursor >= $this->limit) {
                        goto lab5;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab5:
            $this->cursor = $v_6;
            break;
        }
    lab0:
        $this->cursor = $v_1;
        $v_7 = $this->cursor;
        $I_p1 = $this->limit;
        $I_p2 = $this->limit;
        $v_8 = $this->cursor;
        if (!$this->hop(3)) {
            goto lab6;
        }
        $I_x = $this->cursor;
        $this->cursor = $v_8;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab6;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab6;
        }
        $this->inc_cursor();
        $I_p1 = $this->cursor;
        if ($I_p1 >= $I_x) {
            goto lab7;
        }
        $I_p1 = $I_x;
    lab7:
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab6;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab6;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab6:
        $this->cursor = $v_7;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_9 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            goto lab9;
        }
        $this->bra = $this->cursor;
        if ($I_p1 > $this->cursor) {
            goto lab9;
        }
        switch ($among_var) {
            case 1:
                if (!($this->eq_s_b("syst"))) {
                    goto lab10;
                }
                goto lab9;
            lab10:
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                break;
            case 3:
                $this->slice_del();
                $v_10 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("s"))) {
                    $this->cursor = $this->limit - $v_10;
                    goto lab11;
                }
                $this->bra = $this->cursor;
                if (!($this->eq_s_b("nis"))) {
                    $this->cursor = $this->limit - $v_10;
                    goto lab11;
                }
                $this->slice_del();
            lab11:
                break;
            case 4:
                if (!($this->in_grouping_b(self::G_s_ending))) {
                    goto lab9;
                }
                $this->slice_del();
                break;
            case 5:
                $this->slice_from("l");
                break;
        }
    lab9:
        $this->cursor = $this->limit - $v_9;
        $v_11 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab12;
        }
        $this->bra = $this->cursor;
        if ($I_p1 > $this->cursor) {
            goto lab12;
        }
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                if (!($this->in_grouping_b(self::G_st_ending))) {
                    goto lab12;
                }
                if (!$this->hop_back(3)) {
                    goto lab12;
                }
                $this->slice_del();
                break;
            case 3:
                $v_12 = $this->limit - $this->cursor;
                if (!($this->in_grouping_b(self::G_et_ending))) {
                    goto lab12;
                }
                $this->cursor = $this->limit - $v_12;
                $v_13 = $this->limit - $this->cursor;
                if ($this->find_among_b(self::A_3) === 0) {
                    goto lab13;
                }
                goto lab12;
            lab13:
                $this->cursor = $this->limit - $v_13;
                $this->slice_del();
                break;
        }
    lab12:
        $this->cursor = $this->limit - $v_11;
        $v_14 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_6);
        if (0 === $among_var) {
            goto lab14;
        }
        $this->bra = $this->cursor;
        if ($I_p2 > $this->cursor) {
            goto lab14;
        }
        switch ($among_var) {
            case 1:
                $this->slice_del();
                $v_15 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("ig"))) {
                    $this->cursor = $this->limit - $v_15;
                    goto lab15;
                }
                $this->bra = $this->cursor;
                if (!($this->eq_s_b("e"))) {
                    goto lab16;
                }
                $this->cursor = $this->limit - $v_15;
                goto lab15;
            lab16:
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_15;
                    goto lab15;
                }
                $this->slice_del();
            lab15:
                break;
            case 2:
                if (!($this->eq_s_b("e"))) {
                    goto lab17;
                }
                goto lab14;
            lab17:
                $this->slice_del();
                break;
            case 3:
                $this->slice_del();
                $v_16 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("er"))) {
                    goto lab19;
                }
                goto lab20;
            lab19:
                if (!($this->eq_s_b("en"))) {
                    $this->cursor = $this->limit - $v_16;
                    goto lab18;
                }
            lab20:
                $this->bra = $this->cursor;
                if ($I_p1 > $this->cursor) {
                    $this->cursor = $this->limit - $v_16;
                    goto lab18;
                }
                $this->slice_del();
            lab18:
                break;
            case 4:
                $this->slice_del();
                $v_17 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if ($this->find_among_b(self::A_5) === 0) {
                    $this->cursor = $this->limit - $v_17;
                    goto lab21;
                }
                $this->bra = $this->cursor;
                if ($I_p2 > $this->cursor) {
                    $this->cursor = $this->limit - $v_17;
                    goto lab21;
                }
                $this->slice_del();
            lab21:
                break;
        }
    lab14:
        $this->cursor = $this->limit - $v_14;
        $v_18 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_7) === 0) {
            goto lab22;
        }
        $this->bra = $this->cursor;
        if ($this->cursor <= $this->limit_backward) {
            goto lab22;
        }
        $this->dec_cursor();
        if ($this->cursor <= $this->limit_backward) {
            goto lab22;
        }
        $this->slice_del();
    lab22:
        $this->cursor = $this->limit - $v_18;
    lab8:
        $this->cursor = $this->limit_backward;
        $v_19 = $this->cursor;
        while (true) {
            $v_20 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_1);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("y");
                    break;
                case 2:
                    $this->slice_from("u");
                    break;
                case 3:
                    $this->slice_from("a");
                    break;
                case 4:
                    $this->slice_from("o");
                    break;
                case 5:
                    if ($this->cursor >= $this->limit) {
                        goto lab24;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab24:
            $this->cursor = $v_20;
            break;
        }
    lab23:
        $this->cursor = $v_19;
        return true;
    }
}
