<?php
// Generated from arabic.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballArabicStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["\u{640}", -1, 1],
        ["\u{64B}", -1, 1],
        ["\u{64C}", -1, 1],
        ["\u{64D}", -1, 1],
        ["\u{64E}", -1, 1],
        ["\u{64F}", -1, 1],
        ["\u{650}", -1, 1],
        ["\u{651}", -1, 1],
        ["\u{652}", -1, 1],
        ["\u{660}", -1, 2],
        ["\u{661}", -1, 3],
        ["\u{662}", -1, 4],
        ["\u{663}", -1, 5],
        ["\u{664}", -1, 6],
        ["\u{665}", -1, 7],
        ["\u{666}", -1, 8],
        ["\u{667}", -1, 9],
        ["\u{668}", -1, 10],
        ["\u{669}", -1, 11],
        ["\u{FE80}", -1, 12],
        ["\u{FE81}", -1, 16],
        ["\u{FE82}", -1, 16],
        ["\u{FE83}", -1, 13],
        ["\u{FE84}", -1, 13],
        ["\u{FE85}", -1, 17],
        ["\u{FE86}", -1, 17],
        ["\u{FE87}", -1, 14],
        ["\u{FE88}", -1, 14],
        ["\u{FE89}", -1, 15],
        ["\u{FE8A}", -1, 15],
        ["\u{FE8B}", -1, 15],
        ["\u{FE8C}", -1, 15],
        ["\u{FE8D}", -1, 18],
        ["\u{FE8E}", -1, 18],
        ["\u{FE8F}", -1, 19],
        ["\u{FE90}", -1, 19],
        ["\u{FE91}", -1, 19],
        ["\u{FE92}", -1, 19],
        ["\u{FE93}", -1, 20],
        ["\u{FE94}", -1, 20],
        ["\u{FE95}", -1, 21],
        ["\u{FE96}", -1, 21],
        ["\u{FE97}", -1, 21],
        ["\u{FE98}", -1, 21],
        ["\u{FE99}", -1, 22],
        ["\u{FE9A}", -1, 22],
        ["\u{FE9B}", -1, 22],
        ["\u{FE9C}", -1, 22],
        ["\u{FE9D}", -1, 23],
        ["\u{FE9E}", -1, 23],
        ["\u{FE9F}", -1, 23],
        ["\u{FEA0}", -1, 23],
        ["\u{FEA1}", -1, 24],
        ["\u{FEA2}", -1, 24],
        ["\u{FEA3}", -1, 24],
        ["\u{FEA4}", -1, 24],
        ["\u{FEA5}", -1, 25],
        ["\u{FEA6}", -1, 25],
        ["\u{FEA7}", -1, 25],
        ["\u{FEA8}", -1, 25],
        ["\u{FEA9}", -1, 26],
        ["\u{FEAA}", -1, 26],
        ["\u{FEAB}", -1, 27],
        ["\u{FEAC}", -1, 27],
        ["\u{FEAD}", -1, 28],
        ["\u{FEAE}", -1, 28],
        ["\u{FEAF}", -1, 29],
        ["\u{FEB0}", -1, 29],
        ["\u{FEB1}", -1, 30],
        ["\u{FEB2}", -1, 30],
        ["\u{FEB3}", -1, 30],
        ["\u{FEB4}", -1, 30],
        ["\u{FEB5}", -1, 31],
        ["\u{FEB6}", -1, 31],
        ["\u{FEB7}", -1, 31],
        ["\u{FEB8}", -1, 31],
        ["\u{FEB9}", -1, 32],
        ["\u{FEBA}", -1, 32],
        ["\u{FEBB}", -1, 32],
        ["\u{FEBC}", -1, 32],
        ["\u{FEBD}", -1, 33],
        ["\u{FEBE}", -1, 33],
        ["\u{FEBF}", -1, 33],
        ["\u{FEC0}", -1, 33],
        ["\u{FEC1}", -1, 34],
        ["\u{FEC2}", -1, 34],
        ["\u{FEC3}", -1, 34],
        ["\u{FEC4}", -1, 34],
        ["\u{FEC5}", -1, 35],
        ["\u{FEC6}", -1, 35],
        ["\u{FEC7}", -1, 35],
        ["\u{FEC8}", -1, 35],
        ["\u{FEC9}", -1, 36],
        ["\u{FECA}", -1, 36],
        ["\u{FECB}", -1, 36],
        ["\u{FECC}", -1, 36],
        ["\u{FECD}", -1, 37],
        ["\u{FECE}", -1, 37],
        ["\u{FECF}", -1, 37],
        ["\u{FED0}", -1, 37],
        ["\u{FED1}", -1, 38],
        ["\u{FED2}", -1, 38],
        ["\u{FED3}", -1, 38],
        ["\u{FED4}", -1, 38],
        ["\u{FED5}", -1, 39],
        ["\u{FED6}", -1, 39],
        ["\u{FED7}", -1, 39],
        ["\u{FED8}", -1, 39],
        ["\u{FED9}", -1, 40],
        ["\u{FEDA}", -1, 40],
        ["\u{FEDB}", -1, 40],
        ["\u{FEDC}", -1, 40],
        ["\u{FEDD}", -1, 41],
        ["\u{FEDE}", -1, 41],
        ["\u{FEDF}", -1, 41],
        ["\u{FEE0}", -1, 41],
        ["\u{FEE1}", -1, 42],
        ["\u{FEE2}", -1, 42],
        ["\u{FEE3}", -1, 42],
        ["\u{FEE4}", -1, 42],
        ["\u{FEE5}", -1, 43],
        ["\u{FEE6}", -1, 43],
        ["\u{FEE7}", -1, 43],
        ["\u{FEE8}", -1, 43],
        ["\u{FEE9}", -1, 44],
        ["\u{FEEA}", -1, 44],
        ["\u{FEEB}", -1, 44],
        ["\u{FEEC}", -1, 44],
        ["\u{FEED}", -1, 45],
        ["\u{FEEE}", -1, 45],
        ["\u{FEEF}", -1, 46],
        ["\u{FEF0}", -1, 46],
        ["\u{FEF1}", -1, 47],
        ["\u{FEF2}", -1, 47],
        ["\u{FEF3}", -1, 47],
        ["\u{FEF4}", -1, 47],
        ["\u{FEF5}", -1, 51],
        ["\u{FEF6}", -1, 51],
        ["\u{FEF7}", -1, 49],
        ["\u{FEF8}", -1, 49],
        ["\u{FEF9}", -1, 50],
        ["\u{FEFA}", -1, 50],
        ["\u{FEFB}", -1, 48],
        ["\u{FEFC}", -1, 48]
    ];

    private const array AS_0 = ["", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "\u{621}", "\u{623}", "\u{625}", "\u{626}", "\u{622}", "\u{624}", "\u{627}", "\u{628}", "\u{629}", "\u{62A}", "\u{62B}", "\u{62C}", "\u{62D}", "\u{62E}", "\u{62F}", "\u{630}", "\u{631}", "\u{632}", "\u{633}", "\u{634}", "\u{635}", "\u{636}", "\u{637}", "\u{638}", "\u{639}", "\u{63A}", "\u{641}", "\u{642}", "\u{643}", "\u{644}", "\u{645}", "\u{646}", "\u{647}", "\u{648}", "\u{649}", "\u{64A}", "\u{644}\u{627}", "\u{644}\u{623}", "\u{644}\u{625}", "\u{644}\u{622}"];

    private const array A_1 = [
        ["\u{622}", -1, 1],
        ["\u{623}", -1, 1],
        ["\u{624}", -1, 1],
        ["\u{625}", -1, 1],
        ["\u{626}", -1, 1]
    ];

    private const array A_2 = [
        ["\u{622}", -1, 1],
        ["\u{623}", -1, 1],
        ["\u{624}", -1, 2],
        ["\u{625}", -1, 1],
        ["\u{626}", -1, 3]
    ];

    private const array AS_2 = ["\u{627}", "\u{648}", "\u{64A}"];

    private const array A_3 = [
        ["\u{627}\u{644}", -1, 2],
        ["\u{628}\u{627}\u{644}", -1, 1],
        ["\u{643}\u{627}\u{644}", -1, 1],
        ["\u{644}\u{644}", -1, 2]
    ];

    private const array A_4 = [
        ["\u{623}\u{622}", -1, 2],
        ["\u{623}\u{623}", -1, 1],
        ["\u{623}\u{624}", -1, 1],
        ["\u{623}\u{625}", -1, 4],
        ["\u{623}\u{627}", -1, 3]
    ];

    private const array A_5 = [
        ["\u{641}", -1, 1],
        ["\u{648}", -1, 1]
    ];

    private const array A_6 = [
        ["\u{627}\u{644}", -1, 2],
        ["\u{628}\u{627}\u{644}", -1, 1],
        ["\u{643}\u{627}\u{644}", -1, 1],
        ["\u{644}\u{644}", -1, 2]
    ];

    private const array A_7 = [
        ["\u{628}", -1, 1],
        ["\u{628}\u{627}", 0, -1],
        ["\u{628}\u{628}", 0, 2],
        ["\u{643}\u{643}", -1, 3]
    ];

    private const array A_8 = [
        ["\u{633}\u{623}", -1, 4],
        ["\u{633}\u{62A}", -1, 2],
        ["\u{633}\u{646}", -1, 3],
        ["\u{633}\u{64A}", -1, 1]
    ];

    private const array A_9 = [
        ["\u{62A}\u{633}\u{62A}", -1, 1],
        ["\u{646}\u{633}\u{62A}", -1, 1],
        ["\u{64A}\u{633}\u{62A}", -1, 1]
    ];

    private const array A_10 = [
        ["\u{643}", -1, 1],
        ["\u{643}\u{645}", -1, 2],
        ["\u{647}\u{645}", -1, 2],
        ["\u{647}\u{646}", -1, 2],
        ["\u{647}", -1, 1],
        ["\u{64A}", -1, 1],
        ["\u{643}\u{645}\u{627}", -1, 3],
        ["\u{647}\u{645}\u{627}", -1, 3],
        ["\u{646}\u{627}", -1, 2],
        ["\u{647}\u{627}", -1, 2]
    ];

    private const array A_11 = [
        ["\u{648}", -1, 1],
        ["\u{64A}", -1, 1],
        ["\u{627}", -1, 1]
    ];

    private const array A_12 = [
        ["\u{643}", -1, 1],
        ["\u{643}\u{645}", -1, 2],
        ["\u{647}\u{645}", -1, 2],
        ["\u{643}\u{646}", -1, 2],
        ["\u{647}\u{646}", -1, 2],
        ["\u{647}", -1, 1],
        ["\u{643}\u{645}\u{648}", -1, 3],
        ["\u{646}\u{64A}", -1, 2],
        ["\u{643}\u{645}\u{627}", -1, 3],
        ["\u{647}\u{645}\u{627}", -1, 3],
        ["\u{646}\u{627}", -1, 2],
        ["\u{647}\u{627}", -1, 2]
    ];

    private const array A_13 = [
        ["\u{646}", -1, 1],
        ["\u{648}\u{646}", 0, 3],
        ["\u{64A}\u{646}", 0, 3],
        ["\u{627}\u{646}", 0, 3],
        ["\u{62A}\u{646}", 0, 2],
        ["\u{64A}", -1, 1],
        ["\u{627}", -1, 1],
        ["\u{62A}\u{645}\u{627}", 6, 3],
        ["\u{646}\u{627}", 6, 2],
        ["\u{62A}\u{627}", 6, 2],
        ["\u{62A}", -1, 1]
    ];

    private const array A_14 = [
        ["\u{62A}\u{645}", -1, 1],
        ["\u{648}\u{627}", -1, 1]
    ];

    private const array A_15 = [
        ["\u{648}", -1, 1],
        ["\u{62A}\u{645}\u{648}", 0, 2]
    ];



    protected function r_Suffix_Noun_Step2a(): bool
    {
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_11) === 0) {
            return false;
        }
        $this->bra = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 5) {
            return false;
        }
        $this->slice_del();
        return true;
    }


    protected function r_Suffix_Noun_Step2b(): bool
    {
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{627}\u{62A}"))) {
            return false;
        }
        $this->bra = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 5) {
            return false;
        }
        $this->slice_del();
        return true;
    }


    protected function r_Suffix_Noun_Step2c1(): bool
    {
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{62A}"))) {
            return false;
        }
        $this->bra = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 4) {
            return false;
        }
        $this->slice_del();
        return true;
    }


    protected function r_Suffix_Verb_Step2a(): bool
    {
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_13);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    return false;
                }
                $this->slice_del();
                break;
            case 2:
                if (mb_strlen($this->current, 'UTF-8') < 5) {
                    return false;
                }
                $this->slice_del();
                break;
            case 3:
                if (mb_strlen($this->current, 'UTF-8') < 6) {
                    return false;
                }
                $this->slice_del();
                break;
        }
        return true;
    }


    public function stem(): bool
    {
        $B_is_noun = true;
        $B_is_verb = true;
        $B_is_defined = false;
        $v_1 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_3);
        if (0 === $among_var) {
            goto lab0;
        }
        $this->ket = $this->cursor;
        switch ($among_var) {
            case 1:
                if (mb_strlen($this->current, 'UTF-8') < 5) {
                    goto lab0;
                }
                $B_is_noun = true;
                $B_is_verb = false;
                $B_is_defined = true;
                break;
            case 2:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    goto lab0;
                }
                $B_is_noun = true;
                $B_is_verb = false;
                $B_is_defined = true;
                break;
        }
    lab0:
        $this->cursor = $v_1;
        $v_2 = $this->cursor;
        while (true) {
            $v_3 = $this->cursor;
            $v_4 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_0);
            if (0 === $among_var) {
                goto lab4;
            }
            $this->ket = $this->cursor;
            $this->slice_from(self::AS_0[$among_var - 1]);
            goto lab5;
        lab4:
            $this->cursor = $v_4;
            if ($this->cursor >= $this->limit) {
                goto lab3;
            }
            $this->inc_cursor();
        lab5:
            continue;
        lab3:
            $this->cursor = $v_3;
            break;
        }
    lab2:
        $this->cursor = $v_2;
    lab1:
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_5 = $this->limit - $this->cursor;
        $v_6 = $this->limit - $this->cursor;
        if (!$B_is_verb) {
            goto lab7;
        }
        $v_7 = $this->limit - $this->cursor;
        $v_8 = 1;
        while (true) {
            $v_9 = $this->limit - $this->cursor;
            $this->ket = $this->cursor;
            $among_var = $this->find_among_b(self::A_12);
            if (0 === $among_var) {
                goto lab9;
            }
            $this->bra = $this->cursor;
            switch ($among_var) {
                case 1:
                    if (mb_strlen($this->current, 'UTF-8') < 4) {
                        goto lab9;
                    }
                    $this->slice_del();
                    break;
                case 2:
                    if (mb_strlen($this->current, 'UTF-8') < 5) {
                        goto lab9;
                    }
                    $this->slice_del();
                    break;
                case 3:
                    if (mb_strlen($this->current, 'UTF-8') < 6) {
                        goto lab9;
                    }
                    $this->slice_del();
                    break;
            }
            $v_8--;
            continue;
        lab9:
            $this->cursor = $this->limit - $v_9;
            break;
        }
        if ($v_8 > 0) {
            goto lab8;
        }
        $v_10 = $this->limit - $this->cursor;
        if (!$this->r_Suffix_Verb_Step2a()) {
            goto lab10;
        }
        goto lab11;
    lab10:
        $this->cursor = $this->limit - $v_10;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_15);
        if (0 === $among_var) {
            goto lab12;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    goto lab12;
                }
                $this->slice_del();
                break;
            case 2:
                if (mb_strlen($this->current, 'UTF-8') < 6) {
                    goto lab12;
                }
                $this->slice_del();
                break;
        }
        goto lab11;
    lab12:
        $this->cursor = $this->limit - $v_10;
        if ($this->cursor <= $this->limit_backward) {
            goto lab8;
        }
        $this->dec_cursor();
    lab11:
        goto lab13;
    lab8:
        $this->cursor = $this->limit - $v_7;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_14) === 0) {
            goto lab14;
        }
        $this->bra = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 5) {
            goto lab14;
        }
        $this->slice_del();
        goto lab13;
    lab14:
        $this->cursor = $this->limit - $v_7;
        if (!$this->r_Suffix_Verb_Step2a()) {
            goto lab7;
        }
    lab13:
        goto lab15;
    lab7:
        $this->cursor = $this->limit - $v_6;
        if (!$B_is_noun) {
            goto lab16;
        }
        $v_11 = $this->limit - $this->cursor;
        $v_12 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{629}"))) {
            goto lab18;
        }
        $this->bra = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 4) {
            goto lab18;
        }
        $this->slice_del();
        goto lab19;
    lab18:
        $this->cursor = $this->limit - $v_12;
        if ($B_is_defined) {
            goto lab20;
        }
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_10);
        if (0 === $among_var) {
            goto lab20;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    goto lab20;
                }
                $this->slice_del();
                break;
            case 2:
                if (mb_strlen($this->current, 'UTF-8') < 5) {
                    goto lab20;
                }
                $this->slice_del();
                break;
            case 3:
                if (mb_strlen($this->current, 'UTF-8') < 6) {
                    goto lab20;
                }
                $this->slice_del();
                break;
        }
        $v_13 = $this->limit - $this->cursor;
        if (!$this->r_Suffix_Noun_Step2a()) {
            goto lab21;
        }
        goto lab22;
    lab21:
        $this->cursor = $this->limit - $v_13;
        if (!$this->r_Suffix_Noun_Step2b()) {
            goto lab23;
        }
        goto lab22;
    lab23:
        $this->cursor = $this->limit - $v_13;
        if (!$this->r_Suffix_Noun_Step2c1()) {
            goto lab24;
        }
        goto lab22;
    lab24:
        $this->cursor = $this->limit - $v_13;
        if ($this->cursor <= $this->limit_backward) {
            goto lab20;
        }
        $this->dec_cursor();
    lab22:
        goto lab19;
    lab20:
        $this->cursor = $this->limit - $v_12;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{646}"))) {
            goto lab25;
        }
        $this->bra = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 6) {
            goto lab25;
        }
        $this->slice_del();
        $v_14 = $this->limit - $this->cursor;
        if (!$this->r_Suffix_Noun_Step2a()) {
            goto lab26;
        }
        goto lab27;
    lab26:
        $this->cursor = $this->limit - $v_14;
        if (!$this->r_Suffix_Noun_Step2b()) {
            goto lab28;
        }
        goto lab27;
    lab28:
        $this->cursor = $this->limit - $v_14;
        if (!$this->r_Suffix_Noun_Step2c1()) {
            goto lab25;
        }
    lab27:
        goto lab19;
    lab25:
        $this->cursor = $this->limit - $v_12;
        if ($B_is_defined) {
            goto lab29;
        }
        if (!$this->r_Suffix_Noun_Step2a()) {
            goto lab29;
        }
        goto lab19;
    lab29:
        $this->cursor = $this->limit - $v_12;
        if (!$this->r_Suffix_Noun_Step2b()) {
            $this->cursor = $this->limit - $v_11;
            goto lab17;
        }
    lab19:
    lab17:
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{64A}"))) {
            goto lab16;
        }
        $this->bra = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 3) {
            goto lab16;
        }
        $this->slice_del();
        goto lab15;
    lab16:
        $this->cursor = $this->limit - $v_6;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{649}"))) {
            goto lab6;
        }
        $this->bra = $this->cursor;
        $this->slice_from("\u{64A}");
    lab15:
    lab6:
        $this->cursor = $this->limit - $v_5;
        $this->cursor = $this->limit_backward;
        $v_15 = $this->cursor;
        $v_16 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_4);
        if (0 === $among_var) {
            $this->cursor = $v_16;
            goto lab31;
        }
        $this->ket = $this->cursor;
        switch ($among_var) {
            case 1:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    $this->cursor = $v_16;
                    goto lab31;
                }
                $this->slice_from("\u{623}");
                break;
            case 2:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    $this->cursor = $v_16;
                    goto lab31;
                }
                $this->slice_from("\u{622}");
                break;
            case 3:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    $this->cursor = $v_16;
                    goto lab31;
                }
                $this->slice_from("\u{627}");
                break;
            case 4:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    $this->cursor = $v_16;
                    goto lab31;
                }
                $this->slice_from("\u{625}");
                break;
        }
    lab31:
        $v_17 = $this->cursor;
        $this->bra = $this->cursor;
        if ($this->find_among(self::A_5) === 0) {
            $this->cursor = $v_17;
            goto lab32;
        }
        $this->ket = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 4) {
            $this->cursor = $v_17;
            goto lab32;
        }
        if (!($this->eq_s("\u{627}"))) {
            goto lab33;
        }
        $this->cursor = $v_17;
        goto lab32;
    lab33:
        $this->slice_del();
    lab32:
        $v_18 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_6);
        if (0 === $among_var) {
            goto lab34;
        }
        $this->ket = $this->cursor;
        switch ($among_var) {
            case 1:
                if (mb_strlen($this->current, 'UTF-8') < 6) {
                    goto lab34;
                }
                $this->slice_del();
                break;
            case 2:
                if (mb_strlen($this->current, 'UTF-8') < 5) {
                    goto lab34;
                }
                $this->slice_del();
                break;
        }
        goto lab35;
    lab34:
        $this->cursor = $v_18;
        if (!$B_is_noun) {
            goto lab36;
        }
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_7);
        if (0 === $among_var) {
            goto lab36;
        }
        $this->ket = $this->cursor;
        switch ($among_var) {
            case 1:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    goto lab36;
                }
                $this->slice_del();
                break;
            case 2:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    goto lab36;
                }
                $this->slice_from("\u{628}");
                break;
            case 3:
                if (mb_strlen($this->current, 'UTF-8') < 4) {
                    goto lab36;
                }
                $this->slice_from("\u{643}");
                break;
        }
        goto lab35;
    lab36:
        $this->cursor = $v_18;
        if (!$B_is_verb) {
            goto lab30;
        }
        $v_19 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_8);
        if (0 === $among_var) {
            $this->cursor = $v_19;
            goto lab37;
        }
        $this->ket = $this->cursor;
        switch ($among_var) {
            case 1:
                if (mb_strlen($this->current, 'UTF-8') < 5) {
                    $this->cursor = $v_19;
                    goto lab37;
                }
                $this->slice_from("\u{64A}");
                break;
            case 2:
                if (mb_strlen($this->current, 'UTF-8') < 5) {
                    $this->cursor = $v_19;
                    goto lab37;
                }
                $this->slice_from("\u{62A}");
                break;
            case 3:
                if (mb_strlen($this->current, 'UTF-8') < 5) {
                    $this->cursor = $v_19;
                    goto lab37;
                }
                $this->slice_from("\u{646}");
                break;
            case 4:
                if (mb_strlen($this->current, 'UTF-8') < 5) {
                    $this->cursor = $v_19;
                    goto lab37;
                }
                $this->slice_from("\u{623}");
                break;
        }
    lab37:
        $this->bra = $this->cursor;
        if ($this->find_among(self::A_9) === 0) {
            goto lab30;
        }
        $this->ket = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 5) {
            goto lab30;
        }
        $B_is_verb = true;
        $B_is_noun = false;
        $this->slice_from("\u{627}\u{633}\u{62A}");
    lab35:
    lab30:
        $this->cursor = $v_15;
        $v_20 = $this->cursor;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_1) === 0) {
            goto lab39;
        }
        $this->bra = $this->cursor;
        $this->slice_from("\u{621}");
        $this->cursor = $this->limit_backward;
    lab39:
        $this->cursor = $v_20;
        $v_21 = $this->cursor;
        while (true) {
            $v_22 = $this->cursor;
            $v_23 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_2);
            if (0 === $among_var) {
                goto lab42;
            }
            $this->ket = $this->cursor;
            $this->slice_from(self::AS_2[$among_var - 1]);
            goto lab43;
        lab42:
            $this->cursor = $v_23;
            if ($this->cursor >= $this->limit) {
                goto lab41;
            }
            $this->inc_cursor();
        lab43:
            continue;
        lab41:
            $this->cursor = $v_22;
            break;
        }
    lab40:
        $this->cursor = $v_21;
    lab38:
        return true;
    }
}
