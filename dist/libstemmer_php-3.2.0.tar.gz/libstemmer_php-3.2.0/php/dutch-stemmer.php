<?php
// Generated from dutch.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballDutchStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["a", -1, 1],
        ["e", -1, 2],
        ["o", -1, 1],
        ["u", -1, 1],
        ["\u{E0}", -1, 1],
        ["\u{E1}", -1, 1],
        ["\u{E2}", -1, 1],
        ["\u{E4}", -1, 1],
        ["\u{E8}", -1, 2],
        ["\u{E9}", -1, 2],
        ["\u{EA}", -1, 2],
        ["e\u{EB}", -1, 3],
        ["i\u{EB}", -1, 4],
        ["\u{F2}", -1, 1],
        ["\u{F3}", -1, 1],
        ["\u{F4}", -1, 1],
        ["\u{F6}", -1, 1],
        ["\u{F9}", -1, 1],
        ["\u{FA}", -1, 1],
        ["\u{FB}", -1, 1],
        ["\u{FC}", -1, 1]
    ];

    private const array A_1 = [
        ["nde", -1, 8],
        ["en", -1, 7],
        ["s", -1, 2],
        ["'s", 2, 1],
        ["es", 2, 4],
        ["ies", 4, 3],
        ["aus", 2, 6],
        ["\u{E9}s", 2, 5]
    ];

    private const array A_2 = [
        ["de", -1, 5],
        ["ge", -1, 2],
        ["ische", -1, 4],
        ["je", -1, 1],
        ["lijke", -1, 3],
        ["le", -1, 9],
        ["ene", -1, 10],
        ["re", -1, 8],
        ["se", -1, 7],
        ["te", -1, 6],
        ["ieve", -1, 11]
    ];

    private const array A_3 = [
        ["heid", -1, 3],
        ["fie", -1, 7],
        ["gie", -1, 8],
        ["atie", -1, 1],
        ["isme", -1, 5],
        ["ing", -1, 5],
        ["arij", -1, 6],
        ["erij", -1, 5],
        ["sel", -1, 3],
        ["rder", -1, 4],
        ["ster", -1, 3],
        ["iteit", -1, 2],
        ["dst", -1, 10],
        ["tst", -1, 9]
    ];

    private const array A_4 = [
        ["end", -1, 9],
        ["atief", -1, 2],
        ["erig", -1, 9],
        ["achtig", -1, 3],
        ["ioneel", -1, 1],
        ["baar", -1, 3],
        ["laar", -1, 5],
        ["naar", -1, 4],
        ["raar", -1, 6],
        ["eriger", -1, 9],
        ["achtiger", -1, 3],
        ["lijker", -1, 8],
        ["tant", -1, 7],
        ["erigst", -1, 9],
        ["achtigst", -1, 3],
        ["lijkst", -1, 8]
    ];

    private const array A_5 = [
        ["ig", -1, 1],
        ["iger", -1, 1],
        ["igst", -1, 1]
    ];

    private const array A_6 = [
        ["ft", -1, 2],
        ["kt", -1, 1],
        ["pt", -1, 3]
    ];

    private const array AS_6 = ["k", "f", "p"];

    private const array A_7 = [
        ["bb", -1, 1],
        ["cc", -1, 2],
        ["dd", -1, 3],
        ["ff", -1, 4],
        ["gg", -1, 5],
        ["hh", -1, 6],
        ["jj", -1, 7],
        ["kk", -1, 8],
        ["ll", -1, 9],
        ["mm", -1, 10],
        ["nn", -1, 11],
        ["pp", -1, 12],
        ["qq", -1, 13],
        ["rr", -1, 14],
        ["ss", -1, 15],
        ["tt", -1, 16],
        ["v", -1, 4],
        ["vv", 16, 17],
        ["ww", -1, 18],
        ["xx", -1, 19],
        ["z", -1, 15],
        ["zz", 20, 20]
    ];

    private const array A_8 = [
        ["d", -1, 1],
        ["t", -1, 2]
    ];

    private const array A_9 = [
        ["", -1, -1],
        ["eft", 0, 1],
        ["vaa", 0, 1],
        ["val", 0, 1],
        ["vali", 3, -1],
        ["vare", 0, 1]
    ];

    private const array A_10 = [
        ["\u{EB}", -1, 1],
        ["\u{EF}", -1, 2]
    ];

    private const array AS_10 = ["e", "i"];

    private const array A_11 = [
        ["\u{EB}", -1, 1],
        ["\u{EF}", -1, 2]
    ];

    private const array AS_11 = ["e", "i"];

    private const array G_E = ["e"=>true, "\u{E8}"=>true, "\u{E9}"=>true, "\u{EA}"=>true, "\u{EB}"=>true];

    private const array G_AIOU = ["a"=>true, "i"=>true, "o"=>true, "u"=>true, "\u{E0}"=>true, "\u{E1}"=>true, "\u{E2}"=>true, "\u{E4}"=>true, "\u{EC}"=>true, "\u{ED}"=>true, "\u{EE}"=>true, "\u{EF}"=>true, "\u{F2}"=>true, "\u{F3}"=>true, "\u{F4}"=>true, "\u{F6}"=>true, "\u{F9}"=>true, "\u{FA}"=>true, "\u{FB}"=>true, "\u{FC}"=>true];

    private const array G_AEIOU = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "\u{E0}"=>true, "\u{E1}"=>true, "\u{E2}"=>true, "\u{E4}"=>true, "\u{E8}"=>true, "\u{E9}"=>true, "\u{EA}"=>true, "\u{EB}"=>true, "\u{EC}"=>true, "\u{ED}"=>true, "\u{EE}"=>true, "\u{EF}"=>true, "\u{F2}"=>true, "\u{F3}"=>true, "\u{F4}"=>true, "\u{F6}"=>true, "\u{F9}"=>true, "\u{FA}"=>true, "\u{FB}"=>true, "\u{FC}"=>true];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{E0}"=>true, "\u{E1}"=>true, "\u{E2}"=>true, "\u{E4}"=>true, "\u{E8}"=>true, "\u{E9}"=>true, "\u{EA}"=>true, "\u{EB}"=>true, "\u{EC}"=>true, "\u{ED}"=>true, "\u{EE}"=>true, "\u{EF}"=>true, "\u{F2}"=>true, "\u{F3}"=>true, "\u{F4}"=>true, "\u{F6}"=>true, "\u{F9}"=>true, "\u{FA}"=>true, "\u{FB}"=>true, "\u{FC}"=>true];

    private const array G_v_WX = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "w"=>true, "x"=>true, "y"=>true, "\u{E0}"=>true, "\u{E1}"=>true, "\u{E2}"=>true, "\u{E4}"=>true, "\u{E8}"=>true, "\u{E9}"=>true, "\u{EA}"=>true, "\u{EB}"=>true, "\u{EC}"=>true, "\u{ED}"=>true, "\u{EE}"=>true, "\u{EF}"=>true, "\u{F2}"=>true, "\u{F3}"=>true, "\u{F4}"=>true, "\u{F6}"=>true, "\u{F9}"=>true, "\u{FA}"=>true, "\u{FB}"=>true, "\u{FC}"=>true];

    private int $I_p2 = 0;
    private int $I_p1 = 0;



    protected function r_V(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        if (!($this->in_grouping_b(self::G_v))) {
            goto lab0;
        }
        goto lab1;
    lab0:
        if (!($this->eq_s_b("ij"))) {
            return false;
        }
    lab1:
        $this->cursor = $this->limit - $v_1;
        return true;
    }


    protected function r_C(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("ij"))) {
            goto lab0;
        }
        return false;
    lab0:
        if (!($this->out_grouping_b(self::G_v))) {
            return false;
        }
        $this->cursor = $this->limit - $v_1;
        return true;
    }


    protected function r_lengthen_V(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        if (!($this->out_grouping_b(self::G_v_WX))) {
            goto lab0;
        }
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_0);
        if (0 === $among_var) {
            goto lab0;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $v_2 = $this->limit - $this->cursor;
                if (!($this->out_grouping_b(self::G_AEIOU))) {
                    goto lab1;
                }
                goto lab2;
            lab1:
                if ($this->cursor > $this->limit_backward) {
                    goto lab0;
                }
            lab2:
                $this->cursor = $this->limit - $v_2;
                $S_ch = $this->slice_to();
                $c = $this->cursor;
                $this->insert($c, $c, $S_ch);
                $this->cursor = $c;
                break;
            case 2:
                $v_3 = $this->limit - $this->cursor;
                if (!($this->out_grouping_b(self::G_AEIOU))) {
                    goto lab3;
                }
                goto lab4;
            lab3:
                if ($this->cursor > $this->limit_backward) {
                    goto lab0;
                }
            lab4:
                $v_4 = $this->limit - $this->cursor;
                if (!($this->in_grouping_b(self::G_AIOU))) {
                    goto lab6;
                }
                goto lab7;
            lab6:
                if (!($this->in_grouping_b(self::G_E))) {
                    goto lab5;
                }
                if ($this->cursor > $this->limit_backward) {
                    goto lab5;
                }
            lab7:
                goto lab0;
            lab5:
                $this->cursor = $this->limit - $v_4;
                $v_5 = $this->limit - $this->cursor;
                if ($this->cursor <= $this->limit_backward) {
                    goto lab8;
                }
                $this->dec_cursor();
                if (!($this->in_grouping_b(self::G_AIOU))) {
                    goto lab8;
                }
                if (!($this->out_grouping_b(self::G_AEIOU))) {
                    goto lab8;
                }
                goto lab0;
            lab8:
                $this->cursor = $this->limit - $v_5;
                $this->cursor = $this->limit - $v_3;
                $S_ch = $this->slice_to();
                $c = $this->cursor;
                $this->insert($c, $c, $S_ch);
                $this->cursor = $c;
                break;
            case 3:
                $this->slice_from("e\u{EB}e");
                break;
            case 4:
                $this->slice_from("iee");
                break;
        }
    lab0:
        $this->cursor = $this->limit - $v_1;
        return true;
    }


    protected function r_Step_1c(): bool
    {
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_8);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        if ($this->I_p1 > $this->cursor) {
            return false;
        }
        if (!$this->r_C()) {
            return false;
        }
        switch ($among_var) {
            case 1:
                $v_1 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("n"))) {
                    goto lab0;
                }
                if ($this->I_p1 > $this->cursor) {
                    goto lab0;
                }
                return false;
            lab0:
                $this->cursor = $this->limit - $v_1;
                $v_2 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("in"))) {
                    goto lab1;
                }
                if ($this->cursor > $this->limit_backward) {
                    goto lab1;
                }
                $this->slice_from("n");
                goto lab2;
            lab1:
                $this->cursor = $this->limit - $v_2;
                $this->slice_del();
            lab2:
                break;
            case 2:
                $v_3 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("h"))) {
                    goto lab3;
                }
                if ($this->I_p1 > $this->cursor) {
                    goto lab3;
                }
                return false;
            lab3:
                $this->cursor = $this->limit - $v_3;
                $v_4 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("en"))) {
                    goto lab4;
                }
                if ($this->cursor > $this->limit_backward) {
                    goto lab4;
                }
                return false;
            lab4:
                $this->cursor = $this->limit - $v_4;
                $this->slice_del();
                break;
        }
        return true;
    }


    protected function r_measure(): bool
    {
        $this->I_p1 = $this->limit;
        $this->I_p2 = $this->limit;
        $v_1 = $this->cursor;
        while (true) {
            if (!($this->out_grouping(self::G_v))) {
                goto lab1;
            }
            continue;
        lab1:
            break;
        }
        $v_2 = 1;
        while (true) {
            $v_3 = $this->cursor;
            if (!($this->eq_s("ij"))) {
                goto lab3;
            }
            goto lab4;
        lab3:
            if (!($this->in_grouping(self::G_v))) {
                goto lab2;
            }
        lab4:
            $v_2--;
            continue;
        lab2:
            $this->cursor = $v_3;
            break;
        }
        if ($v_2 > 0) {
            goto lab0;
        }
        if (!($this->out_grouping(self::G_v))) {
            goto lab0;
        }
        $this->I_p1 = $this->cursor;
        while (true) {
            if (!($this->out_grouping(self::G_v))) {
                goto lab5;
            }
            continue;
        lab5:
            break;
        }
        $v_4 = 1;
        while (true) {
            $v_5 = $this->cursor;
            if (!($this->eq_s("ij"))) {
                goto lab7;
            }
            goto lab8;
        lab7:
            if (!($this->in_grouping(self::G_v))) {
                goto lab6;
            }
        lab8:
            $v_4--;
            continue;
        lab6:
            $this->cursor = $v_5;
            break;
        }
        if ($v_4 > 0) {
            goto lab0;
        }
        if (!($this->out_grouping(self::G_v))) {
            goto lab0;
        }
        $this->I_p2 = $this->cursor;
    lab0:
        $this->cursor = $v_1;
        return true;
    }


    public function stem(): bool
    {
        $B_stemmed = false;
        $this->r_measure();
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_1 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_1);
        if (0 === $among_var) {
            goto lab0;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                if ($this->I_p1 > $this->cursor) {
                    goto lab0;
                }
                $v_2 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("t"))) {
                    goto lab1;
                }
                if ($this->I_p1 > $this->cursor) {
                    goto lab1;
                }
                goto lab0;
            lab1:
                $this->cursor = $this->limit - $v_2;
                if (!$this->r_C()) {
                    goto lab0;
                }
                $this->slice_del();
                break;
            case 3:
                if ($this->I_p1 > $this->cursor) {
                    goto lab0;
                }
                $this->slice_from("ie");
                break;
            case 4:
                $v_3 = $this->limit - $this->cursor;
                $v_4 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("ar"))) {
                    goto lab2;
                }
                if ($this->I_p1 > $this->cursor) {
                    goto lab2;
                }
                if (!$this->r_C()) {
                    goto lab2;
                }
                $this->cursor = $this->limit - $v_4;
                $this->slice_del();
                $this->r_lengthen_V();
                goto lab3;
            lab2:
                $this->cursor = $this->limit - $v_3;
                $v_5 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("er"))) {
                    goto lab4;
                }
                if ($this->I_p1 > $this->cursor) {
                    goto lab4;
                }
                if (!$this->r_C()) {
                    goto lab4;
                }
                $this->cursor = $this->limit - $v_5;
                $this->slice_del();
                goto lab3;
            lab4:
                $this->cursor = $this->limit - $v_3;
                if ($this->I_p1 > $this->cursor) {
                    goto lab0;
                }
                if (!$this->r_C()) {
                    goto lab0;
                }
                $this->slice_from("e");
            lab3:
                break;
            case 5:
                if ($this->I_p1 > $this->cursor) {
                    goto lab0;
                }
                $this->slice_from("\u{E9}");
                break;
            case 6:
                if ($this->I_p1 > $this->cursor) {
                    goto lab0;
                }
                if (!$this->r_V()) {
                    goto lab0;
                }
                $this->slice_from("au");
                break;
            case 7:
                $v_6 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("hed"))) {
                    goto lab5;
                }
                if ($this->I_p1 > $this->cursor) {
                    goto lab5;
                }
                $this->bra = $this->cursor;
                $this->slice_from("heid");
                goto lab6;
            lab5:
                $this->cursor = $this->limit - $v_6;
                if (!($this->eq_s_b("nd"))) {
                    goto lab7;
                }
                $this->slice_del();
                goto lab6;
            lab7:
                $this->cursor = $this->limit - $v_6;
                if (!($this->eq_s_b("d"))) {
                    goto lab8;
                }
                if ($this->I_p1 > $this->cursor) {
                    goto lab8;
                }
                if (!$this->r_C()) {
                    goto lab8;
                }
                $this->bra = $this->cursor;
                $this->slice_del();
                goto lab6;
            lab8:
                $this->cursor = $this->limit - $v_6;
                if (!($this->eq_s_b("i"))) {
                    goto lab10;
                }
                goto lab11;
            lab10:
                if (!($this->eq_s_b("j"))) {
                    goto lab9;
                }
            lab11:
                if (!$this->r_V()) {
                    goto lab9;
                }
                $this->slice_del();
                goto lab6;
            lab9:
                $this->cursor = $this->limit - $v_6;
                if ($this->I_p1 > $this->cursor) {
                    goto lab0;
                }
                if (!$this->r_C()) {
                    goto lab0;
                }
                $this->slice_del();
                $this->r_lengthen_V();
            lab6:
                break;
            case 8:
                $this->slice_from("nd");
                break;
        }
        $B_stemmed = true;
    lab0:
        $this->cursor = $this->limit - $v_1;
        $v_7 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            goto lab12;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $v_8 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("'t"))) {
                    goto lab13;
                }
                $this->bra = $this->cursor;
                $this->slice_del();
                goto lab14;
            lab13:
                $this->cursor = $this->limit - $v_8;
                if (!($this->eq_s_b("et"))) {
                    goto lab15;
                }
                $this->bra = $this->cursor;
                if ($this->I_p1 > $this->cursor) {
                    goto lab15;
                }
                if (!$this->r_C()) {
                    goto lab15;
                }
                $this->slice_del();
                goto lab14;
            lab15:
                $this->cursor = $this->limit - $v_8;
                if (!($this->eq_s_b("rnt"))) {
                    goto lab16;
                }
                $this->bra = $this->cursor;
                $this->slice_from("rn");
                goto lab14;
            lab16:
                $this->cursor = $this->limit - $v_8;
                if (!($this->eq_s_b("t"))) {
                    goto lab17;
                }
                $this->bra = $this->cursor;
                if ($this->I_p1 > $this->cursor) {
                    goto lab17;
                }
                $v_9 = $this->limit - $this->cursor;
                if ($this->cursor <= $this->limit_backward) {
                    goto lab17;
                }
                $this->dec_cursor();
                if (!($this->in_grouping_b(self::G_v))) {
                    goto lab18;
                }
                goto lab19;
            lab18:
                if (!($this->eq_s_b("ij"))) {
                    goto lab17;
                }
            lab19:
                $this->cursor = $this->limit - $v_9;
                $this->slice_del();
                goto lab14;
            lab17:
                $this->cursor = $this->limit - $v_8;
                if (!($this->eq_s_b("ink"))) {
                    goto lab20;
                }
                $this->bra = $this->cursor;
                $this->slice_from("ing");
                goto lab14;
            lab20:
                $this->cursor = $this->limit - $v_8;
                if (!($this->eq_s_b("mp"))) {
                    goto lab21;
                }
                $this->bra = $this->cursor;
                $this->slice_from("m");
                goto lab14;
            lab21:
                $this->cursor = $this->limit - $v_8;
                if (!($this->eq_s_b("'"))) {
                    goto lab22;
                }
                $this->bra = $this->cursor;
                if ($this->I_p1 > $this->cursor) {
                    goto lab22;
                }
                $this->slice_del();
                goto lab14;
            lab22:
                $this->cursor = $this->limit - $v_8;
                $this->bra = $this->cursor;
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                if (!$this->r_C()) {
                    goto lab12;
                }
                $this->slice_del();
            lab14:
                break;
            case 2:
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                $this->slice_from("g");
                break;
            case 3:
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                $this->slice_from("lijk");
                break;
            case 4:
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                $this->slice_from("isch");
                break;
            case 5:
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                if (!$this->r_C()) {
                    goto lab12;
                }
                $this->slice_del();
                break;
            case 6:
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                $this->slice_from("t");
                break;
            case 7:
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                $this->slice_from("s");
                break;
            case 8:
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                $this->slice_from("r");
                break;
            case 9:
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                $this->slice_del();
                $this->insert($this->cursor, $this->cursor, "l");
                $this->r_lengthen_V();
                break;
            case 10:
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                if (!$this->r_C()) {
                    goto lab12;
                }
                $this->slice_del();
                $this->insert($this->cursor, $this->cursor, "en");
                $this->r_lengthen_V();
                break;
            case 11:
                if ($this->I_p1 > $this->cursor) {
                    goto lab12;
                }
                if (!$this->r_C()) {
                    goto lab12;
                }
                $this->slice_from("ief");
                break;
        }
        $B_stemmed = true;
    lab12:
        $this->cursor = $this->limit - $v_7;
        $v_10 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_3);
        if (0 === $among_var) {
            goto lab23;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($this->I_p1 > $this->cursor) {
                    goto lab23;
                }
                $this->slice_from("eer");
                break;
            case 2:
                if ($this->I_p1 > $this->cursor) {
                    goto lab23;
                }
                $this->slice_del();
                $this->r_lengthen_V();
                break;
            case 3:
                if ($this->I_p1 > $this->cursor) {
                    goto lab23;
                }
                $this->slice_del();
                break;
            case 4:
                $this->slice_from("r");
                break;
            case 5:
                $v_11 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("ild"))) {
                    goto lab24;
                }
                $this->slice_from("er");
                goto lab25;
            lab24:
                $this->cursor = $this->limit - $v_11;
                if ($this->I_p1 > $this->cursor) {
                    goto lab23;
                }
                $this->slice_del();
                $this->r_lengthen_V();
            lab25:
                break;
            case 6:
                if ($this->I_p1 > $this->cursor) {
                    goto lab23;
                }
                if (!$this->r_C()) {
                    goto lab23;
                }
                $this->slice_from("aar");
                break;
            case 7:
                if ($this->I_p2 > $this->cursor) {
                    goto lab23;
                }
                $this->slice_del();
                $this->insert($this->cursor, $this->cursor, "f");
                $this->r_lengthen_V();
                break;
            case 8:
                if ($this->I_p2 > $this->cursor) {
                    goto lab23;
                }
                $this->slice_del();
                $this->insert($this->cursor, $this->cursor, "g");
                $this->r_lengthen_V();
                break;
            case 9:
                if ($this->I_p1 > $this->cursor) {
                    goto lab23;
                }
                if (!$this->r_C()) {
                    goto lab23;
                }
                $this->slice_from("t");
                break;
            case 10:
                if ($this->I_p1 > $this->cursor) {
                    goto lab23;
                }
                if (!$this->r_C()) {
                    goto lab23;
                }
                $this->slice_from("d");
                break;
        }
        $B_stemmed = true;
    lab23:
        $this->cursor = $this->limit - $v_10;
        $v_12 = $this->limit - $this->cursor;
        $v_13 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab27;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($this->I_p1 > $this->cursor) {
                    goto lab27;
                }
                $this->slice_from("ie");
                break;
            case 2:
                if ($this->I_p1 > $this->cursor) {
                    goto lab27;
                }
                $this->slice_from("eer");
                break;
            case 3:
                if ($this->I_p1 > $this->cursor) {
                    goto lab27;
                }
                $this->slice_del();
                break;
            case 4:
                if ($this->I_p1 > $this->cursor) {
                    goto lab27;
                }
                if (!$this->r_V()) {
                    goto lab27;
                }
                $this->slice_from("n");
                break;
            case 5:
                if ($this->I_p1 > $this->cursor) {
                    goto lab27;
                }
                if (!$this->r_V()) {
                    goto lab27;
                }
                $this->slice_from("l");
                break;
            case 6:
                if ($this->I_p1 > $this->cursor) {
                    goto lab27;
                }
                if (!$this->r_V()) {
                    goto lab27;
                }
                $this->slice_from("r");
                break;
            case 7:
                if ($this->I_p1 > $this->cursor) {
                    goto lab27;
                }
                $this->slice_from("teer");
                break;
            case 8:
                if ($this->I_p1 > $this->cursor) {
                    goto lab27;
                }
                $this->slice_from("lijk");
                break;
            case 9:
                if ($this->I_p1 > $this->cursor) {
                    goto lab27;
                }
                if (!$this->r_C()) {
                    goto lab27;
                }
                $this->slice_del();
                $this->r_lengthen_V();
                break;
        }
        goto lab28;
    lab27:
        $this->cursor = $this->limit - $v_13;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_5) === 0) {
            goto lab26;
        }
        $this->bra = $this->cursor;
        if ($this->I_p1 > $this->cursor) {
            goto lab26;
        }
        $v_14 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("inn"))) {
            goto lab29;
        }
        if ($this->cursor > $this->limit_backward) {
            goto lab29;
        }
        goto lab26;
    lab29:
        $this->cursor = $this->limit - $v_14;
        if (!$this->r_C()) {
            goto lab26;
        }
        $this->slice_del();
        $this->r_lengthen_V();
    lab28:
        $B_stemmed = true;
    lab26:
        $this->cursor = $this->limit - $v_12;
        $this->cursor = $this->limit_backward;
        $B_GE_removed = false;
        $v_15 = $this->cursor;
        $v_16 = $this->cursor;
        $this->bra = $this->cursor;
        if (!($this->eq_s("ge"))) {
            goto lab30;
        }
        $this->ket = $this->cursor;
        $v_17 = $this->cursor;
        if (!$this->hop(3)) {
            goto lab30;
        }
        $this->cursor = $v_17;
        $v_18 = $this->cursor;
        while (true) {
            $v_19 = $this->cursor;
            if (!($this->eq_s("ij"))) {
                goto lab32;
            }
            goto lab33;
        lab32:
            if (!($this->in_grouping(self::G_v))) {
                goto lab31;
            }
        lab33:
            break;
        lab31:
            $this->cursor = $v_19;
            if ($this->cursor >= $this->limit) {
                goto lab30;
            }
            $this->inc_cursor();
        }
        while (true) {
            $v_20 = $this->cursor;
            if (!($this->eq_s("ij"))) {
                goto lab35;
            }
            goto lab36;
        lab35:
            if (!($this->in_grouping(self::G_v))) {
                goto lab34;
            }
        lab36:
            continue;
        lab34:
            $this->cursor = $v_20;
            break;
        }
        if ($this->cursor >= $this->limit) {
            goto lab30;
        }
        $this->cursor = $v_18;
        $among_var = $this->find_among(self::A_9);
        switch ($among_var) {
            case 1:
                goto lab30;
        }
        $B_GE_removed = true;
        $this->slice_del();
        $v_21 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_10);
        if (0 === $among_var) {
            goto lab37;
        }
        $this->ket = $this->cursor;
        $this->slice_from(self::AS_10[$among_var - 1]);
    lab37:
        $this->cursor = $v_21;
        $this->cursor = $v_16;
        $this->r_measure();
    lab30:
        $this->cursor = $v_15;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_22 = $this->limit - $this->cursor;
        if (!$B_GE_removed) {
            goto lab38;
        }
        $B_stemmed = true;
        if (!$this->r_Step_1c()) {
            goto lab38;
        }
    lab38:
        $this->cursor = $this->limit - $v_22;
        $this->cursor = $this->limit_backward;
        $B_GE_removed = false;
        $v_23 = $this->cursor;
        $v_24 = $this->cursor;
        if ($this->cursor >= $this->limit) {
            goto lab39;
        }
        $this->inc_cursor();
        while (true) {
            $this->bra = $this->cursor;
            if (!($this->eq_s("ge"))) {
                goto lab40;
            }
            $this->ket = $this->cursor;
            break;
        lab40:
            if ($this->cursor >= $this->limit) {
                goto lab39;
            }
            $this->inc_cursor();
        }
        $v_25 = $this->cursor;
        if (!$this->hop(3)) {
            goto lab39;
        }
        $this->cursor = $v_25;
        $v_26 = $this->cursor;
        while (true) {
            $v_27 = $this->cursor;
            if (!($this->eq_s("ij"))) {
                goto lab42;
            }
            goto lab43;
        lab42:
            if (!($this->in_grouping(self::G_v))) {
                goto lab41;
            }
        lab43:
            break;
        lab41:
            $this->cursor = $v_27;
            if ($this->cursor >= $this->limit) {
                goto lab39;
            }
            $this->inc_cursor();
        }
        while (true) {
            $v_28 = $this->cursor;
            if (!($this->eq_s("ij"))) {
                goto lab45;
            }
            goto lab46;
        lab45:
            if (!($this->in_grouping(self::G_v))) {
                goto lab44;
            }
        lab46:
            continue;
        lab44:
            $this->cursor = $v_28;
            break;
        }
        if ($this->cursor >= $this->limit) {
            goto lab39;
        }
        $this->cursor = $v_26;
        $B_GE_removed = true;
        $this->slice_del();
        $v_29 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_11);
        if (0 === $among_var) {
            goto lab47;
        }
        $this->ket = $this->cursor;
        $this->slice_from(self::AS_11[$among_var - 1]);
    lab47:
        $this->cursor = $v_29;
        $this->cursor = $v_24;
        $this->r_measure();
    lab39:
        $this->cursor = $v_23;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_30 = $this->limit - $this->cursor;
        if (!$B_GE_removed) {
            goto lab48;
        }
        $B_stemmed = true;
        if (!$this->r_Step_1c()) {
            goto lab48;
        }
    lab48:
        $this->cursor = $this->limit - $v_30;
        $this->cursor = $this->limit_backward;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_31 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_6);
        if (0 === $among_var) {
            goto lab49;
        }
        $this->bra = $this->cursor;
        $this->slice_from(self::AS_6[$among_var - 1]);
        $B_stemmed = true;
    lab49:
        $this->cursor = $this->limit - $v_31;
        $v_32 = $this->limit - $this->cursor;
        if (!$B_stemmed) {
            goto lab50;
        }
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_7);
        if (0 === $among_var) {
            goto lab50;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $this->slice_from("b");
                break;
            case 2:
                $this->slice_from("c");
                break;
            case 3:
                $this->slice_from("d");
                break;
            case 4:
                $this->slice_from("f");
                break;
            case 5:
                $this->slice_from("g");
                break;
            case 6:
                $this->slice_from("h");
                break;
            case 7:
                $this->slice_from("j");
                break;
            case 8:
                $this->slice_from("k");
                break;
            case 9:
                $this->slice_from("l");
                break;
            case 10:
                $this->slice_from("m");
                break;
            case 11:
                $v_33 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("i"))) {
                    goto lab51;
                }
                if ($this->cursor > $this->limit_backward) {
                    goto lab51;
                }
                goto lab50;
            lab51:
                $this->cursor = $this->limit - $v_33;
                $this->slice_from("n");
                break;
            case 12:
                $this->slice_from("p");
                break;
            case 13:
                $this->slice_from("q");
                break;
            case 14:
                $this->slice_from("r");
                break;
            case 15:
                $this->slice_from("s");
                break;
            case 16:
                $this->slice_from("t");
                break;
            case 17:
                $this->slice_from("v");
                break;
            case 18:
                $this->slice_from("w");
                break;
            case 19:
                $this->slice_from("x");
                break;
            case 20:
                $this->slice_from("z");
                break;
        }
    lab50:
        $this->cursor = $this->limit - $v_32;
        $this->cursor = $this->limit_backward;
        return true;
    }
}
