<?php
// Generated from esperanto.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballEsperantoStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["", -1, 14],
        ["-", 0, 13],
        ["cx", 0, 1],
        ["gx", 0, 2],
        ["hx", 0, 3],
        ["jx", 0, 4],
        ["q", 0, 12],
        ["sx", 0, 5],
        ["ux", 0, 6],
        ["w", 0, 12],
        ["x", 0, 12],
        ["y", 0, 12],
        ["\u{E1}", 0, 7],
        ["\u{E9}", 0, 8],
        ["\u{ED}", 0, 9],
        ["\u{F3}", 0, 10],
        ["\u{FA}", 0, 11]
    ];

    private const array A_1 = [
        ["as", -1, -1],
        ["i", -1, -1],
        ["is", 1, -1],
        ["os", -1, -1],
        ["u", -1, -1],
        ["us", 4, -1]
    ];

    private const array A_2 = [
        ["ci", -1, -1],
        ["gi", -1, -1],
        ["hi", -1, -1],
        ["li", -1, -1],
        ["ili", 3, -1],
        ["\u{15D}li", 3, -1],
        ["mi", -1, -1],
        ["ni", -1, -1],
        ["oni", 7, -1],
        ["ri", -1, -1],
        ["si", -1, -1],
        ["vi", -1, -1],
        ["ivi", 11, -1],
        ["\u{11D}i", -1, -1],
        ["\u{15D}i", -1, -1],
        ["i\u{15D}i", 14, -1],
        ["mal\u{15D}i", 14, -1]
    ];

    private const array A_3 = [
        ["amb", -1, -1],
        ["bald", -1, -1],
        ["malbald", 1, -1],
        ["morg", -1, -1],
        ["postmorg", 3, -1],
        ["adi", -1, -1],
        ["hodi", -1, -1],
        ["ank", -1, -1],
        ["\u{109}irk", -1, -1],
        ["tut\u{109}irk", 8, -1],
        ["presk", -1, -1],
        ["almen", -1, -1],
        ["apen", -1, -1],
        ["hier", -1, -1],
        ["anta\u{16D}hier", 13, -1],
        ["malgr", -1, -1],
        ["ankor", -1, -1],
        ["kontr", -1, -1],
        ["anstat", -1, -1],
        ["kvaz", -1, -1]
    ];

    private const array A_4 = [
        ["aliu", -1, -1],
        ["unu", -1, -1]
    ];

    private const array A_5 = [
        ["aha", -1, -1],
        ["haha", 0, -1],
        ["haleluja", -1, -1],
        ["hola", -1, -1],
        ["hosana", -1, -1],
        ["maltra", -1, -1],
        ["hura", -1, -1],
        ["\u{125}a\u{125}a", -1, -1],
        ["ekde", -1, -1],
        ["elde", -1, -1],
        ["disde", -1, -1],
        ["ehe", -1, -1],
        ["maltre", -1, -1],
        ["dirlididi", -1, -1],
        ["malpli", -1, -1],
        ["mal\u{109}i", -1, -1],
        ["malkaj", -1, -1],
        ["amen", -1, -1],
        ["tamen", 17, -1],
        ["oho", -1, -1],
        ["maltro", -1, -1],
        ["minus", -1, -1],
        ["uhu", -1, -1],
        ["muu", -1, -1]
    ];

    private const array A_6 = [
        ["tri", -1, -1],
        ["du", -1, -1],
        ["unu", -1, -1]
    ];

    private const array A_7 = [
        ["dek", -1, -1],
        ["cent", -1, -1]
    ];

    private const array A_8 = [
        ["k", -1, -1],
        ["kelk", 0, -1],
        ["nen", -1, -1],
        ["t", -1, -1],
        ["mult", 3, -1],
        ["samt", 3, -1],
        ["\u{109}", -1, -1]
    ];

    private const array A_9 = [
        ["a", -1, -1],
        ["e", -1, -1],
        ["i", -1, -1],
        ["j", -1, 1],
        ["aj", 3, -1],
        ["oj", 3, -1],
        ["n", -1, 1],
        ["an", 6, -1],
        ["en", 6, -1],
        ["jn", 6, 1],
        ["ajn", 9, -1],
        ["ojn", 9, -1],
        ["on", 6, -1],
        ["o", -1, -1],
        ["as", -1, -1],
        ["is", -1, -1],
        ["os", -1, -1],
        ["us", -1, -1],
        ["u", -1, -1]
    ];

    private const array G_vowel = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true];

    private const array G_aou = ["a"=>true, "o"=>true, "u"=>true];

    private const array G_digit = ["0"=>true, "1"=>true, "2"=>true, "3"=>true, "4"=>true, "5"=>true, "6"=>true, "7"=>true, "8"=>true, "9"=>true];



    public function stem(): bool
    {
        $v_1 = $this->cursor;
        $B_foreign = false;
        while (true) {
            $v_2 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_0);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("\u{109}");
                    break;
                case 2:
                    $this->slice_from("\u{11D}");
                    break;
                case 3:
                    $this->slice_from("\u{125}");
                    break;
                case 4:
                    $this->slice_from("\u{135}");
                    break;
                case 5:
                    $this->slice_from("\u{15D}");
                    break;
                case 6:
                    $this->slice_from("\u{16D}");
                    break;
                case 7:
                    $this->slice_from("a");
                    $B_foreign = true;
                    break;
                case 8:
                    $this->slice_from("e");
                    $B_foreign = true;
                    break;
                case 9:
                    $this->slice_from("i");
                    $B_foreign = true;
                    break;
                case 10:
                    $this->slice_from("o");
                    $B_foreign = true;
                    break;
                case 11:
                    $this->slice_from("u");
                    $B_foreign = true;
                    break;
                case 12:
                    $B_foreign = true;
                    break;
                case 13:
                    $B_foreign = false;
                    break;
                case 14:
                    if ($this->cursor >= $this->limit) {
                        goto lab0;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab0:
            $this->cursor = $v_2;
            break;
        }
        if ($B_foreign) {
            return false;
        }
        $this->cursor = $v_1;
        $v_3 = $this->cursor;
        $this->bra = $this->cursor;
        if (!($this->eq_s("'"))) {
            goto lab1;
        }
        $this->ket = $this->cursor;
        if (!($this->eq_s("st"))) {
            goto lab1;
        }
        if ($this->find_among(self::A_1) === 0) {
            goto lab1;
        }
        if ($this->cursor < $this->limit) {
            goto lab1;
        }
        $this->slice_from("e");
    lab1:
        $this->cursor = $v_3;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_4 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $v_5 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("n"))) {
            $this->cursor = $this->limit - $v_5;
            goto lab3;
        }
    lab3:
        $this->bra = $this->cursor;
        if ($this->find_among_b(self::A_2) === 0) {
            goto lab2;
        }
        if ($this->cursor > $this->limit_backward) {
            goto lab4;
        }
        goto lab5;
    lab4:
        if (!($this->eq_s_b("-"))) {
            goto lab2;
        }
    lab5:
        $this->slice_del();
        return false;
    lab2:
        $this->cursor = $this->limit - $v_4;
        $v_6 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("'"))) {
            goto lab6;
        }
        $this->bra = $this->cursor;
        $v_7 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("l"))) {
            goto lab7;
        }
        if ($this->cursor > $this->limit_backward) {
            goto lab7;
        }
        $this->slice_from("a");
        goto lab8;
    lab7:
        $this->cursor = $this->limit - $v_7;
        if (!($this->eq_s_b("un"))) {
            goto lab9;
        }
        if ($this->cursor > $this->limit_backward) {
            goto lab9;
        }
        $this->slice_from("u");
        goto lab8;
    lab9:
        $this->cursor = $this->limit - $v_7;
        if ($this->find_among_b(self::A_3) === 0) {
            goto lab10;
        }
        if ($this->cursor > $this->limit_backward) {
            goto lab11;
        }
        goto lab12;
    lab11:
        if (!($this->eq_s_b("-"))) {
            goto lab10;
        }
    lab12:
        $this->slice_from("a\u{16D}");
        goto lab8;
    lab10:
        $this->cursor = $this->limit - $v_7;
        $this->slice_from("o");
    lab8:
    lab6:
        $this->cursor = $this->limit - $v_6;
        $v_8 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $this->bra = $this->cursor;
        $v_9 = $this->limit - $this->cursor;
        $v_10 = $this->limit - $this->cursor;
        $v_11 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("n"))) {
            $this->cursor = $this->limit - $v_11;
            goto lab15;
        }
    lab15:
        $this->bra = $this->cursor;
        if (!($this->eq_s_b("e"))) {
            goto lab14;
        }
        goto lab16;
    lab14:
        $this->cursor = $this->limit - $v_10;
        $v_12 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("n"))) {
            $this->cursor = $this->limit - $v_12;
            goto lab17;
        }
    lab17:
        $v_13 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("j"))) {
            $this->cursor = $this->limit - $v_13;
            goto lab18;
        }
    lab18:
        $this->bra = $this->cursor;
        if (!($this->in_grouping_b(self::G_aou))) {
            goto lab13;
        }
    lab16:
        if (!($this->eq_s_b("i"))) {
            goto lab13;
        }
        $v_14 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_8) === 0) {
            $this->cursor = $this->limit - $v_14;
            goto lab19;
        }
    lab19:
        if ($this->cursor > $this->limit_backward) {
            goto lab20;
        }
        goto lab21;
    lab20:
        if (!($this->eq_s_b("-"))) {
            goto lab13;
        }
    lab21:
        $this->cursor = $this->limit - $v_9;
        $this->slice_del();
        return false;
    lab13:
        $this->cursor = $this->limit - $v_8;
        $v_15 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_5) === 0) {
            goto lab22;
        }
        if ($this->cursor > $this->limit_backward) {
            goto lab23;
        }
        goto lab24;
    lab23:
        if (!($this->eq_s_b("-"))) {
            goto lab22;
        }
    lab24:
        return false;
    lab22:
        $this->cursor = $this->limit - $v_15;
        $v_16 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_6) === 0) {
            goto lab25;
        }
        if ($this->find_among_b(self::A_7) === 0) {
            goto lab25;
        }
        return false;
    lab25:
        $this->cursor = $this->limit - $v_16;
        $v_17 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $v_18 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("n"))) {
            $this->cursor = $this->limit - $v_18;
            goto lab27;
        }
    lab27:
        $v_19 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("j"))) {
            $this->cursor = $this->limit - $v_19;
            goto lab28;
        }
    lab28:
        $this->bra = $this->cursor;
        if ($this->find_among_b(self::A_4) === 0) {
            goto lab26;
        }
        if ($this->cursor > $this->limit_backward) {
            goto lab29;
        }
        goto lab30;
    lab29:
        if (!($this->eq_s_b("-"))) {
            goto lab26;
        }
    lab30:
        $this->slice_del();
        return false;
    lab26:
        $this->cursor = $this->limit - $v_17;
        $v_20 = $this->limit - $this->cursor;
        $v_21 = $this->limit - $this->cursor;
        for ($v_22 = 2; $v_22 > 0; $v_22--) {
            if (!$this->go_out_grouping_b(self::G_vowel)) {
                goto lab31;
            }
            $this->dec_cursor();
        }
        goto lab32;
    lab31:
        $this->cursor = $this->limit - $v_21;
        while (true) {
            if (!($this->eq_s_b("-"))) {
                goto lab34;
            }
            break;
        lab34:
            if ($this->cursor <= $this->limit_backward) {
                goto lab33;
            }
            $this->dec_cursor();
        }
        if ($this->cursor <= $this->limit_backward) {
            goto lab33;
        }
        $this->dec_cursor();
        goto lab32;
    lab33:
        $this->cursor = $this->limit - $v_21;
        if (!$this->go_out_grouping_b(self::G_digit)) {
            return false;
        }
        $this->dec_cursor();
    lab32:
        $this->cursor = $this->limit - $v_20;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_9);
        if (0 === $among_var) {
            return false;
        }
        switch ($among_var) {
            case 1:
                $v_23 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("-"))) {
                    goto lab35;
                }
                goto lab36;
            lab35:
                if (!($this->in_grouping_b(self::G_digit))) {
                    return false;
                }
            lab36:
                $this->cursor = $this->limit - $v_23;
                break;
        }
        $v_24 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("-"))) {
            $this->cursor = $this->limit - $v_24;
            goto lab37;
        }
    lab37:
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->cursor = $this->limit_backward;
        return true;
    }
}
