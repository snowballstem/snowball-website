<?php
// Generated from yiddish.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballYiddishStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["\u{5D5}\u{5D5}", -1, 1],
        ["\u{5D5}\u{5D9}", -1, 2],
        ["\u{5D9}\u{5D9}", -1, 3],
        ["\u{5DA}", -1, 4],
        ["\u{5DD}", -1, 5],
        ["\u{5DF}", -1, 6],
        ["\u{5E3}", -1, 7],
        ["\u{5E5}", -1, 8]
    ];

    private const array A_1 = [
        ["\u{5D0}\u{5D3}\u{5D5}\u{5E8}\u{5DB}", -1, 1],
        ["\u{5D0}\u{5D4}\u{5D9}\u{5E0}", -1, 1],
        ["\u{5D0}\u{5D4}\u{5E2}\u{5E8}", -1, 1],
        ["\u{5D0}\u{5D4}\u{5F2}\u{5DE}", -1, 1],
        ["\u{5D0}\u{5D5}\u{5DE}", -1, 1],
        ["\u{5D0}\u{5D5}\u{5E0}\u{5D8}\u{5E2}\u{5E8}", -1, 1],
        ["\u{5D0}\u{5D9}\u{5D1}\u{5E2}\u{5E8}", -1, 1],
        ["\u{5D0}\u{5E0}", -1, 1],
        ["\u{5D0}\u{5E0}\u{5D8}", 7, 1],
        ["\u{5D0}\u{5E0}\u{5D8}\u{5E7}\u{5E2}\u{5D2}\u{5E0}", 8, 1],
        ["\u{5D0}\u{5E0}\u{5D9}\u{5D3}\u{5E2}\u{5E8}", 7, 1],
        ["\u{5D0}\u{5E4}", -1, 1],
        ["\u{5D0}\u{5E4}\u{5D9}\u{5E8}", 11, 1],
        ["\u{5D0}\u{5E7}\u{5E2}\u{5D2}\u{5E0}", -1, 1],
        ["\u{5D0}\u{5E8}\u{5D0}\u{5E4}", -1, 1],
        ["\u{5D0}\u{5E8}\u{5D5}\u{5DE}", -1, 1],
        ["\u{5D0}\u{5E8}\u{5D5}\u{5E0}\u{5D8}\u{5E2}\u{5E8}", -1, 1],
        ["\u{5D0}\u{5E8}\u{5D9}\u{5D1}\u{5E2}\u{5E8}", -1, 1],
        ["\u{5D0}\u{5E8}\u{5F1}\u{5E1}", -1, 1],
        ["\u{5D0}\u{5E8}\u{5F1}\u{5E4}", -1, 1],
        ["\u{5D0}\u{5E8}\u{5F2}\u{5E0}", -1, 1],
        ["\u{5D0}\u{5F0}\u{5E2}\u{5E7}", -1, 1],
        ["\u{5D0}\u{5F1}\u{5E1}", -1, 1],
        ["\u{5D0}\u{5F1}\u{5E4}", -1, 1],
        ["\u{5D0}\u{5F2}\u{5E0}", -1, 1],
        ["\u{5D1}\u{5D0}", -1, 1],
        ["\u{5D1}\u{5F2}", -1, 1],
        ["\u{5D3}\u{5D5}\u{5E8}\u{5DB}", -1, 1],
        ["\u{5D3}\u{5E2}\u{5E8}", -1, 1],
        ["\u{5DE}\u{5D9}\u{5D8}", -1, 1],
        ["\u{5E0}\u{5D0}\u{5DB}", -1, 1],
        ["\u{5E4}\u{5D0}\u{5E8}", -1, 1],
        ["\u{5E4}\u{5D0}\u{5E8}\u{5D1}\u{5F2}", 31, 1],
        ["\u{5E4}\u{5D0}\u{5E8}\u{5F1}\u{5E1}", 31, 1],
        ["\u{5E4}\u{5D5}\u{5E0}\u{5D0}\u{5E0}\u{5D3}\u{5E2}\u{5E8}", -1, 1],
        ["\u{5E6}\u{5D5}", -1, 1],
        ["\u{5E6}\u{5D5}\u{5D6}\u{5D0}\u{5DE}\u{5E2}\u{5E0}", 35, 1],
        ["\u{5E6}\u{5D5}\u{5E0}\u{5F1}\u{5E4}", 35, 1],
        ["\u{5E6}\u{5D5}\u{5E8}\u{5D9}\u{5E7}", 35, 1],
        ["\u{5E6}\u{5E2}", -1, 1]
    ];

    private const array A_2 = [
        ["\u{5D3}\u{5D6}\u{5E9}", -1, -1],
        ["\u{5E9}\u{5D8}\u{5E8}", -1, -1],
        ["\u{5E9}\u{5D8}\u{5E9}", -1, -1],
        ["\u{5E9}\u{5E4}\u{5E8}", -1, -1]
    ];

    private const array A_3 = [
        ["\u{5E7}\u{5DC}\u{5D9}\u{5D1}", -1, 9],
        ["\u{5E8}\u{5D9}\u{5D1}", -1, 10],
        ["\u{5D8}\u{5E8}\u{5D9}\u{5D1}", 1, 7],
        ["\u{5E9}\u{5E8}\u{5D9}\u{5D1}", 1, 15],
        ["\u{5D4}\u{5F1}\u{5D1}", -1, 23],
        ["\u{5E9}\u{5F0}\u{5D9}\u{5D2}", -1, 12],
        ["\u{5D2}\u{5D0}\u{5E0}\u{5D2}", -1, 1],
        ["\u{5D6}\u{5D5}\u{5E0}\u{5D2}", -1, 18],
        ["\u{5E9}\u{5DC}\u{5D5}\u{5E0}\u{5D2}", -1, 21],
        ["\u{5E6}\u{5F0}\u{5D5}\u{5E0}\u{5D2}", -1, 20],
        ["\u{5D1}\u{5F1}\u{5D2}", -1, 22],
        ["\u{5D1}\u{5D5}\u{5E0}\u{5D3}", -1, 16],
        ["\u{5F0}\u{5D9}\u{5D6}", -1, 6],
        ["\u{5D1}\u{5D9}\u{5D8}", -1, 4],
        ["\u{5DC}\u{5D9}\u{5D8}", -1, 8],
        ["\u{5DE}\u{5D9}\u{5D8}", -1, 3],
        ["\u{5E9}\u{5E0}\u{5D9}\u{5D8}", -1, 14],
        ["\u{5E0}\u{5D5}\u{5DE}", -1, 2],
        ["\u{5E9}\u{5D8}\u{5D0}\u{5E0}", -1, 25],
        ["\u{5D1}\u{5D9}\u{5E1}", -1, 5],
        ["\u{5E9}\u{5DE}\u{5D9}\u{5E1}", -1, 13],
        ["\u{5E8}\u{5D9}\u{5E1}", -1, 11],
        ["\u{5D8}\u{5E8}\u{5D5}\u{5E0}\u{5E7}", -1, 19],
        ["\u{5E4}\u{5D0}\u{5E8}\u{5DC}\u{5F1}\u{5E8}", -1, 24],
        ["\u{5E9}\u{5F0}\u{5F1}\u{5E8}", -1, 26],
        ["\u{5F0}\u{5D5}\u{5D8}\u{5E9}", -1, 17]
    ];

    private const array AS_3 = ["\u{5D2}\u{5F2}", "\u{5E0}\u{5E2}\u{5DE}", "\u{5DE}\u{5F2}\u{5D3}", "\u{5D1}\u{5F2}\u{5D8}", "\u{5D1}\u{5F2}\u{5E1}", "\u{5F0}\u{5F2}\u{5D6}", "\u{5D8}\u{5E8}\u{5F2}\u{5D1}", "\u{5DC}\u{5F2}\u{5D8}", "\u{5E7}\u{5DC}\u{5F2}\u{5D1}", "\u{5E8}\u{5F2}\u{5D1}", "\u{5E8}\u{5F2}\u{5E1}", "\u{5E9}\u{5F0}\u{5F2}\u{5D2}", "\u{5E9}\u{5DE}\u{5F2}\u{5E1}", "\u{5E9}\u{5E0}\u{5F2}\u{5D3}", "\u{5E9}\u{5E8}\u{5F2}\u{5D1}", "\u{5D1}\u{5D9}\u{5E0}\u{5D3}", "\u{5F0}\u{5D9}\u{5D8}\u{5E9}", "\u{5D6}\u{5D9}\u{5E0}\u{5D2}", "\u{5D8}\u{5E8}\u{5D9}\u{5E0}\u{5E7}", "\u{5E6}\u{5F0}\u{5D9}\u{5E0}\u{5D2}", "\u{5E9}\u{5DC}\u{5D9}\u{5E0}\u{5D2}", "\u{5D1}\u{5F2}\u{5D2}", "\u{5D4}\u{5F2}\u{5D1}", "\u{5E4}\u{5D0}\u{5E8}\u{5DC}\u{5D9}\u{5E8}", "\u{5E9}\u{5D8}\u{5F2}", "\u{5E9}\u{5F0}\u{5E2}\u{5E8}"];

    private const array A_4 = [
        ["\u{5D5}\u{5E0}\u{5D2}", -1, 1],
        ["\u{5E1}\u{5D8}\u{5D5}", -1, 1],
        ["\u{5D8}", -1, 1],
        ["\u{5D1}\u{5E8}\u{5D0}\u{5DB}\u{5D8}", 2, 31],
        ["\u{5E1}\u{5D8}", 2, 1],
        ["\u{5D9}\u{5E1}\u{5D8}", 4, 33],
        ["\u{5E2}\u{5D8}", 2, 1],
        ["\u{5E9}\u{5D0}\u{5E4}\u{5D8}", 2, 1],
        ["\u{5D4}\u{5F2}\u{5D8}", 2, 1],
        ["\u{5E7}\u{5F2}\u{5D8}", 2, 1],
        ["\u{5D9}\u{5E7}\u{5F2}\u{5D8}", 9, 1],
        ["\u{5DC}\u{5E2}\u{5DB}", -1, 1],
        ["\u{5E2}\u{5DC}\u{5E2}\u{5DB}", 11, 1],
        ["\u{5D9}\u{5D6}\u{5DE}", -1, 1],
        ["\u{5D9}\u{5DE}", -1, 1],
        ["\u{5E2}\u{5DE}", -1, 1],
        ["\u{5E2}\u{5E0}\u{5E2}\u{5DE}", 15, 3],
        ["\u{5D8}\u{5E2}\u{5E0}\u{5E2}\u{5DE}", 16, 4],
        ["\u{5E0}", -1, 1],
        ["\u{5E7}\u{5DC}\u{5D9}\u{5D1}\u{5E0}", 18, 14],
        ["\u{5E8}\u{5D9}\u{5D1}\u{5E0}", 18, 15],
        ["\u{5D8}\u{5E8}\u{5D9}\u{5D1}\u{5E0}", 20, 12],
        ["\u{5E9}\u{5E8}\u{5D9}\u{5D1}\u{5E0}", 20, 7],
        ["\u{5D4}\u{5F1}\u{5D1}\u{5E0}", 18, 27],
        ["\u{5E9}\u{5F0}\u{5D9}\u{5D2}\u{5E0}", 18, 17],
        ["\u{5D6}\u{5D5}\u{5E0}\u{5D2}\u{5E0}", 18, 22],
        ["\u{5E9}\u{5DC}\u{5D5}\u{5E0}\u{5D2}\u{5E0}", 18, 25],
        ["\u{5E6}\u{5F0}\u{5D5}\u{5E0}\u{5D2}\u{5E0}", 18, 24],
        ["\u{5D1}\u{5F1}\u{5D2}\u{5E0}", 18, 26],
        ["\u{5D1}\u{5D5}\u{5E0}\u{5D3}\u{5E0}", 18, 20],
        ["\u{5F0}\u{5D9}\u{5D6}\u{5E0}", 18, 11],
        ["\u{5D8}\u{5E0}", 18, 4],
        ["GE\u{5D1}\u{5D9}\u{5D8}\u{5E0}", 31, 9],
        ["GE\u{5DC}\u{5D9}\u{5D8}\u{5E0}", 31, 13],
        ["GE\u{5DE}\u{5D9}\u{5D8}\u{5E0}", 31, 8],
        ["\u{5E9}\u{5E0}\u{5D9}\u{5D8}\u{5E0}", 31, 19],
        ["\u{5E1}\u{5D8}\u{5E0}", 31, 1],
        ["\u{5D9}\u{5E1}\u{5D8}\u{5E0}", 36, 1],
        ["\u{5E2}\u{5D8}\u{5E0}", 31, 1],
        ["GE\u{5D1}\u{5D9}\u{5E1}\u{5E0}", 18, 10],
        ["\u{5E9}\u{5DE}\u{5D9}\u{5E1}\u{5E0}", 18, 18],
        ["GE\u{5E8}\u{5D9}\u{5E1}\u{5E0}", 18, 16],
        ["\u{5E2}\u{5E0}", 18, 1],
        ["\u{5D2}\u{5D0}\u{5E0}\u{5D2}\u{5E2}\u{5E0}", 42, 5],
        ["\u{5E2}\u{5DC}\u{5E2}\u{5E0}", 42, 1],
        ["\u{5E0}\u{5D5}\u{5DE}\u{5E2}\u{5E0}", 42, 6],
        ["\u{5D9}\u{5D6}\u{5DE}\u{5E2}\u{5E0}", 42, 1],
        ["\u{5E9}\u{5D8}\u{5D0}\u{5E0}\u{5E2}\u{5E0}", 42, 29],
        ["\u{5D8}\u{5E8}\u{5D5}\u{5E0}\u{5E7}\u{5E0}", 18, 23],
        ["\u{5E4}\u{5D0}\u{5E8}\u{5DC}\u{5F1}\u{5E8}\u{5E0}", 18, 28],
        ["\u{5E9}\u{5F0}\u{5F1}\u{5E8}\u{5E0}", 18, 30],
        ["\u{5F0}\u{5D5}\u{5D8}\u{5E9}\u{5E0}", 18, 21],
        ["\u{5D2}\u{5F2}\u{5E0}", 18, 5],
        ["\u{5E1}", -1, 1],
        ["\u{5D8}\u{5E1}", 53, 4],
        ["\u{5E2}\u{5D8}\u{5E1}", 54, 1],
        ["\u{5E0}\u{5E1}", 53, 1],
        ["\u{5D8}\u{5E0}\u{5E1}", 56, 4],
        ["\u{5E2}\u{5E0}\u{5E1}", 56, 3],
        ["\u{5E2}\u{5E1}", 53, 1],
        ["\u{5D9}\u{5E2}\u{5E1}", 59, 2],
        ["\u{5E2}\u{5DC}\u{5E2}\u{5E1}", 59, 1],
        ["\u{5E2}\u{5E8}\u{5E1}", 53, 1],
        ["\u{5E2}\u{5E0}\u{5E2}\u{5E8}\u{5E1}", 62, 1],
        ["\u{5E2}", -1, 1],
        ["\u{5D8}\u{5E2}", 64, 4],
        ["\u{5E1}\u{5D8}\u{5E2}", 65, 1],
        ["\u{5E2}\u{5D8}\u{5E2}", 65, 1],
        ["\u{5D9}\u{5E2}", 64, -1],
        ["\u{5E2}\u{5DC}\u{5E2}", 64, 1],
        ["\u{5E2}\u{5E0}\u{5E2}", 64, 3],
        ["\u{5D8}\u{5E2}\u{5E0}\u{5E2}", 70, 4],
        ["\u{5E2}\u{5E8}", -1, 1],
        ["\u{5D8}\u{5E2}\u{5E8}", 72, 4],
        ["\u{5E1}\u{5D8}\u{5E2}\u{5E8}", 73, 1],
        ["\u{5E2}\u{5D8}\u{5E2}\u{5E8}", 73, 1],
        ["\u{5E2}\u{5E0}\u{5E2}\u{5E8}", 72, 3],
        ["\u{5D8}\u{5E2}\u{5E0}\u{5E2}\u{5E8}", 76, 4],
        ["\u{5D5}\u{5EA}", -1, 32]
    ];

    private const array A_5 = [
        ["\u{5D5}\u{5E0}\u{5D2}", -1, 1],
        ["\u{5E9}\u{5D0}\u{5E4}\u{5D8}", -1, 1],
        ["\u{5D4}\u{5F2}\u{5D8}", -1, 1],
        ["\u{5E7}\u{5F2}\u{5D8}", -1, 1],
        ["\u{5D9}\u{5E7}\u{5F2}\u{5D8}", 3, 1],
        ["\u{5DC}", -1, 2]
    ];

    private const array A_6 = [
        ["\u{5D9}\u{5D2}", -1, 1],
        ["\u{5D9}\u{5E7}", -1, 1],
        ["\u{5D3}\u{5D9}\u{5E7}", 1, 1],
        ["\u{5E0}\u{5D3}\u{5D9}\u{5E7}", 2, 1],
        ["\u{5E2}\u{5E0}\u{5D3}\u{5D9}\u{5E7}", 3, 1],
        ["\u{5D1}\u{5DC}\u{5D9}\u{5E7}", 1, -1],
        ["\u{5D2}\u{5DC}\u{5D9}\u{5E7}", 1, -1],
        ["\u{5E0}\u{5D9}\u{5E7}", 1, 1],
        ["\u{5D9}\u{5E9}", -1, 1]
    ];

    private const array G_niked = ["\u{5B0}"=>true, "\u{5B1}"=>true, "\u{5B2}"=>true, "\u{5B3}"=>true, "\u{5B4}"=>true, "\u{5B5}"=>true, "\u{5B6}"=>true, "\u{5B7}"=>true, "\u{5B8}"=>true, "\u{5B9}"=>true, "\u{5BB}"=>true, "\u{5BC}"=>true, "\u{5BF}"=>true, "\u{5C1}"=>true, "\u{5C2}"=>true];

    private const array G_vowel = ["\u{5D0}"=>true, "\u{5D5}"=>true, "\u{5D9}"=>true, "\u{5E2}"=>true, "\u{5F1}"=>true, "\u{5F2}"=>true];

    private const array G_consonant = ["\u{5D1}"=>true, "\u{5D2}"=>true, "\u{5D3}"=>true, "\u{5D4}"=>true, "\u{5D6}"=>true, "\u{5D7}"=>true, "\u{5D8}"=>true, "\u{5DA}"=>true, "\u{5DB}"=>true, "\u{5DC}"=>true, "\u{5DD}"=>true, "\u{5DE}"=>true, "\u{5DF}"=>true, "\u{5E0}"=>true, "\u{5E1}"=>true, "\u{5E3}"=>true, "\u{5E4}"=>true, "\u{5E5}"=>true, "\u{5E6}"=>true, "\u{5E7}"=>true, "\u{5E8}"=>true, "\u{5E9}"=>true, "\u{5EA}"=>true, "\u{5F0}"=>true];



    public function stem(): bool
    {
        $v_1 = $this->cursor;
        while (true) {
            $v_2 = $this->cursor;
            while (true) {
                $v_3 = $this->cursor;
                $this->bra = $this->cursor;
                $among_var = $this->find_among(self::A_0);
                if (0 === $among_var) {
                    goto lab3;
                }
                $this->ket = $this->cursor;
                switch ($among_var) {
                    case 1:
                        if (!($this->eq_s("\u{5BC}"))) {
                            goto lab4;
                        }
                        goto lab3;
                    lab4:
                        $this->slice_from("\u{5F0}");
                        break;
                    case 2:
                        if (!($this->eq_s("\u{5B4}"))) {
                            goto lab5;
                        }
                        goto lab3;
                    lab5:
                        $this->slice_from("\u{5F1}");
                        break;
                    case 3:
                        if (!($this->eq_s("\u{5B4}"))) {
                            goto lab6;
                        }
                        goto lab3;
                    lab6:
                        $this->slice_from("\u{5F2}");
                        break;
                    case 4:
                        $this->slice_from("\u{5DB}");
                        break;
                    case 5:
                        $this->slice_from("\u{5DE}");
                        break;
                    case 6:
                        $this->slice_from("\u{5E0}");
                        break;
                    case 7:
                        $this->slice_from("\u{5E4}");
                        break;
                    case 8:
                        $this->slice_from("\u{5E6}");
                        break;
                }
                $this->cursor = $v_3;
                break;
            lab3:
                $this->cursor = $v_3;
                if ($this->cursor >= $this->limit) {
                    goto lab2;
                }
                $this->inc_cursor();
            }
            continue;
        lab2:
            $this->cursor = $v_2;
            break;
        }
    lab1:
        $this->cursor = $v_1;
        $v_4 = $this->cursor;
        while (true) {
            $v_5 = $this->cursor;
            while (true) {
                $v_6 = $this->cursor;
                $this->bra = $this->cursor;
                if (!($this->in_grouping(self::G_niked))) {
                    goto lab9;
                }
                $this->ket = $this->cursor;
                $this->slice_del();
                $this->cursor = $v_6;
                break;
            lab9:
                $this->cursor = $v_6;
                if ($this->cursor >= $this->limit) {
                    goto lab8;
                }
                $this->inc_cursor();
            }
            continue;
        lab8:
            $this->cursor = $v_5;
            break;
        }
    lab7:
        $this->cursor = $v_4;
    lab0:
        $v_7 = $this->cursor;
        $I_p1 = $this->limit;
        $v_8 = $this->cursor;
        $this->bra = $this->cursor;
        if (!($this->eq_s("\u{5D2}\u{5E2}"))) {
            $this->cursor = $v_8;
            goto lab11;
        }
        $this->ket = $this->cursor;
        $v_9 = $this->cursor;
        if (!($this->eq_s("\u{5DC}\u{5D8}"))) {
            goto lab13;
        }
        goto lab14;
    lab13:
        if (!($this->eq_s("\u{5D1}\u{5E0}"))) {
            goto lab15;
        }
        goto lab14;
    lab15:
        if ($this->cursor < $this->limit) {
            goto lab12;
        }
    lab14:
        $this->cursor = $v_8;
        goto lab11;
    lab12:
        $this->cursor = $v_9;
        $this->slice_from("GE");
    lab11:
        $v_10 = $this->cursor;
        if ($this->find_among(self::A_1) === 0) {
            $this->cursor = $v_10;
            goto lab16;
        }
        $v_11 = $this->cursor;
        $v_12 = $this->cursor;
        if (!($this->eq_s("\u{5E6}\u{5D5}\u{5D2}\u{5E0}"))) {
            goto lab18;
        }
        goto lab19;
    lab18:
        if (!($this->eq_s("\u{5E6}\u{5D5}\u{5E7}\u{5D8}"))) {
            goto lab20;
        }
        goto lab19;
    lab20:
        if (!($this->eq_s("\u{5E6}\u{5D5}\u{5E7}\u{5E0}"))) {
            goto lab17;
        }
    lab19:
        if ($this->cursor < $this->limit) {
            goto lab17;
        }
        $this->cursor = $v_12;
        goto lab21;
    lab17:
        $this->cursor = $v_11;
        $v_13 = $this->cursor;
        if (!($this->eq_s("\u{5D2}\u{5E2}\u{5D1}\u{5E0}"))) {
            goto lab22;
        }
        $this->cursor = $v_13;
        goto lab21;
    lab22:
        $this->cursor = $v_11;
        $this->bra = $this->cursor;
        if (!($this->eq_s("\u{5D2}\u{5E2}"))) {
            goto lab23;
        }
        $this->ket = $this->cursor;
        $this->slice_from("GE");
        goto lab21;
    lab23:
        $this->cursor = $v_11;
        $this->bra = $this->cursor;
        if (!($this->eq_s("\u{5E6}\u{5D5}"))) {
            $this->cursor = $v_10;
            goto lab16;
        }
        $this->ket = $this->cursor;
        $this->slice_from("TSU");
    lab21:
    lab16:
        $v_14 = $this->cursor;
        if (!$this->hop(3)) {
            goto lab10;
        }
        $I_x = $this->cursor;
        $this->cursor = $v_14;
        $v_15 = $this->cursor;
        if ($this->find_among(self::A_2) === 0) {
            $this->cursor = $v_15;
            goto lab24;
        }
    lab24:
        $v_16 = $this->cursor;
        if (!($this->in_grouping(self::G_consonant))) {
            goto lab25;
        }
        if (!($this->in_grouping(self::G_consonant))) {
            goto lab25;
        }
        if (!($this->in_grouping(self::G_consonant))) {
            goto lab25;
        }
        $I_p1 = $this->cursor;
        goto lab10;
    lab25:
        $this->cursor = $v_16;
        if (!$this->go_out_grouping(self::G_vowel)) {
            goto lab10;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_vowel)) {
            goto lab10;
        }
        $I_p1 = $this->cursor;
        if ($I_p1 >= $I_x) {
            goto lab26;
        }
        $I_p1 = $I_x;
    lab26:
    lab10:
        $this->cursor = $v_7;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_17 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab28;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p1 > $this->cursor) {
                    goto lab28;
                }
                $this->slice_del();
                break;
            case 2:
                if ($I_p1 > $this->cursor) {
                    goto lab28;
                }
                $this->slice_from("\u{5D9}\u{5E2}");
                break;
            case 3:
                if ($I_p1 > $this->cursor) {
                    goto lab28;
                }
                $this->slice_del();
                $this->ket = $this->cursor;
                $among_var = $this->find_among_b(self::A_3);
                if (0 === $among_var) {
                    goto lab28;
                }
                $this->bra = $this->cursor;
                $this->slice_from(self::AS_3[$among_var - 1]);
                break;
            case 4:
                $v_18 = $this->limit - $this->cursor;
                if ($I_p1 > $this->cursor) {
                    goto lab29;
                }
                $this->slice_del();
                goto lab30;
            lab29:
                $this->cursor = $this->limit - $v_18;
                $this->slice_from("\u{5D8}");
            lab30:
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("\u{5D1}\u{5E8}\u{5D0}\u{5DB}"))) {
                    goto lab28;
                }
                $v_19 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("\u{5D2}\u{5E2}"))) {
                    $this->cursor = $this->limit - $v_19;
                    goto lab31;
                }
            lab31:
                $this->bra = $this->cursor;
                $this->slice_from("\u{5D1}\u{5E8}\u{5E2}\u{5E0}\u{5D2}");
                break;
            case 5:
                $this->slice_from("\u{5D2}\u{5F2}");
                break;
            case 6:
                $this->slice_from("\u{5E0}\u{5E2}\u{5DE}");
                break;
            case 7:
                $this->slice_from("\u{5E9}\u{5E8}\u{5F2}\u{5D1}");
                break;
            case 8:
                $this->slice_from("\u{5DE}\u{5F2}\u{5D3}");
                break;
            case 9:
                $this->slice_from("\u{5D1}\u{5F2}\u{5D8}");
                break;
            case 10:
                $this->slice_from("\u{5D1}\u{5F2}\u{5E1}");
                break;
            case 11:
                $this->slice_from("\u{5F0}\u{5F2}\u{5D6}");
                break;
            case 12:
                $this->slice_from("\u{5D8}\u{5E8}\u{5F2}\u{5D1}");
                break;
            case 13:
                $this->slice_from("\u{5DC}\u{5F2}\u{5D8}");
                break;
            case 14:
                $this->slice_from("\u{5E7}\u{5DC}\u{5F2}\u{5D1}");
                break;
            case 15:
                $this->slice_from("\u{5E8}\u{5F2}\u{5D1}");
                break;
            case 16:
                $this->slice_from("\u{5E8}\u{5F2}\u{5E1}");
                break;
            case 17:
                $this->slice_from("\u{5E9}\u{5F0}\u{5F2}\u{5D2}");
                break;
            case 18:
                $this->slice_from("\u{5E9}\u{5DE}\u{5F2}\u{5E1}");
                break;
            case 19:
                $this->slice_from("\u{5E9}\u{5E0}\u{5F2}\u{5D3}");
                break;
            case 20:
                $this->slice_from("\u{5D1}\u{5D9}\u{5E0}\u{5D3}");
                break;
            case 21:
                $this->slice_from("\u{5F0}\u{5D9}\u{5D8}\u{5E9}");
                break;
            case 22:
                $this->slice_from("\u{5D6}\u{5D9}\u{5E0}\u{5D2}");
                break;
            case 23:
                $this->slice_from("\u{5D8}\u{5E8}\u{5D9}\u{5E0}\u{5E7}");
                break;
            case 24:
                $this->slice_from("\u{5E6}\u{5F0}\u{5D9}\u{5E0}\u{5D2}");
                break;
            case 25:
                $this->slice_from("\u{5E9}\u{5DC}\u{5D9}\u{5E0}\u{5D2}");
                break;
            case 26:
                $this->slice_from("\u{5D1}\u{5F2}\u{5D2}");
                break;
            case 27:
                $this->slice_from("\u{5D4}\u{5F2}\u{5D1}");
                break;
            case 28:
                $this->slice_from("\u{5E4}\u{5D0}\u{5E8}\u{5DC}\u{5D9}\u{5E8}");
                break;
            case 29:
                $this->slice_from("\u{5E9}\u{5D8}\u{5F2}");
                break;
            case 30:
                $this->slice_from("\u{5E9}\u{5F0}\u{5E2}\u{5E8}");
                break;
            case 31:
                $this->slice_from("\u{5D1}\u{5E8}\u{5E2}\u{5E0}\u{5D2}");
                break;
            case 32:
                if ($I_p1 > $this->cursor) {
                    goto lab28;
                }
                $this->slice_from("\u{5D4}");
                break;
            case 33:
                $v_20 = $this->limit - $this->cursor;
                if (!($this->eq_s_b("\u{5D2}"))) {
                    goto lab33;
                }
                goto lab34;
            lab33:
                if (!($this->eq_s_b("\u{5E9}"))) {
                    goto lab32;
                }
            lab34:
                $v_21 = $this->limit - $this->cursor;
                if ($I_p1 > ($this->cursor + 6)) {
                    $this->cursor = $this->limit - $v_21;
                    goto lab35;
                }
                $this->slice_from("\u{5D9}\u{5E1}");
            lab35:
                goto lab36;
            lab32:
                $this->cursor = $this->limit - $v_20;
                if ($I_p1 > $this->cursor) {
                    goto lab28;
                }
                $this->slice_del();
            lab36:
                break;
        }
    lab28:
        $this->cursor = $this->limit - $v_17;
        $v_22 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_5);
        if (0 === $among_var) {
            goto lab37;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p1 > $this->cursor) {
                    goto lab37;
                }
                $this->slice_del();
                break;
            case 2:
                if ($I_p1 > $this->cursor) {
                    goto lab37;
                }
                if (!($this->in_grouping_b(self::G_consonant))) {
                    goto lab37;
                }
                $this->slice_del();
                break;
        }
    lab37:
        $this->cursor = $this->limit - $v_22;
        $v_23 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_6);
        if (0 === $among_var) {
            goto lab38;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p1 > $this->cursor) {
                    goto lab38;
                }
                $this->slice_del();
                break;
        }
    lab38:
        $this->cursor = $this->limit - $v_23;
        $v_24 = $this->limit - $this->cursor;
        while (true) {
            $v_25 = $this->limit - $this->cursor;
            while (true) {
                $v_26 = $this->limit - $this->cursor;
                $this->ket = $this->cursor;
                if (!($this->eq_s_b("GE"))) {
                    goto lab42;
                }
                goto lab43;
            lab42:
                if (!($this->eq_s_b("TSU"))) {
                    goto lab41;
                }
            lab43:
                $this->bra = $this->cursor;
                $this->slice_del();
                $this->cursor = $this->limit - $v_26;
                break;
            lab41:
                $this->cursor = $this->limit - $v_26;
                if ($this->cursor <= $this->limit_backward) {
                    goto lab40;
                }
                $this->dec_cursor();
            }
            continue;
        lab40:
            $this->cursor = $this->limit - $v_25;
            break;
        }
    lab39:
        $this->cursor = $this->limit - $v_24;
    lab27:
        $this->cursor = $this->limit_backward;
        return true;
    }
}
