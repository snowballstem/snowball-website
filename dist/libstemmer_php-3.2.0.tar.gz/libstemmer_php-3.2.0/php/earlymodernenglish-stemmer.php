<?php
// Generated from earlymodernenglish.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballEarlymodernenglishStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["", -1, 4],
        ["\u{E6}", 0, 1],
        ["\u{153}", 0, 2],
        ["\u{17F}", 0, 3]
    ];

    private const array A_1 = [
        ["o'er", -1, 1],
        ["t'", -1, 2],
        ["th'", -1, 2]
    ];

    private const array A_2 = [
        ["arsen", -1, -1],
        ["commun", -1, -1],
        ["emerg", -1, -1],
        ["gener", -1, -1],
        ["inter", -1, -1],
        ["later", -1, -1],
        ["organ", -1, -1],
        ["past", -1, -1],
        ["univers", -1, -1]
    ];

    private const array A_3 = [
        ["'", -1, 1],
        ["'s'", 0, 1],
        ["'s", -1, 1]
    ];

    private const array A_4 = [
        ["ied", -1, 2],
        ["lie", -1, 5],
        ["e'er", -1, 4],
        ["s", -1, 3],
        ["ies", 3, 2],
        ["sses", 3, 1],
        ["ss", 3, -1],
        ["us", 3, -1]
    ];

    private const array A_5 = [
        ["succ", -1, 1],
        ["proc", -1, 1],
        ["exc", -1, 1]
    ];

    private const array A_6 = [
        ["even", -1, 2],
        ["cann", -1, 2],
        ["inn", -1, 2],
        ["earr", -1, 2],
        ["herr", -1, 2],
        ["out", -1, 2],
        ["y", -1, 1]
    ];

    private const array A_7 = [
        ["", -1, -1],
        ["'d", 0, 2],
        ["ed", 0, 2],
        ["eed", 2, 1],
        ["ing", 0, 3],
        ["eth", 0, 2],
        ["'t", 0, 2],
        ["'st", 0, 2],
        ["'dst", 0, 2],
        ["edst", 0, 2],
        ["est", 0, 2],
        ["'dly", 0, 2],
        ["edly", 0, 2],
        ["eedly", 12, 1],
        ["ingly", 0, 2]
    ];

    private const array A_8 = [
        ["", -1, 3],
        ["bb", 0, 2],
        ["dd", 0, 2],
        ["ff", 0, 2],
        ["gg", 0, 2],
        ["bl", 0, 1],
        ["mm", 0, 2],
        ["nn", 0, 2],
        ["pp", 0, 2],
        ["rr", 0, 2],
        ["at", 0, 1],
        ["tt", 0, 2],
        ["iz", 0, 1]
    ];

    private const array A_9 = [
        ["anci", -1, 3],
        ["enci", -1, 2],
        ["ogi", -1, 14],
        ["li", -1, 16],
        ["bli", 3, 12],
        ["abli", 4, 4],
        ["alli", 3, 8],
        ["fulli", 3, 9],
        ["lessli", 3, 15],
        ["ousli", 3, 10],
        ["entli", 3, 5],
        ["aliti", -1, 8],
        ["biliti", -1, 12],
        ["iviti", -1, 11],
        ["tional", -1, 1],
        ["ational", 14, 7],
        ["alism", -1, 8],
        ["ation", -1, 7],
        ["ization", 17, 6],
        ["izer", -1, 6],
        ["ator", -1, 7],
        ["iveness", -1, 11],
        ["fulness", -1, 9],
        ["ousness", -1, 10],
        ["ogist", -1, 13]
    ];

    private const array A_10 = [
        ["icate", -1, 4],
        ["ative", -1, 6],
        ["alize", -1, 3],
        ["iciti", -1, 4],
        ["ical", -1, 4],
        ["tional", -1, 1],
        ["ational", 5, 2],
        ["ful", -1, 5],
        ["ness", -1, 5]
    ];

    private const array A_11 = [
        ["ic", -1, 1],
        ["ance", -1, 1],
        ["ence", -1, 1],
        ["able", -1, 1],
        ["ible", -1, 1],
        ["ate", -1, 1],
        ["ive", -1, 1],
        ["ize", -1, 1],
        ["iti", -1, 1],
        ["al", -1, 1],
        ["ism", -1, 1],
        ["ion", -1, 2],
        ["er", -1, 1],
        ["ous", -1, 1],
        ["ant", -1, 1],
        ["ent", -1, 1],
        ["ment", 15, 1],
        ["ement", 16, 1]
    ];

    private const array A_12 = [
        ["'nd", -1, 3],
        ["e", -1, 1],
        ["'li", -1, 6],
        ["'ri", -1, 5],
        ["l", -1, 2],
        ["'n", -1, 3],
        ["'r", -1, 4],
        ["'rous", -1, 4]
    ];

    private const array A_13 = [
        ["andes", -1, -1],
        ["atlas", -1, -1],
        ["bias", -1, -1],
        ["cosmos", -1, -1],
        ["early", -1, 6],
        ["gently", -1, 4],
        ["howe", -1, -1],
        ["idly", -1, 3],
        ["news", -1, -1],
        ["only", -1, 7],
        ["singly", -1, 8],
        ["skies", -1, 2],
        ["skis", -1, 1],
        ["sky", -1, -1],
        ["ugly", -1, 5]
    ];

    private const array AS_13 = ["ski", "sky", "idl", "gentl", "ugli", "earli", "onli", "singl"];

    private const array G_aeo = ["a"=>true, "e"=>true, "o"=>true];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true];

    private const array G_v_WXY = ["Y"=>true, "a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "w"=>true, "x"=>true, "y"=>true];

    private const array G_valid_LI = ["c"=>true, "d"=>true, "e"=>true, "g"=>true, "h"=>true, "k"=>true, "m"=>true, "n"=>true, "r"=>true, "t"=>true];



    protected function r_shortv(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        if (!($this->out_grouping_b(self::G_v_WXY))) {
            goto lab0;
        }
        if (!($this->in_grouping_b(self::G_v))) {
            goto lab0;
        }
        if (!($this->out_grouping_b(self::G_v))) {
            goto lab0;
        }
        goto lab1;
    lab0:
        $this->cursor = $this->limit - $v_1;
        if (!($this->out_grouping_b(self::G_v))) {
            goto lab2;
        }
        if (!($this->in_grouping_b(self::G_v))) {
            goto lab2;
        }
        if ($this->cursor > $this->limit_backward) {
            goto lab2;
        }
        goto lab1;
    lab2:
        $this->cursor = $this->limit - $v_1;
        if (!($this->eq_s_b("past"))) {
            return false;
        }
    lab1:
        return true;
    }


    public function stem(): bool
    {
        $v_1 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_13);
        if (0 === $among_var) {
            goto lab0;
        }
        $this->ket = $this->cursor;
        if ($this->cursor < $this->limit) {
            goto lab0;
        }
        if ($among_var > 0) {
            $this->slice_from(self::AS_13[$among_var - 1]);
        }
        goto lab1;
    lab0:
        $this->cursor = $v_1;
        if (!$this->hop(3)) {
            goto lab3;
        }
        goto lab2;
    lab3:
        goto lab1;
    lab2:
        $this->cursor = $v_1;
        $v_2 = $this->cursor;
        while (true) {
            $v_3 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_0);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("ae");
                    break;
                case 2:
                    $this->slice_from("oe");
                    break;
                case 3:
                    $this->slice_from("s");
                    break;
                case 4:
                    if ($this->cursor >= $this->limit) {
                        goto lab6;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab6:
            $this->cursor = $v_3;
            break;
        }
    lab5:
        $this->cursor = $v_2;
        $B_Y_found = false;
        $v_4 = $this->cursor;
        $this->bra = $this->cursor;
        if (!($this->eq_s("'"))) {
            goto lab7;
        }
        $this->ket = $this->cursor;
        $this->slice_del();
    lab7:
        $this->cursor = $v_4;
        $v_5 = $this->cursor;
        $this->bra = $this->cursor;
        if (!($this->eq_s("y"))) {
            goto lab8;
        }
        $this->ket = $this->cursor;
        $this->slice_from("Y");
        $B_Y_found = true;
    lab8:
        $this->cursor = $v_5;
        $v_6 = $this->cursor;
        while (true) {
            $v_7 = $this->cursor;
            while (true) {
                $v_8 = $this->cursor;
                if (!($this->in_grouping(self::G_v))) {
                    goto lab11;
                }
                $this->bra = $this->cursor;
                if (!($this->eq_s("y"))) {
                    goto lab11;
                }
                $this->ket = $this->cursor;
                $this->cursor = $v_8;
                break;
            lab11:
                $this->cursor = $v_8;
                if ($this->cursor >= $this->limit) {
                    goto lab10;
                }
                $this->inc_cursor();
            }
            $this->slice_from("Y");
            $B_Y_found = true;
            continue;
        lab10:
            $this->cursor = $v_7;
            break;
        }
    lab9:
        $this->cursor = $v_6;
    lab4:
        $v_9 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_1);
        if (0 === $among_var) {
            goto lab12;
        }
        $this->ket = $this->cursor;
        switch ($among_var) {
            case 1:
                $this->slice_from("over");
                break;
            case 2:
                if ($this->cursor >= $this->limit) {
                    goto lab12;
                }
                $this->slice_del();
                break;
        }
    lab12:
        $this->cursor = $v_9;
        $I_p1 = $this->limit;
        $I_p2 = $this->limit;
        $v_10 = $this->cursor;
        $v_11 = $this->cursor;
        if ($this->find_among(self::A_2) === 0) {
            goto lab15;
        }
        goto lab16;
    lab15:
        $this->cursor = $v_11;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab14;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab14;
        }
        $this->inc_cursor();
    lab16:
        $I_p1 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab14;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab14;
        }
        $this->inc_cursor();
        $I_p2 = $this->cursor;
    lab14:
        $this->cursor = $v_10;
    lab13:
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_12 = $this->limit - $this->cursor;
        $v_13 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_3) === 0) {
            $this->cursor = $this->limit - $v_13;
            goto lab18;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
    lab18:
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            goto lab17;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $this->slice_from("ss");
                break;
            case 2:
                $v_14 = $this->limit - $this->cursor;
                if (!$this->hop_back(2)) {
                    goto lab19;
                }
                $this->slice_from("i");
                goto lab20;
            lab19:
                $this->cursor = $this->limit - $v_14;
                $this->slice_from("ie");
            lab20:
                break;
            case 3:
                if ($this->cursor <= $this->limit_backward) {
                    goto lab17;
                }
                $this->dec_cursor();
                if (!$this->go_out_grouping_b(self::G_v)) {
                    goto lab17;
                }
                $this->dec_cursor();
                $this->slice_del();
                break;
            case 4:
                $this->slice_from("ever");
                break;
            case 5:
                if ($I_p1 > $this->cursor) {
                    goto lab17;
                }
                $this->slice_from("ly");
                break;
        }
    lab17:
        $this->cursor = $this->limit - $v_12;
        $v_15 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_7);
        $this->bra = $this->cursor;
        $v_16 = $this->limit - $this->cursor;
        switch ($among_var) {
            case 1:
                $v_17 = $this->limit - $this->cursor;
                if ($I_p1 > $this->cursor) {
                    goto lab23;
                }
                $v_18 = $this->limit - $this->cursor;
                if ($this->find_among_b(self::A_5) === 0) {
                    goto lab24;
                }
                if ($this->cursor > $this->limit_backward) {
                    goto lab24;
                }
                goto lab25;
            lab24:
                $this->cursor = $this->limit - $v_18;
                $this->slice_from("ee");
            lab25:
            lab23:
                $this->cursor = $this->limit - $v_17;
                break;
            case 2:
                goto lab22;
            case 3:
                $among_var = $this->find_among_b(self::A_6);
                if (0 === $among_var) {
                    goto lab22;
                }
                switch ($among_var) {
                    case 1:
                        $v_19 = $this->limit - $this->cursor;
                        if (!($this->out_grouping_b(self::G_v))) {
                            goto lab22;
                        }
                        if ($this->cursor > $this->limit_backward) {
                            goto lab22;
                        }
                        $this->cursor = $this->limit - $v_19;
                        $this->bra = $this->cursor;
                        $this->slice_from("ie");
                        break;
                    case 2:
                        if ($this->cursor > $this->limit_backward) {
                            goto lab22;
                        }
                        break;
                }
                break;
        }
        goto lab26;
    lab22:
        $this->cursor = $this->limit - $v_16;
        $v_20 = $this->limit - $this->cursor;
        if (!$this->go_out_grouping_b(self::G_v)) {
            goto lab21;
        }
        $this->dec_cursor();
        $this->cursor = $this->limit - $v_20;
        $this->slice_del();
        $this->ket = $this->cursor;
        $this->bra = $this->cursor;
        $v_21 = $this->limit - $this->cursor;
        $among_var = $this->find_among_b(self::A_8);
        switch ($among_var) {
            case 1:
                $this->slice_from("e");
                goto lab21;
            case 2:
                $v_22 = $this->limit - $this->cursor;
                if (!($this->in_grouping_b(self::G_aeo))) {
                    goto lab27;
                }
                if ($this->cursor > $this->limit_backward) {
                    goto lab27;
                }
                goto lab21;
            lab27:
                $this->cursor = $this->limit - $v_22;
                break;
            case 3:
                if ($this->cursor !== $I_p1) {
                    goto lab21;
                }
                $v_23 = $this->limit - $this->cursor;
                if (!$this->r_shortv()) {
                    goto lab21;
                }
                $this->cursor = $this->limit - $v_23;
                $this->slice_from("e");
                goto lab21;
        }
        $this->cursor = $this->limit - $v_21;
        $this->ket = $this->cursor;
        if ($this->cursor <= $this->limit_backward) {
            goto lab21;
        }
        $this->dec_cursor();
        $this->bra = $this->cursor;
        $this->slice_del();
    lab26:
    lab21:
        $this->cursor = $this->limit - $v_15;
        $v_24 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("y"))) {
            goto lab29;
        }
        goto lab30;
    lab29:
        if (!($this->eq_s_b("Y"))) {
            goto lab28;
        }
    lab30:
        $this->bra = $this->cursor;
        if (!($this->out_grouping_b(self::G_v))) {
            goto lab28;
        }
        if ($this->cursor <= $this->limit_backward) {
            goto lab28;
        }
        $this->slice_from("i");
    lab28:
        $this->cursor = $this->limit - $v_24;
        $v_25 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_9);
        if (0 === $among_var) {
            goto lab31;
        }
        $this->bra = $this->cursor;
        if ($I_p1 > $this->cursor) {
            goto lab31;
        }
        switch ($among_var) {
            case 1:
                $this->slice_from("tion");
                break;
            case 2:
                $this->slice_from("ence");
                break;
            case 3:
                $this->slice_from("ance");
                break;
            case 4:
                $this->slice_from("able");
                break;
            case 5:
                $this->slice_from("ent");
                break;
            case 6:
                $this->slice_from("ize");
                break;
            case 7:
                $this->slice_from("ate");
                break;
            case 8:
                $this->slice_from("al");
                break;
            case 9:
                $this->slice_from("ful");
                break;
            case 10:
                $this->slice_from("ous");
                break;
            case 11:
                $this->slice_from("ive");
                break;
            case 12:
                $this->slice_from("ble");
                break;
            case 13:
                $this->slice_from("og");
                break;
            case 14:
                if (!($this->eq_s_b("l"))) {
                    goto lab31;
                }
                $this->slice_from("og");
                break;
            case 15:
                $this->slice_from("less");
                break;
            case 16:
                if (!($this->in_grouping_b(self::G_valid_LI))) {
                    goto lab31;
                }
                $this->slice_del();
                break;
        }
    lab31:
        $this->cursor = $this->limit - $v_25;
        $v_26 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_10);
        if (0 === $among_var) {
            goto lab32;
        }
        $this->bra = $this->cursor;
        if ($I_p1 > $this->cursor) {
            goto lab32;
        }
        switch ($among_var) {
            case 1:
                $this->slice_from("tion");
                break;
            case 2:
                $this->slice_from("ate");
                break;
            case 3:
                $this->slice_from("al");
                break;
            case 4:
                $this->slice_from("ic");
                break;
            case 5:
                $this->slice_del();
                break;
            case 6:
                if ($I_p2 > $this->cursor) {
                    goto lab32;
                }
                $this->slice_del();
                break;
        }
    lab32:
        $this->cursor = $this->limit - $v_26;
        $v_27 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_11);
        if (0 === $among_var) {
            goto lab33;
        }
        $this->bra = $this->cursor;
        if ($I_p2 > $this->cursor) {
            goto lab33;
        }
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                if (!($this->eq_s_b("s"))) {
                    goto lab34;
                }
                goto lab35;
            lab34:
                if (!($this->eq_s_b("t"))) {
                    goto lab33;
                }
            lab35:
                $this->slice_del();
                break;
        }
    lab33:
        $this->cursor = $this->limit - $v_27;
        $v_28 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_12);
        if (0 === $among_var) {
            goto lab36;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if ($I_p2 > $this->cursor) {
                    goto lab37;
                }
                goto lab38;
            lab37:
                if ($I_p1 > $this->cursor) {
                    goto lab36;
                }
                $v_29 = $this->limit - $this->cursor;
                if (!$this->r_shortv()) {
                    goto lab39;
                }
                goto lab36;
            lab39:
                $this->cursor = $this->limit - $v_29;
            lab38:
                $this->slice_del();
                break;
            case 2:
                if ($I_p2 > $this->cursor) {
                    goto lab36;
                }
                if (!($this->eq_s_b("l"))) {
                    goto lab36;
                }
                $this->slice_del();
                break;
            case 3:
                $this->slice_from("en");
                break;
            case 4:
                $this->slice_from("er");
                break;
            case 5:
                $this->slice_from("eri");
                break;
            case 6:
                $this->slice_from("ili");
                break;
        }
    lab36:
        $this->cursor = $this->limit - $v_28;
        $this->cursor = $this->limit_backward;
        $v_30 = $this->cursor;
        if (!$B_Y_found) {
            goto lab40;
        }
        while (true) {
            $v_31 = $this->cursor;
            while (true) {
                $v_32 = $this->cursor;
                $this->bra = $this->cursor;
                if (!($this->eq_s("Y"))) {
                    goto lab42;
                }
                $this->ket = $this->cursor;
                $this->cursor = $v_32;
                break;
            lab42:
                $this->cursor = $v_32;
                if ($this->cursor >= $this->limit) {
                    goto lab41;
                }
                $this->inc_cursor();
            }
            $this->slice_from("y");
            continue;
        lab41:
            $this->cursor = $v_31;
            break;
        }
    lab40:
        $this->cursor = $v_30;
    lab1:
        return true;
    }
}
