<?php
// Generated from sesotho.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballSesothoStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["ba", -1, -1],
        ["boi", -1, -1],
        ["le", -1, -1],
        ["li", -1, -1],
        ["ma", -1, -1],
        ["me", -1, -1],
        ["mo", -1, -1],
        ["se", -1, -1]
    ];

    private const array A_1 = [
        ["a", -1, 1],
        ["ela", 0, 1],
        ["isa", 0, 1],
        ["wa", 0, 1],
        ["ile", -1, 1],
        ["etse", -1, 1],
        ["ang", -1, 1],
        ["eng", -1, 1],
        ["ong", -1, 1]
    ];

    private const array A_2 = [
        ["ana", -1, 1],
        ["nyana", 0, 1],
        ["oa", -1, 1],
        ["i", -1, 1],
        ["ano", -1, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true];



    public function stem(): bool
    {
        $v_1 = $this->cursor;
        if (!$this->go_out_grouping(self::G_v)) {
            return false;
        }
        $this->inc_cursor();
        $I_pV = $this->cursor;
        $this->cursor = $v_1;
        $v_2 = $this->cursor;
        if (!$this->hop(2)) {
            return false;
        }
        if ($this->cursor <= $I_pV) {
            goto lab0;
        }
        $I_pV = $this->cursor;
    lab0:
        $this->cursor = $v_2;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_3 = $this->limit - $this->cursor;
        if ($this->cursor < $I_pV) {
            goto lab1;
        }
        $v_4 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_2) === 0) {
            $this->limit_backward = $v_4;
            goto lab1;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->limit_backward = $v_4;
    lab1:
        $this->cursor = $this->limit - $v_3;
        $v_5 = $this->limit - $this->cursor;
        if ($this->cursor < $I_pV) {
            goto lab2;
        }
        $v_6 = $this->limit_backward;
        $this->limit_backward = $I_pV;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_1) === 0) {
            $this->limit_backward = $v_6;
            goto lab2;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->limit_backward = $v_6;
    lab2:
        $this->cursor = $this->limit - $v_5;
        $this->cursor = $this->limit_backward;
        $v_7 = $this->cursor;
        $this->bra = $this->cursor;
        if ($this->find_among(self::A_0) === 0) {
            goto lab3;
        }
        $this->ket = $this->cursor;
        $v_8 = $this->cursor;
        if ($this->cursor >= $this->limit) {
            goto lab3;
        }
        $this->inc_cursor();
        if ($this->cursor >= $this->limit) {
            goto lab3;
        }
        $this->cursor = $v_8;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab3;
        }
        $this->inc_cursor();
        $this->slice_del();
    lab3:
        $this->cursor = $v_7;
        return true;
    }
}
