<?php
// Generated from indonesian.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballIndonesianStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["kah", -1, 1],
        ["lah", -1, 1],
        ["pun", -1, 1]
    ];

    private const array A_1 = [
        ["nya", -1, 1],
        ["ku", -1, 1],
        ["mu", -1, 1]
    ];

    private const array A_2 = [
        ["i", -1, 2],
        ["an", -1, 1]
    ];

    private const array A_3 = [
        ["di", -1, 1],
        ["ke", -1, 3],
        ["me", -1, 1],
        ["mem", 2, 5],
        ["men", 2, 2],
        ["meng", 4, 1],
        ["pem", -1, 6],
        ["pen", -1, 4],
        ["peng", 7, 3],
        ["ter", -1, 1]
    ];

    private const array A_4 = [
        ["be", -1, 2],
        ["pe", -1, 1]
    ];

    private const array G_vowel = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true];

    private int $I_prefix = 0;
    private int $I_measure = 0;



    protected function r_remove_suffix(): bool
    {
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $v_1 = $this->limit - $this->cursor;
                if ($this->I_prefix === 3) {
                    goto lab0;
                }
                if ($this->I_prefix === 2) {
                    goto lab0;
                }
                if (!($this->eq_s_b("k"))) {
                    goto lab0;
                }
                $this->bra = $this->cursor;
                goto lab1;
            lab0:
                $this->cursor = $this->limit - $v_1;
                if ($this->I_prefix === 1) {
                    return false;
                }
            lab1:
                break;
            case 2:
                if ($this->I_prefix > 2) {
                    return false;
                }
                if (!($this->eq_s_b("s"))) {
                    goto lab2;
                }
                return false;
            lab2:
                break;
        }
        $this->slice_del();
        --$this->I_measure;
        return true;
    }


    protected function r_remove_second_order_prefix(): bool
    {
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_4);
        if (0 === $among_var) {
            return false;
        }
        switch ($among_var) {
            case 1:
                $v_1 = $this->cursor;
                if (!($this->eq_s("r"))) {
                    goto lab0;
                }
                $this->ket = $this->cursor;
                $this->I_prefix = 2;
                goto lab1;
            lab0:
                $this->cursor = $v_1;
                if (!($this->eq_s("l"))) {
                    goto lab2;
                }
                $this->ket = $this->cursor;
                if (!($this->eq_s("ajar"))) {
                    goto lab2;
                }
                goto lab1;
            lab2:
                $this->cursor = $v_1;
                $this->ket = $this->cursor;
                $this->I_prefix = 2;
            lab1:
                break;
            case 2:
                $v_2 = $this->cursor;
                if (!($this->eq_s("r"))) {
                    goto lab3;
                }
                $this->ket = $this->cursor;
                goto lab4;
            lab3:
                $this->cursor = $v_2;
                if (!($this->eq_s("l"))) {
                    goto lab5;
                }
                $this->ket = $this->cursor;
                if (!($this->eq_s("ajar"))) {
                    goto lab5;
                }
                goto lab4;
            lab5:
                $this->cursor = $v_2;
                $this->ket = $this->cursor;
                if (!($this->out_grouping(self::G_vowel))) {
                    return false;
                }
                if (!($this->eq_s("er"))) {
                    return false;
                }
            lab4:
                $this->I_prefix = 4;
                break;
        }
        --$this->I_measure;
        $this->slice_del();
        return true;
    }


    public function stem(): bool
    {
        $this->I_measure = 0;
        $v_1 = $this->cursor;
        while (true) {
            $v_2 = $this->cursor;
            if (!$this->go_out_grouping(self::G_vowel)) {
                goto lab1;
            }
            $this->inc_cursor();
            ++$this->I_measure;
            continue;
        lab1:
            $this->cursor = $v_2;
            break;
        }
    lab0:
        $this->cursor = $v_1;
        if ($this->I_measure < 3) {
            return false;
        }
        $this->I_prefix = 0;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_3 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_0) === 0) {
            goto lab2;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        --$this->I_measure;
    lab2:
        $this->cursor = $this->limit - $v_3;
        if ($this->I_measure < 3) {
            return false;
        }
        $v_4 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_1) === 0) {
            goto lab3;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        --$this->I_measure;
    lab3:
        $this->cursor = $this->limit - $v_4;
        $this->cursor = $this->limit_backward;
        if ($this->I_measure < 3) {
            return false;
        }
        $v_5 = $this->cursor;
        $v_6 = $this->cursor;
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_3);
        if (0 === $among_var) {
            goto lab4;
        }
        $this->ket = $this->cursor;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                $this->I_prefix = 1;
                --$this->I_measure;
                break;
            case 2:
                $v_7 = $this->cursor;
                if (!($this->eq_s("y"))) {
                    goto lab5;
                }
                $v_8 = $this->cursor;
                if (!($this->in_grouping(self::G_vowel))) {
                    goto lab5;
                }
                $this->cursor = $v_8;
                $this->ket = $this->cursor;
                $this->slice_from("s");
                $this->I_prefix = 1;
                --$this->I_measure;
                goto lab6;
            lab5:
                $this->cursor = $v_7;
                $this->slice_del();
                $this->I_prefix = 1;
                --$this->I_measure;
            lab6:
                break;
            case 3:
                $this->slice_del();
                $this->I_prefix = 3;
                --$this->I_measure;
                break;
            case 4:
                $v_9 = $this->cursor;
                if (!($this->eq_s("y"))) {
                    goto lab7;
                }
                $v_10 = $this->cursor;
                if (!($this->in_grouping(self::G_vowel))) {
                    goto lab7;
                }
                $this->cursor = $v_10;
                $this->ket = $this->cursor;
                $this->slice_from("s");
                $this->I_prefix = 3;
                --$this->I_measure;
                goto lab8;
            lab7:
                $this->cursor = $v_9;
                $this->slice_del();
                $this->I_prefix = 3;
                --$this->I_measure;
            lab8:
                break;
            case 5:
                $this->I_prefix = 1;
                --$this->I_measure;
                $v_11 = $this->cursor;
                $v_12 = $this->cursor;
                if (!($this->in_grouping(self::G_vowel))) {
                    goto lab9;
                }
                $this->cursor = $v_12;
                $this->slice_from("p");
                goto lab10;
            lab9:
                $this->cursor = $v_11;
                $this->slice_del();
            lab10:
                break;
            case 6:
                $this->I_prefix = 3;
                --$this->I_measure;
                $v_13 = $this->cursor;
                $v_14 = $this->cursor;
                if (!($this->in_grouping(self::G_vowel))) {
                    goto lab11;
                }
                $this->cursor = $v_14;
                $this->slice_from("p");
                goto lab12;
            lab11:
                $this->cursor = $v_13;
                $this->slice_del();
            lab12:
                break;
        }
        $v_15 = $this->cursor;
        $v_16 = $this->cursor;
        if ($this->I_measure < 3) {
            goto lab13;
        }
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        if (!$this->r_remove_suffix()) {
            goto lab13;
        }
        $this->cursor = $this->limit_backward;
        $this->cursor = $v_16;
        if ($this->I_measure < 3) {
            goto lab13;
        }
        if (!$this->r_remove_second_order_prefix()) {
            goto lab13;
        }
    lab13:
        $this->cursor = $v_15;
        $this->cursor = $v_6;
        goto lab14;
    lab4:
        $this->cursor = $v_5;
        $v_17 = $this->cursor;
        $this->r_remove_second_order_prefix();
        $this->cursor = $v_17;
        $v_18 = $this->cursor;
        if ($this->I_measure < 3) {
            goto lab15;
        }
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        if (!$this->r_remove_suffix()) {
            goto lab15;
        }
        $this->cursor = $this->limit_backward;
    lab15:
        $this->cursor = $v_18;
    lab14:
        return true;
    }
}
