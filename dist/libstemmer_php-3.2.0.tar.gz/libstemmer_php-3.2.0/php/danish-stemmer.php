<?php
// Generated from danish.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballDanishStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["hed", -1, 1],
        ["ethed", 0, 1],
        ["ered", -1, 1],
        ["e", -1, 1],
        ["erede", 3, 1],
        ["ende", 3, 1],
        ["erende", 5, 1],
        ["ene", 3, 1],
        ["erne", 3, 1],
        ["ere", 3, 1],
        ["en", -1, 1],
        ["heden", 10, 1],
        ["eren", 10, 1],
        ["er", -1, 1],
        ["heder", 13, 1],
        ["erer", 13, 1],
        ["s", -1, 2],
        ["heds", 16, 1],
        ["es", 16, 1],
        ["endes", 18, 1],
        ["erendes", 19, 1],
        ["enes", 18, 1],
        ["ernes", 18, 1],
        ["eres", 18, 1],
        ["ens", 16, 1],
        ["hedens", 24, 1],
        ["erens", 24, 1],
        ["ers", 16, 1],
        ["ets", 16, 1],
        ["erets", 28, 1],
        ["et", -1, 1],
        ["eret", 30, 1]
    ];

    private const array A_1 = [
        ["gd", -1, -1],
        ["dt", -1, -1],
        ["gt", -1, -1],
        ["kt", -1, -1]
    ];

    private const array A_2 = [
        ["ig", -1, 1],
        ["lig", 0, 1],
        ["elig", 1, 1],
        ["els", -1, 1],
        ["l\u{F8}st", -1, 2]
    ];

    private const array G_undouble_c = ["b"=>true, "d"=>true, "f"=>true, "g"=>true, "k"=>true, "l"=>true, "m"=>true, "n"=>true, "p"=>true, "r"=>true, "s"=>true, "t"=>true];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{E5}"=>true, "\u{E6}"=>true, "\u{F8}"=>true];

    private const array G_s_ending = ["'"=>true, "a"=>true, "b"=>true, "c"=>true, "d"=>true, "f"=>true, "g"=>true, "h"=>true, "j"=>true, "k"=>true, "l"=>true, "m"=>true, "n"=>true, "o"=>true, "p"=>true, "r"=>true, "t"=>true, "v"=>true, "y"=>true, "z"=>true, "\u{E5}"=>true];

    private int $I_p1 = 0;



    protected function r_consonant_pair(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        if ($this->cursor < $this->I_p1) {
            return false;
        }
        $v_2 = $this->limit_backward;
        $this->limit_backward = $this->I_p1;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_1) === 0) {
            $this->limit_backward = $v_2;
            return false;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_2;
        $this->cursor = $this->limit - $v_1;
        if ($this->cursor <= $this->limit_backward) {
            return false;
        }
        $this->dec_cursor();
        $this->bra = $this->cursor;
        $this->slice_del();
        return true;
    }


    public function stem(): bool
    {
        $this->I_p1 = $this->limit;
        $v_1 = $this->cursor;
        $v_2 = $this->cursor;
        while (true) {
            if (!($this->eq_s("'"))) {
                goto lab2;
            }
            break;
        lab2:
            if ($this->cursor >= $this->limit) {
                goto lab1;
            }
            $this->inc_cursor();
        }
        goto lab3;
    lab1:
        $this->cursor = $v_2;
        if (!$this->go_out_grouping(self::G_v)) {
            goto lab0;
        }
        $this->inc_cursor();
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab0;
        }
        $this->inc_cursor();
    lab3:
        $this->I_p1 = $this->cursor;
    lab0:
        $this->cursor = $v_1;
        $v_3 = $this->cursor;
        if (!$this->hop(3)) {
            return false;
        }
        if ($this->I_p1 >= $this->cursor) {
            goto lab4;
        }
        $this->I_p1 = $this->cursor;
    lab4:
        $this->cursor = $v_3;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_4 = $this->limit - $this->cursor;
        if ($this->cursor < $this->I_p1) {
            goto lab5;
        }
        $v_5 = $this->limit_backward;
        $this->limit_backward = $this->I_p1;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_0);
        if (0 === $among_var) {
            $this->limit_backward = $v_5;
            goto lab5;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_5;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                if (!($this->in_grouping_b(self::G_s_ending))) {
                    goto lab5;
                }
                $this->slice_del();
                break;
        }
    lab5:
        $this->cursor = $this->limit - $v_4;
        $v_6 = $this->limit - $this->cursor;
        $this->r_consonant_pair();
        $this->cursor = $this->limit - $v_6;
        $v_7 = $this->limit - $this->cursor;
        $v_8 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("st"))) {
            goto lab7;
        }
        $this->bra = $this->cursor;
        if (!($this->eq_s_b("ig"))) {
            goto lab7;
        }
        $this->slice_del();
    lab7:
        $this->cursor = $this->limit - $v_8;
        if ($this->cursor < $this->I_p1) {
            goto lab6;
        }
        $v_9 = $this->limit_backward;
        $this->limit_backward = $this->I_p1;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            $this->limit_backward = $v_9;
            goto lab6;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_9;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                $v_10 = $this->limit - $this->cursor;
                $this->r_consonant_pair();
                $this->cursor = $this->limit - $v_10;
                break;
            case 2:
                $this->slice_from("l\u{F8}s");
                break;
        }
    lab6:
        $this->cursor = $this->limit - $v_7;
        $v_11 = $this->limit - $this->cursor;
        if ($this->cursor < $this->I_p1) {
            goto lab8;
        }
        $v_12 = $this->limit_backward;
        $this->limit_backward = $this->I_p1;
        $this->ket = $this->cursor;
        if (!($this->in_grouping_b(self::G_undouble_c))) {
            $this->limit_backward = $v_12;
            goto lab8;
        }
        $this->bra = $this->cursor;
        $S_ch = $this->slice_to();
        $this->limit_backward = $v_12;
        if (!($this->eq_s_b($S_ch))) {
            goto lab8;
        }
        $this->slice_del();
    lab8:
        $this->cursor = $this->limit - $v_11;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("'"))) {
            return false;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->cursor = $this->limit_backward;
        return true;
    }
}
