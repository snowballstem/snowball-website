<?php
// Generated from tamil.sbl by Snowball 3.2.0 - https://snowballstem.org/

class SnowballTamilStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["\u{BB5}\u{BC1}", -1, 3],
        ["\u{BB5}\u{BC2}", -1, 4],
        ["\u{BB5}\u{BCA}", -1, 2],
        ["\u{BB5}\u{BCB}", -1, 1]
    ];

    private const array AS_0 = ["\u{B93}", "\u{B92}", "\u{B89}", "\u{B8A}"];

    private const array A_1 = [
        ["\u{B95}", -1, -1],
        ["\u{B99}", -1, -1],
        ["\u{B9A}", -1, -1],
        ["\u{B9E}", -1, -1],
        ["\u{BA4}", -1, -1],
        ["\u{BA8}", -1, -1],
        ["\u{BAA}", -1, -1],
        ["\u{BAE}", -1, -1],
        ["\u{BAF}", -1, -1],
        ["\u{BB5}", -1, -1]
    ];

    private const array A_2 = [
        ["\u{BC0}", -1, -1],
        ["\u{BC8}", -1, -1],
        ["\u{BBF}", -1, -1]
    ];

    private const array A_3 = [
        ["\u{BC0}", -1, -1],
        ["\u{BC1}", -1, -1],
        ["\u{BC2}", -1, -1],
        ["\u{BC6}", -1, -1],
        ["\u{BC7}", -1, -1],
        ["\u{BC8}", -1, -1],
        ["\u{BBE}", -1, -1],
        ["\u{BBF}", -1, -1]
    ];

    private const array A_4 = [
        ["", -1, 2],
        ["\u{BC8}", 0, 1],
        ["\u{BCD}", 0, 1]
    ];

    private const array AS_4 = ["", "\u{BAE}\u{BCD}"];

    private const array A_5 = [
        ["\u{BA9}\u{BC1}", -1, 8],
        ["\u{BC1}\u{B95}\u{BCD}", -1, 7],
        ["\u{BC1}\u{B95}\u{BCD}\u{B95}\u{BCD}", -1, 7],
        ["\u{B9F}\u{BCD}\u{B95}\u{BCD}", -1, 3],
        ["\u{BB1}\u{BCD}\u{B95}\u{BCD}", -1, 4],
        ["\u{B99}\u{BCD}", -1, 9],
        ["\u{B9F}\u{BCD}\u{B9F}\u{BCD}", -1, 5],
        ["\u{BA4}\u{BCD}\u{BA4}\u{BCD}", -1, 6],
        ["\u{BA8}\u{BCD}\u{BA4}\u{BCD}", -1, 1],
        ["\u{BA8}\u{BCD}", -1, 1],
        ["\u{B9F}\u{BCD}\u{BAA}\u{BCD}", -1, 3],
        ["\u{BAF}\u{BCD}", -1, 2],
        ["\u{BA9}\u{BCD}\u{BB1}\u{BCD}", -1, 4],
        ["\u{BB5}\u{BCD}", -1, 1],
        ["\u{BA8}\u{BCD}\u{BA4}", -1, 1],
        ["\u{BAF}", -1, 1],
        ["\u{BB5}", -1, 1]
    ];

    private const array A_6 = [
        ["\u{B95}", -1, -1],
        ["\u{B9A}", -1, -1],
        ["\u{B9F}", -1, -1],
        ["\u{BA4}", -1, -1],
        ["\u{BAA}", -1, -1],
        ["\u{BB1}", -1, -1]
    ];

    private const array A_7 = [
        ["\u{B9E}", -1, -1],
        ["\u{BA3}", -1, -1],
        ["\u{BA8}", -1, -1],
        ["\u{BA9}", -1, -1],
        ["\u{BAE}", -1, -1],
        ["\u{BAF}", -1, -1],
        ["\u{BB0}", -1, -1],
        ["\u{BB2}", -1, -1],
        ["\u{BB3}", -1, -1],
        ["\u{BB4}", -1, -1],
        ["\u{BB5}", -1, -1]
    ];

    private const array A_8 = [
        ["\u{BC0}", -1, -1],
        ["\u{BC1}", -1, -1],
        ["\u{BC2}", -1, -1],
        ["\u{BC6}", -1, -1],
        ["\u{BC7}", -1, -1],
        ["\u{BC8}", -1, -1],
        ["\u{BCD}", -1, -1],
        ["\u{BBE}", -1, -1],
        ["\u{BBF}", -1, -1]
    ];

    private const array A_9 = [
        ["\u{B85}", -1, -1],
        ["\u{B87}", -1, -1],
        ["\u{B89}", -1, -1]
    ];

    private const array A_10 = [
        ["\u{B95}\u{BB3}\u{BCD}", -1, 4],
        ["\u{BC1}\u{B99}\u{BCD}\u{B95}\u{BB3}\u{BCD}", 0, 1],
        ["\u{B9F}\u{BCD}\u{B95}\u{BB3}\u{BCD}", 0, 3],
        ["\u{BB1}\u{BCD}\u{B95}\u{BB3}\u{BCD}", 0, 2]
    ];

    private const array A_11 = [
        ["\u{BC7}", -1, -1],
        ["\u{BCB}", -1, -1],
        ["\u{BBE}", -1, -1]
    ];

    private const array A_12 = [
        ["\u{BAA}\u{BBF}", -1, -1],
        ["\u{BB5}\u{BBF}", -1, -1]
    ];

    private const array A_13 = [
        ["\u{BAA}\u{B9F}\u{BCD}\u{B9F}\u{BC1}", -1, 3],
        ["\u{BB5}\u{BBF}\u{B9F}\u{BCD}\u{B9F}\u{BC1}", -1, 3],
        ["\u{BAA}\u{B9F}\u{BC1}", -1, 3],
        ["\u{BB5}\u{BBF}\u{B9F}\u{BC1}", -1, 3],
        ["\u{BAA}\u{B9F}\u{BCD}\u{B9F}\u{BA4}\u{BC1}", -1, 3],
        ["\u{BC6}\u{BA9}\u{BCD}\u{BB1}\u{BC1}", -1, 1],
        ["\u{BC1}\u{B9F}\u{BC8}", -1, 1],
        ["\u{BBF}\u{BB2}\u{BCD}\u{BB2}\u{BC8}", -1, 1],
        ["\u{BC1}\u{B9F}\u{BA9}\u{BCD}", -1, 1],
        ["\u{BC6}\u{BA9}\u{BC1}\u{BAE}\u{BCD}", -1, 1],
        ["\u{BBF}\u{B9F}\u{BAE}\u{BCD}", -1, 1],
        ["\u{BC6}\u{BB2}\u{BCD}\u{BB2}\u{BBE}\u{BAE}\u{BCD}", -1, 3],
        ["\u{BAA}\u{B9F}\u{BCD}\u{B9F}", -1, 3],
        ["\u{BAA}\u{B9F}\u{BCD}\u{B9F}\u{BA3}", -1, 3],
        ["\u{BC6}\u{BA9}", -1, 1],
        ["\u{BA4}\u{BBE}\u{BA9}", -1, 3],
        ["\u{BAA}\u{B9F}\u{BBF}\u{BA4}\u{BBE}\u{BA9}", 15, 3],
        ["\u{BC1}\u{B9F}\u{BC8}\u{BAF}", -1, 1],
        ["\u{BBE}\u{B95}\u{BBF}\u{BAF}", -1, 1],
        ["\u{B95}\u{BC1}\u{BB0}\u{BBF}\u{BAF}", -1, 3],
        ["\u{BB2}\u{BCD}\u{BB2}", -1, 2],
        ["\u{BC1}\u{BB3}\u{BCD}\u{BB3}", -1, 1],
        ["\u{BBE}\u{B95}\u{BBF}", -1, 1],
        ["\u{BAA}\u{B9F}\u{BBF}", -1, 3],
        ["\u{BBF}\u{BA9}\u{BCD}\u{BB1}\u{BBF}", -1, 1],
        ["\u{BAA}\u{BB1}\u{BCD}\u{BB1}\u{BBF}", -1, 3]
    ];

    private const array A_14 = [
        ["\u{BC0}", -1, 7],
        ["\u{BCA}\u{B9F}\u{BC1}", -1, 2],
        ["\u{BCB}\u{B9F}\u{BC1}", -1, 2],
        ["\u{BA4}\u{BC1}", -1, 6],
        ["\u{BBF}\u{BB0}\u{BC1}\u{BA8}\u{BCD}\u{BA4}\u{BC1}", 3, 2],
        ["\u{BBF}\u{BA9}\u{BCD}\u{BB1}\u{BC1}", -1, 2],
        ["\u{BC1}\u{B9F}\u{BC8}", -1, 2],
        ["\u{BA9}\u{BC8}", -1, 1],
        ["\u{B95}\u{BA3}\u{BCD}", -1, 1],
        ["\u{BAE}\u{BC1}\u{BA9}\u{BCD}", -1, 1],
        ["\u{BBF}\u{BA9}\u{BCD}", -1, 3],
        ["\u{BBF}\u{B9F}\u{BAE}\u{BCD}", -1, 4],
        ["\u{BAE}\u{BC7}\u{BB1}\u{BCD}", -1, 1],
        ["\u{BBF}\u{BB1}\u{BCD}", -1, 2],
        ["\u{BB2}\u{BCD}", -1, 5],
        ["\u{BAE}\u{BC7}\u{BB2}\u{BCD}", 14, 1],
        ["\u{BBE}\u{BAE}\u{BB2}\u{BCD}", 14, 2],
        ["\u{BBE}\u{BB2}\u{BCD}", 14, 2],
        ["\u{BBF}\u{BB2}\u{BCD}", 14, 2],
        ["\u{BC1}\u{BB3}\u{BCD}", -1, 2],
        ["\u{B95}\u{BC0}\u{BB4}\u{BCD}", -1, 1],
        ["\u{BB5}\u{BBF}\u{B9F}", -1, 2]
    ];

    private const array A_15 = [
        ["\u{B85}", -1, -1],
        ["\u{B86}", -1, -1],
        ["\u{B87}", -1, -1],
        ["\u{B88}", -1, -1],
        ["\u{B89}", -1, -1],
        ["\u{B8A}", -1, -1],
        ["\u{B8E}", -1, -1],
        ["\u{B8F}", -1, -1],
        ["\u{B90}", -1, -1],
        ["\u{B92}", -1, -1],
        ["\u{B93}", -1, -1],
        ["\u{B94}", -1, -1]
    ];

    private const array A_16 = [
        ["\u{B95}\u{BC1}", -1, 6],
        ["\u{BAA}\u{B9F}\u{BC1}", -1, 1],
        ["\u{BA4}\u{BC1}", -1, 3],
        ["\u{BBF}\u{BB1}\u{BCD}\u{BB1}\u{BC1}", -1, 1],
        ["\u{BA9}\u{BC8}", -1, 1],
        ["\u{BB5}\u{BC8}", -1, 1],
        ["\u{BA9}\u{BC6}\u{BA9}\u{BCD}", -1, 1],
        ["\u{BC7}\u{BA9}\u{BCD}", -1, 5],
        ["\u{BA9}\u{BA9}\u{BCD}", -1, 1],
        ["\u{BAA}\u{BA9}\u{BCD}", -1, 1],
        ["\u{BB5}\u{BA9}\u{BCD}", -1, 2],
        ["\u{BBE}\u{BA9}\u{BCD}", -1, 4],
        ["\u{BA9}\u{BBE}\u{BA9}\u{BCD}", 11, 1],
        ["\u{BAE}\u{BBF}\u{BA9}\u{BCD}", -1, 1],
        ["\u{B95}\u{BC1}\u{BAE}\u{BCD}", -1, 1],
        ["\u{B9F}\u{BC1}\u{BAE}\u{BCD}", -1, 5],
        ["\u{BA4}\u{BC1}\u{BAE}\u{BCD}", -1, 1],
        ["\u{BB1}\u{BC1}\u{BAE}\u{BCD}", -1, 1],
        ["\u{BC6}\u{BAE}\u{BCD}", -1, 5],
        ["\u{BC7}\u{BAE}\u{BCD}", -1, 5],
        ["\u{BCB}\u{BAE}\u{BCD}", -1, 5],
        ["\u{BA9}\u{BAE}\u{BCD}", -1, 1],
        ["\u{BAA}\u{BAE}\u{BCD}", -1, 1],
        ["\u{BBE}\u{BAE}\u{BCD}", -1, 5],
        ["\u{BBE}\u{BAF}\u{BCD}", -1, 5],
        ["\u{BC0}\u{BB0}\u{BCD}", -1, 5],
        ["\u{BA9}\u{BB0}\u{BCD}", -1, 1],
        ["\u{BAA}\u{BB0}\u{BCD}", -1, 1],
        ["\u{BC0}\u{BAF}\u{BB0}\u{BCD}", -1, 5],
        ["\u{BB5}\u{BB0}\u{BCD}", -1, 1],
        ["\u{BBE}\u{BB0}\u{BCD}", -1, 5],
        ["\u{BA9}\u{BBE}\u{BB0}\u{BCD}", 30, 1],
        ["\u{BAE}\u{BBE}\u{BB0}\u{BCD}", 30, 1],
        ["\u{B95}\u{BCA}\u{BA3}\u{BCD}\u{B9F}\u{BBF}\u{BB0}\u{BCD}", -1, 1],
        ["\u{BA9}\u{BBF}\u{BB0}\u{BCD}", -1, 5],
        ["\u{BA9}\u{BB3}\u{BCD}", -1, 1],
        ["\u{BAA}\u{BB3}\u{BCD}", -1, 1],
        ["\u{BB5}\u{BB3}\u{BCD}", -1, 1],
        ["\u{BBE}\u{BB3}\u{BCD}", -1, 5],
        ["\u{BA9}\u{BBE}\u{BB3}\u{BCD}", 38, 1],
        ["\u{B95}", -1, 1],
        ["\u{BA4}", -1, 1],
        ["\u{BA9}", -1, 1],
        ["\u{BAA}", -1, 1],
        ["\u{BAF}", -1, 1],
        ["\u{BBE}", -1, 5]
    ];

    private const array A_17 = [
        ["\u{B95}\u{BBF}\u{BA9}\u{BCD}\u{BB1}\u{BCD}", -1, -1],
        ["\u{BBE}\u{BA8}\u{BBF}\u{BA9}\u{BCD}\u{BB1}\u{BCD}", -1, -1],
        ["\u{B95}\u{BBF}\u{BB1}\u{BCD}", -1, -1],
        ["\u{B95}\u{BBF}\u{BA9}\u{BCD}\u{BB1}", -1, -1],
        ["\u{BBE}\u{BA8}\u{BBF}\u{BA9}\u{BCD}\u{BB1}", -1, -1],
        ["\u{B95}\u{BBF}\u{BB1}", -1, -1]
    ];

    private bool $B_found_vetrumai_urupu = false;



    protected function r_fix_va_start(): bool
    {
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_0);
        if (0 === $among_var) {
            return false;
        }
        $this->ket = $this->cursor;
        $this->slice_from(self::AS_0[$among_var - 1]);
        return true;
    }


    protected function r_fix_endings(): bool
    {
        $v_1 = $this->cursor;
        while (true) {
            $v_2 = $this->cursor;
            if (!$this->r_fix_ending()) {
                goto lab1;
            }
            continue;
        lab1:
            $this->cursor = $v_2;
            break;
        }
    lab0:
        $this->cursor = $v_1;
        return true;
    }


    protected function r_fix_ending(): bool
    {
        if (mb_strlen($this->current, 'UTF-8') < 4) {
            return false;
        }
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_1 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_5);
        if (0 === $among_var) {
            goto lab0;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                $v_2 = $this->limit - $this->cursor;
                if ($this->find_among_b(self::A_2) === 0) {
                    goto lab0;
                }
                $this->cursor = $this->limit - $v_2;
                $this->slice_del();
                break;
            case 3:
                $this->slice_from("\u{BB3}\u{BCD}");
                break;
            case 4:
                $this->slice_from("\u{BB2}\u{BCD}");
                break;
            case 5:
                $this->slice_from("\u{B9F}\u{BC1}");
                break;
            case 6:
                if (!$this->B_found_vetrumai_urupu) {
                    goto lab0;
                }
                if (!($this->eq_s_b("\u{BC8}"))) {
                    goto lab1;
                }
                goto lab0;
            lab1:
                $this->slice_from("\u{BAE}\u{BCD}");
                break;
            case 7:
                $this->slice_from("\u{BCD}");
                break;
            case 8:
                $v_3 = $this->limit - $this->cursor;
                if ($this->find_among_b(self::A_3) === 0) {
                    goto lab2;
                }
                goto lab0;
            lab2:
                $this->cursor = $this->limit - $v_3;
                $this->slice_del();
                break;
            case 9:
                $among_var = $this->find_among_b(self::A_4);
                $this->slice_from(self::AS_4[$among_var - 1]);
                break;
        }
        goto lab3;
    lab0:
        $this->cursor = $this->limit - $v_1;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{BCD}"))) {
            return false;
        }
        $v_4 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_6) === 0) {
            goto lab4;
        }
        $v_5 = $this->limit - $this->cursor;
        if (!($this->eq_s_b("\u{BCD}"))) {
            $this->cursor = $this->limit - $v_5;
            goto lab5;
        }
        if ($this->find_among_b(self::A_6) === 0) {
            $this->cursor = $this->limit - $v_5;
            goto lab5;
        }
    lab5:
        $this->bra = $this->cursor;
        $this->slice_del();
        goto lab6;
    lab4:
        $this->cursor = $this->limit - $v_4;
        if ($this->find_among_b(self::A_7) === 0) {
            goto lab7;
        }
        $this->bra = $this->cursor;
        if (!($this->eq_s_b("\u{BCD}"))) {
            goto lab7;
        }
        $this->slice_del();
        goto lab6;
    lab7:
        $this->cursor = $this->limit - $v_4;
        $v_6 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_8) === 0) {
            return false;
        }
        $this->cursor = $this->limit - $v_6;
        $this->bra = $this->cursor;
        $this->slice_del();
    lab6:
    lab3:
        $this->cursor = $this->limit_backward;
        return true;
    }


    public function stem(): bool
    {
        $this->B_found_vetrumai_urupu = false;
        $v_1 = $this->cursor;
        $this->r_fix_ending();
        $this->cursor = $v_1;
        if (mb_strlen($this->current, 'UTF-8') < 5) {
            return false;
        }
        $v_2 = $this->cursor;
        $this->bra = $this->cursor;
        if (!($this->eq_s("\u{B8E}"))) {
            goto lab0;
        }
        if ($this->find_among(self::A_1) === 0) {
            goto lab0;
        }
        if (!($this->eq_s("\u{BCD}"))) {
            goto lab0;
        }
        $this->ket = $this->cursor;
        $this->slice_del();
        $v_3 = $this->cursor;
        $this->r_fix_va_start();
        $this->cursor = $v_3;
    lab0:
        $this->cursor = $v_2;
        $v_4 = $this->cursor;
        $this->bra = $this->cursor;
        if ($this->find_among(self::A_9) === 0) {
            goto lab1;
        }
        if ($this->find_among(self::A_1) === 0) {
            goto lab1;
        }
        if (!($this->eq_s("\u{BCD}"))) {
            goto lab1;
        }
        $this->ket = $this->cursor;
        $this->slice_del();
        $v_5 = $this->cursor;
        $this->r_fix_va_start();
        $this->cursor = $v_5;
    lab1:
        $this->cursor = $v_4;
        if (mb_strlen($this->current, 'UTF-8') < 5) {
            goto lab2;
        }
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_6 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_11) === 0) {
            goto lab3;
        }
        $this->bra = $this->cursor;
        $this->slice_from("\u{BCD}");
    lab3:
        $this->cursor = $this->limit - $v_6;
        $this->cursor = $this->limit_backward;
        $this->r_fix_endings();
    lab2:
        $v_7 = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 5) {
            goto lab4;
        }
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{BC1}\u{BAE}\u{BCD}"))) {
            goto lab4;
        }
        $this->bra = $this->cursor;
        $this->slice_from("\u{BCD}");
        $this->cursor = $this->limit_backward;
        $v_8 = $this->cursor;
        $this->r_fix_ending();
        $this->cursor = $v_8;
    lab4:
        $this->cursor = $v_7;
        $v_9 = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 5) {
            goto lab5;
        }
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_13);
        if (0 === $among_var) {
            goto lab5;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $this->slice_from("\u{BCD}");
                break;
            case 2:
                $v_10 = $this->limit - $this->cursor;
                if ($this->find_among_b(self::A_3) === 0) {
                    goto lab6;
                }
                goto lab5;
            lab6:
                $this->cursor = $this->limit - $v_10;
                $this->slice_from("\u{BCD}");
                break;
            case 3:
                $this->slice_del();
                break;
        }
        $this->cursor = $this->limit_backward;
        $this->r_fix_endings();
    lab5:
        $this->cursor = $v_9;
        $v_11 = $this->cursor;
        $this->B_found_vetrumai_urupu = false;
        if (mb_strlen($this->current, 'UTF-8') < 5) {
            goto lab7;
        }
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_12 = $this->limit - $this->cursor;
        $v_13 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_14);
        if (0 === $among_var) {
            goto lab8;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                $this->slice_from("\u{BCD}");
                break;
            case 3:
                if (!($this->eq_s_b("\u{BAE}"))) {
                    goto lab9;
                }
                goto lab8;
            lab9:
                $this->slice_from("\u{BCD}");
                break;
            case 4:
                if (mb_strlen($this->current, 'UTF-8') < 7) {
                    goto lab8;
                }
                $this->slice_from("\u{BCD}");
                break;
            case 5:
                $v_14 = $this->limit - $this->cursor;
                if ($this->find_among_b(self::A_3) === 0) {
                    goto lab10;
                }
                goto lab8;
            lab10:
                $this->cursor = $this->limit - $v_14;
                $this->slice_from("\u{BCD}");
                break;
            case 6:
                $v_15 = $this->limit - $this->cursor;
                if ($this->find_among_b(self::A_3) === 0) {
                    goto lab11;
                }
                goto lab8;
            lab11:
                $this->cursor = $this->limit - $v_15;
                $this->slice_del();
                break;
            case 7:
                $this->slice_from("\u{BBF}");
                break;
        }
        $this->cursor = $this->limit - $v_13;
        goto lab12;
    lab8:
        $this->cursor = $this->limit - $v_12;
        $v_16 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{BC8}"))) {
            goto lab7;
        }
        $v_17 = $this->limit - $this->cursor;
        $v_18 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_6) === 0) {
            goto lab14;
        }
        goto lab13;
    lab14:
        $this->cursor = $this->limit - $v_18;
        goto lab15;
    lab13:
        $this->cursor = $this->limit - $v_17;
        $v_19 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_6) === 0) {
            goto lab7;
        }
        if (!($this->eq_s_b("\u{BCD}"))) {
            goto lab7;
        }
        $this->cursor = $this->limit - $v_19;
    lab15:
        $this->bra = $this->cursor;
        $this->slice_from("\u{BCD}");
        $this->cursor = $this->limit - $v_16;
    lab12:
        $this->B_found_vetrumai_urupu = true;
        $v_20 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if (!($this->eq_s_b("\u{BBF}\u{BA9}\u{BCD}"))) {
            goto lab16;
        }
        $this->bra = $this->cursor;
        $this->slice_from("\u{BCD}");
    lab16:
        $this->cursor = $this->limit - $v_20;
        $this->cursor = $this->limit_backward;
        $this->r_fix_endings();
    lab7:
        $this->cursor = $v_11;
        $v_21 = $this->cursor;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_10);
        if (0 === $among_var) {
            goto lab17;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $v_22 = $this->limit - $this->cursor;
                if ($this->find_among_b(self::A_6) === 0) {
                    goto lab18;
                }
                $this->slice_from("\u{BC1}\u{B99}\u{BCD}");
                goto lab19;
            lab18:
                $this->cursor = $this->limit - $v_22;
                $this->slice_from("\u{BCD}");
            lab19:
                break;
            case 2:
                $this->slice_from("\u{BB2}\u{BCD}");
                break;
            case 3:
                $this->slice_from("\u{BB3}\u{BCD}");
                break;
            case 4:
                $this->slice_del();
                break;
        }
        $this->cursor = $this->limit_backward;
    lab17:
        $this->cursor = $v_21;
        $v_23 = $this->cursor;
        if (mb_strlen($this->current, 'UTF-8') < 5) {
            goto lab20;
        }
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_12) === 0) {
            goto lab20;
        }
        $this->bra = $this->cursor;
        $this->slice_del();
        $this->cursor = $this->limit_backward;
    lab20:
        $this->cursor = $v_23;
        $v_24 = $this->cursor;
        while (true) {
            $v_25 = $this->cursor;
            $B_found_a_match = false;
            if (mb_strlen($this->current, 'UTF-8') < 5) {
                goto lab22;
            }
            $this->limit_backward = $this->cursor;
            $this->cursor = $this->limit;
            $v_26 = $this->limit - $this->cursor;
            $v_27 = $this->limit - $this->cursor;
            $this->ket = $this->cursor;
            $among_var = $this->find_among_b(self::A_16);
            if (0 === $among_var) {
                goto lab23;
            }
            $this->bra = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_del();
                    break;
                case 2:
                    $v_28 = $this->limit - $this->cursor;
                    if ($this->find_among_b(self::A_15) === 0) {
                        goto lab24;
                    }
                    goto lab23;
                lab24:
                    $this->cursor = $this->limit - $v_28;
                    $this->slice_del();
                    break;
                case 3:
                    $v_29 = $this->limit - $this->cursor;
                    if ($this->find_among_b(self::A_3) === 0) {
                        goto lab25;
                    }
                    goto lab23;
                lab25:
                    $this->cursor = $this->limit - $v_29;
                    $this->slice_del();
                    break;
                case 4:
                    if (!($this->eq_s_b("\u{B9A}"))) {
                        goto lab26;
                    }
                    goto lab23;
                lab26:
                    $this->slice_from("\u{BCD}");
                    break;
                case 5:
                    $this->slice_from("\u{BCD}");
                    break;
                case 6:
                    $v_30 = $this->limit - $this->cursor;
                    if (!($this->eq_s_b("\u{BCD}"))) {
                        goto lab23;
                    }
                    $this->cursor = $this->limit - $v_30;
                    $this->slice_del();
                    break;
            }
            $B_found_a_match = true;
            $this->cursor = $this->limit - $v_27;
        lab23:
            $this->cursor = $this->limit - $v_26;
            $v_31 = $this->limit - $this->cursor;
            $this->ket = $this->cursor;
            if ($this->find_among_b(self::A_17) === 0) {
                goto lab27;
            }
            $this->bra = $this->cursor;
            $this->slice_del();
            $B_found_a_match = true;
        lab27:
            $this->cursor = $this->limit - $v_31;
            $this->cursor = $this->limit_backward;
            $this->r_fix_endings();
            if (!$B_found_a_match) {
                goto lab22;
            }
            continue;
        lab22:
            $this->cursor = $v_25;
            break;
        }
    lab21:
        $this->cursor = $v_24;
        return true;
    }
}
