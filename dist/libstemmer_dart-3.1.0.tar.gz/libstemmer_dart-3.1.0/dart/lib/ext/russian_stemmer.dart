// Generated from russian.sbl by Snowball 3.1.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from russian.sbl by Snowball 3.1.0 - https://snowballstem.org/
 */
class russian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("\u0432", -1, 1, 0),
        Among("\u0438\u0432", 0, 2, 0),
        Among("\u044B\u0432", 0, 2, 0),
        Among("\u0432\u0448\u0438", -1, 1, 0),
        Among("\u0438\u0432\u0448\u0438", 3, 2, 0),
        Among("\u044B\u0432\u0448\u0438", 3, 2, 0),
        Among("\u0432\u0448\u0438\u0441\u044C", -1, 1, 0),
        Among("\u0438\u0432\u0448\u0438\u0441\u044C", 6, 2, 0),
        Among("\u044B\u0432\u0448\u0438\u0441\u044C", 6, 2, 0)
    ];

    static final a_1 = [
        Among("\u0435\u0435", -1, 1, 0),
        Among("\u0438\u0435", -1, 1, 0),
        Among("\u043E\u0435", -1, 1, 0),
        Among("\u044B\u0435", -1, 1, 0),
        Among("\u0438\u043C\u0438", -1, 1, 0),
        Among("\u044B\u043C\u0438", -1, 1, 0),
        Among("\u0435\u0439", -1, 1, 0),
        Among("\u0438\u0439", -1, 1, 0),
        Among("\u043E\u0439", -1, 1, 0),
        Among("\u044B\u0439", -1, 1, 0),
        Among("\u0435\u043C", -1, 1, 0),
        Among("\u0438\u043C", -1, 1, 0),
        Among("\u043E\u043C", -1, 1, 0),
        Among("\u044B\u043C", -1, 1, 0),
        Among("\u0435\u0433\u043E", -1, 1, 0),
        Among("\u043E\u0433\u043E", -1, 1, 0),
        Among("\u0435\u043C\u0443", -1, 1, 0),
        Among("\u043E\u043C\u0443", -1, 1, 0),
        Among("\u0438\u0445", -1, 1, 0),
        Among("\u044B\u0445", -1, 1, 0),
        Among("\u0435\u044E", -1, 1, 0),
        Among("\u043E\u044E", -1, 1, 0),
        Among("\u0443\u044E", -1, 1, 0),
        Among("\u044E\u044E", -1, 1, 0),
        Among("\u0430\u044F", -1, 1, 0),
        Among("\u044F\u044F", -1, 1, 0)
    ];

    static final a_2 = [
        Among("\u0435\u043C", -1, 1, 0),
        Among("\u043D\u043D", -1, 1, 0),
        Among("\u0432\u0448", -1, 1, 0),
        Among("\u0438\u0432\u0448", 2, 2, 0),
        Among("\u044B\u0432\u0448", 2, 2, 0),
        Among("\u0449", -1, 1, 0),
        Among("\u044E\u0449", 5, 1, 0),
        Among("\u0443\u044E\u0449", 6, 2, 0)
    ];

    static final a_3 = [
        Among("\u0441\u044C", -1, 1, 0),
        Among("\u0441\u044F", -1, 1, 0)
    ];

    static final a_4 = [
        Among("\u043B\u0430", -1, 1, 0),
        Among("\u0438\u043B\u0430", 0, 2, 0),
        Among("\u044B\u043B\u0430", 0, 2, 0),
        Among("\u043D\u0430", -1, 1, 0),
        Among("\u0435\u043D\u0430", 3, 2, 0),
        Among("\u0435\u0442\u0435", -1, 1, 0),
        Among("\u0438\u0442\u0435", -1, 2, 0),
        Among("\u0439\u0442\u0435", -1, 1, 0),
        Among("\u0435\u0439\u0442\u0435", 7, 2, 0),
        Among("\u0443\u0439\u0442\u0435", 7, 2, 0),
        Among("\u043B\u0438", -1, 1, 0),
        Among("\u0438\u043B\u0438", 10, 2, 0),
        Among("\u044B\u043B\u0438", 10, 2, 0),
        Among("\u0439", -1, 1, 0),
        Among("\u0435\u0439", 13, 2, 0),
        Among("\u0443\u0439", 13, 2, 0),
        Among("\u043B", -1, 1, 0),
        Among("\u0438\u043B", 16, 2, 0),
        Among("\u044B\u043B", 16, 2, 0),
        Among("\u0435\u043C", -1, 1, 0),
        Among("\u0438\u043C", -1, 2, 0),
        Among("\u044B\u043C", -1, 2, 0),
        Among("\u043D", -1, 1, 0),
        Among("\u0435\u043D", 22, 2, 0),
        Among("\u043B\u043E", -1, 1, 0),
        Among("\u0438\u043B\u043E", 24, 2, 0),
        Among("\u044B\u043B\u043E", 24, 2, 0),
        Among("\u043D\u043E", -1, 1, 0),
        Among("\u0435\u043D\u043E", 27, 2, 0),
        Among("\u043D\u043D\u043E", 27, 1, 0),
        Among("\u0435\u0442", -1, 1, 0),
        Among("\u0443\u0435\u0442", 30, 2, 0),
        Among("\u0438\u0442", -1, 2, 0),
        Among("\u044B\u0442", -1, 2, 0),
        Among("\u044E\u0442", -1, 1, 0),
        Among("\u0443\u044E\u0442", 34, 2, 0),
        Among("\u044F\u0442", -1, 2, 0),
        Among("\u043D\u044B", -1, 1, 0),
        Among("\u0435\u043D\u044B", 37, 2, 0),
        Among("\u0442\u044C", -1, 1, 0),
        Among("\u0438\u0442\u044C", 39, 2, 0),
        Among("\u044B\u0442\u044C", 39, 2, 0),
        Among("\u0435\u0448\u044C", -1, 1, 0),
        Among("\u0438\u0448\u044C", -1, 2, 0),
        Among("\u044E", -1, 2, 0),
        Among("\u0443\u044E", 44, 2, 0)
    ];

    static final a_5 = [
        Among("\u0430", -1, 1, 0),
        Among("\u0435\u0432", -1, 1, 0),
        Among("\u043E\u0432", -1, 1, 0),
        Among("\u0435", -1, 1, 0),
        Among("\u0438\u0435", 3, 1, 0),
        Among("\u044C\u0435", 3, 1, 0),
        Among("\u0438", -1, 1, 0),
        Among("\u0435\u0438", 6, 1, 0),
        Among("\u0438\u0438", 6, 1, 0),
        Among("\u0430\u043C\u0438", 6, 1, 0),
        Among("\u044F\u043C\u0438", 6, 1, 0),
        Among("\u0438\u044F\u043C\u0438", 10, 1, 0),
        Among("\u0439", -1, 1, 0),
        Among("\u0435\u0439", 12, 1, 0),
        Among("\u0438\u0435\u0439", 13, 1, 0),
        Among("\u0438\u0439", 12, 1, 0),
        Among("\u043E\u0439", 12, 1, 0),
        Among("\u0430\u043C", -1, 1, 0),
        Among("\u0435\u043C", -1, 1, 0),
        Among("\u0438\u0435\u043C", 18, 1, 0),
        Among("\u043E\u043C", -1, 1, 0),
        Among("\u044F\u043C", -1, 1, 0),
        Among("\u0438\u044F\u043C", 21, 1, 0),
        Among("\u043E", -1, 1, 0),
        Among("\u0443", -1, 1, 0),
        Among("\u0430\u0445", -1, 1, 0),
        Among("\u044F\u0445", -1, 1, 0),
        Among("\u0438\u044F\u0445", 26, 1, 0),
        Among("\u044B", -1, 1, 0),
        Among("\u044C", -1, 1, 0),
        Among("\u044E", -1, 1, 0),
        Among("\u0438\u044E", 30, 1, 0),
        Among("\u044C\u044E", 30, 1, 0),
        Among("\u044F", -1, 1, 0),
        Among("\u0438\u044F", 33, 1, 0),
        Among("\u044C\u044F", 33, 1, 0)
    ];

    static final a_6 = [
        Among("\u043E\u0441\u0442", -1, 1, 0),
        Among("\u043E\u0441\u0442\u044C", -1, 1, 0)
    ];

    static final a_7 = [
        Among("\u0435\u0439\u0448\u0435", -1, 1, 0),
        Among("\u043D", -1, 2, 0),
        Among("\u0435\u0439\u0448", -1, 1, 0),
        Among("\u044C", -1, 3, 0)
    ];

    static final g_v = String.fromCharCodes([33, 65, 8, 232]);

    int I_p2 = 0;
    int I_pV = 0;


    bool r_mark_regions() {
        I_pV = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            if (!go_out_grouping(g_v, 1072, 1103))
            {
                break lab0;
            }
            cursor++;
            I_pV = cursor;
            if (!go_in_grouping(g_v, 1072, 1103))
            {
                break lab0;
            }
            cursor++;
            if (!go_out_grouping(g_v, 1072, 1103))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 1072, 1103))
            {
                break lab0;
            }
            cursor++;
            I_p2 = cursor;
            break lab0;
        }
        cursor = v_1;
        return true;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_perfective_gerund() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_0, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    lab1: while (true) {
                        if (!(eq_s_b("\u0430")))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    if (!(eq_s_b("\u044F")))
                    {
                        return false;
                    }
                    break lab0;
                }
                slice_del();
                break;
            case 2:
                slice_del();
                break;
        }
        return true;
    }

    bool r_adjective() {
        ket = cursor;
        if (find_among_b(a_1, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_adjectival() {
        int among_var;
        if (!r_adjective())
        {
            return false;
        }
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            among_var = find_among_b(a_2, null);
            if (among_var == 0)
            {
                cursor = limit - v_1;
                break lab0;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    lab1: while (true) {
                        lab2: while (true) {
                            if (!(eq_s_b("\u0430")))
                            {
                                break lab2;
                            }
                            break lab1;
                        }
                        if (!(eq_s_b("\u044F")))
                        {
                            cursor = limit - v_1;
                            break lab0;
                        }
                        break lab1;
                    }
                    slice_del();
                    break;
                case 2:
                    slice_del();
                    break;
            }
            break lab0;
        }
        return true;
    }

    bool r_reflexive() {
        ket = cursor;
        if (find_among_b(a_3, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_verb() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_4, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    lab1: while (true) {
                        if (!(eq_s_b("\u0430")))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    if (!(eq_s_b("\u044F")))
                    {
                        return false;
                    }
                    break lab0;
                }
                slice_del();
                break;
            case 2:
                slice_del();
                break;
        }
        return true;
    }

    bool r_noun() {
        ket = cursor;
        if (find_among_b(a_5, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_derivational() {
        ket = cursor;
        if (find_among_b(a_6, null) == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R2())
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_tidy_up() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_7, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_del();
                ket = cursor;
                if (!(eq_s_b("\u043D")))
                {
                    return false;
                }
                bra = cursor;
                if (!(eq_s_b("\u043D")))
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!(eq_s_b("\u043D")))
                {
                    return false;
                }
                slice_del();
                break;
            case 3:
                slice_del();
                break;
        }
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = cursor;
                lab2: while (true) {
                    golab3: while(true)
                    {
                        int v_3 = cursor;
                        lab4: while (true) {
                            bra = cursor;
                            if (!(eq_s("\u0451")))
                            {
                                break lab4;
                            }
                            ket = cursor;
                            cursor = v_3;
                            break golab3;
                        }
                        cursor = v_3;
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    slice_from("\u0435");
                    continue replab1;
                }
                cursor = v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = v_1;
        r_mark_regions();
        limit_backward = cursor;
        cursor = limit;
        if (cursor < I_pV)
        {
            return false;
        }
        int v_4 = limit_backward;
        limit_backward = I_pV;
        int v_5 = limit - cursor;
        lab5: while (true) {
            lab6: while (true) {
                int v_6 = limit - cursor;
                lab7: while (true) {
                    if (!r_perfective_gerund())
                    {
                        break lab7;
                    }
                    break lab6;
                }
                cursor = limit - v_6;
                int v_7 = limit - cursor;
                lab8: while (true) {
                    if (!r_reflexive())
                    {
                        cursor = limit - v_7;
                        break lab8;
                    }
                    break lab8;
                }
                lab9: while (true) {
                    int v_8 = limit - cursor;
                    lab10: while (true) {
                        if (!r_adjectival())
                        {
                            break lab10;
                        }
                        break lab9;
                    }
                    cursor = limit - v_8;
                    lab11: while (true) {
                        if (!r_verb())
                        {
                            break lab11;
                        }
                        break lab9;
                    }
                    cursor = limit - v_8;
                    if (!r_noun())
                    {
                        break lab5;
                    }
                    break lab9;
                }
                break lab6;
            }
            break lab5;
        }
        cursor = limit - v_5;
        int v_9 = limit - cursor;
        lab12: while (true) {
            ket = cursor;
            if (!(eq_s_b("\u0438")))
            {
                cursor = limit - v_9;
                break lab12;
            }
            bra = cursor;
            slice_del();
            break lab12;
        }
        int v_10 = limit - cursor;
        r_derivational();
        cursor = limit - v_10;
        int v_11 = limit - cursor;
        r_tidy_up();
        cursor = limit - v_11;
        limit_backward = v_4;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is russian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
