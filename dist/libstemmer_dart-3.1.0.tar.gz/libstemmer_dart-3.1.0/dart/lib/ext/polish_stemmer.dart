// Generated from polish.sbl by Snowball 3.1.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from polish.sbl by Snowball 3.1.0 - https://snowballstem.org/
 */
class polish_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("by\u015Bcie", -1, 1, 0),
        Among("bym", -1, 1, 0),
        Among("by", -1, 1, 0),
        Among("by\u015Bmy", -1, 1, 0),
        Among("by\u015B", -1, 1, 0)
    ];

    static final a_1 = [
        Among("\u0105c", -1, 1, 0),
        Among("aj\u0105c", 0, 1, 0),
        Among("sz\u0105c", 0, 2, 0),
        Among("sz", -1, 1, 0),
        Among("iejsz", 3, 1, 0)
    ];

    static final a_2 = [
        Among("a", -1, 1, 1),
        Among("\u0105ca", 0, 1, 0),
        Among("aj\u0105ca", 1, 1, 0),
        Among("sz\u0105ca", 1, 2, 0),
        Among("ia", 0, 1, 1),
        Among("sza", 0, 1, 0),
        Among("iejsza", 5, 1, 0),
        Among("a\u0142a", 0, 1, 0),
        Among("ia\u0142a", 7, 1, 0),
        Among("i\u0142a", 0, 1, 0),
        Among("\u0105c", -1, 1, 0),
        Among("aj\u0105c", 10, 1, 0),
        Among("e", -1, 1, 1),
        Among("\u0105ce", 12, 1, 0),
        Among("aj\u0105ce", 13, 1, 0),
        Among("sz\u0105ce", 13, 2, 0),
        Among("ie", 12, 1, 1),
        Among("cie", 16, 1, 0),
        Among("acie", 17, 1, 0),
        Among("ecie", 17, 1, 0),
        Among("icie", 17, 1, 0),
        Among("ajcie", 17, 1, 0),
        Among("li\u015Bcie", 17, 4, 0),
        Among("ali\u015Bcie", 22, 1, 0),
        Among("ieli\u015Bcie", 22, 1, 0),
        Among("ili\u015Bcie", 22, 1, 0),
        Among("\u0142y\u015Bcie", 17, 4, 0),
        Among("a\u0142y\u015Bcie", 26, 1, 0),
        Among("ia\u0142y\u015Bcie", 27, 1, 0),
        Among("i\u0142y\u015Bcie", 26, 1, 0),
        Among("sze", 12, 1, 0),
        Among("iejsze", 30, 1, 0),
        Among("ach", -1, 1, 1),
        Among("iach", 32, 1, 1),
        Among("ich", -1, 5, 0),
        Among("ych", -1, 5, 0),
        Among("i", -1, 1, 1),
        Among("ali", 36, 1, 0),
        Among("ieli", 36, 1, 0),
        Among("ili", 36, 1, 0),
        Among("ami", 36, 1, 1),
        Among("iami", 40, 1, 1),
        Among("imi", 36, 5, 0),
        Among("ymi", 36, 5, 0),
        Among("owi", 36, 1, 1),
        Among("iowi", 44, 1, 1),
        Among("aj", -1, 1, 0),
        Among("ej", -1, 5, 0),
        Among("iej", 47, 5, 0),
        Among("am", -1, 1, 0),
        Among("a\u0142am", 49, 1, 0),
        Among("ia\u0142am", 50, 1, 0),
        Among("i\u0142am", 49, 1, 0),
        Among("em", -1, 1, 1),
        Among("iem", 53, 1, 1),
        Among("a\u0142em", 53, 1, 0),
        Among("ia\u0142em", 55, 1, 0),
        Among("i\u0142em", 53, 1, 0),
        Among("im", -1, 5, 0),
        Among("om", -1, 1, 1),
        Among("iom", 59, 1, 1),
        Among("ym", -1, 5, 0),
        Among("o", -1, 1, 1),
        Among("ego", 62, 5, 0),
        Among("iego", 63, 5, 0),
        Among("a\u0142o", 62, 1, 0),
        Among("ia\u0142o", 65, 1, 0),
        Among("i\u0142o", 62, 1, 0),
        Among("u", -1, 1, 1),
        Among("iu", 68, 1, 1),
        Among("emu", 68, 5, 0),
        Among("iemu", 70, 5, 0),
        Among("\u00F3w", -1, 1, 1),
        Among("y", -1, 5, 0),
        Among("amy", 73, 1, 0),
        Among("emy", 73, 1, 0),
        Among("imy", 73, 1, 0),
        Among("li\u015Bmy", 73, 4, 0),
        Among("ali\u015Bmy", 77, 1, 0),
        Among("ieli\u015Bmy", 77, 1, 0),
        Among("ili\u015Bmy", 77, 1, 0),
        Among("\u0142y\u015Bmy", 73, 4, 0),
        Among("a\u0142y\u015Bmy", 81, 1, 0),
        Among("ia\u0142y\u015Bmy", 82, 1, 0),
        Among("i\u0142y\u015Bmy", 81, 1, 0),
        Among("a\u0142y", 73, 1, 0),
        Among("ia\u0142y", 85, 1, 0),
        Among("i\u0142y", 73, 1, 0),
        Among("asz", -1, 1, 0),
        Among("esz", -1, 1, 0),
        Among("isz", -1, 1, 0),
        Among("\u0105", -1, 1, 1),
        Among("\u0105c\u0105", 91, 1, 0),
        Among("aj\u0105c\u0105", 92, 1, 0),
        Among("sz\u0105c\u0105", 92, 2, 0),
        Among("i\u0105", 91, 1, 1),
        Among("aj\u0105", 91, 1, 0),
        Among("sz\u0105", 91, 3, 0),
        Among("iejsz\u0105", 97, 1, 0),
        Among("a\u0107", -1, 1, 0),
        Among("ie\u0107", -1, 1, 0),
        Among("i\u0107", -1, 1, 0),
        Among("\u0105\u0107", -1, 1, 0),
        Among("a\u015B\u0107", -1, 1, 0),
        Among("e\u015B\u0107", -1, 1, 0),
        Among("\u0119", -1, 1, 0),
        Among("sz\u0119", 105, 2, 0),
        Among("a\u0142", -1, 1, 0),
        Among("ia\u0142", 107, 1, 0),
        Among("i\u0142", -1, 1, 0),
        Among("\u0142a\u015B", -1, 4, 0),
        Among("a\u0142a\u015B", 110, 1, 0),
        Among("ia\u0142a\u015B", 111, 1, 0),
        Among("i\u0142a\u015B", 110, 1, 0),
        Among("\u0142e\u015B", -1, 4, 0),
        Among("a\u0142e\u015B", 114, 1, 0),
        Among("ia\u0142e\u015B", 115, 1, 0),
        Among("i\u0142e\u015B", 114, 1, 0)
    ];

    static final a_3 = [
        Among("\u0107", -1, 1, 0),
        Among("\u0144", -1, 2, 0),
        Among("\u015B", -1, 3, 0),
        Among("\u017A", -1, 4, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 16, 0, 0, 1]);

    int I_p1 = 0;


    bool r_mark_regions() {
        I_p1 = limit;
        if (!go_out_grouping(g_v, 97, 281))
        {
            return false;
        }
        cursor++;
        if (!go_in_grouping(g_v, 97, 281))
        {
            return false;
        }
        cursor++;
        I_p1 = cursor;
        return true;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_remove_endings() {
        int among_var;
        int v_1 = limit - cursor;
        lab0: while (true) {
            if (cursor < I_p1)
            {
                break lab0;
            }
            int v_2 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            if (find_among_b(a_0, null) == 0)
            {
                limit_backward = v_2;
                break lab0;
            }
            bra = cursor;
            limit_backward = v_2;
            slice_del();
            break lab0;
        }
        cursor = limit - v_1;
        ket = cursor;
        among_var = find_among_b(a_2, r_R1);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_from("s");
                break;
            case 3:
                lab1: while (true) {
                    int v_3 = limit - cursor;
                    lab2: while (true) {
                        if (!r_R1())
                        {
                            break lab2;
                        }
                        slice_del();
                        break lab1;
                    }
                    cursor = limit - v_3;
                    slice_from("s");
                    break lab1;
                }
                break;
            case 4:
                slice_from("\u0142");
                break;
            case 5:
                slice_del();
                int v_4 = limit - cursor;
                lab3: while (true) {
                    ket = cursor;
                    among_var = find_among_b(a_1, null);
                    if (among_var == 0)
                    {
                        cursor = limit - v_4;
                        break lab3;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            slice_del();
                            break;
                        case 2:
                            slice_from("s");
                            break;
                    }
                    break lab3;
                }
                break;
        }
        int v_5 = limit - cursor;
        lab4: while (true) {
            ket = cursor;
            if (!(eq_s_b("'")))
            {
                cursor = limit - v_5;
                break lab4;
            }
            bra = cursor;
            slice_del();
            break lab4;
        }
        return true;
    }

    bool r_normalize_consonant() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_3, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        lab0: while (true) {
            if (cursor > limit_backward)
            {
                break lab0;
            }
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("c");
                break;
            case 2:
                slice_from("n");
                break;
            case 3:
                slice_from("s");
                break;
            case 4:
                slice_from("z");
                break;
        }
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        r_mark_regions();
        cursor = v_1;
        lab0: while (true) {
            int v_2 = cursor;
            lab1: while (true) {
                {
                    int c = cursor + 2;
                    if (c > limit)
                    {
                        break lab1;
                    }
                    cursor = c;
                }
                limit_backward = cursor;
                cursor = limit;
                if (!r_remove_endings())
                {
                    break lab1;
                }
                cursor = limit_backward;
                break lab0;
            }
            cursor = v_2;
            limit_backward = cursor;
            cursor = limit;
            if (!r_normalize_consonant())
            {
                return false;
            }
            cursor = limit_backward;
            break lab0;
        }
        return true;
    }

    @override
    bool operator ==(Object other) => other is polish_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
