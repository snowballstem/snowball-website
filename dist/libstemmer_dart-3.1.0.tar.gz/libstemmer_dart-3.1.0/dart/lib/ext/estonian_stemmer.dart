// Generated from estonian.sbl by Snowball 3.1.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from estonian.sbl by Snowball 3.1.0 - https://snowballstem.org/
 */
class estonian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("gi", -1, 1, 0),
        Among("ki", -1, 2, 0)
    ];

    static final a_1 = [
        Among("da", -1, 3, 0),
        Among("mata", -1, 1, 0),
        Among("b", -1, 3, 0),
        Among("ksid", -1, 1, 0),
        Among("nuksid", 3, 1, 0),
        Among("me", -1, 3, 0),
        Among("sime", 5, 1, 0),
        Among("ksime", 6, 1, 0),
        Among("nuksime", 7, 1, 0),
        Among("akse", -1, 2, 0),
        Among("dakse", 9, 1, 0),
        Among("takse", 9, 1, 0),
        Among("site", -1, 1, 0),
        Among("ksite", 12, 1, 0),
        Among("nuksite", 13, 1, 0),
        Among("n", -1, 3, 0),
        Among("sin", 15, 1, 0),
        Among("ksin", 16, 1, 0),
        Among("nuksin", 17, 1, 0),
        Among("daks", -1, 1, 0),
        Among("taks", -1, 1, 0)
    ];

    static final a_2 = [
        Among("aa", -1, -1, 0),
        Among("ee", -1, -1, 0),
        Among("ii", -1, -1, 0),
        Among("oo", -1, -1, 0),
        Among("uu", -1, -1, 0),
        Among("\u00E4\u00E4", -1, -1, 0),
        Among("\u00F5\u00F5", -1, -1, 0),
        Among("\u00F6\u00F6", -1, -1, 0),
        Among("\u00FC\u00FC", -1, -1, 0)
    ];

    static final a_3 = [
        Among("lane", -1, 1, 0),
        Among("line", -1, 3, 0),
        Among("mine", -1, 2, 0),
        Among("lasse", -1, 1, 0),
        Among("lisse", -1, 3, 0),
        Among("misse", -1, 2, 0),
        Among("lasi", -1, 1, 0),
        Among("lisi", -1, 3, 0),
        Among("misi", -1, 2, 0),
        Among("last", -1, 1, 0),
        Among("list", -1, 3, 0),
        Among("mist", -1, 2, 0)
    ];

    static final a_4 = [
        Among("ga", -1, 1, 0),
        Among("ta", -1, 1, 0),
        Among("le", -1, 1, 0),
        Among("sse", -1, 1, 0),
        Among("l", -1, 1, 0),
        Among("s", -1, 1, 0),
        Among("ks", 5, 1, 0),
        Among("t", -1, 2, 0),
        Among("lt", 7, 1, 0),
        Among("st", 7, 1, 0)
    ];

    static final a_5 = [
        Among("", -1, 2, 0),
        Among("las", 0, 1, 0),
        Among("lis", 0, 1, 0),
        Among("mis", 0, 1, 0),
        Among("t", 0, -1, 0)
    ];

    static final a_6 = [
        Among("d", -1, 4, 0),
        Among("sid", 0, 2, 0),
        Among("de", -1, 4, 0),
        Among("ikkude", 2, 1, 0),
        Among("ike", -1, 1, 0),
        Among("ikke", -1, 1, 0),
        Among("te", -1, 3, 0)
    ];

    static final a_7 = [
        Among("va", -1, -1, 0),
        Among("du", -1, -1, 0),
        Among("nu", -1, -1, 0),
        Among("tu", -1, -1, 0)
    ];

    static final a_8 = [
        Among("kk", -1, 1, 0),
        Among("pp", -1, 2, 0),
        Among("tt", -1, 3, 0)
    ];

    static final a_9 = [
        Among("ma", -1, 2, 0),
        Among("mai", -1, 1, 0),
        Among("m", -1, 1, 0)
    ];

    static final a_10 = [
        Among("joob", -1, 1, 0),
        Among("jood", -1, 1, 0),
        Among("joodakse", 1, 1, 0),
        Among("jooma", -1, 1, 0),
        Among("joomata", 3, 1, 0),
        Among("joome", -1, 1, 0),
        Among("joon", -1, 1, 0),
        Among("joote", -1, 1, 0),
        Among("joovad", -1, 1, 0),
        Among("juua", -1, 1, 0),
        Among("juuakse", 9, 1, 0),
        Among("j\u00E4i", -1, 12, 0),
        Among("j\u00E4id", 11, 12, 0),
        Among("j\u00E4ime", 11, 12, 0),
        Among("j\u00E4in", 11, 12, 0),
        Among("j\u00E4ite", 11, 12, 0),
        Among("j\u00E4\u00E4b", -1, 12, 0),
        Among("j\u00E4\u00E4d", -1, 12, 0),
        Among("j\u00E4\u00E4da", 17, 12, 0),
        Among("j\u00E4\u00E4dakse", 18, 12, 0),
        Among("j\u00E4\u00E4di", 17, 12, 0),
        Among("j\u00E4\u00E4ks", -1, 12, 0),
        Among("j\u00E4\u00E4ksid", 21, 12, 0),
        Among("j\u00E4\u00E4ksime", 21, 12, 0),
        Among("j\u00E4\u00E4ksin", 21, 12, 0),
        Among("j\u00E4\u00E4ksite", 21, 12, 0),
        Among("j\u00E4\u00E4ma", -1, 12, 0),
        Among("j\u00E4\u00E4mata", 26, 12, 0),
        Among("j\u00E4\u00E4me", -1, 12, 0),
        Among("j\u00E4\u00E4n", -1, 12, 0),
        Among("j\u00E4\u00E4te", -1, 12, 0),
        Among("j\u00E4\u00E4vad", -1, 12, 0),
        Among("j\u00F5i", -1, 1, 0),
        Among("j\u00F5id", 32, 1, 0),
        Among("j\u00F5ime", 32, 1, 0),
        Among("j\u00F5in", 32, 1, 0),
        Among("j\u00F5ite", 32, 1, 0),
        Among("keeb", -1, 4, 0),
        Among("keed", -1, 4, 0),
        Among("keedakse", 38, 4, 0),
        Among("keeks", -1, 4, 0),
        Among("keeksid", 40, 4, 0),
        Among("keeksime", 40, 4, 0),
        Among("keeksin", 40, 4, 0),
        Among("keeksite", 40, 4, 0),
        Among("keema", -1, 4, 0),
        Among("keemata", 45, 4, 0),
        Among("keeme", -1, 4, 0),
        Among("keen", -1, 4, 0),
        Among("kees", -1, 4, 0),
        Among("keeta", -1, 4, 0),
        Among("keete", -1, 4, 0),
        Among("keevad", -1, 4, 0),
        Among("k\u00E4ia", -1, 8, 0),
        Among("k\u00E4iakse", 53, 8, 0),
        Among("k\u00E4ib", -1, 8, 0),
        Among("k\u00E4id", -1, 8, 0),
        Among("k\u00E4idi", 56, 8, 0),
        Among("k\u00E4iks", -1, 8, 0),
        Among("k\u00E4iksid", 58, 8, 0),
        Among("k\u00E4iksime", 58, 8, 0),
        Among("k\u00E4iksin", 58, 8, 0),
        Among("k\u00E4iksite", 58, 8, 0),
        Among("k\u00E4ima", -1, 8, 0),
        Among("k\u00E4imata", 63, 8, 0),
        Among("k\u00E4ime", -1, 8, 0),
        Among("k\u00E4in", -1, 8, 0),
        Among("k\u00E4is", -1, 8, 0),
        Among("k\u00E4ite", -1, 8, 0),
        Among("k\u00E4ivad", -1, 8, 0),
        Among("laob", -1, 16, 0),
        Among("laod", -1, 16, 0),
        Among("laoks", -1, 16, 0),
        Among("laoksid", 72, 16, 0),
        Among("laoksime", 72, 16, 0),
        Among("laoksin", 72, 16, 0),
        Among("laoksite", 72, 16, 0),
        Among("laome", -1, 16, 0),
        Among("laon", -1, 16, 0),
        Among("laote", -1, 16, 0),
        Among("laovad", -1, 16, 0),
        Among("loeb", -1, 14, 0),
        Among("loed", -1, 14, 0),
        Among("loeks", -1, 14, 0),
        Among("loeksid", 83, 14, 0),
        Among("loeksime", 83, 14, 0),
        Among("loeksin", 83, 14, 0),
        Among("loeksite", 83, 14, 0),
        Among("loeme", -1, 14, 0),
        Among("loen", -1, 14, 0),
        Among("loete", -1, 14, 0),
        Among("loevad", -1, 14, 0),
        Among("loob", -1, 7, 0),
        Among("lood", -1, 7, 0),
        Among("loodi", 93, 7, 0),
        Among("looks", -1, 7, 0),
        Among("looksid", 95, 7, 0),
        Among("looksime", 95, 7, 0),
        Among("looksin", 95, 7, 0),
        Among("looksite", 95, 7, 0),
        Among("looma", -1, 7, 0),
        Among("loomata", 100, 7, 0),
        Among("loome", -1, 7, 0),
        Among("loon", -1, 7, 0),
        Among("loote", -1, 7, 0),
        Among("loovad", -1, 7, 0),
        Among("luua", -1, 7, 0),
        Among("luuakse", 106, 7, 0),
        Among("l\u00F5i", -1, 6, 0),
        Among("l\u00F5id", 108, 6, 0),
        Among("l\u00F5ime", 108, 6, 0),
        Among("l\u00F5in", 108, 6, 0),
        Among("l\u00F5ite", 108, 6, 0),
        Among("l\u00F6\u00F6b", -1, 5, 0),
        Among("l\u00F6\u00F6d", -1, 5, 0),
        Among("l\u00F6\u00F6dakse", 114, 5, 0),
        Among("l\u00F6\u00F6di", 114, 5, 0),
        Among("l\u00F6\u00F6ks", -1, 5, 0),
        Among("l\u00F6\u00F6ksid", 117, 5, 0),
        Among("l\u00F6\u00F6ksime", 117, 5, 0),
        Among("l\u00F6\u00F6ksin", 117, 5, 0),
        Among("l\u00F6\u00F6ksite", 117, 5, 0),
        Among("l\u00F6\u00F6ma", -1, 5, 0),
        Among("l\u00F6\u00F6mata", 122, 5, 0),
        Among("l\u00F6\u00F6me", -1, 5, 0),
        Among("l\u00F6\u00F6n", -1, 5, 0),
        Among("l\u00F6\u00F6te", -1, 5, 0),
        Among("l\u00F6\u00F6vad", -1, 5, 0),
        Among("l\u00FC\u00FCa", -1, 5, 0),
        Among("l\u00FC\u00FCakse", 128, 5, 0),
        Among("m\u00FC\u00FCa", -1, 13, 0),
        Among("m\u00FC\u00FCakse", 130, 13, 0),
        Among("m\u00FC\u00FCb", -1, 13, 0),
        Among("m\u00FC\u00FCd", -1, 13, 0),
        Among("m\u00FC\u00FCdi", 133, 13, 0),
        Among("m\u00FC\u00FCks", -1, 13, 0),
        Among("m\u00FC\u00FCksid", 135, 13, 0),
        Among("m\u00FC\u00FCksime", 135, 13, 0),
        Among("m\u00FC\u00FCksin", 135, 13, 0),
        Among("m\u00FC\u00FCksite", 135, 13, 0),
        Among("m\u00FC\u00FCma", -1, 13, 0),
        Among("m\u00FC\u00FCmata", 140, 13, 0),
        Among("m\u00FC\u00FCme", -1, 13, 0),
        Among("m\u00FC\u00FCn", -1, 13, 0),
        Among("m\u00FC\u00FCs", -1, 13, 0),
        Among("m\u00FC\u00FCte", -1, 13, 0),
        Among("m\u00FC\u00FCvad", -1, 13, 0),
        Among("n\u00E4eb", -1, 18, 0),
        Among("n\u00E4ed", -1, 18, 0),
        Among("n\u00E4eks", -1, 18, 0),
        Among("n\u00E4eksid", 149, 18, 0),
        Among("n\u00E4eksime", 149, 18, 0),
        Among("n\u00E4eksin", 149, 18, 0),
        Among("n\u00E4eksite", 149, 18, 0),
        Among("n\u00E4eme", -1, 18, 0),
        Among("n\u00E4en", -1, 18, 0),
        Among("n\u00E4ete", -1, 18, 0),
        Among("n\u00E4evad", -1, 18, 0),
        Among("n\u00E4gema", -1, 18, 0),
        Among("n\u00E4gemata", 158, 18, 0),
        Among("n\u00E4ha", -1, 18, 0),
        Among("n\u00E4hakse", 160, 18, 0),
        Among("n\u00E4hti", -1, 18, 0),
        Among("p\u00F5eb", -1, 15, 0),
        Among("p\u00F5ed", -1, 15, 0),
        Among("p\u00F5eks", -1, 15, 0),
        Among("p\u00F5eksid", 165, 15, 0),
        Among("p\u00F5eksime", 165, 15, 0),
        Among("p\u00F5eksin", 165, 15, 0),
        Among("p\u00F5eksite", 165, 15, 0),
        Among("p\u00F5eme", -1, 15, 0),
        Among("p\u00F5en", -1, 15, 0),
        Among("p\u00F5ete", -1, 15, 0),
        Among("p\u00F5evad", -1, 15, 0),
        Among("saab", -1, 2, 0),
        Among("saad", -1, 2, 0),
        Among("saada", 175, 2, 0),
        Among("saadakse", 176, 2, 0),
        Among("saadi", 175, 2, 0),
        Among("saaks", -1, 2, 0),
        Among("saaksid", 179, 2, 0),
        Among("saaksime", 179, 2, 0),
        Among("saaksin", 179, 2, 0),
        Among("saaksite", 179, 2, 0),
        Among("saama", -1, 2, 0),
        Among("saamata", 184, 2, 0),
        Among("saame", -1, 2, 0),
        Among("saan", -1, 2, 0),
        Among("saate", -1, 2, 0),
        Among("saavad", -1, 2, 0),
        Among("sai", -1, 2, 0),
        Among("said", 190, 2, 0),
        Among("saime", 190, 2, 0),
        Among("sain", 190, 2, 0),
        Among("saite", 190, 2, 0),
        Among("s\u00F5i", -1, 9, 0),
        Among("s\u00F5id", 195, 9, 0),
        Among("s\u00F5ime", 195, 9, 0),
        Among("s\u00F5in", 195, 9, 0),
        Among("s\u00F5ite", 195, 9, 0),
        Among("s\u00F6\u00F6b", -1, 9, 0),
        Among("s\u00F6\u00F6d", -1, 9, 0),
        Among("s\u00F6\u00F6dakse", 201, 9, 0),
        Among("s\u00F6\u00F6di", 201, 9, 0),
        Among("s\u00F6\u00F6ks", -1, 9, 0),
        Among("s\u00F6\u00F6ksid", 204, 9, 0),
        Among("s\u00F6\u00F6ksime", 204, 9, 0),
        Among("s\u00F6\u00F6ksin", 204, 9, 0),
        Among("s\u00F6\u00F6ksite", 204, 9, 0),
        Among("s\u00F6\u00F6ma", -1, 9, 0),
        Among("s\u00F6\u00F6mata", 209, 9, 0),
        Among("s\u00F6\u00F6me", -1, 9, 0),
        Among("s\u00F6\u00F6n", -1, 9, 0),
        Among("s\u00F6\u00F6te", -1, 9, 0),
        Among("s\u00F6\u00F6vad", -1, 9, 0),
        Among("s\u00FC\u00FCa", -1, 9, 0),
        Among("s\u00FC\u00FCakse", 215, 9, 0),
        Among("teeb", -1, 17, 0),
        Among("teed", -1, 17, 0),
        Among("teeks", -1, 17, 0),
        Among("teeksid", 219, 17, 0),
        Among("teeksime", 219, 17, 0),
        Among("teeksin", 219, 17, 0),
        Among("teeksite", 219, 17, 0),
        Among("teeme", -1, 17, 0),
        Among("teen", -1, 17, 0),
        Among("teete", -1, 17, 0),
        Among("teevad", -1, 17, 0),
        Among("tegema", -1, 17, 0),
        Among("tegemata", 228, 17, 0),
        Among("teha", -1, 17, 0),
        Among("tehakse", 230, 17, 0),
        Among("tehti", -1, 17, 0),
        Among("toob", -1, 10, 0),
        Among("tood", -1, 10, 0),
        Among("toodi", 234, 10, 0),
        Among("tooks", -1, 10, 0),
        Among("tooksid", 236, 10, 0),
        Among("tooksime", 236, 10, 0),
        Among("tooksin", 236, 10, 0),
        Among("tooksite", 236, 10, 0),
        Among("tooma", -1, 10, 0),
        Among("toomata", 241, 10, 0),
        Among("toome", -1, 10, 0),
        Among("toon", -1, 10, 0),
        Among("toote", -1, 10, 0),
        Among("toovad", -1, 10, 0),
        Among("tuua", -1, 10, 0),
        Among("tuuakse", 247, 10, 0),
        Among("t\u00F5i", -1, 10, 0),
        Among("t\u00F5id", 249, 10, 0),
        Among("t\u00F5ime", 249, 10, 0),
        Among("t\u00F5in", 249, 10, 0),
        Among("t\u00F5ite", 249, 10, 0),
        Among("viia", -1, 3, 0),
        Among("viiakse", 254, 3, 0),
        Among("viib", -1, 3, 0),
        Among("viid", -1, 3, 0),
        Among("viidi", 257, 3, 0),
        Among("viiks", -1, 3, 0),
        Among("viiksid", 259, 3, 0),
        Among("viiksime", 259, 3, 0),
        Among("viiksin", 259, 3, 0),
        Among("viiksite", 259, 3, 0),
        Among("viima", -1, 3, 0),
        Among("viimata", 264, 3, 0),
        Among("viime", -1, 3, 0),
        Among("viin", -1, 3, 0),
        Among("viisime", -1, 3, 0),
        Among("viisin", -1, 3, 0),
        Among("viisite", -1, 3, 0),
        Among("viite", -1, 3, 0),
        Among("viivad", -1, 3, 0),
        Among("v\u00F5ib", -1, 11, 0),
        Among("v\u00F5id", -1, 11, 0),
        Among("v\u00F5ida", 274, 11, 0),
        Among("v\u00F5idakse", 275, 11, 0),
        Among("v\u00F5idi", 274, 11, 0),
        Among("v\u00F5iks", -1, 11, 0),
        Among("v\u00F5iksid", 278, 11, 0),
        Among("v\u00F5iksime", 278, 11, 0),
        Among("v\u00F5iksin", 278, 11, 0),
        Among("v\u00F5iksite", 278, 11, 0),
        Among("v\u00F5ima", -1, 11, 0),
        Among("v\u00F5imata", 283, 11, 0),
        Among("v\u00F5ime", -1, 11, 0),
        Among("v\u00F5in", -1, 11, 0),
        Among("v\u00F5is", -1, 11, 0),
        Among("v\u00F5ite", -1, 11, 0),
        Among("v\u00F5ivad", -1, 11, 0)
    ];

    static final g_V1 = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 48, 8]);

    static final g_RV = String.fromCharCodes([1, 0, 0, 0, 0, 0, 0, 68, 4, 65]);

    static final g_KI = String.fromCharCodes([117, 66, 6, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 0, 0, 0, 16]);

    static final g_GI = String.fromCharCodes([21, 123, 243, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 48, 8]);

    int I_p1 = 0;


    bool r_mark_regions() {
        I_p1 = limit;
        lab0: while (true) {
            int v_1 = cursor;
            lab1: while (true) {
                {
                    int c = cursor + 2;
                    if (c > limit)
                    {
                        break lab1;
                    }
                    cursor = c;
                }
                golab2: while(true)
                {
                    lab3: while (true) {
                        if (!(eq_s("'")))
                        {
                            break lab3;
                        }
                        break golab2;
                    }
                    if (cursor >= limit)
                    {
                        break lab1;
                    }
                    cursor++;
                }
                break lab0;
            }
            cursor = v_1;
            if (!go_out_grouping(g_V1, 97, 252))
            {
                return false;
            }
            cursor++;
            if (!go_in_grouping(g_V1, 97, 252))
            {
                return false;
            }
            cursor++;
            break lab0;
        }
        I_p1 = cursor;
        return true;
    }

    bool r_emphasis() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_0, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        int v_2 = limit - cursor;
        {
            int c = cursor - 4;
            if (c < limit_backward)
            {
                return false;
            }
            cursor = c;
        }
        cursor = limit - v_2;
        switch (among_var) {
            case 1:
                int v_3 = limit - cursor;
                if (!(in_grouping_b(g_GI, 97, 252)))
                {
                    return false;
                }
                cursor = limit - v_3;
                {
                    int v_4 = limit - cursor;
                    lab0: while (true) {
                        if (!r_LONGV())
                        {
                            break lab0;
                        }
                        return false;
                    }
                    cursor = limit - v_4;
                }
                slice_del();
                break;
            case 2:
                if (!(in_grouping_b(g_KI, 98, 382)))
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_verb() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_1, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_from("a");
                break;
            case 3:
                if (!(in_grouping_b(g_V1, 97, 252)))
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_LONGV() {
        return find_among_b(a_2, null) != 0;
    }

    bool r_i_plural() {
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (!(eq_s_b("i")))
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        if (!(in_grouping_b(g_RV, 39, 117)))
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_special_noun_endings() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_3, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_from("lase");
                break;
            case 2:
                slice_from("mise");
                break;
            case 3:
                slice_from("lise");
                break;
        }
        return true;
    }

    bool r_case_ending() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_4, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    lab1: while (true) {
                        if (!(in_grouping_b(g_RV, 39, 117)))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    if (!r_LONGV())
                    {
                        return false;
                    }
                    break lab0;
                }
                break;
            case 2:
                int v_2 = limit - cursor;
                {
                    int c = cursor - 4;
                    if (c < limit_backward)
                    {
                        return false;
                    }
                    cursor = c;
                }
                cursor = limit - v_2;
                break;
        }
        slice_del();
        return true;
    }

    bool r_plural_three_first_cases() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_6, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_from("iku");
                break;
            case 2:
                {
                    int v_2 = limit - cursor;
                    lab0: while (true) {
                        if (!r_LONGV())
                        {
                            break lab0;
                        }
                        return false;
                    }
                    cursor = limit - v_2;
                }
                slice_del();
                break;
            case 3:
                lab1: while (true) {
                    int v_3 = limit - cursor;
                    lab2: while (true) {
                        int v_4 = limit - cursor;
                        {
                            int c = cursor - 4;
                            if (c < limit_backward)
                            {
                                break lab2;
                            }
                            cursor = c;
                        }
                        cursor = limit - v_4;
                        among_var = find_among_b(a_5, null);
                        switch (among_var) {
                            case 1:
                                slice_from("e");
                                break;
                            case 2:
                                slice_del();
                                break;
                        }
                        break lab1;
                    }
                    cursor = limit - v_3;
                    slice_from("t");
                    break lab1;
                }
                break;
            case 4:
                lab3: while (true) {
                    lab4: while (true) {
                        if (!(in_grouping_b(g_RV, 39, 117)))
                        {
                            break lab4;
                        }
                        break lab3;
                    }
                    if (!r_LONGV())
                    {
                        return false;
                    }
                    break lab3;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_nu() {
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (find_among_b(a_7, null) == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        slice_del();
        return true;
    }

    bool r_undouble_kpt() {
        int among_var;
        if (!(in_grouping_b(g_V1, 97, 252)))
        {
            return false;
        }
        if (I_p1 > cursor)
        {
            return false;
        }
        ket = cursor;
        among_var = find_among_b(a_8, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("k");
                break;
            case 2:
                slice_from("p");
                break;
            case 3:
                slice_from("t");
                break;
        }
        return true;
    }

    bool r_degrees() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_9, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                if (!(in_grouping_b(g_RV, 39, 117)))
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                slice_del();
                break;
        }
        return true;
    }

    bool r_substantive() {
        int v_1 = limit - cursor;
        r_special_noun_endings();
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        r_case_ending();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_plural_three_first_cases();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_degrees();
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        r_i_plural();
        cursor = limit - v_5;
        int v_6 = limit - cursor;
        r_nu();
        cursor = limit - v_6;
        return true;
    }

    bool r_verb_exceptions() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_10, null);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        if (cursor < limit)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("joo");
                break;
            case 2:
                slice_from("saa");
                break;
            case 3:
                slice_from("viima");
                break;
            case 4:
                slice_from("keesi");
                break;
            case 5:
                slice_from("l\u00F6\u00F6");
                break;
            case 6:
                slice_from("l\u00F5i");
                break;
            case 7:
                slice_from("loo");
                break;
            case 8:
                slice_from("k\u00E4isi");
                break;
            case 9:
                slice_from("s\u00F6\u00F6");
                break;
            case 10:
                slice_from("too");
                break;
            case 11:
                slice_from("v\u00F5isi");
                break;
            case 12:
                slice_from("j\u00E4\u00E4ma");
                break;
            case 13:
                slice_from("m\u00FC\u00FCsi");
                break;
            case 14:
                slice_from("luge");
                break;
            case 15:
                slice_from("p\u00F5de");
                break;
            case 16:
                slice_from("ladu");
                break;
            case 17:
                slice_from("tegi");
                break;
            case 18:
                slice_from("n\u00E4gi");
                break;
        }
        return true;
    }

    @override
    bool stem() {
        {
            int v_1 = cursor;
            lab0: while (true) {
                if (!r_verb_exceptions())
                {
                    break lab0;
                }
                return false;
            }
            cursor = v_1;
        }
        int v_2 = cursor;
        r_mark_regions();
        cursor = v_2;
        limit_backward = cursor;
        cursor = limit;
        int v_3 = limit - cursor;
        r_emphasis();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        lab1: while (true) {
            lab2: while (true) {
                int v_5 = limit - cursor;
                lab3: while (true) {
                    if (!r_verb())
                    {
                        break lab3;
                    }
                    break lab2;
                }
                cursor = limit - v_5;
                r_substantive();
                break lab2;
            }
            break lab1;
        }
        cursor = limit - v_4;
        int v_6 = limit - cursor;
        r_undouble_kpt();
        cursor = limit - v_6;
        ket = cursor;
        if (!(eq_s_b("'")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is estonian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
