// Generated from armenian.sbl by Snowball 3.1.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from armenian.sbl by Snowball 3.1.0 - https://snowballstem.org/
 */
class armenian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("\u0580\u0578\u0580\u0564", -1, 1, 0),
        Among("\u0565\u0580\u0578\u0580\u0564", 0, 1, 0),
        Among("\u0561\u056C\u056B", -1, 1, 0),
        Among("\u0561\u056F\u056B", -1, 1, 0),
        Among("\u0578\u0580\u0561\u056F", -1, 1, 0),
        Among("\u0565\u0572", -1, 1, 0),
        Among("\u0561\u056F\u0561\u0576", -1, 1, 0),
        Among("\u0561\u0580\u0561\u0576", -1, 1, 0),
        Among("\u0565\u0576", -1, 1, 0),
        Among("\u0565\u056F\u0565\u0576", 8, 1, 0),
        Among("\u0565\u0580\u0565\u0576", 8, 1, 0),
        Among("\u0578\u0580\u0567\u0576", -1, 1, 0),
        Among("\u056B\u0576", -1, 1, 0),
        Among("\u0563\u056B\u0576", 12, 1, 0),
        Among("\u0578\u057E\u056B\u0576", 12, 1, 0),
        Among("\u056C\u0561\u0575\u0576", -1, 1, 0),
        Among("\u057E\u0578\u0582\u0576", -1, 1, 0),
        Among("\u057A\u0565\u057D", -1, 1, 0),
        Among("\u056B\u057E", -1, 1, 0),
        Among("\u0561\u057F", -1, 1, 0),
        Among("\u0561\u057E\u0565\u057F", -1, 1, 0),
        Among("\u056F\u0578\u057F", -1, 1, 0),
        Among("\u0562\u0561\u0580", -1, 1, 0)
    ];

    static final a_1 = [
        Among("\u0561", -1, 1, 0),
        Among("\u0561\u0581\u0561", 0, 1, 0),
        Among("\u0565\u0581\u0561", 0, 1, 0),
        Among("\u057E\u0565", -1, 1, 0),
        Among("\u0561\u0581\u0580\u056B", -1, 1, 0),
        Among("\u0561\u0581\u056B", -1, 1, 0),
        Among("\u0565\u0581\u056B", -1, 1, 0),
        Among("\u057E\u0565\u0581\u056B", 6, 1, 0),
        Among("\u0561\u056C", -1, 1, 0),
        Among("\u0568\u0561\u056C", 8, 1, 0),
        Among("\u0561\u0576\u0561\u056C", 8, 1, 0),
        Among("\u0565\u0576\u0561\u056C", 8, 1, 0),
        Among("\u0561\u0581\u0576\u0561\u056C", 8, 1, 0),
        Among("\u0565\u056C", -1, 1, 0),
        Among("\u0568\u0565\u056C", 13, 1, 0),
        Among("\u0576\u0565\u056C", 13, 1, 0),
        Among("\u0581\u0576\u0565\u056C", 15, 1, 0),
        Among("\u0565\u0581\u0576\u0565\u056C", 16, 1, 0),
        Among("\u0579\u0565\u056C", 13, 1, 0),
        Among("\u057E\u0565\u056C", 13, 1, 0),
        Among("\u0561\u0581\u057E\u0565\u056C", 19, 1, 0),
        Among("\u0565\u0581\u057E\u0565\u056C", 19, 1, 0),
        Among("\u057F\u0565\u056C", 13, 1, 0),
        Among("\u0561\u057F\u0565\u056C", 22, 1, 0),
        Among("\u0578\u057F\u0565\u056C", 22, 1, 0),
        Among("\u056F\u0578\u057F\u0565\u056C", 24, 1, 0),
        Among("\u057E\u0561\u056E", -1, 1, 0),
        Among("\u0578\u0582\u0574", -1, 1, 0),
        Among("\u057E\u0578\u0582\u0574", 27, 1, 0),
        Among("\u0561\u0576", -1, 1, 0),
        Among("\u0581\u0561\u0576", 29, 1, 0),
        Among("\u0561\u0581\u0561\u0576", 30, 1, 0),
        Among("\u0561\u0581\u0580\u056B\u0576", -1, 1, 0),
        Among("\u0561\u0581\u056B\u0576", -1, 1, 0),
        Among("\u0565\u0581\u056B\u0576", -1, 1, 0),
        Among("\u057E\u0565\u0581\u056B\u0576", 34, 1, 0),
        Among("\u0561\u056C\u056B\u057D", -1, 1, 0),
        Among("\u0565\u056C\u056B\u057D", -1, 1, 0),
        Among("\u0561\u057E", -1, 1, 0),
        Among("\u0561\u0581\u0561\u057E", 38, 1, 0),
        Among("\u0565\u0581\u0561\u057E", 38, 1, 0),
        Among("\u0561\u056C\u0578\u057E", -1, 1, 0),
        Among("\u0565\u056C\u0578\u057E", -1, 1, 0),
        Among("\u0561\u0580", -1, 1, 0),
        Among("\u0561\u0581\u0561\u0580", 43, 1, 0),
        Among("\u0565\u0581\u0561\u0580", 43, 1, 0),
        Among("\u0561\u0581\u0580\u056B\u0580", -1, 1, 0),
        Among("\u0561\u0581\u056B\u0580", -1, 1, 0),
        Among("\u0565\u0581\u056B\u0580", -1, 1, 0),
        Among("\u057E\u0565\u0581\u056B\u0580", 48, 1, 0),
        Among("\u0561\u0581", -1, 1, 0),
        Among("\u0565\u0581", -1, 1, 0),
        Among("\u0561\u0581\u0580\u0565\u0581", 51, 1, 0),
        Among("\u0561\u056C\u0578\u0582\u0581", -1, 1, 0),
        Among("\u0565\u056C\u0578\u0582\u0581", -1, 1, 0),
        Among("\u0561\u056C\u0578\u0582", -1, 1, 0),
        Among("\u0565\u056C\u0578\u0582", -1, 1, 0),
        Among("\u0561\u0584", -1, 1, 0),
        Among("\u0581\u0561\u0584", 57, 1, 0),
        Among("\u0561\u0581\u0561\u0584", 58, 1, 0),
        Among("\u0561\u0581\u0580\u056B\u0584", -1, 1, 0),
        Among("\u0561\u0581\u056B\u0584", -1, 1, 0),
        Among("\u0565\u0581\u056B\u0584", -1, 1, 0),
        Among("\u057E\u0565\u0581\u056B\u0584", 62, 1, 0),
        Among("\u0561\u0576\u0584", -1, 1, 0),
        Among("\u0581\u0561\u0576\u0584", 64, 1, 0),
        Among("\u0561\u0581\u0561\u0576\u0584", 65, 1, 0),
        Among("\u0561\u0581\u0580\u056B\u0576\u0584", -1, 1, 0),
        Among("\u0561\u0581\u056B\u0576\u0584", -1, 1, 0),
        Among("\u0565\u0581\u056B\u0576\u0584", -1, 1, 0),
        Among("\u057E\u0565\u0581\u056B\u0576\u0584", 69, 1, 0)
    ];

    static final a_2 = [
        Among("\u0578\u0580\u0564", -1, 1, 0),
        Among("\u0578\u0582\u0575\u0569", -1, 1, 0),
        Among("\u0578\u0582\u0570\u056B", -1, 1, 0),
        Among("\u0581\u056B", -1, 1, 0),
        Among("\u056B\u056C", -1, 1, 0),
        Among("\u0561\u056F", -1, 1, 0),
        Among("\u0575\u0561\u056F", 5, 1, 0),
        Among("\u0561\u0576\u0561\u056F", 5, 1, 0),
        Among("\u056B\u056F", -1, 1, 0),
        Among("\u0578\u0582\u056F", -1, 1, 0),
        Among("\u0561\u0576", -1, 1, 0),
        Among("\u057A\u0561\u0576", 10, 1, 0),
        Among("\u057D\u057F\u0561\u0576", 10, 1, 0),
        Among("\u0561\u0580\u0561\u0576", 10, 1, 0),
        Among("\u0565\u0572\u0567\u0576", -1, 1, 0),
        Among("\u0575\u0578\u0582\u0576", -1, 1, 0),
        Among("\u0578\u0582\u0569\u0575\u0578\u0582\u0576", 15, 1, 0),
        Among("\u0561\u056E\u0578", -1, 1, 0),
        Among("\u056B\u0579", -1, 1, 0),
        Among("\u0578\u0582\u057D", -1, 1, 0),
        Among("\u0578\u0582\u057D\u057F", -1, 1, 0),
        Among("\u0563\u0561\u0580", -1, 1, 0),
        Among("\u057E\u0578\u0580", -1, 1, 0),
        Among("\u0561\u057E\u0578\u0580", 22, 1, 0),
        Among("\u0578\u0581", -1, 1, 0),
        Among("\u0561\u0576\u0585\u0581", -1, 1, 0),
        Among("\u0578\u0582", -1, 1, 0),
        Among("\u0584", -1, 1, 0),
        Among("\u0579\u0565\u0584", 27, 1, 0),
        Among("\u056B\u0584", 27, 1, 0),
        Among("\u0561\u056C\u056B\u0584", 29, 1, 0),
        Among("\u0561\u0576\u056B\u0584", 29, 1, 0),
        Among("\u057E\u0561\u056E\u0584", 27, 1, 0),
        Among("\u0578\u0582\u0575\u0584", 27, 1, 0),
        Among("\u0565\u0576\u0584", 27, 1, 0),
        Among("\u0578\u0576\u0584", 27, 1, 0),
        Among("\u0578\u0582\u0576\u0584", 27, 1, 0),
        Among("\u0574\u0578\u0582\u0576\u0584", 36, 1, 0),
        Among("\u056B\u0579\u0584", 27, 1, 0),
        Among("\u0561\u0580\u0584", 27, 1, 0)
    ];

    static final a_3 = [
        Among("\u057D\u0561", -1, 1, 0),
        Among("\u057E\u0561", -1, 1, 0),
        Among("\u0561\u0574\u0562", -1, 1, 0),
        Among("\u0564", -1, 1, 0),
        Among("\u0561\u0576\u0564", 3, 1, 0),
        Among("\u0578\u0582\u0569\u0575\u0561\u0576\u0564", 4, 1, 0),
        Among("\u057E\u0561\u0576\u0564", 4, 1, 0),
        Among("\u0578\u057B\u0564", 3, 1, 0),
        Among("\u0565\u0580\u0564", 3, 1, 0),
        Among("\u0576\u0565\u0580\u0564", 8, 1, 0),
        Among("\u0578\u0582\u0564", 3, 1, 0),
        Among("\u0568", -1, 1, 0),
        Among("\u0561\u0576\u0568", 11, 1, 0),
        Among("\u0578\u0582\u0569\u0575\u0561\u0576\u0568", 12, 1, 0),
        Among("\u057E\u0561\u0576\u0568", 12, 1, 0),
        Among("\u0578\u057B\u0568", 11, 1, 0),
        Among("\u0565\u0580\u0568", 11, 1, 0),
        Among("\u0576\u0565\u0580\u0568", 16, 1, 0),
        Among("\u056B", -1, 1, 0),
        Among("\u057E\u056B", 18, 1, 0),
        Among("\u0565\u0580\u056B", 18, 1, 0),
        Among("\u0576\u0565\u0580\u056B", 20, 1, 0),
        Among("\u0561\u0576\u0578\u0582\u0574", -1, 1, 0),
        Among("\u0565\u0580\u0578\u0582\u0574", -1, 1, 0),
        Among("\u0576\u0565\u0580\u0578\u0582\u0574", 23, 1, 0),
        Among("\u0576", -1, 1, 0),
        Among("\u0561\u0576", 25, 1, 0),
        Among("\u0578\u0582\u0569\u0575\u0561\u0576", 26, 1, 0),
        Among("\u057E\u0561\u0576", 26, 1, 0),
        Among("\u056B\u0576", 25, 1, 0),
        Among("\u0565\u0580\u056B\u0576", 29, 1, 0),
        Among("\u0576\u0565\u0580\u056B\u0576", 30, 1, 0),
        Among("\u0578\u0582\u0569\u0575\u0561\u0576\u0576", 25, 1, 0),
        Among("\u0565\u0580\u0576", 25, 1, 0),
        Among("\u0576\u0565\u0580\u0576", 33, 1, 0),
        Among("\u0578\u0582\u0576", 25, 1, 0),
        Among("\u0578\u057B", -1, 1, 0),
        Among("\u0578\u0582\u0569\u0575\u0561\u0576\u057D", -1, 1, 0),
        Among("\u057E\u0561\u0576\u057D", -1, 1, 0),
        Among("\u0578\u057B\u057D", -1, 1, 0),
        Among("\u0578\u057E", -1, 1, 0),
        Among("\u0561\u0576\u0578\u057E", 40, 1, 0),
        Among("\u057E\u0578\u057E", 40, 1, 0),
        Among("\u0565\u0580\u0578\u057E", 40, 1, 0),
        Among("\u0576\u0565\u0580\u0578\u057E", 43, 1, 0),
        Among("\u0565\u0580", -1, 1, 0),
        Among("\u0576\u0565\u0580", 45, 1, 0),
        Among("\u0581", -1, 1, 0),
        Among("\u056B\u0581", 47, 1, 0),
        Among("\u057E\u0561\u0576\u056B\u0581", 48, 1, 0),
        Among("\u0578\u057B\u056B\u0581", 48, 1, 0),
        Among("\u057E\u056B\u0581", 48, 1, 0),
        Among("\u0565\u0580\u056B\u0581", 48, 1, 0),
        Among("\u0576\u0565\u0580\u056B\u0581", 52, 1, 0),
        Among("\u0581\u056B\u0581", 48, 1, 0),
        Among("\u0578\u0581", 47, 1, 0),
        Among("\u0578\u0582\u0581", 47, 1, 0)
    ];

    static final g_v = String.fromCharCodes([209, 4, 128, 0, 18]);

    int I_p2 = 0;
    int I_pV = 0;


    bool r_mark_regions() {
        I_pV = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            if (!go_out_grouping(g_v, 1377, 1413))
            {
                break lab0;
            }
            cursor++;
            I_pV = cursor;
            if (!go_in_grouping(g_v, 1377, 1413))
            {
                break lab0;
            }
            cursor++;
            if (!go_out_grouping(g_v, 1377, 1413))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 1377, 1413))
            {
                break lab0;
            }
            cursor++;
            I_p2 = cursor;
            break lab0;
        }
        cursor = v_1;
        return true;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_adjective() {
        ket = cursor;
        if (find_among_b(a_0, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_verb() {
        ket = cursor;
        if (find_among_b(a_1, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_noun() {
        ket = cursor;
        if (find_among_b(a_2, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_ending() {
        ket = cursor;
        if (find_among_b(a_3, null) == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R2())
        {
            return false;
        }
        slice_del();
        return true;
    }

    @override
    bool stem() {
        r_mark_regions();
        limit_backward = cursor;
        cursor = limit;
        if (cursor < I_pV)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_pV;
        int v_2 = limit - cursor;
        r_ending();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_verb();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_adjective();
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        r_noun();
        cursor = limit - v_5;
        limit_backward = v_1;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is armenian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
