// Generated from italian.sbl by Snowball 3.1.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from italian.sbl by Snowball 3.1.0 - https://snowballstem.org/
 */
class italian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("all'", -1, -1, 0),
        Among("d'", -1, -1, 0),
        Among("dall'", -1, -1, 0),
        Among("dell'", -1, -1, 0),
        Among("gl'", -1, -1, 0),
        Among("l'", -1, -1, 0),
        Among("m'", -1, -1, 0),
        Among("nell'", -1, -1, 0),
        Among("quell'", -1, -1, 0),
        Among("quest'", -1, -1, 0),
        Among("s'", -1, -1, 0),
        Among("sull'", -1, -1, 0),
        Among("t'", -1, -1, 0),
        Among("tutt'", -1, -1, 0),
        Among("un'", -1, -1, 0),
        Among("v'", -1, -1, 0)
    ];

    static final a_1 = [
        Among("", -1, 7, 0),
        Among("qu", 0, 6, 0),
        Among("\u00E1", 0, 1, 0),
        Among("\u00E9", 0, 2, 0),
        Among("\u00ED", 0, 3, 0),
        Among("\u00F3", 0, 4, 0),
        Among("\u00FA", 0, 5, 0)
    ];

    static final a_2 = [
        Among("", -1, 3, 0),
        Among("I", 0, 1, 0),
        Among("U", 0, 2, 0)
    ];

    static final a_3 = [
        Among("la", -1, -1, 0),
        Among("cela", 0, -1, 0),
        Among("gliela", 0, -1, 0),
        Among("mela", 0, -1, 0),
        Among("tela", 0, -1, 0),
        Among("vela", 0, -1, 0),
        Among("le", -1, -1, 0),
        Among("cele", 6, -1, 0),
        Among("gliele", 6, -1, 0),
        Among("mele", 6, -1, 0),
        Among("tele", 6, -1, 0),
        Among("vele", 6, -1, 0),
        Among("ne", -1, -1, 0),
        Among("cene", 12, -1, 0),
        Among("gliene", 12, -1, 0),
        Among("mene", 12, -1, 0),
        Among("sene", 12, -1, 0),
        Among("tene", 12, -1, 0),
        Among("vene", 12, -1, 0),
        Among("ci", -1, -1, 0),
        Among("li", -1, -1, 0),
        Among("celi", 20, -1, 0),
        Among("glieli", 20, -1, 0),
        Among("meli", 20, -1, 0),
        Among("teli", 20, -1, 0),
        Among("veli", 20, -1, 0),
        Among("gli", 20, -1, 0),
        Among("mi", -1, -1, 0),
        Among("si", -1, -1, 0),
        Among("ti", -1, -1, 0),
        Among("vi", -1, -1, 0),
        Among("lo", -1, -1, 0),
        Among("celo", 31, -1, 0),
        Among("glielo", 31, -1, 0),
        Among("melo", 31, -1, 0),
        Among("telo", 31, -1, 0),
        Among("velo", 31, -1, 0)
    ];

    static final a_4 = [
        Among("ando", -1, 1, 0),
        Among("endo", -1, 1, 0),
        Among("ar", -1, 2, 0),
        Among("er", -1, 2, 0),
        Among("ir", -1, 2, 0)
    ];

    static final a_5 = [
        Among("ic", -1, -1, 0),
        Among("abil", -1, -1, 0),
        Among("os", -1, -1, 0),
        Among("iv", -1, 1, 0)
    ];

    static final a_6 = [
        Among("ic", -1, 1, 0),
        Among("abil", -1, 1, 0),
        Among("iv", -1, 1, 0)
    ];

    static final a_7 = [
        Among("ica", -1, 1, 0),
        Among("logia", -1, 3, 0),
        Among("osa", -1, 1, 0),
        Among("ista", -1, 1, 0),
        Among("iva", -1, 9, 0),
        Among("anza", -1, 1, 0),
        Among("enza", -1, 5, 0),
        Among("ice", -1, 1, 0),
        Among("atrice", 7, 1, 0),
        Among("iche", -1, 1, 0),
        Among("logie", -1, 3, 0),
        Among("abile", -1, 1, 0),
        Among("ibile", -1, 1, 0),
        Among("usione", -1, 4, 0),
        Among("azione", -1, 2, 0),
        Among("uzione", -1, 4, 0),
        Among("atore", -1, 2, 0),
        Among("ose", -1, 1, 0),
        Among("ante", -1, 1, 0),
        Among("mente", -1, 1, 0),
        Among("amente", 19, 7, 0),
        Among("iste", -1, 1, 0),
        Among("ive", -1, 9, 0),
        Among("anze", -1, 1, 0),
        Among("enze", -1, 5, 0),
        Among("ici", -1, 1, 0),
        Among("atrici", 25, 1, 0),
        Among("ichi", -1, 1, 0),
        Among("abili", -1, 1, 0),
        Among("ibili", -1, 1, 0),
        Among("ismi", -1, 1, 0),
        Among("usioni", -1, 4, 0),
        Among("azioni", -1, 2, 0),
        Among("uzioni", -1, 4, 0),
        Among("atori", -1, 2, 0),
        Among("osi", -1, 1, 0),
        Among("anti", -1, 1, 0),
        Among("amenti", -1, 6, 0),
        Among("imenti", -1, 6, 0),
        Among("isti", -1, 1, 0),
        Among("ivi", -1, 9, 0),
        Among("ico", -1, 1, 0),
        Among("ismo", -1, 1, 0),
        Among("oso", -1, 1, 0),
        Among("amento", -1, 6, 0),
        Among("imento", -1, 6, 0),
        Among("ivo", -1, 9, 0),
        Among("it\u00E0", -1, 8, 0),
        Among("ist\u00E0", -1, 1, 0),
        Among("ist\u00E8", -1, 1, 0),
        Among("ist\u00EC", -1, 1, 0)
    ];

    static final a_8 = [
        Among("isca", -1, 1, 0),
        Among("enda", -1, 1, 0),
        Among("ata", -1, 1, 0),
        Among("ita", -1, 1, 0),
        Among("uta", -1, 1, 0),
        Among("ava", -1, 1, 0),
        Among("eva", -1, 1, 0),
        Among("iva", -1, 1, 0),
        Among("erebbe", -1, 1, 0),
        Among("irebbe", -1, 1, 0),
        Among("isce", -1, 1, 0),
        Among("ende", -1, 1, 0),
        Among("are", -1, 1, 0),
        Among("ere", -1, 1, 0),
        Among("ire", -1, 1, 0),
        Among("asse", -1, 1, 0),
        Among("ate", -1, 1, 0),
        Among("avate", 16, 1, 0),
        Among("evate", 16, 1, 0),
        Among("ivate", 16, 1, 0),
        Among("ete", -1, 1, 0),
        Among("erete", 20, 1, 0),
        Among("irete", 20, 1, 0),
        Among("ite", -1, 1, 0),
        Among("ereste", -1, 1, 0),
        Among("ireste", -1, 1, 0),
        Among("ute", -1, 1, 0),
        Among("erai", -1, 1, 0),
        Among("irai", -1, 1, 0),
        Among("isci", -1, 1, 0),
        Among("endi", -1, 1, 0),
        Among("erei", -1, 1, 0),
        Among("irei", -1, 1, 0),
        Among("assi", -1, 1, 0),
        Among("ati", -1, 1, 0),
        Among("iti", -1, 1, 0),
        Among("eresti", -1, 1, 0),
        Among("iresti", -1, 1, 0),
        Among("uti", -1, 1, 0),
        Among("avi", -1, 1, 0),
        Among("evi", -1, 1, 0),
        Among("ivi", -1, 1, 0),
        Among("isco", -1, 1, 0),
        Among("ando", -1, 1, 0),
        Among("endo", -1, 1, 0),
        Among("Yamo", -1, 1, 0),
        Among("iamo", -1, 1, 0),
        Among("avamo", -1, 1, 0),
        Among("evamo", -1, 1, 0),
        Among("ivamo", -1, 1, 0),
        Among("eremo", -1, 1, 0),
        Among("iremo", -1, 1, 0),
        Among("assimo", -1, 1, 0),
        Among("ammo", -1, 1, 0),
        Among("emmo", -1, 1, 0),
        Among("eremmo", 54, 1, 0),
        Among("iremmo", 54, 1, 0),
        Among("immo", -1, 1, 0),
        Among("ano", -1, 1, 0),
        Among("iscano", 58, 1, 0),
        Among("avano", 58, 1, 0),
        Among("evano", 58, 1, 0),
        Among("ivano", 58, 1, 0),
        Among("eranno", -1, 1, 0),
        Among("iranno", -1, 1, 0),
        Among("ono", -1, 1, 0),
        Among("iscono", 65, 1, 0),
        Among("arono", 65, 1, 0),
        Among("erono", 65, 1, 0),
        Among("irono", 65, 1, 0),
        Among("erebbero", -1, 1, 0),
        Among("irebbero", -1, 1, 0),
        Among("assero", -1, 1, 0),
        Among("essero", -1, 1, 0),
        Among("issero", -1, 1, 0),
        Among("ato", -1, 1, 0),
        Among("ito", -1, 1, 0),
        Among("uto", -1, 1, 0),
        Among("avo", -1, 1, 0),
        Among("evo", -1, 1, 0),
        Among("ivo", -1, 1, 0),
        Among("ar", -1, 1, 0),
        Among("ir", -1, 1, 0),
        Among("er\u00E0", -1, 1, 0),
        Among("ir\u00E0", -1, 1, 0),
        Among("er\u00F2", -1, 1, 0),
        Among("ir\u00F2", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 128, 8, 2, 1]);

    static final g_AEIO = String.fromCharCodes([17, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 128, 8, 2]);

    static final g_CG = String.fromCharCodes([17]);

    int I_p2 = 0;
    int I_p1 = 0;
    int I_pV = 0;


    bool r_elisions() {
        bra = cursor;
        if (find_among(a_0, null) == 0)
        {
            return false;
        }
        ket = cursor;
        lab0: while (true) {
            if (cursor < limit)
            {
                break lab0;
            }
            return false;
        }
        slice_del();
        return true;
    }

    bool r_prelude() {
        int among_var;
        int v_1 = cursor;
        replab0: while(true)
        {
            int v_2 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_1, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("\u00E0");
                        break;
                    case 2:
                        slice_from("\u00E8");
                        break;
                    case 3:
                        slice_from("\u00EC");
                        break;
                    case 4:
                        slice_from("\u00F2");
                        break;
                    case 5:
                        slice_from("\u00F9");
                        break;
                    case 6:
                        slice_from("qU");
                        break;
                    case 7:
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break;
                }
                continue replab0;
            }
            cursor = v_2;
            break replab0;
        }
        cursor = v_1;
        replab2: while(true)
        {
            int v_3 = cursor;
            lab3: while (true) {
                golab4: while(true)
                {
                    int v_4 = cursor;
                    lab5: while (true) {
                        if (!(in_grouping(g_v, 97, 249)))
                        {
                            break lab5;
                        }
                        bra = cursor;
                        lab6: while (true) {
                            int v_5 = cursor;
                            lab7: while (true) {
                                if (!(eq_s("u")))
                                {
                                    break lab7;
                                }
                                ket = cursor;
                                if (!(in_grouping(g_v, 97, 249)))
                                {
                                    break lab7;
                                }
                                slice_from("U");
                                break lab6;
                            }
                            cursor = v_5;
                            if (!(eq_s("i")))
                            {
                                break lab5;
                            }
                            ket = cursor;
                            if (!(in_grouping(g_v, 97, 249)))
                            {
                                break lab5;
                            }
                            slice_from("I");
                            break lab6;
                        }
                        cursor = v_4;
                        break golab4;
                    }
                    cursor = v_4;
                    if (cursor >= limit)
                    {
                        break lab3;
                    }
                    cursor++;
                }
                continue replab2;
            }
            cursor = v_3;
            break replab2;
        }
        return true;
    }

    bool r_mark_regions() {
        I_pV = limit;
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_2 = cursor;
                lab2: while (true) {
                    if (!(in_grouping(g_v, 97, 249)))
                    {
                        break lab2;
                    }
                    lab3: while (true) {
                        int v_3 = cursor;
                        lab4: while (true) {
                            if (!(out_grouping(g_v, 97, 249)))
                            {
                                break lab4;
                            }
                            if (!go_out_grouping(g_v, 97, 249))
                            {
                                break lab4;
                            }
                            cursor++;
                            break lab3;
                        }
                        cursor = v_3;
                        if (!(in_grouping(g_v, 97, 249)))
                        {
                            break lab2;
                        }
                        if (!go_in_grouping(g_v, 97, 249))
                        {
                            break lab2;
                        }
                        cursor++;
                        break lab3;
                    }
                    break lab1;
                }
                cursor = v_2;
                lab5: while (true) {
                    if (!(eq_s("divan")))
                    {
                        break lab5;
                    }
                    break lab1;
                }
                cursor = v_2;
                if (!(out_grouping(g_v, 97, 249)))
                {
                    break lab0;
                }
                lab6: while (true) {
                    int v_4 = cursor;
                    lab7: while (true) {
                        if (!(out_grouping(g_v, 97, 249)))
                        {
                            break lab7;
                        }
                        if (!go_out_grouping(g_v, 97, 249))
                        {
                            break lab7;
                        }
                        cursor++;
                        break lab6;
                    }
                    cursor = v_4;
                    if (!(in_grouping(g_v, 97, 249)))
                    {
                        break lab0;
                    }
                    if (cursor >= limit)
                    {
                        break lab0;
                    }
                    cursor++;
                    break lab6;
                }
                break lab1;
            }
            I_pV = cursor;
            break lab0;
        }
        cursor = v_1;
        int v_5 = cursor;
        lab8: while (true) {
            if (!go_out_grouping(g_v, 97, 249))
            {
                break lab8;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 249))
            {
                break lab8;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 249))
            {
                break lab8;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 249))
            {
                break lab8;
            }
            cursor++;
            I_p2 = cursor;
            break lab8;
        }
        cursor = v_5;
        return true;
    }

    bool r_postlude() {
        int among_var;
        replab0: while(true)
        {
            int v_1 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_2, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("i");
                        break;
                    case 2:
                        slice_from("u");
                        break;
                    case 3:
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break;
                }
                continue replab0;
            }
            cursor = v_1;
            break replab0;
        }
        return true;
    }

    bool r_RV() {
        return I_pV <= cursor;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_attached_pronoun() {
        int among_var;
        ket = cursor;
        if (find_among_b(a_3, null) == 0)
        {
            return false;
        }
        bra = cursor;
        among_var = find_among_b(a_4, null);
        if (among_var == 0)
        {
            return false;
        }
        if (!r_RV())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_from("e");
                break;
        }
        return true;
    }

    bool r_standard_suffix() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_7, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                int v_1 = limit - cursor;
                lab0: while (true) {
                    ket = cursor;
                    if (!(eq_s_b("ic")))
                    {
                        cursor = limit - v_1;
                        break lab0;
                    }
                    bra = cursor;
                    if (!r_R2())
                    {
                        cursor = limit - v_1;
                        break lab0;
                    }
                    slice_del();
                    break lab0;
                }
                break;
            case 3:
                if (!r_R2())
                {
                    return false;
                }
                slice_from("log");
                break;
            case 4:
                if (!r_R2())
                {
                    return false;
                }
                slice_from("u");
                break;
            case 5:
                if (!r_R2())
                {
                    return false;
                }
                slice_from("ente");
                break;
            case 6:
                if (!r_RV())
                {
                    return false;
                }
                slice_del();
                break;
            case 7:
                if (!r_R1())
                {
                    return false;
                }
                slice_del();
                int v_2 = limit - cursor;
                lab1: while (true) {
                    ket = cursor;
                    among_var = find_among_b(a_5, null);
                    if (among_var == 0)
                    {
                        cursor = limit - v_2;
                        break lab1;
                    }
                    bra = cursor;
                    if (!r_R2())
                    {
                        cursor = limit - v_2;
                        break lab1;
                    }
                    slice_del();
                    switch (among_var) {
                        case 1:
                            ket = cursor;
                            if (!(eq_s_b("at")))
                            {
                                cursor = limit - v_2;
                                break lab1;
                            }
                            bra = cursor;
                            if (!r_R2())
                            {
                                cursor = limit - v_2;
                                break lab1;
                            }
                            slice_del();
                            break;
                    }
                    break lab1;
                }
                break;
            case 8:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                int v_3 = limit - cursor;
                lab2: while (true) {
                    ket = cursor;
                    if (find_among_b(a_6, null) == 0)
                    {
                        cursor = limit - v_3;
                        break lab2;
                    }
                    bra = cursor;
                    if (!r_R2())
                    {
                        cursor = limit - v_3;
                        break lab2;
                    }
                    slice_del();
                    break lab2;
                }
                break;
            case 9:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                int v_4 = limit - cursor;
                lab3: while (true) {
                    ket = cursor;
                    if (!(eq_s_b("at")))
                    {
                        cursor = limit - v_4;
                        break lab3;
                    }
                    bra = cursor;
                    if (!r_R2())
                    {
                        cursor = limit - v_4;
                        break lab3;
                    }
                    slice_del();
                    ket = cursor;
                    if (!(eq_s_b("ic")))
                    {
                        cursor = limit - v_4;
                        break lab3;
                    }
                    bra = cursor;
                    if (!r_R2())
                    {
                        cursor = limit - v_4;
                        break lab3;
                    }
                    slice_del();
                    break lab3;
                }
                break;
        }
        return true;
    }

    bool r_verb_suffix() {
        if (cursor < I_pV)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_pV;
        ket = cursor;
        if (find_among_b(a_8, null) == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        slice_del();
        limit_backward = v_1;
        return true;
    }

    bool r_vowel_suffix() {
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            if (!(in_grouping_b(g_AEIO, 97, 242)))
            {
                cursor = limit - v_1;
                break lab0;
            }
            bra = cursor;
            if (!r_RV())
            {
                cursor = limit - v_1;
                break lab0;
            }
            slice_del();
            ket = cursor;
            if (!(eq_s_b("i")))
            {
                cursor = limit - v_1;
                break lab0;
            }
            bra = cursor;
            if (!r_RV())
            {
                cursor = limit - v_1;
                break lab0;
            }
            slice_del();
            break lab0;
        }
        int v_2 = limit - cursor;
        lab1: while (true) {
            ket = cursor;
            if (!(eq_s_b("h")))
            {
                cursor = limit - v_2;
                break lab1;
            }
            bra = cursor;
            if (!(in_grouping_b(g_CG, 99, 103)))
            {
                cursor = limit - v_2;
                break lab1;
            }
            if (!r_RV())
            {
                cursor = limit - v_2;
                break lab1;
            }
            slice_del();
            break lab1;
        }
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        r_elisions();
        cursor = v_1;
        int v_2 = cursor;
        r_prelude();
        cursor = v_2;
        r_mark_regions();
        limit_backward = cursor;
        cursor = limit;
        int v_3 = limit - cursor;
        r_attached_pronoun();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_5 = limit - cursor;
                lab2: while (true) {
                    if (!r_standard_suffix())
                    {
                        break lab2;
                    }
                    break lab1;
                }
                cursor = limit - v_5;
                if (!r_verb_suffix())
                {
                    break lab0;
                }
                break lab1;
            }
            break lab0;
        }
        cursor = limit - v_4;
        int v_6 = limit - cursor;
        r_vowel_suffix();
        cursor = limit - v_6;
        cursor = limit_backward;
        int v_7 = cursor;
        r_postlude();
        cursor = v_7;
        return true;
    }

    @override
    bool operator ==(Object other) => other is italian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
