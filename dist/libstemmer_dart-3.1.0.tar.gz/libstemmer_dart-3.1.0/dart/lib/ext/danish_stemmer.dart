// Generated from danish.sbl by Snowball 3.1.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from danish.sbl by Snowball 3.1.0 - https://snowballstem.org/
 */
class danish_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("hed", -1, 1, 0),
        Among("ethed", 0, 1, 0),
        Among("ered", -1, 1, 0),
        Among("e", -1, 1, 0),
        Among("erede", 3, 1, 0),
        Among("ende", 3, 1, 0),
        Among("erende", 5, 1, 0),
        Among("ene", 3, 1, 0),
        Among("erne", 3, 1, 0),
        Among("ere", 3, 1, 0),
        Among("en", -1, 1, 0),
        Among("heden", 10, 1, 0),
        Among("eren", 10, 1, 0),
        Among("er", -1, 1, 0),
        Among("heder", 13, 1, 0),
        Among("erer", 13, 1, 0),
        Among("s", -1, 2, 0),
        Among("heds", 16, 1, 0),
        Among("es", 16, 1, 0),
        Among("endes", 18, 1, 0),
        Among("erendes", 19, 1, 0),
        Among("enes", 18, 1, 0),
        Among("ernes", 18, 1, 0),
        Among("eres", 18, 1, 0),
        Among("ens", 16, 1, 0),
        Among("hedens", 24, 1, 0),
        Among("erens", 24, 1, 0),
        Among("ers", 16, 1, 0),
        Among("ets", 16, 1, 0),
        Among("erets", 28, 1, 0),
        Among("et", -1, 1, 0),
        Among("eret", 30, 1, 0)
    ];

    static final a_1 = [
        Among("gd", -1, -1, 0),
        Among("dt", -1, -1, 0),
        Among("gt", -1, -1, 0),
        Among("kt", -1, -1, 0)
    ];

    static final a_2 = [
        Among("ig", -1, 1, 0),
        Among("lig", 0, 1, 0),
        Among("elig", 1, 1, 0),
        Among("els", -1, 1, 0),
        Among("l\u00F8st", -1, 2, 0)
    ];

    static final g_undouble_c = String.fromCharCodes([53, 94, 7]);

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 0, 128]);

    static final g_s_ending = String.fromCharCodes([1, 0, 0, 0, 0, 0, 0, 188, 251, 171, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64]);

    int I_p1 = 0;


    bool r_mark_regions() {
        I_p1 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_2 = cursor;
                lab2: while (true) {
                    golab3: while(true)
                    {
                        lab4: while (true) {
                            if (!(eq_s("'")))
                            {
                                break lab4;
                            }
                            break golab3;
                        }
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    break lab1;
                }
                cursor = v_2;
                if (!go_out_grouping(g_v, 97, 248))
                {
                    break lab0;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 248))
                {
                    break lab0;
                }
                cursor++;
                break lab1;
            }
            I_p1 = cursor;
            break lab0;
        }
        cursor = v_1;
        int v_3 = cursor;
        {
            int c = cursor + 3;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        lab5: while (true) {
            if (I_p1 >= cursor)
            {
                break lab5;
            }
            I_p1 = cursor;
            break lab5;
        }
        cursor = v_3;
        return true;
    }

    bool r_main_suffix() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_0, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                if (!(in_grouping_b(g_s_ending, 39, 229)))
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_consonant_pair() {
        int v_1 = limit - cursor;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_2 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (find_among_b(a_1, null) == 0)
        {
            limit_backward = v_2;
            return false;
        }
        bra = cursor;
        limit_backward = v_2;
        cursor = limit - v_1;
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor--;
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_other_suffix() {
        int among_var;
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            if (!(eq_s_b("st")))
            {
                break lab0;
            }
            bra = cursor;
            if (!(eq_s_b("ig")))
            {
                break lab0;
            }
            slice_del();
            break lab0;
        }
        cursor = limit - v_1;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_2 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            limit_backward = v_2;
            return false;
        }
        bra = cursor;
        limit_backward = v_2;
        switch (among_var) {
            case 1:
                slice_del();
                int v_3 = limit - cursor;
                r_consonant_pair();
                cursor = limit - v_3;
                break;
            case 2:
                slice_from("l\u00F8s");
                break;
        }
        return true;
    }

    bool r_undouble() {
        String S_ch;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (!(in_grouping_b(g_undouble_c, 98, 116)))
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        S_ch = slice_to();
        limit_backward = v_1;
        if (!(eq_s_b(S_ch)))
        {
            return false;
        }
        slice_del();
        return true;
    }

    @override
    bool stem() {
        if (!r_mark_regions())
        {
            return false;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        r_main_suffix();
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        r_consonant_pair();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_other_suffix();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_undouble();
        cursor = limit - v_4;
        ket = cursor;
        if (!(eq_s_b("'")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is danish_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
