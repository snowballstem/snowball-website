// Generated from hungarian.sbl by Snowball 3.1.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from hungarian.sbl by Snowball 3.1.0 - https://snowballstem.org/
 */
class hungarian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("\u00E1", -1, 1, 0),
        Among("\u00E9", -1, 2, 0)
    ];

    static final a_1 = [
        Among("bb", -1, -1, 0),
        Among("cc", -1, -1, 0),
        Among("dd", -1, -1, 0),
        Among("ff", -1, -1, 0),
        Among("gg", -1, -1, 0),
        Among("jj", -1, -1, 0),
        Among("kk", -1, -1, 0),
        Among("ll", -1, -1, 0),
        Among("mm", -1, -1, 0),
        Among("nn", -1, -1, 0),
        Among("pp", -1, -1, 0),
        Among("rr", -1, -1, 0),
        Among("ccs", -1, -1, 0),
        Among("ss", -1, -1, 0),
        Among("zzs", -1, -1, 0),
        Among("tt", -1, -1, 0),
        Among("vv", -1, -1, 0),
        Among("ggy", -1, -1, 0),
        Among("lly", -1, -1, 0),
        Among("nny", -1, -1, 0),
        Among("tty", -1, -1, 0),
        Among("ssz", -1, -1, 0),
        Among("zz", -1, -1, 0)
    ];

    static final a_2 = [
        Among("al", -1, 1, 0),
        Among("el", -1, 1, 0)
    ];

    static final a_3 = [
        Among("ba", -1, -1, 0),
        Among("ra", -1, -1, 0),
        Among("be", -1, -1, 0),
        Among("re", -1, -1, 0),
        Among("ig", -1, -1, 0),
        Among("nak", -1, -1, 0),
        Among("nek", -1, -1, 0),
        Among("val", -1, -1, 0),
        Among("vel", -1, -1, 0),
        Among("ul", -1, -1, 0),
        Among("n\u00E1l", -1, -1, 0),
        Among("n\u00E9l", -1, -1, 0),
        Among("b\u00F3l", -1, -1, 0),
        Among("r\u00F3l", -1, -1, 0),
        Among("t\u00F3l", -1, -1, 0),
        Among("\u00FCl", -1, -1, 0),
        Among("b\u0151l", -1, -1, 0),
        Among("r\u0151l", -1, -1, 0),
        Among("t\u0151l", -1, -1, 0),
        Among("n", -1, -1, 0),
        Among("an", 19, -1, 0),
        Among("ban", 20, -1, 0),
        Among("en", 19, -1, 0),
        Among("ben", 22, -1, 0),
        Among("k\u00E9ppen", 22, -1, 0),
        Among("on", 19, -1, 0),
        Among("\u00F6n", 19, -1, 0),
        Among("k\u00E9pp", -1, -1, 0),
        Among("kor", -1, -1, 0),
        Among("t", -1, -1, 0),
        Among("at", 29, -1, 0),
        Among("et", 29, -1, 0),
        Among("k\u00E9nt", 29, -1, 0),
        Among("ank\u00E9nt", 32, -1, 0),
        Among("enk\u00E9nt", 32, -1, 0),
        Among("onk\u00E9nt", 32, -1, 0),
        Among("ot", 29, -1, 0),
        Among("\u00E9rt", 29, -1, 0),
        Among("\u00F6t", 29, -1, 0),
        Among("hez", -1, -1, 0),
        Among("hoz", -1, -1, 0),
        Among("h\u00F6z", -1, -1, 0),
        Among("v\u00E1", -1, -1, 0),
        Among("v\u00E9", -1, -1, 0)
    ];

    static final a_4 = [
        Among("\u00E1n", -1, 2, 0),
        Among("\u00E9n", -1, 1, 0),
        Among("\u00E1nk\u00E9nt", -1, 2, 0)
    ];

    static final a_5 = [
        Among("stul", -1, 1, 0),
        Among("astul", 0, 1, 0),
        Among("\u00E1stul", 0, 2, 0),
        Among("st\u00FCl", -1, 1, 0),
        Among("est\u00FCl", 3, 1, 0),
        Among("\u00E9st\u00FCl", 3, 3, 0)
    ];

    static final a_6 = [
        Among("\u00E1", -1, 1, 0),
        Among("\u00E9", -1, 1, 0)
    ];

    static final a_7 = [
        Among("k", -1, 3, 0),
        Among("ak", 0, 3, 0),
        Among("ek", 0, 3, 0),
        Among("ok", 0, 3, 0),
        Among("\u00E1k", 0, 1, 0),
        Among("\u00E9k", 0, 2, 0),
        Among("\u00F6k", 0, 3, 0)
    ];

    static final a_8 = [
        Among("\u00E9i", -1, 1, 0),
        Among("\u00E1\u00E9i", 0, 3, 0),
        Among("\u00E9\u00E9i", 0, 2, 0),
        Among("\u00E9", -1, 1, 0),
        Among("k\u00E9", 3, 1, 0),
        Among("ak\u00E9", 4, 1, 0),
        Among("ek\u00E9", 4, 1, 0),
        Among("ok\u00E9", 4, 1, 0),
        Among("\u00E1k\u00E9", 4, 3, 0),
        Among("\u00E9k\u00E9", 4, 2, 0),
        Among("\u00F6k\u00E9", 4, 1, 0),
        Among("\u00E9\u00E9", 3, 2, 0)
    ];

    static final a_9 = [
        Among("a", -1, 1, 0),
        Among("ja", 0, 1, 0),
        Among("d", -1, 1, 0),
        Among("ad", 2, 1, 0),
        Among("ed", 2, 1, 0),
        Among("od", 2, 1, 0),
        Among("\u00E1d", 2, 2, 0),
        Among("\u00E9d", 2, 3, 0),
        Among("\u00F6d", 2, 1, 0),
        Among("e", -1, 1, 0),
        Among("je", 9, 1, 0),
        Among("nk", -1, 1, 0),
        Among("unk", 11, 1, 0),
        Among("\u00E1nk", 11, 2, 0),
        Among("\u00E9nk", 11, 3, 0),
        Among("\u00FCnk", 11, 1, 0),
        Among("uk", -1, 1, 0),
        Among("juk", 16, 1, 0),
        Among("\u00E1juk", 17, 2, 0),
        Among("\u00FCk", -1, 1, 0),
        Among("j\u00FCk", 19, 1, 0),
        Among("\u00E9j\u00FCk", 20, 3, 0),
        Among("m", -1, 1, 0),
        Among("am", 22, 1, 0),
        Among("em", 22, 1, 0),
        Among("om", 22, 1, 0),
        Among("\u00E1m", 22, 2, 0),
        Among("\u00E9m", 22, 3, 0),
        Among("o", -1, 1, 0),
        Among("\u00E1", -1, 2, 0),
        Among("\u00E9", -1, 3, 0)
    ];

    static final a_10 = [
        Among("id", -1, 1, 0),
        Among("aid", 0, 1, 0),
        Among("jaid", 1, 1, 0),
        Among("eid", 0, 1, 0),
        Among("jeid", 3, 1, 0),
        Among("\u00E1id", 0, 2, 0),
        Among("\u00E9id", 0, 3, 0),
        Among("i", -1, 1, 0),
        Among("ai", 7, 1, 0),
        Among("jai", 8, 1, 0),
        Among("ei", 7, 1, 0),
        Among("jei", 10, 1, 0),
        Among("\u00E1i", 7, 2, 0),
        Among("\u00E9i", 7, 3, 0),
        Among("itek", -1, 1, 0),
        Among("eitek", 14, 1, 0),
        Among("jeitek", 15, 1, 0),
        Among("\u00E9itek", 14, 3, 0),
        Among("ik", -1, 1, 0),
        Among("aik", 18, 1, 0),
        Among("jaik", 19, 1, 0),
        Among("eik", 18, 1, 0),
        Among("jeik", 21, 1, 0),
        Among("\u00E1ik", 18, 2, 0),
        Among("\u00E9ik", 18, 3, 0),
        Among("ink", -1, 1, 0),
        Among("aink", 25, 1, 0),
        Among("jaink", 26, 1, 0),
        Among("eink", 25, 1, 0),
        Among("jeink", 28, 1, 0),
        Among("\u00E1ink", 25, 2, 0),
        Among("\u00E9ink", 25, 3, 0),
        Among("aitok", -1, 1, 0),
        Among("jaitok", 32, 1, 0),
        Among("\u00E1itok", -1, 2, 0),
        Among("im", -1, 1, 0),
        Among("aim", 35, 1, 0),
        Among("jaim", 36, 1, 0),
        Among("eim", 35, 1, 0),
        Among("jeim", 38, 1, 0),
        Among("\u00E1im", 35, 2, 0),
        Among("\u00E9im", 35, 3, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 17, 36, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1]);

    int I_p1 = 0;


    bool r_mark_regions() {
        I_p1 = limit;
        lab0: while (true) {
            int v_1 = cursor;
            lab1: while (true) {
                if (!(in_grouping(g_v, 97, 369)))
                {
                    break lab1;
                }
                int v_2 = cursor;
                lab2: while (true) {
                    if (!go_in_grouping(g_v, 97, 369))
                    {
                        break lab2;
                    }
                    cursor++;
                    I_p1 = cursor;
                    break lab2;
                }
                cursor = v_2;
                break lab0;
            }
            cursor = v_1;
            if (!go_out_grouping(g_v, 97, 369))
            {
                return false;
            }
            cursor++;
            I_p1 = cursor;
            break lab0;
        }
        return true;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_v_ending() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_0, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("a");
                break;
            case 2:
                slice_from("e");
                break;
        }
        return true;
    }

    bool r_double() {
        int v_1 = limit - cursor;
        if (find_among_b(a_1, null) == 0)
        {
            return false;
        }
        cursor = limit - v_1;
        return true;
    }

    bool r_undouble() {
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor--;
        ket = cursor;
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor--;
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_instrum() {
        ket = cursor;
        if (find_among_b(a_2, null) == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        if (!r_double())
        {
            return false;
        }
        slice_del();
        return r_undouble();
    }

    bool r_case() {
        ket = cursor;
        if (find_among_b(a_3, null) == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        slice_del();
        return r_v_ending();
    }

    bool r_case_special() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_4, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("e");
                break;
            case 2:
                slice_from("a");
                break;
        }
        return true;
    }

    bool r_case_other() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_5, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_from("a");
                break;
            case 3:
                slice_from("e");
                break;
        }
        return true;
    }

    bool r_factive() {
        ket = cursor;
        if (find_among_b(a_6, null) == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        if (!r_double())
        {
            return false;
        }
        slice_del();
        return r_undouble();
    }

    bool r_plural() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_7, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("a");
                break;
            case 2:
                slice_from("e");
                break;
            case 3:
                slice_del();
                break;
        }
        return true;
    }

    bool r_owned() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_8, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_from("e");
                break;
            case 3:
                slice_from("a");
                break;
        }
        return true;
    }

    bool r_sing_owner() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_9, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_from("a");
                break;
            case 3:
                slice_from("e");
                break;
        }
        return true;
    }

    bool r_plur_owner() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_10, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_from("a");
                break;
            case 3:
                slice_from("e");
                break;
        }
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        r_mark_regions();
        cursor = v_1;
        limit_backward = cursor;
        cursor = limit;
        int v_2 = limit - cursor;
        r_instrum();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_case();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_case_special();
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        r_case_other();
        cursor = limit - v_5;
        int v_6 = limit - cursor;
        r_factive();
        cursor = limit - v_6;
        int v_7 = limit - cursor;
        r_owned();
        cursor = limit - v_7;
        int v_8 = limit - cursor;
        r_sing_owner();
        cursor = limit - v_8;
        int v_9 = limit - cursor;
        r_plur_owner();
        cursor = limit - v_9;
        int v_10 = limit - cursor;
        r_plural();
        cursor = limit - v_10;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is hungarian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
