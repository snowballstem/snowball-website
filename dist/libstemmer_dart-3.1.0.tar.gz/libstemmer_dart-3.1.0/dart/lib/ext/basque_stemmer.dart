// Generated from basque.sbl by Snowball 3.1.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from basque.sbl by Snowball 3.1.0 - https://snowballstem.org/
 */
class basque_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("idea", -1, 1, 0),
        Among("bidea", 0, 1, 0),
        Among("kidea", 0, 1, 0),
        Among("pidea", 0, 1, 0),
        Among("kundea", -1, 1, 0),
        Among("galea", -1, 1, 0),
        Among("tailea", -1, 1, 0),
        Among("tzailea", -1, 1, 0),
        Among("gunea", -1, 1, 0),
        Among("kunea", -1, 1, 0),
        Among("tzaga", -1, 1, 0),
        Among("gaia", -1, 1, 0),
        Among("aldia", -1, 1, 0),
        Among("taldia", 12, 1, 0),
        Among("karia", -1, 1, 0),
        Among("garria", -1, 2, 0),
        Among("karria", -1, 1, 0),
        Among("ka", -1, 1, 0),
        Among("tzaka", 17, 1, 0),
        Among("la", -1, 1, 0),
        Among("mena", -1, 1, 0),
        Among("pena", -1, 1, 0),
        Among("kina", -1, 1, 0),
        Among("ezina", -1, 1, 0),
        Among("tezina", 23, 1, 0),
        Among("kuna", -1, 1, 0),
        Among("tuna", -1, 1, 0),
        Among("kizuna", -1, 1, 0),
        Among("era", -1, 1, 0),
        Among("bera", 28, 1, 0),
        Among("arabera", 29, -1, 0),
        Among("kera", 28, 1, 0),
        Among("pera", 28, 1, 0),
        Among("orra", -1, 1, 0),
        Among("korra", 33, 1, 0),
        Among("dura", -1, 1, 0),
        Among("gura", -1, 1, 0),
        Among("kura", -1, 1, 0),
        Among("tura", -1, 1, 0),
        Among("eta", -1, 1, 0),
        Among("keta", 39, 1, 0),
        Among("gailua", -1, 1, 0),
        Among("eza", -1, 1, 0),
        Among("erreza", 42, 1, 0),
        Among("tza", -1, 2, 0),
        Among("gaitza", 44, 1, 0),
        Among("kaitza", 44, 1, 0),
        Among("kuntza", 44, 1, 0),
        Among("ide", -1, 1, 0),
        Among("bide", 48, 1, 0),
        Among("kide", 48, 1, 0),
        Among("pide", 48, 1, 0),
        Among("kunde", -1, 1, 0),
        Among("tzake", -1, 1, 0),
        Among("tzeke", -1, 1, 0),
        Among("le", -1, 1, 0),
        Among("gale", 55, 1, 0),
        Among("taile", 55, 1, 0),
        Among("tzaile", 55, 1, 0),
        Among("gune", -1, 1, 0),
        Among("kune", -1, 1, 0),
        Among("tze", -1, 1, 0),
        Among("atze", 61, 1, 0),
        Among("gai", -1, 1, 0),
        Among("aldi", -1, 1, 0),
        Among("taldi", 64, 1, 0),
        Among("ki", -1, 1, 0),
        Among("ari", -1, 1, 0),
        Among("kari", 67, 1, 0),
        Among("lari", 67, 1, 0),
        Among("tari", 67, 1, 0),
        Among("etari", 70, 1, 0),
        Among("garri", -1, 2, 0),
        Among("karri", -1, 1, 0),
        Among("arazi", -1, 1, 0),
        Among("tarazi", 74, 1, 0),
        Among("an", -1, 1, 0),
        Among("ean", 76, 1, 0),
        Among("rean", 77, 1, 0),
        Among("kan", 76, 1, 0),
        Among("etan", 76, 1, 0),
        Among("atseden", -1, -1, 0),
        Among("men", -1, 1, 0),
        Among("pen", -1, 1, 0),
        Among("kin", -1, 1, 0),
        Among("rekin", 84, 1, 0),
        Among("ezin", -1, 1, 0),
        Among("tezin", 86, 1, 0),
        Among("tun", -1, 1, 0),
        Among("kizun", -1, 1, 0),
        Among("go", -1, 1, 0),
        Among("ago", 90, 1, 0),
        Among("tio", -1, 1, 0),
        Among("dako", -1, 1, 0),
        Among("or", -1, 1, 0),
        Among("kor", 94, 1, 0),
        Among("tzat", -1, 1, 0),
        Among("du", -1, 1, 0),
        Among("gailu", -1, 1, 0),
        Among("tu", -1, 1, 0),
        Among("atu", 99, 1, 0),
        Among("aldatu", 100, 1, 0),
        Among("tatu", 100, 1, 0),
        Among("baditu", 99, -1, 0),
        Among("ez", -1, 1, 0),
        Among("errez", 104, 1, 0),
        Among("tzez", 104, 1, 0),
        Among("gaitz", -1, 1, 0),
        Among("kaitz", -1, 1, 0)
    ];

    static final a_1 = [
        Among("ada", -1, 1, 0),
        Among("kada", 0, 1, 0),
        Among("anda", -1, 1, 0),
        Among("denda", -1, 1, 0),
        Among("gabea", -1, 1, 0),
        Among("kabea", -1, 1, 0),
        Among("aldea", -1, 1, 0),
        Among("kaldea", 6, 1, 0),
        Among("taldea", 6, 1, 0),
        Among("ordea", -1, 1, 0),
        Among("zalea", -1, 1, 0),
        Among("tzalea", 10, 1, 0),
        Among("gilea", -1, 1, 0),
        Among("emea", -1, 1, 0),
        Among("kumea", -1, 1, 0),
        Among("nea", -1, 1, 0),
        Among("enea", 15, 1, 0),
        Among("zionea", 15, 1, 0),
        Among("unea", 15, 1, 0),
        Among("gunea", 18, 1, 0),
        Among("pea", -1, 1, 0),
        Among("aurrea", -1, 1, 0),
        Among("tea", -1, 1, 0),
        Among("kotea", 22, 1, 0),
        Among("artea", 22, 1, 0),
        Among("ostea", 22, 1, 0),
        Among("etxea", -1, 1, 0),
        Among("ga", -1, 1, 0),
        Among("anga", 27, 1, 0),
        Among("gaia", -1, 1, 0),
        Among("aldia", -1, 1, 0),
        Among("taldia", 30, 1, 0),
        Among("handia", -1, 1, 0),
        Among("mendia", -1, 1, 0),
        Among("geia", -1, 1, 0),
        Among("egia", -1, 1, 0),
        Among("degia", 35, 1, 0),
        Among("tegia", 35, 1, 0),
        Among("nahia", -1, 1, 0),
        Among("ohia", -1, 1, 0),
        Among("kia", -1, 1, 0),
        Among("tokia", 40, 1, 0),
        Among("oia", -1, 1, 0),
        Among("koia", 42, 1, 0),
        Among("aria", -1, 1, 0),
        Among("karia", 44, 1, 0),
        Among("laria", 44, 1, 0),
        Among("taria", 44, 1, 0),
        Among("eria", -1, 1, 0),
        Among("keria", 48, 1, 0),
        Among("teria", 48, 1, 0),
        Among("garria", -1, 2, 0),
        Among("larria", -1, 1, 0),
        Among("kirria", -1, 1, 0),
        Among("duria", -1, 1, 0),
        Among("asia", -1, 1, 0),
        Among("tia", -1, 1, 0),
        Among("ezia", -1, 1, 0),
        Among("bizia", -1, 1, 0),
        Among("ontzia", -1, 1, 0),
        Among("ka", -1, 1, 0),
        Among("joka", 60, 3, 0),
        Among("aurka", 60, -1, 0),
        Among("ska", 60, 1, 0),
        Among("xka", 60, 1, 0),
        Among("zka", 60, 1, 0),
        Among("gibela", -1, 1, 0),
        Among("gela", -1, 1, 0),
        Among("kaila", -1, 1, 0),
        Among("skila", -1, 1, 0),
        Among("tila", -1, 1, 0),
        Among("ola", -1, 1, 0),
        Among("na", -1, 1, 0),
        Among("kana", 72, 1, 0),
        Among("ena", 72, 1, 0),
        Among("garrena", 74, 1, 0),
        Among("gerrena", 74, 1, 0),
        Among("urrena", 74, 1, 0),
        Among("zaina", 72, 1, 0),
        Among("tzaina", 78, 1, 0),
        Among("kina", 72, 1, 0),
        Among("mina", 72, 1, 0),
        Among("garna", 72, 1, 0),
        Among("una", 72, 1, 0),
        Among("duna", 83, 1, 0),
        Among("asuna", 83, 1, 0),
        Among("tasuna", 85, 1, 0),
        Among("ondoa", -1, 1, 0),
        Among("kondoa", 87, 1, 0),
        Among("ngoa", -1, 1, 0),
        Among("zioa", -1, 1, 0),
        Among("koa", -1, 1, 0),
        Among("takoa", 91, 1, 0),
        Among("zkoa", 91, 1, 0),
        Among("noa", -1, 1, 0),
        Among("zinoa", 94, 1, 0),
        Among("aroa", -1, 1, 0),
        Among("taroa", 96, 1, 0),
        Among("zaroa", 96, 1, 0),
        Among("eroa", -1, 1, 0),
        Among("oroa", -1, 1, 0),
        Among("osoa", -1, 1, 0),
        Among("toa", -1, 1, 0),
        Among("ttoa", 102, 1, 0),
        Among("ztoa", 102, 1, 0),
        Among("txoa", -1, 1, 0),
        Among("tzoa", -1, 1, 0),
        Among("\u00F1oa", -1, 1, 0),
        Among("ra", -1, 1, 0),
        Among("ara", 108, 1, 0),
        Among("dara", 109, 1, 0),
        Among("liara", 109, 1, 0),
        Among("tiara", 109, 1, 0),
        Among("tara", 109, 1, 0),
        Among("etara", 113, 1, 0),
        Among("tzara", 109, 1, 0),
        Among("bera", 108, 1, 0),
        Among("kera", 108, 1, 0),
        Among("pera", 108, 1, 0),
        Among("ora", 108, 2, 0),
        Among("tzarra", 108, 1, 0),
        Among("korra", 108, 1, 0),
        Among("tra", 108, 1, 0),
        Among("sa", -1, 1, 0),
        Among("osa", 123, 1, 0),
        Among("ta", -1, 1, 0),
        Among("eta", 125, 1, 0),
        Among("keta", 126, 1, 0),
        Among("sta", 125, 1, 0),
        Among("dua", -1, 1, 0),
        Among("mendua", 129, 1, 0),
        Among("ordua", 129, 1, 0),
        Among("lekua", -1, 1, 0),
        Among("burua", -1, 1, 0),
        Among("durua", -1, 1, 0),
        Among("tsua", -1, 1, 0),
        Among("tua", -1, 1, 0),
        Among("mentua", 136, 1, 0),
        Among("estua", 136, 1, 0),
        Among("txua", -1, 1, 0),
        Among("zua", -1, 1, 0),
        Among("tzua", 140, 1, 0),
        Among("za", -1, 1, 0),
        Among("eza", 142, 1, 0),
        Among("eroza", 142, 1, 0),
        Among("tza", 142, 2, 0),
        Among("koitza", 145, 1, 0),
        Among("antza", 145, 1, 0),
        Among("gintza", 145, 1, 0),
        Among("kintza", 145, 1, 0),
        Among("kuntza", 145, 1, 0),
        Among("gabe", -1, 1, 0),
        Among("kabe", -1, 1, 0),
        Among("kide", -1, 1, 0),
        Among("alde", -1, 1, 0),
        Among("kalde", 154, 1, 0),
        Among("talde", 154, 1, 0),
        Among("orde", -1, 1, 0),
        Among("ge", -1, 1, 0),
        Among("zale", -1, 1, 0),
        Among("tzale", 159, 1, 0),
        Among("gile", -1, 1, 0),
        Among("eme", -1, 1, 0),
        Among("kume", -1, 1, 0),
        Among("ne", -1, 1, 0),
        Among("zione", 164, 1, 0),
        Among("une", 164, 1, 0),
        Among("gune", 166, 1, 0),
        Among("pe", -1, 1, 0),
        Among("aurre", -1, 1, 0),
        Among("te", -1, 1, 0),
        Among("kote", 170, 1, 0),
        Among("arte", 170, 1, 0),
        Among("oste", 170, 1, 0),
        Among("etxe", -1, 1, 0),
        Among("gai", -1, 1, 0),
        Among("di", -1, 1, 0),
        Among("aldi", 176, 1, 0),
        Among("taldi", 177, 1, 0),
        Among("geldi", 176, -1, 0),
        Among("handi", 176, 1, 0),
        Among("mendi", 176, 1, 0),
        Among("gei", -1, 1, 0),
        Among("egi", -1, 1, 0),
        Among("degi", 183, 1, 0),
        Among("tegi", 183, 1, 0),
        Among("nahi", -1, 1, 0),
        Among("ohi", -1, 1, 0),
        Among("ki", -1, 1, 0),
        Among("toki", 188, 1, 0),
        Among("oi", -1, 1, 0),
        Among("goi", 190, 1, 0),
        Among("koi", 190, 1, 0),
        Among("ari", -1, 1, 0),
        Among("kari", 193, 1, 0),
        Among("lari", 193, 1, 0),
        Among("tari", 193, 1, 0),
        Among("garri", -1, 2, 0),
        Among("larri", -1, 1, 0),
        Among("kirri", -1, 1, 0),
        Among("duri", -1, 1, 0),
        Among("asi", -1, 1, 0),
        Among("ti", -1, 1, 0),
        Among("ontzi", -1, 1, 0),
        Among("\u00F1i", -1, 1, 0),
        Among("ak", -1, 1, 0),
        Among("ek", -1, 1, 0),
        Among("tarik", -1, 1, 0),
        Among("gibel", -1, 1, 0),
        Among("ail", -1, 1, 0),
        Among("kail", 209, 1, 0),
        Among("kan", -1, 1, 0),
        Among("tan", -1, 1, 0),
        Among("etan", 212, 1, 0),
        Among("en", -1, 4, 0),
        Among("ren", 214, 2, 0),
        Among("garren", 215, 1, 0),
        Among("gerren", 215, 1, 0),
        Among("urren", 215, 1, 0),
        Among("ten", 214, 4, 0),
        Among("tzen", 214, 4, 0),
        Among("zain", -1, 1, 0),
        Among("tzain", 221, 1, 0),
        Among("kin", -1, 1, 0),
        Among("min", -1, 1, 0),
        Among("dun", -1, 1, 0),
        Among("asun", -1, 1, 0),
        Among("tasun", 226, 1, 0),
        Among("aizun", -1, 1, 0),
        Among("ondo", -1, 1, 0),
        Among("kondo", 229, 1, 0),
        Among("go", -1, 1, 0),
        Among("ngo", 231, 1, 0),
        Among("zio", -1, 1, 0),
        Among("ko", -1, 1, 0),
        Among("trako", 234, 5, 0),
        Among("tako", 234, 1, 0),
        Among("etako", 236, 1, 0),
        Among("eko", 234, 1, 0),
        Among("tariko", 234, 1, 0),
        Among("sko", 234, 1, 0),
        Among("tuko", 234, 1, 0),
        Among("minutuko", 241, 6, 0),
        Among("zko", 234, 1, 0),
        Among("no", -1, 1, 0),
        Among("zino", 244, 1, 0),
        Among("ro", -1, 1, 0),
        Among("aro", 246, 1, 0),
        Among("igaro", 247, -1, 0),
        Among("taro", 247, 1, 0),
        Among("zaro", 247, 1, 0),
        Among("ero", 246, 1, 0),
        Among("giro", 246, 1, 0),
        Among("oro", 246, 1, 0),
        Among("oso", -1, 1, 0),
        Among("to", -1, 1, 0),
        Among("tto", 255, 1, 0),
        Among("zto", 255, 1, 0),
        Among("txo", -1, 1, 0),
        Among("tzo", -1, 1, 0),
        Among("gintzo", 259, 1, 0),
        Among("\u00F1o", -1, 1, 0),
        Among("zp", -1, 1, 0),
        Among("ar", -1, 1, 0),
        Among("dar", 263, 1, 0),
        Among("behar", 263, 1, 0),
        Among("zehar", 263, -1, 0),
        Among("liar", 263, 1, 0),
        Among("tiar", 263, 1, 0),
        Among("tar", 263, 1, 0),
        Among("tzar", 263, 1, 0),
        Among("or", -1, 2, 0),
        Among("kor", 271, 1, 0),
        Among("os", -1, 1, 0),
        Among("ket", -1, 1, 0),
        Among("du", -1, 1, 0),
        Among("mendu", 275, 1, 0),
        Among("ordu", 275, 1, 0),
        Among("leku", -1, 1, 0),
        Among("buru", -1, 2, 0),
        Among("duru", -1, 1, 0),
        Among("tsu", -1, 1, 0),
        Among("tu", -1, 1, 0),
        Among("tatu", 282, 4, 0),
        Among("mentu", 282, 1, 0),
        Among("estu", 282, 1, 0),
        Among("txu", -1, 1, 0),
        Among("zu", -1, 1, 0),
        Among("tzu", 287, 1, 0),
        Among("gintzu", 288, 1, 0),
        Among("z", -1, 1, 0),
        Among("ez", 290, 1, 0),
        Among("eroz", 290, 1, 0),
        Among("tz", 290, 1, 0),
        Among("koitz", 293, 1, 0)
    ];

    static final a_2 = [
        Among("zlea", -1, 2, 0),
        Among("keria", -1, 1, 0),
        Among("la", -1, 1, 0),
        Among("era", -1, 1, 0),
        Among("dade", -1, 1, 0),
        Among("tade", -1, 1, 0),
        Among("date", -1, 1, 0),
        Among("tate", -1, 1, 0),
        Among("gi", -1, 1, 0),
        Among("ki", -1, 1, 0),
        Among("ik", -1, 1, 0),
        Among("lanik", 10, 1, 0),
        Among("rik", 10, 1, 0),
        Among("larik", 12, 1, 0),
        Among("ztik", 10, 1, 0),
        Among("go", -1, 1, 0),
        Among("ro", -1, 1, 0),
        Among("ero", 16, 1, 0),
        Among("to", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16]);

    int I_p2 = 0;
    int I_p1 = 0;
    int I_pV = 0;


    bool r_mark_regions() {
        I_pV = limit;
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_2 = cursor;
                lab2: while (true) {
                    if (!(in_grouping(g_v, 97, 117)))
                    {
                        break lab2;
                    }
                    lab3: while (true) {
                        int v_3 = cursor;
                        lab4: while (true) {
                            if (!(out_grouping(g_v, 97, 117)))
                            {
                                break lab4;
                            }
                            if (!go_out_grouping(g_v, 97, 117))
                            {
                                break lab4;
                            }
                            cursor++;
                            break lab3;
                        }
                        cursor = v_3;
                        if (!(in_grouping(g_v, 97, 117)))
                        {
                            break lab2;
                        }
                        if (!go_in_grouping(g_v, 97, 117))
                        {
                            break lab2;
                        }
                        cursor++;
                        break lab3;
                    }
                    break lab1;
                }
                cursor = v_2;
                if (!(out_grouping(g_v, 97, 117)))
                {
                    break lab0;
                }
                lab5: while (true) {
                    int v_4 = cursor;
                    lab6: while (true) {
                        if (!(out_grouping(g_v, 97, 117)))
                        {
                            break lab6;
                        }
                        if (!go_out_grouping(g_v, 97, 117))
                        {
                            break lab6;
                        }
                        cursor++;
                        break lab5;
                    }
                    cursor = v_4;
                    if (!(in_grouping(g_v, 97, 117)))
                    {
                        break lab0;
                    }
                    if (cursor >= limit)
                    {
                        break lab0;
                    }
                    cursor++;
                    break lab5;
                }
                break lab1;
            }
            I_pV = cursor;
            break lab0;
        }
        cursor = v_1;
        int v_5 = cursor;
        lab7: while (true) {
            if (!go_out_grouping(g_v, 97, 117))
            {
                break lab7;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 117))
            {
                break lab7;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 117))
            {
                break lab7;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 117))
            {
                break lab7;
            }
            cursor++;
            I_p2 = cursor;
            break lab7;
        }
        cursor = v_5;
        return true;
    }

    bool r_RV() {
        return I_pV <= cursor;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_aditzak() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_0, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_RV())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_izenak() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_1, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_RV())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                break;
            case 3:
                slice_from("jok");
                break;
            case 4:
                if (!r_R1())
                {
                    return false;
                }
                slice_del();
                break;
            case 5:
                slice_from("tra");
                break;
            case 6:
                slice_from("minutu");
                break;
        }
        return true;
    }

    bool r_adjetiboak() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_RV())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                slice_from("z");
                break;
        }
        return true;
    }

    @override
    bool stem() {
        r_mark_regions();
        limit_backward = cursor;
        cursor = limit;
        replab0: while(true)
        {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (!r_aditzak())
                {
                    break lab1;
                }
                continue replab0;
            }
            cursor = limit - v_1;
            break replab0;
        }
        replab2: while(true)
        {
            int v_2 = limit - cursor;
            lab3: while (true) {
                if (!r_izenak())
                {
                    break lab3;
                }
                continue replab2;
            }
            cursor = limit - v_2;
            break replab2;
        }
        int v_3 = limit - cursor;
        r_adjetiboak();
        cursor = limit - v_3;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is basque_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
