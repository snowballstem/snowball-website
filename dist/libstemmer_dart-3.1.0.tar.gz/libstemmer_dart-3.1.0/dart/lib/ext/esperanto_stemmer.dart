// Generated from esperanto.sbl by Snowball 3.1.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from esperanto.sbl by Snowball 3.1.0 - https://snowballstem.org/
 */
class esperanto_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 14, 0),
        Among("-", 0, 13, 0),
        Among("cx", 0, 1, 0),
        Among("gx", 0, 2, 0),
        Among("hx", 0, 3, 0),
        Among("jx", 0, 4, 0),
        Among("q", 0, 12, 0),
        Among("sx", 0, 5, 0),
        Among("ux", 0, 6, 0),
        Among("w", 0, 12, 0),
        Among("x", 0, 12, 0),
        Among("y", 0, 12, 0),
        Among("\u00E1", 0, 7, 0),
        Among("\u00E9", 0, 8, 0),
        Among("\u00ED", 0, 9, 0),
        Among("\u00F3", 0, 10, 0),
        Among("\u00FA", 0, 11, 0)
    ];

    static final a_1 = [
        Among("as", -1, -1, 0),
        Among("i", -1, -1, 0),
        Among("is", 1, -1, 0),
        Among("os", -1, -1, 0),
        Among("u", -1, -1, 0),
        Among("us", 4, -1, 0)
    ];

    static final a_2 = [
        Among("ci", -1, -1, 0),
        Among("gi", -1, -1, 0),
        Among("hi", -1, -1, 0),
        Among("li", -1, -1, 0),
        Among("ili", 3, -1, 0),
        Among("\u015Dli", 3, -1, 0),
        Among("mi", -1, -1, 0),
        Among("ni", -1, -1, 0),
        Among("oni", 7, -1, 0),
        Among("ri", -1, -1, 0),
        Among("si", -1, -1, 0),
        Among("vi", -1, -1, 0),
        Among("ivi", 11, -1, 0),
        Among("\u011Di", -1, -1, 0),
        Among("\u015Di", -1, -1, 0),
        Among("i\u015Di", 14, -1, 0),
        Among("mal\u015Di", 14, -1, 0)
    ];

    static final a_3 = [
        Among("amb", -1, -1, 0),
        Among("bald", -1, -1, 0),
        Among("malbald", 1, -1, 0),
        Among("morg", -1, -1, 0),
        Among("postmorg", 3, -1, 0),
        Among("adi", -1, -1, 0),
        Among("hodi", -1, -1, 0),
        Among("ank", -1, -1, 0),
        Among("\u0109irk", -1, -1, 0),
        Among("tut\u0109irk", 8, -1, 0),
        Among("presk", -1, -1, 0),
        Among("almen", -1, -1, 0),
        Among("apen", -1, -1, 0),
        Among("hier", -1, -1, 0),
        Among("anta\u016Dhier", 13, -1, 0),
        Among("malgr", -1, -1, 0),
        Among("ankor", -1, -1, 0),
        Among("kontr", -1, -1, 0),
        Among("anstat", -1, -1, 0),
        Among("kvaz", -1, -1, 0)
    ];

    static final a_4 = [
        Among("aliu", -1, -1, 0),
        Among("unu", -1, -1, 0)
    ];

    static final a_5 = [
        Among("aha", -1, -1, 0),
        Among("haha", 0, -1, 0),
        Among("haleluja", -1, -1, 0),
        Among("hola", -1, -1, 0),
        Among("hosana", -1, -1, 0),
        Among("maltra", -1, -1, 0),
        Among("hura", -1, -1, 0),
        Among("\u0125a\u0125a", -1, -1, 0),
        Among("ekde", -1, -1, 0),
        Among("elde", -1, -1, 0),
        Among("disde", -1, -1, 0),
        Among("ehe", -1, -1, 0),
        Among("maltre", -1, -1, 0),
        Among("dirlididi", -1, -1, 0),
        Among("malpli", -1, -1, 0),
        Among("mal\u0109i", -1, -1, 0),
        Among("malkaj", -1, -1, 0),
        Among("amen", -1, -1, 0),
        Among("tamen", 17, -1, 0),
        Among("oho", -1, -1, 0),
        Among("maltro", -1, -1, 0),
        Among("minus", -1, -1, 0),
        Among("uhu", -1, -1, 0),
        Among("muu", -1, -1, 0)
    ];

    static final a_6 = [
        Among("tri", -1, -1, 0),
        Among("du", -1, -1, 0),
        Among("unu", -1, -1, 0)
    ];

    static final a_7 = [
        Among("dek", -1, -1, 0),
        Among("cent", -1, -1, 0)
    ];

    static final a_8 = [
        Among("k", -1, -1, 0),
        Among("kelk", 0, -1, 0),
        Among("nen", -1, -1, 0),
        Among("t", -1, -1, 0),
        Among("mult", 3, -1, 0),
        Among("samt", 3, -1, 0),
        Among("\u0109", -1, -1, 0)
    ];

    static final a_9 = [
        Among("a", -1, -1, 0),
        Among("e", -1, -1, 0),
        Among("i", -1, -1, 0),
        Among("j", -1, 1, 0),
        Among("aj", 3, -1, 0),
        Among("oj", 3, -1, 0),
        Among("n", -1, 1, 0),
        Among("an", 6, -1, 0),
        Among("en", 6, -1, 0),
        Among("jn", 6, 1, 0),
        Among("ajn", 9, -1, 0),
        Among("ojn", 9, -1, 0),
        Among("on", 6, -1, 0),
        Among("o", -1, -1, 0),
        Among("as", -1, -1, 0),
        Among("is", -1, -1, 0),
        Among("os", -1, -1, 0),
        Among("us", -1, -1, 0),
        Among("u", -1, -1, 0)
    ];

    static final g_vowel = String.fromCharCodes([17, 65, 16]);

    static final g_aou = String.fromCharCodes([1, 64, 16]);

    static final g_digit = String.fromCharCodes([255, 3]);


    bool r_canonical_form() {
        int among_var;
        bool B_foreign;
        B_foreign = false;
        replab0: while(true)
        {
            int v_1 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_0, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("\u0109");
                        break;
                    case 2:
                        slice_from("\u011D");
                        break;
                    case 3:
                        slice_from("\u0125");
                        break;
                    case 4:
                        slice_from("\u0135");
                        break;
                    case 5:
                        slice_from("\u015D");
                        break;
                    case 6:
                        slice_from("\u016D");
                        break;
                    case 7:
                        slice_from("a");
                        B_foreign = true;
                        break;
                    case 8:
                        slice_from("e");
                        B_foreign = true;
                        break;
                    case 9:
                        slice_from("i");
                        B_foreign = true;
                        break;
                    case 10:
                        slice_from("o");
                        B_foreign = true;
                        break;
                    case 11:
                        slice_from("u");
                        B_foreign = true;
                        break;
                    case 12:
                        B_foreign = true;
                        break;
                    case 13:
                        B_foreign = false;
                        break;
                    case 14:
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break;
                }
                continue replab0;
            }
            cursor = v_1;
            break replab0;
        }
        return !B_foreign;
    }

    bool r_initial_apostrophe() {
        bra = cursor;
        if (!(eq_s("'")))
        {
            return false;
        }
        ket = cursor;
        if (!(eq_s("st")))
        {
            return false;
        }
        if (find_among(a_1, null) == 0)
        {
            return false;
        }
        if (cursor < limit)
        {
            return false;
        }
        slice_from("e");
        return true;
    }

    bool r_pronoun() {
        ket = cursor;
        int v_1 = limit - cursor;
        lab0: while (true) {
            if (!(eq_s_b("n")))
            {
                cursor = limit - v_1;
                break lab0;
            }
            break lab0;
        }
        bra = cursor;
        if (find_among_b(a_2, null) == 0)
        {
            return false;
        }
        lab1: while (true) {
            lab2: while (true) {
                if (cursor > limit_backward)
                {
                    break lab2;
                }
                break lab1;
            }
            if (!(eq_s_b("-")))
            {
                return false;
            }
            break lab1;
        }
        slice_del();
        return true;
    }

    bool r_final_apostrophe() {
        ket = cursor;
        if (!(eq_s_b("'")))
        {
            return false;
        }
        bra = cursor;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (!(eq_s_b("l")))
                {
                    break lab1;
                }
                if (cursor > limit_backward)
                {
                    break lab1;
                }
                slice_from("a");
                break lab0;
            }
            cursor = limit - v_1;
            lab2: while (true) {
                if (!(eq_s_b("un")))
                {
                    break lab2;
                }
                if (cursor > limit_backward)
                {
                    break lab2;
                }
                slice_from("u");
                break lab0;
            }
            cursor = limit - v_1;
            lab3: while (true) {
                if (find_among_b(a_3, null) == 0)
                {
                    break lab3;
                }
                lab4: while (true) {
                    lab5: while (true) {
                        if (cursor > limit_backward)
                        {
                            break lab5;
                        }
                        break lab4;
                    }
                    if (!(eq_s_b("-")))
                    {
                        break lab3;
                    }
                    break lab4;
                }
                slice_from("a\u016D");
                break lab0;
            }
            cursor = limit - v_1;
            slice_from("o");
            break lab0;
        }
        return true;
    }

    bool r_ujn_suffix() {
        ket = cursor;
        int v_1 = limit - cursor;
        lab0: while (true) {
            if (!(eq_s_b("n")))
            {
                cursor = limit - v_1;
                break lab0;
            }
            break lab0;
        }
        int v_2 = limit - cursor;
        lab1: while (true) {
            if (!(eq_s_b("j")))
            {
                cursor = limit - v_2;
                break lab1;
            }
            break lab1;
        }
        bra = cursor;
        if (find_among_b(a_4, null) == 0)
        {
            return false;
        }
        lab2: while (true) {
            lab3: while (true) {
                if (cursor > limit_backward)
                {
                    break lab3;
                }
                break lab2;
            }
            if (!(eq_s_b("-")))
            {
                return false;
            }
            break lab2;
        }
        slice_del();
        return true;
    }

    bool r_uninflected() {
        if (find_among_b(a_5, null) == 0)
        {
            return false;
        }
        lab0: while (true) {
            lab1: while (true) {
                if (cursor > limit_backward)
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("-")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_merged_numeral() {
        if (find_among_b(a_6, null) == 0)
        {
            return false;
        }
        return find_among_b(a_7, null) != 0;
    }

    bool r_correlative() {
        ket = cursor;
        bra = cursor;
        int v_1 = limit - cursor;
        lab0: while (true) {
            int v_2 = limit - cursor;
            lab1: while (true) {
                int v_3 = limit - cursor;
                lab2: while (true) {
                    if (!(eq_s_b("n")))
                    {
                        cursor = limit - v_3;
                        break lab2;
                    }
                    break lab2;
                }
                bra = cursor;
                if (!(eq_s_b("e")))
                {
                    break lab1;
                }
                break lab0;
            }
            cursor = limit - v_2;
            int v_4 = limit - cursor;
            lab3: while (true) {
                if (!(eq_s_b("n")))
                {
                    cursor = limit - v_4;
                    break lab3;
                }
                break lab3;
            }
            int v_5 = limit - cursor;
            lab4: while (true) {
                if (!(eq_s_b("j")))
                {
                    cursor = limit - v_5;
                    break lab4;
                }
                break lab4;
            }
            bra = cursor;
            if (!(in_grouping_b(g_aou, 97, 117)))
            {
                return false;
            }
            break lab0;
        }
        if (!(eq_s_b("i")))
        {
            return false;
        }
        int v_6 = limit - cursor;
        lab5: while (true) {
            if (find_among_b(a_8, null) == 0)
            {
                cursor = limit - v_6;
                break lab5;
            }
            break lab5;
        }
        lab6: while (true) {
            lab7: while (true) {
                if (cursor > limit_backward)
                {
                    break lab7;
                }
                break lab6;
            }
            if (!(eq_s_b("-")))
            {
                return false;
            }
            break lab6;
        }
        cursor = limit - v_1;
        slice_del();
        return true;
    }

    bool r_long_word() {
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                for (int v_2 = 2; v_2 > 0; v_2--)
                {
                    if (!go_out_grouping_b(g_vowel, 97, 117))
                    {
                        break lab1;
                    }
                    cursor--;
                }
                break lab0;
            }
            cursor = limit - v_1;
            lab2: while (true) {
                golab3: while(true)
                {
                    lab4: while (true) {
                        if (!(eq_s_b("-")))
                        {
                            break lab4;
                        }
                        break golab3;
                    }
                    if (cursor <= limit_backward)
                    {
                        break lab2;
                    }
                    cursor--;
                }
                if (cursor <= limit_backward)
                {
                    break lab2;
                }
                cursor--;
                break lab0;
            }
            cursor = limit - v_1;
            if (!go_out_grouping_b(g_digit, 48, 57))
            {
                return false;
            }
            cursor--;
            break lab0;
        }
        return true;
    }

    bool r_standard_suffix() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_9, null);
        if (among_var == 0)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                int v_1 = limit - cursor;
                lab0: while (true) {
                    lab1: while (true) {
                        if (!(eq_s_b("-")))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    if (!(in_grouping_b(g_digit, 48, 57)))
                    {
                        return false;
                    }
                    break lab0;
                }
                cursor = limit - v_1;
                break;
        }
        int v_2 = limit - cursor;
        lab2: while (true) {
            if (!(eq_s_b("-")))
            {
                cursor = limit - v_2;
                break lab2;
            }
            break lab2;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        if (!r_canonical_form())
        {
            return false;
        }
        cursor = v_1;
        int v_2 = cursor;
        r_initial_apostrophe();
        cursor = v_2;
        limit_backward = cursor;
        cursor = limit;
        {
            int v_3 = limit - cursor;
            lab0: while (true) {
                if (!r_pronoun())
                {
                    break lab0;
                }
                return false;
            }
            cursor = limit - v_3;
        }
        int v_4 = limit - cursor;
        r_final_apostrophe();
        cursor = limit - v_4;
        {
            int v_5 = limit - cursor;
            lab1: while (true) {
                if (!r_correlative())
                {
                    break lab1;
                }
                return false;
            }
            cursor = limit - v_5;
        }
        {
            int v_6 = limit - cursor;
            lab2: while (true) {
                if (!r_uninflected())
                {
                    break lab2;
                }
                return false;
            }
            cursor = limit - v_6;
        }
        {
            int v_7 = limit - cursor;
            lab3: while (true) {
                if (!r_merged_numeral())
                {
                    break lab3;
                }
                return false;
            }
            cursor = limit - v_7;
        }
        {
            int v_8 = limit - cursor;
            lab4: while (true) {
                if (!r_ujn_suffix())
                {
                    break lab4;
                }
                return false;
            }
            cursor = limit - v_8;
        }
        int v_9 = limit - cursor;
        if (!r_long_word())
        {
            return false;
        }
        cursor = limit - v_9;
        if (!r_standard_suffix())
        {
            return false;
        }
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is esperanto_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
