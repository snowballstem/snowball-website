// Generated from dutch_porter.sbl by Snowball 3.1.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from dutch_porter.sbl by Snowball 3.1.0 - https://snowballstem.org/
 */
class dutch_porter_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 6, 0),
        Among("\u00E1", 0, 1, 0),
        Among("\u00E4", 0, 1, 0),
        Among("\u00E9", 0, 2, 0),
        Among("\u00EB", 0, 2, 0),
        Among("\u00ED", 0, 3, 0),
        Among("\u00EF", 0, 3, 0),
        Among("\u00F3", 0, 4, 0),
        Among("\u00F6", 0, 4, 0),
        Among("\u00FA", 0, 5, 0),
        Among("\u00FC", 0, 5, 0)
    ];

    static final a_1 = [
        Among("", -1, 3, 0),
        Among("I", 0, 2, 0),
        Among("Y", 0, 1, 0)
    ];

    static final a_2 = [
        Among("dd", -1, -1, 0),
        Among("kk", -1, -1, 0),
        Among("tt", -1, -1, 0)
    ];

    static final a_3 = [
        Among("ene", -1, 2, 0),
        Among("se", -1, 3, 0),
        Among("en", -1, 2, 0),
        Among("heden", 2, 1, 0),
        Among("s", -1, 3, 0)
    ];

    static final a_4 = [
        Among("end", -1, 1, 0),
        Among("ig", -1, 2, 0),
        Among("ing", -1, 1, 0),
        Among("lijk", -1, 3, 0),
        Among("baar", -1, 4, 0),
        Among("bar", -1, 5, 0)
    ];

    static final a_5 = [
        Among("aa", -1, -1, 0),
        Among("ee", -1, -1, 0),
        Among("oo", -1, -1, 0),
        Among("uu", -1, -1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128]);

    static final g_v_I = String.fromCharCodes([1, 0, 0, 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128]);

    static final g_v_j = String.fromCharCodes([17, 67, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128]);

    int I_p2 = 0;
    int I_p1 = 0;
    bool B_e_found = false;


    bool r_prelude() {
        int among_var;
        int v_1 = cursor;
        replab0: while(true)
        {
            int v_2 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_0, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("a");
                        break;
                    case 2:
                        slice_from("e");
                        break;
                    case 3:
                        slice_from("i");
                        break;
                    case 4:
                        slice_from("o");
                        break;
                    case 5:
                        slice_from("u");
                        break;
                    case 6:
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break;
                }
                continue replab0;
            }
            cursor = v_2;
            break replab0;
        }
        cursor = v_1;
        int v_3 = cursor;
        lab2: while (true) {
            bra = cursor;
            if (!(eq_s("y")))
            {
                cursor = v_3;
                break lab2;
            }
            ket = cursor;
            slice_from("Y");
            break lab2;
        }
        replab3: while(true)
        {
            int v_4 = cursor;
            lab4: while (true) {
                if (!go_out_grouping(g_v, 97, 232))
                {
                    break lab4;
                }
                cursor++;
                int v_5 = cursor;
                lab5: while (true) {
                    bra = cursor;
                    lab6: while (true) {
                        int v_6 = cursor;
                        lab7: while (true) {
                            if (!(eq_s("i")))
                            {
                                break lab7;
                            }
                            ket = cursor;
                            int v_7 = cursor;
                            lab8: while (true) {
                                if (!(in_grouping(g_v, 97, 232)))
                                {
                                    break lab8;
                                }
                                slice_from("I");
                                break lab8;
                            }
                            cursor = v_7;
                            break lab6;
                        }
                        cursor = v_6;
                        if (!(eq_s("y")))
                        {
                            cursor = v_5;
                            break lab5;
                        }
                        ket = cursor;
                        slice_from("Y");
                        break lab6;
                    }
                    break lab5;
                }
                continue replab3;
            }
            cursor = v_4;
            break replab3;
        }
        return true;
    }

    bool r_mark_regions() {
        int I_x;
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        {
            int c = cursor + 3;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        I_x = cursor;
        cursor = v_1;
        if (!go_out_grouping(g_v, 97, 232))
        {
            return false;
        }
        cursor++;
        if (!go_in_grouping(g_v, 97, 232))
        {
            return false;
        }
        cursor++;
        I_p1 = cursor;
        lab0: while (true) {
            if (I_p1 >= I_x)
            {
                break lab0;
            }
            I_p1 = I_x;
            break lab0;
        }
        if (!go_out_grouping(g_v, 97, 232))
        {
            return false;
        }
        cursor++;
        if (!go_in_grouping(g_v, 97, 232))
        {
            return false;
        }
        cursor++;
        I_p2 = cursor;
        return true;
    }

    bool r_postlude() {
        int among_var;
        replab0: while(true)
        {
            int v_1 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_1, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("y");
                        break;
                    case 2:
                        slice_from("i");
                        break;
                    case 3:
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break;
                }
                continue replab0;
            }
            cursor = v_1;
            break replab0;
        }
        return true;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_undouble() {
        int v_1 = limit - cursor;
        if (find_among_b(a_2, null) == 0)
        {
            return false;
        }
        cursor = limit - v_1;
        ket = cursor;
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor--;
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_e_ending() {
        B_e_found = false;
        ket = cursor;
        if (!(eq_s_b("e")))
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        int v_1 = limit - cursor;
        if (!(out_grouping_b(g_v, 97, 232)))
        {
            return false;
        }
        cursor = limit - v_1;
        slice_del();
        B_e_found = true;
        return r_undouble();
    }

    bool r_en_ending() {
        if (!r_R1())
        {
            return false;
        }
        int v_1 = limit - cursor;
        if (!(out_grouping_b(g_v, 97, 232)))
        {
            return false;
        }
        cursor = limit - v_1;
        lab0: while (true) {
            if (!(eq_s_b("gem")))
            {
                break lab0;
            }
            return false;
        }
        slice_del();
        return r_undouble();
    }

    bool r_standard_suffix() {
        int among_var;
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            among_var = find_among_b(a_3, null);
            if (among_var == 0)
            {
                break lab0;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    if (!r_R1())
                    {
                        break lab0;
                    }
                    slice_from("heid");
                    break;
                case 2:
                    if (!r_en_ending())
                    {
                        break lab0;
                    }
                    break;
                case 3:
                    if (!r_R1())
                    {
                        break lab0;
                    }
                    if (!(out_grouping_b(g_v_j, 97, 232)))
                    {
                        break lab0;
                    }
                    slice_del();
                    break;
            }
            break lab0;
        }
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        r_e_ending();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        lab1: while (true) {
            ket = cursor;
            if (!(eq_s_b("heid")))
            {
                break lab1;
            }
            bra = cursor;
            if (!r_R2())
            {
                break lab1;
            }
            lab2: while (true) {
                if (!(eq_s_b("c")))
                {
                    break lab2;
                }
                break lab1;
            }
            slice_del();
            ket = cursor;
            if (!(eq_s_b("en")))
            {
                break lab1;
            }
            bra = cursor;
            if (!r_en_ending())
            {
                break lab1;
            }
            break lab1;
        }
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        lab3: while (true) {
            ket = cursor;
            among_var = find_among_b(a_4, null);
            if (among_var == 0)
            {
                break lab3;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    if (!r_R2())
                    {
                        break lab3;
                    }
                    slice_del();
                    lab4: while (true) {
                        int v_5 = limit - cursor;
                        lab5: while (true) {
                            ket = cursor;
                            if (!(eq_s_b("ig")))
                            {
                                break lab5;
                            }
                            bra = cursor;
                            if (!r_R2())
                            {
                                break lab5;
                            }
                            lab6: while (true) {
                                if (!(eq_s_b("e")))
                                {
                                    break lab6;
                                }
                                break lab5;
                            }
                            slice_del();
                            break lab4;
                        }
                        cursor = limit - v_5;
                        if (!r_undouble())
                        {
                            break lab3;
                        }
                        break lab4;
                    }
                    break;
                case 2:
                    if (!r_R2())
                    {
                        break lab3;
                    }
                    lab7: while (true) {
                        if (!(eq_s_b("e")))
                        {
                            break lab7;
                        }
                        break lab3;
                    }
                    slice_del();
                    break;
                case 3:
                    if (!r_R2())
                    {
                        break lab3;
                    }
                    slice_del();
                    if (!r_e_ending())
                    {
                        break lab3;
                    }
                    break;
                case 4:
                    if (!r_R2())
                    {
                        break lab3;
                    }
                    slice_del();
                    break;
                case 5:
                    if (!r_R2())
                    {
                        break lab3;
                    }
                    if (!B_e_found)
                    {
                        break lab3;
                    }
                    slice_del();
                    break;
            }
            break lab3;
        }
        cursor = limit - v_4;
        int v_6 = limit - cursor;
        lab8: while (true) {
            if (!(out_grouping_b(g_v_I, 73, 232)))
            {
                break lab8;
            }
            int v_7 = limit - cursor;
            if (find_among_b(a_5, null) == 0)
            {
                break lab8;
            }
            if (!(out_grouping_b(g_v, 97, 232)))
            {
                break lab8;
            }
            cursor = limit - v_7;
            ket = cursor;
            if (cursor <= limit_backward)
            {
                break lab8;
            }
            cursor--;
            bra = cursor;
            slice_del();
            break lab8;
        }
        cursor = limit - v_6;
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        r_prelude();
        cursor = v_1;
        int v_2 = cursor;
        r_mark_regions();
        cursor = v_2;
        limit_backward = cursor;
        cursor = limit;
        r_standard_suffix();
        cursor = limit_backward;
        int v_3 = cursor;
        r_postlude();
        cursor = v_3;
        return true;
    }

    @override
    bool operator ==(Object other) => other is dutch_porter_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
