# snowball

This package provides stemmers generated from Snowball algorithms.

### What is Stemming?

Stemming maps different forms of the same word to a common "stem" - for
example, the English stemmer maps *connection*, *connections*, *connective*,
*connected*, and *connecting* to *connect*.  So a search for *connected*
would also find documents which only have the other forms.

This stem form is often a word itself, but this is not always the case as this
is not a requirement for text search systems, which are the intended field of
use.  We also aim to conflate words with the same meaning, rather than all
words with a common linguistic root (so *awe* and *awful* don't have the same
stem), and over-stemming is more problematic than under-stemming so we tend not
to stem in cases that are hard to resolve.  If you want to always reduce words
to a root form and/or get a root form which is itself a word then Snowball's
stemming algorithms likely aren't the right answer.

### How to use library

The stemming algorithms generally expect the input text to use composed accents
(Unicode NFC or NFKC) and to have been folded to lower case already.

The ``snowball`` package has two functions.

```dart
import 'package:snowball/snowball.dart';

final stemmer = SnowballStemmer(Algorithm.english);
print(stemmer.stem('walking'));
```

Generally you should create a stemmer object and reuse it rather than creating
a fresh object for each word stemmed (since there's some cost to creating and
destroying the object).
