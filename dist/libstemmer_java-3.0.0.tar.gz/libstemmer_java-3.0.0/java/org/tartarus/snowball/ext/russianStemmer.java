// Generated from russian.sbl by Snowball 3.0.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from russian.sbl by Snowball 3.0.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class russianStemmer extends org.tartarus.snowball.SnowballStemmer {

    private static final long serialVersionUID = 1L;

    private final static Among[] a_0 = {
        new Among("\u0432", -1, 1),
        new Among("\u0438\u0432", 0, 2),
        new Among("\u044B\u0432", 0, 2),
        new Among("\u0432\u0448\u0438", -1, 1),
        new Among("\u0438\u0432\u0448\u0438", 3, 2),
        new Among("\u044B\u0432\u0448\u0438", 3, 2),
        new Among("\u0432\u0448\u0438\u0441\u044C", -1, 1),
        new Among("\u0438\u0432\u0448\u0438\u0441\u044C", 6, 2),
        new Among("\u044B\u0432\u0448\u0438\u0441\u044C", 6, 2)
    };

    private final static Among[] a_1 = {
        new Among("\u0435\u0435", -1, 1),
        new Among("\u0438\u0435", -1, 1),
        new Among("\u043E\u0435", -1, 1),
        new Among("\u044B\u0435", -1, 1),
        new Among("\u0438\u043C\u0438", -1, 1),
        new Among("\u044B\u043C\u0438", -1, 1),
        new Among("\u0435\u0439", -1, 1),
        new Among("\u0438\u0439", -1, 1),
        new Among("\u043E\u0439", -1, 1),
        new Among("\u044B\u0439", -1, 1),
        new Among("\u0435\u043C", -1, 1),
        new Among("\u0438\u043C", -1, 1),
        new Among("\u043E\u043C", -1, 1),
        new Among("\u044B\u043C", -1, 1),
        new Among("\u0435\u0433\u043E", -1, 1),
        new Among("\u043E\u0433\u043E", -1, 1),
        new Among("\u0435\u043C\u0443", -1, 1),
        new Among("\u043E\u043C\u0443", -1, 1),
        new Among("\u0438\u0445", -1, 1),
        new Among("\u044B\u0445", -1, 1),
        new Among("\u0435\u044E", -1, 1),
        new Among("\u043E\u044E", -1, 1),
        new Among("\u0443\u044E", -1, 1),
        new Among("\u044E\u044E", -1, 1),
        new Among("\u0430\u044F", -1, 1),
        new Among("\u044F\u044F", -1, 1)
    };

    private final static Among[] a_2 = {
        new Among("\u0435\u043C", -1, 1),
        new Among("\u043D\u043D", -1, 1),
        new Among("\u0432\u0448", -1, 1),
        new Among("\u0438\u0432\u0448", 2, 2),
        new Among("\u044B\u0432\u0448", 2, 2),
        new Among("\u0449", -1, 1),
        new Among("\u044E\u0449", 5, 1),
        new Among("\u0443\u044E\u0449", 6, 2)
    };

    private final static Among[] a_3 = {
        new Among("\u0441\u044C", -1, 1),
        new Among("\u0441\u044F", -1, 1)
    };

    private final static Among[] a_4 = {
        new Among("\u043B\u0430", -1, 1),
        new Among("\u0438\u043B\u0430", 0, 2),
        new Among("\u044B\u043B\u0430", 0, 2),
        new Among("\u043D\u0430", -1, 1),
        new Among("\u0435\u043D\u0430", 3, 2),
        new Among("\u0435\u0442\u0435", -1, 1),
        new Among("\u0438\u0442\u0435", -1, 2),
        new Among("\u0439\u0442\u0435", -1, 1),
        new Among("\u0435\u0439\u0442\u0435", 7, 2),
        new Among("\u0443\u0439\u0442\u0435", 7, 2),
        new Among("\u043B\u0438", -1, 1),
        new Among("\u0438\u043B\u0438", 10, 2),
        new Among("\u044B\u043B\u0438", 10, 2),
        new Among("\u0439", -1, 1),
        new Among("\u0435\u0439", 13, 2),
        new Among("\u0443\u0439", 13, 2),
        new Among("\u043B", -1, 1),
        new Among("\u0438\u043B", 16, 2),
        new Among("\u044B\u043B", 16, 2),
        new Among("\u0435\u043C", -1, 1),
        new Among("\u0438\u043C", -1, 2),
        new Among("\u044B\u043C", -1, 2),
        new Among("\u043D", -1, 1),
        new Among("\u0435\u043D", 22, 2),
        new Among("\u043B\u043E", -1, 1),
        new Among("\u0438\u043B\u043E", 24, 2),
        new Among("\u044B\u043B\u043E", 24, 2),
        new Among("\u043D\u043E", -1, 1),
        new Among("\u0435\u043D\u043E", 27, 2),
        new Among("\u043D\u043D\u043E", 27, 1),
        new Among("\u0435\u0442", -1, 1),
        new Among("\u0443\u0435\u0442", 30, 2),
        new Among("\u0438\u0442", -1, 2),
        new Among("\u044B\u0442", -1, 2),
        new Among("\u044E\u0442", -1, 1),
        new Among("\u0443\u044E\u0442", 34, 2),
        new Among("\u044F\u0442", -1, 2),
        new Among("\u043D\u044B", -1, 1),
        new Among("\u0435\u043D\u044B", 37, 2),
        new Among("\u0442\u044C", -1, 1),
        new Among("\u0438\u0442\u044C", 39, 2),
        new Among("\u044B\u0442\u044C", 39, 2),
        new Among("\u0435\u0448\u044C", -1, 1),
        new Among("\u0438\u0448\u044C", -1, 2),
        new Among("\u044E", -1, 2),
        new Among("\u0443\u044E", 44, 2)
    };

    private final static Among[] a_5 = {
        new Among("\u0430", -1, 1),
        new Among("\u0435\u0432", -1, 1),
        new Among("\u043E\u0432", -1, 1),
        new Among("\u0435", -1, 1),
        new Among("\u0438\u0435", 3, 1),
        new Among("\u044C\u0435", 3, 1),
        new Among("\u0438", -1, 1),
        new Among("\u0435\u0438", 6, 1),
        new Among("\u0438\u0438", 6, 1),
        new Among("\u0430\u043C\u0438", 6, 1),
        new Among("\u044F\u043C\u0438", 6, 1),
        new Among("\u0438\u044F\u043C\u0438", 10, 1),
        new Among("\u0439", -1, 1),
        new Among("\u0435\u0439", 12, 1),
        new Among("\u0438\u0435\u0439", 13, 1),
        new Among("\u0438\u0439", 12, 1),
        new Among("\u043E\u0439", 12, 1),
        new Among("\u0430\u043C", -1, 1),
        new Among("\u0435\u043C", -1, 1),
        new Among("\u0438\u0435\u043C", 18, 1),
        new Among("\u043E\u043C", -1, 1),
        new Among("\u044F\u043C", -1, 1),
        new Among("\u0438\u044F\u043C", 21, 1),
        new Among("\u043E", -1, 1),
        new Among("\u0443", -1, 1),
        new Among("\u0430\u0445", -1, 1),
        new Among("\u044F\u0445", -1, 1),
        new Among("\u0438\u044F\u0445", 26, 1),
        new Among("\u044B", -1, 1),
        new Among("\u044C", -1, 1),
        new Among("\u044E", -1, 1),
        new Among("\u0438\u044E", 30, 1),
        new Among("\u044C\u044E", 30, 1),
        new Among("\u044F", -1, 1),
        new Among("\u0438\u044F", 33, 1),
        new Among("\u044C\u044F", 33, 1)
    };

    private final static Among[] a_6 = {
        new Among("\u043E\u0441\u0442", -1, 1),
        new Among("\u043E\u0441\u0442\u044C", -1, 1)
    };

    private final static Among[] a_7 = {
        new Among("\u0435\u0439\u0448\u0435", -1, 1),
        new Among("\u043D", -1, 2),
        new Among("\u0435\u0439\u0448", -1, 1),
        new Among("\u044C", -1, 3)
    };

    private static final char[] g_v = {33, 65, 8, 232 };

    private int I_p2;
    private int I_pV;


    private boolean r_mark_regions() {
        I_pV = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: {
            if (!go_out_grouping(g_v, 1072, 1103))
            {
                break lab0;
            }
            cursor++;
            I_pV = cursor;
            if (!go_in_grouping(g_v, 1072, 1103))
            {
                break lab0;
            }
            cursor++;
            if (!go_out_grouping(g_v, 1072, 1103))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 1072, 1103))
            {
                break lab0;
            }
            cursor++;
            I_p2 = cursor;
        }
        cursor = v_1;
        return true;
    }

    private boolean r_R2() {
        return I_p2 <= cursor;
    }

    private boolean r_perfective_gerund() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_0);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                lab0: {
                    int v_1 = limit - cursor;
                    lab1: {
                        if (!(eq_s_b("\u0430")))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    cursor = limit - v_1;
                    if (!(eq_s_b("\u044F")))
                    {
                        return false;
                    }
                }
                slice_del();
                break;
            case 2:
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_adjective() {
        ket = cursor;
        if (find_among_b(a_1) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    private boolean r_adjectival() {
        int among_var;
        if (!r_adjective())
        {
            return false;
        }
        int v_1 = limit - cursor;
        lab0: {
            ket = cursor;
            among_var = find_among_b(a_2);
            if (among_var == 0)
            {
                cursor = limit - v_1;
                break lab0;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    lab1: {
                        int v_2 = limit - cursor;
                        lab2: {
                            if (!(eq_s_b("\u0430")))
                            {
                                break lab2;
                            }
                            break lab1;
                        }
                        cursor = limit - v_2;
                        if (!(eq_s_b("\u044F")))
                        {
                            cursor = limit - v_1;
                            break lab0;
                        }
                    }
                    slice_del();
                    break;
                case 2:
                    slice_del();
                    break;
            }
        }
        return true;
    }

    private boolean r_reflexive() {
        ket = cursor;
        if (find_among_b(a_3) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    private boolean r_verb() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_4);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                lab0: {
                    int v_1 = limit - cursor;
                    lab1: {
                        if (!(eq_s_b("\u0430")))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    cursor = limit - v_1;
                    if (!(eq_s_b("\u044F")))
                    {
                        return false;
                    }
                }
                slice_del();
                break;
            case 2:
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_noun() {
        ket = cursor;
        if (find_among_b(a_5) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    private boolean r_derivational() {
        ket = cursor;
        if (find_among_b(a_6) == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R2())
        {
            return false;
        }
        slice_del();
        return true;
    }

    private boolean r_tidy_up() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_7);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_del();
                ket = cursor;
                if (!(eq_s_b("\u043D")))
                {
                    return false;
                }
                bra = cursor;
                if (!(eq_s_b("\u043D")))
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!(eq_s_b("\u043D")))
                {
                    return false;
                }
                slice_del();
                break;
            case 3:
                slice_del();
                break;
        }
        return true;
    }

    @Override
    public boolean stem() {
        int v_1 = cursor;
        lab0: {
            while(true)
            {
                int v_2 = cursor;
                lab1: {
                    golab2: while(true)
                    {
                        int v_3 = cursor;
                        lab3: {
                            bra = cursor;
                            if (!(eq_s("\u0451")))
                            {
                                break lab3;
                            }
                            ket = cursor;
                            cursor = v_3;
                            break golab2;
                        }
                        cursor = v_3;
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                    }
                    slice_from("\u0435");
                    continue;
                }
                cursor = v_2;
                break;
            }
        }
        cursor = v_1;
        r_mark_regions();
        limit_backward = cursor;
        cursor = limit;
        if (cursor < I_pV)
        {
            return false;
        }
        int v_4 = limit_backward;
        limit_backward = I_pV;
        int v_5 = limit - cursor;
        lab4: {
            lab5: {
                int v_6 = limit - cursor;
                lab6: {
                    if (!r_perfective_gerund())
                    {
                        break lab6;
                    }
                    break lab5;
                }
                cursor = limit - v_6;
                int v_7 = limit - cursor;
                lab7: {
                    if (!r_reflexive())
                    {
                        cursor = limit - v_7;
                        break lab7;
                    }
                }
                lab8: {
                    int v_8 = limit - cursor;
                    lab9: {
                        if (!r_adjectival())
                        {
                            break lab9;
                        }
                        break lab8;
                    }
                    cursor = limit - v_8;
                    lab10: {
                        if (!r_verb())
                        {
                            break lab10;
                        }
                        break lab8;
                    }
                    cursor = limit - v_8;
                    if (!r_noun())
                    {
                        break lab4;
                    }
                }
            }
        }
        cursor = limit - v_5;
        int v_9 = limit - cursor;
        lab11: {
            ket = cursor;
            if (!(eq_s_b("\u0438")))
            {
                cursor = limit - v_9;
                break lab11;
            }
            bra = cursor;
            slice_del();
        }
        int v_10 = limit - cursor;
        r_derivational();
        cursor = limit - v_10;
        int v_11 = limit - cursor;
        r_tidy_up();
        cursor = limit - v_11;
        limit_backward = v_4;
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof russianStemmer;
    }

    @Override
    public int hashCode() {
        return russianStemmer.class.getName().hashCode();
    }

}
