// Generated from estonian.sbl by Snowball 3.0.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from estonian.sbl by Snowball 3.0.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class estonianStemmer extends org.tartarus.snowball.SnowballStemmer {

    private static final long serialVersionUID = 1L;

    private final static Among[] a_0 = {
        new Among("gi", -1, 1),
        new Among("ki", -1, 2)
    };

    private final static Among[] a_1 = {
        new Among("da", -1, 3),
        new Among("mata", -1, 1),
        new Among("b", -1, 3),
        new Among("ksid", -1, 1),
        new Among("nuksid", 3, 1),
        new Among("me", -1, 3),
        new Among("sime", 5, 1),
        new Among("ksime", 6, 1),
        new Among("nuksime", 7, 1),
        new Among("akse", -1, 2),
        new Among("dakse", 9, 1),
        new Among("takse", 9, 1),
        new Among("site", -1, 1),
        new Among("ksite", 12, 1),
        new Among("nuksite", 13, 1),
        new Among("n", -1, 3),
        new Among("sin", 15, 1),
        new Among("ksin", 16, 1),
        new Among("nuksin", 17, 1),
        new Among("daks", -1, 1),
        new Among("taks", -1, 1)
    };

    private final static Among[] a_2 = {
        new Among("aa", -1, -1),
        new Among("ee", -1, -1),
        new Among("ii", -1, -1),
        new Among("oo", -1, -1),
        new Among("uu", -1, -1),
        new Among("\u00E4\u00E4", -1, -1),
        new Among("\u00F5\u00F5", -1, -1),
        new Among("\u00F6\u00F6", -1, -1),
        new Among("\u00FC\u00FC", -1, -1)
    };

    private final static Among[] a_3 = {
        new Among("i", -1, 1)
    };

    private final static Among[] a_4 = {
        new Among("lane", -1, 1),
        new Among("line", -1, 3),
        new Among("mine", -1, 2),
        new Among("lasse", -1, 1),
        new Among("lisse", -1, 3),
        new Among("misse", -1, 2),
        new Among("lasi", -1, 1),
        new Among("lisi", -1, 3),
        new Among("misi", -1, 2),
        new Among("last", -1, 1),
        new Among("list", -1, 3),
        new Among("mist", -1, 2)
    };

    private final static Among[] a_5 = {
        new Among("ga", -1, 1),
        new Among("ta", -1, 1),
        new Among("le", -1, 1),
        new Among("sse", -1, 1),
        new Among("l", -1, 1),
        new Among("s", -1, 1),
        new Among("ks", 5, 1),
        new Among("t", -1, 2),
        new Among("lt", 7, 1),
        new Among("st", 7, 1)
    };

    private final static Among[] a_6 = {
        new Among("", -1, 2),
        new Among("las", 0, 1),
        new Among("lis", 0, 1),
        new Among("mis", 0, 1),
        new Among("t", 0, -1)
    };

    private final static Among[] a_7 = {
        new Among("d", -1, 4),
        new Among("sid", 0, 2),
        new Among("de", -1, 4),
        new Among("ikkude", 2, 1),
        new Among("ike", -1, 1),
        new Among("ikke", -1, 1),
        new Among("te", -1, 3)
    };

    private final static Among[] a_8 = {
        new Among("va", -1, -1),
        new Among("du", -1, -1),
        new Among("nu", -1, -1),
        new Among("tu", -1, -1)
    };

    private final static Among[] a_9 = {
        new Among("kk", -1, 1),
        new Among("pp", -1, 2),
        new Among("tt", -1, 3)
    };

    private final static Among[] a_10 = {
        new Among("ma", -1, 2),
        new Among("mai", -1, 1),
        new Among("m", -1, 1)
    };

    private final static Among[] a_11 = {
        new Among("joob", -1, 1),
        new Among("jood", -1, 1),
        new Among("joodakse", 1, 1),
        new Among("jooma", -1, 1),
        new Among("joomata", 3, 1),
        new Among("joome", -1, 1),
        new Among("joon", -1, 1),
        new Among("joote", -1, 1),
        new Among("joovad", -1, 1),
        new Among("juua", -1, 1),
        new Among("juuakse", 9, 1),
        new Among("j\u00E4i", -1, 12),
        new Among("j\u00E4id", 11, 12),
        new Among("j\u00E4ime", 11, 12),
        new Among("j\u00E4in", 11, 12),
        new Among("j\u00E4ite", 11, 12),
        new Among("j\u00E4\u00E4b", -1, 12),
        new Among("j\u00E4\u00E4d", -1, 12),
        new Among("j\u00E4\u00E4da", 17, 12),
        new Among("j\u00E4\u00E4dakse", 18, 12),
        new Among("j\u00E4\u00E4di", 17, 12),
        new Among("j\u00E4\u00E4ks", -1, 12),
        new Among("j\u00E4\u00E4ksid", 21, 12),
        new Among("j\u00E4\u00E4ksime", 21, 12),
        new Among("j\u00E4\u00E4ksin", 21, 12),
        new Among("j\u00E4\u00E4ksite", 21, 12),
        new Among("j\u00E4\u00E4ma", -1, 12),
        new Among("j\u00E4\u00E4mata", 26, 12),
        new Among("j\u00E4\u00E4me", -1, 12),
        new Among("j\u00E4\u00E4n", -1, 12),
        new Among("j\u00E4\u00E4te", -1, 12),
        new Among("j\u00E4\u00E4vad", -1, 12),
        new Among("j\u00F5i", -1, 1),
        new Among("j\u00F5id", 32, 1),
        new Among("j\u00F5ime", 32, 1),
        new Among("j\u00F5in", 32, 1),
        new Among("j\u00F5ite", 32, 1),
        new Among("keeb", -1, 4),
        new Among("keed", -1, 4),
        new Among("keedakse", 38, 4),
        new Among("keeks", -1, 4),
        new Among("keeksid", 40, 4),
        new Among("keeksime", 40, 4),
        new Among("keeksin", 40, 4),
        new Among("keeksite", 40, 4),
        new Among("keema", -1, 4),
        new Among("keemata", 45, 4),
        new Among("keeme", -1, 4),
        new Among("keen", -1, 4),
        new Among("kees", -1, 4),
        new Among("keeta", -1, 4),
        new Among("keete", -1, 4),
        new Among("keevad", -1, 4),
        new Among("k\u00E4ia", -1, 8),
        new Among("k\u00E4iakse", 53, 8),
        new Among("k\u00E4ib", -1, 8),
        new Among("k\u00E4id", -1, 8),
        new Among("k\u00E4idi", 56, 8),
        new Among("k\u00E4iks", -1, 8),
        new Among("k\u00E4iksid", 58, 8),
        new Among("k\u00E4iksime", 58, 8),
        new Among("k\u00E4iksin", 58, 8),
        new Among("k\u00E4iksite", 58, 8),
        new Among("k\u00E4ima", -1, 8),
        new Among("k\u00E4imata", 63, 8),
        new Among("k\u00E4ime", -1, 8),
        new Among("k\u00E4in", -1, 8),
        new Among("k\u00E4is", -1, 8),
        new Among("k\u00E4ite", -1, 8),
        new Among("k\u00E4ivad", -1, 8),
        new Among("laob", -1, 16),
        new Among("laod", -1, 16),
        new Among("laoks", -1, 16),
        new Among("laoksid", 72, 16),
        new Among("laoksime", 72, 16),
        new Among("laoksin", 72, 16),
        new Among("laoksite", 72, 16),
        new Among("laome", -1, 16),
        new Among("laon", -1, 16),
        new Among("laote", -1, 16),
        new Among("laovad", -1, 16),
        new Among("loeb", -1, 14),
        new Among("loed", -1, 14),
        new Among("loeks", -1, 14),
        new Among("loeksid", 83, 14),
        new Among("loeksime", 83, 14),
        new Among("loeksin", 83, 14),
        new Among("loeksite", 83, 14),
        new Among("loeme", -1, 14),
        new Among("loen", -1, 14),
        new Among("loete", -1, 14),
        new Among("loevad", -1, 14),
        new Among("loob", -1, 7),
        new Among("lood", -1, 7),
        new Among("loodi", 93, 7),
        new Among("looks", -1, 7),
        new Among("looksid", 95, 7),
        new Among("looksime", 95, 7),
        new Among("looksin", 95, 7),
        new Among("looksite", 95, 7),
        new Among("looma", -1, 7),
        new Among("loomata", 100, 7),
        new Among("loome", -1, 7),
        new Among("loon", -1, 7),
        new Among("loote", -1, 7),
        new Among("loovad", -1, 7),
        new Among("luua", -1, 7),
        new Among("luuakse", 106, 7),
        new Among("l\u00F5i", -1, 6),
        new Among("l\u00F5id", 108, 6),
        new Among("l\u00F5ime", 108, 6),
        new Among("l\u00F5in", 108, 6),
        new Among("l\u00F5ite", 108, 6),
        new Among("l\u00F6\u00F6b", -1, 5),
        new Among("l\u00F6\u00F6d", -1, 5),
        new Among("l\u00F6\u00F6dakse", 114, 5),
        new Among("l\u00F6\u00F6di", 114, 5),
        new Among("l\u00F6\u00F6ks", -1, 5),
        new Among("l\u00F6\u00F6ksid", 117, 5),
        new Among("l\u00F6\u00F6ksime", 117, 5),
        new Among("l\u00F6\u00F6ksin", 117, 5),
        new Among("l\u00F6\u00F6ksite", 117, 5),
        new Among("l\u00F6\u00F6ma", -1, 5),
        new Among("l\u00F6\u00F6mata", 122, 5),
        new Among("l\u00F6\u00F6me", -1, 5),
        new Among("l\u00F6\u00F6n", -1, 5),
        new Among("l\u00F6\u00F6te", -1, 5),
        new Among("l\u00F6\u00F6vad", -1, 5),
        new Among("l\u00FC\u00FCa", -1, 5),
        new Among("l\u00FC\u00FCakse", 128, 5),
        new Among("m\u00FC\u00FCa", -1, 13),
        new Among("m\u00FC\u00FCakse", 130, 13),
        new Among("m\u00FC\u00FCb", -1, 13),
        new Among("m\u00FC\u00FCd", -1, 13),
        new Among("m\u00FC\u00FCdi", 133, 13),
        new Among("m\u00FC\u00FCks", -1, 13),
        new Among("m\u00FC\u00FCksid", 135, 13),
        new Among("m\u00FC\u00FCksime", 135, 13),
        new Among("m\u00FC\u00FCksin", 135, 13),
        new Among("m\u00FC\u00FCksite", 135, 13),
        new Among("m\u00FC\u00FCma", -1, 13),
        new Among("m\u00FC\u00FCmata", 140, 13),
        new Among("m\u00FC\u00FCme", -1, 13),
        new Among("m\u00FC\u00FCn", -1, 13),
        new Among("m\u00FC\u00FCs", -1, 13),
        new Among("m\u00FC\u00FCte", -1, 13),
        new Among("m\u00FC\u00FCvad", -1, 13),
        new Among("n\u00E4eb", -1, 18),
        new Among("n\u00E4ed", -1, 18),
        new Among("n\u00E4eks", -1, 18),
        new Among("n\u00E4eksid", 149, 18),
        new Among("n\u00E4eksime", 149, 18),
        new Among("n\u00E4eksin", 149, 18),
        new Among("n\u00E4eksite", 149, 18),
        new Among("n\u00E4eme", -1, 18),
        new Among("n\u00E4en", -1, 18),
        new Among("n\u00E4ete", -1, 18),
        new Among("n\u00E4evad", -1, 18),
        new Among("n\u00E4gema", -1, 18),
        new Among("n\u00E4gemata", 158, 18),
        new Among("n\u00E4ha", -1, 18),
        new Among("n\u00E4hakse", 160, 18),
        new Among("n\u00E4hti", -1, 18),
        new Among("p\u00F5eb", -1, 15),
        new Among("p\u00F5ed", -1, 15),
        new Among("p\u00F5eks", -1, 15),
        new Among("p\u00F5eksid", 165, 15),
        new Among("p\u00F5eksime", 165, 15),
        new Among("p\u00F5eksin", 165, 15),
        new Among("p\u00F5eksite", 165, 15),
        new Among("p\u00F5eme", -1, 15),
        new Among("p\u00F5en", -1, 15),
        new Among("p\u00F5ete", -1, 15),
        new Among("p\u00F5evad", -1, 15),
        new Among("saab", -1, 2),
        new Among("saad", -1, 2),
        new Among("saada", 175, 2),
        new Among("saadakse", 176, 2),
        new Among("saadi", 175, 2),
        new Among("saaks", -1, 2),
        new Among("saaksid", 179, 2),
        new Among("saaksime", 179, 2),
        new Among("saaksin", 179, 2),
        new Among("saaksite", 179, 2),
        new Among("saama", -1, 2),
        new Among("saamata", 184, 2),
        new Among("saame", -1, 2),
        new Among("saan", -1, 2),
        new Among("saate", -1, 2),
        new Among("saavad", -1, 2),
        new Among("sai", -1, 2),
        new Among("said", 190, 2),
        new Among("saime", 190, 2),
        new Among("sain", 190, 2),
        new Among("saite", 190, 2),
        new Among("s\u00F5i", -1, 9),
        new Among("s\u00F5id", 195, 9),
        new Among("s\u00F5ime", 195, 9),
        new Among("s\u00F5in", 195, 9),
        new Among("s\u00F5ite", 195, 9),
        new Among("s\u00F6\u00F6b", -1, 9),
        new Among("s\u00F6\u00F6d", -1, 9),
        new Among("s\u00F6\u00F6dakse", 201, 9),
        new Among("s\u00F6\u00F6di", 201, 9),
        new Among("s\u00F6\u00F6ks", -1, 9),
        new Among("s\u00F6\u00F6ksid", 204, 9),
        new Among("s\u00F6\u00F6ksime", 204, 9),
        new Among("s\u00F6\u00F6ksin", 204, 9),
        new Among("s\u00F6\u00F6ksite", 204, 9),
        new Among("s\u00F6\u00F6ma", -1, 9),
        new Among("s\u00F6\u00F6mata", 209, 9),
        new Among("s\u00F6\u00F6me", -1, 9),
        new Among("s\u00F6\u00F6n", -1, 9),
        new Among("s\u00F6\u00F6te", -1, 9),
        new Among("s\u00F6\u00F6vad", -1, 9),
        new Among("s\u00FC\u00FCa", -1, 9),
        new Among("s\u00FC\u00FCakse", 215, 9),
        new Among("teeb", -1, 17),
        new Among("teed", -1, 17),
        new Among("teeks", -1, 17),
        new Among("teeksid", 219, 17),
        new Among("teeksime", 219, 17),
        new Among("teeksin", 219, 17),
        new Among("teeksite", 219, 17),
        new Among("teeme", -1, 17),
        new Among("teen", -1, 17),
        new Among("teete", -1, 17),
        new Among("teevad", -1, 17),
        new Among("tegema", -1, 17),
        new Among("tegemata", 228, 17),
        new Among("teha", -1, 17),
        new Among("tehakse", 230, 17),
        new Among("tehti", -1, 17),
        new Among("toob", -1, 10),
        new Among("tood", -1, 10),
        new Among("toodi", 234, 10),
        new Among("tooks", -1, 10),
        new Among("tooksid", 236, 10),
        new Among("tooksime", 236, 10),
        new Among("tooksin", 236, 10),
        new Among("tooksite", 236, 10),
        new Among("tooma", -1, 10),
        new Among("toomata", 241, 10),
        new Among("toome", -1, 10),
        new Among("toon", -1, 10),
        new Among("toote", -1, 10),
        new Among("toovad", -1, 10),
        new Among("tuua", -1, 10),
        new Among("tuuakse", 247, 10),
        new Among("t\u00F5i", -1, 10),
        new Among("t\u00F5id", 249, 10),
        new Among("t\u00F5ime", 249, 10),
        new Among("t\u00F5in", 249, 10),
        new Among("t\u00F5ite", 249, 10),
        new Among("viia", -1, 3),
        new Among("viiakse", 254, 3),
        new Among("viib", -1, 3),
        new Among("viid", -1, 3),
        new Among("viidi", 257, 3),
        new Among("viiks", -1, 3),
        new Among("viiksid", 259, 3),
        new Among("viiksime", 259, 3),
        new Among("viiksin", 259, 3),
        new Among("viiksite", 259, 3),
        new Among("viima", -1, 3),
        new Among("viimata", 264, 3),
        new Among("viime", -1, 3),
        new Among("viin", -1, 3),
        new Among("viisime", -1, 3),
        new Among("viisin", -1, 3),
        new Among("viisite", -1, 3),
        new Among("viite", -1, 3),
        new Among("viivad", -1, 3),
        new Among("v\u00F5ib", -1, 11),
        new Among("v\u00F5id", -1, 11),
        new Among("v\u00F5ida", 274, 11),
        new Among("v\u00F5idakse", 275, 11),
        new Among("v\u00F5idi", 274, 11),
        new Among("v\u00F5iks", -1, 11),
        new Among("v\u00F5iksid", 278, 11),
        new Among("v\u00F5iksime", 278, 11),
        new Among("v\u00F5iksin", 278, 11),
        new Among("v\u00F5iksite", 278, 11),
        new Among("v\u00F5ima", -1, 11),
        new Among("v\u00F5imata", 283, 11),
        new Among("v\u00F5ime", -1, 11),
        new Among("v\u00F5in", -1, 11),
        new Among("v\u00F5is", -1, 11),
        new Among("v\u00F5ite", -1, 11),
        new Among("v\u00F5ivad", -1, 11)
    };

    private static final char[] g_V1 = {17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 48, 8 };

    private static final char[] g_RV = {17, 65, 16 };

    private static final char[] g_KI = {117, 66, 6, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 0, 0, 0, 16 };

    private static final char[] g_GI = {21, 123, 243, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 48, 8 };

    private int I_p1;


    private boolean r_mark_regions() {
        I_p1 = limit;
        if (!go_out_grouping(g_V1, 97, 252))
        {
            return false;
        }
        cursor++;
        if (!go_in_grouping(g_V1, 97, 252))
        {
            return false;
        }
        cursor++;
        I_p1 = cursor;
        return true;
    }

    private boolean r_emphasis() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_0);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        int v_2 = limit - cursor;
        {
            int c = cursor - 4;
            if (c < limit_backward)
            {
                return false;
            }
            cursor = c;
        }
        cursor = limit - v_2;
        switch (among_var) {
            case 1:
                int v_3 = limit - cursor;
                if (!(in_grouping_b(g_GI, 97, 252)))
                {
                    return false;
                }
                cursor = limit - v_3;
                {
                    int v_4 = limit - cursor;
                    lab0: {
                        if (!r_LONGV())
                        {
                            break lab0;
                        }
                        return false;
                    }
                    cursor = limit - v_4;
                }
                slice_del();
                break;
            case 2:
                if (!(in_grouping_b(g_KI, 98, 382)))
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_verb() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_1);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_from("a");
                break;
            case 3:
                if (!(in_grouping_b(g_V1, 97, 252)))
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_LONGV() {
        if (find_among_b(a_2) == 0)
        {
            return false;
        }
        return true;
    }

    private boolean r_i_plural() {
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (find_among_b(a_3) == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        if (!(in_grouping_b(g_RV, 97, 117)))
        {
            return false;
        }
        slice_del();
        return true;
    }

    private boolean r_special_noun_endings() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_4);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_from("lase");
                break;
            case 2:
                slice_from("mise");
                break;
            case 3:
                slice_from("lise");
                break;
        }
        return true;
    }

    private boolean r_case_ending() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_5);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                lab0: {
                    int v_2 = limit - cursor;
                    lab1: {
                        if (!(in_grouping_b(g_RV, 97, 117)))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    cursor = limit - v_2;
                    if (!r_LONGV())
                    {
                        return false;
                    }
                }
                break;
            case 2:
                int v_3 = limit - cursor;
                {
                    int c = cursor - 4;
                    if (c < limit_backward)
                    {
                        return false;
                    }
                    cursor = c;
                }
                cursor = limit - v_3;
                break;
        }
        slice_del();
        return true;
    }

    private boolean r_plural_three_first_cases() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_7);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_from("iku");
                break;
            case 2:
                {
                    int v_2 = limit - cursor;
                    lab0: {
                        if (!r_LONGV())
                        {
                            break lab0;
                        }
                        return false;
                    }
                    cursor = limit - v_2;
                }
                slice_del();
                break;
            case 3:
                lab1: {
                    int v_3 = limit - cursor;
                    lab2: {
                        int v_4 = limit - cursor;
                        {
                            int c = cursor - 4;
                            if (c < limit_backward)
                            {
                                break lab2;
                            }
                            cursor = c;
                        }
                        cursor = limit - v_4;
                        among_var = find_among_b(a_6);
                        switch (among_var) {
                            case 1:
                                slice_from("e");
                                break;
                            case 2:
                                slice_del();
                                break;
                        }
                        break lab1;
                    }
                    cursor = limit - v_3;
                    slice_from("t");
                }
                break;
            case 4:
                lab3: {
                    int v_5 = limit - cursor;
                    lab4: {
                        if (!(in_grouping_b(g_RV, 97, 117)))
                        {
                            break lab4;
                        }
                        break lab3;
                    }
                    cursor = limit - v_5;
                    if (!r_LONGV())
                    {
                        return false;
                    }
                }
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_nu() {
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (find_among_b(a_8) == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        slice_del();
        return true;
    }

    private boolean r_undouble_kpt() {
        int among_var;
        if (!(in_grouping_b(g_V1, 97, 252)))
        {
            return false;
        }
        if (I_p1 > cursor)
        {
            return false;
        }
        ket = cursor;
        among_var = find_among_b(a_9);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("k");
                break;
            case 2:
                slice_from("p");
                break;
            case 3:
                slice_from("t");
                break;
        }
        return true;
    }

    private boolean r_degrees() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_10);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                if (!(in_grouping_b(g_RV, 97, 117)))
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_substantive() {
        int v_1 = limit - cursor;
        r_special_noun_endings();
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        r_case_ending();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_plural_three_first_cases();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_degrees();
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        r_i_plural();
        cursor = limit - v_5;
        int v_6 = limit - cursor;
        r_nu();
        cursor = limit - v_6;
        return true;
    }

    private boolean r_verb_exceptions() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_11);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        if (cursor < limit)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("joo");
                break;
            case 2:
                slice_from("saa");
                break;
            case 3:
                slice_from("viima");
                break;
            case 4:
                slice_from("keesi");
                break;
            case 5:
                slice_from("l\u00F6\u00F6");
                break;
            case 6:
                slice_from("l\u00F5i");
                break;
            case 7:
                slice_from("loo");
                break;
            case 8:
                slice_from("k\u00E4isi");
                break;
            case 9:
                slice_from("s\u00F6\u00F6");
                break;
            case 10:
                slice_from("too");
                break;
            case 11:
                slice_from("v\u00F5isi");
                break;
            case 12:
                slice_from("j\u00E4\u00E4ma");
                break;
            case 13:
                slice_from("m\u00FC\u00FCsi");
                break;
            case 14:
                slice_from("luge");
                break;
            case 15:
                slice_from("p\u00F5de");
                break;
            case 16:
                slice_from("ladu");
                break;
            case 17:
                slice_from("tegi");
                break;
            case 18:
                slice_from("n\u00E4gi");
                break;
        }
        return true;
    }

    @Override
    public boolean stem() {
        {
            int v_1 = cursor;
            lab0: {
                if (!r_verb_exceptions())
                {
                    break lab0;
                }
                return false;
            }
            cursor = v_1;
        }
        int v_2 = cursor;
        r_mark_regions();
        cursor = v_2;
        limit_backward = cursor;
        cursor = limit;
        int v_3 = limit - cursor;
        r_emphasis();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        lab1: {
            lab2: {
                int v_5 = limit - cursor;
                lab3: {
                    if (!r_verb())
                    {
                        break lab3;
                    }
                    break lab2;
                }
                cursor = limit - v_5;
                r_substantive();
            }
        }
        cursor = limit - v_4;
        int v_6 = limit - cursor;
        r_undouble_kpt();
        cursor = limit - v_6;
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof estonianStemmer;
    }

    @Override
    public int hashCode() {
        return estonianStemmer.class.getName().hashCode();
    }

}
