// Generated from greek.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from greek.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class greek_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 25, 0),
        Among("\u0386", 0, 1, 0),
        Among("\u0388", 0, 5, 0),
        Among("\u0389", 0, 7, 0),
        Among("\u038A", 0, 9, 0),
        Among("\u038C", 0, 15, 0),
        Among("\u038E", 0, 20, 0),
        Among("\u038F", 0, 24, 0),
        Among("\u0390", 0, 7, 0),
        Among("\u0391", 0, 1, 0),
        Among("\u0392", 0, 2, 0),
        Among("\u0393", 0, 3, 0),
        Among("\u0394", 0, 4, 0),
        Among("\u0395", 0, 5, 0),
        Among("\u0396", 0, 6, 0),
        Among("\u0397", 0, 7, 0),
        Among("\u0398", 0, 8, 0),
        Among("\u0399", 0, 9, 0),
        Among("\u039A", 0, 10, 0),
        Among("\u039B", 0, 11, 0),
        Among("\u039C", 0, 12, 0),
        Among("\u039D", 0, 13, 0),
        Among("\u039E", 0, 14, 0),
        Among("\u039F", 0, 15, 0),
        Among("\u03A0", 0, 16, 0),
        Among("\u03A1", 0, 17, 0),
        Among("\u03A3", 0, 18, 0),
        Among("\u03A4", 0, 19, 0),
        Among("\u03A5", 0, 20, 0),
        Among("\u03A6", 0, 21, 0),
        Among("\u03A7", 0, 22, 0),
        Among("\u03A8", 0, 23, 0),
        Among("\u03A9", 0, 24, 0),
        Among("\u03AA", 0, 9, 0),
        Among("\u03AB", 0, 20, 0),
        Among("\u03AC", 0, 1, 0),
        Among("\u03AD", 0, 5, 0),
        Among("\u03AE", 0, 7, 0),
        Among("\u03AF", 0, 9, 0),
        Among("\u03B0", 0, 20, 0),
        Among("\u03C2", 0, 18, 0),
        Among("\u03CA", 0, 7, 0),
        Among("\u03CB", 0, 20, 0),
        Among("\u03CC", 0, 15, 0),
        Among("\u03CD", 0, 20, 0),
        Among("\u03CE", 0, 24, 0)
    ];

    static final a_1 = [
        Among("\u03C3\u03BA\u03B1\u03B3\u03B9\u03B1", -1, 2, 0),
        Among("\u03C6\u03B1\u03B3\u03B9\u03B1", -1, 1, 0),
        Among("\u03BF\u03BB\u03BF\u03B3\u03B9\u03B1", -1, 3, 0),
        Among("\u03C3\u03BF\u03B3\u03B9\u03B1", -1, 4, 0),
        Among("\u03C4\u03B1\u03C4\u03BF\u03B3\u03B9\u03B1", -1, 5, 0),
        Among("\u03BA\u03C1\u03B5\u03B1\u03C4\u03B1", -1, 6, 0),
        Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03B1", -1, 7, 0),
        Among("\u03C4\u03B5\u03C1\u03B1\u03C4\u03B1", -1, 8, 0),
        Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C4\u03B1", -1, 11, 0),
        Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C4\u03B1", -1, 10, 0),
        Among("\u03C6\u03C9\u03C4\u03B1", -1, 9, 0),
        Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03B7", -1, 7, 0),
        Among("\u03C3\u03BA\u03B1\u03B3\u03B9\u03C9\u03BD", -1, 2, 0),
        Among("\u03C6\u03B1\u03B3\u03B9\u03C9\u03BD", -1, 1, 0),
        Among("\u03BF\u03BB\u03BF\u03B3\u03B9\u03C9\u03BD", -1, 3, 0),
        Among("\u03C3\u03BF\u03B3\u03B9\u03C9\u03BD", -1, 4, 0),
        Among("\u03C4\u03B1\u03C4\u03BF\u03B3\u03B9\u03C9\u03BD", -1, 5, 0),
        Among("\u03BA\u03C1\u03B5\u03B1\u03C4\u03C9\u03BD", -1, 6, 0),
        Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03C9\u03BD", -1, 7, 0),
        Among("\u03C4\u03B5\u03C1\u03B1\u03C4\u03C9\u03BD", -1, 8, 0),
        Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C4\u03C9\u03BD", -1, 11, 0),
        Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C4\u03C9\u03BD", -1, 10, 0),
        Among("\u03C6\u03C9\u03C4\u03C9\u03BD", -1, 9, 0),
        Among("\u03BA\u03C1\u03B5\u03B1\u03C3", -1, 6, 0),
        Among("\u03C0\u03B5\u03C1\u03B1\u03C3", -1, 7, 0),
        Among("\u03C4\u03B5\u03C1\u03B1\u03C3", -1, 8, 0),
        Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C3", -1, 11, 0),
        Among("\u03BA\u03C1\u03B5\u03B1\u03C4\u03BF\u03C3", -1, 6, 0),
        Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03BF\u03C3", -1, 7, 0),
        Among("\u03C4\u03B5\u03C1\u03B1\u03C4\u03BF\u03C3", -1, 8, 0),
        Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C4\u03BF\u03C3", -1, 11, 0),
        Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C4\u03BF\u03C3", -1, 10, 0),
        Among("\u03C6\u03C9\u03C4\u03BF\u03C3", -1, 9, 0),
        Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C3", -1, 10, 0),
        Among("\u03C6\u03C9\u03C3", -1, 9, 0),
        Among("\u03C3\u03BA\u03B1\u03B3\u03B9\u03BF\u03C5", -1, 2, 0),
        Among("\u03C6\u03B1\u03B3\u03B9\u03BF\u03C5", -1, 1, 0),
        Among("\u03BF\u03BB\u03BF\u03B3\u03B9\u03BF\u03C5", -1, 3, 0),
        Among("\u03C3\u03BF\u03B3\u03B9\u03BF\u03C5", -1, 4, 0),
        Among("\u03C4\u03B1\u03C4\u03BF\u03B3\u03B9\u03BF\u03C5", -1, 5, 0)
    ];

    static final a_2 = [
        Among("\u03C0\u03B1", -1, 1, 0),
        Among("\u03BE\u03B1\u03BD\u03B1\u03C0\u03B1", 0, 1, 0),
        Among("\u03B5\u03C0\u03B1", 0, 1, 0),
        Among("\u03C0\u03B5\u03C1\u03B9\u03C0\u03B1", 0, 1, 0),
        Among("\u03B1\u03BD\u03B1\u03BC\u03C0\u03B1", 0, 1, 0),
        Among("\u03B5\u03BC\u03C0\u03B1", 0, 1, 0),
        Among("\u03B2", -1, 2, 0),
        Among("\u03B4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B2\u03B1\u03B8\u03C5\u03C1\u03B9", -1, 2, 0),
        Among("\u03B2\u03B1\u03C1\u03BA", -1, 2, 0),
        Among("\u03BC\u03B1\u03C1\u03BA", -1, 2, 0),
        Among("\u03BB", -1, 2, 0),
        Among("\u03BC", -1, 2, 0),
        Among("\u03BA\u03BF\u03C1\u03BD", -1, 2, 0),
        Among("\u03B1\u03B8\u03C1\u03BF", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", 14, 1, 0),
        Among("\u03C0", -1, 2, 0),
        Among("\u03B9\u03BC\u03C0", 16, 2, 0),
        Among("\u03C1", -1, 2, 0),
        Among("\u03BC\u03B1\u03C1", 18, 2, 0),
        Among("\u03B1\u03BC\u03C0\u03B1\u03C1", 18, 2, 0),
        Among("\u03B3\u03BA\u03C1", 18, 2, 0),
        Among("\u03B2\u03BF\u03BB\u03B2\u03BF\u03C1", 18, 2, 0),
        Among("\u03B3\u03BB\u03C5\u03BA\u03BF\u03C1", 18, 2, 0),
        Among("\u03C0\u03B9\u03C0\u03B5\u03C1\u03BF\u03C1", 18, 2, 0),
        Among("\u03C0\u03C1", 18, 2, 0),
        Among("\u03BC\u03C0\u03C1", 25, 2, 0),
        Among("\u03B1\u03C1\u03C1", 18, 2, 0),
        Among("\u03B3\u03BB\u03C5\u03BA\u03C5\u03C1", 18, 2, 0),
        Among("\u03C0\u03BF\u03BB\u03C5\u03C1", 18, 2, 0),
        Among("\u03BB\u03BF\u03C5", -1, 2, 0)
    ];

    static final a_3 = [
        Among("\u03B9\u03B6\u03B1", -1, 1, 0),
        Among("\u03B9\u03B6\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03BF\u03C5\u03BC\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03BF\u03C5\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03B1\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03B5\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03B5\u03B9", -1, 1, 0),
        Among("\u03B9\u03B6\u03B1\u03BD", -1, 1, 0),
        Among("\u03B9\u03B6\u03BF\u03C5\u03BD", -1, 1, 0),
        Among("\u03B9\u03B6\u03B5\u03C3", -1, 1, 0),
        Among("\u03B9\u03B6\u03B5\u03B9\u03C3", -1, 1, 0),
        Among("\u03B9\u03B6\u03C9", -1, 1, 0)
    ];

    static final a_4 = [
        Among("\u03B2\u03B9", -1, 1, 0),
        Among("\u03BB\u03B9", -1, 1, 0),
        Among("\u03B1\u03BB", -1, 1, 0),
        Among("\u03B5\u03BD", -1, 1, 0),
        Among("\u03C3", -1, 1, 0),
        Among("\u03C7", -1, 1, 0),
        Among("\u03C5\u03C8", -1, 1, 0),
        Among("\u03B6\u03C9", -1, 1, 0)
    ];

    static final a_5 = [
        Among("\u03C9\u03B8\u03B7\u03BA\u03B1", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B5", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03C4\u03B5", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03BD", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_6 = [
        Among("\u03BE\u03B1\u03BD\u03B1\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03C0\u03B1", -1, 1, 0),
        Among("\u03C0\u03B5\u03C1\u03B9\u03C0\u03B1", -1, 1, 0),
        Among("\u03B1\u03BD\u03B1\u03BC\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03BC\u03C0\u03B1", -1, 1, 0),
        Among("\u03C7\u03B1\u03C1\u03C4\u03BF\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03BE\u03B1\u03C1\u03C7\u03B1", -1, 1, 0),
        Among("\u03B3\u03B5", -1, 2, 0),
        Among("\u03B3\u03BA\u03B5", -1, 2, 0),
        Among("\u03BA\u03BB\u03B5", -1, 1, 0),
        Among("\u03B5\u03BA\u03BB\u03B5", 9, 1, 0),
        Among("\u03B1\u03C0\u03B5\u03BA\u03BB\u03B5", 10, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03BA\u03BB\u03B5", 9, 1, 0),
        Among("\u03B5\u03C3\u03C9\u03BA\u03BB\u03B5", 9, 1, 0),
        Among("\u03B4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03C0\u03B5", -1, 1, 0),
        Among("\u03B5\u03C0\u03B5", 15, 1, 0),
        Among("\u03BC\u03B5\u03C4\u03B5\u03C0\u03B5", 16, 1, 0),
        Among("\u03B5\u03C3\u03B5", -1, 1, 0),
        Among("\u03B3\u03BA", -1, 2, 0),
        Among("\u03BC", -1, 2, 0),
        Among("\u03C0\u03BF\u03C5\u03BA\u03B1\u03BC", 20, 2, 0),
        Among("\u03BA\u03BF\u03BC", 20, 2, 0),
        Among("\u03B1\u03BD", -1, 2, 0),
        Among("\u03BF\u03BB\u03BF", -1, 2, 0),
        Among("\u03B1\u03B8\u03C1\u03BF", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", 25, 1, 0),
        Among("\u03C0", -1, 2, 0),
        Among("\u03BB\u03B1\u03C1", -1, 2, 0),
        Among("\u03B4\u03B7\u03BC\u03BF\u03BA\u03C1\u03B1\u03C4", -1, 2, 0),
        Among("\u03B1\u03C6", -1, 2, 0),
        Among("\u03B3\u03B9\u03B3\u03B1\u03BD\u03C4\u03BF\u03B1\u03C6", 30, 2, 0)
    ];

    static final a_7 = [
        Among("\u03B9\u03C3\u03B1", -1, 1, 0),
        Among("\u03B9\u03C3\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B1\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B1\u03BD", -1, 1, 0),
        Among("\u03B9\u03C3\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_8 = [
        Among("\u03BE\u03B1\u03BD\u03B1\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03C0\u03B1", -1, 1, 0),
        Among("\u03C0\u03B5\u03C1\u03B9\u03C0\u03B1", -1, 1, 0),
        Among("\u03B1\u03BD\u03B1\u03BC\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03BC\u03C0\u03B1", -1, 1, 0),
        Among("\u03C7\u03B1\u03C1\u03C4\u03BF\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03BE\u03B1\u03C1\u03C7\u03B1", -1, 1, 0),
        Among("\u03BA\u03BB\u03B5", -1, 1, 0),
        Among("\u03B5\u03BA\u03BB\u03B5", 7, 1, 0),
        Among("\u03B1\u03C0\u03B5\u03BA\u03BB\u03B5", 8, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03BA\u03BB\u03B5", 7, 1, 0),
        Among("\u03B5\u03C3\u03C9\u03BA\u03BB\u03B5", 7, 1, 0),
        Among("\u03B4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03C0\u03B5", -1, 1, 0),
        Among("\u03B5\u03C0\u03B5", 13, 1, 0),
        Among("\u03BC\u03B5\u03C4\u03B5\u03C0\u03B5", 14, 1, 0),
        Among("\u03B5\u03C3\u03B5", -1, 1, 0),
        Among("\u03B1\u03B8\u03C1\u03BF", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", 17, 1, 0)
    ];

    static final a_9 = [
        Among("\u03B9\u03C3\u03BF\u03C5\u03BC\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03BF\u03C5\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B5\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B5\u03B9", -1, 1, 0),
        Among("\u03B9\u03C3\u03BF\u03C5\u03BD", -1, 1, 0),
        Among("\u03B9\u03C3\u03B5\u03B9\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03C9", -1, 1, 0)
    ];

    static final a_10 = [
        Among("\u03B1\u03C4\u03B1", -1, 2, 0),
        Among("\u03C6\u03B1", -1, 2, 0),
        Among("\u03B7\u03C6\u03B1", 1, 2, 0),
        Among("\u03BC\u03B5\u03B3", -1, 2, 0),
        Among("\u03BB\u03C5\u03B3", -1, 2, 0),
        Among("\u03B7\u03B4", -1, 2, 0),
        Among("\u03BA\u03BB\u03B5", -1, 1, 0),
        Among("\u03B5\u03C3\u03C9\u03BA\u03BB\u03B5", 6, 1, 0),
        Among("\u03C0\u03BB\u03B5", -1, 1, 0),
        Among("\u03B4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03C3\u03B5", -1, 1, 0),
        Among("\u03B1\u03C3\u03B5", 10, 1, 0),
        Among("\u03BA\u03B1\u03B8", -1, 2, 0),
        Among("\u03B5\u03C7\u03B8", -1, 2, 0),
        Among("\u03BA\u03B1\u03BA", -1, 2, 0),
        Among("\u03BC\u03B1\u03BA", -1, 2, 0),
        Among("\u03C3\u03BA", -1, 2, 0),
        Among("\u03C6\u03B9\u03BB", -1, 2, 0),
        Among("\u03BA\u03C5\u03BB", -1, 2, 0),
        Among("\u03BC", -1, 2, 0),
        Among("\u03B3\u03B5\u03BC", 19, 2, 0),
        Among("\u03B1\u03C7\u03BD", -1, 2, 0),
        Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", -1, 1, 0),
        Among("\u03C0", -1, 2, 0),
        Among("\u03B1\u03C0", 23, 2, 0),
        Among("\u03B5\u03BC\u03C0", 23, 2, 0),
        Among("\u03B5\u03C5\u03C0", 23, 2, 0),
        Among("\u03B1\u03C1", -1, 2, 0),
        Among("\u03B1\u03BF\u03C1", -1, 2, 0),
        Among("\u03B3\u03C5\u03C1", -1, 2, 0),
        Among("\u03C7\u03C1", -1, 2, 0),
        Among("\u03C7\u03C9\u03C1", -1, 2, 0),
        Among("\u03BA\u03C4", -1, 2, 0),
        Among("\u03B1\u03BA\u03C4", 32, 2, 0),
        Among("\u03C7\u03C4", -1, 2, 0),
        Among("\u03B1\u03C7\u03C4", 34, 2, 0),
        Among("\u03C4\u03B1\u03C7", -1, 2, 0),
        Among("\u03C3\u03C7", -1, 2, 0),
        Among("\u03B1\u03C3\u03C7", 37, 2, 0),
        Among("\u03C5\u03C8", -1, 2, 0)
    ];

    static final a_11 = [
        Among("\u03B9\u03C3\u03C4\u03B1", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03B7", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03BF\u03B9", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03BF", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03B5\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03B7\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03BF\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03BF\u03C5\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_12 = [
        Among("\u03B5\u03B3\u03BA\u03BB\u03B5", -1, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03BA\u03BB\u03B5", -1, 1, 0),
        Among("\u03B4\u03B1\u03BD\u03B5", -1, 2, 0),
        Among("\u03B1\u03BD\u03C4\u03B9\u03B4\u03B1\u03BD\u03B5", 2, 2, 0),
        Among("\u03C3\u03B5", -1, 1, 0),
        Among("\u03BC\u03B5\u03C4\u03B1\u03C3\u03B5", 4, 1, 0),
        Among("\u03BC\u03B9\u03BA\u03C1\u03BF\u03C3\u03B5", 4, 1, 0)
    ];

    static final a_13 = [
        Among("\u03B1\u03C4\u03BF\u03BC\u03B9\u03BA", -1, 2, 0),
        Among("\u03B5\u03B8\u03BD\u03B9\u03BA", -1, 4, 0),
        Among("\u03C4\u03BF\u03C0\u03B9\u03BA", -1, 7, 0),
        Among("\u03B5\u03BA\u03BB\u03B5\u03BA\u03C4\u03B9\u03BA", -1, 5, 0),
        Among("\u03C3\u03BA\u03B5\u03C0\u03C4\u03B9\u03BA", -1, 6, 0),
        Among("\u03B3\u03BD\u03C9\u03C3\u03C4\u03B9\u03BA", -1, 3, 0),
        Among("\u03B1\u03B3\u03BD\u03C9\u03C3\u03C4\u03B9\u03BA", 5, 1, 0),
        Among("\u03B1\u03BB\u03B5\u03BE\u03B1\u03BD\u03B4\u03C1\u03B9\u03BD", -1, 8, 0),
        Among("\u03B8\u03B5\u03B1\u03C4\u03C1\u03B9\u03BD", -1, 10, 0),
        Among("\u03B2\u03C5\u03B6\u03B1\u03BD\u03C4\u03B9\u03BD", -1, 9, 0)
    ];

    static final a_14 = [
        Among("\u03B9\u03C3\u03BC\u03BF\u03B9", -1, 1, 0),
        Among("\u03B9\u03C3\u03BC\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03C3\u03BC\u03BF", -1, 1, 0),
        Among("\u03B9\u03C3\u03BC\u03BF\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03BC\u03BF\u03C5\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03BC\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_15 = [
        Among("\u03C3", -1, 1, 0),
        Among("\u03C7", -1, 1, 0)
    ];

    static final a_16 = [
        Among("\u03BF\u03C5\u03B4\u03B1\u03BA\u03B9\u03B1", -1, 1, 0),
        Among("\u03B1\u03C1\u03B1\u03BA\u03B9\u03B1", -1, 1, 0),
        Among("\u03BF\u03C5\u03B4\u03B1\u03BA\u03B9", -1, 1, 0),
        Among("\u03B1\u03C1\u03B1\u03BA\u03B9", -1, 1, 0)
    ];

    static final a_17 = [
        Among("\u03B2", -1, 2, 0),
        Among("\u03B2\u03B1\u03BC\u03B2", 0, 1, 0),
        Among("\u03C3\u03BB\u03BF\u03B2", 0, 1, 0),
        Among("\u03C4\u03C3\u03B5\u03C7\u03BF\u03C3\u03BB\u03BF\u03B2", 2, 1, 0),
        Among("\u03BA\u03B1\u03C1\u03B4", -1, 2, 0),
        Among("\u03B6", -1, 2, 0),
        Among("\u03C4\u03B6", 5, 1, 0),
        Among("\u03BA", -1, 1, 0),
        Among("\u03BA\u03B1\u03C0\u03B1\u03BA", 7, 1, 0),
        Among("\u03C3\u03BF\u03BA", 7, 1, 0),
        Among("\u03C3\u03BA", 7, 1, 0),
        Among("\u03B2\u03B1\u03BB", -1, 2, 0),
        Among("\u03BC\u03B1\u03BB", -1, 1, 0),
        Among("\u03B3\u03BB", -1, 2, 0),
        Among("\u03C4\u03C1\u03B9\u03C0\u03BF\u03BB", -1, 2, 0),
        Among("\u03C0\u03BB", -1, 1, 0),
        Among("\u03BB\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03C6\u03C5\u03BB", -1, 1, 0),
        Among("\u03BA\u03B1\u03B9\u03BC", -1, 1, 0),
        Among("\u03BA\u03BB\u03B9\u03BC", -1, 1, 0),
        Among("\u03C6\u03B1\u03C1\u03BC", -1, 1, 0),
        Among("\u03B3\u03B9\u03B1\u03BD", -1, 2, 0),
        Among("\u03C3\u03C0\u03B1\u03BD", -1, 1, 0),
        Among("\u03B7\u03B3\u03BF\u03C5\u03BC\u03B5\u03BD", -1, 2, 0),
        Among("\u03BA\u03BF\u03BD", -1, 1, 0),
        Among("\u03BC\u03B1\u03BA\u03C1\u03C5\u03BD", -1, 2, 0),
        Among("\u03C0", -1, 2, 0),
        Among("\u03BA\u03B1\u03C4\u03C1\u03B1\u03C0", 26, 1, 0),
        Among("\u03C1", -1, 1, 0),
        Among("\u03B2\u03C1", 28, 1, 0),
        Among("\u03BB\u03B1\u03B2\u03C1", 29, 1, 0),
        Among("\u03B1\u03BC\u03B2\u03C1", 29, 1, 0),
        Among("\u03BC\u03B5\u03C1", 28, 1, 0),
        Among("\u03C0\u03B1\u03C4\u03B5\u03C1", 28, 2, 0),
        Among("\u03B1\u03BD\u03B8\u03C1", 28, 1, 0),
        Among("\u03BA\u03BF\u03C1", 28, 1, 0),
        Among("\u03C3", -1, 1, 0),
        Among("\u03BD\u03B1\u03B3\u03BA\u03B1\u03C3", 36, 1, 0),
        Among("\u03C4\u03BF\u03C3", 36, 2, 0),
        Among("\u03BC\u03BF\u03C5\u03C3\u03C4", -1, 1, 0),
        Among("\u03C1\u03C5", -1, 1, 0),
        Among("\u03C6", -1, 1, 0),
        Among("\u03C3\u03C6", 41, 1, 0),
        Among("\u03B1\u03BB\u03B9\u03C3\u03C6", 42, 1, 0),
        Among("\u03BD\u03C5\u03C6", 41, 2, 0),
        Among("\u03C7", -1, 1, 0)
    ];

    static final a_18 = [
        Among("\u03B1\u03BA\u03B9\u03B1", -1, 1, 0),
        Among("\u03B1\u03C1\u03B1\u03BA\u03B9\u03B1", 0, 1, 0),
        Among("\u03B9\u03C4\u03C3\u03B1", -1, 1, 0),
        Among("\u03B1\u03BA\u03B9", -1, 1, 0),
        Among("\u03B1\u03C1\u03B1\u03BA\u03B9", 3, 1, 0),
        Among("\u03B9\u03C4\u03C3\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03C4\u03C3\u03B1\u03C3", -1, 1, 0),
        Among("\u03B9\u03C4\u03C3\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_19 = [
        Among("\u03C8\u03B1\u03BB", -1, 1, 0),
        Among("\u03B1\u03B9\u03C6\u03BD", -1, 1, 0),
        Among("\u03BF\u03BB\u03BF", -1, 1, 0),
        Among("\u03B9\u03C1", -1, 1, 0)
    ];

    static final a_20 = [
        Among("\u03B5", -1, 1, 0),
        Among("\u03C0\u03B1\u03B9\u03C7\u03BD", -1, 1, 0)
    ];

    static final a_21 = [
        Among("\u03B9\u03B4\u03B9\u03B1", -1, 1, 0),
        Among("\u03B9\u03B4\u03B9\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03B4\u03B9\u03BF", -1, 1, 0)
    ];

    static final a_22 = [
        Among("\u03B9\u03B2", -1, 1, 0),
        Among("\u03B4", -1, 1, 0),
        Among("\u03C6\u03C1\u03B1\u03B3\u03BA", -1, 1, 0),
        Among("\u03BB\u03C5\u03BA", -1, 1, 0),
        Among("\u03BF\u03B2\u03B5\u03BB", -1, 1, 0),
        Among("\u03BC\u03B7\u03BD", -1, 1, 0),
        Among("\u03C1", -1, 1, 0)
    ];

    static final a_23 = [
        Among("\u03B9\u03C3\u03BA\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03BA\u03BF", -1, 1, 0),
        Among("\u03B9\u03C3\u03BA\u03BF\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03BA\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_24 = [
        Among("\u03B1\u03B4\u03C9\u03BD", -1, 1, 0),
        Among("\u03B1\u03B4\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_25 = [
        Among("\u03B3\u03B9\u03B1\u03B3\u03B9", -1, -1, 0),
        Among("\u03B8\u03B5\u03B9", -1, -1, 0),
        Among("\u03BF\u03BA", -1, -1, 0),
        Among("\u03BC\u03B1\u03BC", -1, -1, 0),
        Among("\u03BC\u03B1\u03BD", -1, -1, 0),
        Among("\u03BC\u03C0\u03B1\u03BC\u03C0", -1, -1, 0),
        Among("\u03C0\u03B5\u03B8\u03B5\u03C1", -1, -1, 0),
        Among("\u03C0\u03B1\u03C4\u03B5\u03C1", -1, -1, 0),
        Among("\u03BA\u03C5\u03C1", -1, -1, 0),
        Among("\u03BD\u03C4\u03B1\u03BD\u03C4", -1, -1, 0)
    ];

    static final a_26 = [
        Among("\u03B5\u03B4\u03C9\u03BD", -1, 1, 0),
        Among("\u03B5\u03B4\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_27 = [
        Among("\u03BC\u03B9\u03BB", -1, 1, 0),
        Among("\u03B4\u03B1\u03C0", -1, 1, 0),
        Among("\u03B3\u03B7\u03C0", -1, 1, 0),
        Among("\u03B9\u03C0", -1, 1, 0),
        Among("\u03B5\u03BC\u03C0", -1, 1, 0),
        Among("\u03BF\u03C0", -1, 1, 0),
        Among("\u03BA\u03C1\u03B1\u03C3\u03C0", -1, 1, 0),
        Among("\u03C5\u03C0", -1, 1, 0)
    ];

    static final a_28 = [
        Among("\u03BF\u03C5\u03B4\u03C9\u03BD", -1, 1, 0),
        Among("\u03BF\u03C5\u03B4\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_29 = [
        Among("\u03C4\u03C1\u03B1\u03B3", -1, 1, 0),
        Among("\u03C6\u03B5", -1, 1, 0),
        Among("\u03BA\u03B1\u03BB\u03B9\u03B1\u03BA", -1, 1, 0),
        Among("\u03B1\u03C1\u03BA", -1, 1, 0),
        Among("\u03C3\u03BA", -1, 1, 0),
        Among("\u03C0\u03B5\u03C4\u03B1\u03BB", -1, 1, 0),
        Among("\u03B2\u03B5\u03BB", -1, 1, 0),
        Among("\u03BB\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03C6\u03BB", -1, 1, 0),
        Among("\u03C7\u03BD", -1, 1, 0),
        Among("\u03C0\u03BB\u03B5\u03BE", -1, 1, 0),
        Among("\u03C3\u03C0", -1, 1, 0),
        Among("\u03C6\u03C1", -1, 1, 0),
        Among("\u03C3", -1, 1, 0),
        Among("\u03BB\u03B9\u03C7", -1, 1, 0)
    ];

    static final a_30 = [
        Among("\u03B5\u03C9\u03BD", -1, 1, 0),
        Among("\u03B5\u03C9\u03C3", -1, 1, 0)
    ];

    static final a_31 = [
        Among("\u03B4", -1, 1, 0),
        Among("\u03B9\u03B4", 0, 1, 0),
        Among("\u03B8", -1, 1, 0),
        Among("\u03B3\u03B1\u03BB", -1, 1, 0),
        Among("\u03B5\u03BB", -1, 1, 0),
        Among("\u03BD", -1, 1, 0),
        Among("\u03C0", -1, 1, 0),
        Among("\u03C0\u03B1\u03C1", -1, 1, 0)
    ];

    static final a_32 = [
        Among("\u03B9\u03B1", -1, 1, 0),
        Among("\u03B9\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_33 = [
        Among("\u03B9\u03BA\u03B1", -1, 1, 0),
        Among("\u03B9\u03BA\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03BA\u03BF", -1, 1, 0),
        Among("\u03B9\u03BA\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_34 = [
        Among("\u03B1\u03B4", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B1\u03B4", 0, 1, 0),
        Among("\u03BA\u03B1\u03C4\u03B1\u03B4", 0, 1, 0),
        Among("\u03B1\u03BD\u03C4\u03B9\u03B4", -1, 1, 0),
        Among("\u03B5\u03BD\u03B4", -1, 1, 0),
        Among("\u03C6\u03C5\u03BB\u03BF\u03B4", -1, 1, 0),
        Among("\u03C5\u03C0\u03BF\u03B4", -1, 1, 0),
        Among("\u03C0\u03C1\u03C9\u03C4\u03BF\u03B4", -1, 1, 0),
        Among("\u03B5\u03BE\u03C9\u03B4", -1, 1, 0),
        Among("\u03B7\u03B8", -1, 1, 0),
        Among("\u03B1\u03BD\u03B7\u03B8", 9, 1, 0),
        Among("\u03BE\u03B9\u03BA", -1, 1, 0),
        Among("\u03B1\u03BB", -1, 1, 0),
        Among("\u03B1\u03BC\u03BC\u03BF\u03C7\u03B1\u03BB", 12, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03BF\u03BC\u03B7\u03BB", -1, 1, 0),
        Among("\u03BC\u03C0\u03BF\u03BB", -1, 1, 0),
        Among("\u03BC\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03C4\u03C3\u03B1\u03BC", -1, 1, 0),
        Among("\u03B2\u03C1\u03C9\u03BC", -1, 1, 0),
        Among("\u03B1\u03BC\u03B1\u03BD", -1, 1, 0),
        Among("\u03BC\u03C0\u03B1\u03BD", -1, 1, 0),
        Among("\u03BA\u03B1\u03BB\u03BB\u03B9\u03BD", -1, 1, 0),
        Among("\u03C0\u03BF\u03C3\u03C4\u03B5\u03BB\u03BD", -1, 1, 0),
        Among("\u03C6\u03B9\u03BB\u03BF\u03BD", -1, 1, 0),
        Among("\u03BA\u03B1\u03BB\u03C0", -1, 1, 0),
        Among("\u03B3\u03B5\u03C1", -1, 1, 0),
        Among("\u03C7\u03B1\u03C3", -1, 1, 0),
        Among("\u03BC\u03C0\u03BF\u03C3", -1, 1, 0),
        Among("\u03C0\u03BB\u03B9\u03B1\u03C4\u03C3", -1, 1, 0),
        Among("\u03C0\u03B5\u03C4\u03C3", -1, 1, 0),
        Among("\u03C0\u03B9\u03C4\u03C3", -1, 1, 0),
        Among("\u03C6\u03C5\u03C3", -1, 1, 0),
        Among("\u03BC\u03C0\u03B1\u03B3\u03B9\u03B1\u03C4", -1, 1, 0),
        Among("\u03BD\u03B9\u03C4", -1, 1, 0),
        Among("\u03C0\u03B9\u03BA\u03B1\u03BD\u03C4", -1, 1, 0),
        Among("\u03C3\u03B5\u03C1\u03C4", -1, 1, 0)
    ];

    static final a_35 = [
        Among("\u03B1\u03B3\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03B7\u03BA\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03BC\u03B5", 1, 1, 0),
        Among("\u03B7\u03C3\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B1\u03BC\u03B5", -1, 1, 0)
    ];

    static final a_36 = [
        Among("\u03B2\u03BF\u03C5\u03B2", -1, 1, 0),
        Among("\u03BE\u03B5\u03B8", -1, 1, 0),
        Among("\u03C0\u03B5\u03B8", -1, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03B8", -1, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03BA", -1, 1, 0),
        Among("\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03B1\u03BD\u03B1\u03C0", -1, 1, 0),
        Among("\u03C0\u03B9\u03BA\u03C1", -1, 1, 0),
        Among("\u03C0\u03BF\u03C4", -1, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03C3\u03C4", -1, 1, 0),
        Among("\u03C7", -1, 1, 0),
        Among("\u03C3\u03B9\u03C7", 10, 1, 0)
    ];

    static final a_37 = [
        Among("\u03C4\u03C1", -1, 1, 0),
        Among("\u03C4\u03C3", -1, 1, 0)
    ];

    static final a_38 = [
        Among("\u03B1\u03B3\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B7\u03BA\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03BD\u03B5", 1, 1, 0),
        Among("\u03B7\u03C3\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03BF\u03BD\u03C4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03BF\u03BD\u03C4\u03B1\u03BD\u03B5", 5, 1, 0),
        Among("\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD\u03B5", 7, 1, 0),
        Among("\u03BF\u03C4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03BF\u03C4\u03B1\u03BD\u03B5", 9, 1, 0)
    ];

    static final a_39 = [
        Among("\u03C4\u03B1\u03B2", -1, 1, 0),
        Among("\u03BD\u03C4\u03B1\u03B2", 0, 1, 0),
        Among("\u03C8\u03B7\u03BB\u03BF\u03C4\u03B1\u03B2", 0, 1, 0),
        Among("\u03BB\u03B9\u03B2", -1, 1, 0),
        Among("\u03BA\u03BB\u03B9\u03B2", 3, 1, 0),
        Among("\u03BE\u03B7\u03C1\u03BF\u03BA\u03BB\u03B9\u03B2", 4, 1, 0),
        Among("\u03B3", -1, 1, 0),
        Among("\u03B1\u03B3", 6, 1, 0),
        Among("\u03C4\u03C1\u03B1\u03B3", 7, 1, 0),
        Among("\u03C4\u03C3\u03B1\u03B3", 7, 1, 0),
        Among("\u03B1\u03B8\u03B9\u03B3\u03B3", 6, 1, 0),
        Among("\u03C4\u03C3\u03B9\u03B3\u03B3", 6, 1, 0),
        Among("\u03B1\u03C4\u03C3\u03B9\u03B3\u03B3", 11, 1, 0),
        Among("\u03C3\u03C4\u03B5\u03B3", 6, 1, 0),
        Among("\u03B1\u03C0\u03B7\u03B3", 6, 1, 0),
        Among("\u03C3\u03B9\u03B3", 6, 1, 0),
        Among("\u03B1\u03BD\u03BF\u03C1\u03B3", 6, 1, 0),
        Among("\u03B5\u03BD\u03BF\u03C1\u03B3", 6, 1, 0),
        Among("\u03BA\u03B1\u03BB\u03C0\u03BF\u03C5\u03B6", -1, 1, 0),
        Among("\u03B8", -1, 1, 0),
        Among("\u03BC\u03C9\u03B1\u03BC\u03B5\u03B8", 19, 1, 0),
        Among("\u03C0\u03B9\u03B8", 19, 1, 0),
        Among("\u03B1\u03C0\u03B9\u03B8", 21, 1, 0),
        Among("\u03B4\u03B5\u03BA", -1, 1, 0),
        Among("\u03C0\u03B5\u03BB\u03B5\u03BA", -1, 1, 0),
        Among("\u03B9\u03BA", -1, 1, 0),
        Among("\u03B1\u03BD\u03B9\u03BA", 25, 1, 0),
        Among("\u03B2\u03BF\u03C5\u03BB\u03BA", -1, 1, 0),
        Among("\u03B2\u03B1\u03C3\u03BA", -1, 1, 0),
        Among("\u03B2\u03C1\u03B1\u03C7\u03C5\u03BA", -1, 1, 0),
        Among("\u03B3\u03B1\u03BB", -1, 1, 0),
        Among("\u03BA\u03B1\u03C4\u03B1\u03B3\u03B1\u03BB", 30, 1, 0),
        Among("\u03BF\u03BB\u03BF\u03B3\u03B1\u03BB", 30, 1, 0),
        Among("\u03B2\u03B1\u03B8\u03C5\u03B3\u03B1\u03BB", 30, 1, 0),
        Among("\u03BC\u03B5\u03BB", -1, 1, 0),
        Among("\u03BA\u03B1\u03C3\u03C4\u03B5\u03BB", -1, 1, 0),
        Among("\u03C0\u03BF\u03C1\u03C4\u03BF\u03BB", -1, 1, 0),
        Among("\u03C0\u03BB", -1, 1, 0),
        Among("\u03B4\u03B9\u03C0\u03BB", 37, 1, 0),
        Among("\u03BB\u03B1\u03BF\u03C0\u03BB", 37, 1, 0),
        Among("\u03C8\u03C5\u03C7\u03BF\u03C0\u03BB", 37, 1, 0),
        Among("\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03BC", -1, 1, 0),
        Among("\u03BF\u03BB\u03B9\u03B3\u03BF\u03B4\u03B1\u03BC", 42, 1, 0),
        Among("\u03BC\u03BF\u03C5\u03C3\u03BF\u03C5\u03BB\u03BC", 42, 1, 0),
        Among("\u03B4\u03C1\u03B1\u03B4\u03BF\u03C5\u03BC", 42, 1, 0),
        Among("\u03B2\u03C1\u03B1\u03C7\u03BC", 42, 1, 0),
        Among("\u03BD", -1, 1, 0),
        Among("\u03B1\u03BC\u03B5\u03C1\u03B9\u03BA\u03B1\u03BD", 47, 1, 0),
        Among("\u03C0", -1, 1, 0),
        Among("\u03B1\u03B4\u03B1\u03C0", 49, 1, 0),
        Among("\u03C7\u03B1\u03BC\u03B7\u03BB\u03BF\u03B4\u03B1\u03C0", 49, 1, 0),
        Among("\u03C0\u03BF\u03BB\u03C5\u03B4\u03B1\u03C0", 49, 1, 0),
        Among("\u03BA\u03BF\u03C0", 49, 1, 0),
        Among("\u03C5\u03C0\u03BF\u03BA\u03BF\u03C0", 53, 1, 0),
        Among("\u03C4\u03C3\u03BF\u03C0", 49, 1, 0),
        Among("\u03C3\u03C0", 49, 1, 0),
        Among("\u03B5\u03C1", -1, 1, 0),
        Among("\u03B3\u03B5\u03C1", 57, 1, 0),
        Among("\u03B2\u03B5\u03C4\u03B5\u03C1", 57, 1, 0),
        Among("\u03BB\u03BF\u03C5\u03B8\u03B7\u03C1", -1, 1, 0),
        Among("\u03BA\u03BF\u03C1\u03BC\u03BF\u03C1", -1, 1, 0),
        Among("\u03C0\u03B5\u03C1\u03B9\u03C4\u03C1", -1, 1, 0),
        Among("\u03BF\u03C5\u03C1", -1, 1, 0),
        Among("\u03C3", -1, 1, 0),
        Among("\u03B2\u03B1\u03C3", 64, 1, 0),
        Among("\u03C0\u03BF\u03BB\u03B9\u03C3", 64, 1, 0),
        Among("\u03C3\u03B1\u03C1\u03B1\u03BA\u03B1\u03C4\u03C3", 64, 1, 0),
        Among("\u03B8\u03C5\u03C3", 64, 1, 0),
        Among("\u03B4\u03B9\u03B1\u03C4", -1, 1, 0),
        Among("\u03C0\u03BB\u03B1\u03C4", -1, 1, 0),
        Among("\u03C4\u03C3\u03B1\u03C1\u03BB\u03B1\u03C4", -1, 1, 0),
        Among("\u03C4\u03B5\u03C4", -1, 1, 0),
        Among("\u03C0\u03BF\u03C5\u03C1\u03B9\u03C4", -1, 1, 0),
        Among("\u03C3\u03BF\u03C5\u03BB\u03C4", -1, 1, 0),
        Among("\u03BC\u03B1\u03B9\u03BD\u03C4", -1, 1, 0),
        Among("\u03B6\u03C9\u03BD\u03C4", -1, 1, 0),
        Among("\u03BA\u03B1\u03C3\u03C4", -1, 1, 0),
        Among("\u03C6", -1, 1, 0),
        Among("\u03B4\u03B9\u03B1\u03C6", 78, 1, 0),
        Among("\u03C3\u03C4\u03B5\u03C6", 78, 1, 0),
        Among("\u03C6\u03C9\u03C4\u03BF\u03C3\u03C4\u03B5\u03C6", 80, 1, 0),
        Among("\u03C0\u03B5\u03C1\u03B7\u03C6", 78, 1, 0),
        Among("\u03C5\u03C0\u03B5\u03C1\u03B7\u03C6", 82, 1, 0),
        Among("\u03BA\u03BF\u03B9\u03BB\u03B1\u03C1\u03C6", 78, 1, 0),
        Among("\u03C0\u03B5\u03BD\u03C4\u03B1\u03C1\u03C6", 78, 1, 0),
        Among("\u03BF\u03C1\u03C6", 78, 1, 0),
        Among("\u03C7", -1, 1, 0),
        Among("\u03B1\u03BC\u03B7\u03C7", 87, 1, 0),
        Among("\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 87, 1, 0),
        Among("\u03BC\u03B5\u03B3\u03BB\u03BF\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 89, 1, 0),
        Among("\u03BA\u03B1\u03C0\u03BD\u03BF\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 89, 1, 0),
        Among("\u03BC\u03B9\u03BA\u03C1\u03BF\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 89, 1, 0),
        Among("\u03C0\u03BF\u03BB\u03C5\u03BC\u03B7\u03C7", 87, 1, 0),
        Among("\u03BB\u03B9\u03C7", 87, 1, 0)
    ];

    static final a_40 = [
        Among("\u03B5\u03BD\u03B4", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B4", -1, 1, 0),
        Among("\u03BF\u03B4", -1, 1, 0),
        Among("\u03B4\u03B9\u03B1\u03B8", -1, 1, 0),
        Among("\u03BA\u03B1\u03B8", -1, 1, 0),
        Among("\u03C1\u03B1\u03B8", -1, 1, 0),
        Among("\u03C4\u03B1\u03B8", -1, 1, 0),
        Among("\u03C4\u03B9\u03B8", -1, 1, 0),
        Among("\u03B5\u03BA\u03B8", -1, 1, 0),
        Among("\u03B5\u03BD\u03B8", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B8", -1, 1, 0),
        Among("\u03C1\u03BF\u03B8", -1, 1, 0),
        Among("\u03C5\u03C0\u03B5\u03C1\u03B8", -1, 1, 0),
        Among("\u03C3\u03B8", -1, 1, 0),
        Among("\u03B5\u03C5\u03B8", -1, 1, 0),
        Among("\u03B1\u03C1\u03BA", -1, 1, 0),
        Among("\u03C9\u03C6\u03B5\u03BB", -1, 1, 0),
        Among("\u03B2\u03BF\u03BB", -1, 1, 0),
        Among("\u03B1\u03B9\u03BD", -1, 1, 0),
        Among("\u03C0\u03BF\u03BD", -1, 1, 0),
        Among("\u03C1\u03BF\u03BD", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD", -1, 1, 0),
        Among("\u03B2\u03B1\u03C1", -1, 1, 0),
        Among("\u03B2\u03C1", -1, 1, 0),
        Among("\u03B1\u03B9\u03C1", -1, 1, 0),
        Among("\u03C6\u03BF\u03C1", -1, 1, 0),
        Among("\u03B5\u03C5\u03C1", -1, 1, 0),
        Among("\u03C0\u03C5\u03C1", -1, 1, 0),
        Among("\u03C7\u03C9\u03C1", -1, 1, 0),
        Among("\u03BD\u03B5\u03C4", -1, 1, 0),
        Among("\u03C3\u03C7", -1, 1, 0)
    ];

    static final a_41 = [
        Among("\u03C0\u03B1\u03B3", -1, 1, 0),
        Among("\u03B4", -1, 1, 0),
        Among("\u03B1\u03B4", 1, 1, 0),
        Among("\u03B8", -1, 1, 0),
        Among("\u03B1\u03B8", 3, 1, 0),
        Among("\u03C4\u03BF\u03BA", -1, 1, 0),
        Among("\u03C3\u03BA", -1, 1, 0),
        Among("\u03C0\u03B1\u03C1\u03B1\u03BA\u03B1\u03BB", -1, 1, 0),
        Among("\u03C3\u03BA\u03B5\u03BB", -1, 1, 0),
        Among("\u03B1\u03C0\u03BB", -1, 1, 0),
        Among("\u03B5\u03BC", -1, 1, 0),
        Among("\u03B1\u03BD", -1, 1, 0),
        Among("\u03B2\u03B5\u03BD", -1, 1, 0),
        Among("\u03B2\u03B1\u03C1\u03BF\u03BD", -1, 1, 0),
        Among("\u03BA\u03BF\u03C0", -1, 1, 0),
        Among("\u03C3\u03B5\u03C1\u03C0", -1, 1, 0),
        Among("\u03B1\u03B2\u03B1\u03C1", -1, 1, 0),
        Among("\u03B5\u03BD\u03B1\u03C1", -1, 1, 0),
        Among("\u03B1\u03B2\u03C1", -1, 1, 0),
        Among("\u03BC\u03C0\u03BF\u03C1", -1, 1, 0),
        Among("\u03B8\u03B1\u03C1\u03C1", -1, 1, 0),
        Among("\u03BD\u03C4\u03C1", -1, 1, 0),
        Among("\u03C5", -1, 1, 0),
        Among("\u03BD\u03B9\u03C6", -1, 1, 0),
        Among("\u03C3\u03C5\u03C1\u03C6", -1, 1, 0)
    ];

    static final a_42 = [
        Among("\u03BF\u03BD\u03C4\u03B1\u03C3", -1, 1, 0),
        Among("\u03C9\u03BD\u03C4\u03B1\u03C3", -1, 1, 0)
    ];

    static final a_43 = [
        Among("\u03BF\u03BC\u03B1\u03C3\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03BF\u03BC\u03B1\u03C3\u03C4\u03B5", 0, 1, 0)
    ];

    static final a_44 = [
        Among("\u03C0", -1, 1, 0),
        Among("\u03B1\u03C0", 0, 1, 0),
        Among("\u03B1\u03BA\u03B1\u03C4\u03B1\u03C0", 1, 1, 0),
        Among("\u03C3\u03C5\u03BC\u03C0", 0, 1, 0),
        Among("\u03B1\u03C3\u03C5\u03BC\u03C0", 3, 1, 0),
        Among("\u03B1\u03BC\u03B5\u03C4\u03B1\u03BC\u03C6", -1, 1, 0)
    ];

    static final a_45 = [
        Among("\u03B6", -1, 1, 0),
        Among("\u03B1\u03BB", -1, 1, 0),
        Among("\u03C0\u03B1\u03C1\u03B1\u03BA\u03B1\u03BB", 1, 1, 0),
        Among("\u03B5\u03BA\u03C4\u03B5\u03BB", -1, 1, 0),
        Among("\u03BC", -1, 1, 0),
        Among("\u03BE", -1, 1, 0),
        Among("\u03C0\u03C1\u03BF", -1, 1, 0),
        Among("\u03B1\u03C1", -1, 1, 0),
        Among("\u03BD\u03B9\u03C3", -1, 1, 0)
    ];

    static final a_46 = [
        Among("\u03B7\u03B8\u03B7\u03BA\u03B1", -1, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B5", -1, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_47 = [
        Among("\u03C0\u03B9\u03B8", -1, 1, 0),
        Among("\u03BF\u03B8", -1, 1, 0),
        Among("\u03BD\u03B1\u03C1\u03B8", -1, 1, 0),
        Among("\u03C3\u03BA\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03C3\u03BA\u03C9\u03BB", -1, 1, 0),
        Among("\u03C3\u03C6", -1, 1, 0)
    ];

    static final a_48 = [
        Among("\u03B8", -1, 1, 0),
        Among("\u03B4\u03B9\u03B1\u03B8", 0, 1, 0),
        Among("\u03C0\u03B1\u03C1\u03B1\u03BA\u03B1\u03C4\u03B1\u03B8", 0, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B8", 0, 1, 0),
        Among("\u03C0\u03C1\u03BF\u03C3\u03B8", 0, 1, 0)
    ];

    static final a_49 = [
        Among("\u03B7\u03BA\u03B1", -1, 1, 0),
        Among("\u03B7\u03BA\u03B5", -1, 1, 0),
        Among("\u03B7\u03BA\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_50 = [
        Among("\u03C6\u03B1\u03B3", -1, 1, 0),
        Among("\u03BB\u03B7\u03B3", -1, 1, 0),
        Among("\u03C6\u03C1\u03C5\u03B4", -1, 1, 0),
        Among("\u03BC\u03B1\u03BD\u03C4\u03B9\u03BB", -1, 1, 0),
        Among("\u03BC\u03B1\u03BB\u03BB", -1, 1, 0),
        Among("\u03BF\u03BC", -1, 1, 0),
        Among("\u03B2\u03BB\u03B5\u03C0", -1, 1, 0),
        Among("\u03C0\u03BF\u03B4\u03B1\u03C1", -1, 1, 0),
        Among("\u03BA\u03C5\u03BC\u03B1\u03C4", -1, 1, 0),
        Among("\u03C0\u03C1\u03C9\u03C4", -1, 1, 0),
        Among("\u03BB\u03B1\u03C7", -1, 1, 0),
        Among("\u03C0\u03B1\u03BD\u03C4\u03B1\u03C7", -1, 1, 0)
    ];

    static final a_51 = [
        Among("\u03C4\u03C3\u03B1", -1, 1, 0),
        Among("\u03C7\u03B1\u03B4", -1, 1, 0),
        Among("\u03BC\u03B5\u03B4", -1, 1, 0),
        Among("\u03BB\u03B1\u03BC\u03C0\u03B9\u03B4", -1, 1, 0),
        Among("\u03B4\u03B5", -1, 1, 0),
        Among("\u03C0\u03BB\u03B5", -1, 1, 0),
        Among("\u03BC\u03B5\u03C3\u03B1\u03B6", -1, 1, 0),
        Among("\u03B4\u03B5\u03C3\u03C0\u03BF\u03B6", -1, 1, 0),
        Among("\u03B1\u03B9\u03B8", -1, 1, 0),
        Among("\u03C6\u03B1\u03C1\u03BC\u03B1\u03BA", -1, 1, 0),
        Among("\u03B1\u03B3\u03BA", -1, 1, 0),
        Among("\u03B1\u03BD\u03B7\u03BA", -1, 1, 0),
        Among("\u03BB", -1, 1, 0),
        Among("\u03BC", -1, 1, 0),
        Among("\u03B1\u03BC", 13, 1, 0),
        Among("\u03B2\u03C1\u03BF\u03BC", 13, 1, 0),
        Among("\u03C5\u03C0\u03BF\u03C4\u03B5\u03B9\u03BD", -1, 1, 0),
        Among("\u03B5\u03BA\u03BB\u03B9\u03C0", -1, 1, 0),
        Among("\u03C1", -1, 1, 0),
        Among("\u03B5\u03BD\u03B4\u03B9\u03B1\u03C6\u03B5\u03C1", 18, 1, 0),
        Among("\u03B1\u03BD\u03B1\u03C1\u03C1", 18, 1, 0),
        Among("\u03C0\u03B1\u03C4", -1, 1, 0),
        Among("\u03BA\u03B1\u03B8\u03B1\u03C1\u03B5\u03C5", -1, 1, 0),
        Among("\u03B4\u03B5\u03C5\u03C4\u03B5\u03C1\u03B5\u03C5", -1, 1, 0),
        Among("\u03BB\u03B5\u03C7", -1, 1, 0)
    ];

    static final a_52 = [
        Among("\u03BF\u03C5\u03C3\u03B1", -1, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B5", -1, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_53 = [
        Among("\u03C0\u03B5\u03BB", -1, 1, 0),
        Among("\u03BB\u03BB", -1, 1, 0),
        Among("\u03C3\u03BC\u03B7\u03BD", -1, 1, 0),
        Among("\u03C1\u03C0", -1, 1, 0),
        Among("\u03C0\u03C1", -1, 1, 0),
        Among("\u03C6\u03C1", -1, 1, 0),
        Among("\u03C7\u03BF\u03C1\u03C4", -1, 1, 0),
        Among("\u03BF\u03C6", -1, 1, 0),
        Among("\u03C8\u03BF\u03C6", 7, -1, 0),
        Among("\u03C3\u03C6", -1, 1, 0),
        Among("\u03BB\u03BF\u03C7", -1, 1, 0),
        Among("\u03BD\u03B1\u03C5\u03BB\u03BF\u03C7", 10, -1, 0)
    ];

    static final a_54 = [
        Among("\u03B1\u03BC\u03B1\u03BB\u03BB\u03B9", -1, 1, 0),
        Among("\u03BB", -1, 1, 0),
        Among("\u03B1\u03BC\u03B1\u03BB", 1, 1, 0),
        Among("\u03BC", -1, 1, 0),
        Among("\u03BF\u03C5\u03BB\u03B1\u03BC", 3, 1, 0),
        Among("\u03B5\u03BD", -1, 1, 0),
        Among("\u03B4\u03B5\u03C1\u03B2\u03B5\u03BD", 5, 1, 0),
        Among("\u03C0", -1, 1, 0),
        Among("\u03B1\u03B5\u03B9\u03C0", 7, 1, 0),
        Among("\u03B1\u03C1\u03C4\u03B9\u03C0", 7, 1, 0),
        Among("\u03C3\u03C5\u03BC\u03C0", 7, 1, 0),
        Among("\u03BD\u03B5\u03BF\u03C0", 7, 1, 0),
        Among("\u03BA\u03C1\u03BF\u03BA\u03B1\u03BB\u03BF\u03C0", 7, 1, 0),
        Among("\u03BF\u03BB\u03BF\u03C0", 7, 1, 0),
        Among("\u03C0\u03C1\u03BF\u03C3\u03C9\u03C0\u03BF\u03C0", 7, 1, 0),
        Among("\u03C3\u03B9\u03B4\u03B7\u03C1\u03BF\u03C0", 7, 1, 0),
        Among("\u03B4\u03C1\u03BF\u03C3\u03BF\u03C0", 7, 1, 0),
        Among("\u03B1\u03C3\u03C0", 7, 1, 0),
        Among("\u03B1\u03BD\u03C5\u03C0", 7, 1, 0),
        Among("\u03C1", -1, 1, 0),
        Among("\u03B1\u03C3\u03C0\u03B1\u03C1", 19, 1, 0),
        Among("\u03C7\u03B1\u03C1", 19, 1, 0),
        Among("\u03B1\u03C7\u03B1\u03C1", 21, 1, 0),
        Among("\u03B1\u03C0\u03B5\u03C1", 19, 1, 0),
        Among("\u03C4\u03C1", 19, 1, 0),
        Among("\u03BF\u03C5\u03C1", 19, 1, 0),
        Among("\u03C4", -1, 1, 0),
        Among("\u03B4\u03B9\u03B1\u03C4", 26, 1, 0),
        Among("\u03B5\u03C0\u03B9\u03C4", 26, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03C4", 26, 1, 0),
        Among("\u03BF\u03BC\u03BF\u03C4", 26, 1, 0),
        Among("\u03BD\u03BF\u03BC\u03BF\u03C4", 30, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03C4", 26, 1, 0),
        Among("\u03C5\u03C0\u03BF\u03C4", 26, 1, 0),
        Among("\u03B1\u03B2\u03B1\u03C3\u03C4", 26, 1, 0),
        Among("\u03B1\u03B9\u03BC\u03BF\u03C3\u03C4", 26, 1, 0),
        Among("\u03C0\u03C1\u03BF\u03C3\u03C4", 26, 1, 0),
        Among("\u03B1\u03BD\u03C5\u03C3\u03C4", 26, 1, 0),
        Among("\u03BD\u03B1\u03C5", -1, 1, 0),
        Among("\u03B1\u03C6", -1, 1, 0),
        Among("\u03BE\u03B5\u03C6", -1, 1, 0),
        Among("\u03B1\u03B4\u03B7\u03C6", -1, 1, 0),
        Among("\u03C0\u03B1\u03BC\u03C6", -1, 1, 0),
        Among("\u03C0\u03BF\u03BB\u03C5\u03C6", -1, 1, 0)
    ];

    static final a_55 = [
        Among("\u03B1\u03B3\u03B1", -1, 1, 0),
        Among("\u03B1\u03B3\u03B5", -1, 1, 0),
        Among("\u03B1\u03B3\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_56 = [
        Among("\u03B7\u03C3\u03B1", -1, 1, 0),
        Among("\u03B7\u03C3\u03B5", -1, 1, 0),
        Among("\u03B7\u03C3\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_57 = [
        Among("\u03BD", -1, 1, 0),
        Among("\u03B4\u03C9\u03B4\u03B5\u03BA\u03B1\u03BD", 0, 1, 0),
        Among("\u03B5\u03C0\u03C4\u03B1\u03BD", 0, 1, 0),
        Among("\u03BC\u03B5\u03B3\u03B1\u03BB\u03BF\u03BD", 0, 1, 0),
        Among("\u03B5\u03C1\u03B7\u03BC\u03BF\u03BD", 0, 1, 0),
        Among("\u03C7\u03B5\u03C1\u03C3\u03BF\u03BD", 0, 1, 0)
    ];

    static final a_58 = [
        Among("\u03C3\u03B2", -1, 1, 0),
        Among("\u03B1\u03C3\u03B2", 0, 1, 0),
        Among("\u03B1\u03C0\u03BB", -1, 1, 0),
        Among("\u03B1\u03B5\u03B9\u03BC\u03BD", -1, 1, 0),
        Among("\u03C7\u03C1", -1, 1, 0),
        Among("\u03B1\u03C7\u03C1", 4, 1, 0),
        Among("\u03BA\u03BF\u03B9\u03BD\u03BF\u03C7\u03C1", 4, 1, 0),
        Among("\u03B4\u03C5\u03C3\u03C7\u03C1", 4, 1, 0),
        Among("\u03B5\u03C5\u03C7\u03C1", 4, 1, 0),
        Among("\u03C0\u03B1\u03BB\u03B9\u03BC\u03C8", -1, 1, 0)
    ];

    static final a_59 = [
        Among("\u03BF\u03C5\u03BD\u03B5", -1, 1, 0),
        Among("\u03B7\u03B8\u03BF\u03C5\u03BD\u03B5", 0, 1, 0),
        Among("\u03B7\u03C3\u03BF\u03C5\u03BD\u03B5", 0, 1, 0)
    ];

    static final a_60 = [
        Among("\u03C3\u03C0\u03B9", -1, 1, 0),
        Among("\u03BD", -1, 1, 0),
        Among("\u03B5\u03BE\u03C9\u03BD", 1, 1, 0),
        Among("\u03C1", -1, 1, 0),
        Among("\u03C3\u03C4\u03C1\u03B1\u03B2\u03BF\u03BC\u03BF\u03C5\u03C4\u03C3", -1, 1, 0),
        Among("\u03BA\u03B1\u03BA\u03BF\u03BC\u03BF\u03C5\u03C4\u03C3", -1, 1, 0)
    ];

    static final a_61 = [
        Among("\u03BF\u03C5\u03BC\u03B5", -1, 1, 0),
        Among("\u03B7\u03B8\u03BF\u03C5\u03BC\u03B5", 0, 1, 0),
        Among("\u03B7\u03C3\u03BF\u03C5\u03BC\u03B5", 0, 1, 0)
    ];

    static final a_62 = [
        Among("\u03B1\u03B6", -1, 1, 0),
        Among("\u03C9\u03C1\u03B9\u03BF\u03C0\u03BB", -1, 1, 0),
        Among("\u03B1\u03C3\u03BF\u03C5\u03C3", -1, 1, 0),
        Among("\u03C0\u03B1\u03C1\u03B1\u03C3\u03BF\u03C5\u03C3", 2, 1, 0),
        Among("\u03B1\u03BB\u03BB\u03BF\u03C3\u03BF\u03C5\u03C3", -1, 1, 0),
        Among("\u03C6", -1, 1, 0),
        Among("\u03C7", -1, 1, 0)
    ];

    static final a_63 = [
        Among("\u03BC\u03B1\u03C4\u03B1", -1, 1, 0),
        Among("\u03BC\u03B1\u03C4\u03C9\u03BD", -1, 1, 0),
        Among("\u03BC\u03B1\u03C4\u03BF\u03C3", -1, 1, 0)
    ];

    static final a_64 = [
        Among("\u03B1", -1, 1, 0),
        Among("\u03B9\u03BF\u03C5\u03BC\u03B1", 0, 1, 0),
        Among("\u03BF\u03BC\u03BF\u03C5\u03BD\u03B1", 0, 1, 0),
        Among("\u03B9\u03BF\u03BC\u03BF\u03C5\u03BD\u03B1", 2, 1, 0),
        Among("\u03BF\u03C3\u03BF\u03C5\u03BD\u03B1", 0, 1, 0),
        Among("\u03B9\u03BF\u03C3\u03BF\u03C5\u03BD\u03B1", 4, 1, 0),
        Among("\u03B5", -1, 1, 0),
        Among("\u03B1\u03B3\u03B1\u03C4\u03B5", 6, 1, 0),
        Among("\u03B7\u03BA\u03B1\u03C4\u03B5", 6, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03C4\u03B5", 8, 1, 0),
        Among("\u03B7\u03C3\u03B1\u03C4\u03B5", 6, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B1\u03C4\u03B5", 6, 1, 0),
        Among("\u03B5\u03B9\u03C4\u03B5", 6, 1, 0),
        Among("\u03B7\u03B8\u03B5\u03B9\u03C4\u03B5", 12, 1, 0),
        Among("\u03B9\u03B5\u03BC\u03B1\u03C3\u03C4\u03B5", 6, 1, 0),
        Among("\u03BF\u03C5\u03BC\u03B1\u03C3\u03C4\u03B5", 6, 1, 0),
        Among("\u03B9\u03BF\u03C5\u03BC\u03B1\u03C3\u03C4\u03B5", 15, 1, 0),
        Among("\u03B9\u03B5\u03C3\u03B1\u03C3\u03C4\u03B5", 6, 1, 0),
        Among("\u03BF\u03C3\u03B1\u03C3\u03C4\u03B5", 6, 1, 0),
        Among("\u03B9\u03BF\u03C3\u03B1\u03C3\u03C4\u03B5", 18, 1, 0),
        Among("\u03B7", -1, 1, 0),
        Among("\u03B9", -1, 1, 0),
        Among("\u03B1\u03BC\u03B1\u03B9", 21, 1, 0),
        Among("\u03B9\u03B5\u03BC\u03B1\u03B9", 21, 1, 0),
        Among("\u03BF\u03BC\u03B1\u03B9", 21, 1, 0),
        Among("\u03BF\u03C5\u03BC\u03B1\u03B9", 21, 1, 0),
        Among("\u03B1\u03C3\u03B1\u03B9", 21, 1, 0),
        Among("\u03B5\u03C3\u03B1\u03B9", 21, 1, 0),
        Among("\u03B9\u03B5\u03C3\u03B1\u03B9", 27, 1, 0),
        Among("\u03B1\u03C4\u03B1\u03B9", 21, 1, 0),
        Among("\u03B5\u03C4\u03B1\u03B9", 21, 1, 0),
        Among("\u03B9\u03B5\u03C4\u03B1\u03B9", 30, 1, 0),
        Among("\u03BF\u03BD\u03C4\u03B1\u03B9", 21, 1, 0),
        Among("\u03BF\u03C5\u03BD\u03C4\u03B1\u03B9", 21, 1, 0),
        Among("\u03B9\u03BF\u03C5\u03BD\u03C4\u03B1\u03B9", 33, 1, 0),
        Among("\u03B5\u03B9", 21, 1, 0),
        Among("\u03B1\u03B5\u03B9", 35, 1, 0),
        Among("\u03B7\u03B8\u03B5\u03B9", 35, 1, 0),
        Among("\u03B7\u03C3\u03B5\u03B9", 35, 1, 0),
        Among("\u03BF\u03B9", 21, 1, 0),
        Among("\u03B1\u03BD", -1, 1, 0),
        Among("\u03B1\u03B3\u03B1\u03BD", 40, 1, 0),
        Among("\u03B7\u03BA\u03B1\u03BD", 40, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03BD", 42, 1, 0),
        Among("\u03B7\u03C3\u03B1\u03BD", 40, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B1\u03BD", 40, 1, 0),
        Among("\u03BF\u03BD\u03C4\u03BF\u03C5\u03C3\u03B1\u03BD", 45, 1, 0),
        Among("\u03B9\u03BF\u03BD\u03C4\u03BF\u03C5\u03C3\u03B1\u03BD", 46, 1, 0),
        Among("\u03BF\u03BD\u03C4\u03B1\u03BD", 40, 1, 0),
        Among("\u03B9\u03BF\u03BD\u03C4\u03B1\u03BD", 48, 1, 0),
        Among("\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD", 40, 1, 0),
        Among("\u03B9\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD", 50, 1, 0),
        Among("\u03BF\u03C4\u03B1\u03BD", 40, 1, 0),
        Among("\u03B9\u03BF\u03C4\u03B1\u03BD", 52, 1, 0),
        Among("\u03BF\u03BC\u03B1\u03C3\u03C4\u03B1\u03BD", 40, 1, 0),
        Among("\u03B9\u03BF\u03BC\u03B1\u03C3\u03C4\u03B1\u03BD", 54, 1, 0),
        Among("\u03BF\u03C3\u03B1\u03C3\u03C4\u03B1\u03BD", 40, 1, 0),
        Among("\u03B9\u03BF\u03C3\u03B1\u03C3\u03C4\u03B1\u03BD", 56, 1, 0),
        Among("\u03BF\u03C5\u03BD", -1, 1, 0),
        Among("\u03B7\u03B8\u03BF\u03C5\u03BD", 58, 1, 0),
        Among("\u03BF\u03BC\u03BF\u03C5\u03BD", 58, 1, 0),
        Among("\u03B9\u03BF\u03BC\u03BF\u03C5\u03BD", 60, 1, 0),
        Among("\u03B7\u03C3\u03BF\u03C5\u03BD", 58, 1, 0),
        Among("\u03BF\u03C3\u03BF\u03C5\u03BD", 58, 1, 0),
        Among("\u03B9\u03BF\u03C3\u03BF\u03C5\u03BD", 63, 1, 0),
        Among("\u03C9\u03BD", -1, 1, 0),
        Among("\u03B7\u03B4\u03C9\u03BD", 65, 1, 0),
        Among("\u03BF", -1, 1, 0),
        Among("\u03B1\u03C3", -1, 1, 0),
        Among("\u03B5\u03C3", -1, 1, 0),
        Among("\u03B7\u03B4\u03B5\u03C3", 69, 1, 0),
        Among("\u03B7\u03C3\u03B5\u03C3", 69, 1, 0),
        Among("\u03B7\u03C3", -1, 1, 0),
        Among("\u03B5\u03B9\u03C3", -1, 1, 0),
        Among("\u03B7\u03B8\u03B5\u03B9\u03C3", 73, 1, 0),
        Among("\u03BF\u03C3", -1, 1, 0),
        Among("\u03C5\u03C3", -1, 1, 0),
        Among("\u03BF\u03C5\u03C3", 76, 1, 0),
        Among("\u03C5", -1, 1, 0),
        Among("\u03BF\u03C5", 78, 1, 0),
        Among("\u03C9", -1, 1, 0),
        Among("\u03B1\u03C9", 80, 1, 0),
        Among("\u03B7\u03B8\u03C9", 80, 1, 0),
        Among("\u03B7\u03C3\u03C9", 80, 1, 0)
    ];

    static final a_65 = [
        Among("\u03BF\u03C4\u03B5\u03C1", -1, 1, 0),
        Among("\u03B5\u03C3\u03C4\u03B5\u03C1", -1, 1, 0),
        Among("\u03C5\u03C4\u03B5\u03C1", -1, 1, 0),
        Among("\u03C9\u03C4\u03B5\u03C1", -1, 1, 0),
        Among("\u03BF\u03C4\u03B1\u03C4", -1, 1, 0),
        Among("\u03B5\u03C3\u03C4\u03B1\u03C4", -1, 1, 0),
        Among("\u03C5\u03C4\u03B1\u03C4", -1, 1, 0),
        Among("\u03C9\u03C4\u03B1\u03C4", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([81, 65, 16, 1]);

    static final g_v2 = String.fromCharCodes([81, 65, 0, 1]);

    bool B_test1 = false;


    bool r_tolower() {
        int among_var;
        replab0: while(true)
        {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                among_var = find_among_b(a_0, null);
                bra = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("\u03B1");
                        break;
                    case 2:
                        slice_from("\u03B2");
                        break;
                    case 3:
                        slice_from("\u03B3");
                        break;
                    case 4:
                        slice_from("\u03B4");
                        break;
                    case 5:
                        slice_from("\u03B5");
                        break;
                    case 6:
                        slice_from("\u03B6");
                        break;
                    case 7:
                        slice_from("\u03B7");
                        break;
                    case 8:
                        slice_from("\u03B8");
                        break;
                    case 9:
                        slice_from("\u03B9");
                        break;
                    case 10:
                        slice_from("\u03BA");
                        break;
                    case 11:
                        slice_from("\u03BB");
                        break;
                    case 12:
                        slice_from("\u03BC");
                        break;
                    case 13:
                        slice_from("\u03BD");
                        break;
                    case 14:
                        slice_from("\u03BE");
                        break;
                    case 15:
                        slice_from("\u03BF");
                        break;
                    case 16:
                        slice_from("\u03C0");
                        break;
                    case 17:
                        slice_from("\u03C1");
                        break;
                    case 18:
                        slice_from("\u03C3");
                        break;
                    case 19:
                        slice_from("\u03C4");
                        break;
                    case 20:
                        slice_from("\u03C5");
                        break;
                    case 21:
                        slice_from("\u03C6");
                        break;
                    case 22:
                        slice_from("\u03C7");
                        break;
                    case 23:
                        slice_from("\u03C8");
                        break;
                    case 24:
                        slice_from("\u03C9");
                        break;
                    case 25:
                        if (cursor <= limit_backward)
                        {
                            break lab1;
                        }
                        cursor--;
                        break;
                }
                continue replab0;
            }
            cursor = limit - v_1;
            break replab0;
        }
        return true;
    }

    bool r_step_1() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_1, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("\u03C6\u03B1");
                break;
            case 2:
                slice_from("\u03C3\u03BA\u03B1");
                break;
            case 3:
                slice_from("\u03BF\u03BB\u03BF");
                break;
            case 4:
                slice_from("\u03C3\u03BF");
                break;
            case 5:
                slice_from("\u03C4\u03B1\u03C4\u03BF");
                break;
            case 6:
                slice_from("\u03BA\u03C1\u03B5");
                break;
            case 7:
                slice_from("\u03C0\u03B5\u03C1");
                break;
            case 8:
                slice_from("\u03C4\u03B5\u03C1");
                break;
            case 9:
                slice_from("\u03C6\u03C9");
                break;
            case 10:
                slice_from("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4");
                break;
            case 11:
                slice_from("\u03B3\u03B5\u03B3\u03BF\u03BD");
                break;
        }
        B_test1 = false;
        return true;
    }

    bool r_step_s1() {
        int among_var;
        ket = cursor;
        if (find_among_b(a_3, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("\u03B9");
                break;
            case 2:
                slice_from("\u03B9\u03B6");
                break;
        }
        return true;
    }

    bool r_step_s2() {
        ket = cursor;
        if (find_among_b(a_5, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_4, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03C9\u03BD");
        return true;
    }

    bool r_step_s3() {
        int among_var;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                if (!(eq_s_b("\u03B9\u03C3\u03B1")))
                {
                    break lab1;
                }
                bra = cursor;
                if (cursor > limit_backward)
                {
                    break lab1;
                }
                slice_from("\u03B9\u03C3");
                break lab0;
            }
            cursor = limit - v_1;
            ket = cursor;
            break lab0;
        }
        if (find_among_b(a_7, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        among_var = find_among_b(a_6, null);
        if (among_var == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("\u03B9");
                break;
            case 2:
                slice_from("\u03B9\u03C3");
                break;
        }
        return true;
    }

    bool r_step_s4() {
        ket = cursor;
        if (find_among_b(a_9, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_8, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B9");
        return true;
    }

    bool r_step_s5() {
        int among_var;
        ket = cursor;
        if (find_among_b(a_11, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        among_var = find_among_b(a_10, null);
        if (among_var == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("\u03B9");
                break;
            case 2:
                slice_from("\u03B9\u03C3\u03C4");
                break;
        }
        return true;
    }

    bool r_step_s6() {
        int among_var;
        ket = cursor;
        if (find_among_b(a_14, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                bra = cursor;
                among_var = find_among_b(a_12, null);
                if (among_var == 0)
                {
                    break lab1;
                }
                if (cursor > limit_backward)
                {
                    break lab1;
                }
                switch (among_var) {
                    case 1:
                        slice_from("\u03B9\u03C3\u03BC");
                        break;
                    case 2:
                        slice_from("\u03B9");
                        break;
                }
                break lab0;
            }
            cursor = limit - v_1;
            ket = cursor;
            among_var = find_among_b(a_13, null);
            if (among_var == 0)
            {
                return false;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_from("\u03B1\u03B3\u03BD\u03C9\u03C3\u03C4");
                    break;
                case 2:
                    slice_from("\u03B1\u03C4\u03BF\u03BC");
                    break;
                case 3:
                    slice_from("\u03B3\u03BD\u03C9\u03C3\u03C4");
                    break;
                case 4:
                    slice_from("\u03B5\u03B8\u03BD");
                    break;
                case 5:
                    slice_from("\u03B5\u03BA\u03BB\u03B5\u03BA\u03C4");
                    break;
                case 6:
                    slice_from("\u03C3\u03BA\u03B5\u03C0\u03C4");
                    break;
                case 7:
                    slice_from("\u03C4\u03BF\u03C0");
                    break;
                case 8:
                    slice_from("\u03B1\u03BB\u03B5\u03BE\u03B1\u03BD\u03B4\u03C1");
                    break;
                case 9:
                    slice_from("\u03B2\u03C5\u03B6\u03B1\u03BD\u03C4");
                    break;
                case 10:
                    slice_from("\u03B8\u03B5\u03B1\u03C4\u03C1");
                    break;
            }
            break lab0;
        }
        return true;
    }

    bool r_step_s7() {
        ket = cursor;
        if (find_among_b(a_16, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_15, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B1\u03C1\u03B1\u03BA");
        return true;
    }

    bool r_step_s8() {
        int among_var;
        ket = cursor;
        if (find_among_b(a_18, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                bra = cursor;
                among_var = find_among_b(a_17, null);
                if (among_var == 0)
                {
                    break lab1;
                }
                if (cursor > limit_backward)
                {
                    break lab1;
                }
                switch (among_var) {
                    case 1:
                        slice_from("\u03B1\u03BA");
                        break;
                    case 2:
                        slice_from("\u03B9\u03C4\u03C3");
                        break;
                }
                break lab0;
            }
            cursor = limit - v_1;
            ket = cursor;
            bra = cursor;
            if (!(eq_s_b("\u03BA\u03BF\u03C1")))
            {
                return false;
            }
            slice_from("\u03B9\u03C4\u03C3");
            break lab0;
        }
        return true;
    }

    bool r_step_s9() {
        ket = cursor;
        if (find_among_b(a_21, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_19, null) == 0)
                {
                    break lab1;
                }
                if (cursor > limit_backward)
                {
                    break lab1;
                }
                slice_from("\u03B9\u03B4");
                break lab0;
            }
            cursor = limit - v_1;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_20, null) == 0)
            {
                return false;
            }
            slice_from("\u03B9\u03B4");
            break lab0;
        }
        return true;
    }

    bool r_step_s10() {
        ket = cursor;
        if (find_among_b(a_23, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_22, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B9\u03C3\u03BA");
        return true;
    }

    bool r_step_2a() {
        ket = cursor;
        if (find_among_b(a_24, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        {
            int v_1 = limit - cursor;
            lab0: while (true) {
                if (find_among_b(a_25, null) == 0)
                {
                    break lab0;
                }
                return false;
            }
            cursor = limit - v_1;
        }
        {
            int c = cursor;
            insert(cursor, cursor, "\u03B1\u03B4");
            cursor = c;
        }
        return true;
    }

    bool r_step_2b() {
        ket = cursor;
        if (find_among_b(a_26, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_27, null) == 0)
        {
            return false;
        }
        slice_from("\u03B5\u03B4");
        return true;
    }

    bool r_step_2c() {
        ket = cursor;
        if (find_among_b(a_28, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_29, null) == 0)
        {
            return false;
        }
        slice_from("\u03BF\u03C5\u03B4");
        return true;
    }

    bool r_step_2d() {
        ket = cursor;
        if (find_among_b(a_30, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_31, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B5");
        return true;
    }

    bool r_step_3() {
        ket = cursor;
        if (find_among_b(a_32, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (!(in_grouping_b(g_v, 945, 969)))
        {
            return false;
        }
        slice_from("\u03B9");
        return true;
    }

    bool r_step_4() {
        ket = cursor;
        if (find_among_b(a_33, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                bra = cursor;
                if (!(in_grouping_b(g_v, 945, 969)))
                {
                    break lab1;
                }
                slice_from("\u03B9\u03BA");
                break lab0;
            }
            cursor = limit - v_1;
            ket = cursor;
            break lab0;
        }
        bra = cursor;
        if (find_among_b(a_34, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B9\u03BA");
        return true;
    }

    bool r_step_5a() {
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            if (!(eq_s_b("\u03B1\u03B3\u03B1\u03BC\u03B5")))
            {
                break lab0;
            }
            bra = cursor;
            if (cursor > limit_backward)
            {
                break lab0;
            }
            slice_from("\u03B1\u03B3\u03B1\u03BC");
            break lab0;
        }
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        lab1: while (true) {
            ket = cursor;
            if (find_among_b(a_35, null) == 0)
            {
                break lab1;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            break lab1;
        }
        cursor = limit - v_2;
        ket = cursor;
        if (!(eq_s_b("\u03B1\u03BC\u03B5")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_36, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B1\u03BC");
        return true;
    }

    bool r_step_5b() {
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            if (find_among_b(a_38, null) == 0)
            {
                break lab0;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_37, null) == 0)
            {
                break lab0;
            }
            if (cursor > limit_backward)
            {
                break lab0;
            }
            slice_from("\u03B1\u03B3\u03B1\u03BD");
            break lab0;
        }
        cursor = limit - v_1;
        ket = cursor;
        if (!(eq_s_b("\u03B1\u03BD\u03B5")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        lab1: while (true) {
            int v_2 = limit - cursor;
            lab2: while (true) {
                ket = cursor;
                bra = cursor;
                if (!(in_grouping_b(g_v2, 945, 969)))
                {
                    break lab2;
                }
                slice_from("\u03B1\u03BD");
                break lab1;
            }
            cursor = limit - v_2;
            ket = cursor;
            break lab1;
        }
        bra = cursor;
        if (find_among_b(a_39, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B1\u03BD");
        return true;
    }

    bool r_step_5c() {
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            if (!(eq_s_b("\u03B7\u03C3\u03B5\u03C4\u03B5")))
            {
                break lab0;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            break lab0;
        }
        cursor = limit - v_1;
        ket = cursor;
        if (!(eq_s_b("\u03B5\u03C4\u03B5")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        lab1: while (true) {
            int v_2 = limit - cursor;
            lab2: while (true) {
                ket = cursor;
                bra = cursor;
                if (!(in_grouping_b(g_v2, 945, 969)))
                {
                    break lab2;
                }
                slice_from("\u03B5\u03C4");
                break lab1;
            }
            cursor = limit - v_2;
            lab3: while (true) {
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_40, null) == 0)
                {
                    break lab3;
                }
                slice_from("\u03B5\u03C4");
                break lab1;
            }
            cursor = limit - v_2;
            ket = cursor;
            break lab1;
        }
        bra = cursor;
        if (find_among_b(a_41, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B5\u03C4");
        return true;
    }

    bool r_step_5d() {
        ket = cursor;
        if (find_among_b(a_42, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                bra = cursor;
                if (!(eq_s_b("\u03B1\u03C1\u03C7")))
                {
                    break lab1;
                }
                if (cursor > limit_backward)
                {
                    break lab1;
                }
                slice_from("\u03BF\u03BD\u03C4");
                break lab0;
            }
            cursor = limit - v_1;
            ket = cursor;
            bra = cursor;
            if (!(eq_s_b("\u03BA\u03C1\u03B5")))
            {
                return false;
            }
            slice_from("\u03C9\u03BD\u03C4");
            break lab0;
        }
        return true;
    }

    bool r_step_5e() {
        ket = cursor;
        if (find_among_b(a_43, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (!(eq_s_b("\u03BF\u03BD")))
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03BF\u03BC\u03B1\u03C3\u03C4");
        return true;
    }

    bool r_step_5f() {
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            if (!(eq_s_b("\u03B9\u03B5\u03C3\u03C4\u03B5")))
            {
                break lab0;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_44, null) == 0)
            {
                break lab0;
            }
            if (cursor > limit_backward)
            {
                break lab0;
            }
            slice_from("\u03B9\u03B5\u03C3\u03C4");
            break lab0;
        }
        cursor = limit - v_1;
        ket = cursor;
        if (!(eq_s_b("\u03B5\u03C3\u03C4\u03B5")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_45, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B9\u03B5\u03C3\u03C4");
        return true;
    }

    bool r_step_5g() {
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            if (find_among_b(a_46, null) == 0)
            {
                break lab0;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            break lab0;
        }
        cursor = limit - v_1;
        ket = cursor;
        if (find_among_b(a_49, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        lab1: while (true) {
            int v_2 = limit - cursor;
            lab2: while (true) {
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_47, null) == 0)
                {
                    break lab2;
                }
                slice_from("\u03B7\u03BA");
                break lab1;
            }
            cursor = limit - v_2;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_48, null) == 0)
            {
                return false;
            }
            if (cursor > limit_backward)
            {
                return false;
            }
            slice_from("\u03B7\u03BA");
            break lab1;
        }
        return true;
    }

    bool r_step_5h() {
        ket = cursor;
        if (find_among_b(a_52, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_50, null) == 0)
                {
                    break lab1;
                }
                slice_from("\u03BF\u03C5\u03C3");
                break lab0;
            }
            cursor = limit - v_1;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_51, null) == 0)
            {
                return false;
            }
            if (cursor > limit_backward)
            {
                return false;
            }
            slice_from("\u03BF\u03C5\u03C3");
            break lab0;
        }
        return true;
    }

    bool r_step_5i() {
        int among_var;
        ket = cursor;
        if (find_among_b(a_55, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                bra = cursor;
                if (!(eq_s_b("\u03BA\u03BF\u03BB\u03BB")))
                {
                    break lab1;
                }
                slice_from("\u03B1\u03B3");
                break lab0;
            }
            cursor = limit - v_1;
            lab2: while (true) {
                int v_2 = limit - cursor;
                lab3: while (true) {
                    ket = cursor;
                    bra = cursor;
                    among_var = find_among_b(a_53, null);
                    if (among_var == 0)
                    {
                        break lab3;
                    }
                    switch (among_var) {
                        case 1:
                            slice_from("\u03B1\u03B3");
                            break;
                    }
                    break lab2;
                }
                cursor = limit - v_2;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_54, null) == 0)
                {
                    return false;
                }
                if (cursor > limit_backward)
                {
                    return false;
                }
                slice_from("\u03B1\u03B3");
                break lab2;
            }
            break lab0;
        }
        return true;
    }

    bool r_step_5j() {
        ket = cursor;
        if (find_among_b(a_56, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_57, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B7\u03C3");
        return true;
    }

    bool r_step_5k() {
        ket = cursor;
        if (!(eq_s_b("\u03B7\u03C3\u03C4\u03B5")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_58, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03B7\u03C3\u03C4");
        return true;
    }

    bool r_step_5l() {
        ket = cursor;
        if (find_among_b(a_59, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_60, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03BF\u03C5\u03BD");
        return true;
    }

    bool r_step_5m() {
        ket = cursor;
        if (find_among_b(a_61, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        B_test1 = false;
        ket = cursor;
        bra = cursor;
        if (find_among_b(a_62, null) == 0)
        {
            return false;
        }
        if (cursor > limit_backward)
        {
            return false;
        }
        slice_from("\u03BF\u03C5\u03BC");
        return true;
    }

    bool r_step_6() {
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            if (find_among_b(a_63, null) == 0)
            {
                break lab0;
            }
            bra = cursor;
            slice_from("\u03BC\u03B1");
            break lab0;
        }
        cursor = limit - v_1;
        if (!B_test1)
        {
            return false;
        }
        ket = cursor;
        if (find_among_b(a_64, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_step_7() {
        ket = cursor;
        if (find_among_b(a_65, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    @override
    bool stem() {
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        r_tolower();
        cursor = limit - v_1;
        if (current.length < 3)
        {
            return false;
        }
        B_test1 = true;
        int v_2 = limit - cursor;
        r_step_1();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_step_s1();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_step_s2();
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        r_step_s3();
        cursor = limit - v_5;
        int v_6 = limit - cursor;
        r_step_s4();
        cursor = limit - v_6;
        int v_7 = limit - cursor;
        r_step_s5();
        cursor = limit - v_7;
        int v_8 = limit - cursor;
        r_step_s6();
        cursor = limit - v_8;
        int v_9 = limit - cursor;
        r_step_s7();
        cursor = limit - v_9;
        int v_10 = limit - cursor;
        r_step_s8();
        cursor = limit - v_10;
        int v_11 = limit - cursor;
        r_step_s9();
        cursor = limit - v_11;
        int v_12 = limit - cursor;
        r_step_s10();
        cursor = limit - v_12;
        int v_13 = limit - cursor;
        r_step_2a();
        cursor = limit - v_13;
        int v_14 = limit - cursor;
        r_step_2b();
        cursor = limit - v_14;
        int v_15 = limit - cursor;
        r_step_2c();
        cursor = limit - v_15;
        int v_16 = limit - cursor;
        r_step_2d();
        cursor = limit - v_16;
        int v_17 = limit - cursor;
        r_step_3();
        cursor = limit - v_17;
        int v_18 = limit - cursor;
        r_step_4();
        cursor = limit - v_18;
        int v_19 = limit - cursor;
        r_step_5a();
        cursor = limit - v_19;
        int v_20 = limit - cursor;
        r_step_5b();
        cursor = limit - v_20;
        int v_21 = limit - cursor;
        r_step_5c();
        cursor = limit - v_21;
        int v_22 = limit - cursor;
        r_step_5d();
        cursor = limit - v_22;
        int v_23 = limit - cursor;
        r_step_5e();
        cursor = limit - v_23;
        int v_24 = limit - cursor;
        r_step_5f();
        cursor = limit - v_24;
        int v_25 = limit - cursor;
        r_step_5g();
        cursor = limit - v_25;
        int v_26 = limit - cursor;
        r_step_5h();
        cursor = limit - v_26;
        int v_27 = limit - cursor;
        r_step_5j();
        cursor = limit - v_27;
        int v_28 = limit - cursor;
        r_step_5i();
        cursor = limit - v_28;
        int v_29 = limit - cursor;
        r_step_5k();
        cursor = limit - v_29;
        int v_30 = limit - cursor;
        r_step_5l();
        cursor = limit - v_30;
        int v_31 = limit - cursor;
        r_step_5m();
        cursor = limit - v_31;
        int v_32 = limit - cursor;
        r_step_6();
        cursor = limit - v_32;
        int v_33 = limit - cursor;
        r_step_7();
        cursor = limit - v_33;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is greek_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
