// Generated from german.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from german.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class german_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 5, 0),
        Among("ae", 0, 2, 0),
        Among("oe", 0, 3, 0),
        Among("qu", 0, -1, 0),
        Among("ue", 0, 4, 0),
        Among("\u00DF", 0, 1, 0)
    ];

    static final a_1 = [
        Among("", -1, 5, 0),
        Among("U", 0, 2, 0),
        Among("Y", 0, 1, 0),
        Among("\u00E4", 0, 3, 0),
        Among("\u00F6", 0, 4, 0),
        Among("\u00FC", 0, 2, 0)
    ];

    static final a_2 = [
        Among("e", -1, 3, 0),
        Among("em", -1, 1, 0),
        Among("en", -1, 3, 0),
        Among("erinnen", 2, 2, 0),
        Among("erin", -1, 2, 0),
        Among("ln", -1, 5, 0),
        Among("ern", -1, 2, 0),
        Among("er", -1, 2, 0),
        Among("s", -1, 4, 0),
        Among("es", 8, 3, 0),
        Among("lns", 8, 5, 0)
    ];

    static final a_3 = [
        Among("tick", -1, -1, 0),
        Among("plan", -1, -1, 0),
        Among("geordn", -1, -1, 0),
        Among("intern", -1, -1, 0),
        Among("tr", -1, -1, 0)
    ];

    static final a_4 = [
        Among("en", -1, 1, 0),
        Among("er", -1, 1, 0),
        Among("et", -1, 3, 0),
        Among("st", -1, 2, 0),
        Among("est", 3, 1, 0)
    ];

    static final a_5 = [
        Among("ig", -1, 1, 0),
        Among("lich", -1, 1, 0)
    ];

    static final a_6 = [
        Among("end", -1, 1, 0),
        Among("ig", -1, 2, 0),
        Among("ung", -1, 1, 0),
        Among("lich", -1, 3, 0),
        Among("isch", -1, 2, 0),
        Among("ik", -1, 2, 0),
        Among("heit", -1, 3, 0),
        Among("keit", -1, 4, 0)
    ];

    static final a_7 = [
        Among("'", -1, 1, 0),
        Among("'sch", -1, 1, 0),
        Among("'s", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32, 8]);

    static final g_et_ending = String.fromCharCodes([1, 128, 198, 227, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128]);

    static final g_s_ending = String.fromCharCodes([117, 30, 5]);

    static final g_st_ending = String.fromCharCodes([117, 30, 4]);

    int I_p2 = 0;
    int I_p1 = 0;


    bool r_prelude() {
        int among_var;
        int v_1 = cursor;
        replab0: while(true)
        {
            int v_2 = cursor;
            lab1: while (true) {
                golab2: while(true)
                {
                    int v_3 = cursor;
                    lab3: while (true) {
                        if (!(in_grouping(g_v, 97, 252)))
                        {
                            break lab3;
                        }
                        bra = cursor;
                        lab4: while (true) {
                            int v_4 = cursor;
                            lab5: while (true) {
                                if (!(eq_s("u")))
                                {
                                    break lab5;
                                }
                                ket = cursor;
                                if (!(in_grouping(g_v, 97, 252)))
                                {
                                    break lab5;
                                }
                                slice_from("U");
                                break lab4;
                            }
                            cursor = v_4;
                            if (!(eq_s("y")))
                            {
                                break lab3;
                            }
                            ket = cursor;
                            if (!(in_grouping(g_v, 97, 252)))
                            {
                                break lab3;
                            }
                            slice_from("Y");
                            break lab4;
                        }
                        cursor = v_3;
                        break golab2;
                    }
                    cursor = v_3;
                    if (cursor >= limit)
                    {
                        break lab1;
                    }
                    cursor++;
                }
                continue replab0;
            }
            cursor = v_2;
            break replab0;
        }
        cursor = v_1;
        replab6: while(true)
        {
            int v_5 = cursor;
            lab7: while (true) {
                bra = cursor;
                among_var = find_among(a_0, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("ss");
                        break;
                    case 2:
                        slice_from("\u00E4");
                        break;
                    case 3:
                        slice_from("\u00F6");
                        break;
                    case 4:
                        slice_from("\u00FC");
                        break;
                    case 5:
                        if (cursor >= limit)
                        {
                            break lab7;
                        }
                        cursor++;
                        break;
                }
                continue replab6;
            }
            cursor = v_5;
            break replab6;
        }
        return true;
    }

    bool r_mark_regions() {
        int I_x;
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        {
            int c = cursor + 3;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        I_x = cursor;
        cursor = v_1;
        if (!go_out_grouping(g_v, 97, 252))
        {
            return false;
        }
        cursor++;
        if (!go_in_grouping(g_v, 97, 252))
        {
            return false;
        }
        cursor++;
        I_p1 = cursor;
        lab0: while (true) {
            if (I_p1 >= I_x)
            {
                break lab0;
            }
            I_p1 = I_x;
            break lab0;
        }
        if (!go_out_grouping(g_v, 97, 252))
        {
            return false;
        }
        cursor++;
        if (!go_in_grouping(g_v, 97, 252))
        {
            return false;
        }
        cursor++;
        I_p2 = cursor;
        return true;
    }

    bool r_postlude() {
        int among_var;
        replab0: while(true)
        {
            int v_1 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_1, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("y");
                        break;
                    case 2:
                        slice_from("u");
                        break;
                    case 3:
                        slice_from("a");
                        break;
                    case 4:
                        slice_from("o");
                        break;
                    case 5:
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break;
                }
                continue replab0;
            }
            cursor = v_1;
            break replab0;
        }
        return true;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_standard_suffix() {
        int among_var;
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            among_var = find_among_b(a_2, null);
            if (among_var == 0)
            {
                break lab0;
            }
            bra = cursor;
            if (!r_R1())
            {
                break lab0;
            }
            switch (among_var) {
                case 1:
                    lab1: while (true) {
                        if (!(eq_s_b("syst")))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    slice_del();
                    break;
                case 2:
                    slice_del();
                    break;
                case 3:
                    slice_del();
                    int v_2 = limit - cursor;
                    lab2: while (true) {
                        ket = cursor;
                        if (!(eq_s_b("s")))
                        {
                            cursor = limit - v_2;
                            break lab2;
                        }
                        bra = cursor;
                        if (!(eq_s_b("nis")))
                        {
                            cursor = limit - v_2;
                            break lab2;
                        }
                        slice_del();
                        break lab2;
                    }
                    break;
                case 4:
                    if (!(in_grouping_b(g_s_ending, 98, 116)))
                    {
                        break lab0;
                    }
                    slice_del();
                    break;
                case 5:
                    slice_from("l");
                    break;
            }
            break lab0;
        }
        cursor = limit - v_1;
        int v_3 = limit - cursor;
        lab3: while (true) {
            ket = cursor;
            among_var = find_among_b(a_4, null);
            if (among_var == 0)
            {
                break lab3;
            }
            bra = cursor;
            if (!r_R1())
            {
                break lab3;
            }
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    if (!(in_grouping_b(g_st_ending, 98, 116)))
                    {
                        break lab3;
                    }
                    {
                        int c = cursor - 3;
                        if (c < limit_backward)
                        {
                            break lab3;
                        }
                        cursor = c;
                    }
                    slice_del();
                    break;
                case 3:
                    int v_4 = limit - cursor;
                    if (!(in_grouping_b(g_et_ending, 85, 228)))
                    {
                        break lab3;
                    }
                    cursor = limit - v_4;
                    {
                        int v_5 = limit - cursor;
                        lab4: while (true) {
                            if (find_among_b(a_3, null) == 0)
                            {
                                break lab4;
                            }
                            break lab3;
                        }
                        cursor = limit - v_5;
                    }
                    slice_del();
                    break;
            }
            break lab3;
        }
        cursor = limit - v_3;
        int v_6 = limit - cursor;
        lab5: while (true) {
            ket = cursor;
            among_var = find_among_b(a_6, null);
            if (among_var == 0)
            {
                break lab5;
            }
            bra = cursor;
            if (!r_R2())
            {
                break lab5;
            }
            switch (among_var) {
                case 1:
                    slice_del();
                    int v_7 = limit - cursor;
                    lab6: while (true) {
                        ket = cursor;
                        if (!(eq_s_b("ig")))
                        {
                            cursor = limit - v_7;
                            break lab6;
                        }
                        bra = cursor;
                        lab7: while (true) {
                            if (!(eq_s_b("e")))
                            {
                                break lab7;
                            }
                            cursor = limit - v_7;
                            break lab6;
                        }
                        if (!r_R2())
                        {
                            cursor = limit - v_7;
                            break lab6;
                        }
                        slice_del();
                        break lab6;
                    }
                    break;
                case 2:
                    lab8: while (true) {
                        if (!(eq_s_b("e")))
                        {
                            break lab8;
                        }
                        break lab5;
                    }
                    slice_del();
                    break;
                case 3:
                    slice_del();
                    int v_8 = limit - cursor;
                    lab9: while (true) {
                        ket = cursor;
                        lab10: while (true) {
                            lab11: while (true) {
                                if (!(eq_s_b("er")))
                                {
                                    break lab11;
                                }
                                break lab10;
                            }
                            if (!(eq_s_b("en")))
                            {
                                cursor = limit - v_8;
                                break lab9;
                            }
                            break lab10;
                        }
                        bra = cursor;
                        if (!r_R1())
                        {
                            cursor = limit - v_8;
                            break lab9;
                        }
                        slice_del();
                        break lab9;
                    }
                    break;
                case 4:
                    slice_del();
                    int v_9 = limit - cursor;
                    lab12: while (true) {
                        ket = cursor;
                        if (find_among_b(a_5, null) == 0)
                        {
                            cursor = limit - v_9;
                            break lab12;
                        }
                        bra = cursor;
                        if (!r_R2())
                        {
                            cursor = limit - v_9;
                            break lab12;
                        }
                        slice_del();
                        break lab12;
                    }
                    break;
            }
            break lab5;
        }
        cursor = limit - v_6;
        int v_10 = limit - cursor;
        lab13: while (true) {
            ket = cursor;
            if (find_among_b(a_7, null) == 0)
            {
                break lab13;
            }
            bra = cursor;
            if (cursor <= limit_backward)
            {
                break lab13;
            }
            cursor--;
            if (cursor <= limit_backward)
            {
                break lab13;
            }
            slice_del();
            break lab13;
        }
        cursor = limit - v_10;
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        r_prelude();
        cursor = v_1;
        int v_2 = cursor;
        r_mark_regions();
        cursor = v_2;
        limit_backward = cursor;
        cursor = limit;
        r_standard_suffix();
        cursor = limit_backward;
        int v_3 = cursor;
        r_postlude();
        cursor = v_3;
        return true;
    }

    @override
    bool operator ==(Object other) => other is german_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
