// Generated from romanian.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from romanian.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class romanian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("\u015F", -1, 1, 0),
        Among("\u0163", -1, 2, 0)
    ];

    static final a_1 = [
        Among("", -1, 3, 0),
        Among("I", 0, 1, 0),
        Among("U", 0, 2, 0)
    ];

    static final a_2 = [
        Among("ea", -1, 3, 0),
        Among("a\u021Bia", -1, 7, 0),
        Among("aua", -1, 2, 0),
        Among("iua", -1, 4, 0),
        Among("a\u021Bie", -1, 7, 0),
        Among("ele", -1, 3, 0),
        Among("ile", -1, 5, 0),
        Among("iile", 6, 4, 0),
        Among("iei", -1, 4, 0),
        Among("atei", -1, 6, 0),
        Among("ii", -1, 4, 0),
        Among("ului", -1, 1, 0),
        Among("ul", -1, 1, 0),
        Among("elor", -1, 3, 0),
        Among("ilor", -1, 4, 0),
        Among("iilor", 14, 4, 0)
    ];

    static final a_3 = [
        Among("icala", -1, 4, 0),
        Among("iciva", -1, 4, 0),
        Among("ativa", -1, 5, 0),
        Among("itiva", -1, 6, 0),
        Among("icale", -1, 4, 0),
        Among("a\u021Biune", -1, 5, 0),
        Among("i\u021Biune", -1, 6, 0),
        Among("atoare", -1, 5, 0),
        Among("itoare", -1, 6, 0),
        Among("\u0103toare", -1, 5, 0),
        Among("icitate", -1, 4, 0),
        Among("abilitate", -1, 1, 0),
        Among("ibilitate", -1, 2, 0),
        Among("ivitate", -1, 3, 0),
        Among("icive", -1, 4, 0),
        Among("ative", -1, 5, 0),
        Among("itive", -1, 6, 0),
        Among("icali", -1, 4, 0),
        Among("atori", -1, 5, 0),
        Among("icatori", 18, 4, 0),
        Among("itori", -1, 6, 0),
        Among("\u0103tori", -1, 5, 0),
        Among("icitati", -1, 4, 0),
        Among("abilitati", -1, 1, 0),
        Among("ivitati", -1, 3, 0),
        Among("icivi", -1, 4, 0),
        Among("ativi", -1, 5, 0),
        Among("itivi", -1, 6, 0),
        Among("icit\u0103i", -1, 4, 0),
        Among("abilit\u0103i", -1, 1, 0),
        Among("ivit\u0103i", -1, 3, 0),
        Among("icit\u0103\u021Bi", -1, 4, 0),
        Among("abilit\u0103\u021Bi", -1, 1, 0),
        Among("ivit\u0103\u021Bi", -1, 3, 0),
        Among("ical", -1, 4, 0),
        Among("ator", -1, 5, 0),
        Among("icator", 35, 4, 0),
        Among("itor", -1, 6, 0),
        Among("\u0103tor", -1, 5, 0),
        Among("iciv", -1, 4, 0),
        Among("ativ", -1, 5, 0),
        Among("itiv", -1, 6, 0),
        Among("ical\u0103", -1, 4, 0),
        Among("iciv\u0103", -1, 4, 0),
        Among("ativ\u0103", -1, 5, 0),
        Among("itiv\u0103", -1, 6, 0)
    ];

    static final a_4 = [
        Among("ica", -1, 1, 0),
        Among("abila", -1, 1, 0),
        Among("ibila", -1, 1, 0),
        Among("oasa", -1, 1, 0),
        Among("ata", -1, 1, 0),
        Among("ita", -1, 1, 0),
        Among("anta", -1, 1, 0),
        Among("ista", -1, 3, 0),
        Among("uta", -1, 1, 0),
        Among("iva", -1, 1, 0),
        Among("ic", -1, 1, 0),
        Among("ice", -1, 1, 0),
        Among("abile", -1, 1, 0),
        Among("ibile", -1, 1, 0),
        Among("isme", -1, 3, 0),
        Among("iune", -1, 2, 0),
        Among("oase", -1, 1, 0),
        Among("ate", -1, 1, 0),
        Among("itate", 17, 1, 0),
        Among("ite", -1, 1, 0),
        Among("ante", -1, 1, 0),
        Among("iste", -1, 3, 0),
        Among("ute", -1, 1, 0),
        Among("ive", -1, 1, 0),
        Among("ici", -1, 1, 0),
        Among("abili", -1, 1, 0),
        Among("ibili", -1, 1, 0),
        Among("iuni", -1, 2, 0),
        Among("atori", -1, 1, 0),
        Among("osi", -1, 1, 0),
        Among("ati", -1, 1, 0),
        Among("itati", 30, 1, 0),
        Among("iti", -1, 1, 0),
        Among("anti", -1, 1, 0),
        Among("isti", -1, 3, 0),
        Among("uti", -1, 1, 0),
        Among("i\u0219ti", -1, 3, 0),
        Among("ivi", -1, 1, 0),
        Among("it\u0103i", -1, 1, 0),
        Among("o\u0219i", -1, 1, 0),
        Among("it\u0103\u021Bi", -1, 1, 0),
        Among("abil", -1, 1, 0),
        Among("ibil", -1, 1, 0),
        Among("ism", -1, 3, 0),
        Among("ator", -1, 1, 0),
        Among("os", -1, 1, 0),
        Among("at", -1, 1, 0),
        Among("it", -1, 1, 0),
        Among("ant", -1, 1, 0),
        Among("ist", -1, 3, 0),
        Among("ut", -1, 1, 0),
        Among("iv", -1, 1, 0),
        Among("ic\u0103", -1, 1, 0),
        Among("abil\u0103", -1, 1, 0),
        Among("ibil\u0103", -1, 1, 0),
        Among("oas\u0103", -1, 1, 0),
        Among("at\u0103", -1, 1, 0),
        Among("it\u0103", -1, 1, 0),
        Among("ant\u0103", -1, 1, 0),
        Among("ist\u0103", -1, 3, 0),
        Among("ut\u0103", -1, 1, 0),
        Among("iv\u0103", -1, 1, 0)
    ];

    static final a_5 = [
        Among("ea", -1, 1, 0),
        Among("ia", -1, 1, 0),
        Among("esc", -1, 1, 0),
        Among("\u0103sc", -1, 1, 0),
        Among("ind", -1, 1, 0),
        Among("\u00E2nd", -1, 1, 0),
        Among("are", -1, 1, 0),
        Among("ere", -1, 1, 0),
        Among("ire", -1, 1, 0),
        Among("\u00E2re", -1, 1, 0),
        Among("se", -1, 2, 0),
        Among("ase", 10, 1, 0),
        Among("sese", 10, 2, 0),
        Among("ise", 10, 1, 0),
        Among("use", 10, 1, 0),
        Among("\u00E2se", 10, 1, 0),
        Among("e\u0219te", -1, 1, 0),
        Among("\u0103\u0219te", -1, 1, 0),
        Among("eze", -1, 1, 0),
        Among("ai", -1, 1, 0),
        Among("eai", 19, 1, 0),
        Among("iai", 19, 1, 0),
        Among("sei", -1, 2, 0),
        Among("e\u0219ti", -1, 1, 0),
        Among("\u0103\u0219ti", -1, 1, 0),
        Among("ui", -1, 1, 0),
        Among("ezi", -1, 1, 0),
        Among("\u00E2i", -1, 1, 0),
        Among("a\u0219i", -1, 1, 0),
        Among("se\u0219i", -1, 2, 0),
        Among("ase\u0219i", 29, 1, 0),
        Among("sese\u0219i", 29, 2, 0),
        Among("ise\u0219i", 29, 1, 0),
        Among("use\u0219i", 29, 1, 0),
        Among("\u00E2se\u0219i", 29, 1, 0),
        Among("i\u0219i", -1, 1, 0),
        Among("u\u0219i", -1, 1, 0),
        Among("\u00E2\u0219i", -1, 1, 0),
        Among("a\u021Bi", -1, 2, 0),
        Among("ea\u021Bi", 38, 1, 0),
        Among("ia\u021Bi", 38, 1, 0),
        Among("e\u021Bi", -1, 2, 0),
        Among("i\u021Bi", -1, 2, 0),
        Among("\u00E2\u021Bi", -1, 2, 0),
        Among("ar\u0103\u021Bi", -1, 1, 0),
        Among("ser\u0103\u021Bi", -1, 2, 0),
        Among("aser\u0103\u021Bi", 45, 1, 0),
        Among("seser\u0103\u021Bi", 45, 2, 0),
        Among("iser\u0103\u021Bi", 45, 1, 0),
        Among("user\u0103\u021Bi", 45, 1, 0),
        Among("\u00E2ser\u0103\u021Bi", 45, 1, 0),
        Among("ir\u0103\u021Bi", -1, 1, 0),
        Among("ur\u0103\u021Bi", -1, 1, 0),
        Among("\u00E2r\u0103\u021Bi", -1, 1, 0),
        Among("am", -1, 1, 0),
        Among("eam", 54, 1, 0),
        Among("iam", 54, 1, 0),
        Among("em", -1, 2, 0),
        Among("asem", 57, 1, 0),
        Among("sesem", 57, 2, 0),
        Among("isem", 57, 1, 0),
        Among("usem", 57, 1, 0),
        Among("\u00E2sem", 57, 1, 0),
        Among("im", -1, 2, 0),
        Among("\u00E2m", -1, 2, 0),
        Among("\u0103m", -1, 2, 0),
        Among("ar\u0103m", 65, 1, 0),
        Among("ser\u0103m", 65, 2, 0),
        Among("aser\u0103m", 67, 1, 0),
        Among("seser\u0103m", 67, 2, 0),
        Among("iser\u0103m", 67, 1, 0),
        Among("user\u0103m", 67, 1, 0),
        Among("\u00E2ser\u0103m", 67, 1, 0),
        Among("ir\u0103m", 65, 1, 0),
        Among("ur\u0103m", 65, 1, 0),
        Among("\u00E2r\u0103m", 65, 1, 0),
        Among("au", -1, 1, 0),
        Among("eau", 76, 1, 0),
        Among("iau", 76, 1, 0),
        Among("indu", -1, 1, 0),
        Among("\u00E2ndu", -1, 1, 0),
        Among("ez", -1, 1, 0),
        Among("easc\u0103", -1, 1, 0),
        Among("ar\u0103", -1, 1, 0),
        Among("ser\u0103", -1, 2, 0),
        Among("aser\u0103", 84, 1, 0),
        Among("seser\u0103", 84, 2, 0),
        Among("iser\u0103", 84, 1, 0),
        Among("user\u0103", 84, 1, 0),
        Among("\u00E2ser\u0103", 84, 1, 0),
        Among("ir\u0103", -1, 1, 0),
        Among("ur\u0103", -1, 1, 0),
        Among("\u00E2r\u0103", -1, 1, 0),
        Among("eaz\u0103", -1, 1, 0)
    ];

    static final a_6 = [
        Among("a", -1, 1, 0),
        Among("e", -1, 1, 0),
        Among("ie", 1, 1, 0),
        Among("i", -1, 1, 0),
        Among("\u0103", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 32, 0, 0, 4]);

    bool B_standard_suffix_removed = false;
    int I_p2 = 0;
    int I_p1 = 0;
    int I_pV = 0;


    bool r_norm() {
        int among_var;
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = cursor;
                lab2: while (true) {
                    golab3: while(true)
                    {
                        int v_3 = cursor;
                        lab4: while (true) {
                            bra = cursor;
                            among_var = find_among(a_0, null);
                            if (among_var == 0)
                            {
                                break lab4;
                            }
                            ket = cursor;
                            switch (among_var) {
                                case 1:
                                    slice_from("\u0219");
                                    break;
                                case 2:
                                    slice_from("\u021B");
                                    break;
                            }
                            cursor = v_3;
                            break golab3;
                        }
                        cursor = v_3;
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    continue replab1;
                }
                cursor = v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = v_1;
        return true;
    }

    bool r_prelude() {
        replab0: while(true)
        {
            int v_1 = cursor;
            lab1: while (true) {
                golab2: while(true)
                {
                    int v_2 = cursor;
                    lab3: while (true) {
                        if (!(in_grouping(g_v, 97, 259)))
                        {
                            break lab3;
                        }
                        bra = cursor;
                        lab4: while (true) {
                            int v_3 = cursor;
                            lab5: while (true) {
                                if (!(eq_s("u")))
                                {
                                    break lab5;
                                }
                                ket = cursor;
                                if (!(in_grouping(g_v, 97, 259)))
                                {
                                    break lab5;
                                }
                                slice_from("U");
                                break lab4;
                            }
                            cursor = v_3;
                            if (!(eq_s("i")))
                            {
                                break lab3;
                            }
                            ket = cursor;
                            if (!(in_grouping(g_v, 97, 259)))
                            {
                                break lab3;
                            }
                            slice_from("I");
                            break lab4;
                        }
                        cursor = v_2;
                        break golab2;
                    }
                    cursor = v_2;
                    if (cursor >= limit)
                    {
                        break lab1;
                    }
                    cursor++;
                }
                continue replab0;
            }
            cursor = v_1;
            break replab0;
        }
        return true;
    }

    bool r_mark_regions() {
        I_pV = limit;
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_2 = cursor;
                lab2: while (true) {
                    if (!(in_grouping(g_v, 97, 259)))
                    {
                        break lab2;
                    }
                    lab3: while (true) {
                        int v_3 = cursor;
                        lab4: while (true) {
                            if (!(out_grouping(g_v, 97, 259)))
                            {
                                break lab4;
                            }
                            if (!go_out_grouping(g_v, 97, 259))
                            {
                                break lab4;
                            }
                            cursor++;
                            break lab3;
                        }
                        cursor = v_3;
                        if (!(in_grouping(g_v, 97, 259)))
                        {
                            break lab2;
                        }
                        if (!go_in_grouping(g_v, 97, 259))
                        {
                            break lab2;
                        }
                        cursor++;
                        break lab3;
                    }
                    break lab1;
                }
                cursor = v_2;
                if (!(out_grouping(g_v, 97, 259)))
                {
                    break lab0;
                }
                lab5: while (true) {
                    int v_4 = cursor;
                    lab6: while (true) {
                        if (!(out_grouping(g_v, 97, 259)))
                        {
                            break lab6;
                        }
                        if (!go_out_grouping(g_v, 97, 259))
                        {
                            break lab6;
                        }
                        cursor++;
                        break lab5;
                    }
                    cursor = v_4;
                    if (!(in_grouping(g_v, 97, 259)))
                    {
                        break lab0;
                    }
                    if (cursor >= limit)
                    {
                        break lab0;
                    }
                    cursor++;
                    break lab5;
                }
                break lab1;
            }
            I_pV = cursor;
            break lab0;
        }
        cursor = v_1;
        int v_5 = cursor;
        lab7: while (true) {
            if (!go_out_grouping(g_v, 97, 259))
            {
                break lab7;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 259))
            {
                break lab7;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 259))
            {
                break lab7;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 259))
            {
                break lab7;
            }
            cursor++;
            I_p2 = cursor;
            break lab7;
        }
        cursor = v_5;
        return true;
    }

    bool r_postlude() {
        int among_var;
        replab0: while(true)
        {
            int v_1 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_1, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("i");
                        break;
                    case 2:
                        slice_from("u");
                        break;
                    case 3:
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break;
                }
                continue replab0;
            }
            cursor = v_1;
            break replab0;
        }
        return true;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_step_0() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_from("a");
                break;
            case 3:
                slice_from("e");
                break;
            case 4:
                slice_from("i");
                break;
            case 5:
                lab0: while (true) {
                    if (!(eq_s_b("ab")))
                    {
                        break lab0;
                    }
                    return false;
                }
                slice_from("i");
                break;
            case 6:
                slice_from("at");
                break;
            case 7:
                slice_from("a\u021Bi");
                break;
        }
        return true;
    }

    bool r_combo_suffix() {
        int among_var;
        int v_1 = limit - cursor;
        ket = cursor;
        among_var = find_among_b(a_3, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("abil");
                break;
            case 2:
                slice_from("ibil");
                break;
            case 3:
                slice_from("iv");
                break;
            case 4:
                slice_from("ic");
                break;
            case 5:
                slice_from("at");
                break;
            case 6:
                slice_from("it");
                break;
        }
        B_standard_suffix_removed = true;
        cursor = limit - v_1;
        return true;
    }

    bool r_standard_suffix() {
        int among_var;
        B_standard_suffix_removed = false;
        replab0: while(true)
        {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (!r_combo_suffix())
                {
                    break lab1;
                }
                continue replab0;
            }
            cursor = limit - v_1;
            break replab0;
        }
        ket = cursor;
        among_var = find_among_b(a_4, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (I_p2 > cursor)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                if (!(eq_s_b("\u021B")))
                {
                    return false;
                }
                bra = cursor;
                slice_from("t");
                break;
            case 3:
                slice_from("ist");
                break;
        }
        B_standard_suffix_removed = true;
        return true;
    }

    bool r_verb_suffix() {
        int among_var;
        if (cursor < I_pV)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_pV;
        ket = cursor;
        among_var = find_among_b(a_5, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    lab1: while (true) {
                        if (!(out_grouping_b(g_v, 97, 259)))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    if (!(eq_s_b("u")))
                    {
                        limit_backward = v_1;
                        return false;
                    }
                    break lab0;
                }
                slice_del();
                break;
            case 2:
                slice_del();
                break;
        }
        limit_backward = v_1;
        return true;
    }

    bool r_vowel_suffix() {
        ket = cursor;
        if (find_among_b(a_6, null) == 0)
        {
            return false;
        }
        bra = cursor;
        if (I_pV > cursor)
        {
            return false;
        }
        slice_del();
        return true;
    }

    @override
    bool stem() {
        r_norm();
        int v_1 = cursor;
        r_prelude();
        cursor = v_1;
        r_mark_regions();
        limit_backward = cursor;
        cursor = limit;
        int v_2 = limit - cursor;
        r_step_0();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_standard_suffix();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        lab0: while (true) {
            lab1: while (true) {
                lab2: while (true) {
                    if (!B_standard_suffix_removed)
                    {
                        break lab2;
                    }
                    break lab1;
                }
                if (!r_verb_suffix())
                {
                    break lab0;
                }
                break lab1;
            }
            break lab0;
        }
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        r_vowel_suffix();
        cursor = limit - v_5;
        cursor = limit_backward;
        int v_6 = cursor;
        r_postlude();
        cursor = v_6;
        return true;
    }

    @override
    bool operator ==(Object other) => other is romanian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
