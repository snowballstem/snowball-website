// Generated from dutch.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from dutch.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class dutch_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("a", -1, 1, 0),
        Among("e", -1, 2, 0),
        Among("o", -1, 1, 0),
        Among("u", -1, 1, 0),
        Among("\u00E0", -1, 1, 0),
        Among("\u00E1", -1, 1, 0),
        Among("\u00E2", -1, 1, 0),
        Among("\u00E4", -1, 1, 0),
        Among("\u00E8", -1, 2, 0),
        Among("\u00E9", -1, 2, 0),
        Among("\u00EA", -1, 2, 0),
        Among("e\u00EB", -1, 3, 0),
        Among("i\u00EB", -1, 4, 0),
        Among("\u00F2", -1, 1, 0),
        Among("\u00F3", -1, 1, 0),
        Among("\u00F4", -1, 1, 0),
        Among("\u00F6", -1, 1, 0),
        Among("\u00F9", -1, 1, 0),
        Among("\u00FA", -1, 1, 0),
        Among("\u00FB", -1, 1, 0),
        Among("\u00FC", -1, 1, 0)
    ];

    static final a_1 = [
        Among("nde", -1, 8, 0),
        Among("en", -1, 7, 0),
        Among("s", -1, 2, 0),
        Among("'s", 2, 1, 0),
        Among("es", 2, 4, 0),
        Among("ies", 4, 3, 0),
        Among("aus", 2, 6, 0),
        Among("\u00E9s", 2, 5, 0)
    ];

    static final a_2 = [
        Among("de", -1, 5, 0),
        Among("ge", -1, 2, 0),
        Among("ische", -1, 4, 0),
        Among("je", -1, 1, 0),
        Among("lijke", -1, 3, 0),
        Among("le", -1, 9, 0),
        Among("ene", -1, 10, 0),
        Among("re", -1, 8, 0),
        Among("se", -1, 7, 0),
        Among("te", -1, 6, 0),
        Among("ieve", -1, 11, 0)
    ];

    static final a_3 = [
        Among("heid", -1, 3, 0),
        Among("fie", -1, 7, 0),
        Among("gie", -1, 8, 0),
        Among("atie", -1, 1, 0),
        Among("isme", -1, 5, 0),
        Among("ing", -1, 5, 0),
        Among("arij", -1, 6, 0),
        Among("erij", -1, 5, 0),
        Among("sel", -1, 3, 0),
        Among("rder", -1, 4, 0),
        Among("ster", -1, 3, 0),
        Among("iteit", -1, 2, 0),
        Among("dst", -1, 10, 0),
        Among("tst", -1, 9, 0)
    ];

    static final a_4 = [
        Among("end", -1, 9, 0),
        Among("atief", -1, 2, 0),
        Among("erig", -1, 9, 0),
        Among("achtig", -1, 3, 0),
        Among("ioneel", -1, 1, 0),
        Among("baar", -1, 3, 0),
        Among("laar", -1, 5, 0),
        Among("naar", -1, 4, 0),
        Among("raar", -1, 6, 0),
        Among("eriger", -1, 9, 0),
        Among("achtiger", -1, 3, 0),
        Among("lijker", -1, 8, 0),
        Among("tant", -1, 7, 0),
        Among("erigst", -1, 9, 0),
        Among("achtigst", -1, 3, 0),
        Among("lijkst", -1, 8, 0)
    ];

    static final a_5 = [
        Among("ig", -1, 1, 0),
        Among("iger", -1, 1, 0),
        Among("igst", -1, 1, 0)
    ];

    static final a_6 = [
        Among("ft", -1, 2, 0),
        Among("kt", -1, 1, 0),
        Among("pt", -1, 3, 0)
    ];

    static final a_7 = [
        Among("bb", -1, 1, 0),
        Among("cc", -1, 2, 0),
        Among("dd", -1, 3, 0),
        Among("ff", -1, 4, 0),
        Among("gg", -1, 5, 0),
        Among("hh", -1, 6, 0),
        Among("jj", -1, 7, 0),
        Among("kk", -1, 8, 0),
        Among("ll", -1, 9, 0),
        Among("mm", -1, 10, 0),
        Among("nn", -1, 11, 0),
        Among("pp", -1, 12, 0),
        Among("qq", -1, 13, 0),
        Among("rr", -1, 14, 0),
        Among("ss", -1, 15, 0),
        Among("tt", -1, 16, 0),
        Among("v", -1, 4, 0),
        Among("vv", 16, 17, 0),
        Among("ww", -1, 18, 0),
        Among("xx", -1, 19, 0),
        Among("z", -1, 15, 0),
        Among("zz", 20, 20, 0)
    ];

    static final a_8 = [
        Among("d", -1, 1, 0),
        Among("t", -1, 2, 0)
    ];

    static final a_9 = [
        Among("", -1, -1, 0),
        Among("eft", 0, 1, 0),
        Among("vaa", 0, 1, 0),
        Among("val", 0, 1, 0),
        Among("vali", 3, -1, 0),
        Among("vare", 0, 1, 0)
    ];

    static final a_10 = [
        Among("\u00EB", -1, 1, 0),
        Among("\u00EF", -1, 2, 0)
    ];

    static final a_11 = [
        Among("\u00EB", -1, 1, 0),
        Among("\u00EF", -1, 2, 0)
    ];

    static final g_E = String.fromCharCodes([1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120]);

    static final g_AIOU = String.fromCharCodes([1, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 11, 120, 46, 15]);

    static final g_AEIOU = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 139, 127, 46, 15]);

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 139, 127, 46, 15]);

    static final g_v_WX = String.fromCharCodes([17, 65, 208, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 139, 127, 46, 15]);

    bool B_GE_removed = false;
    int I_p2 = 0;
    int I_p1 = 0;


    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_V() {
        int v_1 = limit - cursor;
        lab0: while (true) {
            lab1: while (true) {
                if (!(in_grouping_b(g_v, 97, 252)))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("ij")))
            {
                return false;
            }
            break lab0;
        }
        cursor = limit - v_1;
        return true;
    }

    bool r_VX() {
        int v_1 = limit - cursor;
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor--;
        lab0: while (true) {
            lab1: while (true) {
                if (!(in_grouping_b(g_v, 97, 252)))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("ij")))
            {
                return false;
            }
            break lab0;
        }
        cursor = limit - v_1;
        return true;
    }

    bool r_C() {
        int v_1 = limit - cursor;
        lab0: while (true) {
            if (!(eq_s_b("ij")))
            {
                break lab0;
            }
            return false;
        }
        if (!(out_grouping_b(g_v, 97, 252)))
        {
            return false;
        }
        cursor = limit - v_1;
        return true;
    }

    bool r_lengthen_V() {
        int among_var;
        String S_ch;
        int v_1 = limit - cursor;
        lab0: while (true) {
            if (!(out_grouping_b(g_v_WX, 97, 252)))
            {
                break lab0;
            }
            ket = cursor;
            among_var = find_among_b(a_0, null);
            if (among_var == 0)
            {
                break lab0;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    int v_2 = limit - cursor;
                    lab1: while (true) {
                        lab2: while (true) {
                            if (!(out_grouping_b(g_AEIOU, 97, 252)))
                            {
                                break lab2;
                            }
                            break lab1;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab0;
                        }
                        break lab1;
                    }
                    cursor = limit - v_2;
                    S_ch = slice_to();
                    {
                        int c = cursor;
                        insert(cursor, cursor, S_ch);
                        cursor = c;
                    }
                    break;
                case 2:
                    int v_3 = limit - cursor;
                    lab3: while (true) {
                        lab4: while (true) {
                            if (!(out_grouping_b(g_AEIOU, 97, 252)))
                            {
                                break lab4;
                            }
                            break lab3;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab0;
                        }
                        break lab3;
                    }
                    {
                        int v_4 = limit - cursor;
                        lab5: while (true) {
                            lab6: while (true) {
                                lab7: while (true) {
                                    if (!(in_grouping_b(g_AIOU, 97, 252)))
                                    {
                                        break lab7;
                                    }
                                    break lab6;
                                }
                                if (!(in_grouping_b(g_E, 101, 235)))
                                {
                                    break lab5;
                                }
                                if (cursor > limit_backward)
                                {
                                    break lab5;
                                }
                                break lab6;
                            }
                            break lab0;
                        }
                        cursor = limit - v_4;
                    }
                    {
                        int v_5 = limit - cursor;
                        lab8: while (true) {
                            if (cursor <= limit_backward)
                            {
                                break lab8;
                            }
                            cursor--;
                            if (!(in_grouping_b(g_AIOU, 97, 252)))
                            {
                                break lab8;
                            }
                            if (!(out_grouping_b(g_AEIOU, 97, 252)))
                            {
                                break lab8;
                            }
                            break lab0;
                        }
                        cursor = limit - v_5;
                    }
                    cursor = limit - v_3;
                    S_ch = slice_to();
                    {
                        int c = cursor;
                        insert(cursor, cursor, S_ch);
                        cursor = c;
                    }
                    break;
                case 3:
                    slice_from("e\u00EBe");
                    break;
                case 4:
                    slice_from("iee");
                    break;
            }
            break lab0;
        }
        cursor = limit - v_1;
        return true;
    }

    bool r_Step_1() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_1, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                if (!r_R1())
                {
                    return false;
                }
                {
                    int v_1 = limit - cursor;
                    lab0: while (true) {
                        if (!(eq_s_b("t")))
                        {
                            break lab0;
                        }
                        if (!r_R1())
                        {
                            break lab0;
                        }
                        return false;
                    }
                    cursor = limit - v_1;
                }
                if (!r_C())
                {
                    return false;
                }
                slice_del();
                break;
            case 3:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("ie");
                break;
            case 4:
                lab1: while (true) {
                    int v_2 = limit - cursor;
                    lab2: while (true) {
                        int v_3 = limit - cursor;
                        if (!(eq_s_b("ar")))
                        {
                            break lab2;
                        }
                        if (!r_R1())
                        {
                            break lab2;
                        }
                        if (!r_C())
                        {
                            break lab2;
                        }
                        cursor = limit - v_3;
                        slice_del();
                        r_lengthen_V();
                        break lab1;
                    }
                    cursor = limit - v_2;
                    lab3: while (true) {
                        int v_4 = limit - cursor;
                        if (!(eq_s_b("er")))
                        {
                            break lab3;
                        }
                        if (!r_R1())
                        {
                            break lab3;
                        }
                        if (!r_C())
                        {
                            break lab3;
                        }
                        cursor = limit - v_4;
                        slice_del();
                        break lab1;
                    }
                    cursor = limit - v_2;
                    if (!r_R1())
                    {
                        return false;
                    }
                    if (!r_C())
                    {
                        return false;
                    }
                    slice_from("e");
                    break lab1;
                }
                break;
            case 5:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("\u00E9");
                break;
            case 6:
                if (!r_R1())
                {
                    return false;
                }
                if (!r_V())
                {
                    return false;
                }
                slice_from("au");
                break;
            case 7:
                lab4: while (true) {
                    int v_5 = limit - cursor;
                    lab5: while (true) {
                        if (!(eq_s_b("hed")))
                        {
                            break lab5;
                        }
                        if (!r_R1())
                        {
                            break lab5;
                        }
                        bra = cursor;
                        slice_from("heid");
                        break lab4;
                    }
                    cursor = limit - v_5;
                    lab6: while (true) {
                        if (!(eq_s_b("nd")))
                        {
                            break lab6;
                        }
                        slice_del();
                        break lab4;
                    }
                    cursor = limit - v_5;
                    lab7: while (true) {
                        if (!(eq_s_b("d")))
                        {
                            break lab7;
                        }
                        if (!r_R1())
                        {
                            break lab7;
                        }
                        if (!r_C())
                        {
                            break lab7;
                        }
                        bra = cursor;
                        slice_del();
                        break lab4;
                    }
                    cursor = limit - v_5;
                    lab8: while (true) {
                        lab9: while (true) {
                            lab10: while (true) {
                                if (!(eq_s_b("i")))
                                {
                                    break lab10;
                                }
                                break lab9;
                            }
                            if (!(eq_s_b("j")))
                            {
                                break lab8;
                            }
                            break lab9;
                        }
                        if (!r_V())
                        {
                            break lab8;
                        }
                        slice_del();
                        break lab4;
                    }
                    cursor = limit - v_5;
                    if (!r_R1())
                    {
                        return false;
                    }
                    if (!r_C())
                    {
                        return false;
                    }
                    slice_del();
                    r_lengthen_V();
                    break lab4;
                }
                break;
            case 8:
                slice_from("nd");
                break;
        }
        return true;
    }

    bool r_Step_2() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    int v_1 = limit - cursor;
                    lab1: while (true) {
                        if (!(eq_s_b("'t")))
                        {
                            break lab1;
                        }
                        bra = cursor;
                        slice_del();
                        break lab0;
                    }
                    cursor = limit - v_1;
                    lab2: while (true) {
                        if (!(eq_s_b("et")))
                        {
                            break lab2;
                        }
                        bra = cursor;
                        if (!r_R1())
                        {
                            break lab2;
                        }
                        if (!r_C())
                        {
                            break lab2;
                        }
                        slice_del();
                        break lab0;
                    }
                    cursor = limit - v_1;
                    lab3: while (true) {
                        if (!(eq_s_b("rnt")))
                        {
                            break lab3;
                        }
                        bra = cursor;
                        slice_from("rn");
                        break lab0;
                    }
                    cursor = limit - v_1;
                    lab4: while (true) {
                        if (!(eq_s_b("t")))
                        {
                            break lab4;
                        }
                        bra = cursor;
                        if (!r_R1())
                        {
                            break lab4;
                        }
                        if (!r_VX())
                        {
                            break lab4;
                        }
                        slice_del();
                        break lab0;
                    }
                    cursor = limit - v_1;
                    lab5: while (true) {
                        if (!(eq_s_b("ink")))
                        {
                            break lab5;
                        }
                        bra = cursor;
                        slice_from("ing");
                        break lab0;
                    }
                    cursor = limit - v_1;
                    lab6: while (true) {
                        if (!(eq_s_b("mp")))
                        {
                            break lab6;
                        }
                        bra = cursor;
                        slice_from("m");
                        break lab0;
                    }
                    cursor = limit - v_1;
                    lab7: while (true) {
                        if (!(eq_s_b("'")))
                        {
                            break lab7;
                        }
                        bra = cursor;
                        if (!r_R1())
                        {
                            break lab7;
                        }
                        slice_del();
                        break lab0;
                    }
                    cursor = limit - v_1;
                    bra = cursor;
                    if (!r_R1())
                    {
                        return false;
                    }
                    if (!r_C())
                    {
                        return false;
                    }
                    slice_del();
                    break lab0;
                }
                break;
            case 2:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("g");
                break;
            case 3:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("lijk");
                break;
            case 4:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("isch");
                break;
            case 5:
                if (!r_R1())
                {
                    return false;
                }
                if (!r_C())
                {
                    return false;
                }
                slice_del();
                break;
            case 6:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("t");
                break;
            case 7:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("s");
                break;
            case 8:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("r");
                break;
            case 9:
                if (!r_R1())
                {
                    return false;
                }
                slice_del();
                insert(cursor, cursor, "l");
                r_lengthen_V();
                break;
            case 10:
                if (!r_R1())
                {
                    return false;
                }
                if (!r_C())
                {
                    return false;
                }
                slice_del();
                insert(cursor, cursor, "en");
                r_lengthen_V();
                break;
            case 11:
                if (!r_R1())
                {
                    return false;
                }
                if (!r_C())
                {
                    return false;
                }
                slice_from("ief");
                break;
        }
        return true;
    }

    bool r_Step_3() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_3, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("eer");
                break;
            case 2:
                if (!r_R1())
                {
                    return false;
                }
                slice_del();
                r_lengthen_V();
                break;
            case 3:
                if (!r_R1())
                {
                    return false;
                }
                slice_del();
                break;
            case 4:
                slice_from("r");
                break;
            case 5:
                lab0: while (true) {
                    int v_1 = limit - cursor;
                    lab1: while (true) {
                        if (!(eq_s_b("ild")))
                        {
                            break lab1;
                        }
                        slice_from("er");
                        break lab0;
                    }
                    cursor = limit - v_1;
                    if (!r_R1())
                    {
                        return false;
                    }
                    slice_del();
                    r_lengthen_V();
                    break lab0;
                }
                break;
            case 6:
                if (!r_R1())
                {
                    return false;
                }
                if (!r_C())
                {
                    return false;
                }
                slice_from("aar");
                break;
            case 7:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                insert(cursor, cursor, "f");
                r_lengthen_V();
                break;
            case 8:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                insert(cursor, cursor, "g");
                r_lengthen_V();
                break;
            case 9:
                if (!r_R1())
                {
                    return false;
                }
                if (!r_C())
                {
                    return false;
                }
                slice_from("t");
                break;
            case 10:
                if (!r_R1())
                {
                    return false;
                }
                if (!r_C())
                {
                    return false;
                }
                slice_from("d");
                break;
        }
        return true;
    }

    bool r_Step_4() {
        int among_var;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                among_var = find_among_b(a_4, null);
                if (among_var == 0)
                {
                    break lab1;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (!r_R1())
                        {
                            break lab1;
                        }
                        slice_from("ie");
                        break;
                    case 2:
                        if (!r_R1())
                        {
                            break lab1;
                        }
                        slice_from("eer");
                        break;
                    case 3:
                        if (!r_R1())
                        {
                            break lab1;
                        }
                        slice_del();
                        break;
                    case 4:
                        if (!r_R1())
                        {
                            break lab1;
                        }
                        if (!r_V())
                        {
                            break lab1;
                        }
                        slice_from("n");
                        break;
                    case 5:
                        if (!r_R1())
                        {
                            break lab1;
                        }
                        if (!r_V())
                        {
                            break lab1;
                        }
                        slice_from("l");
                        break;
                    case 6:
                        if (!r_R1())
                        {
                            break lab1;
                        }
                        if (!r_V())
                        {
                            break lab1;
                        }
                        slice_from("r");
                        break;
                    case 7:
                        if (!r_R1())
                        {
                            break lab1;
                        }
                        slice_from("teer");
                        break;
                    case 8:
                        if (!r_R1())
                        {
                            break lab1;
                        }
                        slice_from("lijk");
                        break;
                    case 9:
                        if (!r_R1())
                        {
                            break lab1;
                        }
                        if (!r_C())
                        {
                            break lab1;
                        }
                        slice_del();
                        r_lengthen_V();
                        break;
                }
                break lab0;
            }
            cursor = limit - v_1;
            ket = cursor;
            if (find_among_b(a_5, null) == 0)
            {
                return false;
            }
            bra = cursor;
            if (!r_R1())
            {
                return false;
            }
            {
                int v_2 = limit - cursor;
                lab2: while (true) {
                    if (!(eq_s_b("inn")))
                    {
                        break lab2;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab2;
                    }
                    return false;
                }
                cursor = limit - v_2;
            }
            if (!r_C())
            {
                return false;
            }
            slice_del();
            r_lengthen_V();
            break lab0;
        }
        return true;
    }

    bool r_Step_7() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_6, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("k");
                break;
            case 2:
                slice_from("f");
                break;
            case 3:
                slice_from("p");
                break;
        }
        return true;
    }

    bool r_Step_6() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_7, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("b");
                break;
            case 2:
                slice_from("c");
                break;
            case 3:
                slice_from("d");
                break;
            case 4:
                slice_from("f");
                break;
            case 5:
                slice_from("g");
                break;
            case 6:
                slice_from("h");
                break;
            case 7:
                slice_from("j");
                break;
            case 8:
                slice_from("k");
                break;
            case 9:
                slice_from("l");
                break;
            case 10:
                slice_from("m");
                break;
            case 11:
                {
                    int v_1 = limit - cursor;
                    lab0: while (true) {
                        if (!(eq_s_b("i")))
                        {
                            break lab0;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab0;
                        }
                        return false;
                    }
                    cursor = limit - v_1;
                }
                slice_from("n");
                break;
            case 12:
                slice_from("p");
                break;
            case 13:
                slice_from("q");
                break;
            case 14:
                slice_from("r");
                break;
            case 15:
                slice_from("s");
                break;
            case 16:
                slice_from("t");
                break;
            case 17:
                slice_from("v");
                break;
            case 18:
                slice_from("w");
                break;
            case 19:
                slice_from("x");
                break;
            case 20:
                slice_from("z");
                break;
        }
        return true;
    }

    bool r_Step_1c() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_8, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        if (!r_C())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                {
                    int v_1 = limit - cursor;
                    lab0: while (true) {
                        if (!(eq_s_b("n")))
                        {
                            break lab0;
                        }
                        if (!r_R1())
                        {
                            break lab0;
                        }
                        return false;
                    }
                    cursor = limit - v_1;
                }
                lab1: while (true) {
                    int v_2 = limit - cursor;
                    lab2: while (true) {
                        if (!(eq_s_b("in")))
                        {
                            break lab2;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab2;
                        }
                        slice_from("n");
                        break lab1;
                    }
                    cursor = limit - v_2;
                    slice_del();
                    break lab1;
                }
                break;
            case 2:
                {
                    int v_3 = limit - cursor;
                    lab3: while (true) {
                        if (!(eq_s_b("h")))
                        {
                            break lab3;
                        }
                        if (!r_R1())
                        {
                            break lab3;
                        }
                        return false;
                    }
                    cursor = limit - v_3;
                }
                {
                    int v_4 = limit - cursor;
                    lab4: while (true) {
                        if (!(eq_s_b("en")))
                        {
                            break lab4;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        return false;
                    }
                    cursor = limit - v_4;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_Lose_prefix() {
        int among_var;
        bra = cursor;
        if (!(eq_s("ge")))
        {
            return false;
        }
        ket = cursor;
        int v_1 = cursor;
        {
            int c = cursor + 3;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        cursor = v_1;
        int v_2 = cursor;
        golab0: while(true)
        {
            int v_3 = cursor;
            lab1: while (true) {
                lab2: while (true) {
                    lab3: while (true) {
                        if (!(eq_s("ij")))
                        {
                            break lab3;
                        }
                        break lab2;
                    }
                    if (!(in_grouping(g_v, 97, 252)))
                    {
                        break lab1;
                    }
                    break lab2;
                }
                break golab0;
            }
            cursor = v_3;
            if (cursor >= limit)
            {
                return false;
            }
            cursor++;
        }
        replab4: while(true)
        {
            int v_4 = cursor;
            lab5: while (true) {
                lab6: while (true) {
                    lab7: while (true) {
                        if (!(eq_s("ij")))
                        {
                            break lab7;
                        }
                        break lab6;
                    }
                    if (!(in_grouping(g_v, 97, 252)))
                    {
                        break lab5;
                    }
                    break lab6;
                }
                continue replab4;
            }
            cursor = v_4;
            break replab4;
        }
        if (cursor >= limit)
        {
            return false;
        }
        cursor = v_2;
        among_var = find_among(a_9, null);
        switch (among_var) {
            case 1:
                return false;
        }
        B_GE_removed = true;
        slice_del();
        int v_5 = cursor;
        lab8: while (true) {
            bra = cursor;
            among_var = find_among(a_10, null);
            if (among_var == 0)
            {
                break lab8;
            }
            ket = cursor;
            switch (among_var) {
                case 1:
                    slice_from("e");
                    break;
                case 2:
                    slice_from("i");
                    break;
            }
            break lab8;
        }
        cursor = v_5;
        return true;
    }

    bool r_Lose_infix() {
        int among_var;
        if (cursor >= limit)
        {
            return false;
        }
        cursor++;
        golab0: while(true)
        {
            lab1: while (true) {
                bra = cursor;
                if (!(eq_s("ge")))
                {
                    break lab1;
                }
                ket = cursor;
                break golab0;
            }
            if (cursor >= limit)
            {
                return false;
            }
            cursor++;
        }
        int v_1 = cursor;
        {
            int c = cursor + 3;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        cursor = v_1;
        int v_2 = cursor;
        golab2: while(true)
        {
            int v_3 = cursor;
            lab3: while (true) {
                lab4: while (true) {
                    lab5: while (true) {
                        if (!(eq_s("ij")))
                        {
                            break lab5;
                        }
                        break lab4;
                    }
                    if (!(in_grouping(g_v, 97, 252)))
                    {
                        break lab3;
                    }
                    break lab4;
                }
                break golab2;
            }
            cursor = v_3;
            if (cursor >= limit)
            {
                return false;
            }
            cursor++;
        }
        replab6: while(true)
        {
            int v_4 = cursor;
            lab7: while (true) {
                lab8: while (true) {
                    lab9: while (true) {
                        if (!(eq_s("ij")))
                        {
                            break lab9;
                        }
                        break lab8;
                    }
                    if (!(in_grouping(g_v, 97, 252)))
                    {
                        break lab7;
                    }
                    break lab8;
                }
                continue replab6;
            }
            cursor = v_4;
            break replab6;
        }
        if (cursor >= limit)
        {
            return false;
        }
        cursor = v_2;
        B_GE_removed = true;
        slice_del();
        int v_5 = cursor;
        lab10: while (true) {
            bra = cursor;
            among_var = find_among(a_11, null);
            if (among_var == 0)
            {
                break lab10;
            }
            ket = cursor;
            switch (among_var) {
                case 1:
                    slice_from("e");
                    break;
                case 2:
                    slice_from("i");
                    break;
            }
            break lab10;
        }
        cursor = v_5;
        return true;
    }

    bool r_measure() {
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                lab2: while (true) {
                    if (!(out_grouping(g_v, 97, 252)))
                    {
                        break lab2;
                    }
                    continue replab1;
                }
                break replab1;
            }
            {
                int v_2 = 1;
                replab3: while(true)
                {
                    int v_3 = cursor;
                    lab4: while (true) {
                        lab5: while (true) {
                            lab6: while (true) {
                                if (!(eq_s("ij")))
                                {
                                    break lab6;
                                }
                                break lab5;
                            }
                            if (!(in_grouping(g_v, 97, 252)))
                            {
                                break lab4;
                            }
                            break lab5;
                        }
                        v_2--;
                        continue replab3;
                    }
                    cursor = v_3;
                    break replab3;
                }
                if (v_2 > 0)
                {
                    break lab0;
                }
            }
            if (!(out_grouping(g_v, 97, 252)))
            {
                break lab0;
            }
            I_p1 = cursor;
            replab7: while(true)
            {
                lab8: while (true) {
                    if (!(out_grouping(g_v, 97, 252)))
                    {
                        break lab8;
                    }
                    continue replab7;
                }
                break replab7;
            }
            {
                int v_4 = 1;
                replab9: while(true)
                {
                    int v_5 = cursor;
                    lab10: while (true) {
                        lab11: while (true) {
                            lab12: while (true) {
                                if (!(eq_s("ij")))
                                {
                                    break lab12;
                                }
                                break lab11;
                            }
                            if (!(in_grouping(g_v, 97, 252)))
                            {
                                break lab10;
                            }
                            break lab11;
                        }
                        v_4--;
                        continue replab9;
                    }
                    cursor = v_5;
                    break replab9;
                }
                if (v_4 > 0)
                {
                    break lab0;
                }
            }
            if (!(out_grouping(g_v, 97, 252)))
            {
                break lab0;
            }
            I_p2 = cursor;
            break lab0;
        }
        cursor = v_1;
        return true;
    }

    @override
    bool stem() {
        bool B_stemmed;
        B_stemmed = false;
        r_measure();
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        lab0: while (true) {
            if (!r_Step_1())
            {
                break lab0;
            }
            B_stemmed = true;
            break lab0;
        }
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        lab1: while (true) {
            if (!r_Step_2())
            {
                break lab1;
            }
            B_stemmed = true;
            break lab1;
        }
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        lab2: while (true) {
            if (!r_Step_3())
            {
                break lab2;
            }
            B_stemmed = true;
            break lab2;
        }
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        lab3: while (true) {
            if (!r_Step_4())
            {
                break lab3;
            }
            B_stemmed = true;
            break lab3;
        }
        cursor = limit - v_4;
        cursor = limit_backward;
        B_GE_removed = false;
        int v_5 = cursor;
        lab4: while (true) {
            int v_6 = cursor;
            if (!r_Lose_prefix())
            {
                break lab4;
            }
            cursor = v_6;
            r_measure();
            break lab4;
        }
        cursor = v_5;
        limit_backward = cursor;
        cursor = limit;
        int v_7 = limit - cursor;
        lab5: while (true) {
            if (!B_GE_removed)
            {
                break lab5;
            }
            B_stemmed = true;
            if (!r_Step_1c())
            {
                break lab5;
            }
            break lab5;
        }
        cursor = limit - v_7;
        cursor = limit_backward;
        B_GE_removed = false;
        int v_8 = cursor;
        lab6: while (true) {
            int v_9 = cursor;
            if (!r_Lose_infix())
            {
                break lab6;
            }
            cursor = v_9;
            r_measure();
            break lab6;
        }
        cursor = v_8;
        limit_backward = cursor;
        cursor = limit;
        int v_10 = limit - cursor;
        lab7: while (true) {
            if (!B_GE_removed)
            {
                break lab7;
            }
            B_stemmed = true;
            if (!r_Step_1c())
            {
                break lab7;
            }
            break lab7;
        }
        cursor = limit - v_10;
        cursor = limit_backward;
        limit_backward = cursor;
        cursor = limit;
        int v_11 = limit - cursor;
        lab8: while (true) {
            if (!r_Step_7())
            {
                break lab8;
            }
            B_stemmed = true;
            break lab8;
        }
        cursor = limit - v_11;
        int v_12 = limit - cursor;
        lab9: while (true) {
            if (!B_stemmed)
            {
                break lab9;
            }
            if (!r_Step_6())
            {
                break lab9;
            }
            break lab9;
        }
        cursor = limit - v_12;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is dutch_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
