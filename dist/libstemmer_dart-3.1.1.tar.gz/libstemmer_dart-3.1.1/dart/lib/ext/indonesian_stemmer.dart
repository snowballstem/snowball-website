// Generated from indonesian.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from indonesian.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class indonesian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("kah", -1, 1, 0),
        Among("lah", -1, 1, 0),
        Among("pun", -1, 1, 0)
    ];

    static final a_1 = [
        Among("nya", -1, 1, 0),
        Among("ku", -1, 1, 0),
        Among("mu", -1, 1, 0)
    ];

    static final a_2 = [
        Among("i", -1, 2, 0),
        Among("an", -1, 1, 0)
    ];

    static final a_3 = [
        Among("di", -1, 1, 0),
        Among("ke", -1, 3, 0),
        Among("me", -1, 1, 0),
        Among("mem", 2, 5, 0),
        Among("men", 2, 2, 0),
        Among("meng", 4, 1, 0),
        Among("pem", -1, 6, 0),
        Among("pen", -1, 4, 0),
        Among("peng", 7, 3, 0),
        Among("ter", -1, 1, 0)
    ];

    static final a_4 = [
        Among("be", -1, 2, 0),
        Among("pe", -1, 1, 0)
    ];

    static final g_vowel = String.fromCharCodes([17, 65, 16]);

    int I_prefix = 0;
    int I_measure = 0;


    bool r_remove_particle() {
        ket = cursor;
        if (find_among_b(a_0, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        I_measure -= 1;
        return true;
    }

    bool r_remove_possessive_pronoun() {
        ket = cursor;
        if (find_among_b(a_1, null) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        I_measure -= 1;
        return true;
    }

    bool r_remove_suffix() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    int v_1 = limit - cursor;
                    lab1: while (true) {
                        if (I_prefix == 3)
                        {
                            break lab1;
                        }
                        if (I_prefix == 2)
                        {
                            break lab1;
                        }
                        if (!(eq_s_b("k")))
                        {
                            break lab1;
                        }
                        bra = cursor;
                        break lab0;
                    }
                    cursor = limit - v_1;
                    if (I_prefix == 1)
                    {
                        return false;
                    }
                    break lab0;
                }
                break;
            case 2:
                if (I_prefix > 2)
                {
                    return false;
                }
                lab2: while (true) {
                    if (!(eq_s_b("s")))
                    {
                        break lab2;
                    }
                    return false;
                }
                break;
        }
        slice_del();
        I_measure -= 1;
        return true;
    }

    bool r_remove_first_order_prefix() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_3, null);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        switch (among_var) {
            case 1:
                slice_del();
                I_prefix = 1;
                I_measure -= 1;
                break;
            case 2:
                lab0: while (true) {
                    int v_1 = cursor;
                    lab1: while (true) {
                        if (!(eq_s("y")))
                        {
                            break lab1;
                        }
                        int v_2 = cursor;
                        if (!(in_grouping(g_vowel, 97, 117)))
                        {
                            break lab1;
                        }
                        cursor = v_2;
                        ket = cursor;
                        slice_from("s");
                        I_prefix = 1;
                        I_measure -= 1;
                        break lab0;
                    }
                    cursor = v_1;
                    slice_del();
                    I_prefix = 1;
                    I_measure -= 1;
                    break lab0;
                }
                break;
            case 3:
                slice_del();
                I_prefix = 3;
                I_measure -= 1;
                break;
            case 4:
                lab2: while (true) {
                    int v_3 = cursor;
                    lab3: while (true) {
                        if (!(eq_s("y")))
                        {
                            break lab3;
                        }
                        int v_4 = cursor;
                        if (!(in_grouping(g_vowel, 97, 117)))
                        {
                            break lab3;
                        }
                        cursor = v_4;
                        ket = cursor;
                        slice_from("s");
                        I_prefix = 3;
                        I_measure -= 1;
                        break lab2;
                    }
                    cursor = v_3;
                    slice_del();
                    I_prefix = 3;
                    I_measure -= 1;
                    break lab2;
                }
                break;
            case 5:
                I_prefix = 1;
                I_measure -= 1;
                lab4: while (true) {
                    int v_5 = cursor;
                    lab5: while (true) {
                        int v_6 = cursor;
                        if (!(in_grouping(g_vowel, 97, 117)))
                        {
                            break lab5;
                        }
                        cursor = v_6;
                        slice_from("p");
                        break lab4;
                    }
                    cursor = v_5;
                    slice_del();
                    break lab4;
                }
                break;
            case 6:
                I_prefix = 3;
                I_measure -= 1;
                lab6: while (true) {
                    int v_7 = cursor;
                    lab7: while (true) {
                        int v_8 = cursor;
                        if (!(in_grouping(g_vowel, 97, 117)))
                        {
                            break lab7;
                        }
                        cursor = v_8;
                        slice_from("p");
                        break lab6;
                    }
                    cursor = v_7;
                    slice_del();
                    break lab6;
                }
                break;
        }
        return true;
    }

    bool r_remove_second_order_prefix() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_4, null);
        if (among_var == 0)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    int v_1 = cursor;
                    lab1: while (true) {
                        if (!(eq_s("r")))
                        {
                            break lab1;
                        }
                        ket = cursor;
                        I_prefix = 2;
                        break lab0;
                    }
                    cursor = v_1;
                    lab2: while (true) {
                        if (!(eq_s("l")))
                        {
                            break lab2;
                        }
                        ket = cursor;
                        if (!(eq_s("ajar")))
                        {
                            break lab2;
                        }
                        break lab0;
                    }
                    cursor = v_1;
                    ket = cursor;
                    I_prefix = 2;
                    break lab0;
                }
                break;
            case 2:
                lab3: while (true) {
                    int v_2 = cursor;
                    lab4: while (true) {
                        if (!(eq_s("r")))
                        {
                            break lab4;
                        }
                        ket = cursor;
                        break lab3;
                    }
                    cursor = v_2;
                    lab5: while (true) {
                        if (!(eq_s("l")))
                        {
                            break lab5;
                        }
                        ket = cursor;
                        if (!(eq_s("ajar")))
                        {
                            break lab5;
                        }
                        break lab3;
                    }
                    cursor = v_2;
                    ket = cursor;
                    if (!(out_grouping(g_vowel, 97, 117)))
                    {
                        return false;
                    }
                    if (!(eq_s("er")))
                    {
                        return false;
                    }
                    break lab3;
                }
                I_prefix = 4;
                break;
        }
        I_measure -= 1;
        slice_del();
        return true;
    }

    @override
    bool stem() {
        I_measure = 0;
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = cursor;
                lab2: while (true) {
                    if (!go_out_grouping(g_vowel, 97, 117))
                    {
                        break lab2;
                    }
                    cursor++;
                    I_measure += 1;
                    continue replab1;
                }
                cursor = v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = v_1;
        if (I_measure <= 2)
        {
            return false;
        }
        I_prefix = 0;
        limit_backward = cursor;
        cursor = limit;
        int v_3 = limit - cursor;
        r_remove_particle();
        cursor = limit - v_3;
        if (I_measure <= 2)
        {
            return false;
        }
        int v_4 = limit - cursor;
        r_remove_possessive_pronoun();
        cursor = limit - v_4;
        cursor = limit_backward;
        if (I_measure <= 2)
        {
            return false;
        }
        lab3: while (true) {
            int v_5 = cursor;
            lab4: while (true) {
                int v_6 = cursor;
                if (!r_remove_first_order_prefix())
                {
                    break lab4;
                }
                int v_7 = cursor;
                lab5: while (true) {
                    int v_8 = cursor;
                    if (I_measure <= 2)
                    {
                        break lab5;
                    }
                    limit_backward = cursor;
                    cursor = limit;
                    if (!r_remove_suffix())
                    {
                        break lab5;
                    }
                    cursor = limit_backward;
                    cursor = v_8;
                    if (I_measure <= 2)
                    {
                        break lab5;
                    }
                    if (!r_remove_second_order_prefix())
                    {
                        break lab5;
                    }
                    break lab5;
                }
                cursor = v_7;
                cursor = v_6;
                break lab3;
            }
            cursor = v_5;
            int v_9 = cursor;
            r_remove_second_order_prefix();
            cursor = v_9;
            int v_10 = cursor;
            lab6: while (true) {
                if (I_measure <= 2)
                {
                    break lab6;
                }
                limit_backward = cursor;
                cursor = limit;
                if (!r_remove_suffix())
                {
                    break lab6;
                }
                cursor = limit_backward;
                break lab6;
            }
            cursor = v_10;
            break lab3;
        }
        return true;
    }

    @override
    bool operator ==(Object other) => other is indonesian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
