// Generated from serbian.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from serbian.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class serbian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("\u0430", -1, 1, 0),
        Among("\u0431", -1, 2, 0),
        Among("\u0432", -1, 3, 0),
        Among("\u0433", -1, 4, 0),
        Among("\u0434", -1, 5, 0),
        Among("\u0435", -1, 7, 0),
        Among("\u0436", -1, 8, 0),
        Among("\u0437", -1, 9, 0),
        Among("\u0438", -1, 10, 0),
        Among("\u043A", -1, 12, 0),
        Among("\u043B", -1, 13, 0),
        Among("\u043C", -1, 15, 0),
        Among("\u043D", -1, 16, 0),
        Among("\u043E", -1, 18, 0),
        Among("\u043F", -1, 19, 0),
        Among("\u0440", -1, 20, 0),
        Among("\u0441", -1, 21, 0),
        Among("\u0442", -1, 22, 0),
        Among("\u0443", -1, 24, 0),
        Among("\u0444", -1, 25, 0),
        Among("\u0445", -1, 26, 0),
        Among("\u0446", -1, 27, 0),
        Among("\u0447", -1, 28, 0),
        Among("\u0448", -1, 30, 0),
        Among("\u0452", -1, 6, 0),
        Among("\u0458", -1, 11, 0),
        Among("\u0459", -1, 14, 0),
        Among("\u045A", -1, 17, 0),
        Among("\u045B", -1, 23, 0),
        Among("\u045F", -1, 29, 0)
    ];

    static final a_1 = [
        Among("daba", -1, 73, 0),
        Among("ajaca", -1, 12, 0),
        Among("ejaca", -1, 14, 0),
        Among("ljaca", -1, 13, 0),
        Among("njaca", -1, 85, 0),
        Among("ojaca", -1, 15, 0),
        Among("alaca", -1, 82, 0),
        Among("elaca", -1, 83, 0),
        Among("olaca", -1, 84, 0),
        Among("maca", -1, 75, 0),
        Among("naca", -1, 76, 0),
        Among("raca", -1, 81, 0),
        Among("saca", -1, 80, 0),
        Among("vaca", -1, 79, 0),
        Among("\u0161aca", -1, 18, 0),
        Among("aoca", -1, 82, 0),
        Among("acaka", -1, 55, 0),
        Among("ajaka", -1, 16, 0),
        Among("ojaka", -1, 17, 0),
        Among("anaka", -1, 78, 0),
        Among("ataka", -1, 58, 0),
        Among("etaka", -1, 59, 0),
        Among("itaka", -1, 60, 0),
        Among("otaka", -1, 61, 0),
        Among("utaka", -1, 62, 0),
        Among("a\u010Daka", -1, 54, 0),
        Among("esama", -1, 67, 0),
        Among("izama", -1, 87, 0),
        Among("jacima", -1, 5, 0),
        Among("nicima", -1, 23, 0),
        Among("ticima", -1, 24, 0),
        Among("teticima", 30, 21, 0),
        Among("zicima", -1, 25, 0),
        Among("atcima", -1, 58, 0),
        Among("utcima", -1, 62, 0),
        Among("\u010Dcima", -1, 74, 0),
        Among("pesima", -1, 2, 0),
        Among("inzima", -1, 19, 0),
        Among("lozima", -1, 1, 0),
        Among("metara", -1, 68, 0),
        Among("centara", -1, 69, 0),
        Among("istara", -1, 70, 0),
        Among("ekata", -1, 86, 0),
        Among("anata", -1, 53, 0),
        Among("nstava", -1, 22, 0),
        Among("kustava", -1, 29, 0),
        Among("ajac", -1, 12, 0),
        Among("ejac", -1, 14, 0),
        Among("ljac", -1, 13, 0),
        Among("njac", -1, 85, 0),
        Among("anjac", 49, 11, 0),
        Among("ojac", -1, 15, 0),
        Among("alac", -1, 82, 0),
        Among("elac", -1, 83, 0),
        Among("olac", -1, 84, 0),
        Among("mac", -1, 75, 0),
        Among("nac", -1, 76, 0),
        Among("rac", -1, 81, 0),
        Among("sac", -1, 80, 0),
        Among("vac", -1, 79, 0),
        Among("\u0161ac", -1, 18, 0),
        Among("jebe", -1, 88, 0),
        Among("olce", -1, 84, 0),
        Among("kuse", -1, 27, 0),
        Among("rave", -1, 42, 0),
        Among("save", -1, 52, 0),
        Among("\u0161ave", -1, 51, 0),
        Among("baci", -1, 89, 0),
        Among("jaci", -1, 5, 0),
        Among("tvenici", -1, 20, 0),
        Among("snici", -1, 26, 0),
        Among("tetici", -1, 21, 0),
        Among("bojci", -1, 4, 0),
        Among("vojci", -1, 3, 0),
        Among("ojsci", -1, 66, 0),
        Among("atci", -1, 58, 0),
        Among("itci", -1, 60, 0),
        Among("utci", -1, 62, 0),
        Among("\u010Dci", -1, 74, 0),
        Among("pesi", -1, 2, 0),
        Among("inzi", -1, 19, 0),
        Among("lozi", -1, 1, 0),
        Among("acak", -1, 55, 0),
        Among("usak", -1, 57, 0),
        Among("atak", -1, 58, 0),
        Among("etak", -1, 59, 0),
        Among("itak", -1, 60, 0),
        Among("otak", -1, 61, 0),
        Among("utak", -1, 62, 0),
        Among("a\u010Dak", -1, 54, 0),
        Among("u\u0161ak", -1, 56, 0),
        Among("izam", -1, 87, 0),
        Among("tican", -1, 65, 0),
        Among("cajan", -1, 7, 0),
        Among("\u010Dajan", -1, 6, 0),
        Among("voljan", -1, 77, 0),
        Among("eskan", -1, 63, 0),
        Among("alan", -1, 40, 0),
        Among("bilan", -1, 33, 0),
        Among("gilan", -1, 37, 0),
        Among("nilan", -1, 39, 0),
        Among("rilan", -1, 38, 0),
        Among("silan", -1, 36, 0),
        Among("tilan", -1, 34, 0),
        Among("avilan", -1, 35, 0),
        Among("laran", -1, 9, 0),
        Among("eran", -1, 8, 0),
        Among("asan", -1, 91, 0),
        Among("esan", -1, 10, 0),
        Among("dusan", -1, 31, 0),
        Among("kusan", -1, 28, 0),
        Among("atan", -1, 47, 0),
        Among("pletan", -1, 50, 0),
        Among("tetan", -1, 49, 0),
        Among("antan", -1, 32, 0),
        Among("pravan", -1, 44, 0),
        Among("stavan", -1, 43, 0),
        Among("sivan", -1, 46, 0),
        Among("tivan", -1, 45, 0),
        Among("ozan", -1, 41, 0),
        Among("ti\u010Dan", -1, 64, 0),
        Among("a\u0161an", -1, 90, 0),
        Among("du\u0161an", -1, 30, 0),
        Among("metar", -1, 68, 0),
        Among("centar", -1, 69, 0),
        Among("istar", -1, 70, 0),
        Among("ekat", -1, 86, 0),
        Among("enat", -1, 48, 0),
        Among("oscu", -1, 72, 0),
        Among("o\u0161\u0107u", -1, 71, 0)
    ];

    static final a_2 = [
        Among("aca", -1, 124, 0),
        Among("eca", -1, 125, 0),
        Among("uca", -1, 126, 0),
        Among("ga", -1, 20, 0),
        Among("acega", 3, 124, 0),
        Among("ecega", 3, 125, 0),
        Among("ucega", 3, 126, 0),
        Among("anjijega", 3, 84, 0),
        Among("enjijega", 3, 85, 0),
        Among("snjijega", 3, 122, 0),
        Among("\u0161njijega", 3, 86, 0),
        Among("kijega", 3, 95, 0),
        Among("skijega", 11, 1, 0),
        Among("\u0161kijega", 11, 2, 0),
        Among("elijega", 3, 83, 0),
        Among("nijega", 3, 13, 0),
        Among("osijega", 3, 123, 0),
        Among("atijega", 3, 120, 0),
        Among("evitijega", 3, 92, 0),
        Among("ovitijega", 3, 93, 0),
        Among("astijega", 3, 94, 0),
        Among("avijega", 3, 77, 0),
        Among("evijega", 3, 78, 0),
        Among("ivijega", 3, 79, 0),
        Among("ovijega", 3, 80, 0),
        Among("o\u0161ijega", 3, 91, 0),
        Among("anjega", 3, 84, 0),
        Among("enjega", 3, 85, 0),
        Among("snjega", 3, 122, 0),
        Among("\u0161njega", 3, 86, 0),
        Among("kega", 3, 95, 0),
        Among("skega", 30, 1, 0),
        Among("\u0161kega", 30, 2, 0),
        Among("elega", 3, 83, 0),
        Among("nega", 3, 13, 0),
        Among("anega", 34, 10, 0),
        Among("enega", 34, 87, 0),
        Among("snega", 34, 159, 0),
        Among("\u0161nega", 34, 88, 0),
        Among("osega", 3, 123, 0),
        Among("atega", 3, 120, 0),
        Among("evitega", 3, 92, 0),
        Among("ovitega", 3, 93, 0),
        Among("astega", 3, 94, 0),
        Among("avega", 3, 77, 0),
        Among("evega", 3, 78, 0),
        Among("ivega", 3, 79, 0),
        Among("ovega", 3, 80, 0),
        Among("a\u0107ega", 3, 14, 0),
        Among("e\u0107ega", 3, 15, 0),
        Among("u\u0107ega", 3, 16, 0),
        Among("o\u0161ega", 3, 91, 0),
        Among("acoga", 3, 124, 0),
        Among("ecoga", 3, 125, 0),
        Among("ucoga", 3, 126, 0),
        Among("anjoga", 3, 84, 0),
        Among("enjoga", 3, 85, 0),
        Among("snjoga", 3, 122, 0),
        Among("\u0161njoga", 3, 86, 0),
        Among("koga", 3, 95, 0),
        Among("skoga", 59, 1, 0),
        Among("\u0161koga", 59, 2, 0),
        Among("loga", 3, 19, 0),
        Among("eloga", 62, 83, 0),
        Among("noga", 3, 13, 0),
        Among("cinoga", 64, 137, 0),
        Among("\u010Dinoga", 64, 89, 0),
        Among("osoga", 3, 123, 0),
        Among("atoga", 3, 120, 0),
        Among("evitoga", 3, 92, 0),
        Among("ovitoga", 3, 93, 0),
        Among("astoga", 3, 94, 0),
        Among("avoga", 3, 77, 0),
        Among("evoga", 3, 78, 0),
        Among("ivoga", 3, 79, 0),
        Among("ovoga", 3, 80, 0),
        Among("a\u0107oga", 3, 14, 0),
        Among("e\u0107oga", 3, 15, 0),
        Among("u\u0107oga", 3, 16, 0),
        Among("o\u0161oga", 3, 91, 0),
        Among("uga", 3, 18, 0),
        Among("aja", -1, 109, 0),
        Among("caja", 81, 26, 0),
        Among("laja", 81, 30, 0),
        Among("raja", 81, 31, 0),
        Among("\u0107aja", 81, 28, 0),
        Among("\u010Daja", 81, 27, 0),
        Among("\u0111aja", 81, 29, 0),
        Among("bija", -1, 32, 0),
        Among("cija", -1, 33, 0),
        Among("dija", -1, 34, 0),
        Among("fija", -1, 40, 0),
        Among("gija", -1, 39, 0),
        Among("anjija", -1, 84, 0),
        Among("enjija", -1, 85, 0),
        Among("snjija", -1, 122, 0),
        Among("\u0161njija", -1, 86, 0),
        Among("kija", -1, 95, 0),
        Among("skija", 97, 1, 0),
        Among("\u0161kija", 97, 2, 0),
        Among("lija", -1, 24, 0),
        Among("elija", 100, 83, 0),
        Among("mija", -1, 37, 0),
        Among("nija", -1, 13, 0),
        Among("ganija", 103, 9, 0),
        Among("manija", 103, 6, 0),
        Among("panija", 103, 7, 0),
        Among("ranija", 103, 8, 0),
        Among("tanija", 103, 5, 0),
        Among("pija", -1, 41, 0),
        Among("rija", -1, 42, 0),
        Among("rarija", 110, 21, 0),
        Among("sija", -1, 23, 0),
        Among("osija", 112, 123, 0),
        Among("tija", -1, 44, 0),
        Among("atija", 114, 120, 0),
        Among("evitija", 114, 92, 0),
        Among("ovitija", 114, 93, 0),
        Among("otija", 114, 22, 0),
        Among("astija", 114, 94, 0),
        Among("avija", -1, 77, 0),
        Among("evija", -1, 78, 0),
        Among("ivija", -1, 79, 0),
        Among("ovija", -1, 80, 0),
        Among("zija", -1, 45, 0),
        Among("o\u0161ija", -1, 91, 0),
        Among("\u017Eija", -1, 38, 0),
        Among("anja", -1, 84, 0),
        Among("enja", -1, 85, 0),
        Among("snja", -1, 122, 0),
        Among("\u0161nja", -1, 86, 0),
        Among("ka", -1, 95, 0),
        Among("ska", 131, 1, 0),
        Among("\u0161ka", 131, 2, 0),
        Among("ala", -1, 104, 0),
        Among("acala", 134, 128, 0),
        Among("astajala", 134, 106, 0),
        Among("istajala", 134, 107, 0),
        Among("ostajala", 134, 108, 0),
        Among("ijala", 134, 47, 0),
        Among("injala", 134, 114, 0),
        Among("nala", 134, 46, 0),
        Among("irala", 134, 100, 0),
        Among("urala", 134, 105, 0),
        Among("tala", 134, 113, 0),
        Among("astala", 144, 110, 0),
        Among("istala", 144, 111, 0),
        Among("ostala", 144, 112, 0),
        Among("avala", 134, 97, 0),
        Among("evala", 134, 96, 0),
        Among("ivala", 134, 98, 0),
        Among("ovala", 134, 76, 0),
        Among("uvala", 134, 99, 0),
        Among("a\u010Dala", 134, 102, 0),
        Among("ela", -1, 83, 0),
        Among("ila", -1, 116, 0),
        Among("acila", 155, 124, 0),
        Among("lucila", 155, 121, 0),
        Among("nila", 155, 103, 0),
        Among("astanila", 158, 110, 0),
        Among("istanila", 158, 111, 0),
        Among("ostanila", 158, 112, 0),
        Among("rosila", 155, 127, 0),
        Among("jetila", 155, 118, 0),
        Among("ozila", 155, 48, 0),
        Among("a\u010Dila", 155, 101, 0),
        Among("lu\u010Dila", 155, 117, 0),
        Among("ro\u0161ila", 155, 90, 0),
        Among("ola", -1, 50, 0),
        Among("asla", -1, 115, 0),
        Among("nula", -1, 13, 0),
        Among("gama", -1, 20, 0),
        Among("logama", 171, 19, 0),
        Among("ugama", 171, 18, 0),
        Among("ajama", -1, 109, 0),
        Among("cajama", 174, 26, 0),
        Among("lajama", 174, 30, 0),
        Among("rajama", 174, 31, 0),
        Among("\u0107ajama", 174, 28, 0),
        Among("\u010Dajama", 174, 27, 0),
        Among("\u0111ajama", 174, 29, 0),
        Among("bijama", -1, 32, 0),
        Among("cijama", -1, 33, 0),
        Among("dijama", -1, 34, 0),
        Among("fijama", -1, 40, 0),
        Among("gijama", -1, 39, 0),
        Among("lijama", -1, 35, 0),
        Among("mijama", -1, 37, 0),
        Among("nijama", -1, 36, 0),
        Among("ganijama", 188, 9, 0),
        Among("manijama", 188, 6, 0),
        Among("panijama", 188, 7, 0),
        Among("ranijama", 188, 8, 0),
        Among("tanijama", 188, 5, 0),
        Among("pijama", -1, 41, 0),
        Among("rijama", -1, 42, 0),
        Among("sijama", -1, 43, 0),
        Among("tijama", -1, 44, 0),
        Among("zijama", -1, 45, 0),
        Among("\u017Eijama", -1, 38, 0),
        Among("alama", -1, 104, 0),
        Among("ijalama", 200, 47, 0),
        Among("nalama", 200, 46, 0),
        Among("elama", -1, 119, 0),
        Among("ilama", -1, 116, 0),
        Among("ramama", -1, 52, 0),
        Among("lemama", -1, 51, 0),
        Among("inama", -1, 11, 0),
        Among("cinama", 207, 137, 0),
        Among("\u010Dinama", 207, 89, 0),
        Among("rama", -1, 52, 0),
        Among("arama", 210, 53, 0),
        Among("drama", 210, 54, 0),
        Among("erama", 210, 55, 0),
        Among("orama", 210, 56, 0),
        Among("basama", -1, 135, 0),
        Among("gasama", -1, 131, 0),
        Among("jasama", -1, 129, 0),
        Among("kasama", -1, 133, 0),
        Among("nasama", -1, 132, 0),
        Among("tasama", -1, 130, 0),
        Among("vasama", -1, 134, 0),
        Among("esama", -1, 152, 0),
        Among("isama", -1, 154, 0),
        Among("etama", -1, 70, 0),
        Among("estama", -1, 71, 0),
        Among("istama", -1, 72, 0),
        Among("kstama", -1, 73, 0),
        Among("ostama", -1, 74, 0),
        Among("avama", -1, 77, 0),
        Among("evama", -1, 78, 0),
        Among("ivama", -1, 79, 0),
        Among("ba\u0161ama", -1, 63, 0),
        Among("ga\u0161ama", -1, 64, 0),
        Among("ja\u0161ama", -1, 61, 0),
        Among("ka\u0161ama", -1, 62, 0),
        Among("na\u0161ama", -1, 60, 0),
        Among("ta\u0161ama", -1, 59, 0),
        Among("va\u0161ama", -1, 65, 0),
        Among("e\u0161ama", -1, 66, 0),
        Among("i\u0161ama", -1, 67, 0),
        Among("lema", -1, 51, 0),
        Among("acima", -1, 124, 0),
        Among("ecima", -1, 125, 0),
        Among("ucima", -1, 126, 0),
        Among("ajima", -1, 109, 0),
        Among("cajima", 245, 26, 0),
        Among("lajima", 245, 30, 0),
        Among("rajima", 245, 31, 0),
        Among("\u0107ajima", 245, 28, 0),
        Among("\u010Dajima", 245, 27, 0),
        Among("\u0111ajima", 245, 29, 0),
        Among("bijima", -1, 32, 0),
        Among("cijima", -1, 33, 0),
        Among("dijima", -1, 34, 0),
        Among("fijima", -1, 40, 0),
        Among("gijima", -1, 39, 0),
        Among("anjijima", -1, 84, 0),
        Among("enjijima", -1, 85, 0),
        Among("snjijima", -1, 122, 0),
        Among("\u0161njijima", -1, 86, 0),
        Among("kijima", -1, 95, 0),
        Among("skijima", 261, 1, 0),
        Among("\u0161kijima", 261, 2, 0),
        Among("lijima", -1, 35, 0),
        Among("elijima", 264, 83, 0),
        Among("mijima", -1, 37, 0),
        Among("nijima", -1, 13, 0),
        Among("ganijima", 267, 9, 0),
        Among("manijima", 267, 6, 0),
        Among("panijima", 267, 7, 0),
        Among("ranijima", 267, 8, 0),
        Among("tanijima", 267, 5, 0),
        Among("pijima", -1, 41, 0),
        Among("rijima", -1, 42, 0),
        Among("sijima", -1, 43, 0),
        Among("osijima", 275, 123, 0),
        Among("tijima", -1, 44, 0),
        Among("atijima", 277, 120, 0),
        Among("evitijima", 277, 92, 0),
        Among("ovitijima", 277, 93, 0),
        Among("astijima", 277, 94, 0),
        Among("avijima", -1, 77, 0),
        Among("evijima", -1, 78, 0),
        Among("ivijima", -1, 79, 0),
        Among("ovijima", -1, 80, 0),
        Among("zijima", -1, 45, 0),
        Among("o\u0161ijima", -1, 91, 0),
        Among("\u017Eijima", -1, 38, 0),
        Among("anjima", -1, 84, 0),
        Among("enjima", -1, 85, 0),
        Among("snjima", -1, 122, 0),
        Among("\u0161njima", -1, 86, 0),
        Among("kima", -1, 95, 0),
        Among("skima", 293, 1, 0),
        Among("\u0161kima", 293, 2, 0),
        Among("alima", -1, 104, 0),
        Among("ijalima", 296, 47, 0),
        Among("nalima", 296, 46, 0),
        Among("elima", -1, 83, 0),
        Among("ilima", -1, 116, 0),
        Among("ozilima", 300, 48, 0),
        Among("olima", -1, 50, 0),
        Among("lemima", -1, 51, 0),
        Among("nima", -1, 13, 0),
        Among("anima", 304, 10, 0),
        Among("inima", 304, 11, 0),
        Among("cinima", 306, 137, 0),
        Among("\u010Dinima", 306, 89, 0),
        Among("onima", 304, 12, 0),
        Among("arima", -1, 53, 0),
        Among("drima", -1, 54, 0),
        Among("erima", -1, 55, 0),
        Among("orima", -1, 56, 0),
        Among("basima", -1, 135, 0),
        Among("gasima", -1, 131, 0),
        Among("jasima", -1, 129, 0),
        Among("kasima", -1, 133, 0),
        Among("nasima", -1, 132, 0),
        Among("tasima", -1, 130, 0),
        Among("vasima", -1, 134, 0),
        Among("esima", -1, 57, 0),
        Among("isima", -1, 58, 0),
        Among("osima", -1, 123, 0),
        Among("atima", -1, 120, 0),
        Among("ikatima", 324, 68, 0),
        Among("latima", 324, 69, 0),
        Among("etima", -1, 70, 0),
        Among("evitima", -1, 92, 0),
        Among("ovitima", -1, 93, 0),
        Among("astima", -1, 94, 0),
        Among("estima", -1, 71, 0),
        Among("istima", -1, 72, 0),
        Among("kstima", -1, 73, 0),
        Among("ostima", -1, 74, 0),
        Among("i\u0161tima", -1, 75, 0),
        Among("avima", -1, 77, 0),
        Among("evima", -1, 78, 0),
        Among("ajevima", 337, 109, 0),
        Among("cajevima", 338, 26, 0),
        Among("lajevima", 338, 30, 0),
        Among("rajevima", 338, 31, 0),
        Among("\u0107ajevima", 338, 28, 0),
        Among("\u010Dajevima", 338, 27, 0),
        Among("\u0111ajevima", 338, 29, 0),
        Among("ivima", -1, 79, 0),
        Among("ovima", -1, 80, 0),
        Among("govima", 346, 20, 0),
        Among("ugovima", 347, 17, 0),
        Among("lovima", 346, 82, 0),
        Among("olovima", 349, 49, 0),
        Among("movima", 346, 81, 0),
        Among("onovima", 346, 12, 0),
        Among("stvima", -1, 3, 0),
        Among("\u0161tvima", -1, 4, 0),
        Among("a\u0107ima", -1, 14, 0),
        Among("e\u0107ima", -1, 15, 0),
        Among("u\u0107ima", -1, 16, 0),
        Among("ba\u0161ima", -1, 63, 0),
        Among("ga\u0161ima", -1, 64, 0),
        Among("ja\u0161ima", -1, 61, 0),
        Among("ka\u0161ima", -1, 62, 0),
        Among("na\u0161ima", -1, 60, 0),
        Among("ta\u0161ima", -1, 59, 0),
        Among("va\u0161ima", -1, 65, 0),
        Among("e\u0161ima", -1, 66, 0),
        Among("i\u0161ima", -1, 67, 0),
        Among("o\u0161ima", -1, 91, 0),
        Among("na", -1, 13, 0),
        Among("ana", 368, 10, 0),
        Among("acana", 369, 128, 0),
        Among("urana", 369, 105, 0),
        Among("tana", 369, 113, 0),
        Among("avana", 369, 97, 0),
        Among("evana", 369, 96, 0),
        Among("ivana", 369, 98, 0),
        Among("uvana", 369, 99, 0),
        Among("a\u010Dana", 369, 102, 0),
        Among("acena", 368, 124, 0),
        Among("lucena", 368, 121, 0),
        Among("a\u010Dena", 368, 101, 0),
        Among("lu\u010Dena", 368, 117, 0),
        Among("ina", 368, 11, 0),
        Among("cina", 382, 137, 0),
        Among("anina", 382, 10, 0),
        Among("\u010Dina", 382, 89, 0),
        Among("ona", 368, 12, 0),
        Among("ara", -1, 53, 0),
        Among("dra", -1, 54, 0),
        Among("era", -1, 55, 0),
        Among("ora", -1, 56, 0),
        Among("basa", -1, 135, 0),
        Among("gasa", -1, 131, 0),
        Among("jasa", -1, 129, 0),
        Among("kasa", -1, 133, 0),
        Among("nasa", -1, 132, 0),
        Among("tasa", -1, 130, 0),
        Among("vasa", -1, 134, 0),
        Among("esa", -1, 57, 0),
        Among("isa", -1, 58, 0),
        Among("osa", -1, 123, 0),
        Among("ata", -1, 120, 0),
        Among("ikata", 401, 68, 0),
        Among("lata", 401, 69, 0),
        Among("eta", -1, 70, 0),
        Among("evita", -1, 92, 0),
        Among("ovita", -1, 93, 0),
        Among("asta", -1, 94, 0),
        Among("esta", -1, 71, 0),
        Among("ista", -1, 72, 0),
        Among("ksta", -1, 73, 0),
        Among("osta", -1, 74, 0),
        Among("nuta", -1, 13, 0),
        Among("i\u0161ta", -1, 75, 0),
        Among("ava", -1, 77, 0),
        Among("eva", -1, 78, 0),
        Among("ajeva", 415, 109, 0),
        Among("cajeva", 416, 26, 0),
        Among("lajeva", 416, 30, 0),
        Among("rajeva", 416, 31, 0),
        Among("\u0107ajeva", 416, 28, 0),
        Among("\u010Dajeva", 416, 27, 0),
        Among("\u0111ajeva", 416, 29, 0),
        Among("iva", -1, 79, 0),
        Among("ova", -1, 80, 0),
        Among("gova", 424, 20, 0),
        Among("ugova", 425, 17, 0),
        Among("lova", 424, 82, 0),
        Among("olova", 427, 49, 0),
        Among("mova", 424, 81, 0),
        Among("onova", 424, 12, 0),
        Among("stva", -1, 3, 0),
        Among("\u0161tva", -1, 4, 0),
        Among("a\u0107a", -1, 14, 0),
        Among("e\u0107a", -1, 15, 0),
        Among("u\u0107a", -1, 16, 0),
        Among("ba\u0161a", -1, 63, 0),
        Among("ga\u0161a", -1, 64, 0),
        Among("ja\u0161a", -1, 61, 0),
        Among("ka\u0161a", -1, 62, 0),
        Among("na\u0161a", -1, 60, 0),
        Among("ta\u0161a", -1, 59, 0),
        Among("va\u0161a", -1, 65, 0),
        Among("e\u0161a", -1, 66, 0),
        Among("i\u0161a", -1, 67, 0),
        Among("o\u0161a", -1, 91, 0),
        Among("ace", -1, 124, 0),
        Among("ece", -1, 125, 0),
        Among("uce", -1, 126, 0),
        Among("luce", 448, 121, 0),
        Among("astade", -1, 110, 0),
        Among("istade", -1, 111, 0),
        Among("ostade", -1, 112, 0),
        Among("ge", -1, 20, 0),
        Among("loge", 453, 19, 0),
        Among("uge", 453, 18, 0),
        Among("aje", -1, 104, 0),
        Among("caje", 456, 26, 0),
        Among("laje", 456, 30, 0),
        Among("raje", 456, 31, 0),
        Among("astaje", 456, 106, 0),
        Among("istaje", 456, 107, 0),
        Among("ostaje", 456, 108, 0),
        Among("\u0107aje", 456, 28, 0),
        Among("\u010Daje", 456, 27, 0),
        Among("\u0111aje", 456, 29, 0),
        Among("ije", -1, 116, 0),
        Among("bije", 466, 32, 0),
        Among("cije", 466, 33, 0),
        Among("dije", 466, 34, 0),
        Among("fije", 466, 40, 0),
        Among("gije", 466, 39, 0),
        Among("anjije", 466, 84, 0),
        Among("enjije", 466, 85, 0),
        Among("snjije", 466, 122, 0),
        Among("\u0161njije", 466, 86, 0),
        Among("kije", 466, 95, 0),
        Among("skije", 476, 1, 0),
        Among("\u0161kije", 476, 2, 0),
        Among("lije", 466, 35, 0),
        Among("elije", 479, 83, 0),
        Among("mije", 466, 37, 0),
        Among("nije", 466, 13, 0),
        Among("ganije", 482, 9, 0),
        Among("manije", 482, 6, 0),
        Among("panije", 482, 7, 0),
        Among("ranije", 482, 8, 0),
        Among("tanije", 482, 5, 0),
        Among("pije", 466, 41, 0),
        Among("rije", 466, 42, 0),
        Among("sije", 466, 43, 0),
        Among("osije", 490, 123, 0),
        Among("tije", 466, 44, 0),
        Among("atije", 492, 120, 0),
        Among("evitije", 492, 92, 0),
        Among("ovitije", 492, 93, 0),
        Among("astije", 492, 94, 0),
        Among("avije", 466, 77, 0),
        Among("evije", 466, 78, 0),
        Among("ivije", 466, 79, 0),
        Among("ovije", 466, 80, 0),
        Among("zije", 466, 45, 0),
        Among("o\u0161ije", 466, 91, 0),
        Among("\u017Eije", 466, 38, 0),
        Among("anje", -1, 84, 0),
        Among("enje", -1, 85, 0),
        Among("snje", -1, 122, 0),
        Among("\u0161nje", -1, 86, 0),
        Among("uje", -1, 25, 0),
        Among("lucuje", 508, 121, 0),
        Among("iruje", 508, 100, 0),
        Among("lu\u010Duje", 508, 117, 0),
        Among("ke", -1, 95, 0),
        Among("ske", 512, 1, 0),
        Among("\u0161ke", 512, 2, 0),
        Among("ale", -1, 104, 0),
        Among("acale", 515, 128, 0),
        Among("astajale", 515, 106, 0),
        Among("istajale", 515, 107, 0),
        Among("ostajale", 515, 108, 0),
        Among("ijale", 515, 47, 0),
        Among("injale", 515, 114, 0),
        Among("nale", 515, 46, 0),
        Among("irale", 515, 100, 0),
        Among("urale", 515, 105, 0),
        Among("tale", 515, 113, 0),
        Among("astale", 525, 110, 0),
        Among("istale", 525, 111, 0),
        Among("ostale", 525, 112, 0),
        Among("avale", 515, 97, 0),
        Among("evale", 515, 96, 0),
        Among("ivale", 515, 98, 0),
        Among("ovale", 515, 76, 0),
        Among("uvale", 515, 99, 0),
        Among("a\u010Dale", 515, 102, 0),
        Among("ele", -1, 83, 0),
        Among("ile", -1, 116, 0),
        Among("acile", 536, 124, 0),
        Among("lucile", 536, 121, 0),
        Among("nile", 536, 103, 0),
        Among("rosile", 536, 127, 0),
        Among("jetile", 536, 118, 0),
        Among("ozile", 536, 48, 0),
        Among("a\u010Dile", 536, 101, 0),
        Among("lu\u010Dile", 536, 117, 0),
        Among("ro\u0161ile", 536, 90, 0),
        Among("ole", -1, 50, 0),
        Among("asle", -1, 115, 0),
        Among("nule", -1, 13, 0),
        Among("rame", -1, 52, 0),
        Among("leme", -1, 51, 0),
        Among("acome", -1, 124, 0),
        Among("ecome", -1, 125, 0),
        Among("ucome", -1, 126, 0),
        Among("anjome", -1, 84, 0),
        Among("enjome", -1, 85, 0),
        Among("snjome", -1, 122, 0),
        Among("\u0161njome", -1, 86, 0),
        Among("kome", -1, 95, 0),
        Among("skome", 558, 1, 0),
        Among("\u0161kome", 558, 2, 0),
        Among("elome", -1, 83, 0),
        Among("nome", -1, 13, 0),
        Among("cinome", 562, 137, 0),
        Among("\u010Dinome", 562, 89, 0),
        Among("osome", -1, 123, 0),
        Among("atome", -1, 120, 0),
        Among("evitome", -1, 92, 0),
        Among("ovitome", -1, 93, 0),
        Among("astome", -1, 94, 0),
        Among("avome", -1, 77, 0),
        Among("evome", -1, 78, 0),
        Among("ivome", -1, 79, 0),
        Among("ovome", -1, 80, 0),
        Among("a\u0107ome", -1, 14, 0),
        Among("e\u0107ome", -1, 15, 0),
        Among("u\u0107ome", -1, 16, 0),
        Among("o\u0161ome", -1, 91, 0),
        Among("ne", -1, 13, 0),
        Among("ane", 578, 10, 0),
        Among("acane", 579, 128, 0),
        Among("urane", 579, 105, 0),
        Among("tane", 579, 113, 0),
        Among("astane", 582, 110, 0),
        Among("istane", 582, 111, 0),
        Among("ostane", 582, 112, 0),
        Among("avane", 579, 97, 0),
        Among("evane", 579, 96, 0),
        Among("ivane", 579, 98, 0),
        Among("uvane", 579, 99, 0),
        Among("a\u010Dane", 579, 102, 0),
        Among("acene", 578, 124, 0),
        Among("lucene", 578, 121, 0),
        Among("a\u010Dene", 578, 101, 0),
        Among("lu\u010Dene", 578, 117, 0),
        Among("ine", 578, 11, 0),
        Among("cine", 595, 137, 0),
        Among("anine", 595, 10, 0),
        Among("\u010Dine", 595, 89, 0),
        Among("one", 578, 12, 0),
        Among("are", -1, 53, 0),
        Among("dre", -1, 54, 0),
        Among("ere", -1, 55, 0),
        Among("ore", -1, 56, 0),
        Among("ase", -1, 161, 0),
        Among("base", 604, 135, 0),
        Among("acase", 604, 128, 0),
        Among("gase", 604, 131, 0),
        Among("jase", 604, 129, 0),
        Among("astajase", 608, 138, 0),
        Among("istajase", 608, 139, 0),
        Among("ostajase", 608, 140, 0),
        Among("injase", 608, 150, 0),
        Among("kase", 604, 133, 0),
        Among("nase", 604, 132, 0),
        Among("irase", 604, 155, 0),
        Among("urase", 604, 156, 0),
        Among("tase", 604, 130, 0),
        Among("vase", 604, 134, 0),
        Among("avase", 618, 144, 0),
        Among("evase", 618, 145, 0),
        Among("ivase", 618, 146, 0),
        Among("ovase", 618, 148, 0),
        Among("uvase", 618, 147, 0),
        Among("ese", -1, 57, 0),
        Among("ise", -1, 58, 0),
        Among("acise", 625, 124, 0),
        Among("lucise", 625, 121, 0),
        Among("rosise", 625, 127, 0),
        Among("jetise", 625, 149, 0),
        Among("ose", -1, 123, 0),
        Among("astadose", 630, 141, 0),
        Among("istadose", 630, 142, 0),
        Among("ostadose", 630, 143, 0),
        Among("ate", -1, 104, 0),
        Among("acate", 634, 128, 0),
        Among("ikate", 634, 68, 0),
        Among("late", 634, 69, 0),
        Among("irate", 634, 100, 0),
        Among("urate", 634, 105, 0),
        Among("tate", 634, 113, 0),
        Among("avate", 634, 97, 0),
        Among("evate", 634, 96, 0),
        Among("ivate", 634, 98, 0),
        Among("uvate", 634, 99, 0),
        Among("a\u010Date", 634, 102, 0),
        Among("ete", -1, 70, 0),
        Among("astadete", 646, 110, 0),
        Among("istadete", 646, 111, 0),
        Among("ostadete", 646, 112, 0),
        Among("astajete", 646, 106, 0),
        Among("istajete", 646, 107, 0),
        Among("ostajete", 646, 108, 0),
        Among("ijete", 646, 116, 0),
        Among("injete", 646, 114, 0),
        Among("ujete", 646, 25, 0),
        Among("lucujete", 655, 121, 0),
        Among("irujete", 655, 100, 0),
        Among("lu\u010Dujete", 655, 117, 0),
        Among("nete", 646, 13, 0),
        Among("astanete", 659, 110, 0),
        Among("istanete", 659, 111, 0),
        Among("ostanete", 659, 112, 0),
        Among("astete", 646, 115, 0),
        Among("ite", -1, 116, 0),
        Among("acite", 664, 124, 0),
        Among("lucite", 664, 121, 0),
        Among("nite", 664, 13, 0),
        Among("astanite", 667, 110, 0),
        Among("istanite", 667, 111, 0),
        Among("ostanite", 667, 112, 0),
        Among("rosite", 664, 127, 0),
        Among("jetite", 664, 118, 0),
        Among("astite", 664, 115, 0),
        Among("evite", 664, 92, 0),
        Among("ovite", 664, 93, 0),
        Among("a\u010Dite", 664, 101, 0),
        Among("lu\u010Dite", 664, 117, 0),
        Among("ro\u0161ite", 664, 90, 0),
        Among("ajte", -1, 104, 0),
        Among("urajte", 679, 105, 0),
        Among("tajte", 679, 113, 0),
        Among("astajte", 681, 106, 0),
        Among("istajte", 681, 107, 0),
        Among("ostajte", 681, 108, 0),
        Among("avajte", 679, 97, 0),
        Among("evajte", 679, 96, 0),
        Among("ivajte", 679, 98, 0),
        Among("uvajte", 679, 99, 0),
        Among("ijte", -1, 116, 0),
        Among("lucujte", -1, 121, 0),
        Among("irujte", -1, 100, 0),
        Among("lu\u010Dujte", -1, 117, 0),
        Among("aste", -1, 94, 0),
        Among("acaste", 693, 128, 0),
        Among("astajaste", 693, 106, 0),
        Among("istajaste", 693, 107, 0),
        Among("ostajaste", 693, 108, 0),
        Among("injaste", 693, 114, 0),
        Among("iraste", 693, 100, 0),
        Among("uraste", 693, 105, 0),
        Among("taste", 693, 113, 0),
        Among("avaste", 693, 97, 0),
        Among("evaste", 693, 96, 0),
        Among("ivaste", 693, 98, 0),
        Among("ovaste", 693, 76, 0),
        Among("uvaste", 693, 99, 0),
        Among("a\u010Daste", 693, 102, 0),
        Among("este", -1, 71, 0),
        Among("iste", -1, 72, 0),
        Among("aciste", 709, 124, 0),
        Among("luciste", 709, 121, 0),
        Among("niste", 709, 103, 0),
        Among("rosiste", 709, 127, 0),
        Among("jetiste", 709, 118, 0),
        Among("a\u010Diste", 709, 101, 0),
        Among("lu\u010Diste", 709, 117, 0),
        Among("ro\u0161iste", 709, 90, 0),
        Among("kste", -1, 73, 0),
        Among("oste", -1, 74, 0),
        Among("astadoste", 719, 110, 0),
        Among("istadoste", 719, 111, 0),
        Among("ostadoste", 719, 112, 0),
        Among("nuste", -1, 13, 0),
        Among("i\u0161te", -1, 75, 0),
        Among("ave", -1, 77, 0),
        Among("eve", -1, 78, 0),
        Among("ajeve", 726, 109, 0),
        Among("cajeve", 727, 26, 0),
        Among("lajeve", 727, 30, 0),
        Among("rajeve", 727, 31, 0),
        Among("\u0107ajeve", 727, 28, 0),
        Among("\u010Dajeve", 727, 27, 0),
        Among("\u0111ajeve", 727, 29, 0),
        Among("ive", -1, 79, 0),
        Among("ove", -1, 80, 0),
        Among("gove", 735, 20, 0),
        Among("ugove", 736, 17, 0),
        Among("love", 735, 82, 0),
        Among("olove", 738, 49, 0),
        Among("move", 735, 81, 0),
        Among("onove", 735, 12, 0),
        Among("a\u0107e", -1, 14, 0),
        Among("e\u0107e", -1, 15, 0),
        Among("u\u0107e", -1, 16, 0),
        Among("a\u010De", -1, 101, 0),
        Among("lu\u010De", -1, 117, 0),
        Among("a\u0161e", -1, 104, 0),
        Among("ba\u0161e", 747, 63, 0),
        Among("ga\u0161e", 747, 64, 0),
        Among("ja\u0161e", 747, 61, 0),
        Among("astaja\u0161e", 750, 106, 0),
        Among("istaja\u0161e", 750, 107, 0),
        Among("ostaja\u0161e", 750, 108, 0),
        Among("inja\u0161e", 750, 114, 0),
        Among("ka\u0161e", 747, 62, 0),
        Among("na\u0161e", 747, 60, 0),
        Among("ira\u0161e", 747, 100, 0),
        Among("ura\u0161e", 747, 105, 0),
        Among("ta\u0161e", 747, 59, 0),
        Among("va\u0161e", 747, 65, 0),
        Among("ava\u0161e", 760, 97, 0),
        Among("eva\u0161e", 760, 96, 0),
        Among("iva\u0161e", 760, 98, 0),
        Among("ova\u0161e", 760, 76, 0),
        Among("uva\u0161e", 760, 99, 0),
        Among("a\u010Da\u0161e", 747, 102, 0),
        Among("e\u0161e", -1, 66, 0),
        Among("i\u0161e", -1, 67, 0),
        Among("jeti\u0161e", 768, 118, 0),
        Among("a\u010Di\u0161e", 768, 101, 0),
        Among("lu\u010Di\u0161e", 768, 117, 0),
        Among("ro\u0161i\u0161e", 768, 90, 0),
        Among("o\u0161e", -1, 91, 0),
        Among("astado\u0161e", 773, 110, 0),
        Among("istado\u0161e", 773, 111, 0),
        Among("ostado\u0161e", 773, 112, 0),
        Among("aceg", -1, 124, 0),
        Among("eceg", -1, 125, 0),
        Among("uceg", -1, 126, 0),
        Among("anjijeg", -1, 84, 0),
        Among("enjijeg", -1, 85, 0),
        Among("snjijeg", -1, 122, 0),
        Among("\u0161njijeg", -1, 86, 0),
        Among("kijeg", -1, 95, 0),
        Among("skijeg", 784, 1, 0),
        Among("\u0161kijeg", 784, 2, 0),
        Among("elijeg", -1, 83, 0),
        Among("nijeg", -1, 13, 0),
        Among("osijeg", -1, 123, 0),
        Among("atijeg", -1, 120, 0),
        Among("evitijeg", -1, 92, 0),
        Among("ovitijeg", -1, 93, 0),
        Among("astijeg", -1, 94, 0),
        Among("avijeg", -1, 77, 0),
        Among("evijeg", -1, 78, 0),
        Among("ivijeg", -1, 79, 0),
        Among("ovijeg", -1, 80, 0),
        Among("o\u0161ijeg", -1, 91, 0),
        Among("anjeg", -1, 84, 0),
        Among("enjeg", -1, 85, 0),
        Among("snjeg", -1, 122, 0),
        Among("\u0161njeg", -1, 86, 0),
        Among("keg", -1, 95, 0),
        Among("eleg", -1, 83, 0),
        Among("neg", -1, 13, 0),
        Among("aneg", 805, 10, 0),
        Among("eneg", 805, 87, 0),
        Among("sneg", 805, 159, 0),
        Among("\u0161neg", 805, 88, 0),
        Among("oseg", -1, 123, 0),
        Among("ateg", -1, 120, 0),
        Among("aveg", -1, 77, 0),
        Among("eveg", -1, 78, 0),
        Among("iveg", -1, 79, 0),
        Among("oveg", -1, 80, 0),
        Among("a\u0107eg", -1, 14, 0),
        Among("e\u0107eg", -1, 15, 0),
        Among("u\u0107eg", -1, 16, 0),
        Among("o\u0161eg", -1, 91, 0),
        Among("acog", -1, 124, 0),
        Among("ecog", -1, 125, 0),
        Among("ucog", -1, 126, 0),
        Among("anjog", -1, 84, 0),
        Among("enjog", -1, 85, 0),
        Among("snjog", -1, 122, 0),
        Among("\u0161njog", -1, 86, 0),
        Among("kog", -1, 95, 0),
        Among("skog", 827, 1, 0),
        Among("\u0161kog", 827, 2, 0),
        Among("elog", -1, 83, 0),
        Among("nog", -1, 13, 0),
        Among("cinog", 831, 137, 0),
        Among("\u010Dinog", 831, 89, 0),
        Among("osog", -1, 123, 0),
        Among("atog", -1, 120, 0),
        Among("evitog", -1, 92, 0),
        Among("ovitog", -1, 93, 0),
        Among("astog", -1, 94, 0),
        Among("avog", -1, 77, 0),
        Among("evog", -1, 78, 0),
        Among("ivog", -1, 79, 0),
        Among("ovog", -1, 80, 0),
        Among("a\u0107og", -1, 14, 0),
        Among("e\u0107og", -1, 15, 0),
        Among("u\u0107og", -1, 16, 0),
        Among("o\u0161og", -1, 91, 0),
        Among("ah", -1, 104, 0),
        Among("acah", 847, 128, 0),
        Among("astajah", 847, 106, 0),
        Among("istajah", 847, 107, 0),
        Among("ostajah", 847, 108, 0),
        Among("injah", 847, 114, 0),
        Among("irah", 847, 100, 0),
        Among("urah", 847, 105, 0),
        Among("tah", 847, 113, 0),
        Among("avah", 847, 97, 0),
        Among("evah", 847, 96, 0),
        Among("ivah", 847, 98, 0),
        Among("ovah", 847, 76, 0),
        Among("uvah", 847, 99, 0),
        Among("a\u010Dah", 847, 102, 0),
        Among("ih", -1, 116, 0),
        Among("acih", 862, 124, 0),
        Among("ecih", 862, 125, 0),
        Among("ucih", 862, 126, 0),
        Among("lucih", 865, 121, 0),
        Among("anjijih", 862, 84, 0),
        Among("enjijih", 862, 85, 0),
        Among("snjijih", 862, 122, 0),
        Among("\u0161njijih", 862, 86, 0),
        Among("kijih", 862, 95, 0),
        Among("skijih", 871, 1, 0),
        Among("\u0161kijih", 871, 2, 0),
        Among("elijih", 862, 83, 0),
        Among("nijih", 862, 13, 0),
        Among("osijih", 862, 123, 0),
        Among("atijih", 862, 120, 0),
        Among("evitijih", 862, 92, 0),
        Among("ovitijih", 862, 93, 0),
        Among("astijih", 862, 94, 0),
        Among("avijih", 862, 77, 0),
        Among("evijih", 862, 78, 0),
        Among("ivijih", 862, 79, 0),
        Among("ovijih", 862, 80, 0),
        Among("o\u0161ijih", 862, 91, 0),
        Among("anjih", 862, 84, 0),
        Among("enjih", 862, 85, 0),
        Among("snjih", 862, 122, 0),
        Among("\u0161njih", 862, 86, 0),
        Among("kih", 862, 95, 0),
        Among("skih", 890, 1, 0),
        Among("\u0161kih", 890, 2, 0),
        Among("elih", 862, 83, 0),
        Among("nih", 862, 13, 0),
        Among("cinih", 894, 137, 0),
        Among("\u010Dinih", 894, 89, 0),
        Among("osih", 862, 123, 0),
        Among("rosih", 897, 127, 0),
        Among("atih", 862, 120, 0),
        Among("jetih", 862, 118, 0),
        Among("evitih", 862, 92, 0),
        Among("ovitih", 862, 93, 0),
        Among("astih", 862, 94, 0),
        Among("avih", 862, 77, 0),
        Among("evih", 862, 78, 0),
        Among("ivih", 862, 79, 0),
        Among("ovih", 862, 80, 0),
        Among("a\u0107ih", 862, 14, 0),
        Among("e\u0107ih", 862, 15, 0),
        Among("u\u0107ih", 862, 16, 0),
        Among("a\u010Dih", 862, 101, 0),
        Among("lu\u010Dih", 862, 117, 0),
        Among("o\u0161ih", 862, 91, 0),
        Among("ro\u0161ih", 913, 90, 0),
        Among("astadoh", -1, 110, 0),
        Among("istadoh", -1, 111, 0),
        Among("ostadoh", -1, 112, 0),
        Among("acuh", -1, 124, 0),
        Among("ecuh", -1, 125, 0),
        Among("ucuh", -1, 126, 0),
        Among("a\u0107uh", -1, 14, 0),
        Among("e\u0107uh", -1, 15, 0),
        Among("u\u0107uh", -1, 16, 0),
        Among("aci", -1, 124, 0),
        Among("aceci", -1, 124, 0),
        Among("ieci", -1, 162, 0),
        Among("ajuci", -1, 161, 0),
        Among("irajuci", 927, 155, 0),
        Among("urajuci", 927, 156, 0),
        Among("astajuci", 927, 138, 0),
        Among("istajuci", 927, 139, 0),
        Among("ostajuci", 927, 140, 0),
        Among("avajuci", 927, 144, 0),
        Among("evajuci", 927, 145, 0),
        Among("ivajuci", 927, 146, 0),
        Among("uvajuci", 927, 147, 0),
        Among("ujuci", -1, 157, 0),
        Among("lucujuci", 937, 121, 0),
        Among("irujuci", 937, 155, 0),
        Among("luci", -1, 121, 0),
        Among("nuci", -1, 164, 0),
        Among("etuci", -1, 153, 0),
        Among("astuci", -1, 136, 0),
        Among("gi", -1, 20, 0),
        Among("ugi", 944, 18, 0),
        Among("aji", -1, 109, 0),
        Among("caji", 946, 26, 0),
        Among("laji", 946, 30, 0),
        Among("raji", 946, 31, 0),
        Among("\u0107aji", 946, 28, 0),
        Among("\u010Daji", 946, 27, 0),
        Among("\u0111aji", 946, 29, 0),
        Among("biji", -1, 32, 0),
        Among("ciji", -1, 33, 0),
        Among("diji", -1, 34, 0),
        Among("fiji", -1, 40, 0),
        Among("giji", -1, 39, 0),
        Among("anjiji", -1, 84, 0),
        Among("enjiji", -1, 85, 0),
        Among("snjiji", -1, 122, 0),
        Among("\u0161njiji", -1, 86, 0),
        Among("kiji", -1, 95, 0),
        Among("skiji", 962, 1, 0),
        Among("\u0161kiji", 962, 2, 0),
        Among("liji", -1, 35, 0),
        Among("eliji", 965, 83, 0),
        Among("miji", -1, 37, 0),
        Among("niji", -1, 13, 0),
        Among("ganiji", 968, 9, 0),
        Among("maniji", 968, 6, 0),
        Among("paniji", 968, 7, 0),
        Among("raniji", 968, 8, 0),
        Among("taniji", 968, 5, 0),
        Among("piji", -1, 41, 0),
        Among("riji", -1, 42, 0),
        Among("siji", -1, 43, 0),
        Among("osiji", 976, 123, 0),
        Among("tiji", -1, 44, 0),
        Among("atiji", 978, 120, 0),
        Among("evitiji", 978, 92, 0),
        Among("ovitiji", 978, 93, 0),
        Among("astiji", 978, 94, 0),
        Among("aviji", -1, 77, 0),
        Among("eviji", -1, 78, 0),
        Among("iviji", -1, 79, 0),
        Among("oviji", -1, 80, 0),
        Among("ziji", -1, 45, 0),
        Among("o\u0161iji", -1, 91, 0),
        Among("\u017Eiji", -1, 38, 0),
        Among("anji", -1, 84, 0),
        Among("enji", -1, 85, 0),
        Among("snji", -1, 122, 0),
        Among("\u0161nji", -1, 86, 0),
        Among("ki", -1, 95, 0),
        Among("ski", 994, 1, 0),
        Among("\u0161ki", 994, 2, 0),
        Among("ali", -1, 104, 0),
        Among("acali", 997, 128, 0),
        Among("astajali", 997, 106, 0),
        Among("istajali", 997, 107, 0),
        Among("ostajali", 997, 108, 0),
        Among("ijali", 997, 47, 0),
        Among("injali", 997, 114, 0),
        Among("nali", 997, 46, 0),
        Among("irali", 997, 100, 0),
        Among("urali", 997, 105, 0),
        Among("tali", 997, 113, 0),
        Among("astali", 1007, 110, 0),
        Among("istali", 1007, 111, 0),
        Among("ostali", 1007, 112, 0),
        Among("avali", 997, 97, 0),
        Among("evali", 997, 96, 0),
        Among("ivali", 997, 98, 0),
        Among("ovali", 997, 76, 0),
        Among("uvali", 997, 99, 0),
        Among("a\u010Dali", 997, 102, 0),
        Among("eli", -1, 83, 0),
        Among("ili", -1, 116, 0),
        Among("acili", 1018, 124, 0),
        Among("lucili", 1018, 121, 0),
        Among("nili", 1018, 103, 0),
        Among("rosili", 1018, 127, 0),
        Among("jetili", 1018, 118, 0),
        Among("ozili", 1018, 48, 0),
        Among("a\u010Dili", 1018, 101, 0),
        Among("lu\u010Dili", 1018, 117, 0),
        Among("ro\u0161ili", 1018, 90, 0),
        Among("oli", -1, 50, 0),
        Among("asli", -1, 115, 0),
        Among("nuli", -1, 13, 0),
        Among("rami", -1, 52, 0),
        Among("lemi", -1, 51, 0),
        Among("ni", -1, 13, 0),
        Among("ani", 1033, 10, 0),
        Among("acani", 1034, 128, 0),
        Among("urani", 1034, 105, 0),
        Among("tani", 1034, 113, 0),
        Among("avani", 1034, 97, 0),
        Among("evani", 1034, 96, 0),
        Among("ivani", 1034, 98, 0),
        Among("uvani", 1034, 99, 0),
        Among("a\u010Dani", 1034, 102, 0),
        Among("aceni", 1033, 124, 0),
        Among("luceni", 1033, 121, 0),
        Among("a\u010Deni", 1033, 101, 0),
        Among("lu\u010Deni", 1033, 117, 0),
        Among("ini", 1033, 11, 0),
        Among("cini", 1047, 137, 0),
        Among("\u010Dini", 1047, 89, 0),
        Among("oni", 1033, 12, 0),
        Among("ari", -1, 53, 0),
        Among("dri", -1, 54, 0),
        Among("eri", -1, 55, 0),
        Among("ori", -1, 56, 0),
        Among("basi", -1, 135, 0),
        Among("gasi", -1, 131, 0),
        Among("jasi", -1, 129, 0),
        Among("kasi", -1, 133, 0),
        Among("nasi", -1, 132, 0),
        Among("tasi", -1, 130, 0),
        Among("vasi", -1, 134, 0),
        Among("esi", -1, 152, 0),
        Among("isi", -1, 154, 0),
        Among("osi", -1, 123, 0),
        Among("avsi", -1, 161, 0),
        Among("acavsi", 1065, 128, 0),
        Among("iravsi", 1065, 155, 0),
        Among("tavsi", 1065, 160, 0),
        Among("etavsi", 1068, 153, 0),
        Among("astavsi", 1068, 141, 0),
        Among("istavsi", 1068, 142, 0),
        Among("ostavsi", 1068, 143, 0),
        Among("ivsi", -1, 162, 0),
        Among("nivsi", 1073, 158, 0),
        Among("rosivsi", 1073, 127, 0),
        Among("nuvsi", -1, 164, 0),
        Among("ati", -1, 104, 0),
        Among("acati", 1077, 128, 0),
        Among("astajati", 1077, 106, 0),
        Among("istajati", 1077, 107, 0),
        Among("ostajati", 1077, 108, 0),
        Among("injati", 1077, 114, 0),
        Among("ikati", 1077, 68, 0),
        Among("lati", 1077, 69, 0),
        Among("irati", 1077, 100, 0),
        Among("urati", 1077, 105, 0),
        Among("tati", 1077, 113, 0),
        Among("astati", 1087, 110, 0),
        Among("istati", 1087, 111, 0),
        Among("ostati", 1087, 112, 0),
        Among("avati", 1077, 97, 0),
        Among("evati", 1077, 96, 0),
        Among("ivati", 1077, 98, 0),
        Among("ovati", 1077, 76, 0),
        Among("uvati", 1077, 99, 0),
        Among("a\u010Dati", 1077, 102, 0),
        Among("eti", -1, 70, 0),
        Among("iti", -1, 116, 0),
        Among("aciti", 1098, 124, 0),
        Among("luciti", 1098, 121, 0),
        Among("niti", 1098, 103, 0),
        Among("rositi", 1098, 127, 0),
        Among("jetiti", 1098, 118, 0),
        Among("eviti", 1098, 92, 0),
        Among("oviti", 1098, 93, 0),
        Among("a\u010Diti", 1098, 101, 0),
        Among("lu\u010Diti", 1098, 117, 0),
        Among("ro\u0161iti", 1098, 90, 0),
        Among("asti", -1, 94, 0),
        Among("esti", -1, 71, 0),
        Among("isti", -1, 72, 0),
        Among("ksti", -1, 73, 0),
        Among("osti", -1, 74, 0),
        Among("nuti", -1, 13, 0),
        Among("avi", -1, 77, 0),
        Among("evi", -1, 78, 0),
        Among("ajevi", 1116, 109, 0),
        Among("cajevi", 1117, 26, 0),
        Among("lajevi", 1117, 30, 0),
        Among("rajevi", 1117, 31, 0),
        Among("\u0107ajevi", 1117, 28, 0),
        Among("\u010Dajevi", 1117, 27, 0),
        Among("\u0111ajevi", 1117, 29, 0),
        Among("ivi", -1, 79, 0),
        Among("ovi", -1, 80, 0),
        Among("govi", 1125, 20, 0),
        Among("ugovi", 1126, 17, 0),
        Among("lovi", 1125, 82, 0),
        Among("olovi", 1128, 49, 0),
        Among("movi", 1125, 81, 0),
        Among("onovi", 1125, 12, 0),
        Among("ie\u0107i", -1, 116, 0),
        Among("a\u010De\u0107i", -1, 101, 0),
        Among("aju\u0107i", -1, 104, 0),
        Among("iraju\u0107i", 1134, 100, 0),
        Among("uraju\u0107i", 1134, 105, 0),
        Among("astaju\u0107i", 1134, 106, 0),
        Among("istaju\u0107i", 1134, 107, 0),
        Among("ostaju\u0107i", 1134, 108, 0),
        Among("avaju\u0107i", 1134, 97, 0),
        Among("evaju\u0107i", 1134, 96, 0),
        Among("ivaju\u0107i", 1134, 98, 0),
        Among("uvaju\u0107i", 1134, 99, 0),
        Among("uju\u0107i", -1, 25, 0),
        Among("iruju\u0107i", 1144, 100, 0),
        Among("lu\u010Duju\u0107i", 1144, 117, 0),
        Among("nu\u0107i", -1, 13, 0),
        Among("etu\u0107i", -1, 70, 0),
        Among("astu\u0107i", -1, 115, 0),
        Among("a\u010Di", -1, 101, 0),
        Among("lu\u010Di", -1, 117, 0),
        Among("ba\u0161i", -1, 63, 0),
        Among("ga\u0161i", -1, 64, 0),
        Among("ja\u0161i", -1, 61, 0),
        Among("ka\u0161i", -1, 62, 0),
        Among("na\u0161i", -1, 60, 0),
        Among("ta\u0161i", -1, 59, 0),
        Among("va\u0161i", -1, 65, 0),
        Among("e\u0161i", -1, 66, 0),
        Among("i\u0161i", -1, 67, 0),
        Among("o\u0161i", -1, 91, 0),
        Among("av\u0161i", -1, 104, 0),
        Among("irav\u0161i", 1162, 100, 0),
        Among("tav\u0161i", 1162, 113, 0),
        Among("etav\u0161i", 1164, 70, 0),
        Among("astav\u0161i", 1164, 110, 0),
        Among("istav\u0161i", 1164, 111, 0),
        Among("ostav\u0161i", 1164, 112, 0),
        Among("a\u010Dav\u0161i", 1162, 102, 0),
        Among("iv\u0161i", -1, 116, 0),
        Among("niv\u0161i", 1170, 103, 0),
        Among("ro\u0161iv\u0161i", 1170, 90, 0),
        Among("nuv\u0161i", -1, 13, 0),
        Among("aj", -1, 104, 0),
        Among("uraj", 1174, 105, 0),
        Among("taj", 1174, 113, 0),
        Among("avaj", 1174, 97, 0),
        Among("evaj", 1174, 96, 0),
        Among("ivaj", 1174, 98, 0),
        Among("uvaj", 1174, 99, 0),
        Among("ij", -1, 116, 0),
        Among("acoj", -1, 124, 0),
        Among("ecoj", -1, 125, 0),
        Among("ucoj", -1, 126, 0),
        Among("anjijoj", -1, 84, 0),
        Among("enjijoj", -1, 85, 0),
        Among("snjijoj", -1, 122, 0),
        Among("\u0161njijoj", -1, 86, 0),
        Among("kijoj", -1, 95, 0),
        Among("skijoj", 1189, 1, 0),
        Among("\u0161kijoj", 1189, 2, 0),
        Among("elijoj", -1, 83, 0),
        Among("nijoj", -1, 13, 0),
        Among("osijoj", -1, 123, 0),
        Among("evitijoj", -1, 92, 0),
        Among("ovitijoj", -1, 93, 0),
        Among("astijoj", -1, 94, 0),
        Among("avijoj", -1, 77, 0),
        Among("evijoj", -1, 78, 0),
        Among("ivijoj", -1, 79, 0),
        Among("ovijoj", -1, 80, 0),
        Among("o\u0161ijoj", -1, 91, 0),
        Among("anjoj", -1, 84, 0),
        Among("enjoj", -1, 85, 0),
        Among("snjoj", -1, 122, 0),
        Among("\u0161njoj", -1, 86, 0),
        Among("koj", -1, 95, 0),
        Among("skoj", 1207, 1, 0),
        Among("\u0161koj", 1207, 2, 0),
        Among("aloj", -1, 104, 0),
        Among("eloj", -1, 83, 0),
        Among("noj", -1, 13, 0),
        Among("cinoj", 1212, 137, 0),
        Among("\u010Dinoj", 1212, 89, 0),
        Among("osoj", -1, 123, 0),
        Among("atoj", -1, 120, 0),
        Among("evitoj", -1, 92, 0),
        Among("ovitoj", -1, 93, 0),
        Among("astoj", -1, 94, 0),
        Among("avoj", -1, 77, 0),
        Among("evoj", -1, 78, 0),
        Among("ivoj", -1, 79, 0),
        Among("ovoj", -1, 80, 0),
        Among("a\u0107oj", -1, 14, 0),
        Among("e\u0107oj", -1, 15, 0),
        Among("u\u0107oj", -1, 16, 0),
        Among("o\u0161oj", -1, 91, 0),
        Among("lucuj", -1, 121, 0),
        Among("iruj", -1, 100, 0),
        Among("lu\u010Duj", -1, 117, 0),
        Among("al", -1, 104, 0),
        Among("iral", 1231, 100, 0),
        Among("ural", 1231, 105, 0),
        Among("el", -1, 119, 0),
        Among("il", -1, 116, 0),
        Among("am", -1, 104, 0),
        Among("acam", 1236, 128, 0),
        Among("iram", 1236, 100, 0),
        Among("uram", 1236, 105, 0),
        Among("tam", 1236, 113, 0),
        Among("avam", 1236, 97, 0),
        Among("evam", 1236, 96, 0),
        Among("ivam", 1236, 98, 0),
        Among("uvam", 1236, 99, 0),
        Among("a\u010Dam", 1236, 102, 0),
        Among("em", -1, 119, 0),
        Among("acem", 1246, 124, 0),
        Among("ecem", 1246, 125, 0),
        Among("ucem", 1246, 126, 0),
        Among("astadem", 1246, 110, 0),
        Among("istadem", 1246, 111, 0),
        Among("ostadem", 1246, 112, 0),
        Among("ajem", 1246, 104, 0),
        Among("cajem", 1253, 26, 0),
        Among("lajem", 1253, 30, 0),
        Among("rajem", 1253, 31, 0),
        Among("astajem", 1253, 106, 0),
        Among("istajem", 1253, 107, 0),
        Among("ostajem", 1253, 108, 0),
        Among("\u0107ajem", 1253, 28, 0),
        Among("\u010Dajem", 1253, 27, 0),
        Among("\u0111ajem", 1253, 29, 0),
        Among("ijem", 1246, 116, 0),
        Among("anjijem", 1263, 84, 0),
        Among("enjijem", 1263, 85, 0),
        Among("snjijem", 1263, 123, 0),
        Among("\u0161njijem", 1263, 86, 0),
        Among("kijem", 1263, 95, 0),
        Among("skijem", 1268, 1, 0),
        Among("\u0161kijem", 1268, 2, 0),
        Among("lijem", 1263, 24, 0),
        Among("elijem", 1271, 83, 0),
        Among("nijem", 1263, 13, 0),
        Among("rarijem", 1263, 21, 0),
        Among("sijem", 1263, 23, 0),
        Among("osijem", 1275, 123, 0),
        Among("atijem", 1263, 120, 0),
        Among("evitijem", 1263, 92, 0),
        Among("ovitijem", 1263, 93, 0),
        Among("otijem", 1263, 22, 0),
        Among("astijem", 1263, 94, 0),
        Among("avijem", 1263, 77, 0),
        Among("evijem", 1263, 78, 0),
        Among("ivijem", 1263, 79, 0),
        Among("ovijem", 1263, 80, 0),
        Among("o\u0161ijem", 1263, 91, 0),
        Among("anjem", 1246, 84, 0),
        Among("enjem", 1246, 85, 0),
        Among("injem", 1246, 114, 0),
        Among("snjem", 1246, 122, 0),
        Among("\u0161njem", 1246, 86, 0),
        Among("ujem", 1246, 25, 0),
        Among("lucujem", 1292, 121, 0),
        Among("irujem", 1292, 100, 0),
        Among("lu\u010Dujem", 1292, 117, 0),
        Among("kem", 1246, 95, 0),
        Among("skem", 1296, 1, 0),
        Among("\u0161kem", 1296, 2, 0),
        Among("elem", 1246, 83, 0),
        Among("nem", 1246, 13, 0),
        Among("anem", 1300, 10, 0),
        Among("astanem", 1301, 110, 0),
        Among("istanem", 1301, 111, 0),
        Among("ostanem", 1301, 112, 0),
        Among("enem", 1300, 87, 0),
        Among("snem", 1300, 159, 0),
        Among("\u0161nem", 1300, 88, 0),
        Among("basem", 1246, 135, 0),
        Among("gasem", 1246, 131, 0),
        Among("jasem", 1246, 129, 0),
        Among("kasem", 1246, 133, 0),
        Among("nasem", 1246, 132, 0),
        Among("tasem", 1246, 130, 0),
        Among("vasem", 1246, 134, 0),
        Among("esem", 1246, 152, 0),
        Among("isem", 1246, 154, 0),
        Among("osem", 1246, 123, 0),
        Among("atem", 1246, 120, 0),
        Among("etem", 1246, 70, 0),
        Among("evitem", 1246, 92, 0),
        Among("ovitem", 1246, 93, 0),
        Among("astem", 1246, 94, 0),
        Among("istem", 1246, 151, 0),
        Among("i\u0161tem", 1246, 75, 0),
        Among("avem", 1246, 77, 0),
        Among("evem", 1246, 78, 0),
        Among("ivem", 1246, 79, 0),
        Among("a\u0107em", 1246, 14, 0),
        Among("e\u0107em", 1246, 15, 0),
        Among("u\u0107em", 1246, 16, 0),
        Among("ba\u0161em", 1246, 63, 0),
        Among("ga\u0161em", 1246, 64, 0),
        Among("ja\u0161em", 1246, 61, 0),
        Among("ka\u0161em", 1246, 62, 0),
        Among("na\u0161em", 1246, 60, 0),
        Among("ta\u0161em", 1246, 59, 0),
        Among("va\u0161em", 1246, 65, 0),
        Among("e\u0161em", 1246, 66, 0),
        Among("i\u0161em", 1246, 67, 0),
        Among("o\u0161em", 1246, 91, 0),
        Among("im", -1, 116, 0),
        Among("acim", 1341, 124, 0),
        Among("ecim", 1341, 125, 0),
        Among("ucim", 1341, 126, 0),
        Among("lucim", 1344, 121, 0),
        Among("anjijim", 1341, 84, 0),
        Among("enjijim", 1341, 85, 0),
        Among("snjijim", 1341, 122, 0),
        Among("\u0161njijim", 1341, 86, 0),
        Among("kijim", 1341, 95, 0),
        Among("skijim", 1350, 1, 0),
        Among("\u0161kijim", 1350, 2, 0),
        Among("elijim", 1341, 83, 0),
        Among("nijim", 1341, 13, 0),
        Among("osijim", 1341, 123, 0),
        Among("atijim", 1341, 120, 0),
        Among("evitijim", 1341, 92, 0),
        Among("ovitijim", 1341, 93, 0),
        Among("astijim", 1341, 94, 0),
        Among("avijim", 1341, 77, 0),
        Among("evijim", 1341, 78, 0),
        Among("ivijim", 1341, 79, 0),
        Among("ovijim", 1341, 80, 0),
        Among("o\u0161ijim", 1341, 91, 0),
        Among("anjim", 1341, 84, 0),
        Among("enjim", 1341, 85, 0),
        Among("snjim", 1341, 122, 0),
        Among("\u0161njim", 1341, 86, 0),
        Among("kim", 1341, 95, 0),
        Among("skim", 1369, 1, 0),
        Among("\u0161kim", 1369, 2, 0),
        Among("elim", 1341, 83, 0),
        Among("nim", 1341, 13, 0),
        Among("cinim", 1373, 137, 0),
        Among("\u010Dinim", 1373, 89, 0),
        Among("osim", 1341, 123, 0),
        Among("rosim", 1376, 127, 0),
        Among("atim", 1341, 120, 0),
        Among("jetim", 1341, 118, 0),
        Among("evitim", 1341, 92, 0),
        Among("ovitim", 1341, 93, 0),
        Among("astim", 1341, 94, 0),
        Among("avim", 1341, 77, 0),
        Among("evim", 1341, 78, 0),
        Among("ivim", 1341, 79, 0),
        Among("ovim", 1341, 80, 0),
        Among("a\u0107im", 1341, 14, 0),
        Among("e\u0107im", 1341, 15, 0),
        Among("u\u0107im", 1341, 16, 0),
        Among("a\u010Dim", 1341, 101, 0),
        Among("lu\u010Dim", 1341, 117, 0),
        Among("o\u0161im", 1341, 91, 0),
        Among("ro\u0161im", 1392, 90, 0),
        Among("acom", -1, 124, 0),
        Among("ecom", -1, 125, 0),
        Among("ucom", -1, 126, 0),
        Among("gom", -1, 20, 0),
        Among("logom", 1397, 19, 0),
        Among("ugom", 1397, 18, 0),
        Among("bijom", -1, 32, 0),
        Among("cijom", -1, 33, 0),
        Among("dijom", -1, 34, 0),
        Among("fijom", -1, 40, 0),
        Among("gijom", -1, 39, 0),
        Among("lijom", -1, 35, 0),
        Among("mijom", -1, 37, 0),
        Among("nijom", -1, 36, 0),
        Among("ganijom", 1407, 9, 0),
        Among("manijom", 1407, 6, 0),
        Among("panijom", 1407, 7, 0),
        Among("ranijom", 1407, 8, 0),
        Among("tanijom", 1407, 5, 0),
        Among("pijom", -1, 41, 0),
        Among("rijom", -1, 42, 0),
        Among("sijom", -1, 43, 0),
        Among("tijom", -1, 44, 0),
        Among("zijom", -1, 45, 0),
        Among("\u017Eijom", -1, 38, 0),
        Among("anjom", -1, 84, 0),
        Among("enjom", -1, 85, 0),
        Among("snjom", -1, 122, 0),
        Among("\u0161njom", -1, 86, 0),
        Among("kom", -1, 95, 0),
        Among("skom", 1423, 1, 0),
        Among("\u0161kom", 1423, 2, 0),
        Among("alom", -1, 104, 0),
        Among("ijalom", 1426, 47, 0),
        Among("nalom", 1426, 46, 0),
        Among("elom", -1, 83, 0),
        Among("ilom", -1, 116, 0),
        Among("ozilom", 1430, 48, 0),
        Among("olom", -1, 50, 0),
        Among("ramom", -1, 52, 0),
        Among("lemom", -1, 51, 0),
        Among("nom", -1, 13, 0),
        Among("anom", 1435, 10, 0),
        Among("inom", 1435, 11, 0),
        Among("cinom", 1437, 137, 0),
        Among("aninom", 1437, 10, 0),
        Among("\u010Dinom", 1437, 89, 0),
        Among("onom", 1435, 12, 0),
        Among("arom", -1, 53, 0),
        Among("drom", -1, 54, 0),
        Among("erom", -1, 55, 0),
        Among("orom", -1, 56, 0),
        Among("basom", -1, 135, 0),
        Among("gasom", -1, 131, 0),
        Among("jasom", -1, 129, 0),
        Among("kasom", -1, 133, 0),
        Among("nasom", -1, 132, 0),
        Among("tasom", -1, 130, 0),
        Among("vasom", -1, 134, 0),
        Among("esom", -1, 57, 0),
        Among("isom", -1, 58, 0),
        Among("osom", -1, 123, 0),
        Among("atom", -1, 120, 0),
        Among("ikatom", 1456, 68, 0),
        Among("latom", 1456, 69, 0),
        Among("etom", -1, 70, 0),
        Among("evitom", -1, 92, 0),
        Among("ovitom", -1, 93, 0),
        Among("astom", -1, 94, 0),
        Among("estom", -1, 71, 0),
        Among("istom", -1, 72, 0),
        Among("kstom", -1, 73, 0),
        Among("ostom", -1, 74, 0),
        Among("avom", -1, 77, 0),
        Among("evom", -1, 78, 0),
        Among("ivom", -1, 79, 0),
        Among("ovom", -1, 80, 0),
        Among("lovom", 1470, 82, 0),
        Among("movom", 1470, 81, 0),
        Among("stvom", -1, 3, 0),
        Among("\u0161tvom", -1, 4, 0),
        Among("a\u0107om", -1, 14, 0),
        Among("e\u0107om", -1, 15, 0),
        Among("u\u0107om", -1, 16, 0),
        Among("ba\u0161om", -1, 63, 0),
        Among("ga\u0161om", -1, 64, 0),
        Among("ja\u0161om", -1, 61, 0),
        Among("ka\u0161om", -1, 62, 0),
        Among("na\u0161om", -1, 60, 0),
        Among("ta\u0161om", -1, 59, 0),
        Among("va\u0161om", -1, 65, 0),
        Among("e\u0161om", -1, 66, 0),
        Among("i\u0161om", -1, 67, 0),
        Among("o\u0161om", -1, 91, 0),
        Among("an", -1, 104, 0),
        Among("acan", 1488, 128, 0),
        Among("iran", 1488, 100, 0),
        Among("uran", 1488, 105, 0),
        Among("tan", 1488, 113, 0),
        Among("avan", 1488, 97, 0),
        Among("evan", 1488, 96, 0),
        Among("ivan", 1488, 98, 0),
        Among("uvan", 1488, 99, 0),
        Among("a\u010Dan", 1488, 102, 0),
        Among("acen", -1, 124, 0),
        Among("lucen", -1, 121, 0),
        Among("a\u010Den", -1, 101, 0),
        Among("lu\u010Den", -1, 117, 0),
        Among("anin", -1, 10, 0),
        Among("ao", -1, 104, 0),
        Among("acao", 1503, 128, 0),
        Among("astajao", 1503, 106, 0),
        Among("istajao", 1503, 107, 0),
        Among("ostajao", 1503, 108, 0),
        Among("injao", 1503, 114, 0),
        Among("irao", 1503, 100, 0),
        Among("urao", 1503, 105, 0),
        Among("tao", 1503, 113, 0),
        Among("astao", 1511, 110, 0),
        Among("istao", 1511, 111, 0),
        Among("ostao", 1511, 112, 0),
        Among("avao", 1503, 97, 0),
        Among("evao", 1503, 96, 0),
        Among("ivao", 1503, 98, 0),
        Among("ovao", 1503, 76, 0),
        Among("uvao", 1503, 99, 0),
        Among("a\u010Dao", 1503, 102, 0),
        Among("go", -1, 20, 0),
        Among("ugo", 1521, 18, 0),
        Among("io", -1, 116, 0),
        Among("acio", 1523, 124, 0),
        Among("lucio", 1523, 121, 0),
        Among("lio", 1523, 24, 0),
        Among("nio", 1523, 103, 0),
        Among("rario", 1523, 21, 0),
        Among("sio", 1523, 23, 0),
        Among("rosio", 1529, 127, 0),
        Among("jetio", 1523, 118, 0),
        Among("otio", 1523, 22, 0),
        Among("a\u010Dio", 1523, 101, 0),
        Among("lu\u010Dio", 1523, 117, 0),
        Among("ro\u0161io", 1523, 90, 0),
        Among("bijo", -1, 32, 0),
        Among("cijo", -1, 33, 0),
        Among("dijo", -1, 34, 0),
        Among("fijo", -1, 40, 0),
        Among("gijo", -1, 39, 0),
        Among("lijo", -1, 35, 0),
        Among("mijo", -1, 37, 0),
        Among("nijo", -1, 36, 0),
        Among("pijo", -1, 41, 0),
        Among("rijo", -1, 42, 0),
        Among("sijo", -1, 43, 0),
        Among("tijo", -1, 44, 0),
        Among("zijo", -1, 45, 0),
        Among("\u017Eijo", -1, 38, 0),
        Among("anjo", -1, 84, 0),
        Among("enjo", -1, 85, 0),
        Among("snjo", -1, 122, 0),
        Among("\u0161njo", -1, 86, 0),
        Among("ko", -1, 95, 0),
        Among("sko", 1554, 1, 0),
        Among("\u0161ko", 1554, 2, 0),
        Among("alo", -1, 104, 0),
        Among("acalo", 1557, 128, 0),
        Among("astajalo", 1557, 106, 0),
        Among("istajalo", 1557, 107, 0),
        Among("ostajalo", 1557, 108, 0),
        Among("ijalo", 1557, 47, 0),
        Among("injalo", 1557, 114, 0),
        Among("nalo", 1557, 46, 0),
        Among("iralo", 1557, 100, 0),
        Among("uralo", 1557, 105, 0),
        Among("talo", 1557, 113, 0),
        Among("astalo", 1567, 110, 0),
        Among("istalo", 1567, 111, 0),
        Among("ostalo", 1567, 112, 0),
        Among("avalo", 1557, 97, 0),
        Among("evalo", 1557, 96, 0),
        Among("ivalo", 1557, 98, 0),
        Among("ovalo", 1557, 76, 0),
        Among("uvalo", 1557, 99, 0),
        Among("a\u010Dalo", 1557, 102, 0),
        Among("elo", -1, 83, 0),
        Among("ilo", -1, 116, 0),
        Among("acilo", 1578, 124, 0),
        Among("lucilo", 1578, 121, 0),
        Among("nilo", 1578, 103, 0),
        Among("rosilo", 1578, 127, 0),
        Among("jetilo", 1578, 118, 0),
        Among("a\u010Dilo", 1578, 101, 0),
        Among("lu\u010Dilo", 1578, 117, 0),
        Among("ro\u0161ilo", 1578, 90, 0),
        Among("aslo", -1, 115, 0),
        Among("nulo", -1, 13, 0),
        Among("amo", -1, 104, 0),
        Among("acamo", 1589, 128, 0),
        Among("ramo", 1589, 52, 0),
        Among("iramo", 1591, 100, 0),
        Among("uramo", 1591, 105, 0),
        Among("tamo", 1589, 113, 0),
        Among("avamo", 1589, 97, 0),
        Among("evamo", 1589, 96, 0),
        Among("ivamo", 1589, 98, 0),
        Among("uvamo", 1589, 99, 0),
        Among("a\u010Damo", 1589, 102, 0),
        Among("emo", -1, 119, 0),
        Among("astademo", 1600, 110, 0),
        Among("istademo", 1600, 111, 0),
        Among("ostademo", 1600, 112, 0),
        Among("astajemo", 1600, 106, 0),
        Among("istajemo", 1600, 107, 0),
        Among("ostajemo", 1600, 108, 0),
        Among("ijemo", 1600, 116, 0),
        Among("injemo", 1600, 114, 0),
        Among("ujemo", 1600, 25, 0),
        Among("lucujemo", 1609, 121, 0),
        Among("irujemo", 1609, 100, 0),
        Among("lu\u010Dujemo", 1609, 117, 0),
        Among("lemo", 1600, 51, 0),
        Among("nemo", 1600, 13, 0),
        Among("astanemo", 1614, 110, 0),
        Among("istanemo", 1614, 111, 0),
        Among("ostanemo", 1614, 112, 0),
        Among("etemo", 1600, 70, 0),
        Among("astemo", 1600, 115, 0),
        Among("imo", -1, 116, 0),
        Among("acimo", 1620, 124, 0),
        Among("lucimo", 1620, 121, 0),
        Among("nimo", 1620, 13, 0),
        Among("astanimo", 1623, 110, 0),
        Among("istanimo", 1623, 111, 0),
        Among("ostanimo", 1623, 112, 0),
        Among("rosimo", 1620, 127, 0),
        Among("etimo", 1620, 70, 0),
        Among("jetimo", 1628, 118, 0),
        Among("astimo", 1620, 115, 0),
        Among("a\u010Dimo", 1620, 101, 0),
        Among("lu\u010Dimo", 1620, 117, 0),
        Among("ro\u0161imo", 1620, 90, 0),
        Among("ajmo", -1, 104, 0),
        Among("urajmo", 1634, 105, 0),
        Among("tajmo", 1634, 113, 0),
        Among("astajmo", 1636, 106, 0),
        Among("istajmo", 1636, 107, 0),
        Among("ostajmo", 1636, 108, 0),
        Among("avajmo", 1634, 97, 0),
        Among("evajmo", 1634, 96, 0),
        Among("ivajmo", 1634, 98, 0),
        Among("uvajmo", 1634, 99, 0),
        Among("ijmo", -1, 116, 0),
        Among("ujmo", -1, 25, 0),
        Among("lucujmo", 1645, 121, 0),
        Among("irujmo", 1645, 100, 0),
        Among("lu\u010Dujmo", 1645, 117, 0),
        Among("asmo", -1, 104, 0),
        Among("acasmo", 1649, 128, 0),
        Among("astajasmo", 1649, 106, 0),
        Among("istajasmo", 1649, 107, 0),
        Among("ostajasmo", 1649, 108, 0),
        Among("injasmo", 1649, 114, 0),
        Among("irasmo", 1649, 100, 0),
        Among("urasmo", 1649, 105, 0),
        Among("tasmo", 1649, 113, 0),
        Among("avasmo", 1649, 97, 0),
        Among("evasmo", 1649, 96, 0),
        Among("ivasmo", 1649, 98, 0),
        Among("ovasmo", 1649, 76, 0),
        Among("uvasmo", 1649, 99, 0),
        Among("a\u010Dasmo", 1649, 102, 0),
        Among("ismo", -1, 116, 0),
        Among("acismo", 1664, 124, 0),
        Among("lucismo", 1664, 121, 0),
        Among("nismo", 1664, 103, 0),
        Among("rosismo", 1664, 127, 0),
        Among("jetismo", 1664, 118, 0),
        Among("a\u010Dismo", 1664, 101, 0),
        Among("lu\u010Dismo", 1664, 117, 0),
        Among("ro\u0161ismo", 1664, 90, 0),
        Among("astadosmo", -1, 110, 0),
        Among("istadosmo", -1, 111, 0),
        Among("ostadosmo", -1, 112, 0),
        Among("nusmo", -1, 13, 0),
        Among("no", -1, 13, 0),
        Among("ano", 1677, 104, 0),
        Among("acano", 1678, 128, 0),
        Among("urano", 1678, 105, 0),
        Among("tano", 1678, 113, 0),
        Among("avano", 1678, 97, 0),
        Among("evano", 1678, 96, 0),
        Among("ivano", 1678, 98, 0),
        Among("uvano", 1678, 99, 0),
        Among("a\u010Dano", 1678, 102, 0),
        Among("aceno", 1677, 124, 0),
        Among("luceno", 1677, 121, 0),
        Among("a\u010Deno", 1677, 101, 0),
        Among("lu\u010Deno", 1677, 117, 0),
        Among("ino", 1677, 11, 0),
        Among("cino", 1691, 137, 0),
        Among("\u010Dino", 1691, 89, 0),
        Among("ato", -1, 120, 0),
        Among("ikato", 1694, 68, 0),
        Among("lato", 1694, 69, 0),
        Among("eto", -1, 70, 0),
        Among("evito", -1, 92, 0),
        Among("ovito", -1, 93, 0),
        Among("asto", -1, 94, 0),
        Among("esto", -1, 71, 0),
        Among("isto", -1, 72, 0),
        Among("ksto", -1, 73, 0),
        Among("osto", -1, 74, 0),
        Among("nuto", -1, 13, 0),
        Among("nuo", -1, 13, 0),
        Among("avo", -1, 77, 0),
        Among("evo", -1, 78, 0),
        Among("ivo", -1, 79, 0),
        Among("ovo", -1, 80, 0),
        Among("stvo", -1, 3, 0),
        Among("\u0161tvo", -1, 4, 0),
        Among("as", -1, 161, 0),
        Among("acas", 1713, 128, 0),
        Among("iras", 1713, 155, 0),
        Among("uras", 1713, 156, 0),
        Among("tas", 1713, 160, 0),
        Among("avas", 1713, 144, 0),
        Among("evas", 1713, 145, 0),
        Among("ivas", 1713, 146, 0),
        Among("uvas", 1713, 147, 0),
        Among("es", -1, 163, 0),
        Among("astades", 1722, 141, 0),
        Among("istades", 1722, 142, 0),
        Among("ostades", 1722, 143, 0),
        Among("astajes", 1722, 138, 0),
        Among("istajes", 1722, 139, 0),
        Among("ostajes", 1722, 140, 0),
        Among("ijes", 1722, 162, 0),
        Among("injes", 1722, 150, 0),
        Among("ujes", 1722, 157, 0),
        Among("lucujes", 1731, 121, 0),
        Among("irujes", 1731, 155, 0),
        Among("nes", 1722, 164, 0),
        Among("astanes", 1734, 141, 0),
        Among("istanes", 1734, 142, 0),
        Among("ostanes", 1734, 143, 0),
        Among("etes", 1722, 153, 0),
        Among("astes", 1722, 136, 0),
        Among("is", -1, 162, 0),
        Among("acis", 1740, 124, 0),
        Among("lucis", 1740, 121, 0),
        Among("nis", 1740, 158, 0),
        Among("rosis", 1740, 127, 0),
        Among("jetis", 1740, 149, 0),
        Among("at", -1, 104, 0),
        Among("acat", 1746, 128, 0),
        Among("astajat", 1746, 106, 0),
        Among("istajat", 1746, 107, 0),
        Among("ostajat", 1746, 108, 0),
        Among("injat", 1746, 114, 0),
        Among("irat", 1746, 100, 0),
        Among("urat", 1746, 105, 0),
        Among("tat", 1746, 113, 0),
        Among("astat", 1754, 110, 0),
        Among("istat", 1754, 111, 0),
        Among("ostat", 1754, 112, 0),
        Among("avat", 1746, 97, 0),
        Among("evat", 1746, 96, 0),
        Among("ivat", 1746, 98, 0),
        Among("irivat", 1760, 100, 0),
        Among("ovat", 1746, 76, 0),
        Among("uvat", 1746, 99, 0),
        Among("a\u010Dat", 1746, 102, 0),
        Among("it", -1, 116, 0),
        Among("acit", 1765, 124, 0),
        Among("lucit", 1765, 121, 0),
        Among("rosit", 1765, 127, 0),
        Among("jetit", 1765, 118, 0),
        Among("a\u010Dit", 1765, 101, 0),
        Among("lu\u010Dit", 1765, 117, 0),
        Among("ro\u0161it", 1765, 90, 0),
        Among("nut", -1, 13, 0),
        Among("astadu", -1, 110, 0),
        Among("istadu", -1, 111, 0),
        Among("ostadu", -1, 112, 0),
        Among("gu", -1, 20, 0),
        Among("logu", 1777, 19, 0),
        Among("ugu", 1777, 18, 0),
        Among("ahu", -1, 104, 0),
        Among("acahu", 1780, 128, 0),
        Among("astajahu", 1780, 106, 0),
        Among("istajahu", 1780, 107, 0),
        Among("ostajahu", 1780, 108, 0),
        Among("injahu", 1780, 114, 0),
        Among("irahu", 1780, 100, 0),
        Among("urahu", 1780, 105, 0),
        Among("avahu", 1780, 97, 0),
        Among("evahu", 1780, 96, 0),
        Among("ivahu", 1780, 98, 0),
        Among("ovahu", 1780, 76, 0),
        Among("uvahu", 1780, 99, 0),
        Among("a\u010Dahu", 1780, 102, 0),
        Among("aju", -1, 104, 0),
        Among("caju", 1794, 26, 0),
        Among("acaju", 1795, 128, 0),
        Among("laju", 1794, 30, 0),
        Among("raju", 1794, 31, 0),
        Among("iraju", 1798, 100, 0),
        Among("uraju", 1798, 105, 0),
        Among("taju", 1794, 113, 0),
        Among("astaju", 1801, 106, 0),
        Among("istaju", 1801, 107, 0),
        Among("ostaju", 1801, 108, 0),
        Among("avaju", 1794, 97, 0),
        Among("evaju", 1794, 96, 0),
        Among("ivaju", 1794, 98, 0),
        Among("uvaju", 1794, 99, 0),
        Among("\u0107aju", 1794, 28, 0),
        Among("\u010Daju", 1794, 27, 0),
        Among("a\u010Daju", 1810, 102, 0),
        Among("\u0111aju", 1794, 29, 0),
        Among("iju", -1, 116, 0),
        Among("biju", 1813, 32, 0),
        Among("ciju", 1813, 33, 0),
        Among("diju", 1813, 34, 0),
        Among("fiju", 1813, 40, 0),
        Among("giju", 1813, 39, 0),
        Among("anjiju", 1813, 84, 0),
        Among("enjiju", 1813, 85, 0),
        Among("snjiju", 1813, 122, 0),
        Among("\u0161njiju", 1813, 86, 0),
        Among("kiju", 1813, 95, 0),
        Among("liju", 1813, 24, 0),
        Among("eliju", 1824, 83, 0),
        Among("miju", 1813, 37, 0),
        Among("niju", 1813, 13, 0),
        Among("ganiju", 1827, 9, 0),
        Among("maniju", 1827, 6, 0),
        Among("paniju", 1827, 7, 0),
        Among("raniju", 1827, 8, 0),
        Among("taniju", 1827, 5, 0),
        Among("piju", 1813, 41, 0),
        Among("riju", 1813, 42, 0),
        Among("rariju", 1834, 21, 0),
        Among("siju", 1813, 23, 0),
        Among("osiju", 1836, 123, 0),
        Among("tiju", 1813, 44, 0),
        Among("atiju", 1838, 120, 0),
        Among("otiju", 1838, 22, 0),
        Among("aviju", 1813, 77, 0),
        Among("eviju", 1813, 78, 0),
        Among("iviju", 1813, 79, 0),
        Among("oviju", 1813, 80, 0),
        Among("ziju", 1813, 45, 0),
        Among("o\u0161iju", 1813, 91, 0),
        Among("\u017Eiju", 1813, 38, 0),
        Among("anju", -1, 84, 0),
        Among("enju", -1, 85, 0),
        Among("snju", -1, 122, 0),
        Among("\u0161nju", -1, 86, 0),
        Among("uju", -1, 25, 0),
        Among("lucuju", 1852, 121, 0),
        Among("iruju", 1852, 100, 0),
        Among("lu\u010Duju", 1852, 117, 0),
        Among("ku", -1, 95, 0),
        Among("sku", 1856, 1, 0),
        Among("\u0161ku", 1856, 2, 0),
        Among("alu", -1, 104, 0),
        Among("ijalu", 1859, 47, 0),
        Among("nalu", 1859, 46, 0),
        Among("elu", -1, 83, 0),
        Among("ilu", -1, 116, 0),
        Among("ozilu", 1863, 48, 0),
        Among("olu", -1, 50, 0),
        Among("ramu", -1, 52, 0),
        Among("acemu", -1, 124, 0),
        Among("ecemu", -1, 125, 0),
        Among("ucemu", -1, 126, 0),
        Among("anjijemu", -1, 84, 0),
        Among("enjijemu", -1, 85, 0),
        Among("snjijemu", -1, 122, 0),
        Among("\u0161njijemu", -1, 86, 0),
        Among("kijemu", -1, 95, 0),
        Among("skijemu", 1874, 1, 0),
        Among("\u0161kijemu", 1874, 2, 0),
        Among("elijemu", -1, 83, 0),
        Among("nijemu", -1, 13, 0),
        Among("osijemu", -1, 123, 0),
        Among("atijemu", -1, 120, 0),
        Among("evitijemu", -1, 92, 0),
        Among("ovitijemu", -1, 93, 0),
        Among("astijemu", -1, 94, 0),
        Among("avijemu", -1, 77, 0),
        Among("evijemu", -1, 78, 0),
        Among("ivijemu", -1, 79, 0),
        Among("ovijemu", -1, 80, 0),
        Among("o\u0161ijemu", -1, 91, 0),
        Among("anjemu", -1, 84, 0),
        Among("enjemu", -1, 85, 0),
        Among("snjemu", -1, 122, 0),
        Among("\u0161njemu", -1, 86, 0),
        Among("kemu", -1, 95, 0),
        Among("skemu", 1893, 1, 0),
        Among("\u0161kemu", 1893, 2, 0),
        Among("lemu", -1, 51, 0),
        Among("elemu", 1896, 83, 0),
        Among("nemu", -1, 13, 0),
        Among("anemu", 1898, 10, 0),
        Among("enemu", 1898, 87, 0),
        Among("snemu", 1898, 159, 0),
        Among("\u0161nemu", 1898, 88, 0),
        Among("osemu", -1, 123, 0),
        Among("atemu", -1, 120, 0),
        Among("evitemu", -1, 92, 0),
        Among("ovitemu", -1, 93, 0),
        Among("astemu", -1, 94, 0),
        Among("avemu", -1, 77, 0),
        Among("evemu", -1, 78, 0),
        Among("ivemu", -1, 79, 0),
        Among("ovemu", -1, 80, 0),
        Among("a\u0107emu", -1, 14, 0),
        Among("e\u0107emu", -1, 15, 0),
        Among("u\u0107emu", -1, 16, 0),
        Among("o\u0161emu", -1, 91, 0),
        Among("acomu", -1, 124, 0),
        Among("ecomu", -1, 125, 0),
        Among("ucomu", -1, 126, 0),
        Among("anjomu", -1, 84, 0),
        Among("enjomu", -1, 85, 0),
        Among("snjomu", -1, 122, 0),
        Among("\u0161njomu", -1, 86, 0),
        Among("komu", -1, 95, 0),
        Among("skomu", 1923, 1, 0),
        Among("\u0161komu", 1923, 2, 0),
        Among("elomu", -1, 83, 0),
        Among("nomu", -1, 13, 0),
        Among("cinomu", 1927, 137, 0),
        Among("\u010Dinomu", 1927, 89, 0),
        Among("osomu", -1, 123, 0),
        Among("atomu", -1, 120, 0),
        Among("evitomu", -1, 92, 0),
        Among("ovitomu", -1, 93, 0),
        Among("astomu", -1, 94, 0),
        Among("avomu", -1, 77, 0),
        Among("evomu", -1, 78, 0),
        Among("ivomu", -1, 79, 0),
        Among("ovomu", -1, 80, 0),
        Among("a\u0107omu", -1, 14, 0),
        Among("e\u0107omu", -1, 15, 0),
        Among("u\u0107omu", -1, 16, 0),
        Among("o\u0161omu", -1, 91, 0),
        Among("nu", -1, 13, 0),
        Among("anu", 1943, 10, 0),
        Among("astanu", 1944, 110, 0),
        Among("istanu", 1944, 111, 0),
        Among("ostanu", 1944, 112, 0),
        Among("inu", 1943, 11, 0),
        Among("cinu", 1948, 137, 0),
        Among("aninu", 1948, 10, 0),
        Among("\u010Dinu", 1948, 89, 0),
        Among("onu", 1943, 12, 0),
        Among("aru", -1, 53, 0),
        Among("dru", -1, 54, 0),
        Among("eru", -1, 55, 0),
        Among("oru", -1, 56, 0),
        Among("basu", -1, 135, 0),
        Among("gasu", -1, 131, 0),
        Among("jasu", -1, 129, 0),
        Among("kasu", -1, 133, 0),
        Among("nasu", -1, 132, 0),
        Among("tasu", -1, 130, 0),
        Among("vasu", -1, 134, 0),
        Among("esu", -1, 57, 0),
        Among("isu", -1, 58, 0),
        Among("osu", -1, 123, 0),
        Among("atu", -1, 120, 0),
        Among("ikatu", 1967, 68, 0),
        Among("latu", 1967, 69, 0),
        Among("etu", -1, 70, 0),
        Among("evitu", -1, 92, 0),
        Among("ovitu", -1, 93, 0),
        Among("astu", -1, 94, 0),
        Among("estu", -1, 71, 0),
        Among("istu", -1, 72, 0),
        Among("kstu", -1, 73, 0),
        Among("ostu", -1, 74, 0),
        Among("i\u0161tu", -1, 75, 0),
        Among("avu", -1, 77, 0),
        Among("evu", -1, 78, 0),
        Among("ivu", -1, 79, 0),
        Among("ovu", -1, 80, 0),
        Among("lovu", 1982, 82, 0),
        Among("movu", 1982, 81, 0),
        Among("stvu", -1, 3, 0),
        Among("\u0161tvu", -1, 4, 0),
        Among("ba\u0161u", -1, 63, 0),
        Among("ga\u0161u", -1, 64, 0),
        Among("ja\u0161u", -1, 61, 0),
        Among("ka\u0161u", -1, 62, 0),
        Among("na\u0161u", -1, 60, 0),
        Among("ta\u0161u", -1, 59, 0),
        Among("va\u0161u", -1, 65, 0),
        Among("e\u0161u", -1, 66, 0),
        Among("i\u0161u", -1, 67, 0),
        Among("o\u0161u", -1, 91, 0),
        Among("avav", -1, 97, 0),
        Among("evav", -1, 96, 0),
        Among("ivav", -1, 98, 0),
        Among("uvav", -1, 99, 0),
        Among("kov", -1, 95, 0),
        Among("a\u0161", -1, 104, 0),
        Among("ira\u0161", 2002, 100, 0),
        Among("ura\u0161", 2002, 105, 0),
        Among("ta\u0161", 2002, 113, 0),
        Among("ava\u0161", 2002, 97, 0),
        Among("eva\u0161", 2002, 96, 0),
        Among("iva\u0161", 2002, 98, 0),
        Among("uva\u0161", 2002, 99, 0),
        Among("a\u010Da\u0161", 2002, 102, 0),
        Among("e\u0161", -1, 119, 0),
        Among("astade\u0161", 2011, 110, 0),
        Among("istade\u0161", 2011, 111, 0),
        Among("ostade\u0161", 2011, 112, 0),
        Among("astaje\u0161", 2011, 106, 0),
        Among("istaje\u0161", 2011, 107, 0),
        Among("ostaje\u0161", 2011, 108, 0),
        Among("ije\u0161", 2011, 116, 0),
        Among("inje\u0161", 2011, 114, 0),
        Among("uje\u0161", 2011, 25, 0),
        Among("iruje\u0161", 2020, 100, 0),
        Among("lu\u010Duje\u0161", 2020, 117, 0),
        Among("ne\u0161", 2011, 13, 0),
        Among("astane\u0161", 2023, 110, 0),
        Among("istane\u0161", 2023, 111, 0),
        Among("ostane\u0161", 2023, 112, 0),
        Among("ete\u0161", 2011, 70, 0),
        Among("aste\u0161", 2011, 115, 0),
        Among("i\u0161", -1, 116, 0),
        Among("ni\u0161", 2029, 103, 0),
        Among("jeti\u0161", 2029, 118, 0),
        Among("a\u010Di\u0161", 2029, 101, 0),
        Among("lu\u010Di\u0161", 2029, 117, 0),
        Among("ro\u0161i\u0161", 2029, 90, 0)
    ];

    static final a_3 = [
        Among("a", -1, 1, 0),
        Among("oga", 0, 1, 0),
        Among("ama", 0, 1, 0),
        Among("ima", 0, 1, 0),
        Among("ena", 0, 1, 0),
        Among("e", -1, 1, 0),
        Among("og", -1, 1, 0),
        Among("anog", 6, 1, 0),
        Among("enog", 6, 1, 0),
        Among("anih", -1, 1, 0),
        Among("enih", -1, 1, 0),
        Among("i", -1, 1, 0),
        Among("ani", 11, 1, 0),
        Among("eni", 11, 1, 0),
        Among("anoj", -1, 1, 0),
        Among("enoj", -1, 1, 0),
        Among("anim", -1, 1, 0),
        Among("enim", -1, 1, 0),
        Among("om", -1, 1, 0),
        Among("enom", 18, 1, 0),
        Among("o", -1, 1, 0),
        Among("ano", 20, 1, 0),
        Among("eno", 20, 1, 0),
        Among("ost", -1, 1, 0),
        Among("u", -1, 1, 0),
        Among("enu", 24, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16]);

    static final g_sa = String.fromCharCodes([65, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 128]);

    static final g_ca = String.fromCharCodes([119, 95, 23, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 136, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 0, 0, 0, 16]);

    static final g_rg = String.fromCharCodes([1]);

    int I_p1 = 0;
    bool B_no_diacritics = false;


    bool r_cyr_to_lat() {
        int among_var;
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = cursor;
                lab2: while (true) {
                    golab3: while(true)
                    {
                        int v_3 = cursor;
                        lab4: while (true) {
                            bra = cursor;
                            among_var = find_among(a_0, null);
                            if (among_var == 0)
                            {
                                break lab4;
                            }
                            ket = cursor;
                            switch (among_var) {
                                case 1:
                                    slice_from("a");
                                    break;
                                case 2:
                                    slice_from("b");
                                    break;
                                case 3:
                                    slice_from("v");
                                    break;
                                case 4:
                                    slice_from("g");
                                    break;
                                case 5:
                                    slice_from("d");
                                    break;
                                case 6:
                                    slice_from("\u0111");
                                    break;
                                case 7:
                                    slice_from("e");
                                    break;
                                case 8:
                                    slice_from("\u017E");
                                    break;
                                case 9:
                                    slice_from("z");
                                    break;
                                case 10:
                                    slice_from("i");
                                    break;
                                case 11:
                                    slice_from("j");
                                    break;
                                case 12:
                                    slice_from("k");
                                    break;
                                case 13:
                                    slice_from("l");
                                    break;
                                case 14:
                                    slice_from("lj");
                                    break;
                                case 15:
                                    slice_from("m");
                                    break;
                                case 16:
                                    slice_from("n");
                                    break;
                                case 17:
                                    slice_from("nj");
                                    break;
                                case 18:
                                    slice_from("o");
                                    break;
                                case 19:
                                    slice_from("p");
                                    break;
                                case 20:
                                    slice_from("r");
                                    break;
                                case 21:
                                    slice_from("s");
                                    break;
                                case 22:
                                    slice_from("t");
                                    break;
                                case 23:
                                    slice_from("\u0107");
                                    break;
                                case 24:
                                    slice_from("u");
                                    break;
                                case 25:
                                    slice_from("f");
                                    break;
                                case 26:
                                    slice_from("h");
                                    break;
                                case 27:
                                    slice_from("c");
                                    break;
                                case 28:
                                    slice_from("\u010D");
                                    break;
                                case 29:
                                    slice_from("d\u017E");
                                    break;
                                case 30:
                                    slice_from("\u0161");
                                    break;
                            }
                            cursor = v_3;
                            break golab3;
                        }
                        cursor = v_3;
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    continue replab1;
                }
                cursor = v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = v_1;
        return true;
    }

    bool r_prelude() {
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = cursor;
                lab2: while (true) {
                    golab3: while(true)
                    {
                        int v_3 = cursor;
                        lab4: while (true) {
                            if (!(in_grouping(g_ca, 98, 382)))
                            {
                                break lab4;
                            }
                            bra = cursor;
                            if (!(eq_s("ije")))
                            {
                                break lab4;
                            }
                            ket = cursor;
                            if (!(in_grouping(g_ca, 98, 382)))
                            {
                                break lab4;
                            }
                            slice_from("e");
                            cursor = v_3;
                            break golab3;
                        }
                        cursor = v_3;
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    continue replab1;
                }
                cursor = v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = v_1;
        int v_4 = cursor;
        lab5: while (true) {
            replab6: while(true)
            {
                int v_5 = cursor;
                lab7: while (true) {
                    golab8: while(true)
                    {
                        int v_6 = cursor;
                        lab9: while (true) {
                            if (!(in_grouping(g_ca, 98, 382)))
                            {
                                break lab9;
                            }
                            bra = cursor;
                            if (!(eq_s("je")))
                            {
                                break lab9;
                            }
                            ket = cursor;
                            if (!(in_grouping(g_ca, 98, 382)))
                            {
                                break lab9;
                            }
                            slice_from("e");
                            cursor = v_6;
                            break golab8;
                        }
                        cursor = v_6;
                        if (cursor >= limit)
                        {
                            break lab7;
                        }
                        cursor++;
                    }
                    continue replab6;
                }
                cursor = v_5;
                break replab6;
            }
            break lab5;
        }
        cursor = v_4;
        int v_7 = cursor;
        lab10: while (true) {
            replab11: while(true)
            {
                int v_8 = cursor;
                lab12: while (true) {
                    golab13: while(true)
                    {
                        int v_9 = cursor;
                        lab14: while (true) {
                            bra = cursor;
                            if (!(eq_s("dj")))
                            {
                                break lab14;
                            }
                            ket = cursor;
                            slice_from("\u0111");
                            cursor = v_9;
                            break golab13;
                        }
                        cursor = v_9;
                        if (cursor >= limit)
                        {
                            break lab12;
                        }
                        cursor++;
                    }
                    continue replab11;
                }
                cursor = v_8;
                break replab11;
            }
            break lab10;
        }
        cursor = v_7;
        return true;
    }

    bool r_mark_regions() {
        B_no_diacritics = true;
        int v_1 = cursor;
        lab0: while (true) {
            if (!go_out_grouping(g_sa, 263, 382))
            {
                break lab0;
            }
            cursor++;
            B_no_diacritics = false;
            break lab0;
        }
        cursor = v_1;
        I_p1 = limit;
        int v_2 = cursor;
        lab1: while (true) {
            if (!go_out_grouping(g_v, 97, 117))
            {
                break lab1;
            }
            cursor++;
            I_p1 = cursor;
            if (I_p1 >= 2)
            {
                break lab1;
            }
            if (!go_in_grouping(g_v, 97, 117))
            {
                break lab1;
            }
            cursor++;
            I_p1 = cursor;
            break lab1;
        }
        cursor = v_2;
        int v_3 = cursor;
        lab2: while (true) {
            golab3: while(true)
            {
                lab4: while (true) {
                    if (!(eq_s("r")))
                    {
                        break lab4;
                    }
                    break golab3;
                }
                if (cursor >= limit)
                {
                    break lab2;
                }
                cursor++;
            }
            lab5: while (true) {
                lab6: while (true) {
                    if (cursor < 2)
                    {
                        break lab6;
                    }
                    break lab5;
                }
                if (!go_in_grouping(g_rg, 114, 114))
                {
                    break lab2;
                }
                cursor++;
                break lab5;
            }
            if ((I_p1 - cursor) <= 1)
            {
                break lab2;
            }
            I_p1 = cursor;
            break lab2;
        }
        cursor = v_3;
        return true;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_Step_1() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_1, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("loga");
                break;
            case 2:
                slice_from("peh");
                break;
            case 3:
                slice_from("vojka");
                break;
            case 4:
                slice_from("bojka");
                break;
            case 5:
                slice_from("jak");
                break;
            case 6:
                slice_from("\u010Dajni");
                break;
            case 7:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("cajni");
                break;
            case 8:
                slice_from("erni");
                break;
            case 9:
                slice_from("larni");
                break;
            case 10:
                slice_from("esni");
                break;
            case 11:
                slice_from("anjca");
                break;
            case 12:
                slice_from("ajca");
                break;
            case 13:
                slice_from("ljca");
                break;
            case 14:
                slice_from("ejca");
                break;
            case 15:
                slice_from("ojca");
                break;
            case 16:
                slice_from("ajka");
                break;
            case 17:
                slice_from("ojka");
                break;
            case 18:
                slice_from("\u0161ca");
                break;
            case 19:
                slice_from("ing");
                break;
            case 20:
                slice_from("tvenik");
                break;
            case 21:
                slice_from("tetika");
                break;
            case 22:
                slice_from("nstva");
                break;
            case 23:
                slice_from("nik");
                break;
            case 24:
                slice_from("tik");
                break;
            case 25:
                slice_from("zik");
                break;
            case 26:
                slice_from("snik");
                break;
            case 27:
                slice_from("kusi");
                break;
            case 28:
                slice_from("kusni");
                break;
            case 29:
                slice_from("kustva");
                break;
            case 30:
                slice_from("du\u0161ni");
                break;
            case 31:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("dusni");
                break;
            case 32:
                slice_from("antni");
                break;
            case 33:
                slice_from("bilni");
                break;
            case 34:
                slice_from("tilni");
                break;
            case 35:
                slice_from("avilni");
                break;
            case 36:
                slice_from("silni");
                break;
            case 37:
                slice_from("gilni");
                break;
            case 38:
                slice_from("rilni");
                break;
            case 39:
                slice_from("nilni");
                break;
            case 40:
                slice_from("alni");
                break;
            case 41:
                slice_from("ozni");
                break;
            case 42:
                slice_from("ravi");
                break;
            case 43:
                slice_from("stavni");
                break;
            case 44:
                slice_from("pravni");
                break;
            case 45:
                slice_from("tivni");
                break;
            case 46:
                slice_from("sivni");
                break;
            case 47:
                slice_from("atni");
                break;
            case 48:
                slice_from("enta");
                break;
            case 49:
                slice_from("tetni");
                break;
            case 50:
                slice_from("pletni");
                break;
            case 51:
                slice_from("\u0161avi");
                break;
            case 52:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("savi");
                break;
            case 53:
                slice_from("anta");
                break;
            case 54:
                slice_from("a\u010Dka");
                break;
            case 55:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("acka");
                break;
            case 56:
                slice_from("u\u0161ka");
                break;
            case 57:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("uska");
                break;
            case 58:
                slice_from("atka");
                break;
            case 59:
                slice_from("etka");
                break;
            case 60:
                slice_from("itka");
                break;
            case 61:
                slice_from("otka");
                break;
            case 62:
                slice_from("utka");
                break;
            case 63:
                slice_from("eskna");
                break;
            case 64:
                slice_from("ti\u010Dni");
                break;
            case 65:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ticni");
                break;
            case 66:
                slice_from("ojska");
                break;
            case 67:
                slice_from("esma");
                break;
            case 68:
                slice_from("metra");
                break;
            case 69:
                slice_from("centra");
                break;
            case 70:
                slice_from("istra");
                break;
            case 71:
                slice_from("osti");
                break;
            case 72:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("osti");
                break;
            case 73:
                slice_from("dba");
                break;
            case 74:
                slice_from("\u010Dka");
                break;
            case 75:
                slice_from("mca");
                break;
            case 76:
                slice_from("nca");
                break;
            case 77:
                slice_from("voljni");
                break;
            case 78:
                slice_from("anki");
                break;
            case 79:
                slice_from("vca");
                break;
            case 80:
                slice_from("sca");
                break;
            case 81:
                slice_from("rca");
                break;
            case 82:
                slice_from("alca");
                break;
            case 83:
                slice_from("elca");
                break;
            case 84:
                slice_from("olca");
                break;
            case 85:
                slice_from("njca");
                break;
            case 86:
                slice_from("ekta");
                break;
            case 87:
                slice_from("izma");
                break;
            case 88:
                slice_from("jebi");
                break;
            case 89:
                slice_from("baci");
                break;
            case 90:
                slice_from("a\u0161ni");
                break;
            case 91:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("asni");
                break;
        }
        return true;
    }

    bool r_Step_2() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("sk");
                break;
            case 2:
                slice_from("\u0161k");
                break;
            case 3:
                slice_from("stv");
                break;
            case 4:
                slice_from("\u0161tv");
                break;
            case 5:
                slice_from("tanij");
                break;
            case 6:
                slice_from("manij");
                break;
            case 7:
                slice_from("panij");
                break;
            case 8:
                slice_from("ranij");
                break;
            case 9:
                slice_from("ganij");
                break;
            case 10:
                slice_from("an");
                break;
            case 11:
                slice_from("in");
                break;
            case 12:
                slice_from("on");
                break;
            case 13:
                slice_from("n");
                break;
            case 14:
                slice_from("a\u0107");
                break;
            case 15:
                slice_from("e\u0107");
                break;
            case 16:
                slice_from("u\u0107");
                break;
            case 17:
                slice_from("ugov");
                break;
            case 18:
                slice_from("ug");
                break;
            case 19:
                slice_from("log");
                break;
            case 20:
                slice_from("g");
                break;
            case 21:
                slice_from("rari");
                break;
            case 22:
                slice_from("oti");
                break;
            case 23:
                slice_from("si");
                break;
            case 24:
                slice_from("li");
                break;
            case 25:
                slice_from("uj");
                break;
            case 26:
                slice_from("caj");
                break;
            case 27:
                slice_from("\u010Daj");
                break;
            case 28:
                slice_from("\u0107aj");
                break;
            case 29:
                slice_from("\u0111aj");
                break;
            case 30:
                slice_from("laj");
                break;
            case 31:
                slice_from("raj");
                break;
            case 32:
                slice_from("bij");
                break;
            case 33:
                slice_from("cij");
                break;
            case 34:
                slice_from("dij");
                break;
            case 35:
                slice_from("lij");
                break;
            case 36:
                slice_from("nij");
                break;
            case 37:
                slice_from("mij");
                break;
            case 38:
                slice_from("\u017Eij");
                break;
            case 39:
                slice_from("gij");
                break;
            case 40:
                slice_from("fij");
                break;
            case 41:
                slice_from("pij");
                break;
            case 42:
                slice_from("rij");
                break;
            case 43:
                slice_from("sij");
                break;
            case 44:
                slice_from("tij");
                break;
            case 45:
                slice_from("zij");
                break;
            case 46:
                slice_from("nal");
                break;
            case 47:
                slice_from("ijal");
                break;
            case 48:
                slice_from("ozil");
                break;
            case 49:
                slice_from("olov");
                break;
            case 50:
                slice_from("ol");
                break;
            case 51:
                slice_from("lem");
                break;
            case 52:
                slice_from("ram");
                break;
            case 53:
                slice_from("ar");
                break;
            case 54:
                slice_from("dr");
                break;
            case 55:
                slice_from("er");
                break;
            case 56:
                slice_from("or");
                break;
            case 57:
                slice_from("es");
                break;
            case 58:
                slice_from("is");
                break;
            case 59:
                slice_from("ta\u0161");
                break;
            case 60:
                slice_from("na\u0161");
                break;
            case 61:
                slice_from("ja\u0161");
                break;
            case 62:
                slice_from("ka\u0161");
                break;
            case 63:
                slice_from("ba\u0161");
                break;
            case 64:
                slice_from("ga\u0161");
                break;
            case 65:
                slice_from("va\u0161");
                break;
            case 66:
                slice_from("e\u0161");
                break;
            case 67:
                slice_from("i\u0161");
                break;
            case 68:
                slice_from("ikat");
                break;
            case 69:
                slice_from("lat");
                break;
            case 70:
                slice_from("et");
                break;
            case 71:
                slice_from("est");
                break;
            case 72:
                slice_from("ist");
                break;
            case 73:
                slice_from("kst");
                break;
            case 74:
                slice_from("ost");
                break;
            case 75:
                slice_from("i\u0161t");
                break;
            case 76:
                slice_from("ova");
                break;
            case 77:
                slice_from("av");
                break;
            case 78:
                slice_from("ev");
                break;
            case 79:
                slice_from("iv");
                break;
            case 80:
                slice_from("ov");
                break;
            case 81:
                slice_from("mov");
                break;
            case 82:
                slice_from("lov");
                break;
            case 83:
                slice_from("el");
                break;
            case 84:
                slice_from("anj");
                break;
            case 85:
                slice_from("enj");
                break;
            case 86:
                slice_from("\u0161nj");
                break;
            case 87:
                slice_from("en");
                break;
            case 88:
                slice_from("\u0161n");
                break;
            case 89:
                slice_from("\u010Din");
                break;
            case 90:
                slice_from("ro\u0161i");
                break;
            case 91:
                slice_from("o\u0161");
                break;
            case 92:
                slice_from("evit");
                break;
            case 93:
                slice_from("ovit");
                break;
            case 94:
                slice_from("ast");
                break;
            case 95:
                slice_from("k");
                break;
            case 96:
                slice_from("eva");
                break;
            case 97:
                slice_from("ava");
                break;
            case 98:
                slice_from("iva");
                break;
            case 99:
                slice_from("uva");
                break;
            case 100:
                slice_from("ir");
                break;
            case 101:
                slice_from("a\u010D");
                break;
            case 102:
                slice_from("a\u010Da");
                break;
            case 103:
                slice_from("ni");
                break;
            case 104:
                slice_from("a");
                break;
            case 105:
                slice_from("ur");
                break;
            case 106:
                slice_from("astaj");
                break;
            case 107:
                slice_from("istaj");
                break;
            case 108:
                slice_from("ostaj");
                break;
            case 109:
                slice_from("aj");
                break;
            case 110:
                slice_from("asta");
                break;
            case 111:
                slice_from("ista");
                break;
            case 112:
                slice_from("osta");
                break;
            case 113:
                slice_from("ta");
                break;
            case 114:
                slice_from("inj");
                break;
            case 115:
                slice_from("as");
                break;
            case 116:
                slice_from("i");
                break;
            case 117:
                slice_from("lu\u010D");
                break;
            case 118:
                slice_from("jeti");
                break;
            case 119:
                slice_from("e");
                break;
            case 120:
                slice_from("at");
                break;
            case 121:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("luc");
                break;
            case 122:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("snj");
                break;
            case 123:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("os");
                break;
            case 124:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ac");
                break;
            case 125:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ec");
                break;
            case 126:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("uc");
                break;
            case 127:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("rosi");
                break;
            case 128:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("aca");
                break;
            case 129:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("jas");
                break;
            case 130:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("tas");
                break;
            case 131:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("gas");
                break;
            case 132:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("nas");
                break;
            case 133:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("kas");
                break;
            case 134:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("vas");
                break;
            case 135:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("bas");
                break;
            case 136:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("as");
                break;
            case 137:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("cin");
                break;
            case 138:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("astaj");
                break;
            case 139:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("istaj");
                break;
            case 140:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ostaj");
                break;
            case 141:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("asta");
                break;
            case 142:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ista");
                break;
            case 143:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("osta");
                break;
            case 144:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ava");
                break;
            case 145:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("eva");
                break;
            case 146:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("iva");
                break;
            case 147:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("uva");
                break;
            case 148:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ova");
                break;
            case 149:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("jeti");
                break;
            case 150:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("inj");
                break;
            case 151:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ist");
                break;
            case 152:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("es");
                break;
            case 153:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("et");
                break;
            case 154:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("is");
                break;
            case 155:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ir");
                break;
            case 156:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ur");
                break;
            case 157:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("uj");
                break;
            case 158:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ni");
                break;
            case 159:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("sn");
                break;
            case 160:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("ta");
                break;
            case 161:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("a");
                break;
            case 162:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("i");
                break;
            case 163:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("e");
                break;
            case 164:
                if (!B_no_diacritics)
                {
                    return false;
                }
                slice_from("n");
                break;
        }
        return true;
    }

    bool r_Step_3() {
        ket = cursor;
        if (find_among_b(a_3, null) == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        slice_del();
        return true;
    }

    @override
    bool stem() {
        r_cyr_to_lat();
        r_prelude();
        r_mark_regions();
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        r_Step_1();
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_3 = limit - cursor;
                lab2: while (true) {
                    if (!r_Step_2())
                    {
                        break lab2;
                    }
                    break lab1;
                }
                cursor = limit - v_3;
                if (!r_Step_3())
                {
                    break lab0;
                }
                break lab1;
            }
            break lab0;
        }
        cursor = limit - v_2;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is serbian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
