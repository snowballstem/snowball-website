// Generated from irish.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from irish.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class irish_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("b'", -1, 1, 0),
        Among("bh", -1, 4, 0),
        Among("bhf", 1, 2, 0),
        Among("bp", -1, 8, 0),
        Among("ch", -1, 5, 0),
        Among("d'", -1, 1, 0),
        Among("d'fh", 5, 2, 0),
        Among("dh", -1, 6, 0),
        Among("dt", -1, 9, 0),
        Among("fh", -1, 2, 0),
        Among("gc", -1, 5, 0),
        Among("gh", -1, 7, 0),
        Among("h-", -1, 1, 0),
        Among("m'", -1, 1, 0),
        Among("mb", -1, 4, 0),
        Among("mh", -1, 10, 0),
        Among("n-", -1, 1, 0),
        Among("nd", -1, 6, 0),
        Among("ng", -1, 7, 0),
        Among("ph", -1, 8, 0),
        Among("sh", -1, 3, 0),
        Among("t-", -1, 1, 0),
        Among("th", -1, 9, 0),
        Among("ts", -1, 3, 0)
    ];

    static final a_1 = [
        Among("\u00EDochta", -1, 1, 0),
        Among("a\u00EDochta", 0, 1, 0),
        Among("ire", -1, 2, 0),
        Among("aire", 2, 2, 0),
        Among("abh", -1, 1, 0),
        Among("eabh", 4, 1, 0),
        Among("ibh", -1, 1, 0),
        Among("aibh", 6, 1, 0),
        Among("amh", -1, 1, 0),
        Among("eamh", 8, 1, 0),
        Among("imh", -1, 1, 0),
        Among("aimh", 10, 1, 0),
        Among("\u00EDocht", -1, 1, 0),
        Among("a\u00EDocht", 12, 1, 0),
        Among("ir\u00ED", -1, 2, 0),
        Among("air\u00ED", 14, 2, 0)
    ];

    static final a_2 = [
        Among("\u00F3ideacha", -1, 6, 0),
        Among("patacha", -1, 5, 0),
        Among("achta", -1, 1, 0),
        Among("arcachta", 2, 2, 0),
        Among("eachta", 2, 1, 0),
        Among("grafa\u00EDochta", -1, 4, 0),
        Among("paite", -1, 5, 0),
        Among("ach", -1, 1, 0),
        Among("each", 7, 1, 0),
        Among("\u00F3ideach", 8, 6, 0),
        Among("gineach", 8, 3, 0),
        Among("patach", 7, 5, 0),
        Among("grafa\u00EDoch", -1, 4, 0),
        Among("pataigh", -1, 5, 0),
        Among("\u00F3idigh", -1, 6, 0),
        Among("acht\u00FAil", -1, 1, 0),
        Among("eacht\u00FAil", 15, 1, 0),
        Among("gineas", -1, 3, 0),
        Among("ginis", -1, 3, 0),
        Among("acht", -1, 1, 0),
        Among("arcacht", 19, 2, 0),
        Among("eacht", 19, 1, 0),
        Among("grafa\u00EDocht", -1, 4, 0),
        Among("arcachta\u00ED", -1, 2, 0),
        Among("grafa\u00EDochta\u00ED", -1, 4, 0)
    ];

    static final a_3 = [
        Among("imid", -1, 1, 0),
        Among("aimid", 0, 1, 0),
        Among("\u00EDmid", -1, 1, 0),
        Among("a\u00EDmid", 2, 1, 0),
        Among("adh", -1, 2, 0),
        Among("eadh", 4, 2, 0),
        Among("faidh", -1, 1, 0),
        Among("fidh", -1, 1, 0),
        Among("\u00E1il", -1, 2, 0),
        Among("ain", -1, 2, 0),
        Among("tear", -1, 2, 0),
        Among("tar", -1, 2, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 17, 4, 2]);

    int I_p2 = 0;
    int I_p1 = 0;
    int I_pV = 0;


    bool r_mark_regions() {
        I_pV = limit;
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            if (!go_out_grouping(g_v, 97, 250))
            {
                break lab0;
            }
            cursor++;
            I_pV = cursor;
            if (!go_in_grouping(g_v, 97, 250))
            {
                break lab0;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 250))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 250))
            {
                break lab0;
            }
            cursor++;
            I_p2 = cursor;
            break lab0;
        }
        cursor = v_1;
        return true;
    }

    bool r_initial_morph() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_0, null);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_from("f");
                break;
            case 3:
                slice_from("s");
                break;
            case 4:
                slice_from("b");
                break;
            case 5:
                slice_from("c");
                break;
            case 6:
                slice_from("d");
                break;
            case 7:
                slice_from("g");
                break;
            case 8:
                slice_from("p");
                break;
            case 9:
                slice_from("t");
                break;
            case 10:
                slice_from("m");
                break;
        }
        return true;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_noun_sfx() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_1, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_R1())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_deriv() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                slice_from("arc");
                break;
            case 3:
                slice_from("gin");
                break;
            case 4:
                slice_from("graf");
                break;
            case 5:
                slice_from("paite");
                break;
            case 6:
                slice_from("\u00F3id");
                break;
        }
        return true;
    }

    bool r_verb_sfx() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_3, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (I_pV > cursor)
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!r_R1())
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        r_initial_morph();
        cursor = v_1;
        r_mark_regions();
        limit_backward = cursor;
        cursor = limit;
        int v_2 = limit - cursor;
        r_noun_sfx();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_deriv();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_verb_sfx();
        cursor = limit - v_4;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is irish_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
