// Generated from french.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from french.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class french_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("col", -1, -1, 0),
        Among("ni", -1, 1, 0),
        Among("par", -1, -1, 0),
        Among("tap", -1, -1, 0)
    ];

    static final a_1 = [
        Among("", -1, 7, 0),
        Among("H", 0, 6, 0),
        Among("He", 1, 4, 0),
        Among("Hi", 1, 5, 0),
        Among("I", 0, 1, 0),
        Among("U", 0, 2, 0),
        Among("Y", 0, 3, 0)
    ];

    static final a_2 = [
        Among("iqU", -1, 3, 0),
        Among("abl", -1, 3, 0),
        Among("I\u00E8r", -1, 4, 0),
        Among("i\u00E8r", -1, 4, 0),
        Among("eus", -1, 2, 0),
        Among("iv", -1, 1, 0)
    ];

    static final a_3 = [
        Among("ic", -1, 2, 0),
        Among("abil", -1, 1, 0),
        Among("iv", -1, 3, 0)
    ];

    static final a_4 = [
        Among("iqUe", -1, 1, 0),
        Among("atrice", -1, 2, 0),
        Among("ance", -1, 1, 0),
        Among("ence", -1, 5, 0),
        Among("logie", -1, 3, 0),
        Among("able", -1, 1, 0),
        Among("isme", -1, 1, 0),
        Among("euse", -1, 12, 0),
        Among("iste", -1, 1, 0),
        Among("ive", -1, 8, 0),
        Among("if", -1, 8, 0),
        Among("usion", -1, 4, 0),
        Among("ation", -1, 2, 0),
        Among("ution", -1, 4, 0),
        Among("ateur", -1, 2, 0),
        Among("iqUes", -1, 1, 0),
        Among("atrices", -1, 2, 0),
        Among("ances", -1, 1, 0),
        Among("ences", -1, 5, 0),
        Among("logies", -1, 3, 0),
        Among("ables", -1, 1, 0),
        Among("ismes", -1, 1, 0),
        Among("euses", -1, 12, 0),
        Among("istes", -1, 1, 0),
        Among("ives", -1, 8, 0),
        Among("ifs", -1, 8, 0),
        Among("usions", -1, 4, 0),
        Among("ations", -1, 2, 0),
        Among("utions", -1, 4, 0),
        Among("ateurs", -1, 2, 0),
        Among("ments", -1, 16, 0),
        Among("ements", 30, 6, 0),
        Among("issements", 31, 13, 0),
        Among("it\u00E9s", -1, 7, 0),
        Among("ment", -1, 16, 0),
        Among("ement", 34, 6, 0),
        Among("issement", 35, 13, 0),
        Among("amment", 34, 14, 0),
        Among("emment", 34, 15, 0),
        Among("aux", -1, 10, 0),
        Among("eaux", 39, 9, 0),
        Among("eux", -1, 1, 0),
        Among("oux", -1, 11, 0),
        Among("it\u00E9", -1, 7, 0)
    ];

    static final a_5 = [
        Among("ira", -1, 1, 0),
        Among("ie", -1, 1, 0),
        Among("isse", -1, 1, 0),
        Among("issante", -1, 1, 0),
        Among("i", -1, 1, 0),
        Among("irai", 4, 1, 0),
        Among("ir", -1, 1, 0),
        Among("iras", -1, 1, 0),
        Among("ies", -1, 1, 0),
        Among("\u00EEmes", -1, 1, 0),
        Among("isses", -1, 1, 0),
        Among("issantes", -1, 1, 0),
        Among("\u00EEtes", -1, 1, 0),
        Among("is", -1, 1, 0),
        Among("irais", 13, 1, 0),
        Among("issais", 13, 1, 0),
        Among("irions", -1, 1, 0),
        Among("issions", -1, 1, 0),
        Among("irons", -1, 1, 0),
        Among("issons", -1, 1, 0),
        Among("issants", -1, 1, 0),
        Among("it", -1, 1, 0),
        Among("irait", 21, 1, 0),
        Among("issait", 21, 1, 0),
        Among("issant", -1, 1, 0),
        Among("iraIent", -1, 1, 0),
        Among("issaIent", -1, 1, 0),
        Among("irent", -1, 1, 0),
        Among("issent", -1, 1, 0),
        Among("iront", -1, 1, 0),
        Among("\u00EEt", -1, 1, 0),
        Among("iriez", -1, 1, 0),
        Among("issiez", -1, 1, 0),
        Among("irez", -1, 1, 0),
        Among("issez", -1, 1, 0)
    ];

    static final a_6 = [
        Among("al", -1, 1, 0),
        Among("\u00E9pl", -1, -1, 0),
        Among("auv", -1, -1, 0)
    ];

    static final a_7 = [
        Among("a", -1, 3, 0),
        Among("era", 0, 2, 0),
        Among("aise", -1, 4, 0),
        Among("asse", -1, 3, 0),
        Among("ante", -1, 3, 0),
        Among("\u00E9e", -1, 2, 0),
        Among("ai", -1, 3, 0),
        Among("erai", 6, 2, 0),
        Among("er", -1, 2, 0),
        Among("as", -1, 3, 0),
        Among("eras", 9, 2, 0),
        Among("\u00E2mes", -1, 3, 0),
        Among("aises", -1, 4, 0),
        Among("asses", -1, 3, 0),
        Among("antes", -1, 3, 0),
        Among("\u00E2tes", -1, 3, 0),
        Among("\u00E9es", -1, 2, 0),
        Among("ais", -1, 4, 0),
        Among("eais", 17, 2, 0),
        Among("erais", 17, 2, 0),
        Among("ions", -1, 1, 0),
        Among("erions", 20, 2, 0),
        Among("assions", 20, 3, 0),
        Among("erons", -1, 2, 0),
        Among("ants", -1, 3, 0),
        Among("\u00E9s", -1, 2, 0),
        Among("ait", -1, 3, 0),
        Among("erait", 26, 2, 0),
        Among("ant", -1, 3, 0),
        Among("aIent", -1, 3, 0),
        Among("eraIent", 29, 2, 0),
        Among("\u00E8rent", -1, 2, 0),
        Among("assent", -1, 3, 0),
        Among("eront", -1, 2, 0),
        Among("\u00E2t", -1, 3, 0),
        Among("ez", -1, 2, 0),
        Among("iez", 35, 2, 0),
        Among("eriez", 36, 2, 0),
        Among("assiez", 36, 3, 0),
        Among("erez", 35, 2, 0),
        Among("\u00E9", -1, 2, 0)
    ];

    static final a_8 = [
        Among("e", -1, 3, 0),
        Among("I\u00E8re", 0, 2, 0),
        Among("i\u00E8re", 0, 2, 0),
        Among("ion", -1, 1, 0),
        Among("Ier", -1, 2, 0),
        Among("ier", -1, 2, 0)
    ];

    static final a_9 = [
        Among("ell", -1, -1, 0),
        Among("eill", -1, -1, 0),
        Among("enn", -1, -1, 0),
        Among("onn", -1, -1, 0),
        Among("ett", -1, -1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 130, 103, 8, 5]);

    static final g_oux_ending = String.fromCharCodes([65, 85]);

    static final g_elision_char = String.fromCharCodes([131, 14, 3]);

    static final g_keep_with_s = String.fromCharCodes([1, 65, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128]);

    int I_p2 = 0;
    int I_p1 = 0;
    int I_pV = 0;


    bool r_elisions() {
        bra = cursor;
        lab0: while (true) {
            lab1: while (true) {
                if (!(in_grouping(g_elision_char, 99, 116)))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s("qu")))
            {
                return false;
            }
            break lab0;
        }
        if (!(eq_s("'")))
        {
            return false;
        }
        ket = cursor;
        if (cursor >= limit)
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_prelude() {
        replab0: while(true)
        {
            int v_1 = cursor;
            lab1: while (true) {
                golab2: while(true)
                {
                    int v_2 = cursor;
                    lab3: while (true) {
                        lab4: while (true) {
                            int v_3 = cursor;
                            lab5: while (true) {
                                if (!(in_grouping(g_v, 97, 251)))
                                {
                                    break lab5;
                                }
                                bra = cursor;
                                lab6: while (true) {
                                    int v_4 = cursor;
                                    lab7: while (true) {
                                        if (!(eq_s("u")))
                                        {
                                            break lab7;
                                        }
                                        ket = cursor;
                                        if (!(in_grouping(g_v, 97, 251)))
                                        {
                                            break lab7;
                                        }
                                        slice_from("U");
                                        break lab6;
                                    }
                                    cursor = v_4;
                                    lab8: while (true) {
                                        if (!(eq_s("i")))
                                        {
                                            break lab8;
                                        }
                                        ket = cursor;
                                        if (!(in_grouping(g_v, 97, 251)))
                                        {
                                            break lab8;
                                        }
                                        slice_from("I");
                                        break lab6;
                                    }
                                    cursor = v_4;
                                    if (!(eq_s("y")))
                                    {
                                        break lab5;
                                    }
                                    ket = cursor;
                                    slice_from("Y");
                                    break lab6;
                                }
                                break lab4;
                            }
                            cursor = v_3;
                            lab9: while (true) {
                                bra = cursor;
                                if (!(eq_s("\u00EB")))
                                {
                                    break lab9;
                                }
                                ket = cursor;
                                slice_from("He");
                                break lab4;
                            }
                            cursor = v_3;
                            lab10: while (true) {
                                bra = cursor;
                                if (!(eq_s("\u00EF")))
                                {
                                    break lab10;
                                }
                                ket = cursor;
                                slice_from("Hi");
                                break lab4;
                            }
                            cursor = v_3;
                            lab11: while (true) {
                                bra = cursor;
                                if (!(eq_s("y")))
                                {
                                    break lab11;
                                }
                                ket = cursor;
                                if (!(in_grouping(g_v, 97, 251)))
                                {
                                    break lab11;
                                }
                                slice_from("Y");
                                break lab4;
                            }
                            cursor = v_3;
                            if (!(eq_s("q")))
                            {
                                break lab3;
                            }
                            bra = cursor;
                            if (!(eq_s("u")))
                            {
                                break lab3;
                            }
                            ket = cursor;
                            slice_from("U");
                            break lab4;
                        }
                        cursor = v_2;
                        break golab2;
                    }
                    cursor = v_2;
                    if (cursor >= limit)
                    {
                        break lab1;
                    }
                    cursor++;
                }
                continue replab0;
            }
            cursor = v_1;
            break replab0;
        }
        return true;
    }

    bool r_mark_regions() {
        int among_var;
        I_pV = limit;
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_2 = cursor;
                lab2: while (true) {
                    if (!(in_grouping(g_v, 97, 251)))
                    {
                        break lab2;
                    }
                    if (!(in_grouping(g_v, 97, 251)))
                    {
                        break lab2;
                    }
                    if (cursor >= limit)
                    {
                        break lab2;
                    }
                    cursor++;
                    break lab1;
                }
                cursor = v_2;
                lab3: while (true) {
                    among_var = find_among(a_0, null);
                    if (among_var == 0)
                    {
                        break lab3;
                    }
                    switch (among_var) {
                        case 1:
                            if (!(in_grouping(g_v, 97, 251)))
                            {
                                break lab3;
                            }
                            break;
                    }
                    break lab1;
                }
                cursor = v_2;
                if (cursor >= limit)
                {
                    break lab0;
                }
                cursor++;
                if (!go_out_grouping(g_v, 97, 251))
                {
                    break lab0;
                }
                cursor++;
                break lab1;
            }
            I_pV = cursor;
            break lab0;
        }
        cursor = v_1;
        int v_3 = cursor;
        lab4: while (true) {
            if (!go_out_grouping(g_v, 97, 251))
            {
                break lab4;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 251))
            {
                break lab4;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 251))
            {
                break lab4;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 251))
            {
                break lab4;
            }
            cursor++;
            I_p2 = cursor;
            break lab4;
        }
        cursor = v_3;
        return true;
    }

    bool r_postlude() {
        int among_var;
        replab0: while(true)
        {
            int v_1 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_1, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("i");
                        break;
                    case 2:
                        slice_from("u");
                        break;
                    case 3:
                        slice_from("y");
                        break;
                    case 4:
                        slice_from("\u00EB");
                        break;
                    case 5:
                        slice_from("\u00EF");
                        break;
                    case 6:
                        slice_del();
                        break;
                    case 7:
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break;
                }
                continue replab0;
            }
            cursor = v_1;
            break replab0;
        }
        return true;
    }

    bool r_RV() {
        return I_pV <= cursor;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_standard_suffix() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_4, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                int v_1 = limit - cursor;
                lab0: while (true) {
                    ket = cursor;
                    if (!(eq_s_b("ic")))
                    {
                        cursor = limit - v_1;
                        break lab0;
                    }
                    bra = cursor;
                    lab1: while (true) {
                        int v_2 = limit - cursor;
                        lab2: while (true) {
                            if (!r_R2())
                            {
                                break lab2;
                            }
                            slice_del();
                            break lab1;
                        }
                        cursor = limit - v_2;
                        slice_from("iqU");
                        break lab1;
                    }
                    break lab0;
                }
                break;
            case 3:
                if (!r_R2())
                {
                    return false;
                }
                slice_from("log");
                break;
            case 4:
                if (!r_R2())
                {
                    return false;
                }
                slice_from("u");
                break;
            case 5:
                if (!r_R2())
                {
                    return false;
                }
                slice_from("ent");
                break;
            case 6:
                if (!r_RV())
                {
                    return false;
                }
                slice_del();
                int v_3 = limit - cursor;
                lab3: while (true) {
                    ket = cursor;
                    among_var = find_among_b(a_2, null);
                    if (among_var == 0)
                    {
                        cursor = limit - v_3;
                        break lab3;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            if (!r_R2())
                            {
                                cursor = limit - v_3;
                                break lab3;
                            }
                            slice_del();
                            ket = cursor;
                            if (!(eq_s_b("at")))
                            {
                                cursor = limit - v_3;
                                break lab3;
                            }
                            bra = cursor;
                            if (!r_R2())
                            {
                                cursor = limit - v_3;
                                break lab3;
                            }
                            slice_del();
                            break;
                        case 2:
                            lab4: while (true) {
                                int v_4 = limit - cursor;
                                lab5: while (true) {
                                    if (!r_R2())
                                    {
                                        break lab5;
                                    }
                                    slice_del();
                                    break lab4;
                                }
                                cursor = limit - v_4;
                                if (!r_R1())
                                {
                                    cursor = limit - v_3;
                                    break lab3;
                                }
                                slice_from("eux");
                                break lab4;
                            }
                            break;
                        case 3:
                            if (!r_R2())
                            {
                                cursor = limit - v_3;
                                break lab3;
                            }
                            slice_del();
                            break;
                        case 4:
                            if (!r_RV())
                            {
                                cursor = limit - v_3;
                                break lab3;
                            }
                            slice_from("i");
                            break;
                    }
                    break lab3;
                }
                break;
            case 7:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                int v_5 = limit - cursor;
                lab6: while (true) {
                    ket = cursor;
                    among_var = find_among_b(a_3, null);
                    if (among_var == 0)
                    {
                        cursor = limit - v_5;
                        break lab6;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            lab7: while (true) {
                                int v_6 = limit - cursor;
                                lab8: while (true) {
                                    if (!r_R2())
                                    {
                                        break lab8;
                                    }
                                    slice_del();
                                    break lab7;
                                }
                                cursor = limit - v_6;
                                slice_from("abl");
                                break lab7;
                            }
                            break;
                        case 2:
                            lab9: while (true) {
                                int v_7 = limit - cursor;
                                lab10: while (true) {
                                    if (!r_R2())
                                    {
                                        break lab10;
                                    }
                                    slice_del();
                                    break lab9;
                                }
                                cursor = limit - v_7;
                                slice_from("iqU");
                                break lab9;
                            }
                            break;
                        case 3:
                            if (!r_R2())
                            {
                                cursor = limit - v_5;
                                break lab6;
                            }
                            slice_del();
                            break;
                    }
                    break lab6;
                }
                break;
            case 8:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                int v_8 = limit - cursor;
                lab11: while (true) {
                    ket = cursor;
                    if (!(eq_s_b("at")))
                    {
                        cursor = limit - v_8;
                        break lab11;
                    }
                    bra = cursor;
                    if (!r_R2())
                    {
                        cursor = limit - v_8;
                        break lab11;
                    }
                    slice_del();
                    ket = cursor;
                    if (!(eq_s_b("ic")))
                    {
                        cursor = limit - v_8;
                        break lab11;
                    }
                    bra = cursor;
                    lab12: while (true) {
                        int v_9 = limit - cursor;
                        lab13: while (true) {
                            if (!r_R2())
                            {
                                break lab13;
                            }
                            slice_del();
                            break lab12;
                        }
                        cursor = limit - v_9;
                        slice_from("iqU");
                        break lab12;
                    }
                    break lab11;
                }
                break;
            case 9:
                slice_from("eau");
                break;
            case 10:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("al");
                break;
            case 11:
                if (!(in_grouping_b(g_oux_ending, 98, 112)))
                {
                    return false;
                }
                slice_from("ou");
                break;
            case 12:
                lab14: while (true) {
                    int v_10 = limit - cursor;
                    lab15: while (true) {
                        if (!r_R2())
                        {
                            break lab15;
                        }
                        slice_del();
                        break lab14;
                    }
                    cursor = limit - v_10;
                    if (!r_R1())
                    {
                        return false;
                    }
                    slice_from("eux");
                    break lab14;
                }
                break;
            case 13:
                if (!r_R1())
                {
                    return false;
                }
                if (!(out_grouping_b(g_v, 97, 251)))
                {
                    return false;
                }
                slice_del();
                break;
            case 14:
                if (!r_RV())
                {
                    return false;
                }
                slice_from("ant");
                return false;
            case 15:
                if (!r_RV())
                {
                    return false;
                }
                slice_from("ent");
                return false;
            case 16:
                int v_11 = limit - cursor;
                if (!(in_grouping_b(g_v, 97, 251)))
                {
                    return false;
                }
                if (!r_RV())
                {
                    return false;
                }
                cursor = limit - v_11;
                slice_del();
                return false;
        }
        return true;
    }

    bool r_i_verb_suffix() {
        if (cursor < I_pV)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_pV;
        ket = cursor;
        if (find_among_b(a_5, null) == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        lab0: while (true) {
            if (!(eq_s_b("H")))
            {
                break lab0;
            }
            limit_backward = v_1;
            return false;
        }
        if (!(out_grouping_b(g_v, 97, 251)))
        {
            limit_backward = v_1;
            return false;
        }
        slice_del();
        limit_backward = v_1;
        return true;
    }

    bool r_verb_suffix() {
        int among_var;
        if (cursor < I_pV)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_pV;
        ket = cursor;
        among_var = find_among_b(a_7, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                slice_del();
                break;
            case 3:
                int v_2 = limit - cursor;
                lab0: while (true) {
                    if (!(eq_s_b("e")))
                    {
                        cursor = limit - v_2;
                        break lab0;
                    }
                    if (!r_RV())
                    {
                        cursor = limit - v_2;
                        break lab0;
                    }
                    bra = cursor;
                    break lab0;
                }
                slice_del();
                break;
            case 4:
                {
                    int v_3 = limit - cursor;
                    lab1: while (true) {
                        among_var = find_among_b(a_6, null);
                        if (among_var == 0)
                        {
                            break lab1;
                        }
                        switch (among_var) {
                            case 1:
                                if (cursor <= limit_backward)
                                {
                                    break lab1;
                                }
                                cursor--;
                                if (cursor > limit_backward)
                                {
                                    break lab1;
                                }
                                break;
                        }
                        return false;
                    }
                    cursor = limit - v_3;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_residual_suffix() {
        int among_var;
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            if (!(eq_s_b("s")))
            {
                cursor = limit - v_1;
                break lab0;
            }
            bra = cursor;
            int v_2 = limit - cursor;
            lab1: while (true) {
                lab2: while (true) {
                    if (!(eq_s_b("Hi")))
                    {
                        break lab2;
                    }
                    break lab1;
                }
                if (!(out_grouping_b(g_keep_with_s, 97, 232)))
                {
                    cursor = limit - v_1;
                    break lab0;
                }
                break lab1;
            }
            cursor = limit - v_2;
            slice_del();
            break lab0;
        }
        if (cursor < I_pV)
        {
            return false;
        }
        int v_3 = limit_backward;
        limit_backward = I_pV;
        ket = cursor;
        among_var = find_among_b(a_8, null);
        if (among_var == 0)
        {
            limit_backward = v_3;
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_R2())
                {
                    limit_backward = v_3;
                    return false;
                }
                lab3: while (true) {
                    lab4: while (true) {
                        if (!(eq_s_b("s")))
                        {
                            break lab4;
                        }
                        break lab3;
                    }
                    if (!(eq_s_b("t")))
                    {
                        limit_backward = v_3;
                        return false;
                    }
                    break lab3;
                }
                slice_del();
                break;
            case 2:
                slice_from("i");
                break;
            case 3:
                slice_del();
                break;
        }
        limit_backward = v_3;
        return true;
    }

    bool r_un_double() {
        int v_1 = limit - cursor;
        if (find_among_b(a_9, null) == 0)
        {
            return false;
        }
        cursor = limit - v_1;
        ket = cursor;
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor--;
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_un_accent() {
        {
            int v_1 = 1;
            replab0: while(true)
            {
                lab1: while (true) {
                    if (!(out_grouping_b(g_v, 97, 251)))
                    {
                        break lab1;
                    }
                    v_1--;
                    continue replab0;
                }
                break replab0;
            }
            if (v_1 > 0)
            {
                return false;
            }
        }
        ket = cursor;
        lab2: while (true) {
            lab3: while (true) {
                if (!(eq_s_b("\u00E9")))
                {
                    break lab3;
                }
                break lab2;
            }
            if (!(eq_s_b("\u00E8")))
            {
                return false;
            }
            break lab2;
        }
        bra = cursor;
        slice_from("e");
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        r_elisions();
        cursor = v_1;
        int v_2 = cursor;
        r_prelude();
        cursor = v_2;
        r_mark_regions();
        limit_backward = cursor;
        cursor = limit;
        int v_3 = limit - cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_4 = limit - cursor;
                lab2: while (true) {
                    int v_5 = limit - cursor;
                    lab3: while (true) {
                        int v_6 = limit - cursor;
                        lab4: while (true) {
                            if (!r_standard_suffix())
                            {
                                break lab4;
                            }
                            break lab3;
                        }
                        cursor = limit - v_6;
                        lab5: while (true) {
                            if (!r_i_verb_suffix())
                            {
                                break lab5;
                            }
                            break lab3;
                        }
                        cursor = limit - v_6;
                        if (!r_verb_suffix())
                        {
                            break lab2;
                        }
                        break lab3;
                    }
                    cursor = limit - v_5;
                    int v_7 = limit - cursor;
                    lab6: while (true) {
                        ket = cursor;
                        lab7: while (true) {
                            int v_8 = limit - cursor;
                            lab8: while (true) {
                                if (!(eq_s_b("Y")))
                                {
                                    break lab8;
                                }
                                bra = cursor;
                                slice_from("i");
                                break lab7;
                            }
                            cursor = limit - v_8;
                            if (!(eq_s_b("\u00E7")))
                            {
                                cursor = limit - v_7;
                                break lab6;
                            }
                            bra = cursor;
                            slice_from("c");
                            break lab7;
                        }
                        break lab6;
                    }
                    break lab1;
                }
                cursor = limit - v_4;
                if (!r_residual_suffix())
                {
                    break lab0;
                }
                break lab1;
            }
            break lab0;
        }
        cursor = limit - v_3;
        int v_9 = limit - cursor;
        r_un_double();
        cursor = limit - v_9;
        int v_10 = limit - cursor;
        r_un_accent();
        cursor = limit - v_10;
        cursor = limit_backward;
        int v_11 = cursor;
        r_postlude();
        cursor = v_11;
        return true;
    }

    @override
    bool operator ==(Object other) => other is french_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
