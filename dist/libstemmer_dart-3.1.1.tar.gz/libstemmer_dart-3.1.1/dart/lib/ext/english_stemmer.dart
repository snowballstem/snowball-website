// Generated from english.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from english.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class english_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("arsen", -1, -1, 0),
        Among("commun", -1, -1, 0),
        Among("emerg", -1, -1, 0),
        Among("gener", -1, -1, 0),
        Among("inter", -1, -1, 0),
        Among("later", -1, -1, 0),
        Among("organ", -1, -1, 0),
        Among("past", -1, -1, 0),
        Among("univers", -1, -1, 0)
    ];

    static final a_1 = [
        Among("'", -1, 1, 0),
        Among("'s'", 0, 1, 0),
        Among("'s", -1, 1, 0)
    ];

    static final a_2 = [
        Among("ied", -1, 2, 0),
        Among("s", -1, 3, 0),
        Among("ies", 1, 2, 0),
        Among("sses", 1, 1, 0),
        Among("ss", 1, -1, 0),
        Among("us", 1, -1, 0)
    ];

    static final a_3 = [
        Among("succ", -1, 1, 0),
        Among("proc", -1, 1, 0),
        Among("exc", -1, 1, 0)
    ];

    static final a_4 = [
        Among("even", -1, 2, 0),
        Among("cann", -1, 2, 0),
        Among("inn", -1, 2, 0),
        Among("earr", -1, 2, 0),
        Among("herr", -1, 2, 0),
        Among("out", -1, 2, 0),
        Among("y", -1, 1, 0)
    ];

    static final a_5 = [
        Among("", -1, -1, 0),
        Among("ed", 0, 2, 0),
        Among("eed", 1, 1, 0),
        Among("ing", 0, 3, 0),
        Among("edly", 0, 2, 0),
        Among("eedly", 4, 1, 0),
        Among("ingly", 0, 2, 0)
    ];

    static final a_6 = [
        Among("", -1, 3, 0),
        Among("bb", 0, 2, 0),
        Among("dd", 0, 2, 0),
        Among("ff", 0, 2, 0),
        Among("gg", 0, 2, 0),
        Among("bl", 0, 1, 0),
        Among("mm", 0, 2, 0),
        Among("nn", 0, 2, 0),
        Among("pp", 0, 2, 0),
        Among("rr", 0, 2, 0),
        Among("at", 0, 1, 0),
        Among("tt", 0, 2, 0),
        Among("iz", 0, 1, 0)
    ];

    static final a_7 = [
        Among("anci", -1, 3, 0),
        Among("enci", -1, 2, 0),
        Among("ogi", -1, 14, 0),
        Among("li", -1, 16, 0),
        Among("bli", 3, 12, 0),
        Among("abli", 4, 4, 0),
        Among("alli", 3, 8, 0),
        Among("fulli", 3, 9, 0),
        Among("lessli", 3, 15, 0),
        Among("ousli", 3, 10, 0),
        Among("entli", 3, 5, 0),
        Among("aliti", -1, 8, 0),
        Among("biliti", -1, 12, 0),
        Among("iviti", -1, 11, 0),
        Among("tional", -1, 1, 0),
        Among("ational", 14, 7, 0),
        Among("alism", -1, 8, 0),
        Among("ation", -1, 7, 0),
        Among("ization", 17, 6, 0),
        Among("izer", -1, 6, 0),
        Among("ator", -1, 7, 0),
        Among("iveness", -1, 11, 0),
        Among("fulness", -1, 9, 0),
        Among("ousness", -1, 10, 0),
        Among("ogist", -1, 13, 0)
    ];

    static final a_8 = [
        Among("icate", -1, 4, 0),
        Among("ative", -1, 6, 0),
        Among("alize", -1, 3, 0),
        Among("iciti", -1, 4, 0),
        Among("ical", -1, 4, 0),
        Among("tional", -1, 1, 0),
        Among("ational", 5, 2, 0),
        Among("ful", -1, 5, 0),
        Among("ness", -1, 5, 0)
    ];

    static final a_9 = [
        Among("ic", -1, 1, 0),
        Among("ance", -1, 1, 0),
        Among("ence", -1, 1, 0),
        Among("able", -1, 1, 0),
        Among("ible", -1, 1, 0),
        Among("ate", -1, 1, 0),
        Among("ive", -1, 1, 0),
        Among("ize", -1, 1, 0),
        Among("iti", -1, 1, 0),
        Among("al", -1, 1, 0),
        Among("ism", -1, 1, 0),
        Among("ion", -1, 2, 0),
        Among("er", -1, 1, 0),
        Among("ous", -1, 1, 0),
        Among("ant", -1, 1, 0),
        Among("ent", -1, 1, 0),
        Among("ment", 15, 1, 0),
        Among("ement", 16, 1, 0)
    ];

    static final a_10 = [
        Among("e", -1, 1, 0),
        Among("l", -1, 2, 0)
    ];

    static final a_11 = [
        Among("andes", -1, -1, 0),
        Among("atlas", -1, -1, 0),
        Among("bias", -1, -1, 0),
        Among("cosmos", -1, -1, 0),
        Among("early", -1, 6, 0),
        Among("gently", -1, 4, 0),
        Among("howe", -1, -1, 0),
        Among("idly", -1, 3, 0),
        Among("news", -1, -1, 0),
        Among("only", -1, 7, 0),
        Among("singly", -1, 8, 0),
        Among("skies", -1, 2, 0),
        Among("skis", -1, 1, 0),
        Among("sky", -1, -1, 0),
        Among("ugly", -1, 5, 0)
    ];

    static final g_aeo = String.fromCharCodes([17, 64]);

    static final g_v = String.fromCharCodes([17, 65, 16, 1]);

    static final g_v_WXY = String.fromCharCodes([1, 17, 65, 208, 1]);

    static final g_valid_LI = String.fromCharCodes([55, 141, 2]);

    bool B_Y_found = false;
    int I_p2 = 0;
    int I_p1 = 0;


    bool r_prelude() {
        B_Y_found = false;
        int v_1 = cursor;
        lab0: while (true) {
            bra = cursor;
            if (!(eq_s("'")))
            {
                break lab0;
            }
            ket = cursor;
            slice_del();
            break lab0;
        }
        cursor = v_1;
        int v_2 = cursor;
        lab1: while (true) {
            bra = cursor;
            if (!(eq_s("y")))
            {
                break lab1;
            }
            ket = cursor;
            slice_from("Y");
            B_Y_found = true;
            break lab1;
        }
        cursor = v_2;
        int v_3 = cursor;
        lab2: while (true) {
            replab3: while(true)
            {
                int v_4 = cursor;
                lab4: while (true) {
                    golab5: while(true)
                    {
                        int v_5 = cursor;
                        lab6: while (true) {
                            if (!(in_grouping(g_v, 97, 121)))
                            {
                                break lab6;
                            }
                            bra = cursor;
                            if (!(eq_s("y")))
                            {
                                break lab6;
                            }
                            ket = cursor;
                            cursor = v_5;
                            break golab5;
                        }
                        cursor = v_5;
                        if (cursor >= limit)
                        {
                            break lab4;
                        }
                        cursor++;
                    }
                    slice_from("Y");
                    B_Y_found = true;
                    continue replab3;
                }
                cursor = v_4;
                break replab3;
            }
            break lab2;
        }
        cursor = v_3;
        return true;
    }

    bool r_mark_regions() {
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_2 = cursor;
                lab2: while (true) {
                    if (find_among(a_0, null) == 0)
                    {
                        break lab2;
                    }
                    break lab1;
                }
                cursor = v_2;
                if (!go_out_grouping(g_v, 97, 121))
                {
                    break lab0;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 121))
                {
                    break lab0;
                }
                cursor++;
                break lab1;
            }
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 121))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 121))
            {
                break lab0;
            }
            cursor++;
            I_p2 = cursor;
            break lab0;
        }
        cursor = v_1;
        return true;
    }

    bool r_shortv() {
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (!(out_grouping_b(g_v_WXY, 89, 121)))
                {
                    break lab1;
                }
                if (!(in_grouping_b(g_v, 97, 121)))
                {
                    break lab1;
                }
                if (!(out_grouping_b(g_v, 97, 121)))
                {
                    break lab1;
                }
                break lab0;
            }
            cursor = limit - v_1;
            lab2: while (true) {
                if (!(out_grouping_b(g_v, 97, 121)))
                {
                    break lab2;
                }
                if (!(in_grouping_b(g_v, 97, 121)))
                {
                    break lab2;
                }
                if (cursor > limit_backward)
                {
                    break lab2;
                }
                break lab0;
            }
            cursor = limit - v_1;
            if (!(eq_s_b("past")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_Step_1a() {
        int among_var;
        int v_1 = limit - cursor;
        lab0: while (true) {
            ket = cursor;
            if (find_among_b(a_1, null) == 0)
            {
                cursor = limit - v_1;
                break lab0;
            }
            bra = cursor;
            slice_del();
            break lab0;
        }
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("ss");
                break;
            case 2:
                lab1: while (true) {
                    int v_2 = limit - cursor;
                    lab2: while (true) {
                        {
                            int c = cursor - 2;
                            if (c < limit_backward)
                            {
                                break lab2;
                            }
                            cursor = c;
                        }
                        slice_from("i");
                        break lab1;
                    }
                    cursor = limit - v_2;
                    slice_from("ie");
                    break lab1;
                }
                break;
            case 3:
                if (cursor <= limit_backward)
                {
                    return false;
                }
                cursor--;
                if (!go_out_grouping_b(g_v, 97, 121))
                {
                    return false;
                }
                cursor--;
                slice_del();
                break;
        }
        return true;
    }

    bool r_Step_1b() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_5, null);
        bra = cursor;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                switch (among_var) {
                    case 1:
                        int v_2 = limit - cursor;
                        lab2: while (true) {
                            if (!r_R1())
                            {
                                break lab2;
                            }
                            lab3: while (true) {
                                int v_3 = limit - cursor;
                                lab4: while (true) {
                                    if (find_among_b(a_3, null) == 0)
                                    {
                                        break lab4;
                                    }
                                    if (cursor > limit_backward)
                                    {
                                        break lab4;
                                    }
                                    break lab3;
                                }
                                cursor = limit - v_3;
                                slice_from("ee");
                                break lab3;
                            }
                            break lab2;
                        }
                        cursor = limit - v_2;
                        break;
                    case 2:
                        break lab1;
                    case 3:
                        among_var = find_among_b(a_4, null);
                        if (among_var == 0)
                        {
                            break lab1;
                        }
                        switch (among_var) {
                            case 1:
                                int v_4 = limit - cursor;
                                if (!(out_grouping_b(g_v, 97, 121)))
                                {
                                    break lab1;
                                }
                                if (cursor > limit_backward)
                                {
                                    break lab1;
                                }
                                cursor = limit - v_4;
                                bra = cursor;
                                slice_from("ie");
                                break;
                            case 2:
                                if (cursor > limit_backward)
                                {
                                    break lab1;
                                }
                                break;
                        }
                        break;
                }
                break lab0;
            }
            cursor = limit - v_1;
            int v_5 = limit - cursor;
            if (!go_out_grouping_b(g_v, 97, 121))
            {
                return false;
            }
            cursor--;
            cursor = limit - v_5;
            slice_del();
            ket = cursor;
            bra = cursor;
            int v_6 = limit - cursor;
            among_var = find_among_b(a_6, null);
            switch (among_var) {
                case 1:
                    slice_from("e");
                    return false;
                case 2:
                    {
                        int v_7 = limit - cursor;
                        lab5: while (true) {
                            if (!(in_grouping_b(g_aeo, 97, 111)))
                            {
                                break lab5;
                            }
                            if (cursor > limit_backward)
                            {
                                break lab5;
                            }
                            return false;
                        }
                        cursor = limit - v_7;
                    }
                    break;
                case 3:
                    if (cursor != I_p1)
                    {
                        return false;
                    }
                    int v_8 = limit - cursor;
                    if (!r_shortv())
                    {
                        return false;
                    }
                    cursor = limit - v_8;
                    slice_from("e");
                    return false;
            }
            cursor = limit - v_6;
            ket = cursor;
            if (cursor <= limit_backward)
            {
                return false;
            }
            cursor--;
            bra = cursor;
            slice_del();
            break lab0;
        }
        return true;
    }

    bool r_Step_1c() {
        ket = cursor;
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("y")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("Y")))
            {
                return false;
            }
            break lab0;
        }
        bra = cursor;
        if (!(out_grouping_b(g_v, 97, 121)))
        {
            return false;
        }
        if (cursor <= limit_backward)
        {
            return false;
        }
        slice_from("i");
        return true;
    }

    bool r_Step_2() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_7, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("tion");
                break;
            case 2:
                slice_from("ence");
                break;
            case 3:
                slice_from("ance");
                break;
            case 4:
                slice_from("able");
                break;
            case 5:
                slice_from("ent");
                break;
            case 6:
                slice_from("ize");
                break;
            case 7:
                slice_from("ate");
                break;
            case 8:
                slice_from("al");
                break;
            case 9:
                slice_from("ful");
                break;
            case 10:
                slice_from("ous");
                break;
            case 11:
                slice_from("ive");
                break;
            case 12:
                slice_from("ble");
                break;
            case 13:
                slice_from("og");
                break;
            case 14:
                if (!(eq_s_b("l")))
                {
                    return false;
                }
                slice_from("og");
                break;
            case 15:
                slice_from("less");
                break;
            case 16:
                if (!(in_grouping_b(g_valid_LI, 99, 116)))
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_Step_3() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_8, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("tion");
                break;
            case 2:
                slice_from("ate");
                break;
            case 3:
                slice_from("al");
                break;
            case 4:
                slice_from("ic");
                break;
            case 5:
                slice_del();
                break;
            case 6:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_Step_4() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_9, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R2())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                lab0: while (true) {
                    lab1: while (true) {
                        if (!(eq_s_b("s")))
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    if (!(eq_s_b("t")))
                    {
                        return false;
                    }
                    break lab0;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_Step_5() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_10, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    lab1: while (true) {
                        if (!r_R2())
                        {
                            break lab1;
                        }
                        break lab0;
                    }
                    if (!r_R1())
                    {
                        return false;
                    }
                    {
                        int v_1 = limit - cursor;
                        lab2: while (true) {
                            if (!r_shortv())
                            {
                                break lab2;
                            }
                            return false;
                        }
                        cursor = limit - v_1;
                    }
                    break lab0;
                }
                slice_del();
                break;
            case 2:
                if (!r_R2())
                {
                    return false;
                }
                if (!(eq_s_b("l")))
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_exception1() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_11, null);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        if (cursor < limit)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_from("ski");
                break;
            case 2:
                slice_from("sky");
                break;
            case 3:
                slice_from("idl");
                break;
            case 4:
                slice_from("gentl");
                break;
            case 5:
                slice_from("ugli");
                break;
            case 6:
                slice_from("earli");
                break;
            case 7:
                slice_from("onli");
                break;
            case 8:
                slice_from("singl");
                break;
        }
        return true;
    }

    bool r_postlude() {
        if (!B_Y_found)
        {
            return false;
        }
        replab0: while(true)
        {
            int v_1 = cursor;
            lab1: while (true) {
                golab2: while(true)
                {
                    int v_2 = cursor;
                    lab3: while (true) {
                        bra = cursor;
                        if (!(eq_s("Y")))
                        {
                            break lab3;
                        }
                        ket = cursor;
                        cursor = v_2;
                        break golab2;
                    }
                    cursor = v_2;
                    if (cursor >= limit)
                    {
                        break lab1;
                    }
                    cursor++;
                }
                slice_from("y");
                continue replab0;
            }
            cursor = v_1;
            break replab0;
        }
        return true;
    }

    @override
    bool stem() {
        lab0: while (true) {
            int v_1 = cursor;
            lab1: while (true) {
                if (!r_exception1())
                {
                    break lab1;
                }
                break lab0;
            }
            cursor = v_1;
            lab2: while (true) {
                lab3: while (true) {
                    {
                        int c = cursor + 3;
                        if (c > limit)
                        {
                            break lab3;
                        }
                        cursor = c;
                    }
                    break lab2;
                }
                break lab0;
            }
            cursor = v_1;
            r_prelude();
            r_mark_regions();
            limit_backward = cursor;
            cursor = limit;
            int v_2 = limit - cursor;
            r_Step_1a();
            cursor = limit - v_2;
            int v_3 = limit - cursor;
            r_Step_1b();
            cursor = limit - v_3;
            int v_4 = limit - cursor;
            r_Step_1c();
            cursor = limit - v_4;
            int v_5 = limit - cursor;
            r_Step_2();
            cursor = limit - v_5;
            int v_6 = limit - cursor;
            r_Step_3();
            cursor = limit - v_6;
            int v_7 = limit - cursor;
            r_Step_4();
            cursor = limit - v_7;
            int v_8 = limit - cursor;
            r_Step_5();
            cursor = limit - v_8;
            cursor = limit_backward;
            int v_9 = cursor;
            r_postlude();
            cursor = v_9;
            break lab0;
        }
        return true;
    }

    @override
    bool operator ==(Object other) => other is english_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
