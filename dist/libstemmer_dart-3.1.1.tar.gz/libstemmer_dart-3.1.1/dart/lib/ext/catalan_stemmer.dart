// Generated from catalan.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from catalan.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class catalan_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 7, 0),
        Among("\u00B7", 0, 6, 0),
        Among("\u00E0", 0, 1, 0),
        Among("\u00E1", 0, 1, 0),
        Among("\u00E8", 0, 2, 0),
        Among("\u00E9", 0, 2, 0),
        Among("\u00EC", 0, 3, 0),
        Among("\u00ED", 0, 3, 0),
        Among("\u00EF", 0, 3, 0),
        Among("\u00F2", 0, 4, 0),
        Among("\u00F3", 0, 4, 0),
        Among("\u00FA", 0, 5, 0),
        Among("\u00FC", 0, 5, 0)
    ];

    static final a_1 = [
        Among("la", -1, 1, 0),
        Among("-la", 0, 1, 0),
        Among("sela", 0, 1, 0),
        Among("le", -1, 1, 0),
        Among("me", -1, 1, 0),
        Among("-me", 4, 1, 0),
        Among("se", -1, 1, 0),
        Among("-te", -1, 1, 0),
        Among("hi", -1, 1, 0),
        Among("'hi", 8, 1, 0),
        Among("li", -1, 1, 0),
        Among("-li", 10, 1, 0),
        Among("'l", -1, 1, 0),
        Among("'m", -1, 1, 0),
        Among("-m", -1, 1, 0),
        Among("'n", -1, 1, 0),
        Among("-n", -1, 1, 0),
        Among("ho", -1, 1, 0),
        Among("'ho", 17, 1, 0),
        Among("lo", -1, 1, 0),
        Among("selo", 19, 1, 0),
        Among("'s", -1, 1, 0),
        Among("las", -1, 1, 0),
        Among("selas", 22, 1, 0),
        Among("les", -1, 1, 0),
        Among("-les", 24, 1, 0),
        Among("'ls", -1, 1, 0),
        Among("-ls", -1, 1, 0),
        Among("'ns", -1, 1, 0),
        Among("-ns", -1, 1, 0),
        Among("ens", -1, 1, 0),
        Among("los", -1, 1, 0),
        Among("selos", 31, 1, 0),
        Among("nos", -1, 1, 0),
        Among("-nos", 33, 1, 0),
        Among("vos", -1, 1, 0),
        Among("us", -1, 1, 0),
        Among("-us", 36, 1, 0),
        Among("'t", -1, 1, 0)
    ];

    static final a_2 = [
        Among("ica", -1, 4, 0),
        Among("l\u00F3gica", 0, 3, 0),
        Among("enca", -1, 1, 0),
        Among("ada", -1, 2, 0),
        Among("ancia", -1, 1, 0),
        Among("encia", -1, 1, 0),
        Among("\u00E8ncia", -1, 1, 0),
        Among("\u00EDcia", -1, 1, 0),
        Among("logia", -1, 3, 0),
        Among("inia", -1, 1, 0),
        Among("\u00EDinia", 9, 1, 0),
        Among("eria", -1, 1, 0),
        Among("\u00E0ria", -1, 1, 0),
        Among("at\u00F2ria", -1, 1, 0),
        Among("alla", -1, 1, 0),
        Among("ella", -1, 1, 0),
        Among("\u00EDvola", -1, 1, 0),
        Among("ima", -1, 1, 0),
        Among("\u00EDssima", 17, 1, 0),
        Among("qu\u00EDssima", 18, 5, 0),
        Among("ana", -1, 1, 0),
        Among("ina", -1, 1, 0),
        Among("era", -1, 1, 0),
        Among("sfera", 22, 1, 0),
        Among("ora", -1, 1, 0),
        Among("dora", 24, 1, 0),
        Among("adora", 25, 1, 0),
        Among("adura", -1, 1, 0),
        Among("esa", -1, 1, 0),
        Among("osa", -1, 1, 0),
        Among("assa", -1, 1, 0),
        Among("essa", -1, 1, 0),
        Among("issa", -1, 1, 0),
        Among("eta", -1, 1, 0),
        Among("ita", -1, 1, 0),
        Among("ota", -1, 1, 0),
        Among("ista", -1, 1, 0),
        Among("ialista", 36, 1, 0),
        Among("ionista", 36, 1, 0),
        Among("iva", -1, 1, 0),
        Among("ativa", 39, 1, 0),
        Among("n\u00E7a", -1, 1, 0),
        Among("log\u00EDa", -1, 3, 0),
        Among("ic", -1, 4, 0),
        Among("\u00EDstic", 43, 1, 0),
        Among("enc", -1, 1, 0),
        Among("esc", -1, 1, 0),
        Among("ud", -1, 1, 0),
        Among("atge", -1, 1, 0),
        Among("ble", -1, 1, 0),
        Among("able", 49, 1, 0),
        Among("ible", 49, 1, 0),
        Among("isme", -1, 1, 0),
        Among("ialisme", 52, 1, 0),
        Among("ionisme", 52, 1, 0),
        Among("ivisme", 52, 1, 0),
        Among("aire", -1, 1, 0),
        Among("icte", -1, 1, 0),
        Among("iste", -1, 1, 0),
        Among("ici", -1, 1, 0),
        Among("\u00EDci", -1, 1, 0),
        Among("logi", -1, 3, 0),
        Among("ari", -1, 1, 0),
        Among("tori", -1, 1, 0),
        Among("al", -1, 1, 0),
        Among("il", -1, 1, 0),
        Among("all", -1, 1, 0),
        Among("ell", -1, 1, 0),
        Among("\u00EDvol", -1, 1, 0),
        Among("isam", -1, 1, 0),
        Among("issem", -1, 1, 0),
        Among("\u00ECssem", -1, 1, 0),
        Among("\u00EDssem", -1, 1, 0),
        Among("\u00EDssim", -1, 1, 0),
        Among("qu\u00EDssim", 73, 5, 0),
        Among("amen", -1, 1, 0),
        Among("\u00ECssin", -1, 1, 0),
        Among("ar", -1, 1, 0),
        Among("ificar", 77, 1, 0),
        Among("egar", 77, 1, 0),
        Among("ejar", 77, 1, 0),
        Among("itar", 77, 1, 0),
        Among("itzar", 77, 1, 0),
        Among("fer", -1, 1, 0),
        Among("or", -1, 1, 0),
        Among("dor", 84, 1, 0),
        Among("dur", -1, 1, 0),
        Among("doras", -1, 1, 0),
        Among("ics", -1, 4, 0),
        Among("l\u00F3gics", 88, 3, 0),
        Among("uds", -1, 1, 0),
        Among("nces", -1, 1, 0),
        Among("ades", -1, 2, 0),
        Among("ancies", -1, 1, 0),
        Among("encies", -1, 1, 0),
        Among("\u00E8ncies", -1, 1, 0),
        Among("\u00EDcies", -1, 1, 0),
        Among("logies", -1, 3, 0),
        Among("inies", -1, 1, 0),
        Among("\u00EDnies", -1, 1, 0),
        Among("eries", -1, 1, 0),
        Among("\u00E0ries", -1, 1, 0),
        Among("at\u00F2ries", -1, 1, 0),
        Among("bles", -1, 1, 0),
        Among("ables", 103, 1, 0),
        Among("ibles", 103, 1, 0),
        Among("imes", -1, 1, 0),
        Among("\u00EDssimes", 106, 1, 0),
        Among("qu\u00EDssimes", 107, 5, 0),
        Among("formes", -1, 1, 0),
        Among("ismes", -1, 1, 0),
        Among("ialismes", 110, 1, 0),
        Among("ines", -1, 1, 0),
        Among("eres", -1, 1, 0),
        Among("ores", -1, 1, 0),
        Among("dores", 114, 1, 0),
        Among("idores", 115, 1, 0),
        Among("dures", -1, 1, 0),
        Among("eses", -1, 1, 0),
        Among("oses", -1, 1, 0),
        Among("asses", -1, 1, 0),
        Among("ictes", -1, 1, 0),
        Among("ites", -1, 1, 0),
        Among("otes", -1, 1, 0),
        Among("istes", -1, 1, 0),
        Among("ialistes", 124, 1, 0),
        Among("ionistes", 124, 1, 0),
        Among("iques", -1, 4, 0),
        Among("l\u00F3giques", 127, 3, 0),
        Among("ives", -1, 1, 0),
        Among("atives", 129, 1, 0),
        Among("log\u00EDes", -1, 3, 0),
        Among("alleng\u00FCes", -1, 1, 0),
        Among("icis", -1, 1, 0),
        Among("\u00EDcis", -1, 1, 0),
        Among("logis", -1, 3, 0),
        Among("aris", -1, 1, 0),
        Among("toris", -1, 1, 0),
        Among("ls", -1, 1, 0),
        Among("als", 138, 1, 0),
        Among("ells", 138, 1, 0),
        Among("ims", -1, 1, 0),
        Among("\u00EDssims", 141, 1, 0),
        Among("qu\u00EDssims", 142, 5, 0),
        Among("ions", -1, 1, 0),
        Among("cions", 144, 1, 0),
        Among("acions", 145, 2, 0),
        Among("esos", -1, 1, 0),
        Among("osos", -1, 1, 0),
        Among("assos", -1, 1, 0),
        Among("issos", -1, 1, 0),
        Among("ers", -1, 1, 0),
        Among("ors", -1, 1, 0),
        Among("dors", 152, 1, 0),
        Among("adors", 153, 1, 0),
        Among("idors", 153, 1, 0),
        Among("ats", -1, 1, 0),
        Among("itats", 156, 1, 0),
        Among("bilitats", 157, 1, 0),
        Among("ivitats", 157, 1, 0),
        Among("ativitats", 159, 1, 0),
        Among("\u00EFtats", 156, 1, 0),
        Among("ets", -1, 1, 0),
        Among("ants", -1, 1, 0),
        Among("ents", -1, 1, 0),
        Among("ments", 164, 1, 0),
        Among("aments", 165, 1, 0),
        Among("ots", -1, 1, 0),
        Among("uts", -1, 1, 0),
        Among("ius", -1, 1, 0),
        Among("trius", 169, 1, 0),
        Among("atius", 169, 1, 0),
        Among("\u00E8s", -1, 1, 0),
        Among("\u00E9s", -1, 1, 0),
        Among("\u00EDs", -1, 1, 0),
        Among("d\u00EDs", 174, 1, 0),
        Among("\u00F3s", -1, 1, 0),
        Among("itat", -1, 1, 0),
        Among("bilitat", 177, 1, 0),
        Among("ivitat", 177, 1, 0),
        Among("ativitat", 179, 1, 0),
        Among("\u00EFtat", -1, 1, 0),
        Among("et", -1, 1, 0),
        Among("ant", -1, 1, 0),
        Among("ent", -1, 1, 0),
        Among("ient", 184, 1, 0),
        Among("ment", 184, 1, 0),
        Among("ament", 186, 1, 0),
        Among("isament", 187, 1, 0),
        Among("ot", -1, 1, 0),
        Among("isseu", -1, 1, 0),
        Among("\u00ECsseu", -1, 1, 0),
        Among("\u00EDsseu", -1, 1, 0),
        Among("triu", -1, 1, 0),
        Among("\u00EDssiu", -1, 1, 0),
        Among("atiu", -1, 1, 0),
        Among("\u00F3", -1, 1, 0),
        Among("i\u00F3", 196, 1, 0),
        Among("ci\u00F3", 197, 1, 0),
        Among("aci\u00F3", 198, 1, 0)
    ];

    static final a_3 = [
        Among("aba", -1, 1, 0),
        Among("esca", -1, 1, 0),
        Among("isca", -1, 1, 0),
        Among("\u00EFsca", -1, 1, 0),
        Among("ada", -1, 1, 0),
        Among("ida", -1, 1, 0),
        Among("uda", -1, 1, 0),
        Among("\u00EFda", -1, 1, 0),
        Among("ia", -1, 1, 0),
        Among("aria", 8, 1, 0),
        Among("iria", 8, 1, 0),
        Among("ara", -1, 1, 0),
        Among("iera", -1, 1, 0),
        Among("ira", -1, 1, 0),
        Among("adora", -1, 1, 0),
        Among("\u00EFra", -1, 1, 0),
        Among("ava", -1, 1, 0),
        Among("ixa", -1, 1, 0),
        Among("itza", -1, 1, 0),
        Among("\u00EDa", -1, 1, 0),
        Among("ar\u00EDa", 19, 1, 0),
        Among("er\u00EDa", 19, 1, 0),
        Among("ir\u00EDa", 19, 1, 0),
        Among("\u00EFa", -1, 1, 0),
        Among("isc", -1, 1, 0),
        Among("\u00EFsc", -1, 1, 0),
        Among("ad", -1, 1, 0),
        Among("ed", -1, 1, 0),
        Among("id", -1, 1, 0),
        Among("ie", -1, 1, 0),
        Among("re", -1, 1, 0),
        Among("dre", 30, 1, 0),
        Among("ase", -1, 1, 0),
        Among("iese", -1, 1, 0),
        Among("aste", -1, 1, 0),
        Among("iste", -1, 1, 0),
        Among("ii", -1, 1, 0),
        Among("ini", -1, 1, 0),
        Among("esqui", -1, 1, 0),
        Among("eixi", -1, 1, 0),
        Among("itzi", -1, 1, 0),
        Among("am", -1, 1, 0),
        Among("em", -1, 1, 0),
        Among("arem", 42, 1, 0),
        Among("irem", 42, 1, 0),
        Among("\u00E0rem", 42, 1, 0),
        Among("\u00EDrem", 42, 1, 0),
        Among("\u00E0ssem", 42, 1, 0),
        Among("\u00E9ssem", 42, 1, 0),
        Among("iguem", 42, 1, 0),
        Among("\u00EFguem", 42, 1, 0),
        Among("avem", 42, 1, 0),
        Among("\u00E0vem", 42, 1, 0),
        Among("\u00E1vem", 42, 1, 0),
        Among("ir\u00ECem", 42, 1, 0),
        Among("\u00EDem", 42, 1, 0),
        Among("ar\u00EDem", 55, 1, 0),
        Among("ir\u00EDem", 55, 1, 0),
        Among("assim", -1, 1, 0),
        Among("essim", -1, 1, 0),
        Among("issim", -1, 1, 0),
        Among("\u00E0ssim", -1, 1, 0),
        Among("\u00E8ssim", -1, 1, 0),
        Among("\u00E9ssim", -1, 1, 0),
        Among("\u00EDssim", -1, 1, 0),
        Among("\u00EFm", -1, 1, 0),
        Among("an", -1, 1, 0),
        Among("aban", 66, 1, 0),
        Among("arian", 66, 1, 0),
        Among("aran", 66, 1, 0),
        Among("ieran", 66, 1, 0),
        Among("iran", 66, 1, 0),
        Among("\u00EDan", 66, 1, 0),
        Among("ar\u00EDan", 72, 1, 0),
        Among("er\u00EDan", 72, 1, 0),
        Among("ir\u00EDan", 72, 1, 0),
        Among("en", -1, 1, 0),
        Among("ien", 76, 1, 0),
        Among("arien", 77, 1, 0),
        Among("irien", 77, 1, 0),
        Among("aren", 76, 1, 0),
        Among("eren", 76, 1, 0),
        Among("iren", 76, 1, 0),
        Among("\u00E0ren", 76, 1, 0),
        Among("\u00EFren", 76, 1, 0),
        Among("asen", 76, 1, 0),
        Among("iesen", 76, 1, 0),
        Among("assen", 76, 1, 0),
        Among("essen", 76, 1, 0),
        Among("issen", 76, 1, 0),
        Among("\u00E9ssen", 76, 1, 0),
        Among("\u00EFssen", 76, 1, 0),
        Among("esquen", 76, 1, 0),
        Among("isquen", 76, 1, 0),
        Among("\u00EFsquen", 76, 1, 0),
        Among("aven", 76, 1, 0),
        Among("ixen", 76, 1, 0),
        Among("eixen", 96, 1, 0),
        Among("\u00EFxen", 76, 1, 0),
        Among("\u00EFen", 76, 1, 0),
        Among("in", -1, 1, 0),
        Among("inin", 100, 1, 0),
        Among("sin", 100, 1, 0),
        Among("isin", 102, 1, 0),
        Among("assin", 102, 1, 0),
        Among("essin", 102, 1, 0),
        Among("issin", 102, 1, 0),
        Among("\u00EFssin", 102, 1, 0),
        Among("esquin", 100, 1, 0),
        Among("eixin", 100, 1, 0),
        Among("aron", -1, 1, 0),
        Among("ieron", -1, 1, 0),
        Among("ar\u00E1n", -1, 1, 0),
        Among("er\u00E1n", -1, 1, 0),
        Among("ir\u00E1n", -1, 1, 0),
        Among("i\u00EFn", -1, 1, 0),
        Among("ado", -1, 1, 0),
        Among("ido", -1, 1, 0),
        Among("ando", -1, 2, 0),
        Among("iendo", -1, 1, 0),
        Among("io", -1, 1, 0),
        Among("ixo", -1, 1, 0),
        Among("eixo", 121, 1, 0),
        Among("\u00EFxo", -1, 1, 0),
        Among("itzo", -1, 1, 0),
        Among("ar", -1, 1, 0),
        Among("tzar", 125, 1, 0),
        Among("er", -1, 1, 0),
        Among("eixer", 127, 1, 0),
        Among("ir", -1, 1, 0),
        Among("ador", -1, 1, 0),
        Among("as", -1, 1, 0),
        Among("abas", 131, 1, 0),
        Among("adas", 131, 1, 0),
        Among("idas", 131, 1, 0),
        Among("aras", 131, 1, 0),
        Among("ieras", 131, 1, 0),
        Among("\u00EDas", 131, 1, 0),
        Among("ar\u00EDas", 137, 1, 0),
        Among("er\u00EDas", 137, 1, 0),
        Among("ir\u00EDas", 137, 1, 0),
        Among("ids", -1, 1, 0),
        Among("es", -1, 1, 0),
        Among("ades", 142, 1, 0),
        Among("ides", 142, 1, 0),
        Among("udes", 142, 1, 0),
        Among("\u00EFdes", 142, 1, 0),
        Among("atges", 142, 1, 0),
        Among("ies", 142, 1, 0),
        Among("aries", 148, 1, 0),
        Among("iries", 148, 1, 0),
        Among("ares", 142, 1, 0),
        Among("ires", 142, 1, 0),
        Among("adores", 142, 1, 0),
        Among("\u00EFres", 142, 1, 0),
        Among("ases", 142, 1, 0),
        Among("ieses", 142, 1, 0),
        Among("asses", 142, 1, 0),
        Among("esses", 142, 1, 0),
        Among("isses", 142, 1, 0),
        Among("\u00EFsses", 142, 1, 0),
        Among("ques", 142, 1, 0),
        Among("esques", 161, 1, 0),
        Among("\u00EFsques", 161, 1, 0),
        Among("aves", 142, 1, 0),
        Among("ixes", 142, 1, 0),
        Among("eixes", 165, 1, 0),
        Among("\u00EFxes", 142, 1, 0),
        Among("\u00EFes", 142, 1, 0),
        Among("abais", -1, 1, 0),
        Among("arais", -1, 1, 0),
        Among("ierais", -1, 1, 0),
        Among("\u00EDais", -1, 1, 0),
        Among("ar\u00EDais", 172, 1, 0),
        Among("er\u00EDais", 172, 1, 0),
        Among("ir\u00EDais", 172, 1, 0),
        Among("aseis", -1, 1, 0),
        Among("ieseis", -1, 1, 0),
        Among("asteis", -1, 1, 0),
        Among("isteis", -1, 1, 0),
        Among("inis", -1, 1, 0),
        Among("sis", -1, 1, 0),
        Among("isis", 181, 1, 0),
        Among("assis", 181, 1, 0),
        Among("essis", 181, 1, 0),
        Among("issis", 181, 1, 0),
        Among("\u00EFssis", 181, 1, 0),
        Among("esquis", -1, 1, 0),
        Among("eixis", -1, 1, 0),
        Among("itzis", -1, 1, 0),
        Among("\u00E1is", -1, 1, 0),
        Among("ar\u00E9is", -1, 1, 0),
        Among("er\u00E9is", -1, 1, 0),
        Among("ir\u00E9is", -1, 1, 0),
        Among("ams", -1, 1, 0),
        Among("ados", -1, 1, 0),
        Among("idos", -1, 1, 0),
        Among("amos", -1, 1, 0),
        Among("\u00E1bamos", 197, 1, 0),
        Among("\u00E1ramos", 197, 1, 0),
        Among("i\u00E9ramos", 197, 1, 0),
        Among("\u00EDamos", 197, 1, 0),
        Among("ar\u00EDamos", 201, 1, 0),
        Among("er\u00EDamos", 201, 1, 0),
        Among("ir\u00EDamos", 201, 1, 0),
        Among("aremos", -1, 1, 0),
        Among("eremos", -1, 1, 0),
        Among("iremos", -1, 1, 0),
        Among("\u00E1semos", -1, 1, 0),
        Among("i\u00E9semos", -1, 1, 0),
        Among("imos", -1, 1, 0),
        Among("adors", -1, 1, 0),
        Among("ass", -1, 1, 0),
        Among("erass", 212, 1, 0),
        Among("ess", -1, 1, 0),
        Among("ats", -1, 1, 0),
        Among("its", -1, 1, 0),
        Among("ents", -1, 1, 0),
        Among("\u00E0s", -1, 1, 0),
        Among("ar\u00E0s", 218, 1, 0),
        Among("ir\u00E0s", 218, 1, 0),
        Among("ar\u00E1s", -1, 1, 0),
        Among("er\u00E1s", -1, 1, 0),
        Among("ir\u00E1s", -1, 1, 0),
        Among("\u00E9s", -1, 1, 0),
        Among("ar\u00E9s", 224, 1, 0),
        Among("\u00EDs", -1, 1, 0),
        Among("i\u00EFs", -1, 1, 0),
        Among("at", -1, 1, 0),
        Among("it", -1, 1, 0),
        Among("ant", -1, 1, 0),
        Among("ent", -1, 1, 0),
        Among("int", -1, 1, 0),
        Among("ut", -1, 1, 0),
        Among("\u00EFt", -1, 1, 0),
        Among("au", -1, 1, 0),
        Among("erau", 235, 1, 0),
        Among("ieu", -1, 1, 0),
        Among("ineu", -1, 1, 0),
        Among("areu", -1, 1, 0),
        Among("ireu", -1, 1, 0),
        Among("\u00E0reu", -1, 1, 0),
        Among("\u00EDreu", -1, 1, 0),
        Among("asseu", -1, 1, 0),
        Among("esseu", -1, 1, 0),
        Among("eresseu", 244, 1, 0),
        Among("\u00E0sseu", -1, 1, 0),
        Among("\u00E9sseu", -1, 1, 0),
        Among("igueu", -1, 1, 0),
        Among("\u00EFgueu", -1, 1, 0),
        Among("\u00E0veu", -1, 1, 0),
        Among("\u00E1veu", -1, 1, 0),
        Among("itzeu", -1, 1, 0),
        Among("\u00ECeu", -1, 1, 0),
        Among("ir\u00ECeu", 253, 1, 0),
        Among("\u00EDeu", -1, 1, 0),
        Among("ar\u00EDeu", 255, 1, 0),
        Among("ir\u00EDeu", 255, 1, 0),
        Among("assiu", -1, 1, 0),
        Among("issiu", -1, 1, 0),
        Among("\u00E0ssiu", -1, 1, 0),
        Among("\u00E8ssiu", -1, 1, 0),
        Among("\u00E9ssiu", -1, 1, 0),
        Among("\u00EDssiu", -1, 1, 0),
        Among("\u00EFu", -1, 1, 0),
        Among("ix", -1, 1, 0),
        Among("eix", 265, 1, 0),
        Among("\u00EFx", -1, 1, 0),
        Among("itz", -1, 1, 0),
        Among("i\u00E0", -1, 1, 0),
        Among("ar\u00E0", -1, 1, 0),
        Among("ir\u00E0", -1, 1, 0),
        Among("itz\u00E0", -1, 1, 0),
        Among("ar\u00E1", -1, 1, 0),
        Among("er\u00E1", -1, 1, 0),
        Among("ir\u00E1", -1, 1, 0),
        Among("ir\u00E8", -1, 1, 0),
        Among("ar\u00E9", -1, 1, 0),
        Among("er\u00E9", -1, 1, 0),
        Among("ir\u00E9", -1, 1, 0),
        Among("\u00ED", -1, 1, 0),
        Among("i\u00EF", -1, 1, 0),
        Among("i\u00F3", -1, 1, 0)
    ];

    static final a_4 = [
        Among("a", -1, 1, 0),
        Among("e", -1, 1, 0),
        Among("i", -1, 1, 0),
        Among("\u00EFn", -1, 1, 0),
        Among("o", -1, 1, 0),
        Among("ir", -1, 1, 0),
        Among("s", -1, 1, 0),
        Among("is", 6, 1, 0),
        Among("os", 6, 1, 0),
        Among("\u00EFs", 6, 1, 0),
        Among("it", -1, 1, 0),
        Among("eu", -1, 1, 0),
        Among("iu", -1, 1, 0),
        Among("iqu", -1, 2, 0),
        Among("itz", -1, 1, 0),
        Among("\u00E0", -1, 1, 0),
        Among("\u00E1", -1, 1, 0),
        Among("\u00E9", -1, 1, 0),
        Among("\u00EC", -1, 1, 0),
        Among("\u00ED", -1, 1, 0),
        Among("\u00EF", -1, 1, 0),
        Among("\u00F3", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 129, 81, 6, 10]);

    int I_p2 = 0;
    int I_p1 = 0;


    bool r_mark_regions() {
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            if (!go_out_grouping(g_v, 97, 252))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 252))
            {
                break lab0;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 252))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 252))
            {
                break lab0;
            }
            cursor++;
            I_p2 = cursor;
            break lab0;
        }
        cursor = v_1;
        return true;
    }

    bool r_cleaning() {
        int among_var;
        replab0: while(true)
        {
            int v_1 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_0, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("a");
                        break;
                    case 2:
                        slice_from("e");
                        break;
                    case 3:
                        slice_from("i");
                        break;
                    case 4:
                        slice_from("o");
                        break;
                    case 5:
                        slice_from("u");
                        break;
                    case 6:
                        slice_from(".");
                        break;
                    case 7:
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break;
                }
                continue replab0;
            }
            cursor = v_1;
            break replab0;
        }
        return true;
    }

    bool r_R1() {
        return I_p1 <= cursor;
    }

    bool r_R2() {
        return I_p2 <= cursor;
    }

    bool r_attached_pronoun() {
        ket = cursor;
        if (find_among_b(a_1, null) == 0)
        {
            return false;
        }
        bra = cursor;
        if (!r_R1())
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_standard_suffix() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_R1())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                break;
            case 3:
                if (!r_R2())
                {
                    return false;
                }
                slice_from("log");
                break;
            case 4:
                if (!r_R2())
                {
                    return false;
                }
                slice_from("ic");
                break;
            case 5:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("c");
                break;
        }
        return true;
    }

    bool r_verb_suffix() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_3, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_R1())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!r_R2())
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_residual_suffix() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_4, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (!r_R1())
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (!r_R1())
                {
                    return false;
                }
                slice_from("ic");
                break;
        }
        return true;
    }

    @override
    bool stem() {
        r_mark_regions();
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        r_attached_pronoun();
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_3 = limit - cursor;
                lab2: while (true) {
                    if (!r_standard_suffix())
                    {
                        break lab2;
                    }
                    break lab1;
                }
                cursor = limit - v_3;
                if (!r_verb_suffix())
                {
                    break lab0;
                }
                break lab1;
            }
            break lab0;
        }
        cursor = limit - v_2;
        int v_4 = limit - cursor;
        r_residual_suffix();
        cursor = limit - v_4;
        cursor = limit_backward;
        int v_5 = cursor;
        r_cleaning();
        cursor = v_5;
        return true;
    }

    @override
    bool operator ==(Object other) => other is catalan_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
