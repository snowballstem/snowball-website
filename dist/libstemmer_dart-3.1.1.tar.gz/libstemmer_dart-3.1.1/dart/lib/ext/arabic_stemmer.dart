// Generated from arabic.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from arabic.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class arabic_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("\u0640", -1, 1, 0),
        Among("\u064B", -1, 1, 0),
        Among("\u064C", -1, 1, 0),
        Among("\u064D", -1, 1, 0),
        Among("\u064E", -1, 1, 0),
        Among("\u064F", -1, 1, 0),
        Among("\u0650", -1, 1, 0),
        Among("\u0651", -1, 1, 0),
        Among("\u0652", -1, 1, 0),
        Among("\u0660", -1, 2, 0),
        Among("\u0661", -1, 3, 0),
        Among("\u0662", -1, 4, 0),
        Among("\u0663", -1, 5, 0),
        Among("\u0664", -1, 6, 0),
        Among("\u0665", -1, 7, 0),
        Among("\u0666", -1, 8, 0),
        Among("\u0667", -1, 9, 0),
        Among("\u0668", -1, 10, 0),
        Among("\u0669", -1, 11, 0),
        Among("\uFE80", -1, 12, 0),
        Among("\uFE81", -1, 16, 0),
        Among("\uFE82", -1, 16, 0),
        Among("\uFE83", -1, 13, 0),
        Among("\uFE84", -1, 13, 0),
        Among("\uFE85", -1, 17, 0),
        Among("\uFE86", -1, 17, 0),
        Among("\uFE87", -1, 14, 0),
        Among("\uFE88", -1, 14, 0),
        Among("\uFE89", -1, 15, 0),
        Among("\uFE8A", -1, 15, 0),
        Among("\uFE8B", -1, 15, 0),
        Among("\uFE8C", -1, 15, 0),
        Among("\uFE8D", -1, 18, 0),
        Among("\uFE8E", -1, 18, 0),
        Among("\uFE8F", -1, 19, 0),
        Among("\uFE90", -1, 19, 0),
        Among("\uFE91", -1, 19, 0),
        Among("\uFE92", -1, 19, 0),
        Among("\uFE93", -1, 20, 0),
        Among("\uFE94", -1, 20, 0),
        Among("\uFE95", -1, 21, 0),
        Among("\uFE96", -1, 21, 0),
        Among("\uFE97", -1, 21, 0),
        Among("\uFE98", -1, 21, 0),
        Among("\uFE99", -1, 22, 0),
        Among("\uFE9A", -1, 22, 0),
        Among("\uFE9B", -1, 22, 0),
        Among("\uFE9C", -1, 22, 0),
        Among("\uFE9D", -1, 23, 0),
        Among("\uFE9E", -1, 23, 0),
        Among("\uFE9F", -1, 23, 0),
        Among("\uFEA0", -1, 23, 0),
        Among("\uFEA1", -1, 24, 0),
        Among("\uFEA2", -1, 24, 0),
        Among("\uFEA3", -1, 24, 0),
        Among("\uFEA4", -1, 24, 0),
        Among("\uFEA5", -1, 25, 0),
        Among("\uFEA6", -1, 25, 0),
        Among("\uFEA7", -1, 25, 0),
        Among("\uFEA8", -1, 25, 0),
        Among("\uFEA9", -1, 26, 0),
        Among("\uFEAA", -1, 26, 0),
        Among("\uFEAB", -1, 27, 0),
        Among("\uFEAC", -1, 27, 0),
        Among("\uFEAD", -1, 28, 0),
        Among("\uFEAE", -1, 28, 0),
        Among("\uFEAF", -1, 29, 0),
        Among("\uFEB0", -1, 29, 0),
        Among("\uFEB1", -1, 30, 0),
        Among("\uFEB2", -1, 30, 0),
        Among("\uFEB3", -1, 30, 0),
        Among("\uFEB4", -1, 30, 0),
        Among("\uFEB5", -1, 31, 0),
        Among("\uFEB6", -1, 31, 0),
        Among("\uFEB7", -1, 31, 0),
        Among("\uFEB8", -1, 31, 0),
        Among("\uFEB9", -1, 32, 0),
        Among("\uFEBA", -1, 32, 0),
        Among("\uFEBB", -1, 32, 0),
        Among("\uFEBC", -1, 32, 0),
        Among("\uFEBD", -1, 33, 0),
        Among("\uFEBE", -1, 33, 0),
        Among("\uFEBF", -1, 33, 0),
        Among("\uFEC0", -1, 33, 0),
        Among("\uFEC1", -1, 34, 0),
        Among("\uFEC2", -1, 34, 0),
        Among("\uFEC3", -1, 34, 0),
        Among("\uFEC4", -1, 34, 0),
        Among("\uFEC5", -1, 35, 0),
        Among("\uFEC6", -1, 35, 0),
        Among("\uFEC7", -1, 35, 0),
        Among("\uFEC8", -1, 35, 0),
        Among("\uFEC9", -1, 36, 0),
        Among("\uFECA", -1, 36, 0),
        Among("\uFECB", -1, 36, 0),
        Among("\uFECC", -1, 36, 0),
        Among("\uFECD", -1, 37, 0),
        Among("\uFECE", -1, 37, 0),
        Among("\uFECF", -1, 37, 0),
        Among("\uFED0", -1, 37, 0),
        Among("\uFED1", -1, 38, 0),
        Among("\uFED2", -1, 38, 0),
        Among("\uFED3", -1, 38, 0),
        Among("\uFED4", -1, 38, 0),
        Among("\uFED5", -1, 39, 0),
        Among("\uFED6", -1, 39, 0),
        Among("\uFED7", -1, 39, 0),
        Among("\uFED8", -1, 39, 0),
        Among("\uFED9", -1, 40, 0),
        Among("\uFEDA", -1, 40, 0),
        Among("\uFEDB", -1, 40, 0),
        Among("\uFEDC", -1, 40, 0),
        Among("\uFEDD", -1, 41, 0),
        Among("\uFEDE", -1, 41, 0),
        Among("\uFEDF", -1, 41, 0),
        Among("\uFEE0", -1, 41, 0),
        Among("\uFEE1", -1, 42, 0),
        Among("\uFEE2", -1, 42, 0),
        Among("\uFEE3", -1, 42, 0),
        Among("\uFEE4", -1, 42, 0),
        Among("\uFEE5", -1, 43, 0),
        Among("\uFEE6", -1, 43, 0),
        Among("\uFEE7", -1, 43, 0),
        Among("\uFEE8", -1, 43, 0),
        Among("\uFEE9", -1, 44, 0),
        Among("\uFEEA", -1, 44, 0),
        Among("\uFEEB", -1, 44, 0),
        Among("\uFEEC", -1, 44, 0),
        Among("\uFEED", -1, 45, 0),
        Among("\uFEEE", -1, 45, 0),
        Among("\uFEEF", -1, 46, 0),
        Among("\uFEF0", -1, 46, 0),
        Among("\uFEF1", -1, 47, 0),
        Among("\uFEF2", -1, 47, 0),
        Among("\uFEF3", -1, 47, 0),
        Among("\uFEF4", -1, 47, 0),
        Among("\uFEF5", -1, 51, 0),
        Among("\uFEF6", -1, 51, 0),
        Among("\uFEF7", -1, 49, 0),
        Among("\uFEF8", -1, 49, 0),
        Among("\uFEF9", -1, 50, 0),
        Among("\uFEFA", -1, 50, 0),
        Among("\uFEFB", -1, 48, 0),
        Among("\uFEFC", -1, 48, 0)
    ];

    static final a_1 = [
        Among("\u0622", -1, 1, 0),
        Among("\u0623", -1, 1, 0),
        Among("\u0624", -1, 1, 0),
        Among("\u0625", -1, 1, 0),
        Among("\u0626", -1, 1, 0)
    ];

    static final a_2 = [
        Among("\u0622", -1, 1, 0),
        Among("\u0623", -1, 1, 0),
        Among("\u0624", -1, 2, 0),
        Among("\u0625", -1, 1, 0),
        Among("\u0626", -1, 3, 0)
    ];

    static final a_3 = [
        Among("\u0627\u0644", -1, 2, 0),
        Among("\u0628\u0627\u0644", -1, 1, 0),
        Among("\u0643\u0627\u0644", -1, 1, 0),
        Among("\u0644\u0644", -1, 2, 0)
    ];

    static final a_4 = [
        Among("\u0623\u0622", -1, 2, 0),
        Among("\u0623\u0623", -1, 1, 0),
        Among("\u0623\u0624", -1, 1, 0),
        Among("\u0623\u0625", -1, 4, 0),
        Among("\u0623\u0627", -1, 3, 0)
    ];

    static final a_5 = [
        Among("\u0641", -1, 1, 0),
        Among("\u0648", -1, 1, 0)
    ];

    static final a_6 = [
        Among("\u0627\u0644", -1, 2, 0),
        Among("\u0628\u0627\u0644", -1, 1, 0),
        Among("\u0643\u0627\u0644", -1, 1, 0),
        Among("\u0644\u0644", -1, 2, 0)
    ];

    static final a_7 = [
        Among("\u0628", -1, 1, 0),
        Among("\u0628\u0627", 0, -1, 0),
        Among("\u0628\u0628", 0, 2, 0),
        Among("\u0643\u0643", -1, 3, 0)
    ];

    static final a_8 = [
        Among("\u0633\u0623", -1, 4, 0),
        Among("\u0633\u062A", -1, 2, 0),
        Among("\u0633\u0646", -1, 3, 0),
        Among("\u0633\u064A", -1, 1, 0)
    ];

    static final a_9 = [
        Among("\u062A\u0633\u062A", -1, 1, 0),
        Among("\u0646\u0633\u062A", -1, 1, 0),
        Among("\u064A\u0633\u062A", -1, 1, 0)
    ];

    static final a_10 = [
        Among("\u0643\u0645\u0627", -1, 3, 0),
        Among("\u0647\u0645\u0627", -1, 3, 0),
        Among("\u0646\u0627", -1, 2, 0),
        Among("\u0647\u0627", -1, 2, 0),
        Among("\u0643", -1, 1, 0),
        Among("\u0643\u0645", -1, 2, 0),
        Among("\u0647\u0645", -1, 2, 0),
        Among("\u0647\u0646", -1, 2, 0),
        Among("\u0647", -1, 1, 0),
        Among("\u064A", -1, 1, 0)
    ];

    static final a_11 = [
        Among("\u0627", -1, 1, 0),
        Among("\u0648", -1, 1, 0),
        Among("\u064A", -1, 1, 0)
    ];

    static final a_12 = [
        Among("\u0643\u0645\u0627", -1, 3, 0),
        Among("\u0647\u0645\u0627", -1, 3, 0),
        Among("\u0646\u0627", -1, 2, 0),
        Among("\u0647\u0627", -1, 2, 0),
        Among("\u0643", -1, 1, 0),
        Among("\u0643\u0645", -1, 2, 0),
        Among("\u0647\u0645", -1, 2, 0),
        Among("\u0643\u0646", -1, 2, 0),
        Among("\u0647\u0646", -1, 2, 0),
        Among("\u0647", -1, 1, 0),
        Among("\u0643\u0645\u0648", -1, 3, 0),
        Among("\u0646\u064A", -1, 2, 0)
    ];

    static final a_13 = [
        Among("\u0627", -1, 1, 0),
        Among("\u062A\u0627", 0, 2, 0),
        Among("\u062A\u0645\u0627", 0, 4, 0),
        Among("\u0646\u0627", 0, 2, 0),
        Among("\u062A", -1, 1, 0),
        Among("\u0646", -1, 1, 0),
        Among("\u0627\u0646", 5, 3, 0),
        Among("\u062A\u0646", 5, 2, 0),
        Among("\u0648\u0646", 5, 3, 0),
        Among("\u064A\u0646", 5, 3, 0),
        Among("\u064A", -1, 1, 0)
    ];

    static final a_14 = [
        Among("\u0648\u0627", -1, 1, 0),
        Among("\u062A\u0645", -1, 1, 0)
    ];

    static final a_15 = [
        Among("\u0648", -1, 1, 0),
        Among("\u062A\u0645\u0648", 0, 2, 0)
    ];

    bool B_is_defined = false;
    bool B_is_verb = false;
    bool B_is_noun = false;


    bool r_Normalize_pre() {
        int among_var;
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = cursor;
                lab2: while (true) {
                    lab3: while (true) {
                        int v_3 = cursor;
                        lab4: while (true) {
                            bra = cursor;
                            among_var = find_among(a_0, null);
                            if (among_var == 0)
                            {
                                break lab4;
                            }
                            ket = cursor;
                            switch (among_var) {
                                case 1:
                                    slice_del();
                                    break;
                                case 2:
                                    slice_from("0");
                                    break;
                                case 3:
                                    slice_from("1");
                                    break;
                                case 4:
                                    slice_from("2");
                                    break;
                                case 5:
                                    slice_from("3");
                                    break;
                                case 6:
                                    slice_from("4");
                                    break;
                                case 7:
                                    slice_from("5");
                                    break;
                                case 8:
                                    slice_from("6");
                                    break;
                                case 9:
                                    slice_from("7");
                                    break;
                                case 10:
                                    slice_from("8");
                                    break;
                                case 11:
                                    slice_from("9");
                                    break;
                                case 12:
                                    slice_from("\u0621");
                                    break;
                                case 13:
                                    slice_from("\u0623");
                                    break;
                                case 14:
                                    slice_from("\u0625");
                                    break;
                                case 15:
                                    slice_from("\u0626");
                                    break;
                                case 16:
                                    slice_from("\u0622");
                                    break;
                                case 17:
                                    slice_from("\u0624");
                                    break;
                                case 18:
                                    slice_from("\u0627");
                                    break;
                                case 19:
                                    slice_from("\u0628");
                                    break;
                                case 20:
                                    slice_from("\u0629");
                                    break;
                                case 21:
                                    slice_from("\u062A");
                                    break;
                                case 22:
                                    slice_from("\u062B");
                                    break;
                                case 23:
                                    slice_from("\u062C");
                                    break;
                                case 24:
                                    slice_from("\u062D");
                                    break;
                                case 25:
                                    slice_from("\u062E");
                                    break;
                                case 26:
                                    slice_from("\u062F");
                                    break;
                                case 27:
                                    slice_from("\u0630");
                                    break;
                                case 28:
                                    slice_from("\u0631");
                                    break;
                                case 29:
                                    slice_from("\u0632");
                                    break;
                                case 30:
                                    slice_from("\u0633");
                                    break;
                                case 31:
                                    slice_from("\u0634");
                                    break;
                                case 32:
                                    slice_from("\u0635");
                                    break;
                                case 33:
                                    slice_from("\u0636");
                                    break;
                                case 34:
                                    slice_from("\u0637");
                                    break;
                                case 35:
                                    slice_from("\u0638");
                                    break;
                                case 36:
                                    slice_from("\u0639");
                                    break;
                                case 37:
                                    slice_from("\u063A");
                                    break;
                                case 38:
                                    slice_from("\u0641");
                                    break;
                                case 39:
                                    slice_from("\u0642");
                                    break;
                                case 40:
                                    slice_from("\u0643");
                                    break;
                                case 41:
                                    slice_from("\u0644");
                                    break;
                                case 42:
                                    slice_from("\u0645");
                                    break;
                                case 43:
                                    slice_from("\u0646");
                                    break;
                                case 44:
                                    slice_from("\u0647");
                                    break;
                                case 45:
                                    slice_from("\u0648");
                                    break;
                                case 46:
                                    slice_from("\u0649");
                                    break;
                                case 47:
                                    slice_from("\u064A");
                                    break;
                                case 48:
                                    slice_from("\u0644\u0627");
                                    break;
                                case 49:
                                    slice_from("\u0644\u0623");
                                    break;
                                case 50:
                                    slice_from("\u0644\u0625");
                                    break;
                                case 51:
                                    slice_from("\u0644\u0622");
                                    break;
                            }
                            break lab3;
                        }
                        cursor = v_3;
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                        break lab3;
                    }
                    continue replab1;
                }
                cursor = v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = v_1;
        return true;
    }

    bool r_Normalize_post() {
        int among_var;
        int v_1 = cursor;
        lab0: while (true) {
            limit_backward = cursor;
            cursor = limit;
            ket = cursor;
            if (find_among_b(a_1, null) == 0)
            {
                break lab0;
            }
            bra = cursor;
            slice_from("\u0621");
            cursor = limit_backward;
            break lab0;
        }
        cursor = v_1;
        int v_2 = cursor;
        lab1: while (true) {
            replab2: while(true)
            {
                int v_3 = cursor;
                lab3: while (true) {
                    lab4: while (true) {
                        int v_4 = cursor;
                        lab5: while (true) {
                            bra = cursor;
                            among_var = find_among(a_2, null);
                            if (among_var == 0)
                            {
                                break lab5;
                            }
                            ket = cursor;
                            switch (among_var) {
                                case 1:
                                    slice_from("\u0627");
                                    break;
                                case 2:
                                    slice_from("\u0648");
                                    break;
                                case 3:
                                    slice_from("\u064A");
                                    break;
                            }
                            break lab4;
                        }
                        cursor = v_4;
                        if (cursor >= limit)
                        {
                            break lab3;
                        }
                        cursor++;
                        break lab4;
                    }
                    continue replab2;
                }
                cursor = v_3;
                break replab2;
            }
            break lab1;
        }
        cursor = v_2;
        return true;
    }

    bool r_Checks1() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_3, null);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        switch (among_var) {
            case 1:
                if (current.length <= 4)
                {
                    return false;
                }
                B_is_noun = true;
                B_is_verb = false;
                B_is_defined = true;
                break;
            case 2:
                if (current.length <= 3)
                {
                    return false;
                }
                B_is_noun = true;
                B_is_verb = false;
                B_is_defined = true;
                break;
        }
        return true;
    }

    bool r_Prefix_Step1() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_4, null);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        switch (among_var) {
            case 1:
                if (current.length <= 3)
                {
                    return false;
                }
                slice_from("\u0623");
                break;
            case 2:
                if (current.length <= 3)
                {
                    return false;
                }
                slice_from("\u0622");
                break;
            case 3:
                if (current.length <= 3)
                {
                    return false;
                }
                slice_from("\u0627");
                break;
            case 4:
                if (current.length <= 3)
                {
                    return false;
                }
                slice_from("\u0625");
                break;
        }
        return true;
    }

    bool r_Prefix_Step2() {
        bra = cursor;
        if (find_among(a_5, null) == 0)
        {
            return false;
        }
        ket = cursor;
        if (current.length <= 3)
        {
            return false;
        }
        lab0: while (true) {
            if (!(eq_s("\u0627")))
            {
                break lab0;
            }
            return false;
        }
        slice_del();
        return true;
    }

    bool r_Prefix_Step3a_Noun() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_6, null);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        switch (among_var) {
            case 1:
                if (current.length <= 5)
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (current.length <= 4)
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_Prefix_Step3b_Noun() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_7, null);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        switch (among_var) {
            case 1:
                if (current.length <= 3)
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (current.length <= 3)
                {
                    return false;
                }
                slice_from("\u0628");
                break;
            case 3:
                if (current.length <= 3)
                {
                    return false;
                }
                slice_from("\u0643");
                break;
        }
        return true;
    }

    bool r_Prefix_Step3_Verb() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_8, null);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        switch (among_var) {
            case 1:
                if (current.length <= 4)
                {
                    return false;
                }
                slice_from("\u064A");
                break;
            case 2:
                if (current.length <= 4)
                {
                    return false;
                }
                slice_from("\u062A");
                break;
            case 3:
                if (current.length <= 4)
                {
                    return false;
                }
                slice_from("\u0646");
                break;
            case 4:
                if (current.length <= 4)
                {
                    return false;
                }
                slice_from("\u0623");
                break;
        }
        return true;
    }

    bool r_Prefix_Step4_Verb() {
        bra = cursor;
        if (find_among(a_9, null) == 0)
        {
            return false;
        }
        ket = cursor;
        if (current.length <= 4)
        {
            return false;
        }
        B_is_verb = true;
        B_is_noun = false;
        slice_from("\u0627\u0633\u062A");
        return true;
    }

    bool r_Suffix_Noun_Step1a() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_10, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (current.length < 4)
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (current.length < 5)
                {
                    return false;
                }
                slice_del();
                break;
            case 3:
                if (current.length < 6)
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_Suffix_Noun_Step1b() {
        ket = cursor;
        if (!(eq_s_b("\u0646")))
        {
            return false;
        }
        bra = cursor;
        if (current.length <= 5)
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_Suffix_Noun_Step2a() {
        ket = cursor;
        if (find_among_b(a_11, null) == 0)
        {
            return false;
        }
        bra = cursor;
        if (current.length <= 4)
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_Suffix_Noun_Step2b() {
        ket = cursor;
        if (!(eq_s_b("\u0627\u062A")))
        {
            return false;
        }
        bra = cursor;
        if (current.length < 5)
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_Suffix_Noun_Step2c1() {
        ket = cursor;
        if (!(eq_s_b("\u062A")))
        {
            return false;
        }
        bra = cursor;
        if (current.length < 4)
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_Suffix_Noun_Step2c2() {
        ket = cursor;
        if (!(eq_s_b("\u0629")))
        {
            return false;
        }
        bra = cursor;
        if (current.length < 4)
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_Suffix_Noun_Step3() {
        ket = cursor;
        if (!(eq_s_b("\u064A")))
        {
            return false;
        }
        bra = cursor;
        if (current.length < 3)
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_Suffix_Verb_Step1() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_12, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (current.length < 4)
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (current.length < 5)
                {
                    return false;
                }
                slice_del();
                break;
            case 3:
                if (current.length < 6)
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_Suffix_Verb_Step2a() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_13, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (current.length < 4)
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (current.length < 5)
                {
                    return false;
                }
                slice_del();
                break;
            case 3:
                if (current.length <= 5)
                {
                    return false;
                }
                slice_del();
                break;
            case 4:
                if (current.length < 6)
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_Suffix_Verb_Step2b() {
        ket = cursor;
        if (find_among_b(a_14, null) == 0)
        {
            return false;
        }
        bra = cursor;
        if (current.length < 5)
        {
            return false;
        }
        slice_del();
        return true;
    }

    bool r_Suffix_Verb_Step2c() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_15, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                if (current.length < 4)
                {
                    return false;
                }
                slice_del();
                break;
            case 2:
                if (current.length < 6)
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_Suffix_All_alef_maqsura() {
        ket = cursor;
        if (!(eq_s_b("\u0649")))
        {
            return false;
        }
        bra = cursor;
        slice_from("\u064A");
        return true;
    }

    @override
    bool stem() {
        B_is_noun = true;
        B_is_verb = true;
        B_is_defined = false;
        int v_1 = cursor;
        r_Checks1();
        cursor = v_1;
        r_Normalize_pre();
        limit_backward = cursor;
        cursor = limit;
        int v_2 = limit - cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_3 = limit - cursor;
                lab2: while (true) {
                    if (!B_is_verb)
                    {
                        break lab2;
                    }
                    lab3: while (true) {
                        int v_4 = limit - cursor;
                        lab4: while (true) {
                            {
                                int v_5 = 1;
                                replab5: while(true)
                                {
                                    int v_6 = limit - cursor;
                                    lab6: while (true) {
                                        if (!r_Suffix_Verb_Step1())
                                        {
                                            break lab6;
                                        }
                                        v_5--;
                                        continue replab5;
                                    }
                                    cursor = limit - v_6;
                                    break replab5;
                                }
                                if (v_5 > 0)
                                {
                                    break lab4;
                                }
                            }
                            lab7: while (true) {
                                int v_7 = limit - cursor;
                                lab8: while (true) {
                                    if (!r_Suffix_Verb_Step2a())
                                    {
                                        break lab8;
                                    }
                                    break lab7;
                                }
                                cursor = limit - v_7;
                                lab9: while (true) {
                                    if (!r_Suffix_Verb_Step2c())
                                    {
                                        break lab9;
                                    }
                                    break lab7;
                                }
                                cursor = limit - v_7;
                                if (cursor <= limit_backward)
                                {
                                    break lab4;
                                }
                                cursor--;
                                break lab7;
                            }
                            break lab3;
                        }
                        cursor = limit - v_4;
                        lab10: while (true) {
                            if (!r_Suffix_Verb_Step2b())
                            {
                                break lab10;
                            }
                            break lab3;
                        }
                        cursor = limit - v_4;
                        if (!r_Suffix_Verb_Step2a())
                        {
                            break lab2;
                        }
                        break lab3;
                    }
                    break lab1;
                }
                cursor = limit - v_3;
                lab11: while (true) {
                    if (!B_is_noun)
                    {
                        break lab11;
                    }
                    int v_8 = limit - cursor;
                    lab12: while (true) {
                        lab13: while (true) {
                            int v_9 = limit - cursor;
                            lab14: while (true) {
                                if (!r_Suffix_Noun_Step2c2())
                                {
                                    break lab14;
                                }
                                break lab13;
                            }
                            cursor = limit - v_9;
                            lab15: while (true) {
                                if (B_is_defined)
                                {
                                    break lab15;
                                }
                                if (!r_Suffix_Noun_Step1a())
                                {
                                    break lab15;
                                }
                                lab16: while (true) {
                                    int v_10 = limit - cursor;
                                    lab17: while (true) {
                                        if (!r_Suffix_Noun_Step2a())
                                        {
                                            break lab17;
                                        }
                                        break lab16;
                                    }
                                    cursor = limit - v_10;
                                    lab18: while (true) {
                                        if (!r_Suffix_Noun_Step2b())
                                        {
                                            break lab18;
                                        }
                                        break lab16;
                                    }
                                    cursor = limit - v_10;
                                    lab19: while (true) {
                                        if (!r_Suffix_Noun_Step2c1())
                                        {
                                            break lab19;
                                        }
                                        break lab16;
                                    }
                                    cursor = limit - v_10;
                                    if (cursor <= limit_backward)
                                    {
                                        break lab15;
                                    }
                                    cursor--;
                                    break lab16;
                                }
                                break lab13;
                            }
                            cursor = limit - v_9;
                            lab20: while (true) {
                                if (!r_Suffix_Noun_Step1b())
                                {
                                    break lab20;
                                }
                                lab21: while (true) {
                                    int v_11 = limit - cursor;
                                    lab22: while (true) {
                                        if (!r_Suffix_Noun_Step2a())
                                        {
                                            break lab22;
                                        }
                                        break lab21;
                                    }
                                    cursor = limit - v_11;
                                    lab23: while (true) {
                                        if (!r_Suffix_Noun_Step2b())
                                        {
                                            break lab23;
                                        }
                                        break lab21;
                                    }
                                    cursor = limit - v_11;
                                    if (!r_Suffix_Noun_Step2c1())
                                    {
                                        break lab20;
                                    }
                                    break lab21;
                                }
                                break lab13;
                            }
                            cursor = limit - v_9;
                            lab24: while (true) {
                                if (B_is_defined)
                                {
                                    break lab24;
                                }
                                if (!r_Suffix_Noun_Step2a())
                                {
                                    break lab24;
                                }
                                break lab13;
                            }
                            cursor = limit - v_9;
                            if (!r_Suffix_Noun_Step2b())
                            {
                                cursor = limit - v_8;
                                break lab12;
                            }
                            break lab13;
                        }
                        break lab12;
                    }
                    if (!r_Suffix_Noun_Step3())
                    {
                        break lab11;
                    }
                    break lab1;
                }
                cursor = limit - v_3;
                if (!r_Suffix_All_alef_maqsura())
                {
                    break lab0;
                }
                break lab1;
            }
            break lab0;
        }
        cursor = limit - v_2;
        cursor = limit_backward;
        int v_12 = cursor;
        lab25: while (true) {
            int v_13 = cursor;
            lab26: while (true) {
                if (!r_Prefix_Step1())
                {
                    cursor = v_13;
                    break lab26;
                }
                break lab26;
            }
            int v_14 = cursor;
            lab27: while (true) {
                if (!r_Prefix_Step2())
                {
                    cursor = v_14;
                    break lab27;
                }
                break lab27;
            }
            lab28: while (true) {
                int v_15 = cursor;
                lab29: while (true) {
                    if (!r_Prefix_Step3a_Noun())
                    {
                        break lab29;
                    }
                    break lab28;
                }
                cursor = v_15;
                lab30: while (true) {
                    if (!B_is_noun)
                    {
                        break lab30;
                    }
                    if (!r_Prefix_Step3b_Noun())
                    {
                        break lab30;
                    }
                    break lab28;
                }
                cursor = v_15;
                if (!B_is_verb)
                {
                    break lab25;
                }
                int v_16 = cursor;
                lab31: while (true) {
                    if (!r_Prefix_Step3_Verb())
                    {
                        cursor = v_16;
                        break lab31;
                    }
                    break lab31;
                }
                if (!r_Prefix_Step4_Verb())
                {
                    break lab25;
                }
                break lab28;
            }
            break lab25;
        }
        cursor = v_12;
        r_Normalize_post();
        return true;
    }

    @override
    bool operator ==(Object other) => other is arabic_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
