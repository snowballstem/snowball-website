// Generated from lithuanian.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from lithuanian.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class lithuanian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("a", -1, -1, 0),
        Among("ia", 0, -1, 0),
        Among("osna", 0, -1, 0),
        Among("iosna", 2, -1, 0),
        Among("uosna", 2, -1, 0),
        Among("iuosna", 4, -1, 0),
        Among("ysna", 0, -1, 0),
        Among("\u0117sna", 0, -1, 0),
        Among("e", -1, -1, 0),
        Among("ie", 8, -1, 0),
        Among("enie", 9, -1, 0),
        Among("oje", 8, -1, 0),
        Among("ioje", 11, -1, 0),
        Among("uje", 8, -1, 0),
        Among("iuje", 13, -1, 0),
        Among("yje", 8, -1, 0),
        Among("enyje", 15, -1, 0),
        Among("\u0117je", 8, -1, 0),
        Among("ame", 8, -1, 0),
        Among("iame", 18, -1, 0),
        Among("sime", 8, -1, 0),
        Among("ome", 8, -1, 0),
        Among("\u0117me", 8, -1, 0),
        Among("tum\u0117me", 22, -1, 0),
        Among("ose", 8, -1, 0),
        Among("iose", 24, -1, 0),
        Among("uose", 24, -1, 0),
        Among("iuose", 26, -1, 0),
        Among("yse", 8, -1, 0),
        Among("enyse", 28, -1, 0),
        Among("\u0117se", 8, -1, 0),
        Among("ate", 8, -1, 0),
        Among("iate", 31, -1, 0),
        Among("ite", 8, -1, 0),
        Among("kite", 33, -1, 0),
        Among("site", 33, -1, 0),
        Among("ote", 8, -1, 0),
        Among("tute", 8, -1, 0),
        Among("\u0117te", 8, -1, 0),
        Among("tum\u0117te", 38, -1, 0),
        Among("i", -1, -1, 0),
        Among("ai", 40, -1, 0),
        Among("iai", 41, -1, 0),
        Among("ei", 40, -1, 0),
        Among("tumei", 43, -1, 0),
        Among("ki", 40, -1, 0),
        Among("imi", 40, -1, 0),
        Among("umi", 40, -1, 0),
        Among("iumi", 47, -1, 0),
        Among("si", 40, -1, 0),
        Among("asi", 49, -1, 0),
        Among("iasi", 50, -1, 0),
        Among("esi", 49, -1, 0),
        Among("iesi", 52, -1, 0),
        Among("siesi", 53, -1, 0),
        Among("isi", 49, -1, 0),
        Among("aisi", 55, -1, 0),
        Among("eisi", 55, -1, 0),
        Among("tumeisi", 57, -1, 0),
        Among("uisi", 55, -1, 0),
        Among("osi", 49, -1, 0),
        Among("\u0117josi", 60, -1, 0),
        Among("uosi", 60, -1, 0),
        Among("iuosi", 62, -1, 0),
        Among("siuosi", 63, -1, 0),
        Among("usi", 49, -1, 0),
        Among("ausi", 65, -1, 0),
        Among("\u010Diausi", 66, -1, 0),
        Among("\u0105si", 49, -1, 0),
        Among("\u0117si", 49, -1, 0),
        Among("\u0173si", 49, -1, 0),
        Among("t\u0173si", 70, -1, 0),
        Among("ti", 40, -1, 0),
        Among("enti", 72, -1, 0),
        Among("inti", 72, -1, 0),
        Among("oti", 72, -1, 0),
        Among("ioti", 75, -1, 0),
        Among("uoti", 75, -1, 0),
        Among("iuoti", 77, -1, 0),
        Among("auti", 72, -1, 0),
        Among("iauti", 79, -1, 0),
        Among("yti", 72, -1, 0),
        Among("\u0117ti", 72, -1, 0),
        Among("tel\u0117ti", 82, -1, 0),
        Among("in\u0117ti", 82, -1, 0),
        Among("ter\u0117ti", 82, -1, 0),
        Among("ui", 40, -1, 0),
        Among("iui", 86, -1, 0),
        Among("eniui", 87, -1, 0),
        Among("oj", -1, -1, 0),
        Among("\u0117j", -1, -1, 0),
        Among("k", -1, -1, 0),
        Among("am", -1, -1, 0),
        Among("iam", 92, -1, 0),
        Among("iem", -1, -1, 0),
        Among("im", -1, -1, 0),
        Among("sim", 95, -1, 0),
        Among("om", -1, -1, 0),
        Among("tum", -1, -1, 0),
        Among("\u0117m", -1, -1, 0),
        Among("tum\u0117m", 99, -1, 0),
        Among("an", -1, -1, 0),
        Among("on", -1, -1, 0),
        Among("ion", 102, -1, 0),
        Among("un", -1, -1, 0),
        Among("iun", 104, -1, 0),
        Among("\u0117n", -1, -1, 0),
        Among("o", -1, -1, 0),
        Among("io", 107, -1, 0),
        Among("enio", 108, -1, 0),
        Among("\u0117jo", 107, -1, 0),
        Among("uo", 107, -1, 0),
        Among("s", -1, -1, 0),
        Among("as", 112, -1, 0),
        Among("ias", 113, -1, 0),
        Among("es", 112, -1, 0),
        Among("ies", 115, -1, 0),
        Among("is", 112, -1, 0),
        Among("ais", 117, -1, 0),
        Among("iais", 118, -1, 0),
        Among("tumeis", 117, -1, 0),
        Among("imis", 117, -1, 0),
        Among("enimis", 121, -1, 0),
        Among("omis", 117, -1, 0),
        Among("iomis", 123, -1, 0),
        Among("umis", 117, -1, 0),
        Among("\u0117mis", 117, -1, 0),
        Among("enis", 117, -1, 0),
        Among("asis", 117, -1, 0),
        Among("ysis", 117, -1, 0),
        Among("ams", 112, -1, 0),
        Among("iams", 130, -1, 0),
        Among("iems", 112, -1, 0),
        Among("ims", 112, -1, 0),
        Among("enims", 133, -1, 0),
        Among("oms", 112, -1, 0),
        Among("ioms", 135, -1, 0),
        Among("ums", 112, -1, 0),
        Among("\u0117ms", 112, -1, 0),
        Among("ens", 112, -1, 0),
        Among("os", 112, -1, 0),
        Among("ios", 140, -1, 0),
        Among("uos", 140, -1, 0),
        Among("iuos", 142, -1, 0),
        Among("us", 112, -1, 0),
        Among("aus", 144, -1, 0),
        Among("iaus", 145, -1, 0),
        Among("ius", 144, -1, 0),
        Among("ys", 112, -1, 0),
        Among("enys", 148, -1, 0),
        Among("\u0105s", 112, -1, 0),
        Among("i\u0105s", 150, -1, 0),
        Among("\u0117s", 112, -1, 0),
        Among("am\u0117s", 152, -1, 0),
        Among("iam\u0117s", 153, -1, 0),
        Among("im\u0117s", 152, -1, 0),
        Among("kim\u0117s", 155, -1, 0),
        Among("sim\u0117s", 155, -1, 0),
        Among("om\u0117s", 152, -1, 0),
        Among("\u0117m\u0117s", 152, -1, 0),
        Among("tum\u0117m\u0117s", 159, -1, 0),
        Among("at\u0117s", 152, -1, 0),
        Among("iat\u0117s", 161, -1, 0),
        Among("sit\u0117s", 152, -1, 0),
        Among("ot\u0117s", 152, -1, 0),
        Among("\u0117t\u0117s", 152, -1, 0),
        Among("tum\u0117t\u0117s", 165, -1, 0),
        Among("\u012Fs", 112, -1, 0),
        Among("\u016Bs", 112, -1, 0),
        Among("t\u0173s", 112, -1, 0),
        Among("at", -1, -1, 0),
        Among("iat", 170, -1, 0),
        Among("it", -1, -1, 0),
        Among("sit", 172, -1, 0),
        Among("ot", -1, -1, 0),
        Among("\u0117t", -1, -1, 0),
        Among("tum\u0117t", 175, -1, 0),
        Among("u", -1, -1, 0),
        Among("au", 177, -1, 0),
        Among("iau", 178, -1, 0),
        Among("\u010Diau", 179, -1, 0),
        Among("iu", 177, -1, 0),
        Among("eniu", 181, -1, 0),
        Among("siu", 181, -1, 0),
        Among("y", -1, -1, 0),
        Among("\u0105", -1, -1, 0),
        Among("i\u0105", 185, -1, 0),
        Among("\u0117", -1, -1, 0),
        Among("\u0119", -1, -1, 0),
        Among("\u012F", -1, -1, 0),
        Among("en\u012F", 189, -1, 0),
        Among("\u0173", -1, -1, 0),
        Among("i\u0173", 191, -1, 0)
    ];

    static final a_1 = [
        Among("ing", -1, -1, 0),
        Among("aj", -1, -1, 0),
        Among("iaj", 1, -1, 0),
        Among("iej", -1, -1, 0),
        Among("oj", -1, -1, 0),
        Among("ioj", 4, -1, 0),
        Among("uoj", 4, -1, 0),
        Among("iuoj", 6, -1, 0),
        Among("auj", -1, -1, 0),
        Among("\u0105j", -1, -1, 0),
        Among("i\u0105j", 9, -1, 0),
        Among("\u0117j", -1, -1, 0),
        Among("\u0173j", -1, -1, 0),
        Among("i\u0173j", 12, -1, 0),
        Among("ok", -1, -1, 0),
        Among("iok", 14, -1, 0),
        Among("iuk", -1, -1, 0),
        Among("uliuk", 16, -1, 0),
        Among("u\u010Diuk", 16, -1, 0),
        Among("i\u0161k", -1, -1, 0),
        Among("iul", -1, -1, 0),
        Among("yl", -1, -1, 0),
        Among("\u0117l", -1, -1, 0),
        Among("am", -1, -1, 0),
        Among("dam", 23, -1, 0),
        Among("jam", 23, -1, 0),
        Among("zgan", -1, -1, 0),
        Among("ain", -1, -1, 0),
        Among("esn", -1, -1, 0),
        Among("op", -1, -1, 0),
        Among("iop", 29, -1, 0),
        Among("ias", -1, -1, 0),
        Among("ies", -1, -1, 0),
        Among("ais", -1, -1, 0),
        Among("iais", 33, -1, 0),
        Among("os", -1, -1, 0),
        Among("ios", 35, -1, 0),
        Among("uos", 35, -1, 0),
        Among("iuos", 37, -1, 0),
        Among("aus", -1, -1, 0),
        Among("iaus", 39, -1, 0),
        Among("\u0105s", -1, -1, 0),
        Among("i\u0105s", 41, -1, 0),
        Among("\u0119s", -1, -1, 0),
        Among("ut\u0117ait", -1, -1, 0),
        Among("ant", -1, -1, 0),
        Among("iant", 45, -1, 0),
        Among("siant", 46, -1, 0),
        Among("int", -1, -1, 0),
        Among("ot", -1, -1, 0),
        Among("uot", 49, -1, 0),
        Among("iuot", 50, -1, 0),
        Among("yt", -1, -1, 0),
        Among("\u0117t", -1, -1, 0),
        Among("yk\u0161t", -1, -1, 0),
        Among("iau", -1, -1, 0),
        Among("dav", -1, -1, 0),
        Among("sv", -1, -1, 0),
        Among("\u0161v", -1, -1, 0),
        Among("yk\u0161\u010D", -1, -1, 0),
        Among("\u0119", -1, -1, 0),
        Among("\u0117j\u0119", 60, -1, 0)
    ];

    static final a_2 = [
        Among("ojime", -1, 7, 0),
        Among("\u0117jime", -1, 3, 0),
        Among("avime", -1, 6, 0),
        Among("okate", -1, 8, 0),
        Among("aite", -1, 1, 0),
        Among("uote", -1, 2, 0),
        Among("asius", -1, 5, 0),
        Among("okat\u0117s", -1, 8, 0),
        Among("ait\u0117s", -1, 1, 0),
        Among("uot\u0117s", -1, 2, 0),
        Among("esiu", -1, 4, 0)
    ];

    static final a_3 = [
        Among("\u010D", -1, 1, 0),
        Among("d\u017E", -1, 2, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 64, 1, 0, 64, 0, 0, 0, 0, 0, 0, 0, 4, 4]);

    int I_p1 = 0;


    bool r_step1() {
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (find_among_b(a_0, null) == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        slice_del();
        return true;
    }

    bool r_step2() {
        replab0: while(true)
        {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (cursor < I_p1)
                {
                    break lab1;
                }
                int v_2 = limit_backward;
                limit_backward = I_p1;
                ket = cursor;
                if (find_among_b(a_1, null) == 0)
                {
                    limit_backward = v_2;
                    break lab1;
                }
                bra = cursor;
                limit_backward = v_2;
                slice_del();
                continue replab0;
            }
            cursor = limit - v_1;
            break replab0;
        }
        return true;
    }

    bool r_fix_conflicts() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("ait\u0117");
                break;
            case 2:
                slice_from("uot\u0117");
                break;
            case 3:
                slice_from("\u0117jimas");
                break;
            case 4:
                slice_from("esys");
                break;
            case 5:
                slice_from("asys");
                break;
            case 6:
                slice_from("avimas");
                break;
            case 7:
                slice_from("ojimas");
                break;
            case 8:
                slice_from("okat\u0117");
                break;
        }
        return true;
    }

    bool r_fix_chdz() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_3, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("t");
                break;
            case 2:
                slice_from("d");
                break;
        }
        return true;
    }

    bool r_fix_gd() {
        ket = cursor;
        if (!(eq_s_b("gd")))
        {
            return false;
        }
        bra = cursor;
        slice_from("g");
        return true;
    }

    @override
    bool stem() {
        I_p1 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            int v_2 = cursor;
            lab1: while (true) {
                if (!(eq_s("a")))
                {
                    cursor = v_2;
                    break lab1;
                }
                if (current.length <= 6)
                {
                    cursor = v_2;
                    break lab1;
                }
                break lab1;
            }
            if (!go_out_grouping(g_v, 97, 371))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 371))
            {
                break lab0;
            }
            cursor++;
            I_p1 = cursor;
            break lab0;
        }
        cursor = v_1;
        limit_backward = cursor;
        cursor = limit;
        int v_3 = limit - cursor;
        r_fix_conflicts();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_step1();
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        r_fix_chdz();
        cursor = limit - v_5;
        int v_6 = limit - cursor;
        r_step2();
        cursor = limit - v_6;
        int v_7 = limit - cursor;
        r_fix_chdz();
        cursor = limit - v_7;
        int v_8 = limit - cursor;
        r_fix_gd();
        cursor = limit - v_8;
        ket = cursor;
        if (!(eq_s_b("'")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is lithuanian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
