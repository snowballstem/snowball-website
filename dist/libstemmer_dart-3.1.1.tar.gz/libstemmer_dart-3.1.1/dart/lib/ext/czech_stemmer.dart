// Generated from czech.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from czech.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class czech_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("c", -1, 1, 0),
        Among("nc", 0, -1, 0),
        Among("\u00EDnc", 1, 2, 0),
        Among("avc", 0, -1, 0),
        Among("ovc", 0, -1, 0)
    ];

    static final a_1 = [
        Among("c", -1, 1, 0),
        Among("nc", 0, -1, 0),
        Among("\u00EDnc", 1, 2, 0),
        Among("avc", 0, -1, 0),
        Among("ovc", 0, -1, 0),
        Among("\u010Dt", -1, 3, 0),
        Among("\u0161t", -1, 4, 0),
        Among("de\u0161t", 6, -1, 0),
        Among("le\u0161t", 6, -1, 0),
        Among("i\u0161t", 6, -1, 0),
        Among("pou\u0161t", 6, -1, 0),
        Among("\u00E1\u0161t", 6, -1, 0),
        Among("\u00ED\u0161t", 6, -1, 0)
    ];

    static final a_2 = [
        Among("in", -1, 2, 0),
        Among("ov", -1, 1, 0),
        Among("\u016Fv", -1, 1, 0)
    ];

    static final a_3 = [
        Among("", -1, 2, 0),
        Among("l", 0, 1, 0),
        Among("tl", 1, 2, 0),
        Among("s", 0, 1, 0),
        Among("es", 3, 2, 0),
        Among("\u010D", 0, 1, 0),
        Among("e\u010D", 5, 2, 0),
        Among("\u0159", 0, 1, 0),
        Among("\u017E", 0, 1, 0)
    ];

    static final a_4 = [
        Among("obl", -1, -1, 0),
        Among("sn", -1, -1, 0),
        Among("dot", -1, -1, 0)
    ];

    static final a_5 = [
        Among("uc", -1, -1, 0),
        Among("h", -1, -1, 0),
        Among("ok", -1, -1, 0),
        Among("kar", -1, -1, 0),
        Among("\u010D", -1, -1, 0)
    ];

    static final a_6 = [
        Among("a", -1, 1, 0),
        Among("ama", 0, 1, 0),
        Among("ata", 0, 1, 0),
        Among("eb", -1, 4, 0),
        Among("ec", -1, 5, 0),
        Among("e", -1, 2, 0),
        Among("ete", 5, 3, 0),
        Among("\u011Bte", 5, 1, 0),
        Among("ech", -1, 2, 0),
        Among("atech", 8, 1, 0),
        Among("\u00E1ch", -1, 1, 0),
        Among("\u00EDch", -1, 12, 0),
        Among("\u00FDch", -1, 1, 0),
        Among("i", -1, 12, 0),
        Among("mi", 13, 1, 0),
        Among("ami", 14, 1, 0),
        Among("emi", 14, 2, 0),
        Among("\u00EDmi", 14, 12, 0),
        Among("\u00FDmi", 14, 1, 0),
        Among("\u011Bmi", 14, 1, 0),
        Among("\u0165mi", 14, 11, 0),
        Among("eti", 13, 3, 0),
        Among("\u011Bti", 13, 1, 0),
        Among("ovi", 13, 1, 0),
        Among("ek", -1, 6, 0),
        Among("\u011Bk", -1, 7, 0),
        Among("em", -1, 2, 0),
        Among("etem", 26, 3, 0),
        Among("\u011Btem", 26, 1, 0),
        Among("\u00E1m", -1, 1, 0),
        Among("\u00E9m", -1, 1, 0),
        Among("\u00EDm", -1, 12, 0),
        Among("\u00FDm", -1, 1, 0),
        Among("\u011Bm", -1, 1, 0),
        Among("\u016Fm", -1, 1, 0),
        Among("at\u016Fm", 34, 1, 0),
        Among("o", -1, 1, 0),
        Among("\u00E9ho", 36, 1, 0),
        Among("\u00EDho", 36, 12, 0),
        Among("us", -1, 1, 0),
        Among("at", -1, 1, 0),
        Among("et", -1, 9, 0),
        Among("u", -1, 1, 0),
        Among("\u00E9mu", 42, 1, 0),
        Among("\u00EDmu", 42, 12, 0),
        Among("ou", 42, 1, 0),
        Among("ev", -1, 10, 0),
        Among("y", -1, 1, 0),
        Among("aty", 47, 1, 0),
        Among("\u00E1", -1, 1, 0),
        Among("\u00E9", -1, 1, 0),
        Among("ov\u00E9", 50, 1, 0),
        Among("\u00ED", -1, 12, 0),
        Among("\u00FD", -1, 1, 0),
        Among("\u011B", -1, 1, 0),
        Among("e\u0148", -1, 8, 0),
        Among("\u0165", -1, 11, 0),
        Among("\u016F", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 17, 4, 18, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64]);

    static final g_v_or_syllabic_c = String.fromCharCodes([17, 73, 18, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 17, 4, 18, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64]);

    static final g_ev_ending = String.fromCharCodes([73, 20, 4]);

    static final g_env_ending = String.fromCharCodes([71, 66, 23, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 0, 0, 0, 16]);

    int I_p1 = 0;


    bool r_mark_regions() {
        int I_x;
        int v_1 = cursor;
        {
            int c = cursor + 3;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        I_x = cursor;
        cursor = v_1;
        I_p1 = limit;
        int v_2 = cursor;
        lab0: while (true) {
            lab1: while (true) {
                lab2: while (true) {
                    if (!(in_grouping(g_v, 97, 367)))
                    {
                        break lab2;
                    }
                    break lab1;
                }
                if (cursor >= limit)
                {
                    break lab0;
                }
                cursor++;
                if (!go_out_grouping(g_v_or_syllabic_c, 97, 367))
                {
                    break lab0;
                }
                cursor++;
                break lab1;
            }
            if (!go_in_grouping(g_v, 97, 367))
            {
                break lab0;
            }
            cursor++;
            I_p1 = cursor;
            lab3: while (true) {
                if (I_p1 >= I_x)
                {
                    break lab3;
                }
                I_p1 = I_x;
                break lab3;
            }
            break lab0;
        }
        cursor = v_2;
        return true;
    }

    bool r_palatalise_e() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_0, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("k");
                break;
            case 2:
                slice_from("\u00EDnk");
                break;
        }
        return true;
    }

    bool r_palatalise_i() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_1, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_from("k");
                break;
            case 2:
                slice_from("\u00EDnk");
                break;
            case 3:
                slice_from("ck");
                break;
            case 4:
                slice_from("sk");
                break;
        }
        return true;
    }

    bool r_possessive_suffix() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2, null);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (I_p1 > cursor)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_del();
                int v_1 = limit - cursor;
                lab0: while (true) {
                    if (!r_palatalise_i())
                    {
                        cursor = limit - v_1;
                        break lab0;
                    }
                    break lab0;
                }
                break;
        }
        return true;
    }

    bool r_case_suffix() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_6, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                slice_del();
                int v_2 = limit - cursor;
                lab0: while (true) {
                    if (!r_palatalise_e())
                    {
                        cursor = limit - v_2;
                        break lab0;
                    }
                    break lab0;
                }
                break;
            case 3:
                among_var = find_among_b(a_3, null);
                switch (among_var) {
                    case 1:
                        slice_del();
                        break;
                    case 2:
                        slice_from("et");
                        break;
                }
                break;
            case 4:
                int v_3 = limit - cursor;
                if (!(out_grouping_b(g_v, 97, 367)))
                {
                    return false;
                }
                cursor = limit - v_3;
                lab1: while (true) {
                    if (!(eq_s_b("t\u0159")))
                    {
                        break lab1;
                    }
                    return false;
                }
                slice_from("b");
                break;
            case 5:
                int v_4 = limit - cursor;
                if (!(out_grouping_b(g_v, 97, 367)))
                {
                    return false;
                }
                cursor = limit - v_4;
                slice_del();
                insert(cursor, cursor, "c");
                int v_5 = limit - cursor;
                lab2: while (true) {
                    if (!r_palatalise_e())
                    {
                        cursor = limit - v_5;
                        break lab2;
                    }
                    break lab2;
                }
                break;
            case 6:
                int v_6 = limit - cursor;
                if (!(out_grouping_b(g_v, 97, 367)))
                {
                    return false;
                }
                cursor = limit - v_6;
                {
                    int v_7 = limit - cursor;
                    lab3: while (true) {
                        if (find_among_b(a_4, null) == 0)
                        {
                            break lab3;
                        }
                        return false;
                    }
                    cursor = limit - v_7;
                }
                slice_from("k");
                break;
            case 7:
                if (!(eq_s_b("n")))
                {
                    return false;
                }
                bra = cursor;
                slice_from("\u0148k");
                break;
            case 8:
                int v_8 = limit - cursor;
                if (!(in_grouping_b(g_env_ending, 98, 382)))
                {
                    return false;
                }
                cursor = limit - v_8;
                slice_from("n");
                break;
            case 9:
                if (find_among_b(a_5, null) == 0)
                {
                    return false;
                }
                slice_from("t");
                break;
            case 10:
                if (!(in_grouping_b(g_ev_ending, 104, 122)))
                {
                    return false;
                }
                slice_from("v");
                break;
            case 11:
                slice_from("t");
                break;
            case 12:
                slice_del();
                int v_9 = limit - cursor;
                lab4: while (true) {
                    if (!r_palatalise_i())
                    {
                        cursor = limit - v_9;
                        break lab4;
                    }
                    break lab4;
                }
                break;
        }
        return true;
    }

    @override
    bool stem() {
        if (!r_mark_regions())
        {
            return false;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        r_case_suffix();
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        r_possessive_suffix();
        cursor = limit - v_2;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is czech_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
