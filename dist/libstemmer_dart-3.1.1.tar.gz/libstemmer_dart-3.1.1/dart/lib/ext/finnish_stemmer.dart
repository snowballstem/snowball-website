// Generated from finnish.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from finnish.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class finnish_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("pa", -1, 1, 0),
        Among("sti", -1, 2, 0),
        Among("kaan", -1, 1, 0),
        Among("han", -1, 1, 0),
        Among("kin", -1, 1, 0),
        Among("h\u00E4n", -1, 1, 0),
        Among("k\u00E4\u00E4n", -1, 1, 0),
        Among("ko", -1, 1, 0),
        Among("p\u00E4", -1, 1, 0),
        Among("k\u00F6", -1, 1, 0)
    ];

    static final a_1 = [
        Among("lla", -1, -1, 0),
        Among("na", -1, -1, 0),
        Among("ssa", -1, -1, 0),
        Among("ta", -1, -1, 0),
        Among("lta", 3, -1, 0),
        Among("sta", 3, -1, 0)
    ];

    static final a_2 = [
        Among("ll\u00E4", -1, -1, 0),
        Among("n\u00E4", -1, -1, 0),
        Among("ss\u00E4", -1, -1, 0),
        Among("t\u00E4", -1, -1, 0),
        Among("lt\u00E4", 3, -1, 0),
        Among("st\u00E4", 3, -1, 0)
    ];

    static final a_3 = [
        Among("lle", -1, -1, 0),
        Among("ine", -1, -1, 0)
    ];

    static final a_4 = [
        Among("nsa", -1, 3, 0),
        Among("mme", -1, 3, 0),
        Among("nne", -1, 3, 0),
        Among("ni", -1, 2, 0),
        Among("si", -1, 1, 0),
        Among("an", -1, 4, 0),
        Among("en", -1, 6, 0),
        Among("\u00E4n", -1, 5, 0),
        Among("ns\u00E4", -1, 3, 0)
    ];

    static final a_5 = [
        Among("aa", -1, -1, 0),
        Among("ee", -1, -1, 0),
        Among("ii", -1, -1, 0),
        Among("oo", -1, -1, 0),
        Among("uu", -1, -1, 0),
        Among("\u00E4\u00E4", -1, -1, 0),
        Among("\u00F6\u00F6", -1, -1, 0)
    ];

    static final a_6 = [
        Among("'", -1, -1, 0),
        Among("ai", -1, -1, 0),
        Among("ei", -1, -1, 0),
        Among("ii", -1, -1, 0),
        Among("oi", -1, -1, 0),
        Among("ui", -1, -1, 0),
        Among("\u00E4i", -1, -1, 0),
        Among("\u00F6i", -1, -1, 0)
    ];

    static final a_7 = [
        Among("a", -1, 2, 0),
        Among("lla", 0, -1, 0),
        Among("na", 0, -1, 0),
        Among("ssa", 0, -1, 0),
        Among("ta", 0, -1, 0),
        Among("lta", 4, -1, 0),
        Among("sta", 4, -1, 0),
        Among("tta", 4, 3, 0),
        Among("lle", -1, -1, 0),
        Among("ine", -1, -1, 0),
        Among("ksi", -1, -1, 0),
        Among("n", -1, 1, 0),
        Among("han", 11, -1, 3),
        Among("den", 11, -1, 8),
        Among("seen", 11, -1, 9),
        Among("hen", 11, -1, 4),
        Among("tten", 11, -1, 8),
        Among("hin", 11, -1, 5),
        Among("siin", 11, -1, 8),
        Among("hon", 11, -1, 6),
        Among("hun", 11, -1, 7),
        Among("h\u00E4n", 11, -1, 1),
        Among("h\u00F6n", 11, -1, 2),
        Among("\u00E4", -1, 2, 0),
        Among("ll\u00E4", 23, -1, 0),
        Among("n\u00E4", 23, -1, 0),
        Among("ss\u00E4", 23, -1, 0),
        Among("t\u00E4", 23, -1, 0),
        Among("lt\u00E4", 27, -1, 0),
        Among("st\u00E4", 27, -1, 0),
        Among("tt\u00E4", 27, 3, 0)
    ];


    bool af_7() {
        switch (af) {
            case 1: return r_A_();
            case 2: return r_O_();
            case 3: return r_A();
            case 4: return r_E();
            case 5: return r_I();
            case 6: return r_O();
            case 7: return r_U();
            case 8: return r_VI();
            case 9: return r_LV();
        }
        return false;
    }
    static final a_8 = [
        Among("eja", -1, -1, 0),
        Among("mma", -1, 1, 0),
        Among("imma", 1, -1, 0),
        Among("mpa", -1, 1, 0),
        Among("impa", 3, -1, 0),
        Among("mmi", -1, 1, 0),
        Among("immi", 5, -1, 0),
        Among("mpi", -1, 1, 0),
        Among("impi", 7, -1, 0),
        Among("ej\u00E4", -1, -1, 0),
        Among("mm\u00E4", -1, 1, 0),
        Among("imm\u00E4", 10, -1, 0),
        Among("mp\u00E4", -1, 1, 0),
        Among("imp\u00E4", 12, -1, 0)
    ];

    static final a_9 = [
        Among("i", -1, -1, 0),
        Among("j", -1, -1, 0)
    ];

    static final a_10 = [
        Among("mma", -1, 1, 0),
        Among("imma", 0, -1, 0)
    ];

    static final g_AEI = String.fromCharCodes([17, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8]);

    static final g_C = String.fromCharCodes([119, 223, 119, 1]);

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32]);

    static final g_particle_end = String.fromCharCodes([17, 97, 24, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32]);

    bool B_ending_removed = false;
    int I_p2 = 0;
    int I_p1 = 0;


    bool r_mark_regions() {
        I_p1 = limit;
        I_p2 = limit;
        if (!go_out_grouping(g_v, 97, 246))
        {
            return false;
        }
        cursor++;
        if (!go_in_grouping(g_v, 97, 246))
        {
            return false;
        }
        cursor++;
        I_p1 = cursor;
        if (!go_out_grouping(g_v, 97, 246))
        {
            return false;
        }
        cursor++;
        if (!go_in_grouping(g_v, 97, 246))
        {
            return false;
        }
        cursor++;
        I_p2 = cursor;
        return true;
    }

    bool r_particle_etc() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_0, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                if (!(in_grouping_b(g_particle_end, 97, 246)))
                {
                    return false;
                }
                break;
            case 2:
                if (I_p2 > cursor)
                {
                    return false;
                }
                break;
        }
        slice_del();
        return true;
    }

    bool r_possessive() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_4, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    if (!(eq_s_b("k")))
                    {
                        break lab0;
                    }
                    return false;
                }
                slice_del();
                break;
            case 2:
                slice_del();
                ket = cursor;
                if (!(eq_s_b("kse")))
                {
                    return false;
                }
                bra = cursor;
                slice_from("ksi");
                break;
            case 3:
                slice_del();
                break;
            case 4:
                if (find_among_b(a_1, null) == 0)
                {
                    return false;
                }
                slice_del();
                break;
            case 5:
                if (find_among_b(a_2, null) == 0)
                {
                    return false;
                }
                slice_del();
                break;
            case 6:
                if (find_among_b(a_3, null) == 0)
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_LV() {
        return find_among_b(a_5, null) != 0;
    }

    bool r_VI() {
        return find_among_b(a_6, null) != 0;
    }

    bool r_A() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("a")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_E() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("e")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_I() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("i")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_O() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("o")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_U() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("u")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_A_() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("\u00E4")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_O_() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("\u00F6")))
                {
                    break lab1;
                }
                break lab0;
            }
            lab2: while (true) {
                if (!(eq_s_b("\u00F8")))
                {
                    break lab2;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_case_ending() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_7, af_7);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                int v_2 = limit - cursor;
                lab0: while (true) {
                    int v_3 = limit - cursor;
                    lab1: while (true) {
                        int v_4 = limit - cursor;
                        lab2: while (true) {
                            if (!r_LV())
                            {
                                break lab2;
                            }
                            break lab1;
                        }
                        cursor = limit - v_4;
                        if (!(eq_s_b("ie")))
                        {
                            cursor = limit - v_2;
                            break lab0;
                        }
                        break lab1;
                    }
                    cursor = limit - v_3;
                    if (cursor <= limit_backward)
                    {
                        cursor = limit - v_2;
                        break lab0;
                    }
                    cursor--;
                    bra = cursor;
                    break lab0;
                }
                break;
            case 2:
                if (!(in_grouping_b(g_v, 97, 246)))
                {
                    return false;
                }
                if (!(in_grouping_b(g_C, 98, 122)))
                {
                    return false;
                }
                break;
            case 3:
                if (!(eq_s_b("e")))
                {
                    return false;
                }
                break;
        }
        slice_del();
        B_ending_removed = true;
        return true;
    }

    bool r_other_endings() {
        int among_var;
        if (cursor < I_p2)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p2;
        ket = cursor;
        among_var = find_among_b(a_8, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    if (!(eq_s_b("po")))
                    {
                        break lab0;
                    }
                    return false;
                }
                break;
        }
        slice_del();
        return true;
    }

    bool r_i_plural() {
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (find_among_b(a_9, null) == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        slice_del();
        return true;
    }

    bool r_t_plural() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (!(eq_s_b("t")))
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        int v_2 = limit - cursor;
        if (!(in_grouping_b(g_v, 97, 246)))
        {
            limit_backward = v_1;
            return false;
        }
        cursor = limit - v_2;
        slice_del();
        limit_backward = v_1;
        if (cursor < I_p2)
        {
            return false;
        }
        int v_3 = limit_backward;
        limit_backward = I_p2;
        ket = cursor;
        among_var = find_among_b(a_10, null);
        if (among_var == 0)
        {
            limit_backward = v_3;
            return false;
        }
        bra = cursor;
        limit_backward = v_3;
        switch (among_var) {
            case 1:
                lab0: while (true) {
                    if (!(eq_s_b("po")))
                    {
                        break lab0;
                    }
                    return false;
                }
                break;
        }
        slice_del();
        return true;
    }

    bool r_tidy() {
        String S_x;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        int v_2 = limit - cursor;
        lab0: while (true) {
            int v_3 = limit - cursor;
            if (!r_LV())
            {
                break lab0;
            }
            cursor = limit - v_3;
            ket = cursor;
            if (cursor <= limit_backward)
            {
                break lab0;
            }
            cursor--;
            bra = cursor;
            slice_del();
            break lab0;
        }
        cursor = limit - v_2;
        int v_4 = limit - cursor;
        lab1: while (true) {
            ket = cursor;
            if (!(in_grouping_b(g_AEI, 97, 228)))
            {
                break lab1;
            }
            bra = cursor;
            if (!(in_grouping_b(g_C, 98, 122)))
            {
                break lab1;
            }
            slice_del();
            break lab1;
        }
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        lab2: while (true) {
            ket = cursor;
            if (!(eq_s_b("j")))
            {
                break lab2;
            }
            bra = cursor;
            lab3: while (true) {
                lab4: while (true) {
                    if (!(eq_s_b("o")))
                    {
                        break lab4;
                    }
                    break lab3;
                }
                if (!(eq_s_b("u")))
                {
                    break lab2;
                }
                break lab3;
            }
            slice_del();
            break lab2;
        }
        cursor = limit - v_5;
        int v_6 = limit - cursor;
        lab5: while (true) {
            ket = cursor;
            if (!(eq_s_b("o")))
            {
                break lab5;
            }
            bra = cursor;
            if (!(eq_s_b("j")))
            {
                break lab5;
            }
            slice_del();
            break lab5;
        }
        cursor = limit - v_6;
        limit_backward = v_1;
        int v_7 = limit - cursor;
        lab6: while (true) {
            if (!go_in_grouping_b(g_v, 97, 246))
            {
                break lab6;
            }
            ket = cursor;
            if (!(in_grouping_b(g_C, 98, 122)))
            {
                break lab6;
            }
            bra = cursor;
            S_x = slice_to();
            if (!(eq_s_b(S_x)))
            {
                break lab6;
            }
            slice_del();
            break lab6;
        }
        cursor = limit - v_7;
        ket = cursor;
        if (!(eq_s_b("'")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        r_mark_regions();
        cursor = v_1;
        B_ending_removed = false;
        limit_backward = cursor;
        cursor = limit;
        int v_2 = limit - cursor;
        r_particle_etc();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_possessive();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_case_ending();
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        r_other_endings();
        cursor = limit - v_5;
        lab0: while (true) {
            lab1: while (true) {
                if (!B_ending_removed)
                {
                    break lab1;
                }
                int v_6 = limit - cursor;
                r_i_plural();
                cursor = limit - v_6;
                break lab0;
            }
            int v_7 = limit - cursor;
            r_t_plural();
            cursor = limit - v_7;
            break lab0;
        }
        int v_8 = limit - cursor;
        r_tidy();
        cursor = limit - v_8;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is finnish_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
