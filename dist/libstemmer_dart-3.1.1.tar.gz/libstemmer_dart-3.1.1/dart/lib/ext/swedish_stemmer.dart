// Generated from swedish.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from swedish.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class swedish_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("fab", -1, -1, 0),
        Among("h", -1, -1, 0),
        Among("pak", -1, -1, 0),
        Among("rak", -1, -1, 0),
        Among("stak", -1, -1, 0),
        Among("kom", -1, -1, 0),
        Among("iet", -1, -1, 0),
        Among("cit", -1, -1, 0),
        Among("dit", -1, -1, 0),
        Among("alit", -1, -1, 0),
        Among("ilit", -1, -1, 0),
        Among("mit", -1, -1, 0),
        Among("nit", -1, -1, 0),
        Among("pit", -1, -1, 0),
        Among("rit", -1, -1, 0),
        Among("sit", -1, -1, 0),
        Among("tit", -1, -1, 0),
        Among("uit", -1, -1, 0),
        Among("ivit", -1, -1, 0),
        Among("kvit", -1, -1, 0),
        Among("xit", -1, -1, 0)
    ];

    static final a_1 = [
        Among("a", -1, 1, 0),
        Among("arna", 0, 1, 0),
        Among("erna", 0, 1, 0),
        Among("heterna", 2, 1, 0),
        Among("orna", 0, 1, 0),
        Among("ad", -1, 1, 0),
        Among("e", -1, 1, 0),
        Among("ade", 6, 1, 0),
        Among("ande", 6, 1, 0),
        Among("arne", 6, 1, 0),
        Among("are", 6, 1, 0),
        Among("aste", 6, 1, 0),
        Among("en", -1, 1, 0),
        Among("anden", 12, 1, 0),
        Among("aren", 12, 1, 0),
        Among("heten", 12, 1, 0),
        Among("ern", -1, 1, 0),
        Among("ar", -1, 1, 0),
        Among("er", -1, 1, 0),
        Among("heter", 18, 1, 0),
        Among("or", -1, 1, 0),
        Among("s", -1, 2, 0),
        Among("as", 21, 1, 0),
        Among("arnas", 22, 1, 0),
        Among("ernas", 22, 1, 0),
        Among("ornas", 22, 1, 0),
        Among("es", 21, 1, 0),
        Among("ades", 26, 1, 0),
        Among("andes", 26, 1, 0),
        Among("ens", 21, 1, 0),
        Among("arens", 29, 1, 0),
        Among("hetens", 29, 1, 0),
        Among("erns", 21, 1, 0),
        Among("at", -1, 1, 0),
        Among("et", -1, 3, 0),
        Among("andet", 34, 1, 0),
        Among("het", 34, 1, 0),
        Among("ast", -1, 1, 0)
    ];

    static final a_2 = [
        Among("dd", -1, -1, 0),
        Among("gd", -1, -1, 0),
        Among("nn", -1, -1, 0),
        Among("dt", -1, -1, 0),
        Among("gt", -1, -1, 0),
        Among("kt", -1, -1, 0),
        Among("tt", -1, -1, 0)
    ];

    static final a_3 = [
        Among("ig", -1, 1, 0),
        Among("lig", 0, 1, 0),
        Among("els", -1, 1, 0),
        Among("fullt", -1, 3, 0),
        Among("\u00F6st", -1, 2, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 32]);

    static final g_s_ending = String.fromCharCodes([119, 127, 149]);

    static final g_ost_ending = String.fromCharCodes([173, 58]);

    int I_p1 = 0;


    bool r_mark_regions() {
        int I_x;
        I_p1 = limit;
        int v_1 = cursor;
        {
            int c = cursor + 3;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        I_x = cursor;
        cursor = v_1;
        if (!go_out_grouping(g_v, 97, 246))
        {
            return false;
        }
        cursor++;
        if (!go_in_grouping(g_v, 97, 246))
        {
            return false;
        }
        cursor++;
        I_p1 = cursor;
        lab0: while (true) {
            if (I_p1 >= I_x)
            {
                break lab0;
            }
            I_p1 = I_x;
            break lab0;
        }
        return true;
    }

    bool r_et_condition() {
        int v_1 = limit - cursor;
        if (!(out_grouping_b(g_v, 97, 246)))
        {
            return false;
        }
        if (!(in_grouping_b(g_v, 97, 246)))
        {
            return false;
        }
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor = limit - v_1;
        {
            int v_2 = limit - cursor;
            lab0: while (true) {
                if (find_among_b(a_0, null) == 0)
                {
                    break lab0;
                }
                return false;
            }
            cursor = limit - v_2;
        }
        return true;
    }

    bool r_main_suffix() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_1, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                lab0: while (true) {
                    int v_2 = limit - cursor;
                    lab1: while (true) {
                        if (!(eq_s_b("et")))
                        {
                            break lab1;
                        }
                        if (!r_et_condition())
                        {
                            break lab1;
                        }
                        bra = cursor;
                        break lab0;
                    }
                    cursor = limit - v_2;
                    if (!(in_grouping_b(g_s_ending, 98, 121)))
                    {
                        return false;
                    }
                    break lab0;
                }
                slice_del();
                break;
            case 3:
                if (!r_et_condition())
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    bool r_consonant_pair() {
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        int v_2 = limit - cursor;
        if (find_among_b(a_2, null) == 0)
        {
            limit_backward = v_1;
            return false;
        }
        cursor = limit - v_2;
        ket = cursor;
        if (cursor <= limit_backward)
        {
            limit_backward = v_1;
            return false;
        }
        cursor--;
        bra = cursor;
        slice_del();
        limit_backward = v_1;
        return true;
    }

    bool r_other_suffix() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_3, null);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                if (!(in_grouping_b(g_ost_ending, 105, 118)))
                {
                    return false;
                }
                slice_from("\u00F6s");
                break;
            case 3:
                slice_from("full");
                break;
        }
        return true;
    }

    @override
    bool stem() {
        int v_1 = cursor;
        r_mark_regions();
        cursor = v_1;
        limit_backward = cursor;
        cursor = limit;
        int v_2 = limit - cursor;
        r_main_suffix();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_consonant_pair();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_other_suffix();
        cursor = limit - v_4;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is swedish_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
