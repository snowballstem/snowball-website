// Generated from sesotho.sbl by Snowball 3.1.1 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from sesotho.sbl by Snowball 3.1.1 - https://snowballstem.org/
 */
class sesotho_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("ba", -1, -1, 0),
        Among("boi", -1, -1, 0),
        Among("le", -1, -1, 0),
        Among("li", -1, -1, 0),
        Among("ma", -1, -1, 0),
        Among("me", -1, -1, 0),
        Among("mo", -1, -1, 0),
        Among("se", -1, -1, 0)
    ];

    static final a_1 = [
        Among("a", -1, 1, 0),
        Among("ela", 0, 1, 0),
        Among("isa", 0, 1, 0),
        Among("wa", 0, 1, 0),
        Among("ile", -1, 1, 0),
        Among("etse", -1, 1, 0),
        Among("ang", -1, 1, 0),
        Among("eng", -1, 1, 0),
        Among("ong", -1, 1, 0)
    ];

    static final a_2 = [
        Among("ana", -1, 1, 0),
        Among("nyana", 0, 1, 0),
        Among("oa", -1, 1, 0),
        Among("i", -1, 1, 0),
        Among("ano", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16]);

    int I_pV = 0;


    bool r_mark_regions() {
        int v_1 = cursor;
        if (!go_out_grouping(g_v, 97, 117))
        {
            return false;
        }
        cursor++;
        I_pV = cursor;
        cursor = v_1;
        int v_2 = cursor;
        {
            int c = cursor + 2;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        lab0: while (true) {
            if (cursor <= I_pV)
            {
                break lab0;
            }
            I_pV = cursor;
            break lab0;
        }
        cursor = v_2;
        return true;
    }

    bool r_remove_noun_prefixes() {
        bra = cursor;
        if (find_among(a_0, null) == 0)
        {
            return false;
        }
        ket = cursor;
        int v_1 = cursor;
        if (cursor >= limit)
        {
            return false;
        }
        cursor++;
        if (cursor >= limit)
        {
            return false;
        }
        cursor = v_1;
        if (!go_out_grouping(g_v, 97, 117))
        {
            return false;
        }
        cursor++;
        slice_del();
        return true;
    }

    bool r_remove_verb_suffixes() {
        if (cursor < I_pV)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_pV;
        ket = cursor;
        if (find_among_b(a_1, null) == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        slice_del();
        limit_backward = v_1;
        return true;
    }

    bool r_remove_nominal_suffixes() {
        if (cursor < I_pV)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_pV;
        ket = cursor;
        if (find_among_b(a_2, null) == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        slice_del();
        limit_backward = v_1;
        return true;
    }

    @override
    bool stem() {
        if (!r_mark_regions())
        {
            return false;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        r_remove_nominal_suffixes();
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        r_remove_verb_suffixes();
        cursor = limit - v_2;
        cursor = limit_backward;
        int v_3 = cursor;
        r_remove_noun_prefixes();
        cursor = v_3;
        return true;
    }

    @override
    bool operator ==(Object other) => other is sesotho_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
