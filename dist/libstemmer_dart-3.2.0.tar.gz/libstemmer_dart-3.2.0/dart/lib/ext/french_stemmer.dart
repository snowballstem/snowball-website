// Generated from french.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from french.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class french_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("col", -1, -1, 0),
        Among("ni", -1, 1, 0),
        Among("par", -1, -1, 0),
        Among("tap", -1, -1, 0)
    ];

    static final a_1 = [
        Among("", -1, 7, 0),
        Among("H", 0, 6, 0),
        Among("He", 1, 4, 0),
        Among("Hi", 1, 5, 0),
        Among("I", 0, 1, 0),
        Among("U", 0, 2, 0),
        Among("Y", 0, 3, 0)
    ];

    static final a_2 = [
        Among("iqU", -1, 3, 0),
        Among("abl", -1, 3, 0),
        Among("I\u00E8r", -1, 4, 0),
        Among("i\u00E8r", -1, 4, 0),
        Among("eus", -1, 2, 0),
        Among("iv", -1, 1, 0)
    ];

    static final a_3 = [
        Among("ic", -1, 2, 0),
        Among("abil", -1, 1, 0),
        Among("iv", -1, 3, 0)
    ];

    static final a_4 = [
        Among("iqUe", -1, 1, 0),
        Among("atrice", -1, 2, 0),
        Among("ance", -1, 1, 0),
        Among("ence", -1, 5, 0),
        Among("logie", -1, 3, 0),
        Among("able", -1, 1, 0),
        Among("isme", -1, 1, 0),
        Among("euse", -1, 12, 0),
        Among("iste", -1, 1, 0),
        Among("ive", -1, 8, 0),
        Among("if", -1, 8, 0),
        Among("usion", -1, 4, 0),
        Among("ation", -1, 2, 0),
        Among("ution", -1, 4, 0),
        Among("ateur", -1, 2, 0),
        Among("iqUes", -1, 1, 0),
        Among("atrices", -1, 2, 0),
        Among("ances", -1, 1, 0),
        Among("ences", -1, 5, 0),
        Among("logies", -1, 3, 0),
        Among("ables", -1, 1, 0),
        Among("ismes", -1, 1, 0),
        Among("euses", -1, 12, 0),
        Among("istes", -1, 1, 0),
        Among("ives", -1, 8, 0),
        Among("ifs", -1, 8, 0),
        Among("usions", -1, 4, 0),
        Among("ations", -1, 2, 0),
        Among("utions", -1, 4, 0),
        Among("ateurs", -1, 2, 0),
        Among("ments", -1, 16, 0),
        Among("ements", 30, 6, 0),
        Among("issements", 31, 13, 0),
        Among("it\u00E9s", -1, 7, 0),
        Among("ment", -1, 16, 0),
        Among("ement", 34, 6, 0),
        Among("issement", 35, 13, 0),
        Among("amment", 34, 14, 0),
        Among("emment", 34, 15, 0),
        Among("aux", -1, 10, 0),
        Among("eaux", 39, 9, 0),
        Among("eux", -1, 1, 0),
        Among("oux", -1, 11, 0),
        Among("it\u00E9", -1, 7, 0)
    ];

    static final a_5 = [
        Among("ira", -1, 1, 0),
        Among("ie", -1, 1, 0),
        Among("isse", -1, 1, 0),
        Among("issante", -1, 1, 0),
        Among("i", -1, 1, 0),
        Among("irai", 4, 1, 0),
        Among("ir", -1, 1, 0),
        Among("iras", -1, 1, 0),
        Among("ies", -1, 1, 0),
        Among("\u00EEmes", -1, 1, 0),
        Among("isses", -1, 1, 0),
        Among("issantes", -1, 1, 0),
        Among("\u00EEtes", -1, 1, 0),
        Among("is", -1, 1, 0),
        Among("irais", 13, 1, 0),
        Among("issais", 13, 1, 0),
        Among("irions", -1, 1, 0),
        Among("issions", -1, 1, 0),
        Among("irons", -1, 1, 0),
        Among("issons", -1, 1, 0),
        Among("issants", -1, 1, 0),
        Among("it", -1, 1, 0),
        Among("irait", 21, 1, 0),
        Among("issait", 21, 1, 0),
        Among("issant", -1, 1, 0),
        Among("iraIent", -1, 1, 0),
        Among("issaIent", -1, 1, 0),
        Among("irent", -1, 1, 0),
        Among("issent", -1, 1, 0),
        Among("iront", -1, 1, 0),
        Among("\u00EEt", -1, 1, 0),
        Among("iriez", -1, 1, 0),
        Among("issiez", -1, 1, 0),
        Among("irez", -1, 1, 0),
        Among("issez", -1, 1, 0)
    ];

    static final a_6 = [
        Among("al", -1, 1, 0),
        Among("\u00E9pl", -1, -1, 0),
        Among("auv", -1, -1, 0)
    ];

    static final a_7 = [
        Among("a", -1, 3, 0),
        Among("era", 0, 2, 0),
        Among("aise", -1, 4, 0),
        Among("asse", -1, 3, 0),
        Among("ante", -1, 3, 0),
        Among("\u00E9e", -1, 2, 0),
        Among("ai", -1, 3, 0),
        Among("erai", 6, 2, 0),
        Among("er", -1, 2, 0),
        Among("as", -1, 3, 0),
        Among("eras", 9, 2, 0),
        Among("\u00E2mes", -1, 3, 0),
        Among("aises", -1, 4, 0),
        Among("asses", -1, 3, 0),
        Among("antes", -1, 3, 0),
        Among("\u00E2tes", -1, 3, 0),
        Among("\u00E9es", -1, 2, 0),
        Among("ais", -1, 4, 0),
        Among("eais", 17, 2, 0),
        Among("erais", 17, 2, 0),
        Among("ions", -1, 1, 0),
        Among("erions", 20, 2, 0),
        Among("assions", 20, 3, 0),
        Among("erons", -1, 2, 0),
        Among("ants", -1, 3, 0),
        Among("\u00E9s", -1, 2, 0),
        Among("ait", -1, 3, 0),
        Among("erait", 26, 2, 0),
        Among("ant", -1, 3, 0),
        Among("aIent", -1, 3, 0),
        Among("eraIent", 29, 2, 0),
        Among("\u00E8rent", -1, 2, 0),
        Among("assent", -1, 3, 0),
        Among("eront", -1, 2, 0),
        Among("\u00E2t", -1, 3, 0),
        Among("ez", -1, 2, 0),
        Among("iez", 35, 2, 0),
        Among("eriez", 36, 2, 0),
        Among("assiez", 36, 3, 0),
        Among("erez", 35, 2, 0),
        Among("\u00E9", -1, 2, 0)
    ];

    static final a_8 = [
        Among("e", -1, 3, 0),
        Among("I\u00E8re", 0, 2, 0),
        Among("i\u00E8re", 0, 2, 0),
        Among("ion", -1, 1, 0),
        Among("Ier", -1, 2, 0),
        Among("ier", -1, 2, 0)
    ];

    static final a_9 = [
        Among("ell", -1, -1, 0),
        Among("eill", -1, -1, 0),
        Among("enn", -1, -1, 0),
        Among("onn", -1, -1, 0),
        Among("ett", -1, -1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 130, 103, 8, 5]);

    static final g_oux_ending = String.fromCharCodes([65, 85]);

    static final g_elision_char = String.fromCharCodes([131, 14, 131]);

    static final g_keep_with_s = String.fromCharCodes([1, 65, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128]);


    @override
    bool stem() {
        int among_var;
        int I_p2;
        int I_p1;
        int I_pV;
        int v_1 = cursor;
        lab0: while (true) {
            bra = cursor;
            lab1: while (true) {
                lab2: while (true) {
                    if (!(in_grouping(g_elision_char, 99, 122)))
                    {
                        break lab2;
                    }
                    break lab1;
                }
                if (!(eq_s("qu")))
                {
                    break lab0;
                }
                break lab1;
            }
            if (!(eq_s("'")))
            {
                break lab0;
            }
            ket = cursor;
            if (cursor >= limit)
            {
                break lab0;
            }
            slice_del();
            break lab0;
        }
        cursor = v_1;
        int v_2 = cursor;
        lab3: while (true) {
            replab4: while(true)
            {
                int v_3 = cursor;
                lab5: while (true) {
                    golab6: while(true)
                    {
                        int v_4 = cursor;
                        lab7: while (true) {
                            lab8: while (true) {
                                int v_5 = cursor;
                                lab9: while (true) {
                                    if (!(in_grouping(g_v, 97, 251)))
                                    {
                                        break lab9;
                                    }
                                    bra = cursor;
                                    lab10: while (true) {
                                        int v_6 = cursor;
                                        lab11: while (true) {
                                            if (!(eq_s("u")))
                                            {
                                                break lab11;
                                            }
                                            ket = cursor;
                                            if (!(in_grouping(g_v, 97, 251)))
                                            {
                                                break lab11;
                                            }
                                            slice_from("U");
                                            break lab10;
                                        }
                                        cursor = v_6;
                                        lab12: while (true) {
                                            if (!(eq_s("i")))
                                            {
                                                break lab12;
                                            }
                                            ket = cursor;
                                            if (!(in_grouping(g_v, 97, 251)))
                                            {
                                                break lab12;
                                            }
                                            slice_from("I");
                                            break lab10;
                                        }
                                        cursor = v_6;
                                        if (!(eq_s("y")))
                                        {
                                            break lab9;
                                        }
                                        ket = cursor;
                                        slice_from("Y");
                                        break lab10;
                                    }
                                    break lab8;
                                }
                                cursor = v_5;
                                lab13: while (true) {
                                    bra = cursor;
                                    if (!(eq_s("\u00EB")))
                                    {
                                        break lab13;
                                    }
                                    ket = cursor;
                                    slice_from("He");
                                    break lab8;
                                }
                                cursor = v_5;
                                lab14: while (true) {
                                    bra = cursor;
                                    if (!(eq_s("\u00EF")))
                                    {
                                        break lab14;
                                    }
                                    ket = cursor;
                                    slice_from("Hi");
                                    break lab8;
                                }
                                cursor = v_5;
                                lab15: while (true) {
                                    bra = cursor;
                                    if (!(eq_s("y")))
                                    {
                                        break lab15;
                                    }
                                    ket = cursor;
                                    if (!(in_grouping(g_v, 97, 251)))
                                    {
                                        break lab15;
                                    }
                                    slice_from("Y");
                                    break lab8;
                                }
                                cursor = v_5;
                                if (!(eq_s("q")))
                                {
                                    break lab7;
                                }
                                bra = cursor;
                                if (!(eq_s("u")))
                                {
                                    break lab7;
                                }
                                ket = cursor;
                                slice_from("U");
                                break lab8;
                            }
                            cursor = v_4;
                            break golab6;
                        }
                        cursor = v_4;
                        if (cursor >= limit)
                        {
                            break lab5;
                        }
                        cursor++;
                    }
                    continue replab4;
                }
                cursor = v_3;
                break replab4;
            }
            break lab3;
        }
        cursor = v_2;
        lab16: while (true) {
            I_pV = limit;
            I_p1 = limit;
            I_p2 = limit;
            int v_7 = cursor;
            lab17: while (true) {
                lab18: while (true) {
                    int v_8 = cursor;
                    lab19: while (true) {
                        if (!(in_grouping(g_v, 97, 251)))
                        {
                            break lab19;
                        }
                        if (!(in_grouping(g_v, 97, 251)))
                        {
                            break lab19;
                        }
                        if (cursor >= limit)
                        {
                            break lab19;
                        }
                        cursor++;
                        break lab18;
                    }
                    cursor = v_8;
                    lab20: while (true) {
                        among_var = find_among(a_0, null);
                        if (among_var == 0)
                        {
                            break lab20;
                        }
                        switch (among_var) {
                            case 1:
                                if (!(in_grouping(g_v, 97, 251)))
                                {
                                    break lab20;
                                }
                                break;
                        }
                        break lab18;
                    }
                    cursor = v_8;
                    if (cursor >= limit)
                    {
                        break lab17;
                    }
                    cursor++;
                    if (!go_out_grouping(g_v, 97, 251))
                    {
                        break lab17;
                    }
                    cursor++;
                    break lab18;
                }
                I_pV = cursor;
                break lab17;
            }
            cursor = v_7;
            int v_9 = cursor;
            lab21: while (true) {
                if (!go_out_grouping(g_v, 97, 251))
                {
                    break lab21;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 251))
                {
                    break lab21;
                }
                cursor++;
                I_p1 = cursor;
                if (!go_out_grouping(g_v, 97, 251))
                {
                    break lab21;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 251))
                {
                    break lab21;
                }
                cursor++;
                I_p2 = cursor;
                break lab21;
            }
            cursor = v_9;
            break lab16;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_10 = limit - cursor;
        lab22: while (true) {
            lab23: while (true) {
                int v_11 = limit - cursor;
                lab24: while (true) {
                    int v_12 = limit - cursor;
                    lab25: while (true) {
                        int v_13 = limit - cursor;
                        lab26: while (true) {
                            ket = cursor;
                            among_var = find_among_b(a_4, null);
                            if (among_var == 0)
                            {
                                break lab26;
                            }
                            bra = cursor;
                            switch (among_var) {
                                case 1:
                                    if (I_p2 > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_del();
                                    break;
                                case 2:
                                    if (I_p2 > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_del();
                                    int v_14 = limit - cursor;
                                    lab27: while (true) {
                                        ket = cursor;
                                        if (!(eq_s_b("ic")))
                                        {
                                            cursor = limit - v_14;
                                            break lab27;
                                        }
                                        bra = cursor;
                                        lab28: while (true) {
                                            int v_15 = limit - cursor;
                                            lab29: while (true) {
                                                if (I_p2 > cursor)
                                                {
                                                    break lab29;
                                                }
                                                slice_del();
                                                break lab28;
                                            }
                                            cursor = limit - v_15;
                                            slice_from("iqU");
                                            break lab28;
                                        }
                                        break lab27;
                                    }
                                    break;
                                case 3:
                                    if (I_p2 > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_from("log");
                                    break;
                                case 4:
                                    if (I_p2 > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_from("u");
                                    break;
                                case 5:
                                    if (I_p2 > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_from("ent");
                                    break;
                                case 6:
                                    if (I_pV > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_del();
                                    int v_16 = limit - cursor;
                                    lab30: while (true) {
                                        ket = cursor;
                                        among_var = find_among_b(a_2, null);
                                        if (among_var == 0)
                                        {
                                            cursor = limit - v_16;
                                            break lab30;
                                        }
                                        bra = cursor;
                                        switch (among_var) {
                                            case 1:
                                                if (I_p2 > cursor)
                                                {
                                                    cursor = limit - v_16;
                                                    break lab30;
                                                }
                                                slice_del();
                                                ket = cursor;
                                                if (!(eq_s_b("at")))
                                                {
                                                    cursor = limit - v_16;
                                                    break lab30;
                                                }
                                                bra = cursor;
                                                if (I_p2 > cursor)
                                                {
                                                    cursor = limit - v_16;
                                                    break lab30;
                                                }
                                                slice_del();
                                                break;
                                            case 2:
                                                lab31: while (true) {
                                                    int v_17 = limit - cursor;
                                                    lab32: while (true) {
                                                        if (I_p2 > cursor)
                                                        {
                                                            break lab32;
                                                        }
                                                        slice_del();
                                                        break lab31;
                                                    }
                                                    cursor = limit - v_17;
                                                    if (I_p1 > cursor)
                                                    {
                                                        cursor = limit - v_16;
                                                        break lab30;
                                                    }
                                                    slice_from("eux");
                                                    break lab31;
                                                }
                                                break;
                                            case 3:
                                                if (I_p2 > cursor)
                                                {
                                                    cursor = limit - v_16;
                                                    break lab30;
                                                }
                                                slice_del();
                                                break;
                                            case 4:
                                                if (I_pV > cursor)
                                                {
                                                    cursor = limit - v_16;
                                                    break lab30;
                                                }
                                                slice_from("i");
                                                break;
                                        }
                                        break lab30;
                                    }
                                    break;
                                case 7:
                                    if (I_p2 > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_del();
                                    int v_18 = limit - cursor;
                                    lab33: while (true) {
                                        ket = cursor;
                                        among_var = find_among_b(a_3, null);
                                        if (among_var == 0)
                                        {
                                            cursor = limit - v_18;
                                            break lab33;
                                        }
                                        bra = cursor;
                                        switch (among_var) {
                                            case 1:
                                                lab34: while (true) {
                                                    int v_19 = limit - cursor;
                                                    lab35: while (true) {
                                                        if (I_p2 > cursor)
                                                        {
                                                            break lab35;
                                                        }
                                                        slice_del();
                                                        break lab34;
                                                    }
                                                    cursor = limit - v_19;
                                                    slice_from("abl");
                                                    break lab34;
                                                }
                                                break;
                                            case 2:
                                                lab36: while (true) {
                                                    int v_20 = limit - cursor;
                                                    lab37: while (true) {
                                                        if (I_p2 > cursor)
                                                        {
                                                            break lab37;
                                                        }
                                                        slice_del();
                                                        break lab36;
                                                    }
                                                    cursor = limit - v_20;
                                                    slice_from("iqU");
                                                    break lab36;
                                                }
                                                break;
                                            case 3:
                                                if (I_p2 > cursor)
                                                {
                                                    cursor = limit - v_18;
                                                    break lab33;
                                                }
                                                slice_del();
                                                break;
                                        }
                                        break lab33;
                                    }
                                    break;
                                case 8:
                                    if (I_p2 > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_del();
                                    int v_21 = limit - cursor;
                                    lab38: while (true) {
                                        ket = cursor;
                                        if (!(eq_s_b("at")))
                                        {
                                            cursor = limit - v_21;
                                            break lab38;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_21;
                                            break lab38;
                                        }
                                        slice_del();
                                        ket = cursor;
                                        if (!(eq_s_b("ic")))
                                        {
                                            cursor = limit - v_21;
                                            break lab38;
                                        }
                                        bra = cursor;
                                        lab39: while (true) {
                                            int v_22 = limit - cursor;
                                            lab40: while (true) {
                                                if (I_p2 > cursor)
                                                {
                                                    break lab40;
                                                }
                                                slice_del();
                                                break lab39;
                                            }
                                            cursor = limit - v_22;
                                            slice_from("iqU");
                                            break lab39;
                                        }
                                        break lab38;
                                    }
                                    break;
                                case 9:
                                    slice_from("eau");
                                    break;
                                case 10:
                                    if (I_p1 > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_from("al");
                                    break;
                                case 11:
                                    if (!(in_grouping_b(g_oux_ending, 98, 112)))
                                    {
                                        break lab26;
                                    }
                                    slice_from("ou");
                                    break;
                                case 12:
                                    lab41: while (true) {
                                        int v_23 = limit - cursor;
                                        lab42: while (true) {
                                            if (I_p2 > cursor)
                                            {
                                                break lab42;
                                            }
                                            slice_del();
                                            break lab41;
                                        }
                                        cursor = limit - v_23;
                                        if (I_p1 > cursor)
                                        {
                                            break lab26;
                                        }
                                        slice_from("eux");
                                        break lab41;
                                    }
                                    break;
                                case 13:
                                    if (I_p1 > cursor)
                                    {
                                        break lab26;
                                    }
                                    if (!(out_grouping_b(g_v, 97, 251)))
                                    {
                                        break lab26;
                                    }
                                    slice_del();
                                    break;
                                case 14:
                                    if (I_pV > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_from("ant");
                                    break lab26;
                                case 15:
                                    if (I_pV > cursor)
                                    {
                                        break lab26;
                                    }
                                    slice_from("ent");
                                    break lab26;
                                case 16:
                                    int v_24 = limit - cursor;
                                    if (!(in_grouping_b(g_v, 97, 251)))
                                    {
                                        break lab26;
                                    }
                                    if (I_pV > cursor)
                                    {
                                        break lab26;
                                    }
                                    cursor = limit - v_24;
                                    slice_del();
                                    break lab26;
                            }
                            break lab25;
                        }
                        cursor = limit - v_13;
                        lab43: while (true) {
                            if (cursor < I_pV)
                            {
                                break lab43;
                            }
                            int v_25 = limit_backward;
                            limit_backward = I_pV;
                            ket = cursor;
                            if (find_among_b(a_5, null) == 0)
                            {
                                limit_backward = v_25;
                                break lab43;
                            }
                            bra = cursor;
                            lab44: while (true) {
                                if (!(eq_s_b("H")))
                                {
                                    break lab44;
                                }
                                limit_backward = v_25;
                                break lab43;
                            }
                            if (!(out_grouping_b(g_v, 97, 251)))
                            {
                                limit_backward = v_25;
                                break lab43;
                            }
                            slice_del();
                            limit_backward = v_25;
                            break lab25;
                        }
                        cursor = limit - v_13;
                        if (cursor < I_pV)
                        {
                            break lab24;
                        }
                        int v_26 = limit_backward;
                        limit_backward = I_pV;
                        ket = cursor;
                        among_var = find_among_b(a_7, null);
                        if (among_var == 0)
                        {
                            limit_backward = v_26;
                            break lab24;
                        }
                        bra = cursor;
                        limit_backward = v_26;
                        switch (among_var) {
                            case 1:
                                if (I_p2 > cursor)
                                {
                                    break lab24;
                                }
                                slice_del();
                                break;
                            case 2:
                                slice_del();
                                break;
                            case 3:
                                int v_27 = limit - cursor;
                                lab45: while (true) {
                                    if (!(eq_s_b("e")))
                                    {
                                        cursor = limit - v_27;
                                        break lab45;
                                    }
                                    if (I_pV > cursor)
                                    {
                                        cursor = limit - v_27;
                                        break lab45;
                                    }
                                    bra = cursor;
                                    break lab45;
                                }
                                slice_del();
                                break;
                            case 4:
                                {
                                    int v_28 = limit - cursor;
                                    lab46: while (true) {
                                        among_var = find_among_b(a_6, null);
                                        if (among_var == 0)
                                        {
                                            break lab46;
                                        }
                                        switch (among_var) {
                                            case 1:
                                                if (cursor <= limit_backward)
                                                {
                                                    break lab46;
                                                }
                                                cursor--;
                                                if (cursor > limit_backward)
                                                {
                                                    break lab46;
                                                }
                                                break;
                                        }
                                        break lab24;
                                    }
                                    cursor = limit - v_28;
                                }
                                slice_del();
                                break;
                        }
                        break lab25;
                    }
                    cursor = limit - v_12;
                    int v_29 = limit - cursor;
                    lab47: while (true) {
                        ket = cursor;
                        lab48: while (true) {
                            int v_30 = limit - cursor;
                            lab49: while (true) {
                                if (!(eq_s_b("Y")))
                                {
                                    break lab49;
                                }
                                bra = cursor;
                                slice_from("i");
                                break lab48;
                            }
                            cursor = limit - v_30;
                            if (!(eq_s_b("\u00E7")))
                            {
                                cursor = limit - v_29;
                                break lab47;
                            }
                            bra = cursor;
                            slice_from("c");
                            break lab48;
                        }
                        break lab47;
                    }
                    break lab23;
                }
                cursor = limit - v_11;
                int v_31 = limit - cursor;
                lab50: while (true) {
                    ket = cursor;
                    if (!(eq_s_b("s")))
                    {
                        cursor = limit - v_31;
                        break lab50;
                    }
                    bra = cursor;
                    int v_32 = limit - cursor;
                    lab51: while (true) {
                        lab52: while (true) {
                            if (!(eq_s_b("Hi")))
                            {
                                break lab52;
                            }
                            break lab51;
                        }
                        if (!(out_grouping_b(g_keep_with_s, 97, 232)))
                        {
                            cursor = limit - v_31;
                            break lab50;
                        }
                        break lab51;
                    }
                    cursor = limit - v_32;
                    slice_del();
                    break lab50;
                }
                if (cursor < I_pV)
                {
                    break lab22;
                }
                int v_33 = limit_backward;
                limit_backward = I_pV;
                ket = cursor;
                among_var = find_among_b(a_8, null);
                if (among_var == 0)
                {
                    limit_backward = v_33;
                    break lab22;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p2 > cursor)
                        {
                            limit_backward = v_33;
                            break lab22;
                        }
                        lab53: while (true) {
                            lab54: while (true) {
                                if (!(eq_s_b("s")))
                                {
                                    break lab54;
                                }
                                break lab53;
                            }
                            if (!(eq_s_b("t")))
                            {
                                limit_backward = v_33;
                                break lab22;
                            }
                            break lab53;
                        }
                        slice_del();
                        break;
                    case 2:
                        slice_from("i");
                        break;
                    case 3:
                        slice_del();
                        break;
                }
                limit_backward = v_33;
                break lab23;
            }
            break lab22;
        }
        cursor = limit - v_10;
        int v_34 = limit - cursor;
        lab55: while (true) {
            int v_35 = limit - cursor;
            if (find_among_b(a_9, null) == 0)
            {
                break lab55;
            }
            cursor = limit - v_35;
            ket = cursor;
            if (cursor <= limit_backward)
            {
                break lab55;
            }
            cursor--;
            bra = cursor;
            slice_del();
            break lab55;
        }
        cursor = limit - v_34;
        int v_36 = limit - cursor;
        lab56: while (true) {
            {
                int v_37 = 1;
                replab57: while(true)
                {
                    lab58: while (true) {
                        if (!(out_grouping_b(g_v, 97, 251)))
                        {
                            break lab58;
                        }
                        v_37--;
                        continue replab57;
                    }
                    break replab57;
                }
                if (v_37 > 0)
                {
                    break lab56;
                }
            }
            ket = cursor;
            lab59: while (true) {
                lab60: while (true) {
                    if (!(eq_s_b("\u00E9")))
                    {
                        break lab60;
                    }
                    break lab59;
                }
                if (!(eq_s_b("\u00E8")))
                {
                    break lab56;
                }
                break lab59;
            }
            bra = cursor;
            slice_from("e");
            break lab56;
        }
        cursor = limit - v_36;
        cursor = limit_backward;
        int v_38 = cursor;
        lab61: while (true) {
            replab62: while(true)
            {
                int v_39 = cursor;
                lab63: while (true) {
                    bra = cursor;
                    among_var = find_among(a_1, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("i");
                            break;
                        case 2:
                            slice_from("u");
                            break;
                        case 3:
                            slice_from("y");
                            break;
                        case 4:
                            slice_from("\u00EB");
                            break;
                        case 5:
                            slice_from("\u00EF");
                            break;
                        case 6:
                            slice_del();
                            break;
                        case 7:
                            if (cursor >= limit)
                            {
                                break lab63;
                            }
                            cursor++;
                            break;
                    }
                    continue replab62;
                }
                cursor = v_39;
                break replab62;
            }
            break lab61;
        }
        cursor = v_38;
        return true;
    }

    @override
    bool operator ==(Object other) => other is french_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
