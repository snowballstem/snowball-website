// Generated from german.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from german.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class german_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 5, 0),
        Among("ae", 0, 2, 0),
        Among("oe", 0, 3, 0),
        Among("qu", 0, -1, 0),
        Among("ue", 0, 4, 0),
        Among("\u00DF", 0, 1, 0)
    ];

    static final a_1 = [
        Among("", -1, 5, 0),
        Among("U", 0, 2, 0),
        Among("Y", 0, 1, 0),
        Among("\u00E4", 0, 3, 0),
        Among("\u00F6", 0, 4, 0),
        Among("\u00FC", 0, 2, 0)
    ];

    static final a_2 = [
        Among("e", -1, 3, 0),
        Among("em", -1, 1, 0),
        Among("en", -1, 3, 0),
        Among("erinnen", 2, 2, 0),
        Among("erin", -1, 2, 0),
        Among("ln", -1, 5, 0),
        Among("ern", -1, 2, 0),
        Among("er", -1, 2, 0),
        Among("s", -1, 4, 0),
        Among("es", 8, 3, 0),
        Among("lns", 8, 5, 0)
    ];

    static final a_3 = [
        Among("tick", -1, -1, 0),
        Among("plan", -1, -1, 0),
        Among("geordn", -1, -1, 0),
        Among("intern", -1, -1, 0),
        Among("tr", -1, -1, 0)
    ];

    static final a_4 = [
        Among("en", -1, 1, 0),
        Among("er", -1, 1, 0),
        Among("et", -1, 3, 0),
        Among("st", -1, 2, 0),
        Among("est", 3, 1, 0)
    ];

    static final a_5 = [
        Among("ig", -1, 1, 0),
        Among("lich", -1, 1, 0)
    ];

    static final a_6 = [
        Among("end", -1, 1, 0),
        Among("ig", -1, 2, 0),
        Among("ung", -1, 1, 0),
        Among("lich", -1, 3, 0),
        Among("isch", -1, 2, 0),
        Among("ik", -1, 2, 0),
        Among("heit", -1, 3, 0),
        Among("keit", -1, 4, 0)
    ];

    static final a_7 = [
        Among("'", -1, 1, 0),
        Among("'sch", -1, 1, 0),
        Among("'s", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32, 8]);

    static final g_et_ending = String.fromCharCodes([1, 128, 198, 227, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128]);

    static final g_s_ending = String.fromCharCodes([117, 30, 5]);

    static final g_st_ending = String.fromCharCodes([117, 30, 4]);


    @override
    bool stem() {
        int among_var;
        int I_x;
        int I_p2;
        int I_p1;
        int v_1 = cursor;
        lab0: while (true) {
            int v_2 = cursor;
            replab1: while(true)
            {
                int v_3 = cursor;
                lab2: while (true) {
                    golab3: while(true)
                    {
                        int v_4 = cursor;
                        lab4: while (true) {
                            if (!(in_grouping(g_v, 97, 252)))
                            {
                                break lab4;
                            }
                            bra = cursor;
                            lab5: while (true) {
                                int v_5 = cursor;
                                lab6: while (true) {
                                    if (!(eq_s("u")))
                                    {
                                        break lab6;
                                    }
                                    ket = cursor;
                                    if (!(in_grouping(g_v, 97, 252)))
                                    {
                                        break lab6;
                                    }
                                    slice_from("U");
                                    break lab5;
                                }
                                cursor = v_5;
                                if (!(eq_s("y")))
                                {
                                    break lab4;
                                }
                                ket = cursor;
                                if (!(in_grouping(g_v, 97, 252)))
                                {
                                    break lab4;
                                }
                                slice_from("Y");
                                break lab5;
                            }
                            cursor = v_4;
                            break golab3;
                        }
                        cursor = v_4;
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    continue replab1;
                }
                cursor = v_3;
                break replab1;
            }
            cursor = v_2;
            replab7: while(true)
            {
                int v_6 = cursor;
                lab8: while (true) {
                    bra = cursor;
                    among_var = find_among(a_0, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("ss");
                            break;
                        case 2:
                            slice_from("\u00E4");
                            break;
                        case 3:
                            slice_from("\u00F6");
                            break;
                        case 4:
                            slice_from("\u00FC");
                            break;
                        case 5:
                            if (cursor >= limit)
                            {
                                break lab8;
                            }
                            cursor++;
                            break;
                    }
                    continue replab7;
                }
                cursor = v_6;
                break replab7;
            }
            break lab0;
        }
        cursor = v_1;
        int v_7 = cursor;
        lab9: while (true) {
            I_p1 = limit;
            I_p2 = limit;
            int v_8 = cursor;
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab9;
                }
                cursor = c;
            }
            I_x = cursor;
            cursor = v_8;
            if (!go_out_grouping(g_v, 97, 252))
            {
                break lab9;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 252))
            {
                break lab9;
            }
            cursor++;
            I_p1 = cursor;
            lab10: while (true) {
                if (I_p1 >= I_x)
                {
                    break lab10;
                }
                I_p1 = I_x;
                break lab10;
            }
            if (!go_out_grouping(g_v, 97, 252))
            {
                break lab9;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 252))
            {
                break lab9;
            }
            cursor++;
            I_p2 = cursor;
            break lab9;
        }
        cursor = v_7;
        limit_backward = cursor;
        cursor = limit;
        lab11: while (true) {
            int v_9 = limit - cursor;
            lab12: while (true) {
                ket = cursor;
                among_var = find_among_b(a_2, null);
                if (among_var == 0)
                {
                    break lab12;
                }
                bra = cursor;
                if (I_p1 > cursor)
                {
                    break lab12;
                }
                switch (among_var) {
                    case 1:
                        lab13: while (true) {
                            if (!(eq_s_b("syst")))
                            {
                                break lab13;
                            }
                            break lab12;
                        }
                        slice_del();
                        break;
                    case 2:
                        slice_del();
                        break;
                    case 3:
                        slice_del();
                        int v_10 = limit - cursor;
                        lab14: while (true) {
                            ket = cursor;
                            if (!(eq_s_b("s")))
                            {
                                cursor = limit - v_10;
                                break lab14;
                            }
                            bra = cursor;
                            if (!(eq_s_b("nis")))
                            {
                                cursor = limit - v_10;
                                break lab14;
                            }
                            slice_del();
                            break lab14;
                        }
                        break;
                    case 4:
                        if (!(in_grouping_b(g_s_ending, 98, 116)))
                        {
                            break lab12;
                        }
                        slice_del();
                        break;
                    case 5:
                        slice_from("l");
                        break;
                }
                break lab12;
            }
            cursor = limit - v_9;
            int v_11 = limit - cursor;
            lab15: while (true) {
                ket = cursor;
                among_var = find_among_b(a_4, null);
                if (among_var == 0)
                {
                    break lab15;
                }
                bra = cursor;
                if (I_p1 > cursor)
                {
                    break lab15;
                }
                switch (among_var) {
                    case 1:
                        slice_del();
                        break;
                    case 2:
                        if (!(in_grouping_b(g_st_ending, 98, 116)))
                        {
                            break lab15;
                        }
                        {
                            int c = cursor - 3;
                            if (c < limit_backward)
                            {
                                break lab15;
                            }
                            cursor = c;
                        }
                        slice_del();
                        break;
                    case 3:
                        int v_12 = limit - cursor;
                        if (!(in_grouping_b(g_et_ending, 85, 228)))
                        {
                            break lab15;
                        }
                        cursor = limit - v_12;
                        {
                            int v_13 = limit - cursor;
                            lab16: while (true) {
                                if (find_among_b(a_3, null) == 0)
                                {
                                    break lab16;
                                }
                                break lab15;
                            }
                            cursor = limit - v_13;
                        }
                        slice_del();
                        break;
                }
                break lab15;
            }
            cursor = limit - v_11;
            int v_14 = limit - cursor;
            lab17: while (true) {
                ket = cursor;
                among_var = find_among_b(a_6, null);
                if (among_var == 0)
                {
                    break lab17;
                }
                bra = cursor;
                if (I_p2 > cursor)
                {
                    break lab17;
                }
                switch (among_var) {
                    case 1:
                        slice_del();
                        int v_15 = limit - cursor;
                        lab18: while (true) {
                            ket = cursor;
                            if (!(eq_s_b("ig")))
                            {
                                cursor = limit - v_15;
                                break lab18;
                            }
                            bra = cursor;
                            lab19: while (true) {
                                if (!(eq_s_b("e")))
                                {
                                    break lab19;
                                }
                                cursor = limit - v_15;
                                break lab18;
                            }
                            if (I_p2 > cursor)
                            {
                                cursor = limit - v_15;
                                break lab18;
                            }
                            slice_del();
                            break lab18;
                        }
                        break;
                    case 2:
                        lab20: while (true) {
                            if (!(eq_s_b("e")))
                            {
                                break lab20;
                            }
                            break lab17;
                        }
                        slice_del();
                        break;
                    case 3:
                        slice_del();
                        int v_16 = limit - cursor;
                        lab21: while (true) {
                            ket = cursor;
                            lab22: while (true) {
                                lab23: while (true) {
                                    if (!(eq_s_b("er")))
                                    {
                                        break lab23;
                                    }
                                    break lab22;
                                }
                                if (!(eq_s_b("en")))
                                {
                                    cursor = limit - v_16;
                                    break lab21;
                                }
                                break lab22;
                            }
                            bra = cursor;
                            if (I_p1 > cursor)
                            {
                                cursor = limit - v_16;
                                break lab21;
                            }
                            slice_del();
                            break lab21;
                        }
                        break;
                    case 4:
                        slice_del();
                        int v_17 = limit - cursor;
                        lab24: while (true) {
                            ket = cursor;
                            if (find_among_b(a_5, null) == 0)
                            {
                                cursor = limit - v_17;
                                break lab24;
                            }
                            bra = cursor;
                            if (I_p2 > cursor)
                            {
                                cursor = limit - v_17;
                                break lab24;
                            }
                            slice_del();
                            break lab24;
                        }
                        break;
                }
                break lab17;
            }
            cursor = limit - v_14;
            int v_18 = limit - cursor;
            lab25: while (true) {
                ket = cursor;
                if (find_among_b(a_7, null) == 0)
                {
                    break lab25;
                }
                bra = cursor;
                if (cursor <= limit_backward)
                {
                    break lab25;
                }
                cursor--;
                if (cursor <= limit_backward)
                {
                    break lab25;
                }
                slice_del();
                break lab25;
            }
            cursor = limit - v_18;
            break lab11;
        }
        cursor = limit_backward;
        int v_19 = cursor;
        lab26: while (true) {
            replab27: while(true)
            {
                int v_20 = cursor;
                lab28: while (true) {
                    bra = cursor;
                    among_var = find_among(a_1, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("y");
                            break;
                        case 2:
                            slice_from("u");
                            break;
                        case 3:
                            slice_from("a");
                            break;
                        case 4:
                            slice_from("o");
                            break;
                        case 5:
                            if (cursor >= limit)
                            {
                                break lab28;
                            }
                            cursor++;
                            break;
                    }
                    continue replab27;
                }
                cursor = v_20;
                break replab27;
            }
            break lab26;
        }
        cursor = v_19;
        return true;
    }

    @override
    bool operator ==(Object other) => other is german_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
