// Generated from english.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from english.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class english_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("arsen", -1, -1, 0),
        Among("commun", -1, -1, 0),
        Among("emerg", -1, -1, 0),
        Among("gener", -1, -1, 0),
        Among("inter", -1, -1, 0),
        Among("later", -1, -1, 0),
        Among("organ", -1, -1, 0),
        Among("past", -1, -1, 0),
        Among("univers", -1, -1, 0)
    ];

    static final a_1 = [
        Among("'", -1, 1, 0),
        Among("'s'", 0, 1, 0),
        Among("'s", -1, 1, 0)
    ];

    static final a_2 = [
        Among("ied", -1, 2, 0),
        Among("s", -1, 3, 0),
        Among("ies", 1, 2, 0),
        Among("sses", 1, 1, 0),
        Among("ss", 1, -1, 0),
        Among("us", 1, -1, 0)
    ];

    static final a_3 = [
        Among("succ", -1, 1, 0),
        Among("proc", -1, 1, 0),
        Among("exc", -1, 1, 0)
    ];

    static final a_4 = [
        Among("even", -1, 2, 0),
        Among("cann", -1, 2, 0),
        Among("inn", -1, 2, 0),
        Among("earr", -1, 2, 0),
        Among("herr", -1, 2, 0),
        Among("out", -1, 2, 0),
        Among("y", -1, 1, 0)
    ];

    static final a_5 = [
        Among("", -1, -1, 0),
        Among("ed", 0, 2, 0),
        Among("eed", 1, 1, 0),
        Among("ing", 0, 3, 0),
        Among("edly", 0, 2, 0),
        Among("eedly", 4, 1, 0),
        Among("ingly", 0, 2, 0)
    ];

    static final a_6 = [
        Among("", -1, 3, 0),
        Among("bb", 0, 2, 0),
        Among("dd", 0, 2, 0),
        Among("ff", 0, 2, 0),
        Among("gg", 0, 2, 0),
        Among("bl", 0, 1, 0),
        Among("mm", 0, 2, 0),
        Among("nn", 0, 2, 0),
        Among("pp", 0, 2, 0),
        Among("rr", 0, 2, 0),
        Among("at", 0, 1, 0),
        Among("tt", 0, 2, 0),
        Among("iz", 0, 1, 0)
    ];

    static final a_7 = [
        Among("anci", -1, 3, 0),
        Among("enci", -1, 2, 0),
        Among("ogi", -1, 14, 0),
        Among("li", -1, 16, 0),
        Among("bli", 3, 12, 0),
        Among("abli", 4, 4, 0),
        Among("alli", 3, 8, 0),
        Among("fulli", 3, 9, 0),
        Among("lessli", 3, 15, 0),
        Among("ousli", 3, 10, 0),
        Among("entli", 3, 5, 0),
        Among("aliti", -1, 8, 0),
        Among("biliti", -1, 12, 0),
        Among("iviti", -1, 11, 0),
        Among("tional", -1, 1, 0),
        Among("ational", 14, 7, 0),
        Among("alism", -1, 8, 0),
        Among("ation", -1, 7, 0),
        Among("ization", 17, 6, 0),
        Among("izer", -1, 6, 0),
        Among("ator", -1, 7, 0),
        Among("iveness", -1, 11, 0),
        Among("fulness", -1, 9, 0),
        Among("ousness", -1, 10, 0),
        Among("ogist", -1, 13, 0)
    ];

    static final a_8 = [
        Among("icate", -1, 4, 0),
        Among("ative", -1, 6, 0),
        Among("alize", -1, 3, 0),
        Among("iciti", -1, 4, 0),
        Among("ical", -1, 4, 0),
        Among("tional", -1, 1, 0),
        Among("ational", 5, 2, 0),
        Among("ful", -1, 5, 0),
        Among("ness", -1, 5, 0)
    ];

    static final a_9 = [
        Among("ic", -1, 1, 0),
        Among("ance", -1, 1, 0),
        Among("ence", -1, 1, 0),
        Among("able", -1, 1, 0),
        Among("ible", -1, 1, 0),
        Among("ate", -1, 1, 0),
        Among("ive", -1, 1, 0),
        Among("ize", -1, 1, 0),
        Among("iti", -1, 1, 0),
        Among("al", -1, 1, 0),
        Among("ism", -1, 1, 0),
        Among("ion", -1, 2, 0),
        Among("er", -1, 1, 0),
        Among("ous", -1, 1, 0),
        Among("ant", -1, 1, 0),
        Among("ent", -1, 1, 0),
        Among("ment", 15, 1, 0),
        Among("ement", 16, 1, 0)
    ];

    static final a_10 = [
        Among("e", -1, 1, 0),
        Among("l", -1, 2, 0)
    ];

    static final a_11 = [
        Among("andes", -1, -1, 0),
        Among("atlas", -1, -1, 0),
        Among("bias", -1, -1, 0),
        Among("cosmos", -1, -1, 0),
        Among("early", -1, 6, 0),
        Among("gently", -1, 4, 0),
        Among("howe", -1, -1, 0),
        Among("idly", -1, 3, 0),
        Among("news", -1, -1, 0),
        Among("only", -1, 7, 0),
        Among("singly", -1, 8, 0),
        Among("skies", -1, 2, 0),
        Among("skis", -1, 1, 0),
        Among("sky", -1, -1, 0),
        Among("ugly", -1, 5, 0)
    ];

    static final g_aeo = String.fromCharCodes([17, 64]);

    static final g_v = String.fromCharCodes([17, 65, 16, 1]);

    static final g_v_WXY = String.fromCharCodes([1, 17, 65, 208, 1]);

    static final g_valid_LI = String.fromCharCodes([55, 141, 2]);


    bool r_shortv() {
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (!(out_grouping_b(g_v_WXY, 89, 121)))
                {
                    break lab1;
                }
                if (!(in_grouping_b(g_v, 97, 121)))
                {
                    break lab1;
                }
                if (!(out_grouping_b(g_v, 97, 121)))
                {
                    break lab1;
                }
                break lab0;
            }
            cursor = limit - v_1;
            lab2: while (true) {
                if (!(out_grouping_b(g_v, 97, 121)))
                {
                    break lab2;
                }
                if (!(in_grouping_b(g_v, 97, 121)))
                {
                    break lab2;
                }
                if (cursor > limit_backward)
                {
                    break lab2;
                }
                break lab0;
            }
            cursor = limit - v_1;
            if (!(eq_s_b("past")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    @override
    bool stem() {
        int among_var;
        bool B_Y_found;
        int I_p2;
        int I_p1;
        lab0: while (true) {
            int v_1 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_11, null);
                if (among_var == 0)
                {
                    break lab1;
                }
                ket = cursor;
                if (cursor < limit)
                {
                    break lab1;
                }
                switch (among_var) {
                    case 1:
                        slice_from("ski");
                        break;
                    case 2:
                        slice_from("sky");
                        break;
                    case 3:
                        slice_from("idl");
                        break;
                    case 4:
                        slice_from("gentl");
                        break;
                    case 5:
                        slice_from("ugli");
                        break;
                    case 6:
                        slice_from("earli");
                        break;
                    case 7:
                        slice_from("onli");
                        break;
                    case 8:
                        slice_from("singl");
                        break;
                }
                break lab0;
            }
            cursor = v_1;
            lab2: while (true) {
                lab3: while (true) {
                    {
                        int c = cursor + 3;
                        if (c > limit)
                        {
                            break lab3;
                        }
                        cursor = c;
                    }
                    break lab2;
                }
                break lab0;
            }
            cursor = v_1;
            lab4: while (true) {
                B_Y_found = false;
                int v_2 = cursor;
                lab5: while (true) {
                    bra = cursor;
                    if (!(eq_s("'")))
                    {
                        break lab5;
                    }
                    ket = cursor;
                    slice_del();
                    break lab5;
                }
                cursor = v_2;
                int v_3 = cursor;
                lab6: while (true) {
                    bra = cursor;
                    if (!(eq_s("y")))
                    {
                        break lab6;
                    }
                    ket = cursor;
                    slice_from("Y");
                    B_Y_found = true;
                    break lab6;
                }
                cursor = v_3;
                int v_4 = cursor;
                lab7: while (true) {
                    replab8: while(true)
                    {
                        int v_5 = cursor;
                        lab9: while (true) {
                            golab10: while(true)
                            {
                                int v_6 = cursor;
                                lab11: while (true) {
                                    if (!(in_grouping(g_v, 97, 121)))
                                    {
                                        break lab11;
                                    }
                                    bra = cursor;
                                    if (!(eq_s("y")))
                                    {
                                        break lab11;
                                    }
                                    ket = cursor;
                                    cursor = v_6;
                                    break golab10;
                                }
                                cursor = v_6;
                                if (cursor >= limit)
                                {
                                    break lab9;
                                }
                                cursor++;
                            }
                            slice_from("Y");
                            B_Y_found = true;
                            continue replab8;
                        }
                        cursor = v_5;
                        break replab8;
                    }
                    break lab7;
                }
                cursor = v_4;
                break lab4;
            }
            lab12: while (true) {
                I_p1 = limit;
                I_p2 = limit;
                int v_7 = cursor;
                lab13: while (true) {
                    lab14: while (true) {
                        int v_8 = cursor;
                        lab15: while (true) {
                            if (find_among(a_0, null) == 0)
                            {
                                break lab15;
                            }
                            break lab14;
                        }
                        cursor = v_8;
                        if (!go_out_grouping(g_v, 97, 121))
                        {
                            break lab13;
                        }
                        cursor++;
                        if (!go_in_grouping(g_v, 97, 121))
                        {
                            break lab13;
                        }
                        cursor++;
                        break lab14;
                    }
                    I_p1 = cursor;
                    if (!go_out_grouping(g_v, 97, 121))
                    {
                        break lab13;
                    }
                    cursor++;
                    if (!go_in_grouping(g_v, 97, 121))
                    {
                        break lab13;
                    }
                    cursor++;
                    I_p2 = cursor;
                    break lab13;
                }
                cursor = v_7;
                break lab12;
            }
            limit_backward = cursor;
            cursor = limit;
            int v_9 = limit - cursor;
            lab16: while (true) {
                int v_10 = limit - cursor;
                lab17: while (true) {
                    ket = cursor;
                    if (find_among_b(a_1, null) == 0)
                    {
                        cursor = limit - v_10;
                        break lab17;
                    }
                    bra = cursor;
                    slice_del();
                    break lab17;
                }
                ket = cursor;
                among_var = find_among_b(a_2, null);
                if (among_var == 0)
                {
                    break lab16;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("ss");
                        break;
                    case 2:
                        lab18: while (true) {
                            int v_11 = limit - cursor;
                            lab19: while (true) {
                                {
                                    int c = cursor - 2;
                                    if (c < limit_backward)
                                    {
                                        break lab19;
                                    }
                                    cursor = c;
                                }
                                slice_from("i");
                                break lab18;
                            }
                            cursor = limit - v_11;
                            slice_from("ie");
                            break lab18;
                        }
                        break;
                    case 3:
                        if (cursor <= limit_backward)
                        {
                            break lab16;
                        }
                        cursor--;
                        if (!go_out_grouping_b(g_v, 97, 121))
                        {
                            break lab16;
                        }
                        cursor--;
                        slice_del();
                        break;
                }
                break lab16;
            }
            cursor = limit - v_9;
            int v_12 = limit - cursor;
            lab20: while (true) {
                ket = cursor;
                among_var = find_among_b(a_5, null);
                bra = cursor;
                lab21: while (true) {
                    int v_13 = limit - cursor;
                    lab22: while (true) {
                        switch (among_var) {
                            case 1:
                                int v_14 = limit - cursor;
                                lab23: while (true) {
                                    if (I_p1 > cursor)
                                    {
                                        break lab23;
                                    }
                                    lab24: while (true) {
                                        int v_15 = limit - cursor;
                                        lab25: while (true) {
                                            if (find_among_b(a_3, null) == 0)
                                            {
                                                break lab25;
                                            }
                                            if (cursor > limit_backward)
                                            {
                                                break lab25;
                                            }
                                            break lab24;
                                        }
                                        cursor = limit - v_15;
                                        slice_from("ee");
                                        break lab24;
                                    }
                                    break lab23;
                                }
                                cursor = limit - v_14;
                                break;
                            case 2:
                                break lab22;
                            case 3:
                                among_var = find_among_b(a_4, null);
                                if (among_var == 0)
                                {
                                    break lab22;
                                }
                                switch (among_var) {
                                    case 1:
                                        int v_16 = limit - cursor;
                                        if (!(out_grouping_b(g_v, 97, 121)))
                                        {
                                            break lab22;
                                        }
                                        if (cursor > limit_backward)
                                        {
                                            break lab22;
                                        }
                                        cursor = limit - v_16;
                                        bra = cursor;
                                        slice_from("ie");
                                        break;
                                    case 2:
                                        if (cursor > limit_backward)
                                        {
                                            break lab22;
                                        }
                                        break;
                                }
                                break;
                        }
                        break lab21;
                    }
                    cursor = limit - v_13;
                    int v_17 = limit - cursor;
                    if (!go_out_grouping_b(g_v, 97, 121))
                    {
                        break lab20;
                    }
                    cursor--;
                    cursor = limit - v_17;
                    slice_del();
                    ket = cursor;
                    bra = cursor;
                    int v_18 = limit - cursor;
                    among_var = find_among_b(a_6, null);
                    switch (among_var) {
                        case 1:
                            slice_from("e");
                            break lab20;
                        case 2:
                            {
                                int v_19 = limit - cursor;
                                lab26: while (true) {
                                    if (!(in_grouping_b(g_aeo, 97, 111)))
                                    {
                                        break lab26;
                                    }
                                    if (cursor > limit_backward)
                                    {
                                        break lab26;
                                    }
                                    break lab20;
                                }
                                cursor = limit - v_19;
                            }
                            break;
                        case 3:
                            if (cursor != I_p1)
                            {
                                break lab20;
                            }
                            int v_20 = limit - cursor;
                            if (!r_shortv())
                            {
                                break lab20;
                            }
                            cursor = limit - v_20;
                            slice_from("e");
                            break lab20;
                    }
                    cursor = limit - v_18;
                    ket = cursor;
                    if (cursor <= limit_backward)
                    {
                        break lab20;
                    }
                    cursor--;
                    bra = cursor;
                    slice_del();
                    break lab21;
                }
                break lab20;
            }
            cursor = limit - v_12;
            int v_21 = limit - cursor;
            lab27: while (true) {
                ket = cursor;
                lab28: while (true) {
                    lab29: while (true) {
                        if (!(eq_s_b("y")))
                        {
                            break lab29;
                        }
                        break lab28;
                    }
                    if (!(eq_s_b("Y")))
                    {
                        break lab27;
                    }
                    break lab28;
                }
                bra = cursor;
                if (!(out_grouping_b(g_v, 97, 121)))
                {
                    break lab27;
                }
                if (cursor <= limit_backward)
                {
                    break lab27;
                }
                slice_from("i");
                break lab27;
            }
            cursor = limit - v_21;
            int v_22 = limit - cursor;
            lab30: while (true) {
                ket = cursor;
                among_var = find_among_b(a_7, null);
                if (among_var == 0)
                {
                    break lab30;
                }
                bra = cursor;
                if (I_p1 > cursor)
                {
                    break lab30;
                }
                switch (among_var) {
                    case 1:
                        slice_from("tion");
                        break;
                    case 2:
                        slice_from("ence");
                        break;
                    case 3:
                        slice_from("ance");
                        break;
                    case 4:
                        slice_from("able");
                        break;
                    case 5:
                        slice_from("ent");
                        break;
                    case 6:
                        slice_from("ize");
                        break;
                    case 7:
                        slice_from("ate");
                        break;
                    case 8:
                        slice_from("al");
                        break;
                    case 9:
                        slice_from("ful");
                        break;
                    case 10:
                        slice_from("ous");
                        break;
                    case 11:
                        slice_from("ive");
                        break;
                    case 12:
                        slice_from("ble");
                        break;
                    case 13:
                        slice_from("og");
                        break;
                    case 14:
                        if (!(eq_s_b("l")))
                        {
                            break lab30;
                        }
                        slice_from("og");
                        break;
                    case 15:
                        slice_from("less");
                        break;
                    case 16:
                        if (!(in_grouping_b(g_valid_LI, 99, 116)))
                        {
                            break lab30;
                        }
                        slice_del();
                        break;
                }
                break lab30;
            }
            cursor = limit - v_22;
            int v_23 = limit - cursor;
            lab31: while (true) {
                ket = cursor;
                among_var = find_among_b(a_8, null);
                if (among_var == 0)
                {
                    break lab31;
                }
                bra = cursor;
                if (I_p1 > cursor)
                {
                    break lab31;
                }
                switch (among_var) {
                    case 1:
                        slice_from("tion");
                        break;
                    case 2:
                        slice_from("ate");
                        break;
                    case 3:
                        slice_from("al");
                        break;
                    case 4:
                        slice_from("ic");
                        break;
                    case 5:
                        slice_del();
                        break;
                    case 6:
                        if (I_p2 > cursor)
                        {
                            break lab31;
                        }
                        slice_del();
                        break;
                }
                break lab31;
            }
            cursor = limit - v_23;
            int v_24 = limit - cursor;
            lab32: while (true) {
                ket = cursor;
                among_var = find_among_b(a_9, null);
                if (among_var == 0)
                {
                    break lab32;
                }
                bra = cursor;
                if (I_p2 > cursor)
                {
                    break lab32;
                }
                switch (among_var) {
                    case 1:
                        slice_del();
                        break;
                    case 2:
                        lab33: while (true) {
                            lab34: while (true) {
                                if (!(eq_s_b("s")))
                                {
                                    break lab34;
                                }
                                break lab33;
                            }
                            if (!(eq_s_b("t")))
                            {
                                break lab32;
                            }
                            break lab33;
                        }
                        slice_del();
                        break;
                }
                break lab32;
            }
            cursor = limit - v_24;
            int v_25 = limit - cursor;
            lab35: while (true) {
                ket = cursor;
                among_var = find_among_b(a_10, null);
                if (among_var == 0)
                {
                    break lab35;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        lab36: while (true) {
                            lab37: while (true) {
                                if (I_p2 > cursor)
                                {
                                    break lab37;
                                }
                                break lab36;
                            }
                            if (I_p1 > cursor)
                            {
                                break lab35;
                            }
                            {
                                int v_26 = limit - cursor;
                                lab38: while (true) {
                                    if (!r_shortv())
                                    {
                                        break lab38;
                                    }
                                    break lab35;
                                }
                                cursor = limit - v_26;
                            }
                            break lab36;
                        }
                        slice_del();
                        break;
                    case 2:
                        if (I_p2 > cursor)
                        {
                            break lab35;
                        }
                        if (!(eq_s_b("l")))
                        {
                            break lab35;
                        }
                        slice_del();
                        break;
                }
                break lab35;
            }
            cursor = limit - v_25;
            cursor = limit_backward;
            int v_27 = cursor;
            lab39: while (true) {
                if (!B_Y_found)
                {
                    break lab39;
                }
                replab40: while(true)
                {
                    int v_28 = cursor;
                    lab41: while (true) {
                        golab42: while(true)
                        {
                            int v_29 = cursor;
                            lab43: while (true) {
                                bra = cursor;
                                if (!(eq_s("Y")))
                                {
                                    break lab43;
                                }
                                ket = cursor;
                                cursor = v_29;
                                break golab42;
                            }
                            cursor = v_29;
                            if (cursor >= limit)
                            {
                                break lab41;
                            }
                            cursor++;
                        }
                        slice_from("y");
                        continue replab40;
                    }
                    cursor = v_28;
                    break replab40;
                }
                break lab39;
            }
            cursor = v_27;
            break lab0;
        }
        return true;
    }

    @override
    bool operator ==(Object other) => other is english_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
