// Generated from russian.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from russian.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class russian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("\u0432", -1, 1, 0),
        Among("\u0438\u0432", 0, 2, 0),
        Among("\u044B\u0432", 0, 2, 0),
        Among("\u0432\u0448\u0438", -1, 1, 0),
        Among("\u0438\u0432\u0448\u0438", 3, 2, 0),
        Among("\u044B\u0432\u0448\u0438", 3, 2, 0),
        Among("\u0432\u0448\u0438\u0441\u044C", -1, 1, 0),
        Among("\u0438\u0432\u0448\u0438\u0441\u044C", 6, 2, 0),
        Among("\u044B\u0432\u0448\u0438\u0441\u044C", 6, 2, 0)
    ];

    static final a_1 = [
        Among("\u0435\u0435", -1, 1, 0),
        Among("\u0438\u0435", -1, 1, 0),
        Among("\u043E\u0435", -1, 1, 0),
        Among("\u044B\u0435", -1, 1, 0),
        Among("\u0438\u043C\u0438", -1, 1, 0),
        Among("\u044B\u043C\u0438", -1, 1, 0),
        Among("\u0435\u0439", -1, 1, 0),
        Among("\u0438\u0439", -1, 1, 0),
        Among("\u043E\u0439", -1, 1, 0),
        Among("\u044B\u0439", -1, 1, 0),
        Among("\u0435\u043C", -1, 1, 0),
        Among("\u0438\u043C", -1, 1, 0),
        Among("\u043E\u043C", -1, 1, 0),
        Among("\u044B\u043C", -1, 1, 0),
        Among("\u0435\u0433\u043E", -1, 1, 0),
        Among("\u043E\u0433\u043E", -1, 1, 0),
        Among("\u0435\u043C\u0443", -1, 1, 0),
        Among("\u043E\u043C\u0443", -1, 1, 0),
        Among("\u0438\u0445", -1, 1, 0),
        Among("\u044B\u0445", -1, 1, 0),
        Among("\u0435\u044E", -1, 1, 0),
        Among("\u043E\u044E", -1, 1, 0),
        Among("\u0443\u044E", -1, 1, 0),
        Among("\u044E\u044E", -1, 1, 0),
        Among("\u0430\u044F", -1, 1, 0),
        Among("\u044F\u044F", -1, 1, 0)
    ];

    static final a_2 = [
        Among("\u0435\u043C", -1, 1, 0),
        Among("\u043D\u043D", -1, 1, 0),
        Among("\u0432\u0448", -1, 1, 0),
        Among("\u0438\u0432\u0448", 2, 2, 0),
        Among("\u044B\u0432\u0448", 2, 2, 0),
        Among("\u0449", -1, 1, 0),
        Among("\u044E\u0449", 5, 1, 0),
        Among("\u0443\u044E\u0449", 6, 2, 0)
    ];

    static final a_3 = [
        Among("\u0441\u044C", -1, 1, 0),
        Among("\u0441\u044F", -1, 1, 0)
    ];

    static final a_4 = [
        Among("\u043B\u0430", -1, 1, 0),
        Among("\u0438\u043B\u0430", 0, 2, 0),
        Among("\u044B\u043B\u0430", 0, 2, 0),
        Among("\u043D\u0430", -1, 1, 0),
        Among("\u0435\u043D\u0430", 3, 2, 0),
        Among("\u0435\u0442\u0435", -1, 1, 0),
        Among("\u0438\u0442\u0435", -1, 2, 0),
        Among("\u0439\u0442\u0435", -1, 1, 0),
        Among("\u0435\u0439\u0442\u0435", 7, 2, 0),
        Among("\u0443\u0439\u0442\u0435", 7, 2, 0),
        Among("\u043B\u0438", -1, 1, 0),
        Among("\u0438\u043B\u0438", 10, 2, 0),
        Among("\u044B\u043B\u0438", 10, 2, 0),
        Among("\u0439", -1, 1, 0),
        Among("\u0435\u0439", 13, 2, 0),
        Among("\u0443\u0439", 13, 2, 0),
        Among("\u043B", -1, 1, 0),
        Among("\u0438\u043B", 16, 2, 0),
        Among("\u044B\u043B", 16, 2, 0),
        Among("\u0435\u043C", -1, 1, 0),
        Among("\u0438\u043C", -1, 2, 0),
        Among("\u044B\u043C", -1, 2, 0),
        Among("\u043D", -1, 1, 0),
        Among("\u0435\u043D", 22, 2, 0),
        Among("\u043B\u043E", -1, 1, 0),
        Among("\u0438\u043B\u043E", 24, 2, 0),
        Among("\u044B\u043B\u043E", 24, 2, 0),
        Among("\u043D\u043E", -1, 1, 0),
        Among("\u0435\u043D\u043E", 27, 2, 0),
        Among("\u043D\u043D\u043E", 27, 1, 0),
        Among("\u0435\u0442", -1, 1, 0),
        Among("\u0443\u0435\u0442", 30, 2, 0),
        Among("\u0438\u0442", -1, 2, 0),
        Among("\u044B\u0442", -1, 2, 0),
        Among("\u044E\u0442", -1, 1, 0),
        Among("\u0443\u044E\u0442", 34, 2, 0),
        Among("\u044F\u0442", -1, 2, 0),
        Among("\u043D\u044B", -1, 1, 0),
        Among("\u0435\u043D\u044B", 37, 2, 0),
        Among("\u0442\u044C", -1, 1, 0),
        Among("\u0438\u0442\u044C", 39, 2, 0),
        Among("\u044B\u0442\u044C", 39, 2, 0),
        Among("\u0435\u0448\u044C", -1, 1, 0),
        Among("\u0438\u0448\u044C", -1, 2, 0),
        Among("\u044E", -1, 2, 0),
        Among("\u0443\u044E", 44, 2, 0)
    ];

    static final a_5 = [
        Among("\u0430", -1, 1, 0),
        Among("\u0435\u0432", -1, 1, 0),
        Among("\u043E\u0432", -1, 1, 0),
        Among("\u0435", -1, 1, 0),
        Among("\u0438\u0435", 3, 1, 0),
        Among("\u044C\u0435", 3, 1, 0),
        Among("\u0438", -1, 1, 0),
        Among("\u0435\u0438", 6, 1, 0),
        Among("\u0438\u0438", 6, 1, 0),
        Among("\u0430\u043C\u0438", 6, 1, 0),
        Among("\u044F\u043C\u0438", 6, 1, 0),
        Among("\u0438\u044F\u043C\u0438", 10, 1, 0),
        Among("\u0439", -1, 1, 0),
        Among("\u0435\u0439", 12, 1, 0),
        Among("\u0438\u0435\u0439", 13, 1, 0),
        Among("\u0438\u0439", 12, 1, 0),
        Among("\u043E\u0439", 12, 1, 0),
        Among("\u0430\u043C", -1, 1, 0),
        Among("\u0435\u043C", -1, 1, 0),
        Among("\u0438\u0435\u043C", 18, 1, 0),
        Among("\u043E\u043C", -1, 1, 0),
        Among("\u044F\u043C", -1, 1, 0),
        Among("\u0438\u044F\u043C", 21, 1, 0),
        Among("\u043E", -1, 1, 0),
        Among("\u0443", -1, 1, 0),
        Among("\u0430\u0445", -1, 1, 0),
        Among("\u044F\u0445", -1, 1, 0),
        Among("\u0438\u044F\u0445", 26, 1, 0),
        Among("\u044B", -1, 1, 0),
        Among("\u044C", -1, 1, 0),
        Among("\u044E", -1, 1, 0),
        Among("\u0438\u044E", 30, 1, 0),
        Among("\u044C\u044E", 30, 1, 0),
        Among("\u044F", -1, 1, 0),
        Among("\u0438\u044F", 33, 1, 0),
        Among("\u044C\u044F", 33, 1, 0)
    ];

    static final a_6 = [
        Among("\u043E\u0441\u0442", -1, 1, 0),
        Among("\u043E\u0441\u0442\u044C", -1, 1, 0)
    ];

    static final a_7 = [
        Among("\u0435\u0439\u0448\u0435", -1, 1, 0),
        Among("\u043D", -1, 2, 0),
        Among("\u0435\u0439\u0448", -1, 1, 0),
        Among("\u044C", -1, 3, 0)
    ];

    static final g_v = String.fromCharCodes([33, 65, 8, 232]);


    @override
    bool stem() {
        int among_var;
        int I_p2;
        int I_pV;
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = cursor;
                lab2: while (true) {
                    golab3: while(true)
                    {
                        int v_3 = cursor;
                        lab4: while (true) {
                            bra = cursor;
                            if (!(eq_s("\u0451")))
                            {
                                break lab4;
                            }
                            ket = cursor;
                            cursor = v_3;
                            break golab3;
                        }
                        cursor = v_3;
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    slice_from("\u0435");
                    continue replab1;
                }
                cursor = v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = v_1;
        lab5: while (true) {
            I_pV = limit;
            I_p2 = limit;
            int v_4 = cursor;
            lab6: while (true) {
                if (!go_out_grouping(g_v, 1072, 1103))
                {
                    break lab6;
                }
                cursor++;
                I_pV = cursor;
                if (!go_in_grouping(g_v, 1072, 1103))
                {
                    break lab6;
                }
                cursor++;
                if (!go_out_grouping(g_v, 1072, 1103))
                {
                    break lab6;
                }
                cursor++;
                if (!go_in_grouping(g_v, 1072, 1103))
                {
                    break lab6;
                }
                cursor++;
                I_p2 = cursor;
                break lab6;
            }
            cursor = v_4;
            break lab5;
        }
        limit_backward = cursor;
        cursor = limit;
        if (cursor < I_pV)
        {
            return false;
        }
        int v_5 = limit_backward;
        limit_backward = I_pV;
        int v_6 = limit - cursor;
        lab7: while (true) {
            lab8: while (true) {
                int v_7 = limit - cursor;
                lab9: while (true) {
                    ket = cursor;
                    among_var = find_among_b(a_0, null);
                    if (among_var == 0)
                    {
                        break lab9;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            lab10: while (true) {
                                lab11: while (true) {
                                    if (!(eq_s_b("\u0430")))
                                    {
                                        break lab11;
                                    }
                                    break lab10;
                                }
                                if (!(eq_s_b("\u044F")))
                                {
                                    break lab9;
                                }
                                break lab10;
                            }
                            slice_del();
                            break;
                        case 2:
                            slice_del();
                            break;
                    }
                    break lab8;
                }
                cursor = limit - v_7;
                int v_8 = limit - cursor;
                lab12: while (true) {
                    ket = cursor;
                    if (find_among_b(a_3, null) == 0)
                    {
                        cursor = limit - v_8;
                        break lab12;
                    }
                    bra = cursor;
                    slice_del();
                    break lab12;
                }
                lab13: while (true) {
                    int v_9 = limit - cursor;
                    lab14: while (true) {
                        ket = cursor;
                        if (find_among_b(a_1, null) == 0)
                        {
                            break lab14;
                        }
                        bra = cursor;
                        slice_del();
                        int v_10 = limit - cursor;
                        lab15: while (true) {
                            ket = cursor;
                            among_var = find_among_b(a_2, null);
                            if (among_var == 0)
                            {
                                cursor = limit - v_10;
                                break lab15;
                            }
                            bra = cursor;
                            switch (among_var) {
                                case 1:
                                    lab16: while (true) {
                                        lab17: while (true) {
                                            if (!(eq_s_b("\u0430")))
                                            {
                                                break lab17;
                                            }
                                            break lab16;
                                        }
                                        if (!(eq_s_b("\u044F")))
                                        {
                                            cursor = limit - v_10;
                                            break lab15;
                                        }
                                        break lab16;
                                    }
                                    slice_del();
                                    break;
                                case 2:
                                    slice_del();
                                    break;
                            }
                            break lab15;
                        }
                        break lab13;
                    }
                    cursor = limit - v_9;
                    lab18: while (true) {
                        ket = cursor;
                        among_var = find_among_b(a_4, null);
                        if (among_var == 0)
                        {
                            break lab18;
                        }
                        bra = cursor;
                        switch (among_var) {
                            case 1:
                                lab19: while (true) {
                                    lab20: while (true) {
                                        if (!(eq_s_b("\u0430")))
                                        {
                                            break lab20;
                                        }
                                        break lab19;
                                    }
                                    if (!(eq_s_b("\u044F")))
                                    {
                                        break lab18;
                                    }
                                    break lab19;
                                }
                                slice_del();
                                break;
                            case 2:
                                slice_del();
                                break;
                        }
                        break lab13;
                    }
                    cursor = limit - v_9;
                    ket = cursor;
                    if (find_among_b(a_5, null) == 0)
                    {
                        break lab7;
                    }
                    bra = cursor;
                    slice_del();
                    break lab13;
                }
                break lab8;
            }
            break lab7;
        }
        cursor = limit - v_6;
        int v_11 = limit - cursor;
        lab21: while (true) {
            ket = cursor;
            if (!(eq_s_b("\u0438")))
            {
                cursor = limit - v_11;
                break lab21;
            }
            bra = cursor;
            slice_del();
            break lab21;
        }
        int v_12 = limit - cursor;
        lab22: while (true) {
            ket = cursor;
            if (find_among_b(a_6, null) == 0)
            {
                break lab22;
            }
            bra = cursor;
            if (I_p2 > cursor)
            {
                break lab22;
            }
            slice_del();
            break lab22;
        }
        cursor = limit - v_12;
        int v_13 = limit - cursor;
        lab23: while (true) {
            ket = cursor;
            among_var = find_among_b(a_7, null);
            if (among_var == 0)
            {
                break lab23;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_del();
                    ket = cursor;
                    if (!(eq_s_b("\u043D")))
                    {
                        break lab23;
                    }
                    bra = cursor;
                    if (!(eq_s_b("\u043D")))
                    {
                        break lab23;
                    }
                    slice_del();
                    break;
                case 2:
                    if (!(eq_s_b("\u043D")))
                    {
                        break lab23;
                    }
                    slice_del();
                    break;
                case 3:
                    slice_del();
                    break;
            }
            break lab23;
        }
        cursor = limit - v_13;
        limit_backward = v_5;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is russian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
