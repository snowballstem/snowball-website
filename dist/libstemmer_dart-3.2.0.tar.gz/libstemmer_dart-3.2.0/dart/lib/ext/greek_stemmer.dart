// Generated from greek.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from greek.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class greek_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 25, 0),
        Among("\u0386", 0, 1, 0),
        Among("\u0388", 0, 5, 0),
        Among("\u0389", 0, 7, 0),
        Among("\u038A", 0, 9, 0),
        Among("\u038C", 0, 15, 0),
        Among("\u038E", 0, 20, 0),
        Among("\u038F", 0, 24, 0),
        Among("\u0390", 0, 7, 0),
        Among("\u0391", 0, 1, 0),
        Among("\u0392", 0, 2, 0),
        Among("\u0393", 0, 3, 0),
        Among("\u0394", 0, 4, 0),
        Among("\u0395", 0, 5, 0),
        Among("\u0396", 0, 6, 0),
        Among("\u0397", 0, 7, 0),
        Among("\u0398", 0, 8, 0),
        Among("\u0399", 0, 9, 0),
        Among("\u039A", 0, 10, 0),
        Among("\u039B", 0, 11, 0),
        Among("\u039C", 0, 12, 0),
        Among("\u039D", 0, 13, 0),
        Among("\u039E", 0, 14, 0),
        Among("\u039F", 0, 15, 0),
        Among("\u03A0", 0, 16, 0),
        Among("\u03A1", 0, 17, 0),
        Among("\u03A3", 0, 18, 0),
        Among("\u03A4", 0, 19, 0),
        Among("\u03A5", 0, 20, 0),
        Among("\u03A6", 0, 21, 0),
        Among("\u03A7", 0, 22, 0),
        Among("\u03A8", 0, 23, 0),
        Among("\u03A9", 0, 24, 0),
        Among("\u03AA", 0, 9, 0),
        Among("\u03AB", 0, 20, 0),
        Among("\u03AC", 0, 1, 0),
        Among("\u03AD", 0, 5, 0),
        Among("\u03AE", 0, 7, 0),
        Among("\u03AF", 0, 9, 0),
        Among("\u03B0", 0, 20, 0),
        Among("\u03C2", 0, 18, 0),
        Among("\u03CA", 0, 7, 0),
        Among("\u03CB", 0, 20, 0),
        Among("\u03CC", 0, 15, 0),
        Among("\u03CD", 0, 20, 0),
        Among("\u03CE", 0, 24, 0)
    ];

    static final a_1 = [
        Among("\u03C3\u03BA\u03B1\u03B3\u03B9\u03B1", -1, 2, 0),
        Among("\u03C6\u03B1\u03B3\u03B9\u03B1", -1, 1, 0),
        Among("\u03BF\u03BB\u03BF\u03B3\u03B9\u03B1", -1, 3, 0),
        Among("\u03C3\u03BF\u03B3\u03B9\u03B1", -1, 4, 0),
        Among("\u03C4\u03B1\u03C4\u03BF\u03B3\u03B9\u03B1", -1, 5, 0),
        Among("\u03BA\u03C1\u03B5\u03B1\u03C4\u03B1", -1, 6, 0),
        Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03B1", -1, 7, 0),
        Among("\u03C4\u03B5\u03C1\u03B1\u03C4\u03B1", -1, 8, 0),
        Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C4\u03B1", -1, 11, 0),
        Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C4\u03B1", -1, 10, 0),
        Among("\u03C6\u03C9\u03C4\u03B1", -1, 9, 0),
        Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03B7", -1, 7, 0),
        Among("\u03C3\u03BA\u03B1\u03B3\u03B9\u03C9\u03BD", -1, 2, 0),
        Among("\u03C6\u03B1\u03B3\u03B9\u03C9\u03BD", -1, 1, 0),
        Among("\u03BF\u03BB\u03BF\u03B3\u03B9\u03C9\u03BD", -1, 3, 0),
        Among("\u03C3\u03BF\u03B3\u03B9\u03C9\u03BD", -1, 4, 0),
        Among("\u03C4\u03B1\u03C4\u03BF\u03B3\u03B9\u03C9\u03BD", -1, 5, 0),
        Among("\u03BA\u03C1\u03B5\u03B1\u03C4\u03C9\u03BD", -1, 6, 0),
        Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03C9\u03BD", -1, 7, 0),
        Among("\u03C4\u03B5\u03C1\u03B1\u03C4\u03C9\u03BD", -1, 8, 0),
        Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C4\u03C9\u03BD", -1, 11, 0),
        Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C4\u03C9\u03BD", -1, 10, 0),
        Among("\u03C6\u03C9\u03C4\u03C9\u03BD", -1, 9, 0),
        Among("\u03BA\u03C1\u03B5\u03B1\u03C3", -1, 6, 0),
        Among("\u03C0\u03B5\u03C1\u03B1\u03C3", -1, 7, 0),
        Among("\u03C4\u03B5\u03C1\u03B1\u03C3", -1, 8, 0),
        Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C3", -1, 11, 0),
        Among("\u03BA\u03C1\u03B5\u03B1\u03C4\u03BF\u03C3", -1, 6, 0),
        Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03BF\u03C3", -1, 7, 0),
        Among("\u03C4\u03B5\u03C1\u03B1\u03C4\u03BF\u03C3", -1, 8, 0),
        Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C4\u03BF\u03C3", -1, 11, 0),
        Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C4\u03BF\u03C3", -1, 10, 0),
        Among("\u03C6\u03C9\u03C4\u03BF\u03C3", -1, 9, 0),
        Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C3", -1, 10, 0),
        Among("\u03C6\u03C9\u03C3", -1, 9, 0),
        Among("\u03C3\u03BA\u03B1\u03B3\u03B9\u03BF\u03C5", -1, 2, 0),
        Among("\u03C6\u03B1\u03B3\u03B9\u03BF\u03C5", -1, 1, 0),
        Among("\u03BF\u03BB\u03BF\u03B3\u03B9\u03BF\u03C5", -1, 3, 0),
        Among("\u03C3\u03BF\u03B3\u03B9\u03BF\u03C5", -1, 4, 0),
        Among("\u03C4\u03B1\u03C4\u03BF\u03B3\u03B9\u03BF\u03C5", -1, 5, 0)
    ];

    static final a_2 = [
        Among("\u03C0\u03B1", -1, 1, 0),
        Among("\u03BE\u03B1\u03BD\u03B1\u03C0\u03B1", 0, 1, 0),
        Among("\u03B5\u03C0\u03B1", 0, 1, 0),
        Among("\u03C0\u03B5\u03C1\u03B9\u03C0\u03B1", 0, 1, 0),
        Among("\u03B1\u03BD\u03B1\u03BC\u03C0\u03B1", 0, 1, 0),
        Among("\u03B5\u03BC\u03C0\u03B1", 0, 1, 0),
        Among("\u03B2", -1, 2, 0),
        Among("\u03B4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B2\u03B1\u03B8\u03C5\u03C1\u03B9", -1, 2, 0),
        Among("\u03B2\u03B1\u03C1\u03BA", -1, 2, 0),
        Among("\u03BC\u03B1\u03C1\u03BA", -1, 2, 0),
        Among("\u03BB", -1, 2, 0),
        Among("\u03BC", -1, 2, 0),
        Among("\u03BA\u03BF\u03C1\u03BD", -1, 2, 0),
        Among("\u03B1\u03B8\u03C1\u03BF", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", 14, 1, 0),
        Among("\u03C0", -1, 2, 0),
        Among("\u03B9\u03BC\u03C0", 16, 2, 0),
        Among("\u03C1", -1, 2, 0),
        Among("\u03BC\u03B1\u03C1", 18, 2, 0),
        Among("\u03B1\u03BC\u03C0\u03B1\u03C1", 18, 2, 0),
        Among("\u03B3\u03BA\u03C1", 18, 2, 0),
        Among("\u03B2\u03BF\u03BB\u03B2\u03BF\u03C1", 18, 2, 0),
        Among("\u03B3\u03BB\u03C5\u03BA\u03BF\u03C1", 18, 2, 0),
        Among("\u03C0\u03B9\u03C0\u03B5\u03C1\u03BF\u03C1", 18, 2, 0),
        Among("\u03C0\u03C1", 18, 2, 0),
        Among("\u03BC\u03C0\u03C1", 25, 2, 0),
        Among("\u03B1\u03C1\u03C1", 18, 2, 0),
        Among("\u03B3\u03BB\u03C5\u03BA\u03C5\u03C1", 18, 2, 0),
        Among("\u03C0\u03BF\u03BB\u03C5\u03C1", 18, 2, 0),
        Among("\u03BB\u03BF\u03C5", -1, 2, 0)
    ];

    static final a_3 = [
        Among("\u03B9\u03B6\u03B1", -1, 1, 0),
        Among("\u03B9\u03B6\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03BF\u03C5\u03BC\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03BF\u03C5\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03B1\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03B5\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03B6\u03B5\u03B9", -1, 1, 0),
        Among("\u03B9\u03B6\u03B1\u03BD", -1, 1, 0),
        Among("\u03B9\u03B6\u03BF\u03C5\u03BD", -1, 1, 0),
        Among("\u03B9\u03B6\u03B5\u03C3", -1, 1, 0),
        Among("\u03B9\u03B6\u03B5\u03B9\u03C3", -1, 1, 0),
        Among("\u03B9\u03B6\u03C9", -1, 1, 0)
    ];

    static final a_4 = [
        Among("\u03B2\u03B9", -1, 1, 0),
        Among("\u03BB\u03B9", -1, 1, 0),
        Among("\u03B1\u03BB", -1, 1, 0),
        Among("\u03B5\u03BD", -1, 1, 0),
        Among("\u03C3", -1, 1, 0),
        Among("\u03C7", -1, 1, 0),
        Among("\u03C5\u03C8", -1, 1, 0),
        Among("\u03B6\u03C9", -1, 1, 0)
    ];

    static final a_5 = [
        Among("\u03C9\u03B8\u03B7\u03BA\u03B1", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B5", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03C4\u03B5", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03BD", -1, 1, 0),
        Among("\u03C9\u03B8\u03B7\u03BA\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_6 = [
        Among("\u03BE\u03B1\u03BD\u03B1\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03C0\u03B1", -1, 1, 0),
        Among("\u03C0\u03B5\u03C1\u03B9\u03C0\u03B1", -1, 1, 0),
        Among("\u03B1\u03BD\u03B1\u03BC\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03BC\u03C0\u03B1", -1, 1, 0),
        Among("\u03C7\u03B1\u03C1\u03C4\u03BF\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03BE\u03B1\u03C1\u03C7\u03B1", -1, 1, 0),
        Among("\u03B3\u03B5", -1, 2, 0),
        Among("\u03B3\u03BA\u03B5", -1, 2, 0),
        Among("\u03BA\u03BB\u03B5", -1, 1, 0),
        Among("\u03B5\u03BA\u03BB\u03B5", 9, 1, 0),
        Among("\u03B1\u03C0\u03B5\u03BA\u03BB\u03B5", 10, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03BA\u03BB\u03B5", 9, 1, 0),
        Among("\u03B5\u03C3\u03C9\u03BA\u03BB\u03B5", 9, 1, 0),
        Among("\u03B4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03C0\u03B5", -1, 1, 0),
        Among("\u03B5\u03C0\u03B5", 15, 1, 0),
        Among("\u03BC\u03B5\u03C4\u03B5\u03C0\u03B5", 16, 1, 0),
        Among("\u03B5\u03C3\u03B5", -1, 1, 0),
        Among("\u03B3\u03BA", -1, 2, 0),
        Among("\u03BC", -1, 2, 0),
        Among("\u03C0\u03BF\u03C5\u03BA\u03B1\u03BC", 20, 2, 0),
        Among("\u03BA\u03BF\u03BC", 20, 2, 0),
        Among("\u03B1\u03BD", -1, 2, 0),
        Among("\u03BF\u03BB\u03BF", -1, 2, 0),
        Among("\u03B1\u03B8\u03C1\u03BF", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", 25, 1, 0),
        Among("\u03C0", -1, 2, 0),
        Among("\u03BB\u03B1\u03C1", -1, 2, 0),
        Among("\u03B4\u03B7\u03BC\u03BF\u03BA\u03C1\u03B1\u03C4", -1, 2, 0),
        Among("\u03B1\u03C6", -1, 2, 0),
        Among("\u03B3\u03B9\u03B3\u03B1\u03BD\u03C4\u03BF\u03B1\u03C6", 30, 2, 0)
    ];

    static final a_7 = [
        Among("\u03B9\u03C3\u03B1", -1, 1, 0),
        Among("\u03B9\u03C3\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B1\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B1\u03BD", -1, 1, 0),
        Among("\u03B9\u03C3\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_8 = [
        Among("\u03BE\u03B1\u03BD\u03B1\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03C0\u03B1", -1, 1, 0),
        Among("\u03C0\u03B5\u03C1\u03B9\u03C0\u03B1", -1, 1, 0),
        Among("\u03B1\u03BD\u03B1\u03BC\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03BC\u03C0\u03B1", -1, 1, 0),
        Among("\u03C7\u03B1\u03C1\u03C4\u03BF\u03C0\u03B1", -1, 1, 0),
        Among("\u03B5\u03BE\u03B1\u03C1\u03C7\u03B1", -1, 1, 0),
        Among("\u03BA\u03BB\u03B5", -1, 1, 0),
        Among("\u03B5\u03BA\u03BB\u03B5", 7, 1, 0),
        Among("\u03B1\u03C0\u03B5\u03BA\u03BB\u03B5", 8, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03BA\u03BB\u03B5", 7, 1, 0),
        Among("\u03B5\u03C3\u03C9\u03BA\u03BB\u03B5", 7, 1, 0),
        Among("\u03B4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03C0\u03B5", -1, 1, 0),
        Among("\u03B5\u03C0\u03B5", 13, 1, 0),
        Among("\u03BC\u03B5\u03C4\u03B5\u03C0\u03B5", 14, 1, 0),
        Among("\u03B5\u03C3\u03B5", -1, 1, 0),
        Among("\u03B1\u03B8\u03C1\u03BF", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", 17, 1, 0)
    ];

    static final a_9 = [
        Among("\u03B9\u03C3\u03BF\u03C5\u03BC\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03BF\u03C5\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B5\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03B5\u03B9", -1, 1, 0),
        Among("\u03B9\u03C3\u03BF\u03C5\u03BD", -1, 1, 0),
        Among("\u03B9\u03C3\u03B5\u03B9\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03C9", -1, 1, 0)
    ];

    static final a_10 = [
        Among("\u03B1\u03C4\u03B1", -1, 2, 0),
        Among("\u03C6\u03B1", -1, 2, 0),
        Among("\u03B7\u03C6\u03B1", 1, 2, 0),
        Among("\u03BC\u03B5\u03B3", -1, 2, 0),
        Among("\u03BB\u03C5\u03B3", -1, 2, 0),
        Among("\u03B7\u03B4", -1, 2, 0),
        Among("\u03BA\u03BB\u03B5", -1, 1, 0),
        Among("\u03B5\u03C3\u03C9\u03BA\u03BB\u03B5", 6, 1, 0),
        Among("\u03C0\u03BB\u03B5", -1, 1, 0),
        Among("\u03B4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03C3\u03B5", -1, 1, 0),
        Among("\u03B1\u03C3\u03B5", 10, 1, 0),
        Among("\u03BA\u03B1\u03B8", -1, 2, 0),
        Among("\u03B5\u03C7\u03B8", -1, 2, 0),
        Among("\u03BA\u03B1\u03BA", -1, 2, 0),
        Among("\u03BC\u03B1\u03BA", -1, 2, 0),
        Among("\u03C3\u03BA", -1, 2, 0),
        Among("\u03C6\u03B9\u03BB", -1, 2, 0),
        Among("\u03BA\u03C5\u03BB", -1, 2, 0),
        Among("\u03BC", -1, 2, 0),
        Among("\u03B3\u03B5\u03BC", 19, 2, 0),
        Among("\u03B1\u03C7\u03BD", -1, 2, 0),
        Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", -1, 1, 0),
        Among("\u03C0", -1, 2, 0),
        Among("\u03B1\u03C0", 23, 2, 0),
        Among("\u03B5\u03BC\u03C0", 23, 2, 0),
        Among("\u03B5\u03C5\u03C0", 23, 2, 0),
        Among("\u03B1\u03C1", -1, 2, 0),
        Among("\u03B1\u03BF\u03C1", -1, 2, 0),
        Among("\u03B3\u03C5\u03C1", -1, 2, 0),
        Among("\u03C7\u03C1", -1, 2, 0),
        Among("\u03C7\u03C9\u03C1", -1, 2, 0),
        Among("\u03BA\u03C4", -1, 2, 0),
        Among("\u03B1\u03BA\u03C4", 32, 2, 0),
        Among("\u03C7\u03C4", -1, 2, 0),
        Among("\u03B1\u03C7\u03C4", 34, 2, 0),
        Among("\u03C4\u03B1\u03C7", -1, 2, 0),
        Among("\u03C3\u03C7", -1, 2, 0),
        Among("\u03B1\u03C3\u03C7", 37, 2, 0),
        Among("\u03C5\u03C8", -1, 2, 0)
    ];

    static final a_11 = [
        Among("\u03B9\u03C3\u03C4\u03B1", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03B7", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03BF\u03B9", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03BF", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03B5\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03B7\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03BF\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03BF\u03C5\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03C4\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_12 = [
        Among("\u03B5\u03B3\u03BA\u03BB\u03B5", -1, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03BA\u03BB\u03B5", -1, 1, 0),
        Among("\u03B4\u03B1\u03BD\u03B5", -1, 2, 0),
        Among("\u03B1\u03BD\u03C4\u03B9\u03B4\u03B1\u03BD\u03B5", 2, 2, 0),
        Among("\u03C3\u03B5", -1, 1, 0),
        Among("\u03BC\u03B5\u03C4\u03B1\u03C3\u03B5", 4, 1, 0),
        Among("\u03BC\u03B9\u03BA\u03C1\u03BF\u03C3\u03B5", 4, 1, 0)
    ];

    static final a_13 = [
        Among("\u03B1\u03C4\u03BF\u03BC\u03B9\u03BA", -1, 2, 0),
        Among("\u03B5\u03B8\u03BD\u03B9\u03BA", -1, 4, 0),
        Among("\u03C4\u03BF\u03C0\u03B9\u03BA", -1, 7, 0),
        Among("\u03B5\u03BA\u03BB\u03B5\u03BA\u03C4\u03B9\u03BA", -1, 5, 0),
        Among("\u03C3\u03BA\u03B5\u03C0\u03C4\u03B9\u03BA", -1, 6, 0),
        Among("\u03B3\u03BD\u03C9\u03C3\u03C4\u03B9\u03BA", -1, 3, 0),
        Among("\u03B1\u03B3\u03BD\u03C9\u03C3\u03C4\u03B9\u03BA", 5, 1, 0),
        Among("\u03B1\u03BB\u03B5\u03BE\u03B1\u03BD\u03B4\u03C1\u03B9\u03BD", -1, 8, 0),
        Among("\u03B8\u03B5\u03B1\u03C4\u03C1\u03B9\u03BD", -1, 10, 0),
        Among("\u03B2\u03C5\u03B6\u03B1\u03BD\u03C4\u03B9\u03BD", -1, 9, 0)
    ];

    static final a_14 = [
        Among("\u03B9\u03C3\u03BC\u03BF\u03B9", -1, 1, 0),
        Among("\u03B9\u03C3\u03BC\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03C3\u03BC\u03BF", -1, 1, 0),
        Among("\u03B9\u03C3\u03BC\u03BF\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03BC\u03BF\u03C5\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03BC\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_15 = [
        Among("\u03C3", -1, 1, 0),
        Among("\u03C7", -1, 1, 0)
    ];

    static final a_16 = [
        Among("\u03BF\u03C5\u03B4\u03B1\u03BA\u03B9\u03B1", -1, 1, 0),
        Among("\u03B1\u03C1\u03B1\u03BA\u03B9\u03B1", -1, 1, 0),
        Among("\u03BF\u03C5\u03B4\u03B1\u03BA\u03B9", -1, 1, 0),
        Among("\u03B1\u03C1\u03B1\u03BA\u03B9", -1, 1, 0)
    ];

    static final a_17 = [
        Among("\u03B2", -1, 2, 0),
        Among("\u03B2\u03B1\u03BC\u03B2", 0, 1, 0),
        Among("\u03C3\u03BB\u03BF\u03B2", 0, 1, 0),
        Among("\u03C4\u03C3\u03B5\u03C7\u03BF\u03C3\u03BB\u03BF\u03B2", 2, 1, 0),
        Among("\u03BA\u03B1\u03C1\u03B4", -1, 2, 0),
        Among("\u03B6", -1, 2, 0),
        Among("\u03C4\u03B6", 5, 1, 0),
        Among("\u03BA", -1, 1, 0),
        Among("\u03BA\u03B1\u03C0\u03B1\u03BA", 7, 1, 0),
        Among("\u03C3\u03BF\u03BA", 7, 1, 0),
        Among("\u03C3\u03BA", 7, 1, 0),
        Among("\u03B2\u03B1\u03BB", -1, 2, 0),
        Among("\u03BC\u03B1\u03BB", -1, 1, 0),
        Among("\u03B3\u03BB", -1, 2, 0),
        Among("\u03C4\u03C1\u03B9\u03C0\u03BF\u03BB", -1, 2, 0),
        Among("\u03C0\u03BB", -1, 1, 0),
        Among("\u03BB\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03C6\u03C5\u03BB", -1, 1, 0),
        Among("\u03BA\u03B1\u03B9\u03BC", -1, 1, 0),
        Among("\u03BA\u03BB\u03B9\u03BC", -1, 1, 0),
        Among("\u03C6\u03B1\u03C1\u03BC", -1, 1, 0),
        Among("\u03B3\u03B9\u03B1\u03BD", -1, 2, 0),
        Among("\u03C3\u03C0\u03B1\u03BD", -1, 1, 0),
        Among("\u03B7\u03B3\u03BF\u03C5\u03BC\u03B5\u03BD", -1, 2, 0),
        Among("\u03BA\u03BF\u03BD", -1, 1, 0),
        Among("\u03BC\u03B1\u03BA\u03C1\u03C5\u03BD", -1, 2, 0),
        Among("\u03C0", -1, 2, 0),
        Among("\u03BA\u03B1\u03C4\u03C1\u03B1\u03C0", 26, 1, 0),
        Among("\u03C1", -1, 1, 0),
        Among("\u03B2\u03C1", 28, 1, 0),
        Among("\u03BB\u03B1\u03B2\u03C1", 29, 1, 0),
        Among("\u03B1\u03BC\u03B2\u03C1", 29, 1, 0),
        Among("\u03BC\u03B5\u03C1", 28, 1, 0),
        Among("\u03C0\u03B1\u03C4\u03B5\u03C1", 28, 2, 0),
        Among("\u03B1\u03BD\u03B8\u03C1", 28, 1, 0),
        Among("\u03BA\u03BF\u03C1", 28, 1, 0),
        Among("\u03C3", -1, 1, 0),
        Among("\u03BD\u03B1\u03B3\u03BA\u03B1\u03C3", 36, 1, 0),
        Among("\u03C4\u03BF\u03C3", 36, 2, 0),
        Among("\u03BC\u03BF\u03C5\u03C3\u03C4", -1, 1, 0),
        Among("\u03C1\u03C5", -1, 1, 0),
        Among("\u03C6", -1, 1, 0),
        Among("\u03C3\u03C6", 41, 1, 0),
        Among("\u03B1\u03BB\u03B9\u03C3\u03C6", 42, 1, 0),
        Among("\u03BD\u03C5\u03C6", 41, 2, 0),
        Among("\u03C7", -1, 1, 0)
    ];

    static final a_18 = [
        Among("\u03B1\u03BA\u03B9\u03B1", -1, 1, 0),
        Among("\u03B1\u03C1\u03B1\u03BA\u03B9\u03B1", 0, 1, 0),
        Among("\u03B9\u03C4\u03C3\u03B1", -1, 1, 0),
        Among("\u03B1\u03BA\u03B9", -1, 1, 0),
        Among("\u03B1\u03C1\u03B1\u03BA\u03B9", 3, 1, 0),
        Among("\u03B9\u03C4\u03C3\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03C4\u03C3\u03B1\u03C3", -1, 1, 0),
        Among("\u03B9\u03C4\u03C3\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_19 = [
        Among("\u03C8\u03B1\u03BB", -1, 1, 0),
        Among("\u03B1\u03B9\u03C6\u03BD", -1, 1, 0),
        Among("\u03BF\u03BB\u03BF", -1, 1, 0),
        Among("\u03B9\u03C1", -1, 1, 0)
    ];

    static final a_20 = [
        Among("\u03B5", -1, 1, 0),
        Among("\u03C0\u03B1\u03B9\u03C7\u03BD", -1, 1, 0)
    ];

    static final a_21 = [
        Among("\u03B9\u03B4\u03B9\u03B1", -1, 1, 0),
        Among("\u03B9\u03B4\u03B9\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03B4\u03B9\u03BF", -1, 1, 0)
    ];

    static final a_22 = [
        Among("\u03B9\u03B2", -1, 1, 0),
        Among("\u03B4", -1, 1, 0),
        Among("\u03C6\u03C1\u03B1\u03B3\u03BA", -1, 1, 0),
        Among("\u03BB\u03C5\u03BA", -1, 1, 0),
        Among("\u03BF\u03B2\u03B5\u03BB", -1, 1, 0),
        Among("\u03BC\u03B7\u03BD", -1, 1, 0),
        Among("\u03C1", -1, 1, 0)
    ];

    static final a_23 = [
        Among("\u03B9\u03C3\u03BA\u03B5", -1, 1, 0),
        Among("\u03B9\u03C3\u03BA\u03BF", -1, 1, 0),
        Among("\u03B9\u03C3\u03BA\u03BF\u03C3", -1, 1, 0),
        Among("\u03B9\u03C3\u03BA\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_24 = [
        Among("\u03B1\u03B4\u03C9\u03BD", -1, 1, 0),
        Among("\u03B1\u03B4\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_25 = [
        Among("\u03B3\u03B9\u03B1\u03B3\u03B9", -1, -1, 0),
        Among("\u03B8\u03B5\u03B9", -1, -1, 0),
        Among("\u03BF\u03BA", -1, -1, 0),
        Among("\u03BC\u03B1\u03BC", -1, -1, 0),
        Among("\u03BC\u03B1\u03BD", -1, -1, 0),
        Among("\u03BC\u03C0\u03B1\u03BC\u03C0", -1, -1, 0),
        Among("\u03C0\u03B5\u03B8\u03B5\u03C1", -1, -1, 0),
        Among("\u03C0\u03B1\u03C4\u03B5\u03C1", -1, -1, 0),
        Among("\u03BA\u03C5\u03C1", -1, -1, 0),
        Among("\u03BD\u03C4\u03B1\u03BD\u03C4", -1, -1, 0)
    ];

    static final a_26 = [
        Among("\u03B5\u03B4\u03C9\u03BD", -1, 1, 0),
        Among("\u03B5\u03B4\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_27 = [
        Among("\u03BC\u03B9\u03BB", -1, 1, 0),
        Among("\u03B4\u03B1\u03C0", -1, 1, 0),
        Among("\u03B3\u03B7\u03C0", -1, 1, 0),
        Among("\u03B9\u03C0", -1, 1, 0),
        Among("\u03B5\u03BC\u03C0", -1, 1, 0),
        Among("\u03BF\u03C0", -1, 1, 0),
        Among("\u03BA\u03C1\u03B1\u03C3\u03C0", -1, 1, 0),
        Among("\u03C5\u03C0", -1, 1, 0)
    ];

    static final a_28 = [
        Among("\u03BF\u03C5\u03B4\u03C9\u03BD", -1, 1, 0),
        Among("\u03BF\u03C5\u03B4\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_29 = [
        Among("\u03C4\u03C1\u03B1\u03B3", -1, 1, 0),
        Among("\u03C6\u03B5", -1, 1, 0),
        Among("\u03BA\u03B1\u03BB\u03B9\u03B1\u03BA", -1, 1, 0),
        Among("\u03B1\u03C1\u03BA", -1, 1, 0),
        Among("\u03C3\u03BA", -1, 1, 0),
        Among("\u03C0\u03B5\u03C4\u03B1\u03BB", -1, 1, 0),
        Among("\u03B2\u03B5\u03BB", -1, 1, 0),
        Among("\u03BB\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03C6\u03BB", -1, 1, 0),
        Among("\u03C7\u03BD", -1, 1, 0),
        Among("\u03C0\u03BB\u03B5\u03BE", -1, 1, 0),
        Among("\u03C3\u03C0", -1, 1, 0),
        Among("\u03C6\u03C1", -1, 1, 0),
        Among("\u03C3", -1, 1, 0),
        Among("\u03BB\u03B9\u03C7", -1, 1, 0)
    ];

    static final a_30 = [
        Among("\u03B5\u03C9\u03BD", -1, 1, 0),
        Among("\u03B5\u03C9\u03C3", -1, 1, 0)
    ];

    static final a_31 = [
        Among("\u03B4", -1, 1, 0),
        Among("\u03B9\u03B4", 0, 1, 0),
        Among("\u03B8", -1, 1, 0),
        Among("\u03B3\u03B1\u03BB", -1, 1, 0),
        Among("\u03B5\u03BB", -1, 1, 0),
        Among("\u03BD", -1, 1, 0),
        Among("\u03C0", -1, 1, 0),
        Among("\u03C0\u03B1\u03C1", -1, 1, 0)
    ];

    static final a_32 = [
        Among("\u03B9\u03B1", -1, 1, 0),
        Among("\u03B9\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_33 = [
        Among("\u03B9\u03BA\u03B1", -1, 1, 0),
        Among("\u03B9\u03BA\u03C9\u03BD", -1, 1, 0),
        Among("\u03B9\u03BA\u03BF", -1, 1, 0),
        Among("\u03B9\u03BA\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_34 = [
        Among("\u03B1\u03B4", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B1\u03B4", 0, 1, 0),
        Among("\u03BA\u03B1\u03C4\u03B1\u03B4", 0, 1, 0),
        Among("\u03B1\u03BD\u03C4\u03B9\u03B4", -1, 1, 0),
        Among("\u03B5\u03BD\u03B4", -1, 1, 0),
        Among("\u03C6\u03C5\u03BB\u03BF\u03B4", -1, 1, 0),
        Among("\u03C5\u03C0\u03BF\u03B4", -1, 1, 0),
        Among("\u03C0\u03C1\u03C9\u03C4\u03BF\u03B4", -1, 1, 0),
        Among("\u03B5\u03BE\u03C9\u03B4", -1, 1, 0),
        Among("\u03B7\u03B8", -1, 1, 0),
        Among("\u03B1\u03BD\u03B7\u03B8", 9, 1, 0),
        Among("\u03BE\u03B9\u03BA", -1, 1, 0),
        Among("\u03B1\u03BB", -1, 1, 0),
        Among("\u03B1\u03BC\u03BC\u03BF\u03C7\u03B1\u03BB", 12, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03BF\u03BC\u03B7\u03BB", -1, 1, 0),
        Among("\u03BC\u03C0\u03BF\u03BB", -1, 1, 0),
        Among("\u03BC\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03C4\u03C3\u03B1\u03BC", -1, 1, 0),
        Among("\u03B2\u03C1\u03C9\u03BC", -1, 1, 0),
        Among("\u03B1\u03BC\u03B1\u03BD", -1, 1, 0),
        Among("\u03BC\u03C0\u03B1\u03BD", -1, 1, 0),
        Among("\u03BA\u03B1\u03BB\u03BB\u03B9\u03BD", -1, 1, 0),
        Among("\u03C0\u03BF\u03C3\u03C4\u03B5\u03BB\u03BD", -1, 1, 0),
        Among("\u03C6\u03B9\u03BB\u03BF\u03BD", -1, 1, 0),
        Among("\u03BA\u03B1\u03BB\u03C0", -1, 1, 0),
        Among("\u03B3\u03B5\u03C1", -1, 1, 0),
        Among("\u03C7\u03B1\u03C3", -1, 1, 0),
        Among("\u03BC\u03C0\u03BF\u03C3", -1, 1, 0),
        Among("\u03C0\u03BB\u03B9\u03B1\u03C4\u03C3", -1, 1, 0),
        Among("\u03C0\u03B5\u03C4\u03C3", -1, 1, 0),
        Among("\u03C0\u03B9\u03C4\u03C3", -1, 1, 0),
        Among("\u03C6\u03C5\u03C3", -1, 1, 0),
        Among("\u03BC\u03C0\u03B1\u03B3\u03B9\u03B1\u03C4", -1, 1, 0),
        Among("\u03BD\u03B9\u03C4", -1, 1, 0),
        Among("\u03C0\u03B9\u03BA\u03B1\u03BD\u03C4", -1, 1, 0),
        Among("\u03C3\u03B5\u03C1\u03C4", -1, 1, 0)
    ];

    static final a_35 = [
        Among("\u03B1\u03B3\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03B7\u03BA\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03BC\u03B5", 1, 1, 0),
        Among("\u03B7\u03C3\u03B1\u03BC\u03B5", -1, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B1\u03BC\u03B5", -1, 1, 0)
    ];

    static final a_36 = [
        Among("\u03B2\u03BF\u03C5\u03B2", -1, 1, 0),
        Among("\u03BE\u03B5\u03B8", -1, 1, 0),
        Among("\u03C0\u03B5\u03B8", -1, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03B8", -1, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03BA", -1, 1, 0),
        Among("\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03B1\u03BD\u03B1\u03C0", -1, 1, 0),
        Among("\u03C0\u03B9\u03BA\u03C1", -1, 1, 0),
        Among("\u03C0\u03BF\u03C4", -1, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03C3\u03C4", -1, 1, 0),
        Among("\u03C7", -1, 1, 0),
        Among("\u03C3\u03B9\u03C7", 10, 1, 0)
    ];

    static final a_37 = [
        Among("\u03C4\u03C1", -1, 1, 0),
        Among("\u03C4\u03C3", -1, 1, 0)
    ];

    static final a_38 = [
        Among("\u03B1\u03B3\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B7\u03BA\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03BD\u03B5", 1, 1, 0),
        Among("\u03B7\u03C3\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03BF\u03BD\u03C4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03BF\u03BD\u03C4\u03B1\u03BD\u03B5", 5, 1, 0),
        Among("\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD\u03B5", 7, 1, 0),
        Among("\u03BF\u03C4\u03B1\u03BD\u03B5", -1, 1, 0),
        Among("\u03B9\u03BF\u03C4\u03B1\u03BD\u03B5", 9, 1, 0)
    ];

    static final a_39 = [
        Among("\u03C4\u03B1\u03B2", -1, 1, 0),
        Among("\u03BD\u03C4\u03B1\u03B2", 0, 1, 0),
        Among("\u03C8\u03B7\u03BB\u03BF\u03C4\u03B1\u03B2", 0, 1, 0),
        Among("\u03BB\u03B9\u03B2", -1, 1, 0),
        Among("\u03BA\u03BB\u03B9\u03B2", 3, 1, 0),
        Among("\u03BE\u03B7\u03C1\u03BF\u03BA\u03BB\u03B9\u03B2", 4, 1, 0),
        Among("\u03B3", -1, 1, 0),
        Among("\u03B1\u03B3", 6, 1, 0),
        Among("\u03C4\u03C1\u03B1\u03B3", 7, 1, 0),
        Among("\u03C4\u03C3\u03B1\u03B3", 7, 1, 0),
        Among("\u03B1\u03B8\u03B9\u03B3\u03B3", 6, 1, 0),
        Among("\u03C4\u03C3\u03B9\u03B3\u03B3", 6, 1, 0),
        Among("\u03B1\u03C4\u03C3\u03B9\u03B3\u03B3", 11, 1, 0),
        Among("\u03C3\u03C4\u03B5\u03B3", 6, 1, 0),
        Among("\u03B1\u03C0\u03B7\u03B3", 6, 1, 0),
        Among("\u03C3\u03B9\u03B3", 6, 1, 0),
        Among("\u03B1\u03BD\u03BF\u03C1\u03B3", 6, 1, 0),
        Among("\u03B5\u03BD\u03BF\u03C1\u03B3", 6, 1, 0),
        Among("\u03BA\u03B1\u03BB\u03C0\u03BF\u03C5\u03B6", -1, 1, 0),
        Among("\u03B8", -1, 1, 0),
        Among("\u03BC\u03C9\u03B1\u03BC\u03B5\u03B8", 19, 1, 0),
        Among("\u03C0\u03B9\u03B8", 19, 1, 0),
        Among("\u03B1\u03C0\u03B9\u03B8", 21, 1, 0),
        Among("\u03B4\u03B5\u03BA", -1, 1, 0),
        Among("\u03C0\u03B5\u03BB\u03B5\u03BA", -1, 1, 0),
        Among("\u03B9\u03BA", -1, 1, 0),
        Among("\u03B1\u03BD\u03B9\u03BA", 25, 1, 0),
        Among("\u03B2\u03BF\u03C5\u03BB\u03BA", -1, 1, 0),
        Among("\u03B2\u03B1\u03C3\u03BA", -1, 1, 0),
        Among("\u03B2\u03C1\u03B1\u03C7\u03C5\u03BA", -1, 1, 0),
        Among("\u03B3\u03B1\u03BB", -1, 1, 0),
        Among("\u03BA\u03B1\u03C4\u03B1\u03B3\u03B1\u03BB", 30, 1, 0),
        Among("\u03BF\u03BB\u03BF\u03B3\u03B1\u03BB", 30, 1, 0),
        Among("\u03B2\u03B1\u03B8\u03C5\u03B3\u03B1\u03BB", 30, 1, 0),
        Among("\u03BC\u03B5\u03BB", -1, 1, 0),
        Among("\u03BA\u03B1\u03C3\u03C4\u03B5\u03BB", -1, 1, 0),
        Among("\u03C0\u03BF\u03C1\u03C4\u03BF\u03BB", -1, 1, 0),
        Among("\u03C0\u03BB", -1, 1, 0),
        Among("\u03B4\u03B9\u03C0\u03BB", 37, 1, 0),
        Among("\u03BB\u03B1\u03BF\u03C0\u03BB", 37, 1, 0),
        Among("\u03C8\u03C5\u03C7\u03BF\u03C0\u03BB", 37, 1, 0),
        Among("\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03BC", -1, 1, 0),
        Among("\u03BF\u03BB\u03B9\u03B3\u03BF\u03B4\u03B1\u03BC", 42, 1, 0),
        Among("\u03BC\u03BF\u03C5\u03C3\u03BF\u03C5\u03BB\u03BC", 42, 1, 0),
        Among("\u03B4\u03C1\u03B1\u03B4\u03BF\u03C5\u03BC", 42, 1, 0),
        Among("\u03B2\u03C1\u03B1\u03C7\u03BC", 42, 1, 0),
        Among("\u03BD", -1, 1, 0),
        Among("\u03B1\u03BC\u03B5\u03C1\u03B9\u03BA\u03B1\u03BD", 47, 1, 0),
        Among("\u03C0", -1, 1, 0),
        Among("\u03B1\u03B4\u03B1\u03C0", 49, 1, 0),
        Among("\u03C7\u03B1\u03BC\u03B7\u03BB\u03BF\u03B4\u03B1\u03C0", 49, 1, 0),
        Among("\u03C0\u03BF\u03BB\u03C5\u03B4\u03B1\u03C0", 49, 1, 0),
        Among("\u03BA\u03BF\u03C0", 49, 1, 0),
        Among("\u03C5\u03C0\u03BF\u03BA\u03BF\u03C0", 53, 1, 0),
        Among("\u03C4\u03C3\u03BF\u03C0", 49, 1, 0),
        Among("\u03C3\u03C0", 49, 1, 0),
        Among("\u03B5\u03C1", -1, 1, 0),
        Among("\u03B3\u03B5\u03C1", 57, 1, 0),
        Among("\u03B2\u03B5\u03C4\u03B5\u03C1", 57, 1, 0),
        Among("\u03BB\u03BF\u03C5\u03B8\u03B7\u03C1", -1, 1, 0),
        Among("\u03BA\u03BF\u03C1\u03BC\u03BF\u03C1", -1, 1, 0),
        Among("\u03C0\u03B5\u03C1\u03B9\u03C4\u03C1", -1, 1, 0),
        Among("\u03BF\u03C5\u03C1", -1, 1, 0),
        Among("\u03C3", -1, 1, 0),
        Among("\u03B2\u03B1\u03C3", 64, 1, 0),
        Among("\u03C0\u03BF\u03BB\u03B9\u03C3", 64, 1, 0),
        Among("\u03C3\u03B1\u03C1\u03B1\u03BA\u03B1\u03C4\u03C3", 64, 1, 0),
        Among("\u03B8\u03C5\u03C3", 64, 1, 0),
        Among("\u03B4\u03B9\u03B1\u03C4", -1, 1, 0),
        Among("\u03C0\u03BB\u03B1\u03C4", -1, 1, 0),
        Among("\u03C4\u03C3\u03B1\u03C1\u03BB\u03B1\u03C4", -1, 1, 0),
        Among("\u03C4\u03B5\u03C4", -1, 1, 0),
        Among("\u03C0\u03BF\u03C5\u03C1\u03B9\u03C4", -1, 1, 0),
        Among("\u03C3\u03BF\u03C5\u03BB\u03C4", -1, 1, 0),
        Among("\u03BC\u03B1\u03B9\u03BD\u03C4", -1, 1, 0),
        Among("\u03B6\u03C9\u03BD\u03C4", -1, 1, 0),
        Among("\u03BA\u03B1\u03C3\u03C4", -1, 1, 0),
        Among("\u03C6", -1, 1, 0),
        Among("\u03B4\u03B9\u03B1\u03C6", 78, 1, 0),
        Among("\u03C3\u03C4\u03B5\u03C6", 78, 1, 0),
        Among("\u03C6\u03C9\u03C4\u03BF\u03C3\u03C4\u03B5\u03C6", 80, 1, 0),
        Among("\u03C0\u03B5\u03C1\u03B7\u03C6", 78, 1, 0),
        Among("\u03C5\u03C0\u03B5\u03C1\u03B7\u03C6", 82, 1, 0),
        Among("\u03BA\u03BF\u03B9\u03BB\u03B1\u03C1\u03C6", 78, 1, 0),
        Among("\u03C0\u03B5\u03BD\u03C4\u03B1\u03C1\u03C6", 78, 1, 0),
        Among("\u03BF\u03C1\u03C6", 78, 1, 0),
        Among("\u03C7", -1, 1, 0),
        Among("\u03B1\u03BC\u03B7\u03C7", 87, 1, 0),
        Among("\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 87, 1, 0),
        Among("\u03BC\u03B5\u03B3\u03BB\u03BF\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 89, 1, 0),
        Among("\u03BA\u03B1\u03C0\u03BD\u03BF\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 89, 1, 0),
        Among("\u03BC\u03B9\u03BA\u03C1\u03BF\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 89, 1, 0),
        Among("\u03C0\u03BF\u03BB\u03C5\u03BC\u03B7\u03C7", 87, 1, 0),
        Among("\u03BB\u03B9\u03C7", 87, 1, 0)
    ];

    static final a_40 = [
        Among("\u03B5\u03BD\u03B4", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B4", -1, 1, 0),
        Among("\u03BF\u03B4", -1, 1, 0),
        Among("\u03B4\u03B9\u03B1\u03B8", -1, 1, 0),
        Among("\u03BA\u03B1\u03B8", -1, 1, 0),
        Among("\u03C1\u03B1\u03B8", -1, 1, 0),
        Among("\u03C4\u03B1\u03B8", -1, 1, 0),
        Among("\u03C4\u03B9\u03B8", -1, 1, 0),
        Among("\u03B5\u03BA\u03B8", -1, 1, 0),
        Among("\u03B5\u03BD\u03B8", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B8", -1, 1, 0),
        Among("\u03C1\u03BF\u03B8", -1, 1, 0),
        Among("\u03C5\u03C0\u03B5\u03C1\u03B8", -1, 1, 0),
        Among("\u03C3\u03B8", -1, 1, 0),
        Among("\u03B5\u03C5\u03B8", -1, 1, 0),
        Among("\u03B1\u03C1\u03BA", -1, 1, 0),
        Among("\u03C9\u03C6\u03B5\u03BB", -1, 1, 0),
        Among("\u03B2\u03BF\u03BB", -1, 1, 0),
        Among("\u03B1\u03B9\u03BD", -1, 1, 0),
        Among("\u03C0\u03BF\u03BD", -1, 1, 0),
        Among("\u03C1\u03BF\u03BD", -1, 1, 0),
        Among("\u03C3\u03C5\u03BD", -1, 1, 0),
        Among("\u03B2\u03B1\u03C1", -1, 1, 0),
        Among("\u03B2\u03C1", -1, 1, 0),
        Among("\u03B1\u03B9\u03C1", -1, 1, 0),
        Among("\u03C6\u03BF\u03C1", -1, 1, 0),
        Among("\u03B5\u03C5\u03C1", -1, 1, 0),
        Among("\u03C0\u03C5\u03C1", -1, 1, 0),
        Among("\u03C7\u03C9\u03C1", -1, 1, 0),
        Among("\u03BD\u03B5\u03C4", -1, 1, 0),
        Among("\u03C3\u03C7", -1, 1, 0)
    ];

    static final a_41 = [
        Among("\u03C0\u03B1\u03B3", -1, 1, 0),
        Among("\u03B4", -1, 1, 0),
        Among("\u03B1\u03B4", 1, 1, 0),
        Among("\u03B8", -1, 1, 0),
        Among("\u03B1\u03B8", 3, 1, 0),
        Among("\u03C4\u03BF\u03BA", -1, 1, 0),
        Among("\u03C3\u03BA", -1, 1, 0),
        Among("\u03C0\u03B1\u03C1\u03B1\u03BA\u03B1\u03BB", -1, 1, 0),
        Among("\u03C3\u03BA\u03B5\u03BB", -1, 1, 0),
        Among("\u03B1\u03C0\u03BB", -1, 1, 0),
        Among("\u03B5\u03BC", -1, 1, 0),
        Among("\u03B1\u03BD", -1, 1, 0),
        Among("\u03B2\u03B5\u03BD", -1, 1, 0),
        Among("\u03B2\u03B1\u03C1\u03BF\u03BD", -1, 1, 0),
        Among("\u03BA\u03BF\u03C0", -1, 1, 0),
        Among("\u03C3\u03B5\u03C1\u03C0", -1, 1, 0),
        Among("\u03B1\u03B2\u03B1\u03C1", -1, 1, 0),
        Among("\u03B5\u03BD\u03B1\u03C1", -1, 1, 0),
        Among("\u03B1\u03B2\u03C1", -1, 1, 0),
        Among("\u03BC\u03C0\u03BF\u03C1", -1, 1, 0),
        Among("\u03B8\u03B1\u03C1\u03C1", -1, 1, 0),
        Among("\u03BD\u03C4\u03C1", -1, 1, 0),
        Among("\u03C5", -1, 1, 0),
        Among("\u03BD\u03B9\u03C6", -1, 1, 0),
        Among("\u03C3\u03C5\u03C1\u03C6", -1, 1, 0)
    ];

    static final a_42 = [
        Among("\u03BF\u03BD\u03C4\u03B1\u03C3", -1, 1, 0),
        Among("\u03C9\u03BD\u03C4\u03B1\u03C3", -1, 1, 0)
    ];

    static final a_43 = [
        Among("\u03BF\u03BC\u03B1\u03C3\u03C4\u03B5", -1, 1, 0),
        Among("\u03B9\u03BF\u03BC\u03B1\u03C3\u03C4\u03B5", 0, 1, 0)
    ];

    static final a_44 = [
        Among("\u03C0", -1, 1, 0),
        Among("\u03B1\u03C0", 0, 1, 0),
        Among("\u03B1\u03BA\u03B1\u03C4\u03B1\u03C0", 1, 1, 0),
        Among("\u03C3\u03C5\u03BC\u03C0", 0, 1, 0),
        Among("\u03B1\u03C3\u03C5\u03BC\u03C0", 3, 1, 0),
        Among("\u03B1\u03BC\u03B5\u03C4\u03B1\u03BC\u03C6", -1, 1, 0)
    ];

    static final a_45 = [
        Among("\u03B6", -1, 1, 0),
        Among("\u03B1\u03BB", -1, 1, 0),
        Among("\u03C0\u03B1\u03C1\u03B1\u03BA\u03B1\u03BB", 1, 1, 0),
        Among("\u03B5\u03BA\u03C4\u03B5\u03BB", -1, 1, 0),
        Among("\u03BC", -1, 1, 0),
        Among("\u03BE", -1, 1, 0),
        Among("\u03C0\u03C1\u03BF", -1, 1, 0),
        Among("\u03B1\u03C1", -1, 1, 0),
        Among("\u03BD\u03B9\u03C3", -1, 1, 0)
    ];

    static final a_46 = [
        Among("\u03B7\u03B8\u03B7\u03BA\u03B1", -1, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B5", -1, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_47 = [
        Among("\u03C0\u03B9\u03B8", -1, 1, 0),
        Among("\u03BF\u03B8", -1, 1, 0),
        Among("\u03BD\u03B1\u03C1\u03B8", -1, 1, 0),
        Among("\u03C3\u03BA\u03BF\u03C5\u03BB", -1, 1, 0),
        Among("\u03C3\u03BA\u03C9\u03BB", -1, 1, 0),
        Among("\u03C3\u03C6", -1, 1, 0)
    ];

    static final a_48 = [
        Among("\u03B8", -1, 1, 0),
        Among("\u03B4\u03B9\u03B1\u03B8", 0, 1, 0),
        Among("\u03C0\u03B1\u03C1\u03B1\u03BA\u03B1\u03C4\u03B1\u03B8", 0, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03B8", 0, 1, 0),
        Among("\u03C0\u03C1\u03BF\u03C3\u03B8", 0, 1, 0)
    ];

    static final a_49 = [
        Among("\u03B7\u03BA\u03B1", -1, 1, 0),
        Among("\u03B7\u03BA\u03B5", -1, 1, 0),
        Among("\u03B7\u03BA\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_50 = [
        Among("\u03C6\u03B1\u03B3", -1, 1, 0),
        Among("\u03BB\u03B7\u03B3", -1, 1, 0),
        Among("\u03C6\u03C1\u03C5\u03B4", -1, 1, 0),
        Among("\u03BC\u03B1\u03BD\u03C4\u03B9\u03BB", -1, 1, 0),
        Among("\u03BC\u03B1\u03BB\u03BB", -1, 1, 0),
        Among("\u03BF\u03BC", -1, 1, 0),
        Among("\u03B2\u03BB\u03B5\u03C0", -1, 1, 0),
        Among("\u03C0\u03BF\u03B4\u03B1\u03C1", -1, 1, 0),
        Among("\u03BA\u03C5\u03BC\u03B1\u03C4", -1, 1, 0),
        Among("\u03C0\u03C1\u03C9\u03C4", -1, 1, 0),
        Among("\u03BB\u03B1\u03C7", -1, 1, 0),
        Among("\u03C0\u03B1\u03BD\u03C4\u03B1\u03C7", -1, 1, 0)
    ];

    static final a_51 = [
        Among("\u03C4\u03C3\u03B1", -1, 1, 0),
        Among("\u03C7\u03B1\u03B4", -1, 1, 0),
        Among("\u03BC\u03B5\u03B4", -1, 1, 0),
        Among("\u03BB\u03B1\u03BC\u03C0\u03B9\u03B4", -1, 1, 0),
        Among("\u03B4\u03B5", -1, 1, 0),
        Among("\u03C0\u03BB\u03B5", -1, 1, 0),
        Among("\u03BC\u03B5\u03C3\u03B1\u03B6", -1, 1, 0),
        Among("\u03B4\u03B5\u03C3\u03C0\u03BF\u03B6", -1, 1, 0),
        Among("\u03B1\u03B9\u03B8", -1, 1, 0),
        Among("\u03C6\u03B1\u03C1\u03BC\u03B1\u03BA", -1, 1, 0),
        Among("\u03B1\u03B3\u03BA", -1, 1, 0),
        Among("\u03B1\u03BD\u03B7\u03BA", -1, 1, 0),
        Among("\u03BB", -1, 1, 0),
        Among("\u03BC", -1, 1, 0),
        Among("\u03B1\u03BC", 13, 1, 0),
        Among("\u03B2\u03C1\u03BF\u03BC", 13, 1, 0),
        Among("\u03C5\u03C0\u03BF\u03C4\u03B5\u03B9\u03BD", -1, 1, 0),
        Among("\u03B5\u03BA\u03BB\u03B9\u03C0", -1, 1, 0),
        Among("\u03C1", -1, 1, 0),
        Among("\u03B5\u03BD\u03B4\u03B9\u03B1\u03C6\u03B5\u03C1", 18, 1, 0),
        Among("\u03B1\u03BD\u03B1\u03C1\u03C1", 18, 1, 0),
        Among("\u03C0\u03B1\u03C4", -1, 1, 0),
        Among("\u03BA\u03B1\u03B8\u03B1\u03C1\u03B5\u03C5", -1, 1, 0),
        Among("\u03B4\u03B5\u03C5\u03C4\u03B5\u03C1\u03B5\u03C5", -1, 1, 0),
        Among("\u03BB\u03B5\u03C7", -1, 1, 0)
    ];

    static final a_52 = [
        Among("\u03BF\u03C5\u03C3\u03B1", -1, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B5", -1, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_53 = [
        Among("\u03C0\u03B5\u03BB", -1, 1, 0),
        Among("\u03BB\u03BB", -1, 1, 0),
        Among("\u03C3\u03BC\u03B7\u03BD", -1, 1, 0),
        Among("\u03C1\u03C0", -1, 1, 0),
        Among("\u03C0\u03C1", -1, 1, 0),
        Among("\u03C6\u03C1", -1, 1, 0),
        Among("\u03C7\u03BF\u03C1\u03C4", -1, 1, 0),
        Among("\u03BF\u03C6", -1, 1, 0),
        Among("\u03C8\u03BF\u03C6", 7, -1, 0),
        Among("\u03C3\u03C6", -1, 1, 0),
        Among("\u03BB\u03BF\u03C7", -1, 1, 0),
        Among("\u03BD\u03B1\u03C5\u03BB\u03BF\u03C7", 10, -1, 0)
    ];

    static final a_54 = [
        Among("\u03B1\u03BC\u03B1\u03BB\u03BB\u03B9", -1, 1, 0),
        Among("\u03BB", -1, 1, 0),
        Among("\u03B1\u03BC\u03B1\u03BB", 1, 1, 0),
        Among("\u03BC", -1, 1, 0),
        Among("\u03BF\u03C5\u03BB\u03B1\u03BC", 3, 1, 0),
        Among("\u03B5\u03BD", -1, 1, 0),
        Among("\u03B4\u03B5\u03C1\u03B2\u03B5\u03BD", 5, 1, 0),
        Among("\u03C0", -1, 1, 0),
        Among("\u03B1\u03B5\u03B9\u03C0", 7, 1, 0),
        Among("\u03B1\u03C1\u03C4\u03B9\u03C0", 7, 1, 0),
        Among("\u03C3\u03C5\u03BC\u03C0", 7, 1, 0),
        Among("\u03BD\u03B5\u03BF\u03C0", 7, 1, 0),
        Among("\u03BA\u03C1\u03BF\u03BA\u03B1\u03BB\u03BF\u03C0", 7, 1, 0),
        Among("\u03BF\u03BB\u03BF\u03C0", 7, 1, 0),
        Among("\u03C0\u03C1\u03BF\u03C3\u03C9\u03C0\u03BF\u03C0", 7, 1, 0),
        Among("\u03C3\u03B9\u03B4\u03B7\u03C1\u03BF\u03C0", 7, 1, 0),
        Among("\u03B4\u03C1\u03BF\u03C3\u03BF\u03C0", 7, 1, 0),
        Among("\u03B1\u03C3\u03C0", 7, 1, 0),
        Among("\u03B1\u03BD\u03C5\u03C0", 7, 1, 0),
        Among("\u03C1", -1, 1, 0),
        Among("\u03B1\u03C3\u03C0\u03B1\u03C1", 19, 1, 0),
        Among("\u03C7\u03B1\u03C1", 19, 1, 0),
        Among("\u03B1\u03C7\u03B1\u03C1", 21, 1, 0),
        Among("\u03B1\u03C0\u03B5\u03C1", 19, 1, 0),
        Among("\u03C4\u03C1", 19, 1, 0),
        Among("\u03BF\u03C5\u03C1", 19, 1, 0),
        Among("\u03C4", -1, 1, 0),
        Among("\u03B4\u03B9\u03B1\u03C4", 26, 1, 0),
        Among("\u03B5\u03C0\u03B9\u03C4", 26, 1, 0),
        Among("\u03C3\u03C5\u03BD\u03C4", 26, 1, 0),
        Among("\u03BF\u03BC\u03BF\u03C4", 26, 1, 0),
        Among("\u03BD\u03BF\u03BC\u03BF\u03C4", 30, 1, 0),
        Among("\u03B1\u03C0\u03BF\u03C4", 26, 1, 0),
        Among("\u03C5\u03C0\u03BF\u03C4", 26, 1, 0),
        Among("\u03B1\u03B2\u03B1\u03C3\u03C4", 26, 1, 0),
        Among("\u03B1\u03B9\u03BC\u03BF\u03C3\u03C4", 26, 1, 0),
        Among("\u03C0\u03C1\u03BF\u03C3\u03C4", 26, 1, 0),
        Among("\u03B1\u03BD\u03C5\u03C3\u03C4", 26, 1, 0),
        Among("\u03BD\u03B1\u03C5", -1, 1, 0),
        Among("\u03B1\u03C6", -1, 1, 0),
        Among("\u03BE\u03B5\u03C6", -1, 1, 0),
        Among("\u03B1\u03B4\u03B7\u03C6", -1, 1, 0),
        Among("\u03C0\u03B1\u03BC\u03C6", -1, 1, 0),
        Among("\u03C0\u03BF\u03BB\u03C5\u03C6", -1, 1, 0)
    ];

    static final a_55 = [
        Among("\u03B1\u03B3\u03B1", -1, 1, 0),
        Among("\u03B1\u03B3\u03B5", -1, 1, 0),
        Among("\u03B1\u03B3\u03B5\u03C3", -1, 1, 0)
    ];

    static final a_56 = [
        Among("\u03B7\u03C3\u03B1", -1, 1, 0),
        Among("\u03B7\u03C3\u03B5", -1, 1, 0),
        Among("\u03B7\u03C3\u03BF\u03C5", -1, 1, 0)
    ];

    static final a_57 = [
        Among("\u03BD", -1, 1, 0),
        Among("\u03B4\u03C9\u03B4\u03B5\u03BA\u03B1\u03BD", 0, 1, 0),
        Among("\u03B5\u03C0\u03C4\u03B1\u03BD", 0, 1, 0),
        Among("\u03BC\u03B5\u03B3\u03B1\u03BB\u03BF\u03BD", 0, 1, 0),
        Among("\u03B5\u03C1\u03B7\u03BC\u03BF\u03BD", 0, 1, 0),
        Among("\u03C7\u03B5\u03C1\u03C3\u03BF\u03BD", 0, 1, 0)
    ];

    static final a_58 = [
        Among("\u03C3\u03B2", -1, 1, 0),
        Among("\u03B1\u03C3\u03B2", 0, 1, 0),
        Among("\u03B1\u03C0\u03BB", -1, 1, 0),
        Among("\u03B1\u03B5\u03B9\u03BC\u03BD", -1, 1, 0),
        Among("\u03C7\u03C1", -1, 1, 0),
        Among("\u03B1\u03C7\u03C1", 4, 1, 0),
        Among("\u03BA\u03BF\u03B9\u03BD\u03BF\u03C7\u03C1", 4, 1, 0),
        Among("\u03B4\u03C5\u03C3\u03C7\u03C1", 4, 1, 0),
        Among("\u03B5\u03C5\u03C7\u03C1", 4, 1, 0),
        Among("\u03C0\u03B1\u03BB\u03B9\u03BC\u03C8", -1, 1, 0)
    ];

    static final a_59 = [
        Among("\u03BF\u03C5\u03BD\u03B5", -1, 1, 0),
        Among("\u03B7\u03B8\u03BF\u03C5\u03BD\u03B5", 0, 1, 0),
        Among("\u03B7\u03C3\u03BF\u03C5\u03BD\u03B5", 0, 1, 0)
    ];

    static final a_60 = [
        Among("\u03C3\u03C0\u03B9", -1, 1, 0),
        Among("\u03BD", -1, 1, 0),
        Among("\u03B5\u03BE\u03C9\u03BD", 1, 1, 0),
        Among("\u03C1", -1, 1, 0),
        Among("\u03C3\u03C4\u03C1\u03B1\u03B2\u03BF\u03BC\u03BF\u03C5\u03C4\u03C3", -1, 1, 0),
        Among("\u03BA\u03B1\u03BA\u03BF\u03BC\u03BF\u03C5\u03C4\u03C3", -1, 1, 0)
    ];

    static final a_61 = [
        Among("\u03BF\u03C5\u03BC\u03B5", -1, 1, 0),
        Among("\u03B7\u03B8\u03BF\u03C5\u03BC\u03B5", 0, 1, 0),
        Among("\u03B7\u03C3\u03BF\u03C5\u03BC\u03B5", 0, 1, 0)
    ];

    static final a_62 = [
        Among("\u03B1\u03B6", -1, 1, 0),
        Among("\u03C9\u03C1\u03B9\u03BF\u03C0\u03BB", -1, 1, 0),
        Among("\u03B1\u03C3\u03BF\u03C5\u03C3", -1, 1, 0),
        Among("\u03C0\u03B1\u03C1\u03B1\u03C3\u03BF\u03C5\u03C3", 2, 1, 0),
        Among("\u03B1\u03BB\u03BB\u03BF\u03C3\u03BF\u03C5\u03C3", -1, 1, 0),
        Among("\u03C6", -1, 1, 0),
        Among("\u03C7", -1, 1, 0)
    ];

    static final a_63 = [
        Among("\u03BC\u03B1\u03C4\u03B1", -1, 1, 0),
        Among("\u03BC\u03B1\u03C4\u03C9\u03BD", -1, 1, 0),
        Among("\u03BC\u03B1\u03C4\u03BF\u03C3", -1, 1, 0)
    ];

    static final a_64 = [
        Among("\u03B1", -1, 1, 0),
        Among("\u03B9\u03BF\u03C5\u03BC\u03B1", 0, 1, 0),
        Among("\u03BF\u03BC\u03BF\u03C5\u03BD\u03B1", 0, 1, 0),
        Among("\u03B9\u03BF\u03BC\u03BF\u03C5\u03BD\u03B1", 2, 1, 0),
        Among("\u03BF\u03C3\u03BF\u03C5\u03BD\u03B1", 0, 1, 0),
        Among("\u03B9\u03BF\u03C3\u03BF\u03C5\u03BD\u03B1", 4, 1, 0),
        Among("\u03B5", -1, 1, 0),
        Among("\u03B1\u03B3\u03B1\u03C4\u03B5", 6, 1, 0),
        Among("\u03B7\u03BA\u03B1\u03C4\u03B5", 6, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03C4\u03B5", 8, 1, 0),
        Among("\u03B7\u03C3\u03B1\u03C4\u03B5", 6, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B1\u03C4\u03B5", 6, 1, 0),
        Among("\u03B5\u03B9\u03C4\u03B5", 6, 1, 0),
        Among("\u03B7\u03B8\u03B5\u03B9\u03C4\u03B5", 12, 1, 0),
        Among("\u03B9\u03B5\u03BC\u03B1\u03C3\u03C4\u03B5", 6, 1, 0),
        Among("\u03BF\u03C5\u03BC\u03B1\u03C3\u03C4\u03B5", 6, 1, 0),
        Among("\u03B9\u03BF\u03C5\u03BC\u03B1\u03C3\u03C4\u03B5", 15, 1, 0),
        Among("\u03B9\u03B5\u03C3\u03B1\u03C3\u03C4\u03B5", 6, 1, 0),
        Among("\u03BF\u03C3\u03B1\u03C3\u03C4\u03B5", 6, 1, 0),
        Among("\u03B9\u03BF\u03C3\u03B1\u03C3\u03C4\u03B5", 18, 1, 0),
        Among("\u03B7", -1, 1, 0),
        Among("\u03B9", -1, 1, 0),
        Among("\u03B1\u03BC\u03B1\u03B9", 21, 1, 0),
        Among("\u03B9\u03B5\u03BC\u03B1\u03B9", 21, 1, 0),
        Among("\u03BF\u03BC\u03B1\u03B9", 21, 1, 0),
        Among("\u03BF\u03C5\u03BC\u03B1\u03B9", 21, 1, 0),
        Among("\u03B1\u03C3\u03B1\u03B9", 21, 1, 0),
        Among("\u03B5\u03C3\u03B1\u03B9", 21, 1, 0),
        Among("\u03B9\u03B5\u03C3\u03B1\u03B9", 27, 1, 0),
        Among("\u03B1\u03C4\u03B1\u03B9", 21, 1, 0),
        Among("\u03B5\u03C4\u03B1\u03B9", 21, 1, 0),
        Among("\u03B9\u03B5\u03C4\u03B1\u03B9", 30, 1, 0),
        Among("\u03BF\u03BD\u03C4\u03B1\u03B9", 21, 1, 0),
        Among("\u03BF\u03C5\u03BD\u03C4\u03B1\u03B9", 21, 1, 0),
        Among("\u03B9\u03BF\u03C5\u03BD\u03C4\u03B1\u03B9", 33, 1, 0),
        Among("\u03B5\u03B9", 21, 1, 0),
        Among("\u03B1\u03B5\u03B9", 35, 1, 0),
        Among("\u03B7\u03B8\u03B5\u03B9", 35, 1, 0),
        Among("\u03B7\u03C3\u03B5\u03B9", 35, 1, 0),
        Among("\u03BF\u03B9", 21, 1, 0),
        Among("\u03B1\u03BD", -1, 1, 0),
        Among("\u03B1\u03B3\u03B1\u03BD", 40, 1, 0),
        Among("\u03B7\u03BA\u03B1\u03BD", 40, 1, 0),
        Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03BD", 42, 1, 0),
        Among("\u03B7\u03C3\u03B1\u03BD", 40, 1, 0),
        Among("\u03BF\u03C5\u03C3\u03B1\u03BD", 40, 1, 0),
        Among("\u03BF\u03BD\u03C4\u03BF\u03C5\u03C3\u03B1\u03BD", 45, 1, 0),
        Among("\u03B9\u03BF\u03BD\u03C4\u03BF\u03C5\u03C3\u03B1\u03BD", 46, 1, 0),
        Among("\u03BF\u03BD\u03C4\u03B1\u03BD", 40, 1, 0),
        Among("\u03B9\u03BF\u03BD\u03C4\u03B1\u03BD", 48, 1, 0),
        Among("\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD", 40, 1, 0),
        Among("\u03B9\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD", 50, 1, 0),
        Among("\u03BF\u03C4\u03B1\u03BD", 40, 1, 0),
        Among("\u03B9\u03BF\u03C4\u03B1\u03BD", 52, 1, 0),
        Among("\u03BF\u03BC\u03B1\u03C3\u03C4\u03B1\u03BD", 40, 1, 0),
        Among("\u03B9\u03BF\u03BC\u03B1\u03C3\u03C4\u03B1\u03BD", 54, 1, 0),
        Among("\u03BF\u03C3\u03B1\u03C3\u03C4\u03B1\u03BD", 40, 1, 0),
        Among("\u03B9\u03BF\u03C3\u03B1\u03C3\u03C4\u03B1\u03BD", 56, 1, 0),
        Among("\u03BF\u03C5\u03BD", -1, 1, 0),
        Among("\u03B7\u03B8\u03BF\u03C5\u03BD", 58, 1, 0),
        Among("\u03BF\u03BC\u03BF\u03C5\u03BD", 58, 1, 0),
        Among("\u03B9\u03BF\u03BC\u03BF\u03C5\u03BD", 60, 1, 0),
        Among("\u03B7\u03C3\u03BF\u03C5\u03BD", 58, 1, 0),
        Among("\u03BF\u03C3\u03BF\u03C5\u03BD", 58, 1, 0),
        Among("\u03B9\u03BF\u03C3\u03BF\u03C5\u03BD", 63, 1, 0),
        Among("\u03C9\u03BD", -1, 1, 0),
        Among("\u03B7\u03B4\u03C9\u03BD", 65, 1, 0),
        Among("\u03BF", -1, 1, 0),
        Among("\u03B1\u03C3", -1, 1, 0),
        Among("\u03B5\u03C3", -1, 1, 0),
        Among("\u03B7\u03B4\u03B5\u03C3", 69, 1, 0),
        Among("\u03B7\u03C3\u03B5\u03C3", 69, 1, 0),
        Among("\u03B7\u03C3", -1, 1, 0),
        Among("\u03B5\u03B9\u03C3", -1, 1, 0),
        Among("\u03B7\u03B8\u03B5\u03B9\u03C3", 73, 1, 0),
        Among("\u03BF\u03C3", -1, 1, 0),
        Among("\u03C5\u03C3", -1, 1, 0),
        Among("\u03BF\u03C5\u03C3", 76, 1, 0),
        Among("\u03C5", -1, 1, 0),
        Among("\u03BF\u03C5", 78, 1, 0),
        Among("\u03C9", -1, 1, 0),
        Among("\u03B1\u03C9", 80, 1, 0),
        Among("\u03B7\u03B8\u03C9", 80, 1, 0),
        Among("\u03B7\u03C3\u03C9", 80, 1, 0)
    ];

    static final a_65 = [
        Among("\u03BF\u03C4\u03B5\u03C1", -1, 1, 0),
        Among("\u03B5\u03C3\u03C4\u03B5\u03C1", -1, 1, 0),
        Among("\u03C5\u03C4\u03B5\u03C1", -1, 1, 0),
        Among("\u03C9\u03C4\u03B5\u03C1", -1, 1, 0),
        Among("\u03BF\u03C4\u03B1\u03C4", -1, 1, 0),
        Among("\u03B5\u03C3\u03C4\u03B1\u03C4", -1, 1, 0),
        Among("\u03C5\u03C4\u03B1\u03C4", -1, 1, 0),
        Among("\u03C9\u03C4\u03B1\u03C4", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([81, 65, 16, 1]);

    static final g_v2 = String.fromCharCodes([81, 65, 0, 1]);


    @override
    bool stem() {
        int among_var;
        bool B_test1;
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = limit - cursor;
                lab2: while (true) {
                    ket = cursor;
                    among_var = find_among_b(a_0, null);
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("\u03B1");
                            break;
                        case 2:
                            slice_from("\u03B2");
                            break;
                        case 3:
                            slice_from("\u03B3");
                            break;
                        case 4:
                            slice_from("\u03B4");
                            break;
                        case 5:
                            slice_from("\u03B5");
                            break;
                        case 6:
                            slice_from("\u03B6");
                            break;
                        case 7:
                            slice_from("\u03B7");
                            break;
                        case 8:
                            slice_from("\u03B8");
                            break;
                        case 9:
                            slice_from("\u03B9");
                            break;
                        case 10:
                            slice_from("\u03BA");
                            break;
                        case 11:
                            slice_from("\u03BB");
                            break;
                        case 12:
                            slice_from("\u03BC");
                            break;
                        case 13:
                            slice_from("\u03BD");
                            break;
                        case 14:
                            slice_from("\u03BE");
                            break;
                        case 15:
                            slice_from("\u03BF");
                            break;
                        case 16:
                            slice_from("\u03C0");
                            break;
                        case 17:
                            slice_from("\u03C1");
                            break;
                        case 18:
                            slice_from("\u03C3");
                            break;
                        case 19:
                            slice_from("\u03C4");
                            break;
                        case 20:
                            slice_from("\u03C5");
                            break;
                        case 21:
                            slice_from("\u03C6");
                            break;
                        case 22:
                            slice_from("\u03C7");
                            break;
                        case 23:
                            slice_from("\u03C8");
                            break;
                        case 24:
                            slice_from("\u03C9");
                            break;
                        case 25:
                            if (cursor <= limit_backward)
                            {
                                break lab2;
                            }
                            cursor--;
                            break;
                    }
                    continue replab1;
                }
                cursor = limit - v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = limit - v_1;
        if (current.length < 3)
        {
            return false;
        }
        B_test1 = true;
        int v_3 = limit - cursor;
        lab3: while (true) {
            ket = cursor;
            among_var = find_among_b(a_1, null);
            if (among_var == 0)
            {
                break lab3;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_from("\u03C6\u03B1");
                    break;
                case 2:
                    slice_from("\u03C3\u03BA\u03B1");
                    break;
                case 3:
                    slice_from("\u03BF\u03BB\u03BF");
                    break;
                case 4:
                    slice_from("\u03C3\u03BF");
                    break;
                case 5:
                    slice_from("\u03C4\u03B1\u03C4\u03BF");
                    break;
                case 6:
                    slice_from("\u03BA\u03C1\u03B5");
                    break;
                case 7:
                    slice_from("\u03C0\u03B5\u03C1");
                    break;
                case 8:
                    slice_from("\u03C4\u03B5\u03C1");
                    break;
                case 9:
                    slice_from("\u03C6\u03C9");
                    break;
                case 10:
                    slice_from("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4");
                    break;
                case 11:
                    slice_from("\u03B3\u03B5\u03B3\u03BF\u03BD");
                    break;
            }
            B_test1 = false;
            break lab3;
        }
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        lab4: while (true) {
            ket = cursor;
            if (find_among_b(a_3, null) == 0)
            {
                break lab4;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            among_var = find_among_b(a_2, null);
            if (among_var == 0)
            {
                break lab4;
            }
            if (cursor > limit_backward)
            {
                break lab4;
            }
            switch (among_var) {
                case 1:
                    slice_from("\u03B9");
                    break;
                case 2:
                    slice_from("\u03B9\u03B6");
                    break;
            }
            break lab4;
        }
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        lab5: while (true) {
            ket = cursor;
            if (find_among_b(a_5, null) == 0)
            {
                break lab5;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_4, null) == 0)
            {
                break lab5;
            }
            if (cursor > limit_backward)
            {
                break lab5;
            }
            slice_from("\u03C9\u03BD");
            break lab5;
        }
        cursor = limit - v_5;
        int v_6 = limit - cursor;
        lab6: while (true) {
            lab7: while (true) {
                int v_7 = limit - cursor;
                lab8: while (true) {
                    ket = cursor;
                    if (!(eq_s_b("\u03B9\u03C3\u03B1")))
                    {
                        break lab8;
                    }
                    bra = cursor;
                    if (cursor > limit_backward)
                    {
                        break lab8;
                    }
                    slice_from("\u03B9\u03C3");
                    break lab7;
                }
                cursor = limit - v_7;
                ket = cursor;
                break lab7;
            }
            if (find_among_b(a_7, null) == 0)
            {
                break lab6;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            among_var = find_among_b(a_6, null);
            if (among_var == 0)
            {
                break lab6;
            }
            if (cursor > limit_backward)
            {
                break lab6;
            }
            switch (among_var) {
                case 1:
                    slice_from("\u03B9");
                    break;
                case 2:
                    slice_from("\u03B9\u03C3");
                    break;
            }
            break lab6;
        }
        cursor = limit - v_6;
        int v_8 = limit - cursor;
        lab9: while (true) {
            ket = cursor;
            if (find_among_b(a_9, null) == 0)
            {
                break lab9;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_8, null) == 0)
            {
                break lab9;
            }
            if (cursor > limit_backward)
            {
                break lab9;
            }
            slice_from("\u03B9");
            break lab9;
        }
        cursor = limit - v_8;
        int v_9 = limit - cursor;
        lab10: while (true) {
            ket = cursor;
            if (find_among_b(a_11, null) == 0)
            {
                break lab10;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            among_var = find_among_b(a_10, null);
            if (among_var == 0)
            {
                break lab10;
            }
            if (cursor > limit_backward)
            {
                break lab10;
            }
            switch (among_var) {
                case 1:
                    slice_from("\u03B9");
                    break;
                case 2:
                    slice_from("\u03B9\u03C3\u03C4");
                    break;
            }
            break lab10;
        }
        cursor = limit - v_9;
        int v_10 = limit - cursor;
        lab11: while (true) {
            ket = cursor;
            if (find_among_b(a_14, null) == 0)
            {
                break lab11;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab12: while (true) {
                int v_11 = limit - cursor;
                lab13: while (true) {
                    ket = cursor;
                    bra = cursor;
                    among_var = find_among_b(a_12, null);
                    if (among_var == 0)
                    {
                        break lab13;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab13;
                    }
                    switch (among_var) {
                        case 1:
                            slice_from("\u03B9\u03C3\u03BC");
                            break;
                        case 2:
                            slice_from("\u03B9");
                            break;
                    }
                    break lab12;
                }
                cursor = limit - v_11;
                ket = cursor;
                among_var = find_among_b(a_13, null);
                if (among_var == 0)
                {
                    break lab11;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("\u03B1\u03B3\u03BD\u03C9\u03C3\u03C4");
                        break;
                    case 2:
                        slice_from("\u03B1\u03C4\u03BF\u03BC");
                        break;
                    case 3:
                        slice_from("\u03B3\u03BD\u03C9\u03C3\u03C4");
                        break;
                    case 4:
                        slice_from("\u03B5\u03B8\u03BD");
                        break;
                    case 5:
                        slice_from("\u03B5\u03BA\u03BB\u03B5\u03BA\u03C4");
                        break;
                    case 6:
                        slice_from("\u03C3\u03BA\u03B5\u03C0\u03C4");
                        break;
                    case 7:
                        slice_from("\u03C4\u03BF\u03C0");
                        break;
                    case 8:
                        slice_from("\u03B1\u03BB\u03B5\u03BE\u03B1\u03BD\u03B4\u03C1");
                        break;
                    case 9:
                        slice_from("\u03B2\u03C5\u03B6\u03B1\u03BD\u03C4");
                        break;
                    case 10:
                        slice_from("\u03B8\u03B5\u03B1\u03C4\u03C1");
                        break;
                }
                break lab12;
            }
            break lab11;
        }
        cursor = limit - v_10;
        int v_12 = limit - cursor;
        lab14: while (true) {
            ket = cursor;
            if (find_among_b(a_16, null) == 0)
            {
                break lab14;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_15, null) == 0)
            {
                break lab14;
            }
            if (cursor > limit_backward)
            {
                break lab14;
            }
            slice_from("\u03B1\u03C1\u03B1\u03BA");
            break lab14;
        }
        cursor = limit - v_12;
        int v_13 = limit - cursor;
        lab15: while (true) {
            ket = cursor;
            if (find_among_b(a_18, null) == 0)
            {
                break lab15;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab16: while (true) {
                int v_14 = limit - cursor;
                lab17: while (true) {
                    ket = cursor;
                    bra = cursor;
                    among_var = find_among_b(a_17, null);
                    if (among_var == 0)
                    {
                        break lab17;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab17;
                    }
                    switch (among_var) {
                        case 1:
                            slice_from("\u03B1\u03BA");
                            break;
                        case 2:
                            slice_from("\u03B9\u03C4\u03C3");
                            break;
                    }
                    break lab16;
                }
                cursor = limit - v_14;
                ket = cursor;
                bra = cursor;
                if (!(eq_s_b("\u03BA\u03BF\u03C1")))
                {
                    break lab15;
                }
                slice_from("\u03B9\u03C4\u03C3");
                break lab16;
            }
            break lab15;
        }
        cursor = limit - v_13;
        int v_15 = limit - cursor;
        lab18: while (true) {
            ket = cursor;
            if (find_among_b(a_21, null) == 0)
            {
                break lab18;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab19: while (true) {
                int v_16 = limit - cursor;
                lab20: while (true) {
                    ket = cursor;
                    bra = cursor;
                    if (find_among_b(a_19, null) == 0)
                    {
                        break lab20;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab20;
                    }
                    slice_from("\u03B9\u03B4");
                    break lab19;
                }
                cursor = limit - v_16;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_20, null) == 0)
                {
                    break lab18;
                }
                slice_from("\u03B9\u03B4");
                break lab19;
            }
            break lab18;
        }
        cursor = limit - v_15;
        int v_17 = limit - cursor;
        lab21: while (true) {
            ket = cursor;
            if (find_among_b(a_23, null) == 0)
            {
                break lab21;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_22, null) == 0)
            {
                break lab21;
            }
            if (cursor > limit_backward)
            {
                break lab21;
            }
            slice_from("\u03B9\u03C3\u03BA");
            break lab21;
        }
        cursor = limit - v_17;
        int v_18 = limit - cursor;
        lab22: while (true) {
            ket = cursor;
            if (find_among_b(a_24, null) == 0)
            {
                break lab22;
            }
            bra = cursor;
            slice_del();
            {
                int v_19 = limit - cursor;
                lab23: while (true) {
                    if (find_among_b(a_25, null) == 0)
                    {
                        break lab23;
                    }
                    break lab22;
                }
                cursor = limit - v_19;
            }
            {
                int c = cursor;
                insert(cursor, cursor, "\u03B1\u03B4");
                cursor = c;
            }
            break lab22;
        }
        cursor = limit - v_18;
        int v_20 = limit - cursor;
        lab24: while (true) {
            ket = cursor;
            if (find_among_b(a_26, null) == 0)
            {
                break lab24;
            }
            bra = cursor;
            slice_del();
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_27, null) == 0)
            {
                break lab24;
            }
            slice_from("\u03B5\u03B4");
            break lab24;
        }
        cursor = limit - v_20;
        int v_21 = limit - cursor;
        lab25: while (true) {
            ket = cursor;
            if (find_among_b(a_28, null) == 0)
            {
                break lab25;
            }
            bra = cursor;
            slice_del();
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_29, null) == 0)
            {
                break lab25;
            }
            slice_from("\u03BF\u03C5\u03B4");
            break lab25;
        }
        cursor = limit - v_21;
        int v_22 = limit - cursor;
        lab26: while (true) {
            ket = cursor;
            if (find_among_b(a_30, null) == 0)
            {
                break lab26;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_31, null) == 0)
            {
                break lab26;
            }
            if (cursor > limit_backward)
            {
                break lab26;
            }
            slice_from("\u03B5");
            break lab26;
        }
        cursor = limit - v_22;
        int v_23 = limit - cursor;
        lab27: while (true) {
            ket = cursor;
            if (find_among_b(a_32, null) == 0)
            {
                break lab27;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (!(in_grouping_b(g_v, 945, 969)))
            {
                break lab27;
            }
            slice_from("\u03B9");
            break lab27;
        }
        cursor = limit - v_23;
        int v_24 = limit - cursor;
        lab28: while (true) {
            ket = cursor;
            if (find_among_b(a_33, null) == 0)
            {
                break lab28;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab29: while (true) {
                int v_25 = limit - cursor;
                lab30: while (true) {
                    ket = cursor;
                    bra = cursor;
                    if (!(in_grouping_b(g_v, 945, 969)))
                    {
                        break lab30;
                    }
                    slice_from("\u03B9\u03BA");
                    break lab29;
                }
                cursor = limit - v_25;
                ket = cursor;
                break lab29;
            }
            bra = cursor;
            if (find_among_b(a_34, null) == 0)
            {
                break lab28;
            }
            if (cursor > limit_backward)
            {
                break lab28;
            }
            slice_from("\u03B9\u03BA");
            break lab28;
        }
        cursor = limit - v_24;
        int v_26 = limit - cursor;
        lab31: while (true) {
            int v_27 = limit - cursor;
            lab32: while (true) {
                ket = cursor;
                if (!(eq_s_b("\u03B1\u03B3\u03B1\u03BC\u03B5")))
                {
                    break lab32;
                }
                bra = cursor;
                if (cursor > limit_backward)
                {
                    break lab32;
                }
                slice_from("\u03B1\u03B3\u03B1\u03BC");
                break lab32;
            }
            cursor = limit - v_27;
            int v_28 = limit - cursor;
            lab33: while (true) {
                ket = cursor;
                if (find_among_b(a_35, null) == 0)
                {
                    break lab33;
                }
                bra = cursor;
                slice_del();
                B_test1 = false;
                break lab33;
            }
            cursor = limit - v_28;
            ket = cursor;
            if (!(eq_s_b("\u03B1\u03BC\u03B5")))
            {
                break lab31;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_36, null) == 0)
            {
                break lab31;
            }
            if (cursor > limit_backward)
            {
                break lab31;
            }
            slice_from("\u03B1\u03BC");
            break lab31;
        }
        cursor = limit - v_26;
        int v_29 = limit - cursor;
        lab34: while (true) {
            int v_30 = limit - cursor;
            lab35: while (true) {
                ket = cursor;
                if (find_among_b(a_38, null) == 0)
                {
                    break lab35;
                }
                bra = cursor;
                slice_del();
                B_test1 = false;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_37, null) == 0)
                {
                    break lab35;
                }
                if (cursor > limit_backward)
                {
                    break lab35;
                }
                slice_from("\u03B1\u03B3\u03B1\u03BD");
                break lab35;
            }
            cursor = limit - v_30;
            ket = cursor;
            if (!(eq_s_b("\u03B1\u03BD\u03B5")))
            {
                break lab34;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab36: while (true) {
                int v_31 = limit - cursor;
                lab37: while (true) {
                    ket = cursor;
                    bra = cursor;
                    if (!(in_grouping_b(g_v2, 945, 969)))
                    {
                        break lab37;
                    }
                    slice_from("\u03B1\u03BD");
                    break lab36;
                }
                cursor = limit - v_31;
                ket = cursor;
                break lab36;
            }
            bra = cursor;
            if (find_among_b(a_39, null) == 0)
            {
                break lab34;
            }
            if (cursor > limit_backward)
            {
                break lab34;
            }
            slice_from("\u03B1\u03BD");
            break lab34;
        }
        cursor = limit - v_29;
        int v_32 = limit - cursor;
        lab38: while (true) {
            int v_33 = limit - cursor;
            lab39: while (true) {
                ket = cursor;
                if (!(eq_s_b("\u03B7\u03C3\u03B5\u03C4\u03B5")))
                {
                    break lab39;
                }
                bra = cursor;
                slice_del();
                B_test1 = false;
                break lab39;
            }
            cursor = limit - v_33;
            ket = cursor;
            if (!(eq_s_b("\u03B5\u03C4\u03B5")))
            {
                break lab38;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab40: while (true) {
                int v_34 = limit - cursor;
                lab41: while (true) {
                    ket = cursor;
                    bra = cursor;
                    if (!(in_grouping_b(g_v2, 945, 969)))
                    {
                        break lab41;
                    }
                    slice_from("\u03B5\u03C4");
                    break lab40;
                }
                cursor = limit - v_34;
                lab42: while (true) {
                    ket = cursor;
                    bra = cursor;
                    if (find_among_b(a_40, null) == 0)
                    {
                        break lab42;
                    }
                    slice_from("\u03B5\u03C4");
                    break lab40;
                }
                cursor = limit - v_34;
                ket = cursor;
                break lab40;
            }
            bra = cursor;
            if (find_among_b(a_41, null) == 0)
            {
                break lab38;
            }
            if (cursor > limit_backward)
            {
                break lab38;
            }
            slice_from("\u03B5\u03C4");
            break lab38;
        }
        cursor = limit - v_32;
        int v_35 = limit - cursor;
        lab43: while (true) {
            ket = cursor;
            if (find_among_b(a_42, null) == 0)
            {
                break lab43;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab44: while (true) {
                int v_36 = limit - cursor;
                lab45: while (true) {
                    ket = cursor;
                    bra = cursor;
                    if (!(eq_s_b("\u03B1\u03C1\u03C7")))
                    {
                        break lab45;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab45;
                    }
                    slice_from("\u03BF\u03BD\u03C4");
                    break lab44;
                }
                cursor = limit - v_36;
                ket = cursor;
                bra = cursor;
                if (!(eq_s_b("\u03BA\u03C1\u03B5")))
                {
                    break lab43;
                }
                slice_from("\u03C9\u03BD\u03C4");
                break lab44;
            }
            break lab43;
        }
        cursor = limit - v_35;
        int v_37 = limit - cursor;
        lab46: while (true) {
            ket = cursor;
            if (find_among_b(a_43, null) == 0)
            {
                break lab46;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (!(eq_s_b("\u03BF\u03BD")))
            {
                break lab46;
            }
            if (cursor > limit_backward)
            {
                break lab46;
            }
            slice_from("\u03BF\u03BC\u03B1\u03C3\u03C4");
            break lab46;
        }
        cursor = limit - v_37;
        int v_38 = limit - cursor;
        lab47: while (true) {
            int v_39 = limit - cursor;
            lab48: while (true) {
                ket = cursor;
                if (!(eq_s_b("\u03B9\u03B5\u03C3\u03C4\u03B5")))
                {
                    break lab48;
                }
                bra = cursor;
                slice_del();
                B_test1 = false;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_44, null) == 0)
                {
                    break lab48;
                }
                if (cursor > limit_backward)
                {
                    break lab48;
                }
                slice_from("\u03B9\u03B5\u03C3\u03C4");
                break lab48;
            }
            cursor = limit - v_39;
            ket = cursor;
            if (!(eq_s_b("\u03B5\u03C3\u03C4\u03B5")))
            {
                break lab47;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_45, null) == 0)
            {
                break lab47;
            }
            if (cursor > limit_backward)
            {
                break lab47;
            }
            slice_from("\u03B9\u03B5\u03C3\u03C4");
            break lab47;
        }
        cursor = limit - v_38;
        int v_40 = limit - cursor;
        lab49: while (true) {
            int v_41 = limit - cursor;
            lab50: while (true) {
                ket = cursor;
                if (find_among_b(a_46, null) == 0)
                {
                    break lab50;
                }
                bra = cursor;
                slice_del();
                B_test1 = false;
                break lab50;
            }
            cursor = limit - v_41;
            ket = cursor;
            if (find_among_b(a_49, null) == 0)
            {
                break lab49;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab51: while (true) {
                int v_42 = limit - cursor;
                lab52: while (true) {
                    ket = cursor;
                    bra = cursor;
                    if (find_among_b(a_47, null) == 0)
                    {
                        break lab52;
                    }
                    slice_from("\u03B7\u03BA");
                    break lab51;
                }
                cursor = limit - v_42;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_48, null) == 0)
                {
                    break lab49;
                }
                if (cursor > limit_backward)
                {
                    break lab49;
                }
                slice_from("\u03B7\u03BA");
                break lab51;
            }
            break lab49;
        }
        cursor = limit - v_40;
        int v_43 = limit - cursor;
        lab53: while (true) {
            ket = cursor;
            if (find_among_b(a_52, null) == 0)
            {
                break lab53;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab54: while (true) {
                int v_44 = limit - cursor;
                lab55: while (true) {
                    ket = cursor;
                    bra = cursor;
                    if (find_among_b(a_50, null) == 0)
                    {
                        break lab55;
                    }
                    slice_from("\u03BF\u03C5\u03C3");
                    break lab54;
                }
                cursor = limit - v_44;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_51, null) == 0)
                {
                    break lab53;
                }
                if (cursor > limit_backward)
                {
                    break lab53;
                }
                slice_from("\u03BF\u03C5\u03C3");
                break lab54;
            }
            break lab53;
        }
        cursor = limit - v_43;
        int v_45 = limit - cursor;
        lab56: while (true) {
            ket = cursor;
            if (find_among_b(a_56, null) == 0)
            {
                break lab56;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_57, null) == 0)
            {
                break lab56;
            }
            if (cursor > limit_backward)
            {
                break lab56;
            }
            slice_from("\u03B7\u03C3");
            break lab56;
        }
        cursor = limit - v_45;
        int v_46 = limit - cursor;
        lab57: while (true) {
            ket = cursor;
            if (find_among_b(a_55, null) == 0)
            {
                break lab57;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab58: while (true) {
                int v_47 = limit - cursor;
                lab59: while (true) {
                    ket = cursor;
                    bra = cursor;
                    if (!(eq_s_b("\u03BA\u03BF\u03BB\u03BB")))
                    {
                        break lab59;
                    }
                    slice_from("\u03B1\u03B3");
                    break lab58;
                }
                cursor = limit - v_47;
                lab60: while (true) {
                    int v_48 = limit - cursor;
                    lab61: while (true) {
                        ket = cursor;
                        bra = cursor;
                        among_var = find_among_b(a_53, null);
                        if (among_var == 0)
                        {
                            break lab61;
                        }
                        switch (among_var) {
                            case 1:
                                slice_from("\u03B1\u03B3");
                                break;
                        }
                        break lab60;
                    }
                    cursor = limit - v_48;
                    ket = cursor;
                    bra = cursor;
                    if (find_among_b(a_54, null) == 0)
                    {
                        break lab57;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab57;
                    }
                    slice_from("\u03B1\u03B3");
                    break lab60;
                }
                break lab58;
            }
            break lab57;
        }
        cursor = limit - v_46;
        int v_49 = limit - cursor;
        lab62: while (true) {
            ket = cursor;
            if (!(eq_s_b("\u03B7\u03C3\u03C4\u03B5")))
            {
                break lab62;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_58, null) == 0)
            {
                break lab62;
            }
            if (cursor > limit_backward)
            {
                break lab62;
            }
            slice_from("\u03B7\u03C3\u03C4");
            break lab62;
        }
        cursor = limit - v_49;
        int v_50 = limit - cursor;
        lab63: while (true) {
            ket = cursor;
            if (find_among_b(a_59, null) == 0)
            {
                break lab63;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_60, null) == 0)
            {
                break lab63;
            }
            if (cursor > limit_backward)
            {
                break lab63;
            }
            slice_from("\u03BF\u03C5\u03BD");
            break lab63;
        }
        cursor = limit - v_50;
        int v_51 = limit - cursor;
        lab64: while (true) {
            ket = cursor;
            if (find_among_b(a_61, null) == 0)
            {
                break lab64;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_62, null) == 0)
            {
                break lab64;
            }
            if (cursor > limit_backward)
            {
                break lab64;
            }
            slice_from("\u03BF\u03C5\u03BC");
            break lab64;
        }
        cursor = limit - v_51;
        int v_52 = limit - cursor;
        lab65: while (true) {
            int v_53 = limit - cursor;
            lab66: while (true) {
                ket = cursor;
                if (find_among_b(a_63, null) == 0)
                {
                    break lab66;
                }
                bra = cursor;
                slice_from("\u03BC\u03B1");
                break lab66;
            }
            cursor = limit - v_53;
            if (!B_test1)
            {
                break lab65;
            }
            ket = cursor;
            if (find_among_b(a_64, null) == 0)
            {
                break lab65;
            }
            bra = cursor;
            slice_del();
            break lab65;
        }
        cursor = limit - v_52;
        int v_54 = limit - cursor;
        lab67: while (true) {
            ket = cursor;
            if (find_among_b(a_65, null) == 0)
            {
                break lab67;
            }
            bra = cursor;
            slice_del();
            break lab67;
        }
        cursor = limit - v_54;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is greek_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
