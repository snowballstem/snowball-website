// Generated from swedish.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from swedish.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class swedish_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("fab", -1, -1, 0),
        Among("h", -1, -1, 0),
        Among("pak", -1, -1, 0),
        Among("rak", -1, -1, 0),
        Among("stak", -1, -1, 0),
        Among("kom", -1, -1, 0),
        Among("iet", -1, -1, 0),
        Among("cit", -1, -1, 0),
        Among("dit", -1, -1, 0),
        Among("alit", -1, -1, 0),
        Among("ilit", -1, -1, 0),
        Among("mit", -1, -1, 0),
        Among("nit", -1, -1, 0),
        Among("pit", -1, -1, 0),
        Among("rit", -1, -1, 0),
        Among("sit", -1, -1, 0),
        Among("tit", -1, -1, 0),
        Among("uit", -1, -1, 0),
        Among("ivit", -1, -1, 0),
        Among("kvit", -1, -1, 0),
        Among("xit", -1, -1, 0)
    ];

    static final a_1 = [
        Among("a", -1, 1, 0),
        Among("arna", 0, 1, 0),
        Among("erna", 0, 1, 0),
        Among("heterna", 2, 1, 0),
        Among("orna", 0, 1, 0),
        Among("ad", -1, 1, 0),
        Among("e", -1, 1, 0),
        Among("ade", 6, 1, 0),
        Among("ande", 6, 1, 0),
        Among("arne", 6, 1, 0),
        Among("are", 6, 1, 0),
        Among("aste", 6, 1, 0),
        Among("en", -1, 1, 0),
        Among("anden", 12, 1, 0),
        Among("aren", 12, 1, 0),
        Among("heten", 12, 1, 0),
        Among("ern", -1, 1, 0),
        Among("ar", -1, 1, 0),
        Among("er", -1, 1, 0),
        Among("heter", 18, 1, 0),
        Among("or", -1, 1, 0),
        Among("s", -1, 2, 0),
        Among("as", 21, 1, 0),
        Among("arnas", 22, 1, 0),
        Among("ernas", 22, 1, 0),
        Among("ornas", 22, 1, 0),
        Among("es", 21, 1, 0),
        Among("ades", 26, 1, 0),
        Among("andes", 26, 1, 0),
        Among("ens", 21, 1, 0),
        Among("arens", 29, 1, 0),
        Among("hetens", 29, 1, 0),
        Among("erns", 21, 1, 0),
        Among("at", -1, 1, 0),
        Among("et", -1, 3, 0),
        Among("andet", 34, 1, 0),
        Among("het", 34, 1, 0),
        Among("ast", -1, 1, 0)
    ];

    static final a_2 = [
        Among("dd", -1, -1, 0),
        Among("gd", -1, -1, 0),
        Among("nn", -1, -1, 0),
        Among("dt", -1, -1, 0),
        Among("gt", -1, -1, 0),
        Among("kt", -1, -1, 0),
        Among("tt", -1, -1, 0)
    ];

    static final a_3 = [
        Among("ig", -1, 1, 0),
        Among("lig", 0, 1, 0),
        Among("els", -1, 1, 0),
        Among("fullt", -1, 3, 0),
        Among("\u00F6st", -1, 2, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 32]);

    static final g_s_ending = String.fromCharCodes([119, 127, 149]);

    static final g_ost_ending = String.fromCharCodes([173, 58]);


    bool r_et_condition() {
        int v_1 = limit - cursor;
        if (!(out_grouping_b(g_v, 97, 246)))
        {
            return false;
        }
        if (!(in_grouping_b(g_v, 97, 246)))
        {
            return false;
        }
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor = limit - v_1;
        {
            int v_2 = limit - cursor;
            lab0: while (true) {
                if (find_among_b(a_0, null) == 0)
                {
                    break lab0;
                }
                return false;
            }
            cursor = limit - v_2;
        }
        return true;
    }

    @override
    bool stem() {
        int among_var;
        int I_x;
        int I_p1;
        int v_1 = cursor;
        lab0: while (true) {
            I_p1 = limit;
            int v_2 = cursor;
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab0;
                }
                cursor = c;
            }
            I_x = cursor;
            cursor = v_2;
            if (!go_out_grouping(g_v, 97, 246))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 246))
            {
                break lab0;
            }
            cursor++;
            I_p1 = cursor;
            lab1: while (true) {
                if (I_p1 >= I_x)
                {
                    break lab1;
                }
                I_p1 = I_x;
                break lab1;
            }
            break lab0;
        }
        cursor = v_1;
        limit_backward = cursor;
        cursor = limit;
        int v_3 = limit - cursor;
        lab2: while (true) {
            if (cursor < I_p1)
            {
                break lab2;
            }
            int v_4 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            among_var = find_among_b(a_1, null);
            if (among_var == 0)
            {
                limit_backward = v_4;
                break lab2;
            }
            bra = cursor;
            limit_backward = v_4;
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    lab3: while (true) {
                        int v_5 = limit - cursor;
                        lab4: while (true) {
                            if (!(eq_s_b("et")))
                            {
                                break lab4;
                            }
                            if (!r_et_condition())
                            {
                                break lab4;
                            }
                            bra = cursor;
                            break lab3;
                        }
                        cursor = limit - v_5;
                        if (!(in_grouping_b(g_s_ending, 98, 121)))
                        {
                            break lab2;
                        }
                        break lab3;
                    }
                    slice_del();
                    break;
                case 3:
                    if (!r_et_condition())
                    {
                        break lab2;
                    }
                    slice_del();
                    break;
            }
            break lab2;
        }
        cursor = limit - v_3;
        int v_6 = limit - cursor;
        lab5: while (true) {
            if (cursor < I_p1)
            {
                break lab5;
            }
            int v_7 = limit_backward;
            limit_backward = I_p1;
            int v_8 = limit - cursor;
            if (find_among_b(a_2, null) == 0)
            {
                limit_backward = v_7;
                break lab5;
            }
            cursor = limit - v_8;
            ket = cursor;
            if (cursor <= limit_backward)
            {
                limit_backward = v_7;
                break lab5;
            }
            cursor--;
            bra = cursor;
            slice_del();
            limit_backward = v_7;
            break lab5;
        }
        cursor = limit - v_6;
        int v_9 = limit - cursor;
        lab6: while (true) {
            if (cursor < I_p1)
            {
                break lab6;
            }
            int v_10 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            among_var = find_among_b(a_3, null);
            if (among_var == 0)
            {
                limit_backward = v_10;
                break lab6;
            }
            bra = cursor;
            limit_backward = v_10;
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    if (!(in_grouping_b(g_ost_ending, 105, 118)))
                    {
                        break lab6;
                    }
                    slice_from("\u00F6s");
                    break;
                case 3:
                    slice_from("full");
                    break;
            }
            break lab6;
        }
        cursor = limit - v_9;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is swedish_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
