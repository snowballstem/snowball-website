// Generated from dutch_porter.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from dutch_porter.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class dutch_porter_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 6, 0),
        Among("\u00E1", 0, 1, 0),
        Among("\u00E4", 0, 1, 0),
        Among("\u00E9", 0, 2, 0),
        Among("\u00EB", 0, 2, 0),
        Among("\u00ED", 0, 3, 0),
        Among("\u00EF", 0, 3, 0),
        Among("\u00F3", 0, 4, 0),
        Among("\u00F6", 0, 4, 0),
        Among("\u00FA", 0, 5, 0),
        Among("\u00FC", 0, 5, 0)
    ];

    static final a_1 = [
        Among("", -1, 3, 0),
        Among("I", 0, 2, 0),
        Among("Y", 0, 1, 0)
    ];

    static final a_2 = [
        Among("dd", -1, -1, 0),
        Among("kk", -1, -1, 0),
        Among("tt", -1, -1, 0)
    ];

    static final a_3 = [
        Among("ene", -1, 2, 0),
        Among("se", -1, 3, 0),
        Among("en", -1, 2, 0),
        Among("heden", 2, 1, 0),
        Among("s", -1, 3, 0)
    ];

    static final a_4 = [
        Among("end", -1, 1, 0),
        Among("ig", -1, 2, 0),
        Among("ing", -1, 1, 0),
        Among("lijk", -1, 3, 0),
        Among("baar", -1, 4, 0),
        Among("bar", -1, 5, 0)
    ];

    static final a_5 = [
        Among("aa", -1, -1, 0),
        Among("ee", -1, -1, 0),
        Among("oo", -1, -1, 0),
        Among("uu", -1, -1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128]);

    static final g_v_I = String.fromCharCodes([1, 0, 0, 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128]);

    static final g_v_j = String.fromCharCodes([17, 67, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128]);

    int I_p1 = 0;
    bool B_e_found = false;


    bool r_undouble() {
        int v_1 = limit - cursor;
        if (find_among_b(a_2, null) == 0)
        {
            return false;
        }
        cursor = limit - v_1;
        ket = cursor;
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor--;
        bra = cursor;
        slice_del();
        return true;
    }

    bool r_e_ending() {
        B_e_found = false;
        ket = cursor;
        if (!(eq_s_b("e")))
        {
            return false;
        }
        bra = cursor;
        if (I_p1 > cursor)
        {
            return false;
        }
        int v_1 = limit - cursor;
        if (!(out_grouping_b(g_v, 97, 232)))
        {
            return false;
        }
        cursor = limit - v_1;
        slice_del();
        B_e_found = true;
        return r_undouble();
    }

    bool r_en_ending() {
        if (I_p1 > cursor)
        {
            return false;
        }
        int v_1 = limit - cursor;
        if (!(out_grouping_b(g_v, 97, 232)))
        {
            return false;
        }
        cursor = limit - v_1;
        lab0: while (true) {
            if (!(eq_s_b("gem")))
            {
                break lab0;
            }
            return false;
        }
        slice_del();
        return r_undouble();
    }

    @override
    bool stem() {
        int among_var;
        int I_x;
        int I_p2;
        int v_1 = cursor;
        lab0: while (true) {
            int v_2 = cursor;
            replab1: while(true)
            {
                int v_3 = cursor;
                lab2: while (true) {
                    bra = cursor;
                    among_var = find_among(a_0, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("a");
                            break;
                        case 2:
                            slice_from("e");
                            break;
                        case 3:
                            slice_from("i");
                            break;
                        case 4:
                            slice_from("o");
                            break;
                        case 5:
                            slice_from("u");
                            break;
                        case 6:
                            if (cursor >= limit)
                            {
                                break lab2;
                            }
                            cursor++;
                            break;
                    }
                    continue replab1;
                }
                cursor = v_3;
                break replab1;
            }
            cursor = v_2;
            int v_4 = cursor;
            lab3: while (true) {
                bra = cursor;
                if (!(eq_s("y")))
                {
                    cursor = v_4;
                    break lab3;
                }
                ket = cursor;
                slice_from("Y");
                break lab3;
            }
            replab4: while(true)
            {
                int v_5 = cursor;
                lab5: while (true) {
                    if (!go_out_grouping(g_v, 97, 232))
                    {
                        break lab5;
                    }
                    cursor++;
                    int v_6 = cursor;
                    lab6: while (true) {
                        bra = cursor;
                        lab7: while (true) {
                            int v_7 = cursor;
                            lab8: while (true) {
                                if (!(eq_s("i")))
                                {
                                    break lab8;
                                }
                                ket = cursor;
                                int v_8 = cursor;
                                lab9: while (true) {
                                    if (!(in_grouping(g_v, 97, 232)))
                                    {
                                        break lab9;
                                    }
                                    slice_from("I");
                                    break lab9;
                                }
                                cursor = v_8;
                                break lab7;
                            }
                            cursor = v_7;
                            if (!(eq_s("y")))
                            {
                                cursor = v_6;
                                break lab6;
                            }
                            ket = cursor;
                            slice_from("Y");
                            break lab7;
                        }
                        break lab6;
                    }
                    continue replab4;
                }
                cursor = v_5;
                break replab4;
            }
            break lab0;
        }
        cursor = v_1;
        int v_9 = cursor;
        lab10: while (true) {
            I_p1 = limit;
            I_p2 = limit;
            int v_10 = cursor;
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab10;
                }
                cursor = c;
            }
            I_x = cursor;
            cursor = v_10;
            if (!go_out_grouping(g_v, 97, 232))
            {
                break lab10;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 232))
            {
                break lab10;
            }
            cursor++;
            I_p1 = cursor;
            lab11: while (true) {
                if (I_p1 >= I_x)
                {
                    break lab11;
                }
                I_p1 = I_x;
                break lab11;
            }
            if (!go_out_grouping(g_v, 97, 232))
            {
                break lab10;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 232))
            {
                break lab10;
            }
            cursor++;
            I_p2 = cursor;
            break lab10;
        }
        cursor = v_9;
        limit_backward = cursor;
        cursor = limit;
        lab12: while (true) {
            int v_11 = limit - cursor;
            lab13: while (true) {
                ket = cursor;
                among_var = find_among_b(a_3, null);
                if (among_var == 0)
                {
                    break lab13;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p1 > cursor)
                        {
                            break lab13;
                        }
                        slice_from("heid");
                        break;
                    case 2:
                        if (!r_en_ending())
                        {
                            break lab13;
                        }
                        break;
                    case 3:
                        if (I_p1 > cursor)
                        {
                            break lab13;
                        }
                        if (!(out_grouping_b(g_v_j, 97, 232)))
                        {
                            break lab13;
                        }
                        slice_del();
                        break;
                }
                break lab13;
            }
            cursor = limit - v_11;
            int v_12 = limit - cursor;
            r_e_ending();
            cursor = limit - v_12;
            int v_13 = limit - cursor;
            lab14: while (true) {
                ket = cursor;
                if (!(eq_s_b("heid")))
                {
                    break lab14;
                }
                bra = cursor;
                if (I_p2 > cursor)
                {
                    break lab14;
                }
                lab15: while (true) {
                    if (!(eq_s_b("c")))
                    {
                        break lab15;
                    }
                    break lab14;
                }
                slice_del();
                ket = cursor;
                if (!(eq_s_b("en")))
                {
                    break lab14;
                }
                bra = cursor;
                if (!r_en_ending())
                {
                    break lab14;
                }
                break lab14;
            }
            cursor = limit - v_13;
            int v_14 = limit - cursor;
            lab16: while (true) {
                ket = cursor;
                among_var = find_among_b(a_4, null);
                if (among_var == 0)
                {
                    break lab16;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p2 > cursor)
                        {
                            break lab16;
                        }
                        slice_del();
                        lab17: while (true) {
                            int v_15 = limit - cursor;
                            lab18: while (true) {
                                ket = cursor;
                                if (!(eq_s_b("ig")))
                                {
                                    break lab18;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    break lab18;
                                }
                                lab19: while (true) {
                                    if (!(eq_s_b("e")))
                                    {
                                        break lab19;
                                    }
                                    break lab18;
                                }
                                slice_del();
                                break lab17;
                            }
                            cursor = limit - v_15;
                            if (!r_undouble())
                            {
                                break lab16;
                            }
                            break lab17;
                        }
                        break;
                    case 2:
                        if (I_p2 > cursor)
                        {
                            break lab16;
                        }
                        lab20: while (true) {
                            if (!(eq_s_b("e")))
                            {
                                break lab20;
                            }
                            break lab16;
                        }
                        slice_del();
                        break;
                    case 3:
                        if (I_p2 > cursor)
                        {
                            break lab16;
                        }
                        slice_del();
                        if (!r_e_ending())
                        {
                            break lab16;
                        }
                        break;
                    case 4:
                        if (I_p2 > cursor)
                        {
                            break lab16;
                        }
                        slice_del();
                        break;
                    case 5:
                        if (I_p2 > cursor)
                        {
                            break lab16;
                        }
                        if (!B_e_found)
                        {
                            break lab16;
                        }
                        slice_del();
                        break;
                }
                break lab16;
            }
            cursor = limit - v_14;
            int v_16 = limit - cursor;
            lab21: while (true) {
                if (!(out_grouping_b(g_v_I, 73, 232)))
                {
                    break lab21;
                }
                int v_17 = limit - cursor;
                if (find_among_b(a_5, null) == 0)
                {
                    break lab21;
                }
                if (!(out_grouping_b(g_v, 97, 232)))
                {
                    break lab21;
                }
                cursor = limit - v_17;
                ket = cursor;
                if (cursor <= limit_backward)
                {
                    break lab21;
                }
                cursor--;
                bra = cursor;
                slice_del();
                break lab21;
            }
            cursor = limit - v_16;
            break lab12;
        }
        cursor = limit_backward;
        int v_18 = cursor;
        lab22: while (true) {
            replab23: while(true)
            {
                int v_19 = cursor;
                lab24: while (true) {
                    bra = cursor;
                    among_var = find_among(a_1, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("y");
                            break;
                        case 2:
                            slice_from("i");
                            break;
                        case 3:
                            if (cursor >= limit)
                            {
                                break lab24;
                            }
                            cursor++;
                            break;
                    }
                    continue replab23;
                }
                cursor = v_19;
                break replab23;
            }
            break lab22;
        }
        cursor = v_18;
        return true;
    }

    @override
    bool operator ==(Object other) => other is dutch_porter_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
