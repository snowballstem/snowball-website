// Generated from italian.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from italian.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class italian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("all'", -1, -1, 0),
        Among("d'", -1, -1, 0),
        Among("dall'", -1, -1, 0),
        Among("dell'", -1, -1, 0),
        Among("gl'", -1, -1, 0),
        Among("l'", -1, -1, 0),
        Among("m'", -1, -1, 0),
        Among("nell'", -1, -1, 0),
        Among("quell'", -1, -1, 0),
        Among("quest'", -1, -1, 0),
        Among("s'", -1, -1, 0),
        Among("sull'", -1, -1, 0),
        Among("t'", -1, -1, 0),
        Among("tutt'", -1, -1, 0),
        Among("un'", -1, -1, 0),
        Among("v'", -1, -1, 0)
    ];

    static final a_1 = [
        Among("", -1, 7, 0),
        Among("qu", 0, 6, 0),
        Among("\u00E1", 0, 1, 0),
        Among("\u00E9", 0, 2, 0),
        Among("\u00ED", 0, 3, 0),
        Among("\u00F3", 0, 4, 0),
        Among("\u00FA", 0, 5, 0)
    ];

    static final a_2 = [
        Among("", -1, 3, 0),
        Among("I", 0, 1, 0),
        Among("U", 0, 2, 0)
    ];

    static final a_3 = [
        Among("la", -1, -1, 0),
        Among("cela", 0, -1, 0),
        Among("gliela", 0, -1, 0),
        Among("mela", 0, -1, 0),
        Among("tela", 0, -1, 0),
        Among("vela", 0, -1, 0),
        Among("le", -1, -1, 0),
        Among("cele", 6, -1, 0),
        Among("gliele", 6, -1, 0),
        Among("mele", 6, -1, 0),
        Among("tele", 6, -1, 0),
        Among("vele", 6, -1, 0),
        Among("ne", -1, -1, 0),
        Among("cene", 12, -1, 0),
        Among("gliene", 12, -1, 0),
        Among("mene", 12, -1, 0),
        Among("sene", 12, -1, 0),
        Among("tene", 12, -1, 0),
        Among("vene", 12, -1, 0),
        Among("ci", -1, -1, 0),
        Among("li", -1, -1, 0),
        Among("celi", 20, -1, 0),
        Among("glieli", 20, -1, 0),
        Among("meli", 20, -1, 0),
        Among("teli", 20, -1, 0),
        Among("veli", 20, -1, 0),
        Among("gli", 20, -1, 0),
        Among("mi", -1, -1, 0),
        Among("si", -1, -1, 0),
        Among("ti", -1, -1, 0),
        Among("vi", -1, -1, 0),
        Among("lo", -1, -1, 0),
        Among("celo", 31, -1, 0),
        Among("glielo", 31, -1, 0),
        Among("melo", 31, -1, 0),
        Among("telo", 31, -1, 0),
        Among("velo", 31, -1, 0)
    ];

    static final a_4 = [
        Among("ando", -1, 1, 0),
        Among("endo", -1, 1, 0),
        Among("ar", -1, 2, 0),
        Among("er", -1, 2, 0),
        Among("ir", -1, 2, 0)
    ];

    static final a_5 = [
        Among("ic", -1, -1, 0),
        Among("abil", -1, -1, 0),
        Among("os", -1, -1, 0),
        Among("iv", -1, 1, 0)
    ];

    static final a_6 = [
        Among("ic", -1, 1, 0),
        Among("abil", -1, 1, 0),
        Among("iv", -1, 1, 0)
    ];

    static final a_7 = [
        Among("ica", -1, 1, 0),
        Among("logia", -1, 3, 0),
        Among("osa", -1, 1, 0),
        Among("ista", -1, 1, 0),
        Among("iva", -1, 9, 0),
        Among("anza", -1, 1, 0),
        Among("enza", -1, 5, 0),
        Among("ice", -1, 1, 0),
        Among("atrice", 7, 1, 0),
        Among("iche", -1, 1, 0),
        Among("logie", -1, 3, 0),
        Among("abile", -1, 1, 0),
        Among("ibile", -1, 1, 0),
        Among("usione", -1, 4, 0),
        Among("azione", -1, 2, 0),
        Among("uzione", -1, 4, 0),
        Among("atore", -1, 2, 0),
        Among("ose", -1, 1, 0),
        Among("ante", -1, 1, 0),
        Among("mente", -1, 1, 0),
        Among("amente", 19, 7, 0),
        Among("iste", -1, 1, 0),
        Among("ive", -1, 9, 0),
        Among("anze", -1, 1, 0),
        Among("enze", -1, 5, 0),
        Among("ici", -1, 1, 0),
        Among("atrici", 25, 1, 0),
        Among("ichi", -1, 1, 0),
        Among("abili", -1, 1, 0),
        Among("ibili", -1, 1, 0),
        Among("ismi", -1, 1, 0),
        Among("usioni", -1, 4, 0),
        Among("azioni", -1, 2, 0),
        Among("uzioni", -1, 4, 0),
        Among("atori", -1, 2, 0),
        Among("osi", -1, 1, 0),
        Among("anti", -1, 1, 0),
        Among("amenti", -1, 6, 0),
        Among("imenti", -1, 6, 0),
        Among("isti", -1, 1, 0),
        Among("ivi", -1, 9, 0),
        Among("ico", -1, 1, 0),
        Among("ismo", -1, 1, 0),
        Among("oso", -1, 1, 0),
        Among("amento", -1, 6, 0),
        Among("imento", -1, 6, 0),
        Among("ivo", -1, 9, 0),
        Among("it\u00E0", -1, 8, 0),
        Among("ist\u00E0", -1, 1, 0),
        Among("ist\u00E8", -1, 1, 0),
        Among("ist\u00EC", -1, 1, 0)
    ];

    static final a_8 = [
        Among("isca", -1, 1, 0),
        Among("enda", -1, 1, 0),
        Among("ata", -1, 1, 0),
        Among("ita", -1, 1, 0),
        Among("uta", -1, 1, 0),
        Among("ava", -1, 1, 0),
        Among("eva", -1, 1, 0),
        Among("iva", -1, 1, 0),
        Among("erebbe", -1, 1, 0),
        Among("irebbe", -1, 1, 0),
        Among("isce", -1, 1, 0),
        Among("ende", -1, 1, 0),
        Among("are", -1, 1, 0),
        Among("ere", -1, 1, 0),
        Among("ire", -1, 1, 0),
        Among("asse", -1, 1, 0),
        Among("ate", -1, 1, 0),
        Among("avate", 16, 1, 0),
        Among("evate", 16, 1, 0),
        Among("ivate", 16, 1, 0),
        Among("ete", -1, 1, 0),
        Among("erete", 20, 1, 0),
        Among("irete", 20, 1, 0),
        Among("ite", -1, 1, 0),
        Among("ereste", -1, 1, 0),
        Among("ireste", -1, 1, 0),
        Among("ute", -1, 1, 0),
        Among("erai", -1, 1, 0),
        Among("irai", -1, 1, 0),
        Among("isci", -1, 1, 0),
        Among("endi", -1, 1, 0),
        Among("erei", -1, 1, 0),
        Among("irei", -1, 1, 0),
        Among("assi", -1, 1, 0),
        Among("ati", -1, 1, 0),
        Among("iti", -1, 1, 0),
        Among("eresti", -1, 1, 0),
        Among("iresti", -1, 1, 0),
        Among("uti", -1, 1, 0),
        Among("avi", -1, 1, 0),
        Among("evi", -1, 1, 0),
        Among("ivi", -1, 1, 0),
        Among("isco", -1, 1, 0),
        Among("ando", -1, 1, 0),
        Among("endo", -1, 1, 0),
        Among("Yamo", -1, 1, 0),
        Among("iamo", -1, 1, 0),
        Among("avamo", -1, 1, 0),
        Among("evamo", -1, 1, 0),
        Among("ivamo", -1, 1, 0),
        Among("eremo", -1, 1, 0),
        Among("iremo", -1, 1, 0),
        Among("assimo", -1, 1, 0),
        Among("ammo", -1, 1, 0),
        Among("emmo", -1, 1, 0),
        Among("eremmo", 54, 1, 0),
        Among("iremmo", 54, 1, 0),
        Among("immo", -1, 1, 0),
        Among("ano", -1, 1, 0),
        Among("iscano", 58, 1, 0),
        Among("avano", 58, 1, 0),
        Among("evano", 58, 1, 0),
        Among("ivano", 58, 1, 0),
        Among("eranno", -1, 1, 0),
        Among("iranno", -1, 1, 0),
        Among("ono", -1, 1, 0),
        Among("iscono", 65, 1, 0),
        Among("arono", 65, 1, 0),
        Among("erono", 65, 1, 0),
        Among("irono", 65, 1, 0),
        Among("erebbero", -1, 1, 0),
        Among("irebbero", -1, 1, 0),
        Among("assero", -1, 1, 0),
        Among("essero", -1, 1, 0),
        Among("issero", -1, 1, 0),
        Among("ato", -1, 1, 0),
        Among("ito", -1, 1, 0),
        Among("uto", -1, 1, 0),
        Among("avo", -1, 1, 0),
        Among("evo", -1, 1, 0),
        Among("ivo", -1, 1, 0),
        Among("ar", -1, 1, 0),
        Among("ir", -1, 1, 0),
        Among("er\u00E0", -1, 1, 0),
        Among("ir\u00E0", -1, 1, 0),
        Among("er\u00F2", -1, 1, 0),
        Among("ir\u00F2", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 128, 8, 2, 1]);

    static final g_AEIO = String.fromCharCodes([17, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 128, 8, 2]);

    static final g_CG = String.fromCharCodes([17]);


    @override
    bool stem() {
        int among_var;
        int I_p2;
        int I_p1;
        int I_pV;
        int v_1 = cursor;
        lab0: while (true) {
            bra = cursor;
            if (find_among(a_0, null) == 0)
            {
                break lab0;
            }
            ket = cursor;
            if (cursor >= limit)
            {
                break lab0;
            }
            slice_del();
            break lab0;
        }
        cursor = v_1;
        int v_2 = cursor;
        lab1: while (true) {
            int v_3 = cursor;
            replab2: while(true)
            {
                int v_4 = cursor;
                lab3: while (true) {
                    bra = cursor;
                    among_var = find_among(a_1, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("\u00E0");
                            break;
                        case 2:
                            slice_from("\u00E8");
                            break;
                        case 3:
                            slice_from("\u00EC");
                            break;
                        case 4:
                            slice_from("\u00F2");
                            break;
                        case 5:
                            slice_from("\u00F9");
                            break;
                        case 6:
                            slice_from("qU");
                            break;
                        case 7:
                            if (cursor >= limit)
                            {
                                break lab3;
                            }
                            cursor++;
                            break;
                    }
                    continue replab2;
                }
                cursor = v_4;
                break replab2;
            }
            cursor = v_3;
            replab4: while(true)
            {
                int v_5 = cursor;
                lab5: while (true) {
                    golab6: while(true)
                    {
                        int v_6 = cursor;
                        lab7: while (true) {
                            if (!(in_grouping(g_v, 97, 249)))
                            {
                                break lab7;
                            }
                            bra = cursor;
                            lab8: while (true) {
                                int v_7 = cursor;
                                lab9: while (true) {
                                    if (!(eq_s("u")))
                                    {
                                        break lab9;
                                    }
                                    ket = cursor;
                                    if (!(in_grouping(g_v, 97, 249)))
                                    {
                                        break lab9;
                                    }
                                    slice_from("U");
                                    break lab8;
                                }
                                cursor = v_7;
                                if (!(eq_s("i")))
                                {
                                    break lab7;
                                }
                                ket = cursor;
                                if (!(in_grouping(g_v, 97, 249)))
                                {
                                    break lab7;
                                }
                                slice_from("I");
                                break lab8;
                            }
                            cursor = v_6;
                            break golab6;
                        }
                        cursor = v_6;
                        if (cursor >= limit)
                        {
                            break lab5;
                        }
                        cursor++;
                    }
                    continue replab4;
                }
                cursor = v_5;
                break replab4;
            }
            break lab1;
        }
        cursor = v_2;
        lab10: while (true) {
            I_pV = limit;
            I_p1 = limit;
            I_p2 = limit;
            int v_8 = cursor;
            lab11: while (true) {
                lab12: while (true) {
                    int v_9 = cursor;
                    lab13: while (true) {
                        if (!(in_grouping(g_v, 97, 249)))
                        {
                            break lab13;
                        }
                        lab14: while (true) {
                            int v_10 = cursor;
                            lab15: while (true) {
                                if (!(out_grouping(g_v, 97, 249)))
                                {
                                    break lab15;
                                }
                                if (!go_out_grouping(g_v, 97, 249))
                                {
                                    break lab15;
                                }
                                cursor++;
                                break lab14;
                            }
                            cursor = v_10;
                            if (!(in_grouping(g_v, 97, 249)))
                            {
                                break lab13;
                            }
                            if (!go_in_grouping(g_v, 97, 249))
                            {
                                break lab13;
                            }
                            cursor++;
                            break lab14;
                        }
                        break lab12;
                    }
                    cursor = v_9;
                    lab16: while (true) {
                        if (!(eq_s("divan")))
                        {
                            break lab16;
                        }
                        break lab12;
                    }
                    cursor = v_9;
                    if (!(out_grouping(g_v, 97, 249)))
                    {
                        break lab11;
                    }
                    lab17: while (true) {
                        int v_11 = cursor;
                        lab18: while (true) {
                            if (!(out_grouping(g_v, 97, 249)))
                            {
                                break lab18;
                            }
                            if (!go_out_grouping(g_v, 97, 249))
                            {
                                break lab18;
                            }
                            cursor++;
                            break lab17;
                        }
                        cursor = v_11;
                        if (!(in_grouping(g_v, 97, 249)))
                        {
                            break lab11;
                        }
                        if (cursor >= limit)
                        {
                            break lab11;
                        }
                        cursor++;
                        break lab17;
                    }
                    break lab12;
                }
                I_pV = cursor;
                break lab11;
            }
            cursor = v_8;
            int v_12 = cursor;
            lab19: while (true) {
                if (!go_out_grouping(g_v, 97, 249))
                {
                    break lab19;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 249))
                {
                    break lab19;
                }
                cursor++;
                I_p1 = cursor;
                if (!go_out_grouping(g_v, 97, 249))
                {
                    break lab19;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 249))
                {
                    break lab19;
                }
                cursor++;
                I_p2 = cursor;
                break lab19;
            }
            cursor = v_12;
            break lab10;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_13 = limit - cursor;
        lab20: while (true) {
            ket = cursor;
            if (find_among_b(a_3, null) == 0)
            {
                break lab20;
            }
            bra = cursor;
            among_var = find_among_b(a_4, null);
            if (among_var == 0)
            {
                break lab20;
            }
            if (I_pV > cursor)
            {
                break lab20;
            }
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    slice_from("e");
                    break;
            }
            break lab20;
        }
        cursor = limit - v_13;
        int v_14 = limit - cursor;
        lab21: while (true) {
            lab22: while (true) {
                int v_15 = limit - cursor;
                lab23: while (true) {
                    ket = cursor;
                    among_var = find_among_b(a_7, null);
                    if (among_var == 0)
                    {
                        break lab23;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            if (I_p2 > cursor)
                            {
                                break lab23;
                            }
                            slice_del();
                            break;
                        case 2:
                            if (I_p2 > cursor)
                            {
                                break lab23;
                            }
                            slice_del();
                            int v_16 = limit - cursor;
                            lab24: while (true) {
                                ket = cursor;
                                if (!(eq_s_b("ic")))
                                {
                                    cursor = limit - v_16;
                                    break lab24;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_16;
                                    break lab24;
                                }
                                slice_del();
                                break lab24;
                            }
                            break;
                        case 3:
                            if (I_p2 > cursor)
                            {
                                break lab23;
                            }
                            slice_from("log");
                            break;
                        case 4:
                            if (I_p2 > cursor)
                            {
                                break lab23;
                            }
                            slice_from("u");
                            break;
                        case 5:
                            if (I_p2 > cursor)
                            {
                                break lab23;
                            }
                            slice_from("ente");
                            break;
                        case 6:
                            if (I_pV > cursor)
                            {
                                break lab23;
                            }
                            slice_del();
                            break;
                        case 7:
                            if (I_p1 > cursor)
                            {
                                break lab23;
                            }
                            slice_del();
                            int v_17 = limit - cursor;
                            lab25: while (true) {
                                ket = cursor;
                                among_var = find_among_b(a_5, null);
                                if (among_var == 0)
                                {
                                    cursor = limit - v_17;
                                    break lab25;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_17;
                                    break lab25;
                                }
                                slice_del();
                                switch (among_var) {
                                    case 1:
                                        ket = cursor;
                                        if (!(eq_s_b("at")))
                                        {
                                            cursor = limit - v_17;
                                            break lab25;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_17;
                                            break lab25;
                                        }
                                        slice_del();
                                        break;
                                }
                                break lab25;
                            }
                            break;
                        case 8:
                            if (I_p2 > cursor)
                            {
                                break lab23;
                            }
                            slice_del();
                            int v_18 = limit - cursor;
                            lab26: while (true) {
                                ket = cursor;
                                if (find_among_b(a_6, null) == 0)
                                {
                                    cursor = limit - v_18;
                                    break lab26;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_18;
                                    break lab26;
                                }
                                slice_del();
                                break lab26;
                            }
                            break;
                        case 9:
                            if (I_p2 > cursor)
                            {
                                break lab23;
                            }
                            slice_del();
                            int v_19 = limit - cursor;
                            lab27: while (true) {
                                ket = cursor;
                                if (!(eq_s_b("at")))
                                {
                                    cursor = limit - v_19;
                                    break lab27;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_19;
                                    break lab27;
                                }
                                slice_del();
                                ket = cursor;
                                if (!(eq_s_b("ic")))
                                {
                                    cursor = limit - v_19;
                                    break lab27;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_19;
                                    break lab27;
                                }
                                slice_del();
                                break lab27;
                            }
                            break;
                    }
                    break lab22;
                }
                cursor = limit - v_15;
                if (cursor < I_pV)
                {
                    break lab21;
                }
                int v_20 = limit_backward;
                limit_backward = I_pV;
                ket = cursor;
                if (find_among_b(a_8, null) == 0)
                {
                    limit_backward = v_20;
                    break lab21;
                }
                bra = cursor;
                slice_del();
                limit_backward = v_20;
                break lab22;
            }
            break lab21;
        }
        cursor = limit - v_14;
        int v_21 = limit - cursor;
        lab28: while (true) {
            int v_22 = limit - cursor;
            lab29: while (true) {
                ket = cursor;
                if (!(in_grouping_b(g_AEIO, 97, 242)))
                {
                    cursor = limit - v_22;
                    break lab29;
                }
                bra = cursor;
                if (I_pV > cursor)
                {
                    cursor = limit - v_22;
                    break lab29;
                }
                slice_del();
                ket = cursor;
                if (!(eq_s_b("i")))
                {
                    cursor = limit - v_22;
                    break lab29;
                }
                bra = cursor;
                if (I_pV > cursor)
                {
                    cursor = limit - v_22;
                    break lab29;
                }
                slice_del();
                break lab29;
            }
            int v_23 = limit - cursor;
            lab30: while (true) {
                ket = cursor;
                if (!(eq_s_b("h")))
                {
                    cursor = limit - v_23;
                    break lab30;
                }
                bra = cursor;
                if (!(in_grouping_b(g_CG, 99, 103)))
                {
                    cursor = limit - v_23;
                    break lab30;
                }
                if (I_pV > cursor)
                {
                    cursor = limit - v_23;
                    break lab30;
                }
                slice_del();
                break lab30;
            }
            break lab28;
        }
        cursor = limit - v_21;
        cursor = limit_backward;
        int v_24 = cursor;
        lab31: while (true) {
            replab32: while(true)
            {
                int v_25 = cursor;
                lab33: while (true) {
                    bra = cursor;
                    among_var = find_among(a_2, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("i");
                            break;
                        case 2:
                            slice_from("u");
                            break;
                        case 3:
                            if (cursor >= limit)
                            {
                                break lab33;
                            }
                            cursor++;
                            break;
                    }
                    continue replab32;
                }
                cursor = v_25;
                break replab32;
            }
            break lab31;
        }
        cursor = v_24;
        return true;
    }

    @override
    bool operator ==(Object other) => other is italian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
