// Generated from persian.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from persian.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class persian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 7, 0),
        Among(" ", 0, 6, 0),
        Among("\u0623", 0, 4, 0),
        Among("\u0624", 0, 5, 0),
        Among("\u0625", 0, 4, 0),
        Among("\u0626", 0, 2, 0),
        Among("\u0629", 0, 3, 0),
        Among("\u0643", 0, 1, 0),
        Among("\u064A", 0, 2, 0),
        Among("\u06C1", 0, 3, 0),
        Among("\u200D", 0, 6, 0)
    ];

    static final a_1 = [
        Among("\u0645\u06CC\u200C", -1, 2, 0),
        Among("\u0646\u0645\u06CC\u200C", -1, 1, 0)
    ];

    static final a_2 = [
        Among("\u0633\u062A\u0627\u0646", -1, -1, 0),
        Among("\u0631\u0627\u0646", -1, -1, 0),
        Among("\u0633\u0627\u0646", -1, -1, 0),
        Among("\u0648\u0627\u0646", -1, -1, 0)
    ];

    static final a_3 = [
        Among("\u0622\u0630\u0631\u0628\u0627\u06CC\u062C\u0627\u0646", -1, 1, 0),
        Among("\u0647\u0645\u062F\u0627\u0646", -1, 1, 0),
        Among("\u062E\u0627\u0646\u062F\u0627\u0646", -1, 1, 0),
        Among("\u0632\u0646\u062F\u0627\u0646", -1, 1, 0),
        Among("\u0645\u06CC\u0632\u0627\u0646", -1, 1, 0),
        Among("\u062F\u0631\u062E\u0634\u0627\u0646", -1, 1, 0),
        Among("\u0622\u062A\u0634\u0641\u0634\u0627\u0646", -1, 1, 0),
        Among("\u0646\u0634\u0627\u0646", -1, 1, 0),
        Among("\u06A9\u0647\u06A9\u0634\u0627\u0646", -1, 1, 0),
        Among("\u0627\u06CC\u0634\u0627\u0646", -1, 1, 0),
        Among("\u067E\u0631\u06CC\u0634\u0627\u0646", -1, 1, 0),
        Among("\u0633\u0644\u0637\u0627\u0646", -1, 1, 0),
        Among("\u06AF\u06CC\u0644\u0627\u0646", -1, 1, 0),
        Among("\u0633\u0627\u062E\u062A\u0645\u0627\u0646", -1, 1, 0),
        Among("\u0631\u0645\u0627\u0646", -1, 1, 0),
        Among("\u062F\u0631\u0645\u0627\u0646", 14, 1, 0),
        Among("\u0642\u0647\u0631\u0645\u0627\u0646", 14, 1, 0),
        Among("\u06A9\u0631\u0645\u0627\u0646", 14, 1, 0),
        Among("\u0633\u0627\u0632\u0645\u0627\u0646", -1, 1, 0),
        Among("\u0647\u0645\u0632\u0645\u0627\u0646", -1, 1, 0),
        Among("\u0622\u0633\u0645\u0627\u0646", -1, 1, 0),
        Among("\u0622\u0644\u0645\u0627\u0646", -1, 1, 0),
        Among("\u0645\u0633\u0644\u0645\u0627\u0646", -1, 1, 0),
        Among("\u0627\u06CC\u0645\u0627\u0646", -1, 1, 0),
        Among("\u0633\u0644\u06CC\u0645\u0627\u0646", -1, 1, 0),
        Among("\u067E\u06CC\u0645\u0627\u0646", -1, 1, 0),
        Among("\u0644\u0628\u0646\u0627\u0646", -1, 1, 0),
        Among("\u06CC\u0648\u0646\u0627\u0646", -1, 1, 0),
        Among("\u0627\u0635\u0641\u0647\u0627\u0646", -1, 1, 0),
        Among("\u0627\u0645\u06A9\u0627\u0646", -1, 1, 0),
        Among("\u067E\u0627\u06CC\u0627\u0646", -1, 1, 0),
        Among("\u0628\u06CC\u0627\u0646", -1, 1, 0),
        Among("\u062C\u0631\u06CC\u0627\u0646", -1, 1, 0)
    ];

    static final a_4 = [
        Among("\u0627\u0633\u0627\u062A\u06CC\u062F", -1, 2, 0),
        Among("\u0627\u062E\u0628\u0627\u0631", -1, 1, 0)
    ];

    static final a_5 = [
        Among("\u0647\u0627", -1, 1, 0),
        Among("\u0627\u062A", -1, 1, 0),
        Among("\u06CC\u062A", -1, 1, 0),
        Among("\u0645\u0646\u062F", -1, 1, 0),
        Among("\u0648\u0627\u0631", -1, 1, 0),
        Among("\u06AF\u0627\u0631", -1, 1, 0),
        Among("\u062A\u0631", -1, 2, 0),
        Among("\u0627\u0634", -1, 1, 0),
        Among("\u0627\u0645", -1, 1, 0),
        Among("\u0627\u0646", -1, 1, 0),
        Among("\u0628\u0627\u0646", 9, 1, 0),
        Among("\u06AF\u0627\u0646", 9, 1, 0),
        Among("\u06CC\u0627\u0646", 9, 1, 0),
        Among("\u06CC\u0646", -1, 1, 0),
        Among("\u062A\u0631\u06CC\u0646", 13, 1, 0),
        Among("\u06AF\u0627\u0647", -1, 1, 0),
        Among("\u0627\u0646\u0647", -1, 1, 0),
        Among("\u0646\u0627\u06A9", -1, 1, 0),
        Among("\u0647\u0627\u06CC", -1, 1, 0),
        Among("\u0627\u0646\u06CC", -1, 1, 0),
        Among("\u06AF\u06CC", -1, 1, 0),
        Among("\u06CC\u06CC", -1, 1, 0)
    ];

    static final a_6 = [
        Among("\u0627\u0633\u062A", -1, 1, 0),
        Among("\u0627\u0646\u062F", -1, 1, 0),
        Among("\u06CC\u062F", -1, 1, 0),
        Among("\u0627\u06CC\u062F", 2, 1, 0),
        Among("\u0627\u0633", -1, 1, 0),
        Among("\u06CC\u0645", -1, 1, 0),
        Among("\u0627\u06CC\u0645", 5, 1, 0),
        Among("\u0627\u06CC", -1, 1, 0)
    ];

    static final a_7 = [
        Among("\u062F", -1, 1, 0),
        Among("\u0627\u0646\u062F", 0, 1, 0),
        Among("\u0631\u0641\u062A\u0627\u0646\u062F", 1, 2, 0),
        Among("\u06CC\u062F", 0, 1, 0),
        Among("\u0631\u0641\u062A\u06CC\u062F", 3, 2, 0),
        Among("\u0645", -1, 1, 0),
        Among("\u0627\u0645", 5, 1, 0),
        Among("\u0631\u0641\u062A\u0645", 5, 2, 0),
        Among("\u06CC\u0645", 5, 1, 0),
        Among("\u0631\u0641\u062A\u06CC\u0645", 8, 2, 0),
        Among("\u0627\u0646", -1, 3, 0),
        Among("\u062A\u0647", -1, 5, 0),
        Among("\u062F\u0647", -1, 4, 0),
        Among("\u0646\u062F\u0647", 12, 3, 0),
        Among("\u0631\u0641\u062A\u06CC", -1, 2, 0)
    ];


    @override
    bool stem() {
        int among_var;
        int I_p1;
        bool B_remove_verb_person_endings;
        bool B_saw_present_prefix;
        B_saw_present_prefix = false;
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = cursor;
                lab2: while (true) {
                    bra = cursor;
                    among_var = find_among(a_0, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("\u06A9");
                            break;
                        case 2:
                            slice_from("\u06CC");
                            break;
                        case 3:
                            slice_from("\u0647");
                            break;
                        case 4:
                            slice_from("\u0627");
                            break;
                        case 5:
                            slice_from("\u0648");
                            break;
                        case 6:
                            slice_del();
                            break;
                        case 7:
                            if (cursor >= limit)
                            {
                                break lab2;
                            }
                            cursor++;
                            break;
                    }
                    continue replab1;
                }
                cursor = v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = v_1;
        int v_3 = cursor;
        lab3: while (true) {
            bra = cursor;
            among_var = find_among(a_1, null);
            if (among_var == 0)
            {
                break lab3;
            }
            ket = cursor;
            switch (among_var) {
                case 1:
                    {
                        int c = cursor + 2;
                        if (c > limit)
                        {
                            break lab3;
                        }
                        cursor = c;
                    }
                    B_saw_present_prefix = true;
                    break;
                case 2:
                    {
                        int c = cursor + 2;
                        if (c > limit)
                        {
                            break lab3;
                        }
                        cursor = c;
                    }
                    slice_del();
                    B_saw_present_prefix = true;
                    break;
            }
            break lab3;
        }
        cursor = v_3;
        int v_4 = cursor;
        lab4: while (true) {
            replab5: while(true)
            {
                int v_5 = cursor;
                lab6: while (true) {
                    golab7: while(true)
                    {
                        int v_6 = cursor;
                        lab8: while (true) {
                            bra = cursor;
                            if (!(eq_s("\u200C")))
                            {
                                break lab8;
                            }
                            ket = cursor;
                            slice_del();
                            cursor = v_6;
                            break golab7;
                        }
                        cursor = v_6;
                        if (cursor >= limit)
                        {
                            break lab6;
                        }
                        cursor++;
                    }
                    continue replab5;
                }
                cursor = v_5;
                break replab5;
            }
            break lab4;
        }
        cursor = v_4;
        I_p1 = limit;
        int v_7 = cursor;
        lab9: while (true) {
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab9;
                }
                cursor = c;
            }
            I_p1 = cursor;
            break lab9;
        }
        cursor = v_7;
        limit_backward = cursor;
        cursor = limit;
        replab10: while(true)
        {
            int v_8 = limit - cursor;
            lab11: while (true) {
                int v_9 = limit - cursor;
                B_remove_verb_person_endings = false;
                lab12: while (true) {
                    if (!B_saw_present_prefix)
                    {
                        break lab12;
                    }
                    B_remove_verb_person_endings = true;
                    break lab12;
                }
                {
                    int v_10 = limit - cursor;
                    lab13: while (true) {
                        if (find_among_b(a_3, null) == 0)
                        {
                            break lab13;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab13;
                        }
                        break lab11;
                    }
                    cursor = limit - v_10;
                }
                {
                    int v_11 = limit - cursor;
                    lab14: while (true) {
                        if (find_among_b(a_2, null) == 0)
                        {
                            break lab14;
                        }
                        break lab11;
                    }
                    cursor = limit - v_11;
                }
                lab15: while (true) {
                    int v_12 = limit - cursor;
                    lab16: while (true) {
                        lab17: while (true) {
                            int v_13 = limit - cursor;
                            lab18: while (true) {
                                ket = cursor;
                                among_var = find_among_b(a_4, null);
                                if (among_var == 0)
                                {
                                    break lab18;
                                }
                                bra = cursor;
                                switch (among_var) {
                                    case 1:
                                        slice_from("\u062E\u0628\u0631");
                                        break;
                                    case 2:
                                        slice_from("\u0627\u0633\u062A\u0627\u062F");
                                        break;
                                }
                                break lab17;
                            }
                            cursor = limit - v_13;
                            if (cursor < I_p1)
                            {
                                break lab16;
                            }
                            int v_14 = limit_backward;
                            limit_backward = I_p1;
                            ket = cursor;
                            among_var = find_among_b(a_5, null);
                            if (among_var == 0)
                            {
                                limit_backward = v_14;
                                break lab16;
                            }
                            bra = cursor;
                            switch (among_var) {
                                case 1:
                                    slice_del();
                                    break;
                                case 2:
                                    if (cursor <= limit_backward)
                                    {
                                        limit_backward = v_14;
                                        break lab16;
                                    }
                                    slice_del();
                                    break;
                            }
                            limit_backward = v_14;
                            break lab17;
                        }
                        break lab15;
                    }
                    cursor = limit - v_12;
                    lab19: while (true) {
                        int v_15 = limit - cursor;
                        lab20: while (true) {
                            ket = cursor;
                            if (find_among_b(a_6, null) == 0)
                            {
                                break lab20;
                            }
                            bra = cursor;
                            if (I_p1 > cursor)
                            {
                                break lab20;
                            }
                            slice_del();
                            break lab19;
                        }
                        cursor = limit - v_15;
                        ket = cursor;
                        among_var = find_among_b(a_7, null);
                        if (among_var == 0)
                        {
                            break lab11;
                        }
                        bra = cursor;
                        switch (among_var) {
                            case 1:
                                if (!B_remove_verb_person_endings)
                                {
                                    break lab11;
                                }
                                if (I_p1 > cursor)
                                {
                                    break lab11;
                                }
                                slice_del();
                                break;
                            case 2:
                                slice_from("\u0631\u0641\u062A");
                                break;
                            case 3:
                                if (I_p1 > cursor)
                                {
                                    break lab11;
                                }
                                slice_del();
                                B_remove_verb_person_endings = true;
                                break;
                            case 4:
                                if (cursor <= limit_backward)
                                {
                                    break lab11;
                                }
                                slice_from("\u062F");
                                B_remove_verb_person_endings = true;
                                break;
                            case 5:
                                if (cursor <= limit_backward)
                                {
                                    break lab11;
                                }
                                slice_from("\u062A");
                                B_remove_verb_person_endings = true;
                                break;
                        }
                        break lab19;
                    }
                    break lab15;
                }
                cursor = limit - v_9;
                continue replab10;
            }
            cursor = limit - v_8;
            break replab10;
        }
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is persian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
