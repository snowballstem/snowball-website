// Generated from porter.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from porter.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class porter_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("s", -1, 3, 0),
        Among("ies", 0, 2, 0),
        Among("sses", 0, 1, 0),
        Among("ss", 0, -1, 0)
    ];

    static final a_1 = [
        Among("", -1, 3, 0),
        Among("bb", 0, 2, 0),
        Among("dd", 0, 2, 0),
        Among("ff", 0, 2, 0),
        Among("gg", 0, 2, 0),
        Among("bl", 0, 1, 0),
        Among("mm", 0, 2, 0),
        Among("nn", 0, 2, 0),
        Among("pp", 0, 2, 0),
        Among("rr", 0, 2, 0),
        Among("at", 0, 1, 0),
        Among("tt", 0, 2, 0),
        Among("iz", 0, 1, 0)
    ];

    static final a_2 = [
        Among("ed", -1, 2, 0),
        Among("eed", 0, 1, 0),
        Among("ing", -1, 2, 0)
    ];

    static final a_3 = [
        Among("anci", -1, 3, 0),
        Among("enci", -1, 2, 0),
        Among("abli", -1, 4, 0),
        Among("eli", -1, 6, 0),
        Among("alli", -1, 9, 0),
        Among("ousli", -1, 11, 0),
        Among("entli", -1, 5, 0),
        Among("aliti", -1, 9, 0),
        Among("biliti", -1, 13, 0),
        Among("iviti", -1, 12, 0),
        Among("tional", -1, 1, 0),
        Among("ational", 10, 8, 0),
        Among("alism", -1, 9, 0),
        Among("ation", -1, 8, 0),
        Among("ization", 13, 7, 0),
        Among("izer", -1, 7, 0),
        Among("ator", -1, 8, 0),
        Among("iveness", -1, 12, 0),
        Among("fulness", -1, 10, 0),
        Among("ousness", -1, 11, 0)
    ];

    static final a_4 = [
        Among("icate", -1, 2, 0),
        Among("ative", -1, 3, 0),
        Among("alize", -1, 1, 0),
        Among("iciti", -1, 2, 0),
        Among("ical", -1, 2, 0),
        Among("ful", -1, 3, 0),
        Among("ness", -1, 3, 0)
    ];

    static final a_5 = [
        Among("ic", -1, 1, 0),
        Among("ance", -1, 1, 0),
        Among("ence", -1, 1, 0),
        Among("able", -1, 1, 0),
        Among("ible", -1, 1, 0),
        Among("ate", -1, 1, 0),
        Among("ive", -1, 1, 0),
        Among("ize", -1, 1, 0),
        Among("iti", -1, 1, 0),
        Among("al", -1, 1, 0),
        Among("ism", -1, 1, 0),
        Among("ion", -1, 2, 0),
        Among("er", -1, 1, 0),
        Among("ous", -1, 1, 0),
        Among("ant", -1, 1, 0),
        Among("ent", -1, 1, 0),
        Among("ment", 15, 1, 0),
        Among("ement", 16, 1, 0),
        Among("ou", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1]);

    static final g_v_WXY = String.fromCharCodes([1, 17, 65, 208, 1]);


    bool r_shortv() {
        if (!(out_grouping_b(g_v_WXY, 89, 121)))
        {
            return false;
        }
        if (!(in_grouping_b(g_v, 97, 121)))
        {
            return false;
        }
        return out_grouping_b(g_v, 97, 121);
    }

    @override
    bool stem() {
        int among_var;
        bool B_Y_found;
        int I_p2;
        int I_p1;
        B_Y_found = false;
        int v_1 = cursor;
        lab0: while (true) {
            bra = cursor;
            if (!(eq_s("y")))
            {
                break lab0;
            }
            ket = cursor;
            slice_from("Y");
            B_Y_found = true;
            break lab0;
        }
        cursor = v_1;
        int v_2 = cursor;
        lab1: while (true) {
            replab2: while(true)
            {
                int v_3 = cursor;
                lab3: while (true) {
                    golab4: while(true)
                    {
                        int v_4 = cursor;
                        lab5: while (true) {
                            if (!(in_grouping(g_v, 97, 121)))
                            {
                                break lab5;
                            }
                            bra = cursor;
                            if (!(eq_s("y")))
                            {
                                break lab5;
                            }
                            ket = cursor;
                            cursor = v_4;
                            break golab4;
                        }
                        cursor = v_4;
                        if (cursor >= limit)
                        {
                            break lab3;
                        }
                        cursor++;
                    }
                    slice_from("Y");
                    B_Y_found = true;
                    continue replab2;
                }
                cursor = v_3;
                break replab2;
            }
            break lab1;
        }
        cursor = v_2;
        I_p1 = limit;
        I_p2 = limit;
        int v_5 = cursor;
        lab6: while (true) {
            if (!go_out_grouping(g_v, 97, 121))
            {
                break lab6;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 121))
            {
                break lab6;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 121))
            {
                break lab6;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 121))
            {
                break lab6;
            }
            cursor++;
            I_p2 = cursor;
            break lab6;
        }
        cursor = v_5;
        limit_backward = cursor;
        cursor = limit;
        int v_6 = limit - cursor;
        lab7: while (true) {
            ket = cursor;
            among_var = find_among_b(a_0, null);
            if (among_var == 0)
            {
                break lab7;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_from("ss");
                    break;
                case 2:
                    slice_from("i");
                    break;
                case 3:
                    slice_del();
                    break;
            }
            break lab7;
        }
        cursor = limit - v_6;
        int v_7 = limit - cursor;
        lab8: while (true) {
            ket = cursor;
            among_var = find_among_b(a_2, null);
            if (among_var == 0)
            {
                break lab8;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    if (I_p1 > cursor)
                    {
                        break lab8;
                    }
                    slice_from("ee");
                    break;
                case 2:
                    int v_8 = limit - cursor;
                    if (!go_out_grouping_b(g_v, 97, 121))
                    {
                        break lab8;
                    }
                    cursor--;
                    cursor = limit - v_8;
                    slice_del();
                    int v_9 = limit - cursor;
                    among_var = find_among_b(a_1, null);
                    cursor = limit - v_9;
                    switch (among_var) {
                        case 1:
                            {
                                int c = cursor;
                                insert(cursor, cursor, "e");
                                cursor = c;
                            }
                            break;
                        case 2:
                            ket = cursor;
                            if (cursor <= limit_backward)
                            {
                                break lab8;
                            }
                            cursor--;
                            bra = cursor;
                            slice_del();
                            break;
                        case 3:
                            if (cursor != I_p1)
                            {
                                break lab8;
                            }
                            int v_10 = limit - cursor;
                            if (!r_shortv())
                            {
                                break lab8;
                            }
                            cursor = limit - v_10;
                            {
                                int c = cursor;
                                insert(cursor, cursor, "e");
                                cursor = c;
                            }
                            break;
                    }
                    break;
            }
            break lab8;
        }
        cursor = limit - v_7;
        int v_11 = limit - cursor;
        lab9: while (true) {
            ket = cursor;
            lab10: while (true) {
                lab11: while (true) {
                    if (!(eq_s_b("y")))
                    {
                        break lab11;
                    }
                    break lab10;
                }
                if (!(eq_s_b("Y")))
                {
                    break lab9;
                }
                break lab10;
            }
            bra = cursor;
            if (!go_out_grouping_b(g_v, 97, 121))
            {
                break lab9;
            }
            cursor--;
            slice_from("i");
            break lab9;
        }
        cursor = limit - v_11;
        int v_12 = limit - cursor;
        lab12: while (true) {
            ket = cursor;
            among_var = find_among_b(a_3, null);
            if (among_var == 0)
            {
                break lab12;
            }
            bra = cursor;
            if (I_p1 > cursor)
            {
                break lab12;
            }
            switch (among_var) {
                case 1:
                    slice_from("tion");
                    break;
                case 2:
                    slice_from("ence");
                    break;
                case 3:
                    slice_from("ance");
                    break;
                case 4:
                    slice_from("able");
                    break;
                case 5:
                    slice_from("ent");
                    break;
                case 6:
                    slice_from("e");
                    break;
                case 7:
                    slice_from("ize");
                    break;
                case 8:
                    slice_from("ate");
                    break;
                case 9:
                    slice_from("al");
                    break;
                case 10:
                    slice_from("ful");
                    break;
                case 11:
                    slice_from("ous");
                    break;
                case 12:
                    slice_from("ive");
                    break;
                case 13:
                    slice_from("ble");
                    break;
            }
            break lab12;
        }
        cursor = limit - v_12;
        int v_13 = limit - cursor;
        lab13: while (true) {
            ket = cursor;
            among_var = find_among_b(a_4, null);
            if (among_var == 0)
            {
                break lab13;
            }
            bra = cursor;
            if (I_p1 > cursor)
            {
                break lab13;
            }
            switch (among_var) {
                case 1:
                    slice_from("al");
                    break;
                case 2:
                    slice_from("ic");
                    break;
                case 3:
                    slice_del();
                    break;
            }
            break lab13;
        }
        cursor = limit - v_13;
        int v_14 = limit - cursor;
        lab14: while (true) {
            ket = cursor;
            among_var = find_among_b(a_5, null);
            if (among_var == 0)
            {
                break lab14;
            }
            bra = cursor;
            if (I_p2 > cursor)
            {
                break lab14;
            }
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    lab15: while (true) {
                        lab16: while (true) {
                            if (!(eq_s_b("s")))
                            {
                                break lab16;
                            }
                            break lab15;
                        }
                        if (!(eq_s_b("t")))
                        {
                            break lab14;
                        }
                        break lab15;
                    }
                    slice_del();
                    break;
            }
            break lab14;
        }
        cursor = limit - v_14;
        int v_15 = limit - cursor;
        lab17: while (true) {
            ket = cursor;
            if (!(eq_s_b("e")))
            {
                break lab17;
            }
            bra = cursor;
            lab18: while (true) {
                lab19: while (true) {
                    if (I_p2 > cursor)
                    {
                        break lab19;
                    }
                    break lab18;
                }
                if (I_p1 > cursor)
                {
                    break lab17;
                }
                {
                    int v_16 = limit - cursor;
                    lab20: while (true) {
                        if (!r_shortv())
                        {
                            break lab20;
                        }
                        break lab17;
                    }
                    cursor = limit - v_16;
                }
                break lab18;
            }
            slice_del();
            break lab17;
        }
        cursor = limit - v_15;
        int v_17 = limit - cursor;
        lab21: while (true) {
            ket = cursor;
            if (!(eq_s_b("l")))
            {
                break lab21;
            }
            bra = cursor;
            if (I_p2 > cursor)
            {
                break lab21;
            }
            if (!(eq_s_b("l")))
            {
                break lab21;
            }
            slice_del();
            break lab21;
        }
        cursor = limit - v_17;
        cursor = limit_backward;
        int v_18 = cursor;
        lab22: while (true) {
            if (!B_Y_found)
            {
                break lab22;
            }
            replab23: while(true)
            {
                int v_19 = cursor;
                lab24: while (true) {
                    golab25: while(true)
                    {
                        int v_20 = cursor;
                        lab26: while (true) {
                            bra = cursor;
                            if (!(eq_s("Y")))
                            {
                                break lab26;
                            }
                            ket = cursor;
                            cursor = v_20;
                            break golab25;
                        }
                        cursor = v_20;
                        if (cursor >= limit)
                        {
                            break lab24;
                        }
                        cursor++;
                    }
                    slice_from("y");
                    continue replab23;
                }
                cursor = v_19;
                break replab23;
            }
            break lab22;
        }
        cursor = v_18;
        return true;
    }

    @override
    bool operator ==(Object other) => other is porter_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
