// Generated from turkish.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from turkish.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class turkish_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("m", -1, -1, 0),
        Among("n", -1, -1, 0),
        Among("miz", -1, -1, 0),
        Among("niz", -1, -1, 0),
        Among("muz", -1, -1, 0),
        Among("nuz", -1, -1, 0),
        Among("m\u00FCz", -1, -1, 0),
        Among("n\u00FCz", -1, -1, 0),
        Among("m\u0131z", -1, -1, 0),
        Among("n\u0131z", -1, -1, 0)
    ];

    static final a_1 = [
        Among("leri", -1, -1, 0),
        Among("lar\u0131", -1, -1, 0)
    ];

    static final a_2 = [
        Among("ni", -1, -1, 0),
        Among("nu", -1, -1, 0),
        Among("n\u00FC", -1, -1, 0),
        Among("n\u0131", -1, -1, 0)
    ];

    static final a_3 = [
        Among("in", -1, -1, 0),
        Among("un", -1, -1, 0),
        Among("\u00FCn", -1, -1, 0),
        Among("\u0131n", -1, -1, 0)
    ];

    static final a_4 = [
        Among("a", -1, -1, 0),
        Among("e", -1, -1, 0)
    ];

    static final a_5 = [
        Among("na", -1, -1, 0),
        Among("ne", -1, -1, 0)
    ];

    static final a_6 = [
        Among("da", -1, -1, 0),
        Among("ta", -1, -1, 0),
        Among("de", -1, -1, 0),
        Among("te", -1, -1, 0)
    ];

    static final a_7 = [
        Among("nda", -1, -1, 0),
        Among("nde", -1, -1, 0)
    ];

    static final a_8 = [
        Among("dan", -1, -1, 0),
        Among("tan", -1, -1, 0),
        Among("den", -1, -1, 0),
        Among("ten", -1, -1, 0)
    ];

    static final a_9 = [
        Among("ndan", -1, -1, 0),
        Among("nden", -1, -1, 0)
    ];

    static final a_10 = [
        Among("la", -1, -1, 0),
        Among("le", -1, -1, 0)
    ];

    static final a_11 = [
        Among("ca", -1, -1, 0),
        Among("ce", -1, -1, 0)
    ];

    static final a_12 = [
        Among("im", -1, -1, 0),
        Among("um", -1, -1, 0),
        Among("\u00FCm", -1, -1, 0),
        Among("\u0131m", -1, -1, 0)
    ];

    static final a_13 = [
        Among("sin", -1, -1, 0),
        Among("sun", -1, -1, 0),
        Among("s\u00FCn", -1, -1, 0),
        Among("s\u0131n", -1, -1, 0)
    ];

    static final a_14 = [
        Among("iz", -1, -1, 0),
        Among("uz", -1, -1, 0),
        Among("\u00FCz", -1, -1, 0),
        Among("\u0131z", -1, -1, 0)
    ];

    static final a_15 = [
        Among("siniz", -1, -1, 0),
        Among("sunuz", -1, -1, 0),
        Among("s\u00FCn\u00FCz", -1, -1, 0),
        Among("s\u0131n\u0131z", -1, -1, 0)
    ];

    static final a_16 = [
        Among("lar", -1, -1, 0),
        Among("ler", -1, -1, 0)
    ];

    static final a_17 = [
        Among("niz", -1, -1, 0),
        Among("nuz", -1, -1, 0),
        Among("n\u00FCz", -1, -1, 0),
        Among("n\u0131z", -1, -1, 0)
    ];

    static final a_18 = [
        Among("dir", -1, -1, 0),
        Among("tir", -1, -1, 0),
        Among("dur", -1, -1, 0),
        Among("tur", -1, -1, 0),
        Among("d\u00FCr", -1, -1, 0),
        Among("t\u00FCr", -1, -1, 0),
        Among("d\u0131r", -1, -1, 0),
        Among("t\u0131r", -1, -1, 0)
    ];

    static final a_19 = [
        Among("cas\u0131na", -1, -1, 0),
        Among("cesine", -1, -1, 0)
    ];

    static final a_20 = [
        Among("di", -1, -1, 0),
        Among("ti", -1, -1, 0),
        Among("dik", -1, -1, 0),
        Among("tik", -1, -1, 0),
        Among("duk", -1, -1, 0),
        Among("tuk", -1, -1, 0),
        Among("d\u00FCk", -1, -1, 0),
        Among("t\u00FCk", -1, -1, 0),
        Among("d\u0131k", -1, -1, 0),
        Among("t\u0131k", -1, -1, 0),
        Among("dim", -1, -1, 0),
        Among("tim", -1, -1, 0),
        Among("dum", -1, -1, 0),
        Among("tum", -1, -1, 0),
        Among("d\u00FCm", -1, -1, 0),
        Among("t\u00FCm", -1, -1, 0),
        Among("d\u0131m", -1, -1, 0),
        Among("t\u0131m", -1, -1, 0),
        Among("din", -1, -1, 0),
        Among("tin", -1, -1, 0),
        Among("dun", -1, -1, 0),
        Among("tun", -1, -1, 0),
        Among("d\u00FCn", -1, -1, 0),
        Among("t\u00FCn", -1, -1, 0),
        Among("d\u0131n", -1, -1, 0),
        Among("t\u0131n", -1, -1, 0),
        Among("du", -1, -1, 0),
        Among("tu", -1, -1, 0),
        Among("d\u00FC", -1, -1, 0),
        Among("t\u00FC", -1, -1, 0),
        Among("d\u0131", -1, -1, 0),
        Among("t\u0131", -1, -1, 0)
    ];

    static final a_21 = [
        Among("sa", -1, -1, 0),
        Among("se", -1, -1, 0),
        Among("sak", -1, -1, 0),
        Among("sek", -1, -1, 0),
        Among("sam", -1, -1, 0),
        Among("sem", -1, -1, 0),
        Among("san", -1, -1, 0),
        Among("sen", -1, -1, 0)
    ];

    static final a_22 = [
        Among("mi\u015F", -1, -1, 0),
        Among("mu\u015F", -1, -1, 0),
        Among("m\u00FC\u015F", -1, -1, 0),
        Among("m\u0131\u015F", -1, -1, 0)
    ];

    static final a_23 = [
        Among("b", -1, 1, 0),
        Among("c", -1, 2, 0),
        Among("d", -1, 3, 0),
        Among("\u011F", -1, 4, 0)
    ];

    static final g_vowel = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 8, 0, 0, 0, 0, 0, 0, 1]);

    static final g_U = String.fromCharCodes([1, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 1]);

    static final g_vowel1 = String.fromCharCodes([1, 64, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]);

    static final g_vowel2 = String.fromCharCodes([17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 130]);

    static final g_vowel3 = String.fromCharCodes([1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]);

    static final g_vowel4 = String.fromCharCodes([17]);

    static final g_vowel5 = String.fromCharCodes([65]);

    static final g_vowel6 = String.fromCharCodes([65]);


    bool r_check_vowel_harmony() {
        int v_1 = limit - cursor;
        if (!go_out_grouping_b(g_vowel, 97, 305))
        {
            return false;
        }
        lab0: while (true) {
            int v_2 = limit - cursor;
            lab1: while (true) {
                if (!(eq_s_b("a")))
                {
                    break lab1;
                }
                if (!go_out_grouping_b(g_vowel1, 97, 305))
                {
                    break lab1;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab2: while (true) {
                if (!(eq_s_b("e")))
                {
                    break lab2;
                }
                if (!go_out_grouping_b(g_vowel2, 101, 252))
                {
                    break lab2;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab3: while (true) {
                if (!(eq_s_b("\u0131")))
                {
                    break lab3;
                }
                if (!go_out_grouping_b(g_vowel3, 97, 305))
                {
                    break lab3;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab4: while (true) {
                if (!(eq_s_b("i")))
                {
                    break lab4;
                }
                if (!go_out_grouping_b(g_vowel4, 101, 105))
                {
                    break lab4;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab5: while (true) {
                if (!(eq_s_b("o")))
                {
                    break lab5;
                }
                if (!go_out_grouping_b(g_vowel5, 111, 117))
                {
                    break lab5;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab6: while (true) {
                if (!(eq_s_b("\u00F6")))
                {
                    break lab6;
                }
                if (!go_out_grouping_b(g_vowel6, 246, 252))
                {
                    break lab6;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab7: while (true) {
                if (!(eq_s_b("u")))
                {
                    break lab7;
                }
                if (!go_out_grouping_b(g_vowel5, 111, 117))
                {
                    break lab7;
                }
                break lab0;
            }
            cursor = limit - v_2;
            if (!(eq_s_b("\u00FC")))
            {
                return false;
            }
            if (!go_out_grouping_b(g_vowel6, 246, 252))
            {
                return false;
            }
            break lab0;
        }
        cursor = limit - v_1;
        return true;
    }

    bool r_mark_suffix_with_optional_n_consonant() {
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (!(eq_s_b("n")))
                {
                    break lab1;
                }
                int v_2 = limit - cursor;
                if (!(in_grouping_b(g_vowel, 97, 305)))
                {
                    break lab1;
                }
                cursor = limit - v_2;
                break lab0;
            }
            cursor = limit - v_1;
            lab2: while (true) {
                if (!(eq_s_b("n")))
                {
                    break lab2;
                }
                return false;
            }
            int v_3 = limit - cursor;
            if (cursor <= limit_backward)
            {
                return false;
            }
            cursor--;
            if (!(in_grouping_b(g_vowel, 97, 305)))
            {
                return false;
            }
            cursor = limit - v_3;
            break lab0;
        }
        return true;
    }

    bool r_mark_suffix_with_optional_y_consonant() {
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (!(eq_s_b("y")))
                {
                    break lab1;
                }
                int v_2 = limit - cursor;
                if (!(in_grouping_b(g_vowel, 97, 305)))
                {
                    break lab1;
                }
                cursor = limit - v_2;
                break lab0;
            }
            cursor = limit - v_1;
            lab2: while (true) {
                if (!(eq_s_b("y")))
                {
                    break lab2;
                }
                return false;
            }
            int v_3 = limit - cursor;
            if (cursor <= limit_backward)
            {
                return false;
            }
            cursor--;
            if (!(in_grouping_b(g_vowel, 97, 305)))
            {
                return false;
            }
            cursor = limit - v_3;
            break lab0;
        }
        return true;
    }

    bool r_mark_possessives() {
        if (find_among_b(a_0, null) == 0)
        {
            return false;
        }
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (!(in_grouping_b(g_U, 105, 305)))
                {
                    break lab1;
                }
                int v_2 = limit - cursor;
                if (!(out_grouping_b(g_vowel, 97, 305)))
                {
                    break lab1;
                }
                cursor = limit - v_2;
                break lab0;
            }
            cursor = limit - v_1;
            lab2: while (true) {
                if (!(in_grouping_b(g_U, 105, 305)))
                {
                    break lab2;
                }
                return false;
            }
            int v_3 = limit - cursor;
            if (cursor <= limit_backward)
            {
                return false;
            }
            cursor--;
            if (!(out_grouping_b(g_vowel, 97, 305)))
            {
                return false;
            }
            cursor = limit - v_3;
            break lab0;
        }
        return true;
    }

    bool r_mark_sU() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (!(in_grouping_b(g_U, 105, 305)))
        {
            return false;
        }
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (!(eq_s_b("s")))
                {
                    break lab1;
                }
                int v_2 = limit - cursor;
                if (!(in_grouping_b(g_vowel, 97, 305)))
                {
                    break lab1;
                }
                cursor = limit - v_2;
                break lab0;
            }
            cursor = limit - v_1;
            lab2: while (true) {
                if (!(eq_s_b("s")))
                {
                    break lab2;
                }
                return false;
            }
            int v_3 = limit - cursor;
            if (cursor <= limit_backward)
            {
                return false;
            }
            cursor--;
            if (!(in_grouping_b(g_vowel, 97, 305)))
            {
                return false;
            }
            cursor = limit - v_3;
            break lab0;
        }
        return true;
    }

    bool r_mark_lArI() {
        return find_among_b(a_1, null) != 0;
    }

    bool r_mark_nUn() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (find_among_b(a_3, null) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_n_consonant();
    }

    bool r_mark_DA() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        return find_among_b(a_6, null) != 0;
    }

    bool r_mark_ndA() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        return find_among_b(a_7, null) != 0;
    }

    bool r_mark_yUm() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (find_among_b(a_12, null) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_y_consonant();
    }

    bool r_mark_sUn() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        return find_among_b(a_13, null) != 0;
    }

    bool r_mark_yUz() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (find_among_b(a_14, null) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_y_consonant();
    }

    bool r_mark_sUnUz() {
        return find_among_b(a_15, null) != 0;
    }

    bool r_mark_lAr() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        return find_among_b(a_16, null) != 0;
    }

    bool r_mark_DUr() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        return find_among_b(a_18, null) != 0;
    }

    bool r_mark_yDU() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (find_among_b(a_20, null) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_y_consonant();
    }

    bool r_mark_ysA() {
        if (find_among_b(a_21, null) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_y_consonant();
    }

    bool r_mark_ymUs_() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (find_among_b(a_22, null) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_y_consonant();
    }

    bool r_stem_suffix_chain_before_ki() {
        ket = cursor;
        if (!(eq_s_b("ki")))
        {
            return false;
        }
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                if (!r_mark_DA())
                {
                    break lab1;
                }
                bra = cursor;
                slice_del();
                int v_2 = limit - cursor;
                lab2: while (true) {
                    ket = cursor;
                    lab3: while (true) {
                        int v_3 = limit - cursor;
                        lab4: while (true) {
                            if (!r_mark_lAr())
                            {
                                break lab4;
                            }
                            bra = cursor;
                            slice_del();
                            int v_4 = limit - cursor;
                            lab5: while (true) {
                                if (!r_stem_suffix_chain_before_ki())
                                {
                                    cursor = limit - v_4;
                                    break lab5;
                                }
                                break lab5;
                            }
                            break lab3;
                        }
                        cursor = limit - v_3;
                        if (!r_mark_possessives())
                        {
                            cursor = limit - v_2;
                            break lab2;
                        }
                        bra = cursor;
                        slice_del();
                        int v_5 = limit - cursor;
                        lab6: while (true) {
                            ket = cursor;
                            if (!r_mark_lAr())
                            {
                                cursor = limit - v_5;
                                break lab6;
                            }
                            bra = cursor;
                            slice_del();
                            if (!r_stem_suffix_chain_before_ki())
                            {
                                cursor = limit - v_5;
                                break lab6;
                            }
                            break lab6;
                        }
                        break lab3;
                    }
                    break lab2;
                }
                break lab0;
            }
            cursor = limit - v_1;
            lab7: while (true) {
                if (!r_mark_nUn())
                {
                    break lab7;
                }
                bra = cursor;
                slice_del();
                int v_6 = limit - cursor;
                lab8: while (true) {
                    ket = cursor;
                    lab9: while (true) {
                        int v_7 = limit - cursor;
                        lab10: while (true) {
                            if (!r_mark_lArI())
                            {
                                break lab10;
                            }
                            bra = cursor;
                            slice_del();
                            break lab9;
                        }
                        cursor = limit - v_7;
                        lab11: while (true) {
                            ket = cursor;
                            lab12: while (true) {
                                int v_8 = limit - cursor;
                                lab13: while (true) {
                                    if (!r_mark_possessives())
                                    {
                                        break lab13;
                                    }
                                    break lab12;
                                }
                                cursor = limit - v_8;
                                if (!r_mark_sU())
                                {
                                    break lab11;
                                }
                                break lab12;
                            }
                            bra = cursor;
                            slice_del();
                            int v_9 = limit - cursor;
                            lab14: while (true) {
                                ket = cursor;
                                if (!r_mark_lAr())
                                {
                                    cursor = limit - v_9;
                                    break lab14;
                                }
                                bra = cursor;
                                slice_del();
                                if (!r_stem_suffix_chain_before_ki())
                                {
                                    cursor = limit - v_9;
                                    break lab14;
                                }
                                break lab14;
                            }
                            break lab9;
                        }
                        cursor = limit - v_7;
                        if (!r_stem_suffix_chain_before_ki())
                        {
                            cursor = limit - v_6;
                            break lab8;
                        }
                        break lab9;
                    }
                    break lab8;
                }
                break lab0;
            }
            cursor = limit - v_1;
            if (!r_mark_ndA())
            {
                return false;
            }
            lab15: while (true) {
                int v_10 = limit - cursor;
                lab16: while (true) {
                    if (!r_mark_lArI())
                    {
                        break lab16;
                    }
                    bra = cursor;
                    slice_del();
                    break lab15;
                }
                cursor = limit - v_10;
                lab17: while (true) {
                    if (!r_mark_sU())
                    {
                        break lab17;
                    }
                    bra = cursor;
                    slice_del();
                    int v_11 = limit - cursor;
                    lab18: while (true) {
                        ket = cursor;
                        if (!r_mark_lAr())
                        {
                            cursor = limit - v_11;
                            break lab18;
                        }
                        bra = cursor;
                        slice_del();
                        if (!r_stem_suffix_chain_before_ki())
                        {
                            cursor = limit - v_11;
                            break lab18;
                        }
                        break lab18;
                    }
                    break lab15;
                }
                cursor = limit - v_10;
                if (!r_stem_suffix_chain_before_ki())
                {
                    return false;
                }
                break lab15;
            }
            break lab0;
        }
        return true;
    }

    @override
    bool stem() {
        int among_var;
        bool B_continue_stemming_noun_suffixes;
        lab0: while (true) {
            int v_1 = cursor;
            lab1: while (true) {
                bra = cursor;
                golab2: while(true)
                {
                    int v_2 = cursor;
                    lab3: while (true) {
                        lab4: while (true) {
                            if (!(eq_s("'")))
                            {
                                break lab4;
                            }
                            break lab3;
                        }
                        cursor = v_2;
                        break golab2;
                    }
                    cursor = v_2;
                    if (cursor >= limit)
                    {
                        break lab1;
                    }
                    cursor++;
                }
                ket = cursor;
                slice_del();
                break lab1;
            }
            cursor = v_1;
            int v_3 = cursor;
            lab5: while (true) {
                {
                    int c = cursor + 2;
                    if (c > limit)
                    {
                        break lab5;
                    }
                    cursor = c;
                }
                golab6: while(true)
                {
                    int v_4 = cursor;
                    lab7: while (true) {
                        if (!(eq_s("'")))
                        {
                            break lab7;
                        }
                        cursor = v_4;
                        break golab6;
                    }
                    cursor = v_4;
                    if (cursor >= limit)
                    {
                        break lab5;
                    }
                    cursor++;
                }
                bra = cursor;
                cursor = limit;
                ket = cursor;
                slice_del();
                break lab5;
            }
            cursor = v_3;
            break lab0;
        }
        int v_5 = cursor;
        for (int v_6 = 2; v_6 > 0; v_6--)
        {
            if (!go_out_grouping(g_vowel, 97, 305))
            {
                return false;
            }
            cursor++;
        }
        cursor = v_5;
        limit_backward = cursor;
        cursor = limit;
        int v_7 = limit - cursor;
        lab8: while (true) {
            ket = cursor;
            B_continue_stemming_noun_suffixes = true;
            lab9: while (true) {
                int v_8 = limit - cursor;
                lab10: while (true) {
                    lab11: while (true) {
                        int v_9 = limit - cursor;
                        lab12: while (true) {
                            if (!r_mark_ymUs_())
                            {
                                break lab12;
                            }
                            break lab11;
                        }
                        cursor = limit - v_9;
                        lab13: while (true) {
                            if (!r_mark_yDU())
                            {
                                break lab13;
                            }
                            break lab11;
                        }
                        cursor = limit - v_9;
                        lab14: while (true) {
                            if (!r_mark_ysA())
                            {
                                break lab14;
                            }
                            break lab11;
                        }
                        cursor = limit - v_9;
                        if (!(eq_s_b("ken")))
                        {
                            break lab10;
                        }
                        if (!r_mark_suffix_with_optional_y_consonant())
                        {
                            break lab10;
                        }
                        break lab11;
                    }
                    break lab9;
                }
                cursor = limit - v_8;
                lab15: while (true) {
                    if (find_among_b(a_19, null) == 0)
                    {
                        break lab15;
                    }
                    lab16: while (true) {
                        int v_10 = limit - cursor;
                        lab17: while (true) {
                            if (!r_mark_sUnUz())
                            {
                                break lab17;
                            }
                            break lab16;
                        }
                        cursor = limit - v_10;
                        lab18: while (true) {
                            if (!r_mark_lAr())
                            {
                                break lab18;
                            }
                            break lab16;
                        }
                        cursor = limit - v_10;
                        lab19: while (true) {
                            if (!r_mark_yUm())
                            {
                                break lab19;
                            }
                            break lab16;
                        }
                        cursor = limit - v_10;
                        lab20: while (true) {
                            if (!r_mark_sUn())
                            {
                                break lab20;
                            }
                            break lab16;
                        }
                        cursor = limit - v_10;
                        lab21: while (true) {
                            if (!r_mark_yUz())
                            {
                                break lab21;
                            }
                            break lab16;
                        }
                        cursor = limit - v_10;
                        break lab16;
                    }
                    if (!r_mark_ymUs_())
                    {
                        break lab15;
                    }
                    break lab9;
                }
                cursor = limit - v_8;
                lab22: while (true) {
                    if (!r_mark_lAr())
                    {
                        break lab22;
                    }
                    bra = cursor;
                    slice_del();
                    int v_11 = limit - cursor;
                    lab23: while (true) {
                        ket = cursor;
                        lab24: while (true) {
                            int v_12 = limit - cursor;
                            lab25: while (true) {
                                if (!r_mark_DUr())
                                {
                                    break lab25;
                                }
                                break lab24;
                            }
                            cursor = limit - v_12;
                            lab26: while (true) {
                                if (!r_mark_yDU())
                                {
                                    break lab26;
                                }
                                break lab24;
                            }
                            cursor = limit - v_12;
                            lab27: while (true) {
                                if (!r_mark_ysA())
                                {
                                    break lab27;
                                }
                                break lab24;
                            }
                            cursor = limit - v_12;
                            if (!r_mark_ymUs_())
                            {
                                cursor = limit - v_11;
                                break lab23;
                            }
                            break lab24;
                        }
                        break lab23;
                    }
                    B_continue_stemming_noun_suffixes = false;
                    break lab9;
                }
                cursor = limit - v_8;
                lab28: while (true) {
                    if (!r_check_vowel_harmony())
                    {
                        break lab28;
                    }
                    if (find_among_b(a_17, null) == 0)
                    {
                        break lab28;
                    }
                    lab29: while (true) {
                        int v_13 = limit - cursor;
                        lab30: while (true) {
                            if (!r_mark_yDU())
                            {
                                break lab30;
                            }
                            break lab29;
                        }
                        cursor = limit - v_13;
                        if (!r_mark_ysA())
                        {
                            break lab28;
                        }
                        break lab29;
                    }
                    break lab9;
                }
                cursor = limit - v_8;
                lab31: while (true) {
                    lab32: while (true) {
                        int v_14 = limit - cursor;
                        lab33: while (true) {
                            if (!r_mark_sUnUz())
                            {
                                break lab33;
                            }
                            break lab32;
                        }
                        cursor = limit - v_14;
                        lab34: while (true) {
                            if (!r_mark_yUz())
                            {
                                break lab34;
                            }
                            break lab32;
                        }
                        cursor = limit - v_14;
                        lab35: while (true) {
                            if (!r_mark_sUn())
                            {
                                break lab35;
                            }
                            break lab32;
                        }
                        cursor = limit - v_14;
                        if (!r_mark_yUm())
                        {
                            break lab31;
                        }
                        break lab32;
                    }
                    bra = cursor;
                    slice_del();
                    int v_15 = limit - cursor;
                    lab36: while (true) {
                        ket = cursor;
                        if (!r_mark_ymUs_())
                        {
                            cursor = limit - v_15;
                            break lab36;
                        }
                        break lab36;
                    }
                    break lab9;
                }
                cursor = limit - v_8;
                if (!r_mark_DUr())
                {
                    break lab8;
                }
                bra = cursor;
                slice_del();
                int v_16 = limit - cursor;
                lab37: while (true) {
                    ket = cursor;
                    lab38: while (true) {
                        int v_17 = limit - cursor;
                        lab39: while (true) {
                            if (!r_mark_sUnUz())
                            {
                                break lab39;
                            }
                            break lab38;
                        }
                        cursor = limit - v_17;
                        lab40: while (true) {
                            if (!r_mark_lAr())
                            {
                                break lab40;
                            }
                            break lab38;
                        }
                        cursor = limit - v_17;
                        lab41: while (true) {
                            if (!r_mark_yUm())
                            {
                                break lab41;
                            }
                            break lab38;
                        }
                        cursor = limit - v_17;
                        lab42: while (true) {
                            if (!r_mark_sUn())
                            {
                                break lab42;
                            }
                            break lab38;
                        }
                        cursor = limit - v_17;
                        lab43: while (true) {
                            if (!r_mark_yUz())
                            {
                                break lab43;
                            }
                            break lab38;
                        }
                        cursor = limit - v_17;
                        break lab38;
                    }
                    if (!r_mark_ymUs_())
                    {
                        cursor = limit - v_16;
                        break lab37;
                    }
                    break lab37;
                }
                break lab9;
            }
            bra = cursor;
            slice_del();
            break lab8;
        }
        cursor = limit - v_7;
        if (!B_continue_stemming_noun_suffixes)
        {
            return false;
        }
        int v_18 = limit - cursor;
        lab44: while (true) {
            lab45: while (true) {
                int v_19 = limit - cursor;
                lab46: while (true) {
                    ket = cursor;
                    if (!r_mark_lAr())
                    {
                        break lab46;
                    }
                    bra = cursor;
                    slice_del();
                    int v_20 = limit - cursor;
                    lab47: while (true) {
                        if (!r_stem_suffix_chain_before_ki())
                        {
                            cursor = limit - v_20;
                            break lab47;
                        }
                        break lab47;
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab48: while (true) {
                    ket = cursor;
                    if (!r_check_vowel_harmony())
                    {
                        break lab48;
                    }
                    if (find_among_b(a_11, null) == 0)
                    {
                        break lab48;
                    }
                    if (!r_mark_suffix_with_optional_n_consonant())
                    {
                        break lab48;
                    }
                    bra = cursor;
                    slice_del();
                    int v_21 = limit - cursor;
                    lab49: while (true) {
                        lab50: while (true) {
                            int v_22 = limit - cursor;
                            lab51: while (true) {
                                ket = cursor;
                                if (!r_mark_lArI())
                                {
                                    break lab51;
                                }
                                bra = cursor;
                                slice_del();
                                break lab50;
                            }
                            cursor = limit - v_22;
                            lab52: while (true) {
                                ket = cursor;
                                lab53: while (true) {
                                    int v_23 = limit - cursor;
                                    lab54: while (true) {
                                        if (!r_mark_possessives())
                                        {
                                            break lab54;
                                        }
                                        break lab53;
                                    }
                                    cursor = limit - v_23;
                                    if (!r_mark_sU())
                                    {
                                        break lab52;
                                    }
                                    break lab53;
                                }
                                bra = cursor;
                                slice_del();
                                int v_24 = limit - cursor;
                                lab55: while (true) {
                                    ket = cursor;
                                    if (!r_mark_lAr())
                                    {
                                        cursor = limit - v_24;
                                        break lab55;
                                    }
                                    bra = cursor;
                                    slice_del();
                                    if (!r_stem_suffix_chain_before_ki())
                                    {
                                        cursor = limit - v_24;
                                        break lab55;
                                    }
                                    break lab55;
                                }
                                break lab50;
                            }
                            cursor = limit - v_22;
                            ket = cursor;
                            if (!r_mark_lAr())
                            {
                                cursor = limit - v_21;
                                break lab49;
                            }
                            bra = cursor;
                            slice_del();
                            if (!r_stem_suffix_chain_before_ki())
                            {
                                cursor = limit - v_21;
                                break lab49;
                            }
                            break lab50;
                        }
                        break lab49;
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab56: while (true) {
                    ket = cursor;
                    lab57: while (true) {
                        int v_25 = limit - cursor;
                        lab58: while (true) {
                            if (!r_mark_ndA())
                            {
                                break lab58;
                            }
                            break lab57;
                        }
                        cursor = limit - v_25;
                        if (!r_check_vowel_harmony())
                        {
                            break lab56;
                        }
                        if (find_among_b(a_5, null) == 0)
                        {
                            break lab56;
                        }
                        break lab57;
                    }
                    lab59: while (true) {
                        int v_26 = limit - cursor;
                        lab60: while (true) {
                            if (!r_mark_lArI())
                            {
                                break lab60;
                            }
                            bra = cursor;
                            slice_del();
                            break lab59;
                        }
                        cursor = limit - v_26;
                        lab61: while (true) {
                            if (!r_mark_sU())
                            {
                                break lab61;
                            }
                            bra = cursor;
                            slice_del();
                            int v_27 = limit - cursor;
                            lab62: while (true) {
                                ket = cursor;
                                if (!r_mark_lAr())
                                {
                                    cursor = limit - v_27;
                                    break lab62;
                                }
                                bra = cursor;
                                slice_del();
                                if (!r_stem_suffix_chain_before_ki())
                                {
                                    cursor = limit - v_27;
                                    break lab62;
                                }
                                break lab62;
                            }
                            break lab59;
                        }
                        cursor = limit - v_26;
                        if (!r_stem_suffix_chain_before_ki())
                        {
                            break lab56;
                        }
                        break lab59;
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab63: while (true) {
                    ket = cursor;
                    lab64: while (true) {
                        int v_28 = limit - cursor;
                        lab65: while (true) {
                            if (!r_check_vowel_harmony())
                            {
                                break lab65;
                            }
                            if (find_among_b(a_9, null) == 0)
                            {
                                break lab65;
                            }
                            break lab64;
                        }
                        cursor = limit - v_28;
                        if (!r_check_vowel_harmony())
                        {
                            break lab63;
                        }
                        if (find_among_b(a_2, null) == 0)
                        {
                            break lab63;
                        }
                        break lab64;
                    }
                    lab66: while (true) {
                        int v_29 = limit - cursor;
                        lab67: while (true) {
                            if (!r_mark_sU())
                            {
                                break lab67;
                            }
                            bra = cursor;
                            slice_del();
                            int v_30 = limit - cursor;
                            lab68: while (true) {
                                ket = cursor;
                                if (!r_mark_lAr())
                                {
                                    cursor = limit - v_30;
                                    break lab68;
                                }
                                bra = cursor;
                                slice_del();
                                if (!r_stem_suffix_chain_before_ki())
                                {
                                    cursor = limit - v_30;
                                    break lab68;
                                }
                                break lab68;
                            }
                            break lab66;
                        }
                        cursor = limit - v_29;
                        if (!r_mark_lArI())
                        {
                            break lab63;
                        }
                        break lab66;
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab69: while (true) {
                    ket = cursor;
                    if (!r_check_vowel_harmony())
                    {
                        break lab69;
                    }
                    if (find_among_b(a_8, null) == 0)
                    {
                        break lab69;
                    }
                    bra = cursor;
                    slice_del();
                    int v_31 = limit - cursor;
                    lab70: while (true) {
                        ket = cursor;
                        lab71: while (true) {
                            int v_32 = limit - cursor;
                            lab72: while (true) {
                                if (!r_mark_possessives())
                                {
                                    break lab72;
                                }
                                bra = cursor;
                                slice_del();
                                int v_33 = limit - cursor;
                                lab73: while (true) {
                                    ket = cursor;
                                    if (!r_mark_lAr())
                                    {
                                        cursor = limit - v_33;
                                        break lab73;
                                    }
                                    bra = cursor;
                                    slice_del();
                                    if (!r_stem_suffix_chain_before_ki())
                                    {
                                        cursor = limit - v_33;
                                        break lab73;
                                    }
                                    break lab73;
                                }
                                break lab71;
                            }
                            cursor = limit - v_32;
                            lab74: while (true) {
                                if (!r_mark_lAr())
                                {
                                    break lab74;
                                }
                                bra = cursor;
                                slice_del();
                                int v_34 = limit - cursor;
                                lab75: while (true) {
                                    if (!r_stem_suffix_chain_before_ki())
                                    {
                                        cursor = limit - v_34;
                                        break lab75;
                                    }
                                    break lab75;
                                }
                                break lab71;
                            }
                            cursor = limit - v_32;
                            if (!r_stem_suffix_chain_before_ki())
                            {
                                cursor = limit - v_31;
                                break lab70;
                            }
                            break lab71;
                        }
                        break lab70;
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab76: while (true) {
                    ket = cursor;
                    lab77: while (true) {
                        int v_35 = limit - cursor;
                        lab78: while (true) {
                            if (!r_mark_nUn())
                            {
                                break lab78;
                            }
                            break lab77;
                        }
                        cursor = limit - v_35;
                        if (!r_check_vowel_harmony())
                        {
                            break lab76;
                        }
                        if (find_among_b(a_10, null) == 0)
                        {
                            break lab76;
                        }
                        if (!r_mark_suffix_with_optional_y_consonant())
                        {
                            break lab76;
                        }
                        break lab77;
                    }
                    bra = cursor;
                    slice_del();
                    int v_36 = limit - cursor;
                    lab79: while (true) {
                        lab80: while (true) {
                            int v_37 = limit - cursor;
                            lab81: while (true) {
                                ket = cursor;
                                if (!r_mark_lAr())
                                {
                                    break lab81;
                                }
                                bra = cursor;
                                slice_del();
                                if (!r_stem_suffix_chain_before_ki())
                                {
                                    break lab81;
                                }
                                break lab80;
                            }
                            cursor = limit - v_37;
                            lab82: while (true) {
                                ket = cursor;
                                lab83: while (true) {
                                    int v_38 = limit - cursor;
                                    lab84: while (true) {
                                        if (!r_mark_possessives())
                                        {
                                            break lab84;
                                        }
                                        break lab83;
                                    }
                                    cursor = limit - v_38;
                                    if (!r_mark_sU())
                                    {
                                        break lab82;
                                    }
                                    break lab83;
                                }
                                bra = cursor;
                                slice_del();
                                int v_39 = limit - cursor;
                                lab85: while (true) {
                                    ket = cursor;
                                    if (!r_mark_lAr())
                                    {
                                        cursor = limit - v_39;
                                        break lab85;
                                    }
                                    bra = cursor;
                                    slice_del();
                                    if (!r_stem_suffix_chain_before_ki())
                                    {
                                        cursor = limit - v_39;
                                        break lab85;
                                    }
                                    break lab85;
                                }
                                break lab80;
                            }
                            cursor = limit - v_37;
                            if (!r_stem_suffix_chain_before_ki())
                            {
                                cursor = limit - v_36;
                                break lab79;
                            }
                            break lab80;
                        }
                        break lab79;
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab86: while (true) {
                    ket = cursor;
                    if (!r_mark_lArI())
                    {
                        break lab86;
                    }
                    bra = cursor;
                    slice_del();
                    break lab45;
                }
                cursor = limit - v_19;
                lab87: while (true) {
                    if (!r_stem_suffix_chain_before_ki())
                    {
                        break lab87;
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab88: while (true) {
                    ket = cursor;
                    lab89: while (true) {
                        int v_40 = limit - cursor;
                        lab90: while (true) {
                            if (!r_mark_DA())
                            {
                                break lab90;
                            }
                            break lab89;
                        }
                        cursor = limit - v_40;
                        lab91: while (true) {
                            if (!r_check_vowel_harmony())
                            {
                                break lab91;
                            }
                            if (!(in_grouping_b(g_U, 105, 305)))
                            {
                                break lab91;
                            }
                            if (!r_mark_suffix_with_optional_y_consonant())
                            {
                                break lab91;
                            }
                            break lab89;
                        }
                        cursor = limit - v_40;
                        if (!r_check_vowel_harmony())
                        {
                            break lab88;
                        }
                        if (find_among_b(a_4, null) == 0)
                        {
                            break lab88;
                        }
                        if (!r_mark_suffix_with_optional_y_consonant())
                        {
                            break lab88;
                        }
                        break lab89;
                    }
                    bra = cursor;
                    slice_del();
                    int v_41 = limit - cursor;
                    lab92: while (true) {
                        ket = cursor;
                        lab93: while (true) {
                            int v_42 = limit - cursor;
                            lab94: while (true) {
                                if (!r_mark_possessives())
                                {
                                    break lab94;
                                }
                                bra = cursor;
                                slice_del();
                                int v_43 = limit - cursor;
                                lab95: while (true) {
                                    ket = cursor;
                                    if (!r_mark_lAr())
                                    {
                                        cursor = limit - v_43;
                                        break lab95;
                                    }
                                    break lab95;
                                }
                                break lab93;
                            }
                            cursor = limit - v_42;
                            if (!r_mark_lAr())
                            {
                                cursor = limit - v_41;
                                break lab92;
                            }
                            break lab93;
                        }
                        bra = cursor;
                        slice_del();
                        ket = cursor;
                        if (!r_stem_suffix_chain_before_ki())
                        {
                            cursor = limit - v_41;
                            break lab92;
                        }
                        break lab92;
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                ket = cursor;
                lab96: while (true) {
                    int v_44 = limit - cursor;
                    lab97: while (true) {
                        if (!r_mark_possessives())
                        {
                            break lab97;
                        }
                        break lab96;
                    }
                    cursor = limit - v_44;
                    if (!r_mark_sU())
                    {
                        break lab44;
                    }
                    break lab96;
                }
                bra = cursor;
                slice_del();
                int v_45 = limit - cursor;
                lab98: while (true) {
                    ket = cursor;
                    if (!r_mark_lAr())
                    {
                        cursor = limit - v_45;
                        break lab98;
                    }
                    bra = cursor;
                    slice_del();
                    if (!r_stem_suffix_chain_before_ki())
                    {
                        cursor = limit - v_45;
                        break lab98;
                    }
                    break lab98;
                }
                break lab45;
            }
            break lab44;
        }
        cursor = limit - v_18;
        cursor = limit_backward;
        limit_backward = cursor;
        cursor = limit;
        {
            int v_46 = limit - cursor;
            lab99: while (true) {
                if (!(eq_s_b("ad")))
                {
                    break lab99;
                }
                int v_47 = limit - cursor;
                lab100: while (true) {
                    if (!(eq_s_b("soy")))
                    {
                        cursor = limit - v_47;
                        break lab100;
                    }
                    break lab100;
                }
                if (cursor > limit_backward)
                {
                    break lab99;
                }
                return false;
            }
            cursor = limit - v_46;
        }
        int v_48 = limit - cursor;
        lab101: while (true) {
            ket = cursor;
            bra = cursor;
            lab102: while (true) {
                lab103: while (true) {
                    if (!(eq_s_b("d")))
                    {
                        break lab103;
                    }
                    break lab102;
                }
                if (!(eq_s_b("g")))
                {
                    break lab101;
                }
                break lab102;
            }
            if (!go_out_grouping_b(g_vowel, 97, 305))
            {
                break lab101;
            }
            lab104: while (true) {
                int v_49 = limit - cursor;
                lab105: while (true) {
                    lab106: while (true) {
                        lab107: while (true) {
                            if (!(eq_s_b("a")))
                            {
                                break lab107;
                            }
                            break lab106;
                        }
                        if (!(eq_s_b("\u0131")))
                        {
                            break lab105;
                        }
                        break lab106;
                    }
                    slice_from("\u0131");
                    break lab104;
                }
                cursor = limit - v_49;
                lab108: while (true) {
                    lab109: while (true) {
                        lab110: while (true) {
                            if (!(eq_s_b("e")))
                            {
                                break lab110;
                            }
                            break lab109;
                        }
                        if (!(eq_s_b("i")))
                        {
                            break lab108;
                        }
                        break lab109;
                    }
                    slice_from("i");
                    break lab104;
                }
                cursor = limit - v_49;
                lab111: while (true) {
                    lab112: while (true) {
                        lab113: while (true) {
                            if (!(eq_s_b("o")))
                            {
                                break lab113;
                            }
                            break lab112;
                        }
                        if (!(eq_s_b("u")))
                        {
                            break lab111;
                        }
                        break lab112;
                    }
                    slice_from("u");
                    break lab104;
                }
                cursor = limit - v_49;
                lab114: while (true) {
                    lab115: while (true) {
                        if (!(eq_s_b("\u00F6")))
                        {
                            break lab115;
                        }
                        break lab114;
                    }
                    if (!(eq_s_b("\u00FC")))
                    {
                        break lab101;
                    }
                    break lab114;
                }
                slice_from("\u00FC");
                break lab104;
            }
            break lab101;
        }
        cursor = limit - v_48;
        int v_50 = limit - cursor;
        lab116: while (true) {
            ket = cursor;
            among_var = find_among_b(a_23, null);
            if (among_var == 0)
            {
                break lab116;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_from("p");
                    break;
                case 2:
                    slice_from("\u00E7");
                    break;
                case 3:
                    slice_from("t");
                    break;
                case 4:
                    slice_from("k");
                    break;
            }
            break lab116;
        }
        cursor = limit - v_50;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is turkish_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
