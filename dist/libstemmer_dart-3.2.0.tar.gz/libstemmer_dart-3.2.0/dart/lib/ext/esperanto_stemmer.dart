// Generated from esperanto.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from esperanto.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class esperanto_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 14, 0),
        Among("-", 0, 13, 0),
        Among("cx", 0, 1, 0),
        Among("gx", 0, 2, 0),
        Among("hx", 0, 3, 0),
        Among("jx", 0, 4, 0),
        Among("q", 0, 12, 0),
        Among("sx", 0, 5, 0),
        Among("ux", 0, 6, 0),
        Among("w", 0, 12, 0),
        Among("x", 0, 12, 0),
        Among("y", 0, 12, 0),
        Among("\u00E1", 0, 7, 0),
        Among("\u00E9", 0, 8, 0),
        Among("\u00ED", 0, 9, 0),
        Among("\u00F3", 0, 10, 0),
        Among("\u00FA", 0, 11, 0)
    ];

    static final a_1 = [
        Among("as", -1, -1, 0),
        Among("i", -1, -1, 0),
        Among("is", 1, -1, 0),
        Among("os", -1, -1, 0),
        Among("u", -1, -1, 0),
        Among("us", 4, -1, 0)
    ];

    static final a_2 = [
        Among("ci", -1, -1, 0),
        Among("gi", -1, -1, 0),
        Among("hi", -1, -1, 0),
        Among("li", -1, -1, 0),
        Among("ili", 3, -1, 0),
        Among("\u015Dli", 3, -1, 0),
        Among("mi", -1, -1, 0),
        Among("ni", -1, -1, 0),
        Among("oni", 7, -1, 0),
        Among("ri", -1, -1, 0),
        Among("si", -1, -1, 0),
        Among("vi", -1, -1, 0),
        Among("ivi", 11, -1, 0),
        Among("\u011Di", -1, -1, 0),
        Among("\u015Di", -1, -1, 0),
        Among("i\u015Di", 14, -1, 0),
        Among("mal\u015Di", 14, -1, 0)
    ];

    static final a_3 = [
        Among("amb", -1, -1, 0),
        Among("bald", -1, -1, 0),
        Among("malbald", 1, -1, 0),
        Among("morg", -1, -1, 0),
        Among("postmorg", 3, -1, 0),
        Among("adi", -1, -1, 0),
        Among("hodi", -1, -1, 0),
        Among("ank", -1, -1, 0),
        Among("\u0109irk", -1, -1, 0),
        Among("tut\u0109irk", 8, -1, 0),
        Among("presk", -1, -1, 0),
        Among("almen", -1, -1, 0),
        Among("apen", -1, -1, 0),
        Among("hier", -1, -1, 0),
        Among("anta\u016Dhier", 13, -1, 0),
        Among("malgr", -1, -1, 0),
        Among("ankor", -1, -1, 0),
        Among("kontr", -1, -1, 0),
        Among("anstat", -1, -1, 0),
        Among("kvaz", -1, -1, 0)
    ];

    static final a_4 = [
        Among("aliu", -1, -1, 0),
        Among("unu", -1, -1, 0)
    ];

    static final a_5 = [
        Among("aha", -1, -1, 0),
        Among("haha", 0, -1, 0),
        Among("haleluja", -1, -1, 0),
        Among("hola", -1, -1, 0),
        Among("hosana", -1, -1, 0),
        Among("maltra", -1, -1, 0),
        Among("hura", -1, -1, 0),
        Among("\u0125a\u0125a", -1, -1, 0),
        Among("ekde", -1, -1, 0),
        Among("elde", -1, -1, 0),
        Among("disde", -1, -1, 0),
        Among("ehe", -1, -1, 0),
        Among("maltre", -1, -1, 0),
        Among("dirlididi", -1, -1, 0),
        Among("malpli", -1, -1, 0),
        Among("mal\u0109i", -1, -1, 0),
        Among("malkaj", -1, -1, 0),
        Among("amen", -1, -1, 0),
        Among("tamen", 17, -1, 0),
        Among("oho", -1, -1, 0),
        Among("maltro", -1, -1, 0),
        Among("minus", -1, -1, 0),
        Among("uhu", -1, -1, 0),
        Among("muu", -1, -1, 0)
    ];

    static final a_6 = [
        Among("tri", -1, -1, 0),
        Among("du", -1, -1, 0),
        Among("unu", -1, -1, 0)
    ];

    static final a_7 = [
        Among("dek", -1, -1, 0),
        Among("cent", -1, -1, 0)
    ];

    static final a_8 = [
        Among("k", -1, -1, 0),
        Among("kelk", 0, -1, 0),
        Among("nen", -1, -1, 0),
        Among("t", -1, -1, 0),
        Among("mult", 3, -1, 0),
        Among("samt", 3, -1, 0),
        Among("\u0109", -1, -1, 0)
    ];

    static final a_9 = [
        Among("a", -1, -1, 0),
        Among("e", -1, -1, 0),
        Among("i", -1, -1, 0),
        Among("j", -1, 1, 0),
        Among("aj", 3, -1, 0),
        Among("oj", 3, -1, 0),
        Among("n", -1, 1, 0),
        Among("an", 6, -1, 0),
        Among("en", 6, -1, 0),
        Among("jn", 6, 1, 0),
        Among("ajn", 9, -1, 0),
        Among("ojn", 9, -1, 0),
        Among("on", 6, -1, 0),
        Among("o", -1, -1, 0),
        Among("as", -1, -1, 0),
        Among("is", -1, -1, 0),
        Among("os", -1, -1, 0),
        Among("us", -1, -1, 0),
        Among("u", -1, -1, 0)
    ];

    static final g_vowel = String.fromCharCodes([17, 65, 16]);

    static final g_aou = String.fromCharCodes([1, 64, 16]);

    static final g_digit = String.fromCharCodes([255, 3]);


    @override
    bool stem() {
        int among_var;
        bool B_foreign;
        int v_1 = cursor;
        B_foreign = false;
        replab0: while(true)
        {
            int v_2 = cursor;
            lab1: while (true) {
                bra = cursor;
                among_var = find_among(a_0, null);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("\u0109");
                        break;
                    case 2:
                        slice_from("\u011D");
                        break;
                    case 3:
                        slice_from("\u0125");
                        break;
                    case 4:
                        slice_from("\u0135");
                        break;
                    case 5:
                        slice_from("\u015D");
                        break;
                    case 6:
                        slice_from("\u016D");
                        break;
                    case 7:
                        slice_from("a");
                        B_foreign = true;
                        break;
                    case 8:
                        slice_from("e");
                        B_foreign = true;
                        break;
                    case 9:
                        slice_from("i");
                        B_foreign = true;
                        break;
                    case 10:
                        slice_from("o");
                        B_foreign = true;
                        break;
                    case 11:
                        slice_from("u");
                        B_foreign = true;
                        break;
                    case 12:
                        B_foreign = true;
                        break;
                    case 13:
                        B_foreign = false;
                        break;
                    case 14:
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break;
                }
                continue replab0;
            }
            cursor = v_2;
            break replab0;
        }
        if (B_foreign)
        {
            return false;
        }
        cursor = v_1;
        int v_3 = cursor;
        lab2: while (true) {
            bra = cursor;
            if (!(eq_s("'")))
            {
                break lab2;
            }
            ket = cursor;
            if (!(eq_s("st")))
            {
                break lab2;
            }
            if (find_among(a_1, null) == 0)
            {
                break lab2;
            }
            if (cursor < limit)
            {
                break lab2;
            }
            slice_from("e");
            break lab2;
        }
        cursor = v_3;
        limit_backward = cursor;
        cursor = limit;
        {
            int v_4 = limit - cursor;
            lab3: while (true) {
                ket = cursor;
                int v_5 = limit - cursor;
                lab4: while (true) {
                    if (!(eq_s_b("n")))
                    {
                        cursor = limit - v_5;
                        break lab4;
                    }
                    break lab4;
                }
                bra = cursor;
                if (find_among_b(a_2, null) == 0)
                {
                    break lab3;
                }
                lab5: while (true) {
                    lab6: while (true) {
                        if (cursor > limit_backward)
                        {
                            break lab6;
                        }
                        break lab5;
                    }
                    if (!(eq_s_b("-")))
                    {
                        break lab3;
                    }
                    break lab5;
                }
                slice_del();
                return false;
            }
            cursor = limit - v_4;
        }
        int v_6 = limit - cursor;
        lab7: while (true) {
            ket = cursor;
            if (!(eq_s_b("'")))
            {
                break lab7;
            }
            bra = cursor;
            lab8: while (true) {
                int v_7 = limit - cursor;
                lab9: while (true) {
                    if (!(eq_s_b("l")))
                    {
                        break lab9;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab9;
                    }
                    slice_from("a");
                    break lab8;
                }
                cursor = limit - v_7;
                lab10: while (true) {
                    if (!(eq_s_b("un")))
                    {
                        break lab10;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab10;
                    }
                    slice_from("u");
                    break lab8;
                }
                cursor = limit - v_7;
                lab11: while (true) {
                    if (find_among_b(a_3, null) == 0)
                    {
                        break lab11;
                    }
                    lab12: while (true) {
                        lab13: while (true) {
                            if (cursor > limit_backward)
                            {
                                break lab13;
                            }
                            break lab12;
                        }
                        if (!(eq_s_b("-")))
                        {
                            break lab11;
                        }
                        break lab12;
                    }
                    slice_from("a\u016D");
                    break lab8;
                }
                cursor = limit - v_7;
                slice_from("o");
                break lab8;
            }
            break lab7;
        }
        cursor = limit - v_6;
        {
            int v_8 = limit - cursor;
            lab14: while (true) {
                ket = cursor;
                bra = cursor;
                int v_9 = limit - cursor;
                lab15: while (true) {
                    int v_10 = limit - cursor;
                    lab16: while (true) {
                        int v_11 = limit - cursor;
                        lab17: while (true) {
                            if (!(eq_s_b("n")))
                            {
                                cursor = limit - v_11;
                                break lab17;
                            }
                            break lab17;
                        }
                        bra = cursor;
                        if (!(eq_s_b("e")))
                        {
                            break lab16;
                        }
                        break lab15;
                    }
                    cursor = limit - v_10;
                    int v_12 = limit - cursor;
                    lab18: while (true) {
                        if (!(eq_s_b("n")))
                        {
                            cursor = limit - v_12;
                            break lab18;
                        }
                        break lab18;
                    }
                    int v_13 = limit - cursor;
                    lab19: while (true) {
                        if (!(eq_s_b("j")))
                        {
                            cursor = limit - v_13;
                            break lab19;
                        }
                        break lab19;
                    }
                    bra = cursor;
                    if (!(in_grouping_b(g_aou, 97, 117)))
                    {
                        break lab14;
                    }
                    break lab15;
                }
                if (!(eq_s_b("i")))
                {
                    break lab14;
                }
                int v_14 = limit - cursor;
                lab20: while (true) {
                    if (find_among_b(a_8, null) == 0)
                    {
                        cursor = limit - v_14;
                        break lab20;
                    }
                    break lab20;
                }
                lab21: while (true) {
                    lab22: while (true) {
                        if (cursor > limit_backward)
                        {
                            break lab22;
                        }
                        break lab21;
                    }
                    if (!(eq_s_b("-")))
                    {
                        break lab14;
                    }
                    break lab21;
                }
                cursor = limit - v_9;
                slice_del();
                return false;
            }
            cursor = limit - v_8;
        }
        {
            int v_15 = limit - cursor;
            lab23: while (true) {
                if (find_among_b(a_5, null) == 0)
                {
                    break lab23;
                }
                lab24: while (true) {
                    lab25: while (true) {
                        if (cursor > limit_backward)
                        {
                            break lab25;
                        }
                        break lab24;
                    }
                    if (!(eq_s_b("-")))
                    {
                        break lab23;
                    }
                    break lab24;
                }
                return false;
            }
            cursor = limit - v_15;
        }
        {
            int v_16 = limit - cursor;
            lab26: while (true) {
                if (find_among_b(a_6, null) == 0)
                {
                    break lab26;
                }
                if (find_among_b(a_7, null) == 0)
                {
                    break lab26;
                }
                return false;
            }
            cursor = limit - v_16;
        }
        {
            int v_17 = limit - cursor;
            lab27: while (true) {
                ket = cursor;
                int v_18 = limit - cursor;
                lab28: while (true) {
                    if (!(eq_s_b("n")))
                    {
                        cursor = limit - v_18;
                        break lab28;
                    }
                    break lab28;
                }
                int v_19 = limit - cursor;
                lab29: while (true) {
                    if (!(eq_s_b("j")))
                    {
                        cursor = limit - v_19;
                        break lab29;
                    }
                    break lab29;
                }
                bra = cursor;
                if (find_among_b(a_4, null) == 0)
                {
                    break lab27;
                }
                lab30: while (true) {
                    lab31: while (true) {
                        if (cursor > limit_backward)
                        {
                            break lab31;
                        }
                        break lab30;
                    }
                    if (!(eq_s_b("-")))
                    {
                        break lab27;
                    }
                    break lab30;
                }
                slice_del();
                return false;
            }
            cursor = limit - v_17;
        }
        int v_20 = limit - cursor;
        lab32: while (true) {
            int v_21 = limit - cursor;
            lab33: while (true) {
                for (int v_22 = 2; v_22 > 0; v_22--)
                {
                    if (!go_out_grouping_b(g_vowel, 97, 117))
                    {
                        break lab33;
                    }
                    cursor--;
                }
                break lab32;
            }
            cursor = limit - v_21;
            lab34: while (true) {
                golab35: while(true)
                {
                    lab36: while (true) {
                        if (!(eq_s_b("-")))
                        {
                            break lab36;
                        }
                        break golab35;
                    }
                    if (cursor <= limit_backward)
                    {
                        break lab34;
                    }
                    cursor--;
                }
                if (cursor <= limit_backward)
                {
                    break lab34;
                }
                cursor--;
                break lab32;
            }
            cursor = limit - v_21;
            if (!go_out_grouping_b(g_digit, 48, 57))
            {
                return false;
            }
            cursor--;
            break lab32;
        }
        cursor = limit - v_20;
        ket = cursor;
        among_var = find_among_b(a_9, null);
        if (among_var == 0)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                int v_23 = limit - cursor;
                lab37: while (true) {
                    lab38: while (true) {
                        if (!(eq_s_b("-")))
                        {
                            break lab38;
                        }
                        break lab37;
                    }
                    if (!(in_grouping_b(g_digit, 48, 57)))
                    {
                        return false;
                    }
                    break lab37;
                }
                cursor = limit - v_23;
                break;
        }
        int v_24 = limit - cursor;
        lab39: while (true) {
            if (!(eq_s_b("-")))
            {
                cursor = limit - v_24;
                break lab39;
            }
            break lab39;
        }
        bra = cursor;
        slice_del();
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is esperanto_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
