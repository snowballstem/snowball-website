// Generated from finnish.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from finnish.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class finnish_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("pa", -1, 1, 0),
        Among("sti", -1, 2, 0),
        Among("kaan", -1, 1, 0),
        Among("han", -1, 1, 0),
        Among("kin", -1, 1, 0),
        Among("h\u00E4n", -1, 1, 0),
        Among("k\u00E4\u00E4n", -1, 1, 0),
        Among("ko", -1, 1, 0),
        Among("p\u00E4", -1, 1, 0),
        Among("k\u00F6", -1, 1, 0)
    ];

    static final a_1 = [
        Among("lla", -1, -1, 0),
        Among("na", -1, -1, 0),
        Among("ssa", -1, -1, 0),
        Among("ta", -1, -1, 0),
        Among("lta", 3, -1, 0),
        Among("sta", 3, -1, 0)
    ];

    static final a_2 = [
        Among("ll\u00E4", -1, -1, 0),
        Among("n\u00E4", -1, -1, 0),
        Among("ss\u00E4", -1, -1, 0),
        Among("t\u00E4", -1, -1, 0),
        Among("lt\u00E4", 3, -1, 0),
        Among("st\u00E4", 3, -1, 0)
    ];

    static final a_3 = [
        Among("lle", -1, -1, 0),
        Among("ine", -1, -1, 0)
    ];

    static final a_4 = [
        Among("nsa", -1, 3, 0),
        Among("mme", -1, 3, 0),
        Among("nne", -1, 3, 0),
        Among("ni", -1, 2, 0),
        Among("si", -1, 1, 0),
        Among("an", -1, 4, 0),
        Among("en", -1, 6, 0),
        Among("\u00E4n", -1, 5, 0),
        Among("ns\u00E4", -1, 3, 0)
    ];

    static final a_5 = [
        Among("aa", -1, -1, 0),
        Among("ee", -1, -1, 0),
        Among("ii", -1, -1, 0),
        Among("oo", -1, -1, 0),
        Among("uu", -1, -1, 0),
        Among("\u00E4\u00E4", -1, -1, 0),
        Among("\u00F6\u00F6", -1, -1, 0)
    ];

    static final a_6 = [
        Among("'", -1, -1, 0),
        Among("ai", -1, -1, 0),
        Among("ei", -1, -1, 0),
        Among("ii", -1, -1, 0),
        Among("oi", -1, -1, 0),
        Among("ui", -1, -1, 0),
        Among("\u00E4i", -1, -1, 0),
        Among("\u00F6i", -1, -1, 0)
    ];

    static final a_7 = [
        Among("a", -1, 2, 0),
        Among("lla", 0, -1, 0),
        Among("na", 0, -1, 0),
        Among("ssa", 0, -1, 0),
        Among("ta", 0, -1, 0),
        Among("lta", 4, -1, 0),
        Among("sta", 4, -1, 0),
        Among("tta", 4, 3, 0),
        Among("lle", -1, -1, 0),
        Among("ine", -1, -1, 0),
        Among("ksi", -1, -1, 0),
        Among("n", -1, 1, 0),
        Among("han", 11, -1, 3),
        Among("den", 11, -1, 8),
        Among("seen", 11, -1, 9),
        Among("hen", 11, -1, 4),
        Among("tten", 11, -1, 8),
        Among("hin", 11, -1, 5),
        Among("siin", 11, -1, 8),
        Among("hon", 11, -1, 6),
        Among("hun", 11, -1, 7),
        Among("h\u00E4n", 11, -1, 1),
        Among("h\u00F6n", 11, -1, 2),
        Among("\u00E4", -1, 2, 0),
        Among("ll\u00E4", 23, -1, 0),
        Among("n\u00E4", 23, -1, 0),
        Among("ss\u00E4", 23, -1, 0),
        Among("t\u00E4", 23, -1, 0),
        Among("lt\u00E4", 27, -1, 0),
        Among("st\u00E4", 27, -1, 0),
        Among("tt\u00E4", 27, 3, 0)
    ];


    bool af_7() {
        switch (af) {
            case 1: return r_A_();
            case 2: return r_O_();
            case 3: return r_A();
            case 4: return r_E();
            case 5: return r_I();
            case 6: return r_O();
            case 7: return r_U();
            case 8: return r_VI();
            case 9: return r_LV();
        }
        return false;
    }
    static final a_8 = [
        Among("eja", -1, -1, 0),
        Among("mma", -1, 1, 0),
        Among("imma", 1, -1, 0),
        Among("mpa", -1, 1, 0),
        Among("impa", 3, -1, 0),
        Among("mmi", -1, 1, 0),
        Among("immi", 5, -1, 0),
        Among("mpi", -1, 1, 0),
        Among("impi", 7, -1, 0),
        Among("ej\u00E4", -1, -1, 0),
        Among("mm\u00E4", -1, 1, 0),
        Among("imm\u00E4", 10, -1, 0),
        Among("mp\u00E4", -1, 1, 0),
        Among("imp\u00E4", 12, -1, 0)
    ];

    static final a_9 = [
        Among("i", -1, -1, 0),
        Among("j", -1, -1, 0)
    ];

    static final a_10 = [
        Among("mma", -1, 1, 0),
        Among("imma", 0, -1, 0)
    ];

    static final g_AEI = String.fromCharCodes([17, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8]);

    static final g_C = String.fromCharCodes([119, 223, 119, 1]);

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32]);

    static final g_particle_end = String.fromCharCodes([17, 97, 24, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32]);


    bool r_LV() {
        return find_among_b(a_5, null) != 0;
    }

    bool r_VI() {
        return find_among_b(a_6, null) != 0;
    }

    bool r_A() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("a")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_E() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("e")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_I() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("i")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_O() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("o")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_U() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("u")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_A_() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("\u00E4")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    bool r_O_() {
        lab0: while (true) {
            lab1: while (true) {
                if (!(eq_s_b("\u00F6")))
                {
                    break lab1;
                }
                break lab0;
            }
            lab2: while (true) {
                if (!(eq_s_b("\u00F8")))
                {
                    break lab2;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
            break lab0;
        }
        return true;
    }

    @override
    bool stem() {
        int among_var;
        bool B_ending_removed;
        String S_x;
        int I_p2;
        int I_p1;
        int v_1 = cursor;
        lab0: while (true) {
            I_p1 = limit;
            I_p2 = limit;
            if (!go_out_grouping(g_v, 97, 246))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 246))
            {
                break lab0;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 246))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 246))
            {
                break lab0;
            }
            cursor++;
            I_p2 = cursor;
            break lab0;
        }
        cursor = v_1;
        B_ending_removed = false;
        limit_backward = cursor;
        cursor = limit;
        int v_2 = limit - cursor;
        lab1: while (true) {
            if (cursor < I_p1)
            {
                break lab1;
            }
            int v_3 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            among_var = find_among_b(a_0, null);
            if (among_var == 0)
            {
                limit_backward = v_3;
                break lab1;
            }
            bra = cursor;
            limit_backward = v_3;
            switch (among_var) {
                case 1:
                    if (!(in_grouping_b(g_particle_end, 97, 246)))
                    {
                        break lab1;
                    }
                    break;
                case 2:
                    if (I_p2 > cursor)
                    {
                        break lab1;
                    }
                    break;
            }
            slice_del();
            break lab1;
        }
        cursor = limit - v_2;
        int v_4 = limit - cursor;
        lab2: while (true) {
            if (cursor < I_p1)
            {
                break lab2;
            }
            int v_5 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            among_var = find_among_b(a_4, null);
            if (among_var == 0)
            {
                limit_backward = v_5;
                break lab2;
            }
            bra = cursor;
            limit_backward = v_5;
            switch (among_var) {
                case 1:
                    lab3: while (true) {
                        if (!(eq_s_b("k")))
                        {
                            break lab3;
                        }
                        break lab2;
                    }
                    slice_del();
                    break;
                case 2:
                    slice_del();
                    ket = cursor;
                    if (!(eq_s_b("kse")))
                    {
                        break lab2;
                    }
                    bra = cursor;
                    slice_from("ksi");
                    break;
                case 3:
                    slice_del();
                    break;
                case 4:
                    if (find_among_b(a_1, null) == 0)
                    {
                        break lab2;
                    }
                    slice_del();
                    break;
                case 5:
                    if (find_among_b(a_2, null) == 0)
                    {
                        break lab2;
                    }
                    slice_del();
                    break;
                case 6:
                    if (find_among_b(a_3, null) == 0)
                    {
                        break lab2;
                    }
                    slice_del();
                    break;
            }
            break lab2;
        }
        cursor = limit - v_4;
        int v_6 = limit - cursor;
        lab4: while (true) {
            if (cursor < I_p1)
            {
                break lab4;
            }
            int v_7 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            among_var = find_among_b(a_7, af_7);
            if (among_var == 0)
            {
                limit_backward = v_7;
                break lab4;
            }
            bra = cursor;
            limit_backward = v_7;
            switch (among_var) {
                case 1:
                    int v_8 = limit - cursor;
                    lab5: while (true) {
                        int v_9 = limit - cursor;
                        lab6: while (true) {
                            int v_10 = limit - cursor;
                            lab7: while (true) {
                                if (!r_LV())
                                {
                                    break lab7;
                                }
                                break lab6;
                            }
                            cursor = limit - v_10;
                            if (!(eq_s_b("ie")))
                            {
                                cursor = limit - v_8;
                                break lab5;
                            }
                            break lab6;
                        }
                        cursor = limit - v_9;
                        if (cursor <= limit_backward)
                        {
                            cursor = limit - v_8;
                            break lab5;
                        }
                        cursor--;
                        bra = cursor;
                        break lab5;
                    }
                    break;
                case 2:
                    if (!(in_grouping_b(g_v, 97, 246)))
                    {
                        break lab4;
                    }
                    if (!(in_grouping_b(g_C, 98, 122)))
                    {
                        break lab4;
                    }
                    break;
                case 3:
                    if (!(eq_s_b("e")))
                    {
                        break lab4;
                    }
                    break;
            }
            slice_del();
            B_ending_removed = true;
            break lab4;
        }
        cursor = limit - v_6;
        int v_11 = limit - cursor;
        lab8: while (true) {
            if (cursor < I_p2)
            {
                break lab8;
            }
            int v_12 = limit_backward;
            limit_backward = I_p2;
            ket = cursor;
            among_var = find_among_b(a_8, null);
            if (among_var == 0)
            {
                limit_backward = v_12;
                break lab8;
            }
            bra = cursor;
            limit_backward = v_12;
            switch (among_var) {
                case 1:
                    lab9: while (true) {
                        if (!(eq_s_b("po")))
                        {
                            break lab9;
                        }
                        break lab8;
                    }
                    break;
            }
            slice_del();
            break lab8;
        }
        cursor = limit - v_11;
        lab10: while (true) {
            lab11: while (true) {
                if (!B_ending_removed)
                {
                    break lab11;
                }
                int v_13 = limit - cursor;
                lab12: while (true) {
                    if (cursor < I_p1)
                    {
                        break lab12;
                    }
                    int v_14 = limit_backward;
                    limit_backward = I_p1;
                    ket = cursor;
                    if (find_among_b(a_9, null) == 0)
                    {
                        limit_backward = v_14;
                        break lab12;
                    }
                    bra = cursor;
                    limit_backward = v_14;
                    slice_del();
                    break lab12;
                }
                cursor = limit - v_13;
                break lab10;
            }
            int v_15 = limit - cursor;
            lab13: while (true) {
                if (cursor < I_p1)
                {
                    break lab13;
                }
                int v_16 = limit_backward;
                limit_backward = I_p1;
                ket = cursor;
                if (!(eq_s_b("t")))
                {
                    limit_backward = v_16;
                    break lab13;
                }
                bra = cursor;
                int v_17 = limit - cursor;
                if (!(in_grouping_b(g_v, 97, 246)))
                {
                    limit_backward = v_16;
                    break lab13;
                }
                cursor = limit - v_17;
                slice_del();
                limit_backward = v_16;
                if (cursor < I_p2)
                {
                    break lab13;
                }
                int v_18 = limit_backward;
                limit_backward = I_p2;
                ket = cursor;
                among_var = find_among_b(a_10, null);
                if (among_var == 0)
                {
                    limit_backward = v_18;
                    break lab13;
                }
                bra = cursor;
                limit_backward = v_18;
                switch (among_var) {
                    case 1:
                        lab14: while (true) {
                            if (!(eq_s_b("po")))
                            {
                                break lab14;
                            }
                            break lab13;
                        }
                        break;
                }
                slice_del();
                break lab13;
            }
            cursor = limit - v_15;
            break lab10;
        }
        int v_19 = limit - cursor;
        lab15: while (true) {
            if (cursor < I_p1)
            {
                break lab15;
            }
            int v_20 = limit_backward;
            limit_backward = I_p1;
            int v_21 = limit - cursor;
            lab16: while (true) {
                int v_22 = limit - cursor;
                if (!r_LV())
                {
                    break lab16;
                }
                cursor = limit - v_22;
                ket = cursor;
                if (cursor <= limit_backward)
                {
                    break lab16;
                }
                cursor--;
                bra = cursor;
                slice_del();
                break lab16;
            }
            cursor = limit - v_21;
            int v_23 = limit - cursor;
            lab17: while (true) {
                ket = cursor;
                if (!(in_grouping_b(g_AEI, 97, 228)))
                {
                    break lab17;
                }
                bra = cursor;
                if (!(in_grouping_b(g_C, 98, 122)))
                {
                    break lab17;
                }
                slice_del();
                break lab17;
            }
            cursor = limit - v_23;
            int v_24 = limit - cursor;
            lab18: while (true) {
                ket = cursor;
                if (!(eq_s_b("j")))
                {
                    break lab18;
                }
                bra = cursor;
                lab19: while (true) {
                    lab20: while (true) {
                        if (!(eq_s_b("o")))
                        {
                            break lab20;
                        }
                        break lab19;
                    }
                    if (!(eq_s_b("u")))
                    {
                        break lab18;
                    }
                    break lab19;
                }
                slice_del();
                break lab18;
            }
            cursor = limit - v_24;
            int v_25 = limit - cursor;
            lab21: while (true) {
                ket = cursor;
                if (!(eq_s_b("o")))
                {
                    break lab21;
                }
                bra = cursor;
                if (!(eq_s_b("j")))
                {
                    break lab21;
                }
                slice_del();
                break lab21;
            }
            cursor = limit - v_25;
            limit_backward = v_20;
            int v_26 = limit - cursor;
            lab22: while (true) {
                if (!go_in_grouping_b(g_v, 97, 246))
                {
                    break lab22;
                }
                ket = cursor;
                if (!(in_grouping_b(g_C, 98, 122)))
                {
                    break lab22;
                }
                bra = cursor;
                S_x = slice_to();
                if (!(eq_s_b(S_x)))
                {
                    break lab22;
                }
                slice_del();
                break lab22;
            }
            cursor = limit - v_26;
            ket = cursor;
            if (!(eq_s_b("'")))
            {
                break lab15;
            }
            bra = cursor;
            slice_del();
            break lab15;
        }
        cursor = limit - v_19;
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is finnish_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
