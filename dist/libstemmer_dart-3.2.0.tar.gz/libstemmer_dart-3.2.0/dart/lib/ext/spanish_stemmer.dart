// Generated from spanish.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from spanish.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class spanish_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 6, 0),
        Among("\u00E1", 0, 1, 0),
        Among("\u00E9", 0, 2, 0),
        Among("\u00ED", 0, 3, 0),
        Among("\u00F3", 0, 4, 0),
        Among("\u00FA", 0, 5, 0)
    ];

    static final a_1 = [
        Among("la", -1, -1, 0),
        Among("sela", 0, -1, 0),
        Among("le", -1, -1, 0),
        Among("me", -1, -1, 0),
        Among("se", -1, -1, 0),
        Among("lo", -1, -1, 0),
        Among("selo", 5, -1, 0),
        Among("las", -1, -1, 0),
        Among("selas", 7, -1, 0),
        Among("les", -1, -1, 0),
        Among("los", -1, -1, 0),
        Among("selos", 10, -1, 0),
        Among("nos", -1, -1, 0)
    ];

    static final a_2 = [
        Among("ando", -1, 6, 0),
        Among("iendo", -1, 6, 0),
        Among("yendo", -1, 7, 0),
        Among("\u00E1ndo", -1, 2, 0),
        Among("i\u00E9ndo", -1, 1, 0),
        Among("ar", -1, 6, 0),
        Among("er", -1, 6, 0),
        Among("ir", -1, 6, 0),
        Among("\u00E1r", -1, 3, 0),
        Among("\u00E9r", -1, 4, 0),
        Among("\u00EDr", -1, 5, 0)
    ];

    static final a_3 = [
        Among("ic", -1, -1, 0),
        Among("ad", -1, -1, 0),
        Among("os", -1, -1, 0),
        Among("iv", -1, 1, 0)
    ];

    static final a_4 = [
        Among("able", -1, 1, 0),
        Among("ible", -1, 1, 0),
        Among("ante", -1, 1, 0)
    ];

    static final a_5 = [
        Among("ic", -1, 1, 0),
        Among("abil", -1, 1, 0),
        Among("iv", -1, 1, 0)
    ];

    static final a_6 = [
        Among("ica", -1, 1, 0),
        Among("ancia", -1, 2, 0),
        Among("encia", -1, 5, 0),
        Among("adora", -1, 2, 0),
        Among("osa", -1, 1, 0),
        Among("ista", -1, 1, 0),
        Among("iva", -1, 9, 0),
        Among("anza", -1, 1, 0),
        Among("log\u00EDa", -1, 3, 0),
        Among("idad", -1, 8, 0),
        Among("able", -1, 1, 0),
        Among("ible", -1, 1, 0),
        Among("ante", -1, 2, 0),
        Among("mente", -1, 7, 0),
        Among("amente", 13, 6, 0),
        Among("acion", -1, 2, 0),
        Among("ucion", -1, 4, 0),
        Among("aci\u00F3n", -1, 2, 0),
        Among("uci\u00F3n", -1, 4, 0),
        Among("ico", -1, 1, 0),
        Among("ismo", -1, 1, 0),
        Among("oso", -1, 1, 0),
        Among("amiento", -1, 1, 0),
        Among("imiento", -1, 1, 0),
        Among("ivo", -1, 9, 0),
        Among("ador", -1, 2, 0),
        Among("icas", -1, 1, 0),
        Among("ancias", -1, 2, 0),
        Among("encias", -1, 5, 0),
        Among("adoras", -1, 2, 0),
        Among("osas", -1, 1, 0),
        Among("istas", -1, 1, 0),
        Among("ivas", -1, 9, 0),
        Among("anzas", -1, 1, 0),
        Among("log\u00EDas", -1, 3, 0),
        Among("idades", -1, 8, 0),
        Among("ables", -1, 1, 0),
        Among("ibles", -1, 1, 0),
        Among("aciones", -1, 2, 0),
        Among("uciones", -1, 4, 0),
        Among("adores", -1, 2, 0),
        Among("antes", -1, 2, 0),
        Among("icos", -1, 1, 0),
        Among("ismos", -1, 1, 0),
        Among("osos", -1, 1, 0),
        Among("amientos", -1, 1, 0),
        Among("imientos", -1, 1, 0),
        Among("ivos", -1, 9, 0)
    ];

    static final a_7 = [
        Among("ya", -1, 1, 0),
        Among("ye", -1, 1, 0),
        Among("yan", -1, 1, 0),
        Among("yen", -1, 1, 0),
        Among("yeron", -1, 1, 0),
        Among("yendo", -1, 1, 0),
        Among("yo", -1, 1, 0),
        Among("yas", -1, 1, 0),
        Among("yes", -1, 1, 0),
        Among("yais", -1, 1, 0),
        Among("yamos", -1, 1, 0),
        Among("y\u00F3", -1, 1, 0)
    ];

    static final a_8 = [
        Among("aba", -1, 2, 0),
        Among("ada", -1, 2, 0),
        Among("ida", -1, 2, 0),
        Among("ara", -1, 2, 0),
        Among("iera", -1, 2, 0),
        Among("\u00EDa", -1, 2, 0),
        Among("ar\u00EDa", 5, 2, 0),
        Among("er\u00EDa", 5, 2, 0),
        Among("ir\u00EDa", 5, 2, 0),
        Among("ad", -1, 2, 0),
        Among("ed", -1, 2, 0),
        Among("id", -1, 2, 0),
        Among("ase", -1, 2, 0),
        Among("iese", -1, 2, 0),
        Among("aste", -1, 2, 0),
        Among("iste", -1, 2, 0),
        Among("an", -1, 2, 0),
        Among("aban", 16, 2, 0),
        Among("aran", 16, 2, 0),
        Among("ieran", 16, 2, 0),
        Among("\u00EDan", 16, 2, 0),
        Among("ar\u00EDan", 20, 2, 0),
        Among("er\u00EDan", 20, 2, 0),
        Among("ir\u00EDan", 20, 2, 0),
        Among("en", -1, 1, 0),
        Among("asen", 24, 2, 0),
        Among("iesen", 24, 2, 0),
        Among("aron", -1, 2, 0),
        Among("ieron", -1, 2, 0),
        Among("ar\u00E1n", -1, 2, 0),
        Among("er\u00E1n", -1, 2, 0),
        Among("ir\u00E1n", -1, 2, 0),
        Among("ado", -1, 2, 0),
        Among("ido", -1, 2, 0),
        Among("ando", -1, 2, 0),
        Among("iendo", -1, 2, 0),
        Among("ar", -1, 2, 0),
        Among("er", -1, 2, 0),
        Among("ir", -1, 2, 0),
        Among("as", -1, 2, 0),
        Among("abas", 39, 2, 0),
        Among("adas", 39, 2, 0),
        Among("idas", 39, 2, 0),
        Among("aras", 39, 2, 0),
        Among("ieras", 39, 2, 0),
        Among("\u00EDas", 39, 2, 0),
        Among("ar\u00EDas", 45, 2, 0),
        Among("er\u00EDas", 45, 2, 0),
        Among("ir\u00EDas", 45, 2, 0),
        Among("es", -1, 1, 0),
        Among("ases", 49, 2, 0),
        Among("ieses", 49, 2, 0),
        Among("abais", -1, 2, 0),
        Among("arais", -1, 2, 0),
        Among("ierais", -1, 2, 0),
        Among("\u00EDais", -1, 2, 0),
        Among("ar\u00EDais", 55, 2, 0),
        Among("er\u00EDais", 55, 2, 0),
        Among("ir\u00EDais", 55, 2, 0),
        Among("aseis", -1, 2, 0),
        Among("ieseis", -1, 2, 0),
        Among("asteis", -1, 2, 0),
        Among("isteis", -1, 2, 0),
        Among("\u00E1is", -1, 2, 0),
        Among("\u00E9is", -1, 1, 0),
        Among("ar\u00E9is", 64, 2, 0),
        Among("er\u00E9is", 64, 2, 0),
        Among("ir\u00E9is", 64, 2, 0),
        Among("ados", -1, 2, 0),
        Among("idos", -1, 2, 0),
        Among("amos", -1, 2, 0),
        Among("\u00E1bamos", 70, 2, 0),
        Among("\u00E1ramos", 70, 2, 0),
        Among("i\u00E9ramos", 70, 2, 0),
        Among("\u00EDamos", 70, 2, 0),
        Among("ar\u00EDamos", 74, 2, 0),
        Among("er\u00EDamos", 74, 2, 0),
        Among("ir\u00EDamos", 74, 2, 0),
        Among("emos", -1, 1, 0),
        Among("aremos", 78, 2, 0),
        Among("eremos", 78, 2, 0),
        Among("iremos", 78, 2, 0),
        Among("\u00E1semos", 78, 2, 0),
        Among("i\u00E9semos", 78, 2, 0),
        Among("imos", -1, 2, 0),
        Among("ar\u00E1s", -1, 2, 0),
        Among("er\u00E1s", -1, 2, 0),
        Among("ir\u00E1s", -1, 2, 0),
        Among("\u00EDs", -1, 2, 0),
        Among("ar\u00E1", -1, 2, 0),
        Among("er\u00E1", -1, 2, 0),
        Among("ir\u00E1", -1, 2, 0),
        Among("ar\u00E9", -1, 2, 0),
        Among("er\u00E9", -1, 2, 0),
        Among("ir\u00E9", -1, 2, 0),
        Among("i\u00F3", -1, 2, 0)
    ];

    static final a_9 = [
        Among("a", -1, 1, 0),
        Among("e", -1, 2, 0),
        Among("o", -1, 1, 0),
        Among("os", -1, 1, 0),
        Among("\u00E1", -1, 1, 0),
        Among("\u00E9", -1, 2, 0),
        Among("\u00ED", -1, 1, 0),
        Among("\u00F3", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 17, 4, 10]);


    @override
    bool stem() {
        int among_var;
        int I_p2;
        int I_p1;
        int I_pV;
        lab0: while (true) {
            I_pV = limit;
            I_p1 = limit;
            I_p2 = limit;
            int v_1 = cursor;
            lab1: while (true) {
                lab2: while (true) {
                    int v_2 = cursor;
                    lab3: while (true) {
                        if (!(in_grouping(g_v, 97, 252)))
                        {
                            break lab3;
                        }
                        lab4: while (true) {
                            int v_3 = cursor;
                            lab5: while (true) {
                                if (!(out_grouping(g_v, 97, 252)))
                                {
                                    break lab5;
                                }
                                if (!go_out_grouping(g_v, 97, 252))
                                {
                                    break lab5;
                                }
                                cursor++;
                                break lab4;
                            }
                            cursor = v_3;
                            if (!(in_grouping(g_v, 97, 252)))
                            {
                                break lab3;
                            }
                            if (!go_in_grouping(g_v, 97, 252))
                            {
                                break lab3;
                            }
                            cursor++;
                            break lab4;
                        }
                        break lab2;
                    }
                    cursor = v_2;
                    if (!(out_grouping(g_v, 97, 252)))
                    {
                        break lab1;
                    }
                    lab6: while (true) {
                        int v_4 = cursor;
                        lab7: while (true) {
                            if (!(out_grouping(g_v, 97, 252)))
                            {
                                break lab7;
                            }
                            if (!go_out_grouping(g_v, 97, 252))
                            {
                                break lab7;
                            }
                            cursor++;
                            break lab6;
                        }
                        cursor = v_4;
                        if (!(in_grouping(g_v, 97, 252)))
                        {
                            break lab1;
                        }
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                        break lab6;
                    }
                    break lab2;
                }
                I_pV = cursor;
                break lab1;
            }
            cursor = v_1;
            int v_5 = cursor;
            lab8: while (true) {
                if (!go_out_grouping(g_v, 97, 252))
                {
                    break lab8;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 252))
                {
                    break lab8;
                }
                cursor++;
                I_p1 = cursor;
                if (!go_out_grouping(g_v, 97, 252))
                {
                    break lab8;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 252))
                {
                    break lab8;
                }
                cursor++;
                I_p2 = cursor;
                break lab8;
            }
            cursor = v_5;
            break lab0;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_6 = limit - cursor;
        lab9: while (true) {
            ket = cursor;
            if (find_among_b(a_1, null) == 0)
            {
                break lab9;
            }
            bra = cursor;
            among_var = find_among_b(a_2, null);
            if (among_var == 0)
            {
                break lab9;
            }
            if (I_pV > cursor)
            {
                break lab9;
            }
            switch (among_var) {
                case 1:
                    bra = cursor;
                    slice_from("iendo");
                    break;
                case 2:
                    bra = cursor;
                    slice_from("ando");
                    break;
                case 3:
                    bra = cursor;
                    slice_from("ar");
                    break;
                case 4:
                    bra = cursor;
                    slice_from("er");
                    break;
                case 5:
                    bra = cursor;
                    slice_from("ir");
                    break;
                case 6:
                    slice_del();
                    break;
                case 7:
                    if (!(eq_s_b("u")))
                    {
                        break lab9;
                    }
                    slice_del();
                    break;
            }
            break lab9;
        }
        cursor = limit - v_6;
        int v_7 = limit - cursor;
        lab10: while (true) {
            lab11: while (true) {
                int v_8 = limit - cursor;
                lab12: while (true) {
                    ket = cursor;
                    among_var = find_among_b(a_6, null);
                    if (among_var == 0)
                    {
                        break lab12;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            break;
                        case 2:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            int v_9 = limit - cursor;
                            lab13: while (true) {
                                ket = cursor;
                                if (!(eq_s_b("ic")))
                                {
                                    cursor = limit - v_9;
                                    break lab13;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_9;
                                    break lab13;
                                }
                                slice_del();
                                break lab13;
                            }
                            break;
                        case 3:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_from("log");
                            break;
                        case 4:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_from("u");
                            break;
                        case 5:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_from("ente");
                            break;
                        case 6:
                            if (I_p1 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            int v_10 = limit - cursor;
                            lab14: while (true) {
                                ket = cursor;
                                among_var = find_among_b(a_3, null);
                                if (among_var == 0)
                                {
                                    cursor = limit - v_10;
                                    break lab14;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_10;
                                    break lab14;
                                }
                                slice_del();
                                switch (among_var) {
                                    case 1:
                                        ket = cursor;
                                        if (!(eq_s_b("at")))
                                        {
                                            cursor = limit - v_10;
                                            break lab14;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_10;
                                            break lab14;
                                        }
                                        slice_del();
                                        break;
                                }
                                break lab14;
                            }
                            break;
                        case 7:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            int v_11 = limit - cursor;
                            lab15: while (true) {
                                ket = cursor;
                                if (find_among_b(a_4, null) == 0)
                                {
                                    cursor = limit - v_11;
                                    break lab15;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_11;
                                    break lab15;
                                }
                                slice_del();
                                break lab15;
                            }
                            break;
                        case 8:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            int v_12 = limit - cursor;
                            lab16: while (true) {
                                ket = cursor;
                                if (find_among_b(a_5, null) == 0)
                                {
                                    cursor = limit - v_12;
                                    break lab16;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_12;
                                    break lab16;
                                }
                                slice_del();
                                break lab16;
                            }
                            break;
                        case 9:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            int v_13 = limit - cursor;
                            lab17: while (true) {
                                ket = cursor;
                                if (!(eq_s_b("at")))
                                {
                                    cursor = limit - v_13;
                                    break lab17;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_13;
                                    break lab17;
                                }
                                slice_del();
                                break lab17;
                            }
                            break;
                    }
                    break lab11;
                }
                cursor = limit - v_8;
                lab18: while (true) {
                    if (cursor < I_pV)
                    {
                        break lab18;
                    }
                    int v_14 = limit_backward;
                    limit_backward = I_pV;
                    ket = cursor;
                    if (find_among_b(a_7, null) == 0)
                    {
                        limit_backward = v_14;
                        break lab18;
                    }
                    bra = cursor;
                    limit_backward = v_14;
                    if (!(eq_s_b("u")))
                    {
                        break lab18;
                    }
                    slice_del();
                    break lab11;
                }
                cursor = limit - v_8;
                if (cursor < I_pV)
                {
                    break lab10;
                }
                int v_15 = limit_backward;
                limit_backward = I_pV;
                ket = cursor;
                among_var = find_among_b(a_8, null);
                if (among_var == 0)
                {
                    limit_backward = v_15;
                    break lab10;
                }
                bra = cursor;
                limit_backward = v_15;
                switch (among_var) {
                    case 1:
                        int v_16 = limit - cursor;
                        lab19: while (true) {
                            if (!(eq_s_b("u")))
                            {
                                cursor = limit - v_16;
                                break lab19;
                            }
                            int v_17 = limit - cursor;
                            if (!(eq_s_b("g")))
                            {
                                cursor = limit - v_16;
                                break lab19;
                            }
                            cursor = limit - v_17;
                            break lab19;
                        }
                        bra = cursor;
                        slice_del();
                        break;
                    case 2:
                        slice_del();
                        break;
                }
                break lab11;
            }
            break lab10;
        }
        cursor = limit - v_7;
        int v_18 = limit - cursor;
        lab20: while (true) {
            ket = cursor;
            among_var = find_among_b(a_9, null);
            if (among_var == 0)
            {
                break lab20;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    if (I_pV > cursor)
                    {
                        break lab20;
                    }
                    slice_del();
                    break;
                case 2:
                    if (I_pV > cursor)
                    {
                        break lab20;
                    }
                    slice_del();
                    int v_19 = limit - cursor;
                    lab21: while (true) {
                        ket = cursor;
                        if (!(eq_s_b("u")))
                        {
                            cursor = limit - v_19;
                            break lab21;
                        }
                        bra = cursor;
                        int v_20 = limit - cursor;
                        if (!(eq_s_b("g")))
                        {
                            cursor = limit - v_19;
                            break lab21;
                        }
                        cursor = limit - v_20;
                        if (I_pV > cursor)
                        {
                            cursor = limit - v_19;
                            break lab21;
                        }
                        slice_del();
                        break lab21;
                    }
                    break;
            }
            break lab20;
        }
        cursor = limit - v_18;
        cursor = limit_backward;
        int v_21 = cursor;
        lab22: while (true) {
            replab23: while(true)
            {
                int v_22 = cursor;
                lab24: while (true) {
                    bra = cursor;
                    among_var = find_among(a_0, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("a");
                            break;
                        case 2:
                            slice_from("e");
                            break;
                        case 3:
                            slice_from("i");
                            break;
                        case 4:
                            slice_from("o");
                            break;
                        case 5:
                            slice_from("u");
                            break;
                        case 6:
                            if (cursor >= limit)
                            {
                                break lab24;
                            }
                            cursor++;
                            break;
                    }
                    continue replab23;
                }
                cursor = v_22;
                break replab23;
            }
            break lab22;
        }
        cursor = v_21;
        return true;
    }

    @override
    bool operator ==(Object other) => other is spanish_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
