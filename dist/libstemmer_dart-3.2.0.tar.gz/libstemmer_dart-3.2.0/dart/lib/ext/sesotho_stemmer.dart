// Generated from sesotho.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from sesotho.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class sesotho_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("ba", -1, -1, 0),
        Among("boi", -1, -1, 0),
        Among("le", -1, -1, 0),
        Among("li", -1, -1, 0),
        Among("ma", -1, -1, 0),
        Among("me", -1, -1, 0),
        Among("mo", -1, -1, 0),
        Among("se", -1, -1, 0)
    ];

    static final a_1 = [
        Among("a", -1, 1, 0),
        Among("ela", 0, 1, 0),
        Among("isa", 0, 1, 0),
        Among("wa", 0, 1, 0),
        Among("ile", -1, 1, 0),
        Among("etse", -1, 1, 0),
        Among("ang", -1, 1, 0),
        Among("eng", -1, 1, 0),
        Among("ong", -1, 1, 0)
    ];

    static final a_2 = [
        Among("ana", -1, 1, 0),
        Among("nyana", 0, 1, 0),
        Among("oa", -1, 1, 0),
        Among("i", -1, 1, 0),
        Among("ano", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16]);


    @override
    bool stem() {
        int I_pV;
        int v_1 = cursor;
        if (!go_out_grouping(g_v, 97, 117))
        {
            return false;
        }
        cursor++;
        I_pV = cursor;
        cursor = v_1;
        int v_2 = cursor;
        {
            int c = cursor + 2;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        lab0: while (true) {
            if (cursor <= I_pV)
            {
                break lab0;
            }
            I_pV = cursor;
            break lab0;
        }
        cursor = v_2;
        limit_backward = cursor;
        cursor = limit;
        int v_3 = limit - cursor;
        lab1: while (true) {
            if (cursor < I_pV)
            {
                break lab1;
            }
            int v_4 = limit_backward;
            limit_backward = I_pV;
            ket = cursor;
            if (find_among_b(a_2, null) == 0)
            {
                limit_backward = v_4;
                break lab1;
            }
            bra = cursor;
            slice_del();
            limit_backward = v_4;
            break lab1;
        }
        cursor = limit - v_3;
        int v_5 = limit - cursor;
        lab2: while (true) {
            if (cursor < I_pV)
            {
                break lab2;
            }
            int v_6 = limit_backward;
            limit_backward = I_pV;
            ket = cursor;
            if (find_among_b(a_1, null) == 0)
            {
                limit_backward = v_6;
                break lab2;
            }
            bra = cursor;
            slice_del();
            limit_backward = v_6;
            break lab2;
        }
        cursor = limit - v_5;
        cursor = limit_backward;
        int v_7 = cursor;
        lab3: while (true) {
            bra = cursor;
            if (find_among(a_0, null) == 0)
            {
                break lab3;
            }
            ket = cursor;
            int v_8 = cursor;
            if (cursor >= limit)
            {
                break lab3;
            }
            cursor++;
            if (cursor >= limit)
            {
                break lab3;
            }
            cursor = v_8;
            if (!go_out_grouping(g_v, 97, 117))
            {
                break lab3;
            }
            cursor++;
            slice_del();
            break lab3;
        }
        cursor = v_7;
        return true;
    }

    @override
    bool operator ==(Object other) => other is sesotho_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
