// Generated from yiddish.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from yiddish.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class yiddish_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("\u05D5\u05D5", -1, 1, 0),
        Among("\u05D5\u05D9", -1, 2, 0),
        Among("\u05D9\u05D9", -1, 3, 0),
        Among("\u05DA", -1, 4, 0),
        Among("\u05DD", -1, 5, 0),
        Among("\u05DF", -1, 6, 0),
        Among("\u05E3", -1, 7, 0),
        Among("\u05E5", -1, 8, 0)
    ];

    static final a_1 = [
        Among("\u05D0\u05D3\u05D5\u05E8\u05DB", -1, 1, 0),
        Among("\u05D0\u05D4\u05D9\u05E0", -1, 1, 0),
        Among("\u05D0\u05D4\u05E2\u05E8", -1, 1, 0),
        Among("\u05D0\u05D4\u05F2\u05DE", -1, 1, 0),
        Among("\u05D0\u05D5\u05DE", -1, 1, 0),
        Among("\u05D0\u05D5\u05E0\u05D8\u05E2\u05E8", -1, 1, 0),
        Among("\u05D0\u05D9\u05D1\u05E2\u05E8", -1, 1, 0),
        Among("\u05D0\u05E0", -1, 1, 0),
        Among("\u05D0\u05E0\u05D8", 7, 1, 0),
        Among("\u05D0\u05E0\u05D8\u05E7\u05E2\u05D2\u05E0", 8, 1, 0),
        Among("\u05D0\u05E0\u05D9\u05D3\u05E2\u05E8", 7, 1, 0),
        Among("\u05D0\u05E4", -1, 1, 0),
        Among("\u05D0\u05E4\u05D9\u05E8", 11, 1, 0),
        Among("\u05D0\u05E7\u05E2\u05D2\u05E0", -1, 1, 0),
        Among("\u05D0\u05E8\u05D0\u05E4", -1, 1, 0),
        Among("\u05D0\u05E8\u05D5\u05DE", -1, 1, 0),
        Among("\u05D0\u05E8\u05D5\u05E0\u05D8\u05E2\u05E8", -1, 1, 0),
        Among("\u05D0\u05E8\u05D9\u05D1\u05E2\u05E8", -1, 1, 0),
        Among("\u05D0\u05E8\u05F1\u05E1", -1, 1, 0),
        Among("\u05D0\u05E8\u05F1\u05E4", -1, 1, 0),
        Among("\u05D0\u05E8\u05F2\u05E0", -1, 1, 0),
        Among("\u05D0\u05F0\u05E2\u05E7", -1, 1, 0),
        Among("\u05D0\u05F1\u05E1", -1, 1, 0),
        Among("\u05D0\u05F1\u05E4", -1, 1, 0),
        Among("\u05D0\u05F2\u05E0", -1, 1, 0),
        Among("\u05D1\u05D0", -1, 1, 0),
        Among("\u05D1\u05F2", -1, 1, 0),
        Among("\u05D3\u05D5\u05E8\u05DB", -1, 1, 0),
        Among("\u05D3\u05E2\u05E8", -1, 1, 0),
        Among("\u05DE\u05D9\u05D8", -1, 1, 0),
        Among("\u05E0\u05D0\u05DB", -1, 1, 0),
        Among("\u05E4\u05D0\u05E8", -1, 1, 0),
        Among("\u05E4\u05D0\u05E8\u05D1\u05F2", 31, 1, 0),
        Among("\u05E4\u05D0\u05E8\u05F1\u05E1", 31, 1, 0),
        Among("\u05E4\u05D5\u05E0\u05D0\u05E0\u05D3\u05E2\u05E8", -1, 1, 0),
        Among("\u05E6\u05D5", -1, 1, 0),
        Among("\u05E6\u05D5\u05D6\u05D0\u05DE\u05E2\u05E0", 35, 1, 0),
        Among("\u05E6\u05D5\u05E0\u05F1\u05E4", 35, 1, 0),
        Among("\u05E6\u05D5\u05E8\u05D9\u05E7", 35, 1, 0),
        Among("\u05E6\u05E2", -1, 1, 0)
    ];

    static final a_2 = [
        Among("\u05D3\u05D6\u05E9", -1, -1, 0),
        Among("\u05E9\u05D8\u05E8", -1, -1, 0),
        Among("\u05E9\u05D8\u05E9", -1, -1, 0),
        Among("\u05E9\u05E4\u05E8", -1, -1, 0)
    ];

    static final a_3 = [
        Among("\u05E7\u05DC\u05D9\u05D1", -1, 9, 0),
        Among("\u05E8\u05D9\u05D1", -1, 10, 0),
        Among("\u05D8\u05E8\u05D9\u05D1", 1, 7, 0),
        Among("\u05E9\u05E8\u05D9\u05D1", 1, 15, 0),
        Among("\u05D4\u05F1\u05D1", -1, 23, 0),
        Among("\u05E9\u05F0\u05D9\u05D2", -1, 12, 0),
        Among("\u05D2\u05D0\u05E0\u05D2", -1, 1, 0),
        Among("\u05D6\u05D5\u05E0\u05D2", -1, 18, 0),
        Among("\u05E9\u05DC\u05D5\u05E0\u05D2", -1, 21, 0),
        Among("\u05E6\u05F0\u05D5\u05E0\u05D2", -1, 20, 0),
        Among("\u05D1\u05F1\u05D2", -1, 22, 0),
        Among("\u05D1\u05D5\u05E0\u05D3", -1, 16, 0),
        Among("\u05F0\u05D9\u05D6", -1, 6, 0),
        Among("\u05D1\u05D9\u05D8", -1, 4, 0),
        Among("\u05DC\u05D9\u05D8", -1, 8, 0),
        Among("\u05DE\u05D9\u05D8", -1, 3, 0),
        Among("\u05E9\u05E0\u05D9\u05D8", -1, 14, 0),
        Among("\u05E0\u05D5\u05DE", -1, 2, 0),
        Among("\u05E9\u05D8\u05D0\u05E0", -1, 25, 0),
        Among("\u05D1\u05D9\u05E1", -1, 5, 0),
        Among("\u05E9\u05DE\u05D9\u05E1", -1, 13, 0),
        Among("\u05E8\u05D9\u05E1", -1, 11, 0),
        Among("\u05D8\u05E8\u05D5\u05E0\u05E7", -1, 19, 0),
        Among("\u05E4\u05D0\u05E8\u05DC\u05F1\u05E8", -1, 24, 0),
        Among("\u05E9\u05F0\u05F1\u05E8", -1, 26, 0),
        Among("\u05F0\u05D5\u05D8\u05E9", -1, 17, 0)
    ];

    static final a_4 = [
        Among("\u05D5\u05E0\u05D2", -1, 1, 0),
        Among("\u05E1\u05D8\u05D5", -1, 1, 0),
        Among("\u05D8", -1, 1, 0),
        Among("\u05D1\u05E8\u05D0\u05DB\u05D8", 2, 31, 0),
        Among("\u05E1\u05D8", 2, 1, 0),
        Among("\u05D9\u05E1\u05D8", 4, 33, 0),
        Among("\u05E2\u05D8", 2, 1, 0),
        Among("\u05E9\u05D0\u05E4\u05D8", 2, 1, 0),
        Among("\u05D4\u05F2\u05D8", 2, 1, 0),
        Among("\u05E7\u05F2\u05D8", 2, 1, 0),
        Among("\u05D9\u05E7\u05F2\u05D8", 9, 1, 0),
        Among("\u05DC\u05E2\u05DB", -1, 1, 0),
        Among("\u05E2\u05DC\u05E2\u05DB", 11, 1, 0),
        Among("\u05D9\u05D6\u05DE", -1, 1, 0),
        Among("\u05D9\u05DE", -1, 1, 0),
        Among("\u05E2\u05DE", -1, 1, 0),
        Among("\u05E2\u05E0\u05E2\u05DE", 15, 3, 0),
        Among("\u05D8\u05E2\u05E0\u05E2\u05DE", 16, 4, 0),
        Among("\u05E0", -1, 1, 0),
        Among("\u05E7\u05DC\u05D9\u05D1\u05E0", 18, 14, 0),
        Among("\u05E8\u05D9\u05D1\u05E0", 18, 15, 0),
        Among("\u05D8\u05E8\u05D9\u05D1\u05E0", 20, 12, 0),
        Among("\u05E9\u05E8\u05D9\u05D1\u05E0", 20, 7, 0),
        Among("\u05D4\u05F1\u05D1\u05E0", 18, 27, 0),
        Among("\u05E9\u05F0\u05D9\u05D2\u05E0", 18, 17, 0),
        Among("\u05D6\u05D5\u05E0\u05D2\u05E0", 18, 22, 0),
        Among("\u05E9\u05DC\u05D5\u05E0\u05D2\u05E0", 18, 25, 0),
        Among("\u05E6\u05F0\u05D5\u05E0\u05D2\u05E0", 18, 24, 0),
        Among("\u05D1\u05F1\u05D2\u05E0", 18, 26, 0),
        Among("\u05D1\u05D5\u05E0\u05D3\u05E0", 18, 20, 0),
        Among("\u05F0\u05D9\u05D6\u05E0", 18, 11, 0),
        Among("\u05D8\u05E0", 18, 4, 0),
        Among("GE\u05D1\u05D9\u05D8\u05E0", 31, 9, 0),
        Among("GE\u05DC\u05D9\u05D8\u05E0", 31, 13, 0),
        Among("GE\u05DE\u05D9\u05D8\u05E0", 31, 8, 0),
        Among("\u05E9\u05E0\u05D9\u05D8\u05E0", 31, 19, 0),
        Among("\u05E1\u05D8\u05E0", 31, 1, 0),
        Among("\u05D9\u05E1\u05D8\u05E0", 36, 1, 0),
        Among("\u05E2\u05D8\u05E0", 31, 1, 0),
        Among("GE\u05D1\u05D9\u05E1\u05E0", 18, 10, 0),
        Among("\u05E9\u05DE\u05D9\u05E1\u05E0", 18, 18, 0),
        Among("GE\u05E8\u05D9\u05E1\u05E0", 18, 16, 0),
        Among("\u05E2\u05E0", 18, 1, 0),
        Among("\u05D2\u05D0\u05E0\u05D2\u05E2\u05E0", 42, 5, 0),
        Among("\u05E2\u05DC\u05E2\u05E0", 42, 1, 0),
        Among("\u05E0\u05D5\u05DE\u05E2\u05E0", 42, 6, 0),
        Among("\u05D9\u05D6\u05DE\u05E2\u05E0", 42, 1, 0),
        Among("\u05E9\u05D8\u05D0\u05E0\u05E2\u05E0", 42, 29, 0),
        Among("\u05D8\u05E8\u05D5\u05E0\u05E7\u05E0", 18, 23, 0),
        Among("\u05E4\u05D0\u05E8\u05DC\u05F1\u05E8\u05E0", 18, 28, 0),
        Among("\u05E9\u05F0\u05F1\u05E8\u05E0", 18, 30, 0),
        Among("\u05F0\u05D5\u05D8\u05E9\u05E0", 18, 21, 0),
        Among("\u05D2\u05F2\u05E0", 18, 5, 0),
        Among("\u05E1", -1, 1, 0),
        Among("\u05D8\u05E1", 53, 4, 0),
        Among("\u05E2\u05D8\u05E1", 54, 1, 0),
        Among("\u05E0\u05E1", 53, 1, 0),
        Among("\u05D8\u05E0\u05E1", 56, 4, 0),
        Among("\u05E2\u05E0\u05E1", 56, 3, 0),
        Among("\u05E2\u05E1", 53, 1, 0),
        Among("\u05D9\u05E2\u05E1", 59, 2, 0),
        Among("\u05E2\u05DC\u05E2\u05E1", 59, 1, 0),
        Among("\u05E2\u05E8\u05E1", 53, 1, 0),
        Among("\u05E2\u05E0\u05E2\u05E8\u05E1", 62, 1, 0),
        Among("\u05E2", -1, 1, 0),
        Among("\u05D8\u05E2", 64, 4, 0),
        Among("\u05E1\u05D8\u05E2", 65, 1, 0),
        Among("\u05E2\u05D8\u05E2", 65, 1, 0),
        Among("\u05D9\u05E2", 64, -1, 0),
        Among("\u05E2\u05DC\u05E2", 64, 1, 0),
        Among("\u05E2\u05E0\u05E2", 64, 3, 0),
        Among("\u05D8\u05E2\u05E0\u05E2", 70, 4, 0),
        Among("\u05E2\u05E8", -1, 1, 0),
        Among("\u05D8\u05E2\u05E8", 72, 4, 0),
        Among("\u05E1\u05D8\u05E2\u05E8", 73, 1, 0),
        Among("\u05E2\u05D8\u05E2\u05E8", 73, 1, 0),
        Among("\u05E2\u05E0\u05E2\u05E8", 72, 3, 0),
        Among("\u05D8\u05E2\u05E0\u05E2\u05E8", 76, 4, 0),
        Among("\u05D5\u05EA", -1, 32, 0)
    ];

    static final a_5 = [
        Among("\u05D5\u05E0\u05D2", -1, 1, 0),
        Among("\u05E9\u05D0\u05E4\u05D8", -1, 1, 0),
        Among("\u05D4\u05F2\u05D8", -1, 1, 0),
        Among("\u05E7\u05F2\u05D8", -1, 1, 0),
        Among("\u05D9\u05E7\u05F2\u05D8", 3, 1, 0),
        Among("\u05DC", -1, 2, 0)
    ];

    static final a_6 = [
        Among("\u05D9\u05D2", -1, 1, 0),
        Among("\u05D9\u05E7", -1, 1, 0),
        Among("\u05D3\u05D9\u05E7", 1, 1, 0),
        Among("\u05E0\u05D3\u05D9\u05E7", 2, 1, 0),
        Among("\u05E2\u05E0\u05D3\u05D9\u05E7", 3, 1, 0),
        Among("\u05D1\u05DC\u05D9\u05E7", 1, -1, 0),
        Among("\u05D2\u05DC\u05D9\u05E7", 1, -1, 0),
        Among("\u05E0\u05D9\u05E7", 1, 1, 0),
        Among("\u05D9\u05E9", -1, 1, 0)
    ];

    static final g_niked = String.fromCharCodes([255, 155, 6]);

    static final g_vowel = String.fromCharCodes([33, 2, 4, 0, 6]);

    static final g_consonant = String.fromCharCodes([239, 254, 253, 131]);


    @override
    bool stem() {
        int among_var;
        int I_x;
        int I_p1;
        lab0: while (true) {
            int v_1 = cursor;
            lab1: while (true) {
                replab2: while(true)
                {
                    int v_2 = cursor;
                    lab3: while (true) {
                        golab4: while(true)
                        {
                            int v_3 = cursor;
                            lab5: while (true) {
                                bra = cursor;
                                among_var = find_among(a_0, null);
                                if (among_var == 0)
                                {
                                    break lab5;
                                }
                                ket = cursor;
                                switch (among_var) {
                                    case 1:
                                        lab6: while (true) {
                                            if (!(eq_s("\u05BC")))
                                            {
                                                break lab6;
                                            }
                                            break lab5;
                                        }
                                        slice_from("\u05F0");
                                        break;
                                    case 2:
                                        lab7: while (true) {
                                            if (!(eq_s("\u05B4")))
                                            {
                                                break lab7;
                                            }
                                            break lab5;
                                        }
                                        slice_from("\u05F1");
                                        break;
                                    case 3:
                                        lab8: while (true) {
                                            if (!(eq_s("\u05B4")))
                                            {
                                                break lab8;
                                            }
                                            break lab5;
                                        }
                                        slice_from("\u05F2");
                                        break;
                                    case 4:
                                        slice_from("\u05DB");
                                        break;
                                    case 5:
                                        slice_from("\u05DE");
                                        break;
                                    case 6:
                                        slice_from("\u05E0");
                                        break;
                                    case 7:
                                        slice_from("\u05E4");
                                        break;
                                    case 8:
                                        slice_from("\u05E6");
                                        break;
                                }
                                cursor = v_3;
                                break golab4;
                            }
                            cursor = v_3;
                            if (cursor >= limit)
                            {
                                break lab3;
                            }
                            cursor++;
                        }
                        continue replab2;
                    }
                    cursor = v_2;
                    break replab2;
                }
                break lab1;
            }
            cursor = v_1;
            int v_4 = cursor;
            lab9: while (true) {
                replab10: while(true)
                {
                    int v_5 = cursor;
                    lab11: while (true) {
                        golab12: while(true)
                        {
                            int v_6 = cursor;
                            lab13: while (true) {
                                bra = cursor;
                                if (!(in_grouping(g_niked, 1456, 1474)))
                                {
                                    break lab13;
                                }
                                ket = cursor;
                                slice_del();
                                cursor = v_6;
                                break golab12;
                            }
                            cursor = v_6;
                            if (cursor >= limit)
                            {
                                break lab11;
                            }
                            cursor++;
                        }
                        continue replab10;
                    }
                    cursor = v_5;
                    break replab10;
                }
                break lab9;
            }
            cursor = v_4;
            break lab0;
        }
        int v_7 = cursor;
        lab14: while (true) {
            I_p1 = limit;
            int v_8 = cursor;
            lab15: while (true) {
                bra = cursor;
                if (!(eq_s("\u05D2\u05E2")))
                {
                    cursor = v_8;
                    break lab15;
                }
                ket = cursor;
                {
                    int v_9 = cursor;
                    lab16: while (true) {
                        lab17: while (true) {
                            lab18: while (true) {
                                if (!(eq_s("\u05DC\u05D8")))
                                {
                                    break lab18;
                                }
                                break lab17;
                            }
                            lab19: while (true) {
                                if (!(eq_s("\u05D1\u05E0")))
                                {
                                    break lab19;
                                }
                                break lab17;
                            }
                            if (cursor < limit)
                            {
                                break lab16;
                            }
                            break lab17;
                        }
                        cursor = v_8;
                        break lab15;
                    }
                    cursor = v_9;
                }
                slice_from("GE");
                break lab15;
            }
            int v_10 = cursor;
            lab20: while (true) {
                if (find_among(a_1, null) == 0)
                {
                    cursor = v_10;
                    break lab20;
                }
                lab21: while (true) {
                    int v_11 = cursor;
                    lab22: while (true) {
                        int v_12 = cursor;
                        lab23: while (true) {
                            lab24: while (true) {
                                if (!(eq_s("\u05E6\u05D5\u05D2\u05E0")))
                                {
                                    break lab24;
                                }
                                break lab23;
                            }
                            lab25: while (true) {
                                if (!(eq_s("\u05E6\u05D5\u05E7\u05D8")))
                                {
                                    break lab25;
                                }
                                break lab23;
                            }
                            if (!(eq_s("\u05E6\u05D5\u05E7\u05E0")))
                            {
                                break lab22;
                            }
                            break lab23;
                        }
                        if (cursor < limit)
                        {
                            break lab22;
                        }
                        cursor = v_12;
                        break lab21;
                    }
                    cursor = v_11;
                    lab26: while (true) {
                        int v_13 = cursor;
                        if (!(eq_s("\u05D2\u05E2\u05D1\u05E0")))
                        {
                            break lab26;
                        }
                        cursor = v_13;
                        break lab21;
                    }
                    cursor = v_11;
                    lab27: while (true) {
                        bra = cursor;
                        if (!(eq_s("\u05D2\u05E2")))
                        {
                            break lab27;
                        }
                        ket = cursor;
                        slice_from("GE");
                        break lab21;
                    }
                    cursor = v_11;
                    bra = cursor;
                    if (!(eq_s("\u05E6\u05D5")))
                    {
                        cursor = v_10;
                        break lab20;
                    }
                    ket = cursor;
                    slice_from("TSU");
                    break lab21;
                }
                break lab20;
            }
            int v_14 = cursor;
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab14;
                }
                cursor = c;
            }
            I_x = cursor;
            cursor = v_14;
            int v_15 = cursor;
            lab28: while (true) {
                if (find_among(a_2, null) == 0)
                {
                    cursor = v_15;
                    break lab28;
                }
                break lab28;
            }
            {
                int v_16 = cursor;
                lab29: while (true) {
                    if (!(in_grouping(g_consonant, 1489, 1520)))
                    {
                        break lab29;
                    }
                    if (!(in_grouping(g_consonant, 1489, 1520)))
                    {
                        break lab29;
                    }
                    if (!(in_grouping(g_consonant, 1489, 1520)))
                    {
                        break lab29;
                    }
                    I_p1 = cursor;
                    break lab14;
                }
                cursor = v_16;
            }
            if (!go_out_grouping(g_vowel, 1488, 1522))
            {
                break lab14;
            }
            cursor++;
            if (!go_in_grouping(g_vowel, 1488, 1522))
            {
                break lab14;
            }
            I_p1 = cursor;
            lab30: while (true) {
                if (I_p1 >= I_x)
                {
                    break lab30;
                }
                I_p1 = I_x;
                break lab30;
            }
            break lab14;
        }
        cursor = v_7;
        limit_backward = cursor;
        cursor = limit;
        lab31: while (true) {
            int v_17 = limit - cursor;
            lab32: while (true) {
                ket = cursor;
                among_var = find_among_b(a_4, null);
                if (among_var == 0)
                {
                    break lab32;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p1 > cursor)
                        {
                            break lab32;
                        }
                        slice_del();
                        break;
                    case 2:
                        if (I_p1 > cursor)
                        {
                            break lab32;
                        }
                        slice_from("\u05D9\u05E2");
                        break;
                    case 3:
                        if (I_p1 > cursor)
                        {
                            break lab32;
                        }
                        slice_del();
                        ket = cursor;
                        among_var = find_among_b(a_3, null);
                        if (among_var == 0)
                        {
                            break lab32;
                        }
                        bra = cursor;
                        switch (among_var) {
                            case 1:
                                slice_from("\u05D2\u05F2");
                                break;
                            case 2:
                                slice_from("\u05E0\u05E2\u05DE");
                                break;
                            case 3:
                                slice_from("\u05DE\u05F2\u05D3");
                                break;
                            case 4:
                                slice_from("\u05D1\u05F2\u05D8");
                                break;
                            case 5:
                                slice_from("\u05D1\u05F2\u05E1");
                                break;
                            case 6:
                                slice_from("\u05F0\u05F2\u05D6");
                                break;
                            case 7:
                                slice_from("\u05D8\u05E8\u05F2\u05D1");
                                break;
                            case 8:
                                slice_from("\u05DC\u05F2\u05D8");
                                break;
                            case 9:
                                slice_from("\u05E7\u05DC\u05F2\u05D1");
                                break;
                            case 10:
                                slice_from("\u05E8\u05F2\u05D1");
                                break;
                            case 11:
                                slice_from("\u05E8\u05F2\u05E1");
                                break;
                            case 12:
                                slice_from("\u05E9\u05F0\u05F2\u05D2");
                                break;
                            case 13:
                                slice_from("\u05E9\u05DE\u05F2\u05E1");
                                break;
                            case 14:
                                slice_from("\u05E9\u05E0\u05F2\u05D3");
                                break;
                            case 15:
                                slice_from("\u05E9\u05E8\u05F2\u05D1");
                                break;
                            case 16:
                                slice_from("\u05D1\u05D9\u05E0\u05D3");
                                break;
                            case 17:
                                slice_from("\u05F0\u05D9\u05D8\u05E9");
                                break;
                            case 18:
                                slice_from("\u05D6\u05D9\u05E0\u05D2");
                                break;
                            case 19:
                                slice_from("\u05D8\u05E8\u05D9\u05E0\u05E7");
                                break;
                            case 20:
                                slice_from("\u05E6\u05F0\u05D9\u05E0\u05D2");
                                break;
                            case 21:
                                slice_from("\u05E9\u05DC\u05D9\u05E0\u05D2");
                                break;
                            case 22:
                                slice_from("\u05D1\u05F2\u05D2");
                                break;
                            case 23:
                                slice_from("\u05D4\u05F2\u05D1");
                                break;
                            case 24:
                                slice_from("\u05E4\u05D0\u05E8\u05DC\u05D9\u05E8");
                                break;
                            case 25:
                                slice_from("\u05E9\u05D8\u05F2");
                                break;
                            case 26:
                                slice_from("\u05E9\u05F0\u05E2\u05E8");
                                break;
                        }
                        break;
                    case 4:
                        lab33: while (true) {
                            int v_18 = limit - cursor;
                            lab34: while (true) {
                                if (I_p1 > cursor)
                                {
                                    break lab34;
                                }
                                slice_del();
                                break lab33;
                            }
                            cursor = limit - v_18;
                            slice_from("\u05D8");
                            break lab33;
                        }
                        ket = cursor;
                        if (!(eq_s_b("\u05D1\u05E8\u05D0\u05DB")))
                        {
                            break lab32;
                        }
                        int v_19 = limit - cursor;
                        lab35: while (true) {
                            if (!(eq_s_b("\u05D2\u05E2")))
                            {
                                cursor = limit - v_19;
                                break lab35;
                            }
                            break lab35;
                        }
                        bra = cursor;
                        slice_from("\u05D1\u05E8\u05E2\u05E0\u05D2");
                        break;
                    case 5:
                        slice_from("\u05D2\u05F2");
                        break;
                    case 6:
                        slice_from("\u05E0\u05E2\u05DE");
                        break;
                    case 7:
                        slice_from("\u05E9\u05E8\u05F2\u05D1");
                        break;
                    case 8:
                        slice_from("\u05DE\u05F2\u05D3");
                        break;
                    case 9:
                        slice_from("\u05D1\u05F2\u05D8");
                        break;
                    case 10:
                        slice_from("\u05D1\u05F2\u05E1");
                        break;
                    case 11:
                        slice_from("\u05F0\u05F2\u05D6");
                        break;
                    case 12:
                        slice_from("\u05D8\u05E8\u05F2\u05D1");
                        break;
                    case 13:
                        slice_from("\u05DC\u05F2\u05D8");
                        break;
                    case 14:
                        slice_from("\u05E7\u05DC\u05F2\u05D1");
                        break;
                    case 15:
                        slice_from("\u05E8\u05F2\u05D1");
                        break;
                    case 16:
                        slice_from("\u05E8\u05F2\u05E1");
                        break;
                    case 17:
                        slice_from("\u05E9\u05F0\u05F2\u05D2");
                        break;
                    case 18:
                        slice_from("\u05E9\u05DE\u05F2\u05E1");
                        break;
                    case 19:
                        slice_from("\u05E9\u05E0\u05F2\u05D3");
                        break;
                    case 20:
                        slice_from("\u05D1\u05D9\u05E0\u05D3");
                        break;
                    case 21:
                        slice_from("\u05F0\u05D9\u05D8\u05E9");
                        break;
                    case 22:
                        slice_from("\u05D6\u05D9\u05E0\u05D2");
                        break;
                    case 23:
                        slice_from("\u05D8\u05E8\u05D9\u05E0\u05E7");
                        break;
                    case 24:
                        slice_from("\u05E6\u05F0\u05D9\u05E0\u05D2");
                        break;
                    case 25:
                        slice_from("\u05E9\u05DC\u05D9\u05E0\u05D2");
                        break;
                    case 26:
                        slice_from("\u05D1\u05F2\u05D2");
                        break;
                    case 27:
                        slice_from("\u05D4\u05F2\u05D1");
                        break;
                    case 28:
                        slice_from("\u05E4\u05D0\u05E8\u05DC\u05D9\u05E8");
                        break;
                    case 29:
                        slice_from("\u05E9\u05D8\u05F2");
                        break;
                    case 30:
                        slice_from("\u05E9\u05F0\u05E2\u05E8");
                        break;
                    case 31:
                        slice_from("\u05D1\u05E8\u05E2\u05E0\u05D2");
                        break;
                    case 32:
                        if (I_p1 > cursor)
                        {
                            break lab32;
                        }
                        slice_from("\u05D4");
                        break;
                    case 33:
                        lab36: while (true) {
                            int v_20 = limit - cursor;
                            lab37: while (true) {
                                lab38: while (true) {
                                    lab39: while (true) {
                                        if (!(eq_s_b("\u05D2")))
                                        {
                                            break lab39;
                                        }
                                        break lab38;
                                    }
                                    if (!(eq_s_b("\u05E9")))
                                    {
                                        break lab37;
                                    }
                                    break lab38;
                                }
                                int v_21 = limit - cursor;
                                lab40: while (true) {
                                    if (I_p1 > (cursor + 3))
                                    {
                                        cursor = limit - v_21;
                                        break lab40;
                                    }
                                    slice_from("\u05D9\u05E1");
                                    break lab40;
                                }
                                break lab36;
                            }
                            cursor = limit - v_20;
                            if (I_p1 > cursor)
                            {
                                break lab32;
                            }
                            slice_del();
                            break lab36;
                        }
                        break;
                }
                break lab32;
            }
            cursor = limit - v_17;
            int v_22 = limit - cursor;
            lab41: while (true) {
                ket = cursor;
                among_var = find_among_b(a_5, null);
                if (among_var == 0)
                {
                    break lab41;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p1 > cursor)
                        {
                            break lab41;
                        }
                        slice_del();
                        break;
                    case 2:
                        if (I_p1 > cursor)
                        {
                            break lab41;
                        }
                        if (!(in_grouping_b(g_consonant, 1489, 1520)))
                        {
                            break lab41;
                        }
                        slice_del();
                        break;
                }
                break lab41;
            }
            cursor = limit - v_22;
            int v_23 = limit - cursor;
            lab42: while (true) {
                ket = cursor;
                among_var = find_among_b(a_6, null);
                if (among_var == 0)
                {
                    break lab42;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p1 > cursor)
                        {
                            break lab42;
                        }
                        slice_del();
                        break;
                }
                break lab42;
            }
            cursor = limit - v_23;
            int v_24 = limit - cursor;
            lab43: while (true) {
                replab44: while(true)
                {
                    int v_25 = limit - cursor;
                    lab45: while (true) {
                        golab46: while(true)
                        {
                            int v_26 = limit - cursor;
                            lab47: while (true) {
                                ket = cursor;
                                lab48: while (true) {
                                    lab49: while (true) {
                                        if (!(eq_s_b("GE")))
                                        {
                                            break lab49;
                                        }
                                        break lab48;
                                    }
                                    if (!(eq_s_b("TSU")))
                                    {
                                        break lab47;
                                    }
                                    break lab48;
                                }
                                bra = cursor;
                                slice_del();
                                cursor = limit - v_26;
                                break golab46;
                            }
                            cursor = limit - v_26;
                            if (cursor <= limit_backward)
                            {
                                break lab45;
                            }
                            cursor--;
                        }
                        continue replab44;
                    }
                    cursor = limit - v_25;
                    break replab44;
                }
                break lab43;
            }
            cursor = limit - v_24;
            break lab31;
        }
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is yiddish_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
