// Generated from norwegian.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from norwegian.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class norwegian_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 1, 0),
        Among("ind", 0, -1, 0),
        Among("kk", 0, -1, 0),
        Among("nk", 0, -1, 0),
        Among("amm", 0, -1, 0),
        Among("omm", 0, -1, 0),
        Among("kap", 0, -1, 0),
        Among("skap", 6, 1, 0),
        Among("pp", 0, -1, 0),
        Among("lt", 0, -1, 0),
        Among("ast", 0, -1, 0),
        Among("\u00F8st", 0, -1, 0),
        Among("v", 0, -1, 0),
        Among("hav", 12, 1, 0),
        Among("giv", 12, 1, 0)
    ];

    static final a_1 = [
        Among("a", -1, 1, 0),
        Among("e", -1, 1, 0),
        Among("ede", 1, 1, 0),
        Among("ande", 1, 1, 0),
        Among("ende", 1, 1, 0),
        Among("ane", 1, 1, 0),
        Among("ene", 1, 1, 0),
        Among("hetene", 6, 1, 0),
        Among("erte", 1, 4, 0),
        Among("en", -1, 1, 0),
        Among("heten", 9, 1, 0),
        Among("ar", -1, 1, 0),
        Among("er", -1, 1, 0),
        Among("heter", 12, 1, 0),
        Among("s", -1, 3, 0),
        Among("as", 14, 1, 0),
        Among("es", 14, 1, 0),
        Among("edes", 16, 1, 0),
        Among("endes", 16, 1, 0),
        Among("enes", 16, 1, 0),
        Among("hetenes", 19, 1, 0),
        Among("ens", 14, 1, 0),
        Among("hetens", 21, 1, 0),
        Among("ers", 14, 2, 0),
        Among("ets", 14, 1, 0),
        Among("et", -1, 1, 0),
        Among("het", 25, 1, 0),
        Among("ert", -1, 4, 0),
        Among("ast", -1, 1, 0)
    ];

    static final a_2 = [
        Among("dt", -1, -1, 0),
        Among("vt", -1, -1, 0)
    ];

    static final a_3 = [
        Among("leg", -1, 1, 0),
        Among("eleg", 0, 1, 0),
        Among("ig", -1, 1, 0),
        Among("eig", 2, 1, 0),
        Among("lig", 2, 1, 0),
        Among("elig", 4, 1, 0),
        Among("els", -1, 1, 0),
        Among("lov", -1, 1, 0),
        Among("elov", 7, 1, 0),
        Among("slov", 7, 1, 0),
        Among("hetslov", 9, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 2, 142]);

    static final g_s_ending = String.fromCharCodes([119, 125, 148, 1]);


    @override
    bool stem() {
        int among_var;
        int I_p1;
        I_p1 = limit;
        int v_1 = cursor;
        lab0: while (true) {
            lab1: while (true) {
                int v_2 = cursor;
                lab2: while (true) {
                    golab3: while(true)
                    {
                        lab4: while (true) {
                            if (!(eq_s("'")))
                            {
                                break lab4;
                            }
                            break golab3;
                        }
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    break lab1;
                }
                cursor = v_2;
                if (!go_out_grouping(g_v, 97, 248))
                {
                    break lab0;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 248))
                {
                    break lab0;
                }
                cursor++;
                break lab1;
            }
            I_p1 = cursor;
            break lab0;
        }
        cursor = v_1;
        int v_3 = cursor;
        {
            int c = cursor + 3;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        lab5: while (true) {
            if (I_p1 >= cursor)
            {
                break lab5;
            }
            I_p1 = cursor;
            break lab5;
        }
        cursor = v_3;
        limit_backward = cursor;
        cursor = limit;
        int v_4 = limit - cursor;
        lab6: while (true) {
            if (cursor < I_p1)
            {
                break lab6;
            }
            int v_5 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            among_var = find_among_b(a_1, null);
            if (among_var == 0)
            {
                limit_backward = v_5;
                break lab6;
            }
            bra = cursor;
            limit_backward = v_5;
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    among_var = find_among_b(a_0, null);
                    switch (among_var) {
                        case 1:
                            slice_del();
                            break;
                    }
                    break;
                case 3:
                    lab7: while (true) {
                        int v_6 = limit - cursor;
                        lab8: while (true) {
                            if (!(in_grouping_b(g_s_ending, 98, 122)))
                            {
                                break lab8;
                            }
                            break lab7;
                        }
                        cursor = limit - v_6;
                        lab9: while (true) {
                            if (!(eq_s_b("r")))
                            {
                                break lab9;
                            }
                            lab10: while (true) {
                                if (!(eq_s_b("e")))
                                {
                                    break lab10;
                                }
                                break lab9;
                            }
                            break lab7;
                        }
                        cursor = limit - v_6;
                        if (!(eq_s_b("k")))
                        {
                            break lab6;
                        }
                        if (!(out_grouping_b(g_v, 97, 248)))
                        {
                            break lab6;
                        }
                        break lab7;
                    }
                    slice_del();
                    break;
                case 4:
                    slice_from("er");
                    break;
            }
            break lab6;
        }
        cursor = limit - v_4;
        int v_7 = limit - cursor;
        lab11: while (true) {
            int v_8 = limit - cursor;
            if (cursor < I_p1)
            {
                break lab11;
            }
            int v_9 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            if (find_among_b(a_2, null) == 0)
            {
                limit_backward = v_9;
                break lab11;
            }
            bra = cursor;
            limit_backward = v_9;
            cursor = limit - v_8;
            if (cursor <= limit_backward)
            {
                break lab11;
            }
            cursor--;
            bra = cursor;
            slice_del();
            break lab11;
        }
        cursor = limit - v_7;
        int v_10 = limit - cursor;
        lab12: while (true) {
            if (cursor < I_p1)
            {
                break lab12;
            }
            int v_11 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            if (find_among_b(a_3, null) == 0)
            {
                limit_backward = v_11;
                break lab12;
            }
            bra = cursor;
            limit_backward = v_11;
            slice_del();
            break lab12;
        }
        cursor = limit - v_10;
        ket = cursor;
        if (!(eq_s_b("'")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        cursor = limit_backward;
        return true;
    }

    @override
    bool operator ==(Object other) => other is norwegian_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
