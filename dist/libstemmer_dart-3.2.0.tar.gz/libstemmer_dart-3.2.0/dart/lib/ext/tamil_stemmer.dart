// Generated from tamil.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from tamil.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class tamil_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("\u0BB5\u0BC1", -1, 3, 0),
        Among("\u0BB5\u0BC2", -1, 4, 0),
        Among("\u0BB5\u0BCA", -1, 2, 0),
        Among("\u0BB5\u0BCB", -1, 1, 0)
    ];

    static final a_1 = [
        Among("\u0B95", -1, -1, 0),
        Among("\u0B99", -1, -1, 0),
        Among("\u0B9A", -1, -1, 0),
        Among("\u0B9E", -1, -1, 0),
        Among("\u0BA4", -1, -1, 0),
        Among("\u0BA8", -1, -1, 0),
        Among("\u0BAA", -1, -1, 0),
        Among("\u0BAE", -1, -1, 0),
        Among("\u0BAF", -1, -1, 0),
        Among("\u0BB5", -1, -1, 0)
    ];

    static final a_2 = [
        Among("\u0BBF", -1, -1, 0),
        Among("\u0BC0", -1, -1, 0),
        Among("\u0BC8", -1, -1, 0)
    ];

    static final a_3 = [
        Among("\u0BBE", -1, -1, 0),
        Among("\u0BBF", -1, -1, 0),
        Among("\u0BC0", -1, -1, 0),
        Among("\u0BC1", -1, -1, 0),
        Among("\u0BC2", -1, -1, 0),
        Among("\u0BC6", -1, -1, 0),
        Among("\u0BC7", -1, -1, 0),
        Among("\u0BC8", -1, -1, 0)
    ];

    static final a_4 = [
        Among("", -1, 2, 0),
        Among("\u0BC8", 0, 1, 0),
        Among("\u0BCD", 0, 1, 0)
    ];

    static final a_5 = [
        Among("\u0BA8\u0BCD\u0BA4", -1, 1, 0),
        Among("\u0BAF", -1, 1, 0),
        Among("\u0BB5", -1, 1, 0),
        Among("\u0BA9\u0BC1", -1, 8, 0),
        Among("\u0BC1\u0B95\u0BCD", -1, 7, 0),
        Among("\u0BC1\u0B95\u0BCD\u0B95\u0BCD", -1, 7, 0),
        Among("\u0B9F\u0BCD\u0B95\u0BCD", -1, 3, 0),
        Among("\u0BB1\u0BCD\u0B95\u0BCD", -1, 4, 0),
        Among("\u0B99\u0BCD", -1, 9, 0),
        Among("\u0B9F\u0BCD\u0B9F\u0BCD", -1, 5, 0),
        Among("\u0BA4\u0BCD\u0BA4\u0BCD", -1, 6, 0),
        Among("\u0BA8\u0BCD\u0BA4\u0BCD", -1, 1, 0),
        Among("\u0BA8\u0BCD", -1, 1, 0),
        Among("\u0B9F\u0BCD\u0BAA\u0BCD", -1, 3, 0),
        Among("\u0BAF\u0BCD", -1, 2, 0),
        Among("\u0BA9\u0BCD\u0BB1\u0BCD", -1, 4, 0),
        Among("\u0BB5\u0BCD", -1, 1, 0)
    ];

    static final a_6 = [
        Among("\u0B95", -1, -1, 0),
        Among("\u0B9A", -1, -1, 0),
        Among("\u0B9F", -1, -1, 0),
        Among("\u0BA4", -1, -1, 0),
        Among("\u0BAA", -1, -1, 0),
        Among("\u0BB1", -1, -1, 0)
    ];

    static final a_7 = [
        Among("\u0B9E", -1, -1, 0),
        Among("\u0BA3", -1, -1, 0),
        Among("\u0BA8", -1, -1, 0),
        Among("\u0BA9", -1, -1, 0),
        Among("\u0BAE", -1, -1, 0),
        Among("\u0BAF", -1, -1, 0),
        Among("\u0BB0", -1, -1, 0),
        Among("\u0BB2", -1, -1, 0),
        Among("\u0BB3", -1, -1, 0),
        Among("\u0BB4", -1, -1, 0),
        Among("\u0BB5", -1, -1, 0)
    ];

    static final a_8 = [
        Among("\u0BBE", -1, -1, 0),
        Among("\u0BBF", -1, -1, 0),
        Among("\u0BC0", -1, -1, 0),
        Among("\u0BC1", -1, -1, 0),
        Among("\u0BC2", -1, -1, 0),
        Among("\u0BC6", -1, -1, 0),
        Among("\u0BC7", -1, -1, 0),
        Among("\u0BC8", -1, -1, 0),
        Among("\u0BCD", -1, -1, 0)
    ];

    static final a_9 = [
        Among("\u0B85", -1, -1, 0),
        Among("\u0B87", -1, -1, 0),
        Among("\u0B89", -1, -1, 0)
    ];

    static final a_10 = [
        Among("\u0B95\u0BB3\u0BCD", -1, 4, 0),
        Among("\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD", 0, 1, 0),
        Among("\u0B9F\u0BCD\u0B95\u0BB3\u0BCD", 0, 3, 0),
        Among("\u0BB1\u0BCD\u0B95\u0BB3\u0BCD", 0, 2, 0)
    ];

    static final a_11 = [
        Among("\u0BBE", -1, -1, 0),
        Among("\u0BC7", -1, -1, 0),
        Among("\u0BCB", -1, -1, 0)
    ];

    static final a_12 = [
        Among("\u0BAA\u0BBF", -1, -1, 0),
        Among("\u0BB5\u0BBF", -1, -1, 0)
    ];

    static final a_13 = [
        Among("\u0BAA\u0B9F\u0BCD\u0B9F", -1, 3, 0),
        Among("\u0BAA\u0B9F\u0BCD\u0B9F\u0BA3", -1, 3, 0),
        Among("\u0BA4\u0BBE\u0BA9", -1, 3, 0),
        Among("\u0BAA\u0B9F\u0BBF\u0BA4\u0BBE\u0BA9", 2, 3, 0),
        Among("\u0BC6\u0BA9", -1, 1, 0),
        Among("\u0BBE\u0B95\u0BBF\u0BAF", -1, 1, 0),
        Among("\u0B95\u0BC1\u0BB0\u0BBF\u0BAF", -1, 3, 0),
        Among("\u0BC1\u0B9F\u0BC8\u0BAF", -1, 1, 0),
        Among("\u0BB2\u0BCD\u0BB2", -1, 2, 0),
        Among("\u0BC1\u0BB3\u0BCD\u0BB3", -1, 1, 0),
        Among("\u0BBE\u0B95\u0BBF", -1, 1, 0),
        Among("\u0BAA\u0B9F\u0BBF", -1, 3, 0),
        Among("\u0BBF\u0BA9\u0BCD\u0BB1\u0BBF", -1, 1, 0),
        Among("\u0BAA\u0BB1\u0BCD\u0BB1\u0BBF", -1, 3, 0),
        Among("\u0BAA\u0B9F\u0BC1", -1, 3, 0),
        Among("\u0BB5\u0BBF\u0B9F\u0BC1", -1, 3, 0),
        Among("\u0BAA\u0B9F\u0BCD\u0B9F\u0BC1", -1, 3, 0),
        Among("\u0BB5\u0BBF\u0B9F\u0BCD\u0B9F\u0BC1", -1, 3, 0),
        Among("\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1", -1, 3, 0),
        Among("\u0BC6\u0BA9\u0BCD\u0BB1\u0BC1", -1, 1, 0),
        Among("\u0BC1\u0B9F\u0BC8", -1, 1, 0),
        Among("\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8", -1, 1, 0),
        Among("\u0BC1\u0B9F\u0BA9\u0BCD", -1, 1, 0),
        Among("\u0BBF\u0B9F\u0BAE\u0BCD", -1, 1, 0),
        Among("\u0BC6\u0BB2\u0BCD\u0BB2\u0BBE\u0BAE\u0BCD", -1, 3, 0),
        Among("\u0BC6\u0BA9\u0BC1\u0BAE\u0BCD", -1, 1, 0)
    ];

    static final a_14 = [
        Among("\u0BB5\u0BBF\u0B9F", -1, 2, 0),
        Among("\u0BC0", -1, 7, 0),
        Among("\u0BCA\u0B9F\u0BC1", -1, 2, 0),
        Among("\u0BCB\u0B9F\u0BC1", -1, 2, 0),
        Among("\u0BA4\u0BC1", -1, 6, 0),
        Among("\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1", 4, 2, 0),
        Among("\u0BBF\u0BA9\u0BCD\u0BB1\u0BC1", -1, 2, 0),
        Among("\u0BC1\u0B9F\u0BC8", -1, 2, 0),
        Among("\u0BA9\u0BC8", -1, 1, 0),
        Among("\u0B95\u0BA3\u0BCD", -1, 1, 0),
        Among("\u0BBF\u0BA9\u0BCD", -1, 3, 0),
        Among("\u0BAE\u0BC1\u0BA9\u0BCD", -1, 1, 0),
        Among("\u0BBF\u0B9F\u0BAE\u0BCD", -1, 4, 0),
        Among("\u0BBF\u0BB1\u0BCD", -1, 2, 0),
        Among("\u0BAE\u0BC7\u0BB1\u0BCD", -1, 1, 0),
        Among("\u0BB2\u0BCD", -1, 5, 0),
        Among("\u0BBE\u0BAE\u0BB2\u0BCD", 15, 2, 0),
        Among("\u0BBE\u0BB2\u0BCD", 15, 2, 0),
        Among("\u0BBF\u0BB2\u0BCD", 15, 2, 0),
        Among("\u0BAE\u0BC7\u0BB2\u0BCD", 15, 1, 0),
        Among("\u0BC1\u0BB3\u0BCD", -1, 2, 0),
        Among("\u0B95\u0BC0\u0BB4\u0BCD", -1, 1, 0)
    ];

    static final a_15 = [
        Among("\u0B85", -1, -1, 0),
        Among("\u0B86", -1, -1, 0),
        Among("\u0B87", -1, -1, 0),
        Among("\u0B88", -1, -1, 0),
        Among("\u0B89", -1, -1, 0),
        Among("\u0B8A", -1, -1, 0),
        Among("\u0B8E", -1, -1, 0),
        Among("\u0B8F", -1, -1, 0),
        Among("\u0B90", -1, -1, 0),
        Among("\u0B92", -1, -1, 0),
        Among("\u0B93", -1, -1, 0),
        Among("\u0B94", -1, -1, 0)
    ];

    static final a_16 = [
        Among("\u0B95", -1, 1, 0),
        Among("\u0BA4", -1, 1, 0),
        Among("\u0BA9", -1, 1, 0),
        Among("\u0BAA", -1, 1, 0),
        Among("\u0BAF", -1, 1, 0),
        Among("\u0BBE", -1, 5, 0),
        Among("\u0B95\u0BC1", -1, 6, 0),
        Among("\u0BAA\u0B9F\u0BC1", -1, 1, 0),
        Among("\u0BA4\u0BC1", -1, 3, 0),
        Among("\u0BBF\u0BB1\u0BCD\u0BB1\u0BC1", -1, 1, 0),
        Among("\u0BA9\u0BC8", -1, 1, 0),
        Among("\u0BB5\u0BC8", -1, 1, 0),
        Among("\u0BA9\u0BA9\u0BCD", -1, 1, 0),
        Among("\u0BAA\u0BA9\u0BCD", -1, 1, 0),
        Among("\u0BB5\u0BA9\u0BCD", -1, 2, 0),
        Among("\u0BBE\u0BA9\u0BCD", -1, 4, 0),
        Among("\u0BA9\u0BBE\u0BA9\u0BCD", 15, 1, 0),
        Among("\u0BAE\u0BBF\u0BA9\u0BCD", -1, 1, 0),
        Among("\u0BA9\u0BC6\u0BA9\u0BCD", -1, 1, 0),
        Among("\u0BC7\u0BA9\u0BCD", -1, 5, 0),
        Among("\u0BA9\u0BAE\u0BCD", -1, 1, 0),
        Among("\u0BAA\u0BAE\u0BCD", -1, 1, 0),
        Among("\u0BBE\u0BAE\u0BCD", -1, 5, 0),
        Among("\u0B95\u0BC1\u0BAE\u0BCD", -1, 1, 0),
        Among("\u0B9F\u0BC1\u0BAE\u0BCD", -1, 5, 0),
        Among("\u0BA4\u0BC1\u0BAE\u0BCD", -1, 1, 0),
        Among("\u0BB1\u0BC1\u0BAE\u0BCD", -1, 1, 0),
        Among("\u0BC6\u0BAE\u0BCD", -1, 5, 0),
        Among("\u0BC7\u0BAE\u0BCD", -1, 5, 0),
        Among("\u0BCB\u0BAE\u0BCD", -1, 5, 0),
        Among("\u0BBE\u0BAF\u0BCD", -1, 5, 0),
        Among("\u0BA9\u0BB0\u0BCD", -1, 1, 0),
        Among("\u0BAA\u0BB0\u0BCD", -1, 1, 0),
        Among("\u0BC0\u0BAF\u0BB0\u0BCD", -1, 5, 0),
        Among("\u0BB5\u0BB0\u0BCD", -1, 1, 0),
        Among("\u0BBE\u0BB0\u0BCD", -1, 5, 0),
        Among("\u0BA9\u0BBE\u0BB0\u0BCD", 35, 1, 0),
        Among("\u0BAE\u0BBE\u0BB0\u0BCD", 35, 1, 0),
        Among("\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BCD", -1, 1, 0),
        Among("\u0BA9\u0BBF\u0BB0\u0BCD", -1, 5, 0),
        Among("\u0BC0\u0BB0\u0BCD", -1, 5, 0),
        Among("\u0BA9\u0BB3\u0BCD", -1, 1, 0),
        Among("\u0BAA\u0BB3\u0BCD", -1, 1, 0),
        Among("\u0BB5\u0BB3\u0BCD", -1, 1, 0),
        Among("\u0BBE\u0BB3\u0BCD", -1, 5, 0),
        Among("\u0BA9\u0BBE\u0BB3\u0BCD", 44, 1, 0)
    ];

    static final a_17 = [
        Among("\u0B95\u0BBF\u0BB1", -1, -1, 0),
        Among("\u0B95\u0BBF\u0BA9\u0BCD\u0BB1", -1, -1, 0),
        Among("\u0BBE\u0BA8\u0BBF\u0BA9\u0BCD\u0BB1", -1, -1, 0),
        Among("\u0B95\u0BBF\u0BB1\u0BCD", -1, -1, 0),
        Among("\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BCD", -1, -1, 0),
        Among("\u0BBE\u0BA8\u0BBF\u0BA9\u0BCD\u0BB1\u0BCD", -1, -1, 0)
    ];

    bool B_found_vetrumai_urupu = false;


    bool r_fix_va_start() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_0, null);
        if (among_var == 0)
        {
            return false;
        }
        ket = cursor;
        switch (among_var) {
            case 1:
                slice_from("\u0B93");
                break;
            case 2:
                slice_from("\u0B92");
                break;
            case 3:
                slice_from("\u0B89");
                break;
            case 4:
                slice_from("\u0B8A");
                break;
        }
        return true;
    }

    bool r_fix_endings() {
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = cursor;
                lab2: while (true) {
                    if (!r_fix_ending())
                    {
                        break lab2;
                    }
                    continue replab1;
                }
                cursor = v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = v_1;
        return true;
    }

    bool r_fix_ending() {
        int among_var;
        if (current.length < 4)
        {
            return false;
        }
        limit_backward = cursor;
        cursor = limit;
        lab0: while (true) {
            int v_1 = limit - cursor;
            lab1: while (true) {
                ket = cursor;
                among_var = find_among_b(a_5, null);
                if (among_var == 0)
                {
                    break lab1;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        slice_del();
                        break;
                    case 2:
                        int v_2 = limit - cursor;
                        if (find_among_b(a_2, null) == 0)
                        {
                            break lab1;
                        }
                        cursor = limit - v_2;
                        slice_del();
                        break;
                    case 3:
                        slice_from("\u0BB3\u0BCD");
                        break;
                    case 4:
                        slice_from("\u0BB2\u0BCD");
                        break;
                    case 5:
                        slice_from("\u0B9F\u0BC1");
                        break;
                    case 6:
                        if (!B_found_vetrumai_urupu)
                        {
                            break lab1;
                        }
                        lab2: while (true) {
                            if (!(eq_s_b("\u0BC8")))
                            {
                                break lab2;
                            }
                            break lab1;
                        }
                        slice_from("\u0BAE\u0BCD");
                        break;
                    case 7:
                        slice_from("\u0BCD");
                        break;
                    case 8:
                        {
                            int v_3 = limit - cursor;
                            lab3: while (true) {
                                if (find_among_b(a_3, null) == 0)
                                {
                                    break lab3;
                                }
                                break lab1;
                            }
                            cursor = limit - v_3;
                        }
                        slice_del();
                        break;
                    case 9:
                        among_var = find_among_b(a_4, null);
                        switch (among_var) {
                            case 1:
                                slice_del();
                                break;
                            case 2:
                                slice_from("\u0BAE\u0BCD");
                                break;
                        }
                        break;
                }
                break lab0;
            }
            cursor = limit - v_1;
            ket = cursor;
            if (!(eq_s_b("\u0BCD")))
            {
                return false;
            }
            lab4: while (true) {
                int v_4 = limit - cursor;
                lab5: while (true) {
                    if (find_among_b(a_6, null) == 0)
                    {
                        break lab5;
                    }
                    int v_5 = limit - cursor;
                    lab6: while (true) {
                        if (!(eq_s_b("\u0BCD")))
                        {
                            cursor = limit - v_5;
                            break lab6;
                        }
                        if (find_among_b(a_6, null) == 0)
                        {
                            cursor = limit - v_5;
                            break lab6;
                        }
                        break lab6;
                    }
                    bra = cursor;
                    slice_del();
                    break lab4;
                }
                cursor = limit - v_4;
                lab7: while (true) {
                    if (find_among_b(a_7, null) == 0)
                    {
                        break lab7;
                    }
                    bra = cursor;
                    if (!(eq_s_b("\u0BCD")))
                    {
                        break lab7;
                    }
                    slice_del();
                    break lab4;
                }
                cursor = limit - v_4;
                int v_6 = limit - cursor;
                if (find_among_b(a_8, null) == 0)
                {
                    return false;
                }
                cursor = limit - v_6;
                bra = cursor;
                slice_del();
                break lab4;
            }
            break lab0;
        }
        cursor = limit_backward;
        return true;
    }

    @override
    bool stem() {
        int among_var;
        bool B_found_a_match;
        B_found_vetrumai_urupu = false;
        int v_1 = cursor;
        r_fix_ending();
        cursor = v_1;
        if (current.length < 5)
        {
            return false;
        }
        int v_2 = cursor;
        lab0: while (true) {
            bra = cursor;
            if (!(eq_s("\u0B8E")))
            {
                break lab0;
            }
            if (find_among(a_1, null) == 0)
            {
                break lab0;
            }
            if (!(eq_s("\u0BCD")))
            {
                break lab0;
            }
            ket = cursor;
            slice_del();
            int v_3 = cursor;
            r_fix_va_start();
            cursor = v_3;
            break lab0;
        }
        cursor = v_2;
        int v_4 = cursor;
        lab1: while (true) {
            bra = cursor;
            if (find_among(a_9, null) == 0)
            {
                break lab1;
            }
            if (find_among(a_1, null) == 0)
            {
                break lab1;
            }
            if (!(eq_s("\u0BCD")))
            {
                break lab1;
            }
            ket = cursor;
            slice_del();
            int v_5 = cursor;
            r_fix_va_start();
            cursor = v_5;
            break lab1;
        }
        cursor = v_4;
        lab2: while (true) {
            if (current.length < 5)
            {
                break lab2;
            }
            limit_backward = cursor;
            cursor = limit;
            int v_6 = limit - cursor;
            lab3: while (true) {
                ket = cursor;
                if (find_among_b(a_11, null) == 0)
                {
                    break lab3;
                }
                bra = cursor;
                slice_from("\u0BCD");
                break lab3;
            }
            cursor = limit - v_6;
            cursor = limit_backward;
            r_fix_endings();
            break lab2;
        }
        int v_7 = cursor;
        lab4: while (true) {
            if (current.length < 5)
            {
                break lab4;
            }
            limit_backward = cursor;
            cursor = limit;
            ket = cursor;
            if (!(eq_s_b("\u0BC1\u0BAE\u0BCD")))
            {
                break lab4;
            }
            bra = cursor;
            slice_from("\u0BCD");
            cursor = limit_backward;
            int v_8 = cursor;
            r_fix_ending();
            cursor = v_8;
            break lab4;
        }
        cursor = v_7;
        int v_9 = cursor;
        lab5: while (true) {
            if (current.length < 5)
            {
                break lab5;
            }
            limit_backward = cursor;
            cursor = limit;
            ket = cursor;
            among_var = find_among_b(a_13, null);
            if (among_var == 0)
            {
                break lab5;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_from("\u0BCD");
                    break;
                case 2:
                    {
                        int v_10 = limit - cursor;
                        lab6: while (true) {
                            if (find_among_b(a_3, null) == 0)
                            {
                                break lab6;
                            }
                            break lab5;
                        }
                        cursor = limit - v_10;
                    }
                    slice_from("\u0BCD");
                    break;
                case 3:
                    slice_del();
                    break;
            }
            cursor = limit_backward;
            r_fix_endings();
            break lab5;
        }
        cursor = v_9;
        int v_11 = cursor;
        lab7: while (true) {
            B_found_vetrumai_urupu = false;
            if (current.length < 5)
            {
                break lab7;
            }
            limit_backward = cursor;
            cursor = limit;
            lab8: while (true) {
                int v_12 = limit - cursor;
                lab9: while (true) {
                    int v_13 = limit - cursor;
                    ket = cursor;
                    among_var = find_among_b(a_14, null);
                    if (among_var == 0)
                    {
                        break lab9;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            slice_del();
                            break;
                        case 2:
                            slice_from("\u0BCD");
                            break;
                        case 3:
                            lab10: while (true) {
                                if (!(eq_s_b("\u0BAE")))
                                {
                                    break lab10;
                                }
                                break lab9;
                            }
                            slice_from("\u0BCD");
                            break;
                        case 4:
                            if (current.length < 7)
                            {
                                break lab9;
                            }
                            slice_from("\u0BCD");
                            break;
                        case 5:
                            {
                                int v_14 = limit - cursor;
                                lab11: while (true) {
                                    if (find_among_b(a_3, null) == 0)
                                    {
                                        break lab11;
                                    }
                                    break lab9;
                                }
                                cursor = limit - v_14;
                            }
                            slice_from("\u0BCD");
                            break;
                        case 6:
                            {
                                int v_15 = limit - cursor;
                                lab12: while (true) {
                                    if (find_among_b(a_3, null) == 0)
                                    {
                                        break lab12;
                                    }
                                    break lab9;
                                }
                                cursor = limit - v_15;
                            }
                            slice_del();
                            break;
                        case 7:
                            slice_from("\u0BBF");
                            break;
                    }
                    cursor = limit - v_13;
                    break lab8;
                }
                cursor = limit - v_12;
                int v_16 = limit - cursor;
                ket = cursor;
                if (!(eq_s_b("\u0BC8")))
                {
                    break lab7;
                }
                lab13: while (true) {
                    int v_17 = limit - cursor;
                    lab14: while (true) {
                        {
                            int v_18 = limit - cursor;
                            lab15: while (true) {
                                if (find_among_b(a_6, null) == 0)
                                {
                                    break lab15;
                                }
                                break lab14;
                            }
                            cursor = limit - v_18;
                        }
                        break lab13;
                    }
                    cursor = limit - v_17;
                    int v_19 = limit - cursor;
                    if (find_among_b(a_6, null) == 0)
                    {
                        break lab7;
                    }
                    if (!(eq_s_b("\u0BCD")))
                    {
                        break lab7;
                    }
                    cursor = limit - v_19;
                    break lab13;
                }
                bra = cursor;
                slice_from("\u0BCD");
                cursor = limit - v_16;
                break lab8;
            }
            B_found_vetrumai_urupu = true;
            int v_20 = limit - cursor;
            lab16: while (true) {
                ket = cursor;
                if (!(eq_s_b("\u0BBF\u0BA9\u0BCD")))
                {
                    break lab16;
                }
                bra = cursor;
                slice_from("\u0BCD");
                break lab16;
            }
            cursor = limit - v_20;
            cursor = limit_backward;
            r_fix_endings();
            break lab7;
        }
        cursor = v_11;
        int v_21 = cursor;
        lab17: while (true) {
            limit_backward = cursor;
            cursor = limit;
            ket = cursor;
            among_var = find_among_b(a_10, null);
            if (among_var == 0)
            {
                break lab17;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    lab18: while (true) {
                        int v_22 = limit - cursor;
                        lab19: while (true) {
                            if (find_among_b(a_6, null) == 0)
                            {
                                break lab19;
                            }
                            slice_from("\u0BC1\u0B99\u0BCD");
                            break lab18;
                        }
                        cursor = limit - v_22;
                        slice_from("\u0BCD");
                        break lab18;
                    }
                    break;
                case 2:
                    slice_from("\u0BB2\u0BCD");
                    break;
                case 3:
                    slice_from("\u0BB3\u0BCD");
                    break;
                case 4:
                    slice_del();
                    break;
            }
            cursor = limit_backward;
            break lab17;
        }
        cursor = v_21;
        int v_23 = cursor;
        lab20: while (true) {
            if (current.length < 5)
            {
                break lab20;
            }
            limit_backward = cursor;
            cursor = limit;
            ket = cursor;
            if (find_among_b(a_12, null) == 0)
            {
                break lab20;
            }
            bra = cursor;
            slice_del();
            cursor = limit_backward;
            break lab20;
        }
        cursor = v_23;
        int v_24 = cursor;
        lab21: while (true) {
            replab22: while(true)
            {
                int v_25 = cursor;
                lab23: while (true) {
                    B_found_a_match = false;
                    if (current.length < 5)
                    {
                        break lab23;
                    }
                    limit_backward = cursor;
                    cursor = limit;
                    int v_26 = limit - cursor;
                    lab24: while (true) {
                        int v_27 = limit - cursor;
                        ket = cursor;
                        among_var = find_among_b(a_16, null);
                        if (among_var == 0)
                        {
                            break lab24;
                        }
                        bra = cursor;
                        switch (among_var) {
                            case 1:
                                slice_del();
                                break;
                            case 2:
                                {
                                    int v_28 = limit - cursor;
                                    lab25: while (true) {
                                        if (find_among_b(a_15, null) == 0)
                                        {
                                            break lab25;
                                        }
                                        break lab24;
                                    }
                                    cursor = limit - v_28;
                                }
                                slice_del();
                                break;
                            case 3:
                                {
                                    int v_29 = limit - cursor;
                                    lab26: while (true) {
                                        if (find_among_b(a_3, null) == 0)
                                        {
                                            break lab26;
                                        }
                                        break lab24;
                                    }
                                    cursor = limit - v_29;
                                }
                                slice_del();
                                break;
                            case 4:
                                lab27: while (true) {
                                    if (!(eq_s_b("\u0B9A")))
                                    {
                                        break lab27;
                                    }
                                    break lab24;
                                }
                                slice_from("\u0BCD");
                                break;
                            case 5:
                                slice_from("\u0BCD");
                                break;
                            case 6:
                                int v_30 = limit - cursor;
                                if (!(eq_s_b("\u0BCD")))
                                {
                                    break lab24;
                                }
                                cursor = limit - v_30;
                                slice_del();
                                break;
                        }
                        B_found_a_match = true;
                        cursor = limit - v_27;
                        break lab24;
                    }
                    cursor = limit - v_26;
                    int v_31 = limit - cursor;
                    lab28: while (true) {
                        ket = cursor;
                        if (find_among_b(a_17, null) == 0)
                        {
                            break lab28;
                        }
                        bra = cursor;
                        slice_del();
                        B_found_a_match = true;
                        break lab28;
                    }
                    cursor = limit - v_31;
                    cursor = limit_backward;
                    r_fix_endings();
                    if (!B_found_a_match)
                    {
                        break lab23;
                    }
                    continue replab22;
                }
                cursor = v_25;
                break replab22;
            }
            break lab21;
        }
        cursor = v_24;
        return true;
    }

    @override
    bool operator ==(Object other) => other is tamil_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
