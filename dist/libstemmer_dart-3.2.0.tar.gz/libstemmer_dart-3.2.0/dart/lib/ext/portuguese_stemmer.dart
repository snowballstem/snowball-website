// Generated from portuguese.sbl by Snowball 3.2.0 - https://snowballstem.org/

// ignore_for_file: non_constant_identifier_names, slash_for_doc_comments, camel_case_types

import '../src/snowball.dart';

/**
 * This class implements the stemming algorithm defined by a snowball script.
 *
 * Generated from portuguese.sbl by Snowball 3.2.0 - https://snowballstem.org/
 */
class portuguese_stemmer extends SnowballStemmer {
    static final a_0 = [
        Among("", -1, 3, 0),
        Among("\u00E3", 0, 1, 0),
        Among("\u00F5", 0, 2, 0)
    ];

    static final a_1 = [
        Among("", -1, 3, 0),
        Among("a~", 0, 1, 0),
        Among("o~", 0, 2, 0)
    ];

    static final a_2 = [
        Among("ic", -1, -1, 0),
        Among("ad", -1, -1, 0),
        Among("os", -1, -1, 0),
        Among("iv", -1, 1, 0)
    ];

    static final a_3 = [
        Among("ante", -1, 1, 0),
        Among("avel", -1, 1, 0),
        Among("\u00EDvel", -1, 1, 0)
    ];

    static final a_4 = [
        Among("ic", -1, 1, 0),
        Among("abil", -1, 1, 0),
        Among("iv", -1, 1, 0)
    ];

    static final a_5 = [
        Among("ica", -1, 1, 0),
        Among("\u00E2ncia", -1, 1, 0),
        Among("\u00EAncia", -1, 4, 0),
        Among("logia", -1, 2, 0),
        Among("ira", -1, 9, 0),
        Among("adora", -1, 1, 0),
        Among("osa", -1, 1, 0),
        Among("ista", -1, 1, 0),
        Among("iva", -1, 8, 0),
        Among("eza", -1, 1, 0),
        Among("idade", -1, 7, 0),
        Among("ante", -1, 1, 0),
        Among("mente", -1, 6, 0),
        Among("amente", 12, 5, 0),
        Among("\u00E1vel", -1, 1, 0),
        Among("\u00EDvel", -1, 1, 0),
        Among("ico", -1, 1, 0),
        Among("ismo", -1, 1, 0),
        Among("oso", -1, 1, 0),
        Among("amento", -1, 1, 0),
        Among("imento", -1, 1, 0),
        Among("ivo", -1, 8, 0),
        Among("a\u00E7a~o", -1, 1, 0),
        Among("u\u00E7a~o", -1, 3, 0),
        Among("ador", -1, 1, 0),
        Among("icas", -1, 1, 0),
        Among("\u00EAncias", -1, 4, 0),
        Among("logias", -1, 2, 0),
        Among("iras", -1, 9, 0),
        Among("adoras", -1, 1, 0),
        Among("osas", -1, 1, 0),
        Among("istas", -1, 1, 0),
        Among("ivas", -1, 8, 0),
        Among("ezas", -1, 1, 0),
        Among("idades", -1, 7, 0),
        Among("adores", -1, 1, 0),
        Among("antes", -1, 1, 0),
        Among("a\u00E7o~es", -1, 1, 0),
        Among("u\u00E7o~es", -1, 3, 0),
        Among("icos", -1, 1, 0),
        Among("ismos", -1, 1, 0),
        Among("osos", -1, 1, 0),
        Among("amentos", -1, 1, 0),
        Among("imentos", -1, 1, 0),
        Among("ivos", -1, 8, 0)
    ];

    static final a_6 = [
        Among("ada", -1, 1, 0),
        Among("ida", -1, 1, 0),
        Among("ia", -1, 1, 0),
        Among("aria", 2, 1, 0),
        Among("eria", 2, 1, 0),
        Among("iria", 2, 1, 0),
        Among("ara", -1, 1, 0),
        Among("era", -1, 1, 0),
        Among("ira", -1, 1, 0),
        Among("ava", -1, 1, 0),
        Among("asse", -1, 1, 0),
        Among("esse", -1, 1, 0),
        Among("isse", -1, 1, 0),
        Among("aste", -1, 1, 0),
        Among("este", -1, 1, 0),
        Among("iste", -1, 1, 0),
        Among("ei", -1, 1, 0),
        Among("arei", 16, 1, 0),
        Among("erei", 16, 1, 0),
        Among("irei", 16, 1, 0),
        Among("am", -1, 1, 0),
        Among("iam", 20, 1, 0),
        Among("ariam", 21, 1, 0),
        Among("eriam", 21, 1, 0),
        Among("iriam", 21, 1, 0),
        Among("aram", 20, 1, 0),
        Among("eram", 20, 1, 0),
        Among("iram", 20, 1, 0),
        Among("avam", 20, 1, 0),
        Among("em", -1, 1, 0),
        Among("arem", 29, 1, 0),
        Among("erem", 29, 1, 0),
        Among("irem", 29, 1, 0),
        Among("assem", 29, 1, 0),
        Among("essem", 29, 1, 0),
        Among("issem", 29, 1, 0),
        Among("ado", -1, 1, 0),
        Among("ido", -1, 1, 0),
        Among("ando", -1, 1, 0),
        Among("endo", -1, 1, 0),
        Among("indo", -1, 1, 0),
        Among("ara~o", -1, 1, 0),
        Among("era~o", -1, 1, 0),
        Among("ira~o", -1, 1, 0),
        Among("ar", -1, 1, 0),
        Among("er", -1, 1, 0),
        Among("ir", -1, 1, 0),
        Among("as", -1, 1, 0),
        Among("adas", 47, 1, 0),
        Among("idas", 47, 1, 0),
        Among("ias", 47, 1, 0),
        Among("arias", 50, 1, 0),
        Among("erias", 50, 1, 0),
        Among("irias", 50, 1, 0),
        Among("aras", 47, 1, 0),
        Among("eras", 47, 1, 0),
        Among("iras", 47, 1, 0),
        Among("avas", 47, 1, 0),
        Among("es", -1, 1, 0),
        Among("ardes", 58, 1, 0),
        Among("erdes", 58, 1, 0),
        Among("irdes", 58, 1, 0),
        Among("ares", 58, 1, 0),
        Among("eres", 58, 1, 0),
        Among("ires", 58, 1, 0),
        Among("asses", 58, 1, 0),
        Among("esses", 58, 1, 0),
        Among("isses", 58, 1, 0),
        Among("astes", 58, 1, 0),
        Among("estes", 58, 1, 0),
        Among("istes", 58, 1, 0),
        Among("is", -1, 1, 0),
        Among("ais", 71, 1, 0),
        Among("eis", 71, 1, 0),
        Among("areis", 73, 1, 0),
        Among("ereis", 73, 1, 0),
        Among("ireis", 73, 1, 0),
        Among("\u00E1reis", 73, 1, 0),
        Among("\u00E9reis", 73, 1, 0),
        Among("\u00EDreis", 73, 1, 0),
        Among("\u00E1sseis", 73, 1, 0),
        Among("\u00E9sseis", 73, 1, 0),
        Among("\u00EDsseis", 73, 1, 0),
        Among("\u00E1veis", 73, 1, 0),
        Among("\u00EDeis", 73, 1, 0),
        Among("ar\u00EDeis", 84, 1, 0),
        Among("er\u00EDeis", 84, 1, 0),
        Among("ir\u00EDeis", 84, 1, 0),
        Among("ados", -1, 1, 0),
        Among("idos", -1, 1, 0),
        Among("amos", -1, 1, 0),
        Among("\u00E1ramos", 90, 1, 0),
        Among("\u00E9ramos", 90, 1, 0),
        Among("\u00EDramos", 90, 1, 0),
        Among("\u00E1vamos", 90, 1, 0),
        Among("\u00EDamos", 90, 1, 0),
        Among("ar\u00EDamos", 95, 1, 0),
        Among("er\u00EDamos", 95, 1, 0),
        Among("ir\u00EDamos", 95, 1, 0),
        Among("emos", -1, 1, 0),
        Among("aremos", 99, 1, 0),
        Among("eremos", 99, 1, 0),
        Among("iremos", 99, 1, 0),
        Among("\u00E1ssemos", 99, 1, 0),
        Among("\u00EAssemos", 99, 1, 0),
        Among("\u00EDssemos", 99, 1, 0),
        Among("imos", -1, 1, 0),
        Among("armos", -1, 1, 0),
        Among("ermos", -1, 1, 0),
        Among("irmos", -1, 1, 0),
        Among("\u00E1mos", -1, 1, 0),
        Among("ar\u00E1s", -1, 1, 0),
        Among("er\u00E1s", -1, 1, 0),
        Among("ir\u00E1s", -1, 1, 0),
        Among("eu", -1, 1, 0),
        Among("iu", -1, 1, 0),
        Among("ou", -1, 1, 0),
        Among("ar\u00E1", -1, 1, 0),
        Among("er\u00E1", -1, 1, 0),
        Among("ir\u00E1", -1, 1, 0)
    ];

    static final a_7 = [
        Among("a", -1, 1, 0),
        Among("i", -1, 1, 0),
        Among("o", -1, 1, 0),
        Among("os", -1, 1, 0),
        Among("\u00E1", -1, 1, 0),
        Among("\u00ED", -1, 1, 0),
        Among("\u00F3", -1, 1, 0)
    ];

    static final a_8 = [
        Among("e", -1, 1, 0),
        Among("\u00E7", -1, 2, 0),
        Among("\u00E9", -1, 1, 0),
        Among("\u00EA", -1, 1, 0)
    ];

    static final g_v = String.fromCharCodes([17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 19, 12, 2]);


    @override
    bool stem() {
        int among_var;
        int I_p2;
        int I_p1;
        int I_pV;
        int v_1 = cursor;
        lab0: while (true) {
            replab1: while(true)
            {
                int v_2 = cursor;
                lab2: while (true) {
                    bra = cursor;
                    among_var = find_among(a_0, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("a~");
                            break;
                        case 2:
                            slice_from("o~");
                            break;
                        case 3:
                            if (cursor >= limit)
                            {
                                break lab2;
                            }
                            cursor++;
                            break;
                    }
                    continue replab1;
                }
                cursor = v_2;
                break replab1;
            }
            break lab0;
        }
        cursor = v_1;
        lab3: while (true) {
            I_pV = limit;
            I_p1 = limit;
            I_p2 = limit;
            int v_3 = cursor;
            lab4: while (true) {
                lab5: while (true) {
                    int v_4 = cursor;
                    lab6: while (true) {
                        if (!(in_grouping(g_v, 97, 250)))
                        {
                            break lab6;
                        }
                        lab7: while (true) {
                            int v_5 = cursor;
                            lab8: while (true) {
                                if (!(out_grouping(g_v, 97, 250)))
                                {
                                    break lab8;
                                }
                                if (!go_out_grouping(g_v, 97, 250))
                                {
                                    break lab8;
                                }
                                cursor++;
                                break lab7;
                            }
                            cursor = v_5;
                            if (!(in_grouping(g_v, 97, 250)))
                            {
                                break lab6;
                            }
                            if (!go_in_grouping(g_v, 97, 250))
                            {
                                break lab6;
                            }
                            cursor++;
                            break lab7;
                        }
                        break lab5;
                    }
                    cursor = v_4;
                    if (!(out_grouping(g_v, 97, 250)))
                    {
                        break lab4;
                    }
                    lab9: while (true) {
                        int v_6 = cursor;
                        lab10: while (true) {
                            if (!(out_grouping(g_v, 97, 250)))
                            {
                                break lab10;
                            }
                            if (!go_out_grouping(g_v, 97, 250))
                            {
                                break lab10;
                            }
                            cursor++;
                            break lab9;
                        }
                        cursor = v_6;
                        if (!(in_grouping(g_v, 97, 250)))
                        {
                            break lab4;
                        }
                        if (cursor >= limit)
                        {
                            break lab4;
                        }
                        cursor++;
                        break lab9;
                    }
                    break lab5;
                }
                I_pV = cursor;
                break lab4;
            }
            cursor = v_3;
            int v_7 = cursor;
            lab11: while (true) {
                if (!go_out_grouping(g_v, 97, 250))
                {
                    break lab11;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 250))
                {
                    break lab11;
                }
                cursor++;
                I_p1 = cursor;
                if (!go_out_grouping(g_v, 97, 250))
                {
                    break lab11;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 250))
                {
                    break lab11;
                }
                cursor++;
                I_p2 = cursor;
                break lab11;
            }
            cursor = v_7;
            break lab3;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_8 = limit - cursor;
        lab12: while (true) {
            lab13: while (true) {
                int v_9 = limit - cursor;
                lab14: while (true) {
                    int v_10 = limit - cursor;
                    lab15: while (true) {
                        int v_11 = limit - cursor;
                        lab16: while (true) {
                            ket = cursor;
                            among_var = find_among_b(a_5, null);
                            if (among_var == 0)
                            {
                                break lab16;
                            }
                            bra = cursor;
                            switch (among_var) {
                                case 1:
                                    if (I_p2 > cursor)
                                    {
                                        break lab16;
                                    }
                                    slice_del();
                                    break;
                                case 2:
                                    if (I_p2 > cursor)
                                    {
                                        break lab16;
                                    }
                                    slice_from("log");
                                    break;
                                case 3:
                                    if (I_p2 > cursor)
                                    {
                                        break lab16;
                                    }
                                    slice_from("u");
                                    break;
                                case 4:
                                    if (I_p2 > cursor)
                                    {
                                        break lab16;
                                    }
                                    slice_from("ente");
                                    break;
                                case 5:
                                    if (I_p1 > cursor)
                                    {
                                        break lab16;
                                    }
                                    slice_del();
                                    int v_12 = limit - cursor;
                                    lab17: while (true) {
                                        ket = cursor;
                                        among_var = find_among_b(a_2, null);
                                        if (among_var == 0)
                                        {
                                            cursor = limit - v_12;
                                            break lab17;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_12;
                                            break lab17;
                                        }
                                        slice_del();
                                        switch (among_var) {
                                            case 1:
                                                ket = cursor;
                                                if (!(eq_s_b("at")))
                                                {
                                                    cursor = limit - v_12;
                                                    break lab17;
                                                }
                                                bra = cursor;
                                                if (I_p2 > cursor)
                                                {
                                                    cursor = limit - v_12;
                                                    break lab17;
                                                }
                                                slice_del();
                                                break;
                                        }
                                        break lab17;
                                    }
                                    break;
                                case 6:
                                    if (I_p2 > cursor)
                                    {
                                        break lab16;
                                    }
                                    slice_del();
                                    int v_13 = limit - cursor;
                                    lab18: while (true) {
                                        ket = cursor;
                                        if (find_among_b(a_3, null) == 0)
                                        {
                                            cursor = limit - v_13;
                                            break lab18;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_13;
                                            break lab18;
                                        }
                                        slice_del();
                                        break lab18;
                                    }
                                    break;
                                case 7:
                                    if (I_p2 > cursor)
                                    {
                                        break lab16;
                                    }
                                    slice_del();
                                    int v_14 = limit - cursor;
                                    lab19: while (true) {
                                        ket = cursor;
                                        if (find_among_b(a_4, null) == 0)
                                        {
                                            cursor = limit - v_14;
                                            break lab19;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_14;
                                            break lab19;
                                        }
                                        slice_del();
                                        break lab19;
                                    }
                                    break;
                                case 8:
                                    if (I_p2 > cursor)
                                    {
                                        break lab16;
                                    }
                                    slice_del();
                                    int v_15 = limit - cursor;
                                    lab20: while (true) {
                                        ket = cursor;
                                        if (!(eq_s_b("at")))
                                        {
                                            cursor = limit - v_15;
                                            break lab20;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_15;
                                            break lab20;
                                        }
                                        slice_del();
                                        break lab20;
                                    }
                                    break;
                                case 9:
                                    if (I_pV > cursor)
                                    {
                                        break lab16;
                                    }
                                    if (!(eq_s_b("e")))
                                    {
                                        break lab16;
                                    }
                                    slice_from("ir");
                                    break;
                            }
                            break lab15;
                        }
                        cursor = limit - v_11;
                        if (cursor < I_pV)
                        {
                            break lab14;
                        }
                        int v_16 = limit_backward;
                        limit_backward = I_pV;
                        ket = cursor;
                        if (find_among_b(a_6, null) == 0)
                        {
                            limit_backward = v_16;
                            break lab14;
                        }
                        bra = cursor;
                        slice_del();
                        limit_backward = v_16;
                        break lab15;
                    }
                    cursor = limit - v_10;
                    int v_17 = limit - cursor;
                    lab21: while (true) {
                        ket = cursor;
                        if (!(eq_s_b("i")))
                        {
                            break lab21;
                        }
                        bra = cursor;
                        int v_18 = limit - cursor;
                        if (!(eq_s_b("c")))
                        {
                            break lab21;
                        }
                        cursor = limit - v_18;
                        if (I_pV > cursor)
                        {
                            break lab21;
                        }
                        slice_del();
                        break lab21;
                    }
                    cursor = limit - v_17;
                    break lab13;
                }
                cursor = limit - v_9;
                ket = cursor;
                if (find_among_b(a_7, null) == 0)
                {
                    break lab12;
                }
                bra = cursor;
                if (I_pV > cursor)
                {
                    break lab12;
                }
                slice_del();
                break lab13;
            }
            break lab12;
        }
        cursor = limit - v_8;
        int v_19 = limit - cursor;
        lab22: while (true) {
            ket = cursor;
            among_var = find_among_b(a_8, null);
            if (among_var == 0)
            {
                break lab22;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    if (I_pV > cursor)
                    {
                        break lab22;
                    }
                    slice_del();
                    ket = cursor;
                    lab23: while (true) {
                        int v_20 = limit - cursor;
                        lab24: while (true) {
                            if (!(eq_s_b("u")))
                            {
                                break lab24;
                            }
                            bra = cursor;
                            int v_21 = limit - cursor;
                            if (!(eq_s_b("g")))
                            {
                                break lab24;
                            }
                            cursor = limit - v_21;
                            break lab23;
                        }
                        cursor = limit - v_20;
                        if (!(eq_s_b("i")))
                        {
                            break lab22;
                        }
                        bra = cursor;
                        int v_22 = limit - cursor;
                        if (!(eq_s_b("c")))
                        {
                            break lab22;
                        }
                        cursor = limit - v_22;
                        break lab23;
                    }
                    if (I_pV > cursor)
                    {
                        break lab22;
                    }
                    slice_del();
                    break;
                case 2:
                    slice_from("c");
                    break;
            }
            break lab22;
        }
        cursor = limit - v_19;
        cursor = limit_backward;
        int v_23 = cursor;
        lab25: while (true) {
            replab26: while(true)
            {
                int v_24 = cursor;
                lab27: while (true) {
                    bra = cursor;
                    among_var = find_among(a_1, null);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("\u00E3");
                            break;
                        case 2:
                            slice_from("\u00F5");
                            break;
                        case 3:
                            if (cursor >= limit)
                            {
                                break lab27;
                            }
                            cursor++;
                            break;
                    }
                    continue replab26;
                }
                cursor = v_24;
                break replab26;
            }
            break lab25;
        }
        cursor = v_23;
        return true;
    }

    @override
    bool operator ==(Object other) => other is portuguese_stemmer;

    @override
    int get hashCode => runtimeType.toString().hashCode;

}
