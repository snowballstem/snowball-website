/* Generated from spanish.sbl by Snowball 3.1.1 - https://snowballstem.org/ */

#ifdef __cplusplus
extern "C" {
#endif

extern struct SN_env * spanish_ISO_8859_1_create_env(void);
extern void spanish_ISO_8859_1_close_env(struct SN_env * z);

extern int spanish_ISO_8859_1_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif
