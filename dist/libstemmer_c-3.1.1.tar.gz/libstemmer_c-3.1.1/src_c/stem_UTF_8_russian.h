/* Generated from russian.sbl by Snowball 3.1.1 - https://snowballstem.org/ */

#ifdef __cplusplus
extern "C" {
#endif

extern struct SN_env * russian_UTF_8_create_env(void);
extern void russian_UTF_8_close_env(struct SN_env * z);

extern int russian_UTF_8_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif
