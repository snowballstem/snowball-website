// Generated from danish.sbl by Snowball 3.1.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import java.util.Arrays;

import org.tartarus.snowball.Among;

import org.tartarus.snowball.CharArraySequence;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from danish.sbl by Snowball 3.1.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class danishStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("hed", -1, 1),
        new Among("ethed", 0, 1),
        new Among("ered", -1, 1),
        new Among("e", -1, 1),
        new Among("erede", 3, 1),
        new Among("ende", 3, 1),
        new Among("erende", 5, 1),
        new Among("ene", 3, 1),
        new Among("erne", 3, 1),
        new Among("ere", 3, 1),
        new Among("en", -1, 1),
        new Among("heden", 10, 1),
        new Among("eren", 10, 1),
        new Among("er", -1, 1),
        new Among("heder", 13, 1),
        new Among("erer", 13, 1),
        new Among("s", -1, 2),
        new Among("heds", 16, 1),
        new Among("es", 16, 1),
        new Among("endes", 18, 1),
        new Among("erendes", 19, 1),
        new Among("enes", 18, 1),
        new Among("ernes", 18, 1),
        new Among("eres", 18, 1),
        new Among("ens", 16, 1),
        new Among("hedens", 24, 1),
        new Among("erens", 24, 1),
        new Among("ers", 16, 1),
        new Among("ets", 16, 1),
        new Among("erets", 28, 1),
        new Among("et", -1, 1),
        new Among("eret", 30, 1)
    };

    private final static Among[] a_1 = {
        new Among("gd", -1, -1),
        new Among("dt", -1, -1),
        new Among("gt", -1, -1),
        new Among("kt", -1, -1)
    };

    private final static Among[] a_2 = {
        new Among("ig", -1, 1),
        new Among("lig", 0, 1),
        new Among("elig", 1, 1),
        new Among("els", -1, 1),
        new Among("l\u00F8st", -1, 2)
    };

    private static final char[] g_undouble_c = {53, 94, 7 };

    private static final char[] g_v = {17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 0, 128 };

    private static final char[] g_s_ending = {1, 0, 0, 0, 0, 0, 0, 188, 251, 171, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64 };

    private int I_p1;
    private char[] S_ch = new char[8];
    private int LS_ch = 0;


    private boolean r_mark_regions() {
        I_p1 = limit;
        int v_1 = cursor;
        lab0: {
            lab1: {
                int v_2 = cursor;
                lab2: {
                    golab3: while (true)
                    {
                        lab4: {
                            if (!(eq_s("'")))
                            {
                                break lab4;
                            }
                            break golab3;
                        }
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    break lab1;
                }
                cursor = v_2;
                if (!go_out_grouping(g_v, 97, 248))
                {
                    break lab0;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 248))
                {
                    break lab0;
                }
                cursor++;
            }
            I_p1 = cursor;
        }
        cursor = v_1;
        int v_3 = cursor;
        {
            int c = cursor + 3;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        lab5: {
            if (I_p1 >= cursor)
            {
                break lab5;
            }
            I_p1 = cursor;
        }
        cursor = v_3;
        return true;
    }

    private boolean r_main_suffix() {
        int among_var;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_0);
        if (among_var == 0)
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        limit_backward = v_1;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                if (!(in_grouping_b(g_s_ending, 39, 229)))
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_consonant_pair() {
        int v_1 = limit - cursor;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_2 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (find_among_b(a_1) == 0)
        {
            limit_backward = v_2;
            return false;
        }
        bra = cursor;
        limit_backward = v_2;
        cursor = limit - v_1;
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor--;
        bra = cursor;
        slice_del();
        return true;
    }

    private boolean r_other_suffix() {
        int among_var;
        int v_1 = limit - cursor;
        lab0: {
            ket = cursor;
            if (!(eq_s_b("st")))
            {
                break lab0;
            }
            bra = cursor;
            if (!(eq_s_b("ig")))
            {
                break lab0;
            }
            slice_del();
        }
        cursor = limit - v_1;
        if (cursor < I_p1)
        {
            return false;
        }
        int v_2 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        among_var = find_among_b(a_2);
        if (among_var == 0)
        {
            limit_backward = v_2;
            return false;
        }
        bra = cursor;
        limit_backward = v_2;
        switch (among_var) {
            case 1:
                slice_del();
                int v_3 = limit - cursor;
                r_consonant_pair();
                cursor = limit - v_3;
                break;
            case 2:
                slice_from("l\u00F8s");
                break;
        }
        return true;
    }

    private boolean r_undouble() {
        if (cursor < I_p1)
        {
            return false;
        }
        int v_1 = limit_backward;
        limit_backward = I_p1;
        ket = cursor;
        if (!(in_grouping_b(g_undouble_c, 98, 116)))
        {
            limit_backward = v_1;
            return false;
        }
        bra = cursor;
        slice_check();
        if (S_ch.length < ket - bra) {
            S_ch = Arrays.copyOfRange(current, bra, ket);
        } else {
            System.arraycopy(current, bra, S_ch, 0, ket - bra);
        }
        LS_ch = ket - bra;
        limit_backward = v_1;
        if (!(eq_s_b(new CharArraySequence(S_ch, LS_ch))))
        {
            return false;
        }
        slice_del();
        return true;
    }

    @Override
    public boolean stem() {
        if (!r_mark_regions())
        {
            return false;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        r_main_suffix();
        cursor = limit - v_1;
        int v_2 = limit - cursor;
        r_consonant_pair();
        cursor = limit - v_2;
        int v_3 = limit - cursor;
        r_other_suffix();
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        r_undouble();
        cursor = limit - v_4;
        ket = cursor;
        if (!(eq_s_b("'")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof danishStemmer;
    }

    @Override
    public int hashCode() {
        return danishStemmer.class.getName().hashCode();
    }

}
