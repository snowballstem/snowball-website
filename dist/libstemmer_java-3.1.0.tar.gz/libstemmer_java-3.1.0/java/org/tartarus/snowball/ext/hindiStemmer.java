// Generated from hindi.sbl by Snowball 3.1.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from hindi.sbl by Snowball 3.1.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class hindiStemmer extends org.tartarus.snowball.SnowballStemmer {
    private static final java.lang.invoke.MethodHandles.Lookup methodObject = java.lang.invoke.MethodHandles.lookup();

    private final static Among[] a_0 = {
        new Among("\u0906\u0901", -1, -1),
        new Among("\u093E\u0901", -1, -1),
        new Among("\u0907\u092F\u093E\u0901", 1, -1),
        new Among("\u0906\u0907\u092F\u093E\u0901", 2, -1),
        new Among("\u093E\u0907\u092F\u093E\u0901", 2, -1),
        new Among("\u093F\u092F\u093E\u0901", 1, -1),
        new Among("\u0906\u0902", -1, -1),
        new Among("\u0909\u0906\u0902", 6, -1),
        new Among("\u0941\u0906\u0902", 6, -1),
        new Among("\u0908\u0902", -1, -1),
        new Among("\u0906\u0908\u0902", 9, -1),
        new Among("\u093E\u0908\u0902", 9, -1),
        new Among("\u090F\u0902", -1, -1),
        new Among("\u0906\u090F\u0902", 12, -1),
        new Among("\u0909\u090F\u0902", 12, -1),
        new Among("\u093E\u090F\u0902", 12, -1),
        new Among("\u0924\u093E\u090F\u0902", 15, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0924\u093E\u090F\u0902", 16, -1),
        new Among("\u0928\u093E\u090F\u0902", 15, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0928\u093E\u090F\u0902", 18, -1),
        new Among("\u0941\u090F\u0902", 12, -1),
        new Among("\u0913\u0902", -1, -1),
        new Among("\u0906\u0913\u0902", 21, -1),
        new Among("\u0909\u0913\u0902", 21, -1),
        new Among("\u093E\u0913\u0902", 21, -1),
        new Among("\u0924\u093E\u0913\u0902", 24, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0924\u093E\u0913\u0902", 25, -1),
        new Among("\u0928\u093E\u0913\u0902", 24, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0928\u093E\u0913\u0902", 27, -1),
        new Among("\u0941\u0913\u0902", 21, -1),
        new Among("\u093E\u0902", -1, -1),
        new Among("\u0907\u092F\u093E\u0902", 30, -1),
        new Among("\u0906\u0907\u092F\u093E\u0902", 31, -1),
        new Among("\u093E\u0907\u092F\u093E\u0902", 31, -1),
        new Among("\u093F\u092F\u093E\u0902", 30, -1),
        new Among("\u0940\u0902", -1, -1),
        new Among("\u0924\u0940\u0902", 35, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0924\u0940\u0902", 36, -1),
        new Among("\u0906\u0924\u0940\u0902", 36, -1),
        new Among("\u093E\u0924\u0940\u0902", 36, -1),
        new Among("\u0947\u0902", -1, -1),
        new Among("\u094B\u0902", -1, -1),
        new Among("\u0907\u092F\u094B\u0902", 41, -1),
        new Among("\u0906\u0907\u092F\u094B\u0902", 42, -1),
        new Among("\u093E\u0907\u092F\u094B\u0902", 42, -1),
        new Among("\u093F\u092F\u094B\u0902", 41, -1),
        new Among("\u0905", -1, -1),
        new Among("\u0906", -1, -1),
        new Among("\u0907", -1, -1),
        new Among("\u0908", -1, -1),
        new Among("\u0906\u0908", 49, -1),
        new Among("\u093E\u0908", 49, -1),
        new Among("\u0909", -1, -1),
        new Among("\u090A", -1, -1),
        new Among("\u090F", -1, -1),
        new Among("\u0906\u090F", 54, -1),
        new Among("\u0907\u090F", 54, -1),
        new Among("\u0906\u0907\u090F", 56, -1),
        new Among("\u093E\u0907\u090F", 56, -1),
        new Among("\u093E\u090F", 54, -1),
        new Among("\u093F\u090F", 54, -1),
        new Among("\u0913", -1, -1),
        new Among("\u0906\u0913", 61, -1),
        new Among("\u093E\u0913", 61, -1),
        new Among("\u0915\u0930", -1, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0915\u0930", 64, -1),
        new Among("\u0906\u0915\u0930", 64, -1),
        new Among("\u093E\u0915\u0930", 64, -1),
        new Among("\u093E", -1, -1),
        new Among("\u090A\u0902\u0917\u093E", 68, -1),
        new Among("\u0906\u090A\u0902\u0917\u093E", 69, -1),
        new Among("\u093E\u090A\u0902\u0917\u093E", 69, -1),
        new Among("\u0942\u0902\u0917\u093E", 68, -1),
        new Among("\u090F\u0917\u093E", 68, -1),
        new Among("\u0906\u090F\u0917\u093E", 73, -1),
        new Among("\u093E\u090F\u0917\u093E", 73, -1),
        new Among("\u0947\u0917\u093E", 68, -1),
        new Among("\u0924\u093E", 68, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0924\u093E", 77, -1),
        new Among("\u0906\u0924\u093E", 77, -1),
        new Among("\u093E\u0924\u093E", 77, -1),
        new Among("\u0928\u093E", 68, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0928\u093E", 81, -1),
        new Among("\u0906\u0928\u093E", 81, -1),
        new Among("\u093E\u0928\u093E", 81, -1),
        new Among("\u0906\u092F\u093E", 68, -1),
        new Among("\u093E\u092F\u093E", 68, -1),
        new Among("\u093F", -1, -1),
        new Among("\u0940", -1, -1),
        new Among("\u090A\u0902\u0917\u0940", 88, -1),
        new Among("\u0906\u090A\u0902\u0917\u0940", 89, -1),
        new Among("\u093E\u090A\u0902\u0917\u0940", 89, -1),
        new Among("\u090F\u0902\u0917\u0940", 88, -1),
        new Among("\u0906\u090F\u0902\u0917\u0940", 92, -1),
        new Among("\u093E\u090F\u0902\u0917\u0940", 92, -1),
        new Among("\u0942\u0902\u0917\u0940", 88, -1),
        new Among("\u0947\u0902\u0917\u0940", 88, -1),
        new Among("\u090F\u0917\u0940", 88, -1),
        new Among("\u0906\u090F\u0917\u0940", 97, -1),
        new Among("\u093E\u090F\u0917\u0940", 97, -1),
        new Among("\u0913\u0917\u0940", 88, -1),
        new Among("\u0906\u0913\u0917\u0940", 100, -1),
        new Among("\u093E\u0913\u0917\u0940", 100, -1),
        new Among("\u0947\u0917\u0940", 88, -1),
        new Among("\u094B\u0917\u0940", 88, -1),
        new Among("\u0924\u0940", 88, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0924\u0940", 105, -1),
        new Among("\u0906\u0924\u0940", 105, -1),
        new Among("\u093E\u0924\u0940", 105, -1),
        new Among("\u0928\u0940", 88, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0928\u0940", 109, -1),
        new Among("\u0941", -1, -1),
        new Among("\u0942", -1, -1),
        new Among("\u0947", -1, -1),
        new Among("\u090F\u0902\u0917\u0947", 113, -1),
        new Among("\u0906\u090F\u0902\u0917\u0947", 114, -1),
        new Among("\u093E\u090F\u0902\u0917\u0947", 114, -1),
        new Among("\u0947\u0902\u0917\u0947", 113, -1),
        new Among("\u0913\u0917\u0947", 113, -1),
        new Among("\u0906\u0913\u0917\u0947", 118, -1),
        new Among("\u093E\u0913\u0917\u0947", 118, -1),
        new Among("\u094B\u0917\u0947", 113, -1),
        new Among("\u0924\u0947", 113, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0924\u0947", 122, -1),
        new Among("\u0906\u0924\u0947", 122, -1),
        new Among("\u093E\u0924\u0947", 122, -1),
        new Among("\u0928\u0947", 113, -1, "r_CONSONANT", methodObject),
        new Among("\u0905\u0928\u0947", 126, -1),
        new Among("\u0906\u0928\u0947", 126, -1),
        new Among("\u093E\u0928\u0947", 126, -1),
        new Among("\u094B", -1, -1),
        new Among("\u094D", -1, -1)
    };

    private static final char[] g_consonant = {255, 255, 255, 255, 159, 0, 0, 0, 248, 7 };


    private boolean r_CONSONANT() {
        return in_grouping_b(g_consonant, 2325, 2399);
    }

    @Override
    public boolean stem() {
        if (cursor >= limit)
        {
            return false;
        }
        cursor++;
        limit_backward = cursor;
        cursor = limit;
        ket = cursor;
        if (find_among_b(a_0) == 0)
        {
            return false;
        }
        bra = cursor;
        slice_del();
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof hindiStemmer;
    }

    @Override
    public int hashCode() {
        return hindiStemmer.class.getName().hashCode();
    }

}
