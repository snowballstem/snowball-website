# Generated from swedish.sbl by Snowball 3.1.1 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class SwedishStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from swedish.sbl by Snowball 3.1.1 - https://snowballstem.org/
    '''

    g_v = {"a", "e", "i", "o", "u", "y", "ä", "å", "ö"}

    g_s_ending = {"b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "o", "p", "r", "t", "v", "y"}

    g_ost_ending = {"i", "k", "l", "n", "p", "r", "t", "u", "v"}

    I_p1 = 0

    def __r_mark_regions(self):
        self.I_p1 = self.limit
        v_1 = self.cursor
        if self.cursor + 3 > self.limit:
            return False
        self.cursor += 3
        I_x = self.cursor
        self.cursor = v_1
        if not self.go_out_grouping(SwedishStemmer.g_v):
            return False
        self.cursor += 1
        if not self.go_in_grouping(SwedishStemmer.g_v):
            return False
        self.cursor += 1
        self.I_p1 = self.cursor
        try:
            if self.I_p1 >= I_x:
                raise lab0()
            self.I_p1 = I_x
        except lab0: pass
        return True

    def __r_et_condition(self):
        v_1 = self.limit - self.cursor
        if not self.out_grouping_b(SwedishStemmer.g_v):
            return False
        if not self.in_grouping_b(SwedishStemmer.g_v):
            return False
        if self.cursor <= self.limit_backward:
            return False
        self.cursor = self.limit - v_1
        v_2 = self.limit - self.cursor
        try:
            if self.find_among_b(SwedishStemmer.a_0) == 0:
                raise lab0()
            return False
        except lab0: pass
        self.cursor = self.limit - v_2
        return True

    def __r_main_suffix(self):
        if self.cursor < self.I_p1:
            return False
        v_2 = self.limit_backward
        self.limit_backward = self.I_p1
        self.ket = self.cursor
        among_var = self.find_among_b(SwedishStemmer.a_1)
        if among_var == 0:
            self.limit_backward = v_2
            return False
        self.bra = self.cursor
        self.limit_backward = v_2
        if among_var == 1:
            self.slice_del()
        elif among_var == 2:
            while True:
                v_3 = self.limit - self.cursor
                try:
                    if not self.eq_s_b("et"):
                        raise lab0()
                    if not self.__r_et_condition():
                        raise lab0()
                    self.bra = self.cursor
                    break
                except lab0: pass
                self.cursor = self.limit - v_3
                if not self.in_grouping_b(SwedishStemmer.g_s_ending):
                    return False
                break
            self.slice_del()
        else:
            if not self.__r_et_condition():
                return False
            self.slice_del()
        return True

    def __r_consonant_pair(self):
        if self.cursor < self.I_p1:
            return False
        v_2 = self.limit_backward
        self.limit_backward = self.I_p1
        v_3 = self.limit - self.cursor
        if self.find_among_b(SwedishStemmer.a_2) == 0:
            self.limit_backward = v_2
            return False
        self.cursor = self.limit - v_3
        self.ket = self.cursor
        if self.cursor <= self.limit_backward:
            self.limit_backward = v_2
            return False
        self.cursor -= 1
        self.bra = self.cursor
        self.slice_del()
        self.limit_backward = v_2
        return True

    def __r_other_suffix(self):
        if self.cursor < self.I_p1:
            return False
        v_2 = self.limit_backward
        self.limit_backward = self.I_p1
        self.ket = self.cursor
        among_var = self.find_among_b(SwedishStemmer.a_3)
        if among_var == 0:
            self.limit_backward = v_2
            return False
        self.bra = self.cursor
        self.limit_backward = v_2
        if among_var == 1:
            self.slice_del()
        elif among_var == 2:
            if not self.in_grouping_b(SwedishStemmer.g_ost_ending):
                return False
            self.slice_from("ös")
        else:
            self.slice_from("full")
        return True

    def _stem(self):
        v_1 = self.cursor
        self.__r_mark_regions()
        self.cursor = v_1
        self.limit_backward = self.cursor
        self.cursor = self.limit
        v_2 = self.limit - self.cursor
        self.__r_main_suffix()
        self.cursor = self.limit - v_2
        v_3 = self.limit - self.cursor
        self.__r_consonant_pair()
        self.cursor = self.limit - v_3
        v_4 = self.limit - self.cursor
        self.__r_other_suffix()
        self.cursor = self.limit - v_4
        self.cursor = self.limit_backward
        return True

    a_0 = [
        Among("fab", -1, -1),
        Among("h", -1, -1),
        Among("pak", -1, -1),
        Among("rak", -1, -1),
        Among("stak", -1, -1),
        Among("kom", -1, -1),
        Among("iet", -1, -1),
        Among("cit", -1, -1),
        Among("dit", -1, -1),
        Among("alit", -1, -1),
        Among("ilit", -1, -1),
        Among("mit", -1, -1),
        Among("nit", -1, -1),
        Among("pit", -1, -1),
        Among("rit", -1, -1),
        Among("sit", -1, -1),
        Among("tit", -1, -1),
        Among("uit", -1, -1),
        Among("ivit", -1, -1),
        Among("kvit", -1, -1),
        Among("xit", -1, -1)
    ]

    a_1 = [
        Among("a", -1, 1),
        Among("arna", 0, 1),
        Among("erna", 0, 1),
        Among("heterna", 2, 1),
        Among("orna", 0, 1),
        Among("ad", -1, 1),
        Among("e", -1, 1),
        Among("ade", 6, 1),
        Among("ande", 6, 1),
        Among("arne", 6, 1),
        Among("are", 6, 1),
        Among("aste", 6, 1),
        Among("en", -1, 1),
        Among("anden", 12, 1),
        Among("aren", 12, 1),
        Among("heten", 12, 1),
        Among("ern", -1, 1),
        Among("ar", -1, 1),
        Among("er", -1, 1),
        Among("heter", 18, 1),
        Among("or", -1, 1),
        Among("s", -1, 2),
        Among("as", 21, 1),
        Among("arnas", 22, 1),
        Among("ernas", 22, 1),
        Among("ornas", 22, 1),
        Among("es", 21, 1),
        Among("ades", 26, 1),
        Among("andes", 26, 1),
        Among("ens", 21, 1),
        Among("arens", 29, 1),
        Among("hetens", 29, 1),
        Among("erns", 21, 1),
        Among("at", -1, 1),
        Among("et", -1, 3),
        Among("andet", 34, 1),
        Among("het", 34, 1),
        Among("ast", -1, 1)
    ]

    a_2 = [
        Among("dd", -1, -1),
        Among("gd", -1, -1),
        Among("nn", -1, -1),
        Among("dt", -1, -1),
        Among("gt", -1, -1),
        Among("kt", -1, -1),
        Among("tt", -1, -1)
    ]

    a_3 = [
        Among("ig", -1, 1),
        Among("lig", 0, 1),
        Among("els", -1, 1),
        Among("fullt", -1, 3),
        Among("öst", -1, 2)
    ]


class lab0(BaseException): pass
