# Generated from catalan.sbl by Snowball 3.1.1 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class CatalanStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from catalan.sbl by Snowball 3.1.1 - https://snowballstem.org/
    '''

    g_v = {"a", "e", "i", "o", "u", "à", "á", "è", "é", "í", "ï", "ò", "ó", "ú", "ü"}

    I_p2 = 0
    I_p1 = 0

    def __r_mark_regions(self):
        self.I_p1 = self.limit
        self.I_p2 = self.limit
        v_1 = self.cursor
        try:
            if not self.go_out_grouping(CatalanStemmer.g_v):
                raise lab0()
            self.cursor += 1
            if not self.go_in_grouping(CatalanStemmer.g_v):
                raise lab0()
            self.cursor += 1
            self.I_p1 = self.cursor
            if not self.go_out_grouping(CatalanStemmer.g_v):
                raise lab0()
            self.cursor += 1
            if not self.go_in_grouping(CatalanStemmer.g_v):
                raise lab0()
            self.cursor += 1
            self.I_p2 = self.cursor
        except lab0: pass
        self.cursor = v_1
        return True

    def __r_cleaning(self):
        while True:
            v_1 = self.cursor
            try:
                self.bra = self.cursor
                among_var = self.find_among(CatalanStemmer.a_0)
                self.ket = self.cursor
                if among_var == 1:
                    self.slice_from("a")
                elif among_var == 2:
                    self.slice_from("e")
                elif among_var == 3:
                    self.slice_from("i")
                elif among_var == 4:
                    self.slice_from("o")
                elif among_var == 5:
                    self.slice_from("u")
                elif among_var == 6:
                    self.slice_from(".")
                else:
                    if self.cursor >= self.limit:
                        raise lab0()
                    self.cursor += 1
                continue
            except lab0: pass
            self.cursor = v_1
            break
        return True

    def __r_R1(self):
        return self.I_p1 <= self.cursor

    def __r_R2(self):
        return self.I_p2 <= self.cursor

    def __r_attached_pronoun(self):
        self.ket = self.cursor
        if self.find_among_b(CatalanStemmer.a_1) == 0:
            return False
        self.bra = self.cursor
        if not self.__r_R1():
            return False
        self.slice_del()
        return True

    def __r_standard_suffix(self):
        self.ket = self.cursor
        among_var = self.find_among_b(CatalanStemmer.a_2)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if among_var == 1:
            if not self.__r_R1():
                return False
            self.slice_del()
        elif among_var == 2:
            if not self.__r_R2():
                return False
            self.slice_del()
        elif among_var == 3:
            if not self.__r_R2():
                return False
            self.slice_from("log")
        elif among_var == 4:
            if not self.__r_R2():
                return False
            self.slice_from("ic")
        else:
            if not self.__r_R1():
                return False
            self.slice_from("c")
        return True

    def __r_verb_suffix(self):
        self.ket = self.cursor
        among_var = self.find_among_b(CatalanStemmer.a_3)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if among_var == 1:
            if not self.__r_R1():
                return False
            self.slice_del()
        else:
            if not self.__r_R2():
                return False
            self.slice_del()
        return True

    def __r_residual_suffix(self):
        self.ket = self.cursor
        among_var = self.find_among_b(CatalanStemmer.a_4)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if among_var == 1:
            if not self.__r_R1():
                return False
            self.slice_del()
        else:
            if not self.__r_R1():
                return False
            self.slice_from("ic")
        return True

    def _stem(self):
        self.__r_mark_regions()
        self.limit_backward = self.cursor
        self.cursor = self.limit
        v_1 = self.limit - self.cursor
        self.__r_attached_pronoun()
        self.cursor = self.limit - v_1
        v_2 = self.limit - self.cursor
        try:
            while True:
                v_3 = self.limit - self.cursor
                try:
                    if not self.__r_standard_suffix():
                        raise lab1()
                    break
                except lab1: pass
                self.cursor = self.limit - v_3
                if not self.__r_verb_suffix():
                    raise lab0()
                break
        except lab0: pass
        self.cursor = self.limit - v_2
        v_4 = self.limit - self.cursor
        self.__r_residual_suffix()
        self.cursor = self.limit - v_4
        self.cursor = self.limit_backward
        v_5 = self.cursor
        self.__r_cleaning()
        self.cursor = v_5
        return True

    a_0 = [
        Among("", -1, 7),
        Among("·", 0, 6),
        Among("à", 0, 1),
        Among("á", 0, 1),
        Among("è", 0, 2),
        Among("é", 0, 2),
        Among("ì", 0, 3),
        Among("í", 0, 3),
        Among("ï", 0, 3),
        Among("ò", 0, 4),
        Among("ó", 0, 4),
        Among("ú", 0, 5),
        Among("ü", 0, 5)
    ]

    a_1 = [
        Among("la", -1, 1),
        Among("-la", 0, 1),
        Among("sela", 0, 1),
        Among("le", -1, 1),
        Among("me", -1, 1),
        Among("-me", 4, 1),
        Among("se", -1, 1),
        Among("-te", -1, 1),
        Among("hi", -1, 1),
        Among("'hi", 8, 1),
        Among("li", -1, 1),
        Among("-li", 10, 1),
        Among("'l", -1, 1),
        Among("'m", -1, 1),
        Among("-m", -1, 1),
        Among("'n", -1, 1),
        Among("-n", -1, 1),
        Among("ho", -1, 1),
        Among("'ho", 17, 1),
        Among("lo", -1, 1),
        Among("selo", 19, 1),
        Among("'s", -1, 1),
        Among("las", -1, 1),
        Among("selas", 22, 1),
        Among("les", -1, 1),
        Among("-les", 24, 1),
        Among("'ls", -1, 1),
        Among("-ls", -1, 1),
        Among("'ns", -1, 1),
        Among("-ns", -1, 1),
        Among("ens", -1, 1),
        Among("los", -1, 1),
        Among("selos", 31, 1),
        Among("nos", -1, 1),
        Among("-nos", 33, 1),
        Among("vos", -1, 1),
        Among("us", -1, 1),
        Among("-us", 36, 1),
        Among("'t", -1, 1)
    ]

    a_2 = [
        Among("ica", -1, 4),
        Among("lógica", 0, 3),
        Among("enca", -1, 1),
        Among("ada", -1, 2),
        Among("ancia", -1, 1),
        Among("encia", -1, 1),
        Among("ència", -1, 1),
        Among("ícia", -1, 1),
        Among("logia", -1, 3),
        Among("inia", -1, 1),
        Among("íinia", 9, 1),
        Among("eria", -1, 1),
        Among("ària", -1, 1),
        Among("atòria", -1, 1),
        Among("alla", -1, 1),
        Among("ella", -1, 1),
        Among("ívola", -1, 1),
        Among("ima", -1, 1),
        Among("íssima", 17, 1),
        Among("quíssima", 18, 5),
        Among("ana", -1, 1),
        Among("ina", -1, 1),
        Among("era", -1, 1),
        Among("sfera", 22, 1),
        Among("ora", -1, 1),
        Among("dora", 24, 1),
        Among("adora", 25, 1),
        Among("adura", -1, 1),
        Among("esa", -1, 1),
        Among("osa", -1, 1),
        Among("assa", -1, 1),
        Among("essa", -1, 1),
        Among("issa", -1, 1),
        Among("eta", -1, 1),
        Among("ita", -1, 1),
        Among("ota", -1, 1),
        Among("ista", -1, 1),
        Among("ialista", 36, 1),
        Among("ionista", 36, 1),
        Among("iva", -1, 1),
        Among("ativa", 39, 1),
        Among("nça", -1, 1),
        Among("logía", -1, 3),
        Among("ic", -1, 4),
        Among("ístic", 43, 1),
        Among("enc", -1, 1),
        Among("esc", -1, 1),
        Among("ud", -1, 1),
        Among("atge", -1, 1),
        Among("ble", -1, 1),
        Among("able", 49, 1),
        Among("ible", 49, 1),
        Among("isme", -1, 1),
        Among("ialisme", 52, 1),
        Among("ionisme", 52, 1),
        Among("ivisme", 52, 1),
        Among("aire", -1, 1),
        Among("icte", -1, 1),
        Among("iste", -1, 1),
        Among("ici", -1, 1),
        Among("íci", -1, 1),
        Among("logi", -1, 3),
        Among("ari", -1, 1),
        Among("tori", -1, 1),
        Among("al", -1, 1),
        Among("il", -1, 1),
        Among("all", -1, 1),
        Among("ell", -1, 1),
        Among("ívol", -1, 1),
        Among("isam", -1, 1),
        Among("issem", -1, 1),
        Among("ìssem", -1, 1),
        Among("íssem", -1, 1),
        Among("íssim", -1, 1),
        Among("quíssim", 73, 5),
        Among("amen", -1, 1),
        Among("ìssin", -1, 1),
        Among("ar", -1, 1),
        Among("ificar", 77, 1),
        Among("egar", 77, 1),
        Among("ejar", 77, 1),
        Among("itar", 77, 1),
        Among("itzar", 77, 1),
        Among("fer", -1, 1),
        Among("or", -1, 1),
        Among("dor", 84, 1),
        Among("dur", -1, 1),
        Among("doras", -1, 1),
        Among("ics", -1, 4),
        Among("lógics", 88, 3),
        Among("uds", -1, 1),
        Among("nces", -1, 1),
        Among("ades", -1, 2),
        Among("ancies", -1, 1),
        Among("encies", -1, 1),
        Among("ències", -1, 1),
        Among("ícies", -1, 1),
        Among("logies", -1, 3),
        Among("inies", -1, 1),
        Among("ínies", -1, 1),
        Among("eries", -1, 1),
        Among("àries", -1, 1),
        Among("atòries", -1, 1),
        Among("bles", -1, 1),
        Among("ables", 103, 1),
        Among("ibles", 103, 1),
        Among("imes", -1, 1),
        Among("íssimes", 106, 1),
        Among("quíssimes", 107, 5),
        Among("formes", -1, 1),
        Among("ismes", -1, 1),
        Among("ialismes", 110, 1),
        Among("ines", -1, 1),
        Among("eres", -1, 1),
        Among("ores", -1, 1),
        Among("dores", 114, 1),
        Among("idores", 115, 1),
        Among("dures", -1, 1),
        Among("eses", -1, 1),
        Among("oses", -1, 1),
        Among("asses", -1, 1),
        Among("ictes", -1, 1),
        Among("ites", -1, 1),
        Among("otes", -1, 1),
        Among("istes", -1, 1),
        Among("ialistes", 124, 1),
        Among("ionistes", 124, 1),
        Among("iques", -1, 4),
        Among("lógiques", 127, 3),
        Among("ives", -1, 1),
        Among("atives", 129, 1),
        Among("logíes", -1, 3),
        Among("allengües", -1, 1),
        Among("icis", -1, 1),
        Among("ícis", -1, 1),
        Among("logis", -1, 3),
        Among("aris", -1, 1),
        Among("toris", -1, 1),
        Among("ls", -1, 1),
        Among("als", 138, 1),
        Among("ells", 138, 1),
        Among("ims", -1, 1),
        Among("íssims", 141, 1),
        Among("quíssims", 142, 5),
        Among("ions", -1, 1),
        Among("cions", 144, 1),
        Among("acions", 145, 2),
        Among("esos", -1, 1),
        Among("osos", -1, 1),
        Among("assos", -1, 1),
        Among("issos", -1, 1),
        Among("ers", -1, 1),
        Among("ors", -1, 1),
        Among("dors", 152, 1),
        Among("adors", 153, 1),
        Among("idors", 153, 1),
        Among("ats", -1, 1),
        Among("itats", 156, 1),
        Among("bilitats", 157, 1),
        Among("ivitats", 157, 1),
        Among("ativitats", 159, 1),
        Among("ïtats", 156, 1),
        Among("ets", -1, 1),
        Among("ants", -1, 1),
        Among("ents", -1, 1),
        Among("ments", 164, 1),
        Among("aments", 165, 1),
        Among("ots", -1, 1),
        Among("uts", -1, 1),
        Among("ius", -1, 1),
        Among("trius", 169, 1),
        Among("atius", 169, 1),
        Among("ès", -1, 1),
        Among("és", -1, 1),
        Among("ís", -1, 1),
        Among("dís", 174, 1),
        Among("ós", -1, 1),
        Among("itat", -1, 1),
        Among("bilitat", 177, 1),
        Among("ivitat", 177, 1),
        Among("ativitat", 179, 1),
        Among("ïtat", -1, 1),
        Among("et", -1, 1),
        Among("ant", -1, 1),
        Among("ent", -1, 1),
        Among("ient", 184, 1),
        Among("ment", 184, 1),
        Among("ament", 186, 1),
        Among("isament", 187, 1),
        Among("ot", -1, 1),
        Among("isseu", -1, 1),
        Among("ìsseu", -1, 1),
        Among("ísseu", -1, 1),
        Among("triu", -1, 1),
        Among("íssiu", -1, 1),
        Among("atiu", -1, 1),
        Among("ó", -1, 1),
        Among("ió", 196, 1),
        Among("ció", 197, 1),
        Among("ació", 198, 1)
    ]

    a_3 = [
        Among("aba", -1, 1),
        Among("esca", -1, 1),
        Among("isca", -1, 1),
        Among("ïsca", -1, 1),
        Among("ada", -1, 1),
        Among("ida", -1, 1),
        Among("uda", -1, 1),
        Among("ïda", -1, 1),
        Among("ia", -1, 1),
        Among("aria", 8, 1),
        Among("iria", 8, 1),
        Among("ara", -1, 1),
        Among("iera", -1, 1),
        Among("ira", -1, 1),
        Among("adora", -1, 1),
        Among("ïra", -1, 1),
        Among("ava", -1, 1),
        Among("ixa", -1, 1),
        Among("itza", -1, 1),
        Among("ía", -1, 1),
        Among("aría", 19, 1),
        Among("ería", 19, 1),
        Among("iría", 19, 1),
        Among("ïa", -1, 1),
        Among("isc", -1, 1),
        Among("ïsc", -1, 1),
        Among("ad", -1, 1),
        Among("ed", -1, 1),
        Among("id", -1, 1),
        Among("ie", -1, 1),
        Among("re", -1, 1),
        Among("dre", 30, 1),
        Among("ase", -1, 1),
        Among("iese", -1, 1),
        Among("aste", -1, 1),
        Among("iste", -1, 1),
        Among("ii", -1, 1),
        Among("ini", -1, 1),
        Among("esqui", -1, 1),
        Among("eixi", -1, 1),
        Among("itzi", -1, 1),
        Among("am", -1, 1),
        Among("em", -1, 1),
        Among("arem", 42, 1),
        Among("irem", 42, 1),
        Among("àrem", 42, 1),
        Among("írem", 42, 1),
        Among("àssem", 42, 1),
        Among("éssem", 42, 1),
        Among("iguem", 42, 1),
        Among("ïguem", 42, 1),
        Among("avem", 42, 1),
        Among("àvem", 42, 1),
        Among("ávem", 42, 1),
        Among("irìem", 42, 1),
        Among("íem", 42, 1),
        Among("aríem", 55, 1),
        Among("iríem", 55, 1),
        Among("assim", -1, 1),
        Among("essim", -1, 1),
        Among("issim", -1, 1),
        Among("àssim", -1, 1),
        Among("èssim", -1, 1),
        Among("éssim", -1, 1),
        Among("íssim", -1, 1),
        Among("ïm", -1, 1),
        Among("an", -1, 1),
        Among("aban", 66, 1),
        Among("arian", 66, 1),
        Among("aran", 66, 1),
        Among("ieran", 66, 1),
        Among("iran", 66, 1),
        Among("ían", 66, 1),
        Among("arían", 72, 1),
        Among("erían", 72, 1),
        Among("irían", 72, 1),
        Among("en", -1, 1),
        Among("ien", 76, 1),
        Among("arien", 77, 1),
        Among("irien", 77, 1),
        Among("aren", 76, 1),
        Among("eren", 76, 1),
        Among("iren", 76, 1),
        Among("àren", 76, 1),
        Among("ïren", 76, 1),
        Among("asen", 76, 1),
        Among("iesen", 76, 1),
        Among("assen", 76, 1),
        Among("essen", 76, 1),
        Among("issen", 76, 1),
        Among("éssen", 76, 1),
        Among("ïssen", 76, 1),
        Among("esquen", 76, 1),
        Among("isquen", 76, 1),
        Among("ïsquen", 76, 1),
        Among("aven", 76, 1),
        Among("ixen", 76, 1),
        Among("eixen", 96, 1),
        Among("ïxen", 76, 1),
        Among("ïen", 76, 1),
        Among("in", -1, 1),
        Among("inin", 100, 1),
        Among("sin", 100, 1),
        Among("isin", 102, 1),
        Among("assin", 102, 1),
        Among("essin", 102, 1),
        Among("issin", 102, 1),
        Among("ïssin", 102, 1),
        Among("esquin", 100, 1),
        Among("eixin", 100, 1),
        Among("aron", -1, 1),
        Among("ieron", -1, 1),
        Among("arán", -1, 1),
        Among("erán", -1, 1),
        Among("irán", -1, 1),
        Among("iïn", -1, 1),
        Among("ado", -1, 1),
        Among("ido", -1, 1),
        Among("ando", -1, 2),
        Among("iendo", -1, 1),
        Among("io", -1, 1),
        Among("ixo", -1, 1),
        Among("eixo", 121, 1),
        Among("ïxo", -1, 1),
        Among("itzo", -1, 1),
        Among("ar", -1, 1),
        Among("tzar", 125, 1),
        Among("er", -1, 1),
        Among("eixer", 127, 1),
        Among("ir", -1, 1),
        Among("ador", -1, 1),
        Among("as", -1, 1),
        Among("abas", 131, 1),
        Among("adas", 131, 1),
        Among("idas", 131, 1),
        Among("aras", 131, 1),
        Among("ieras", 131, 1),
        Among("ías", 131, 1),
        Among("arías", 137, 1),
        Among("erías", 137, 1),
        Among("irías", 137, 1),
        Among("ids", -1, 1),
        Among("es", -1, 1),
        Among("ades", 142, 1),
        Among("ides", 142, 1),
        Among("udes", 142, 1),
        Among("ïdes", 142, 1),
        Among("atges", 142, 1),
        Among("ies", 142, 1),
        Among("aries", 148, 1),
        Among("iries", 148, 1),
        Among("ares", 142, 1),
        Among("ires", 142, 1),
        Among("adores", 142, 1),
        Among("ïres", 142, 1),
        Among("ases", 142, 1),
        Among("ieses", 142, 1),
        Among("asses", 142, 1),
        Among("esses", 142, 1),
        Among("isses", 142, 1),
        Among("ïsses", 142, 1),
        Among("ques", 142, 1),
        Among("esques", 161, 1),
        Among("ïsques", 161, 1),
        Among("aves", 142, 1),
        Among("ixes", 142, 1),
        Among("eixes", 165, 1),
        Among("ïxes", 142, 1),
        Among("ïes", 142, 1),
        Among("abais", -1, 1),
        Among("arais", -1, 1),
        Among("ierais", -1, 1),
        Among("íais", -1, 1),
        Among("aríais", 172, 1),
        Among("eríais", 172, 1),
        Among("iríais", 172, 1),
        Among("aseis", -1, 1),
        Among("ieseis", -1, 1),
        Among("asteis", -1, 1),
        Among("isteis", -1, 1),
        Among("inis", -1, 1),
        Among("sis", -1, 1),
        Among("isis", 181, 1),
        Among("assis", 181, 1),
        Among("essis", 181, 1),
        Among("issis", 181, 1),
        Among("ïssis", 181, 1),
        Among("esquis", -1, 1),
        Among("eixis", -1, 1),
        Among("itzis", -1, 1),
        Among("áis", -1, 1),
        Among("aréis", -1, 1),
        Among("eréis", -1, 1),
        Among("iréis", -1, 1),
        Among("ams", -1, 1),
        Among("ados", -1, 1),
        Among("idos", -1, 1),
        Among("amos", -1, 1),
        Among("ábamos", 197, 1),
        Among("áramos", 197, 1),
        Among("iéramos", 197, 1),
        Among("íamos", 197, 1),
        Among("aríamos", 201, 1),
        Among("eríamos", 201, 1),
        Among("iríamos", 201, 1),
        Among("aremos", -1, 1),
        Among("eremos", -1, 1),
        Among("iremos", -1, 1),
        Among("ásemos", -1, 1),
        Among("iésemos", -1, 1),
        Among("imos", -1, 1),
        Among("adors", -1, 1),
        Among("ass", -1, 1),
        Among("erass", 212, 1),
        Among("ess", -1, 1),
        Among("ats", -1, 1),
        Among("its", -1, 1),
        Among("ents", -1, 1),
        Among("às", -1, 1),
        Among("aràs", 218, 1),
        Among("iràs", 218, 1),
        Among("arás", -1, 1),
        Among("erás", -1, 1),
        Among("irás", -1, 1),
        Among("és", -1, 1),
        Among("arés", 224, 1),
        Among("ís", -1, 1),
        Among("iïs", -1, 1),
        Among("at", -1, 1),
        Among("it", -1, 1),
        Among("ant", -1, 1),
        Among("ent", -1, 1),
        Among("int", -1, 1),
        Among("ut", -1, 1),
        Among("ït", -1, 1),
        Among("au", -1, 1),
        Among("erau", 235, 1),
        Among("ieu", -1, 1),
        Among("ineu", -1, 1),
        Among("areu", -1, 1),
        Among("ireu", -1, 1),
        Among("àreu", -1, 1),
        Among("íreu", -1, 1),
        Among("asseu", -1, 1),
        Among("esseu", -1, 1),
        Among("eresseu", 244, 1),
        Among("àsseu", -1, 1),
        Among("ésseu", -1, 1),
        Among("igueu", -1, 1),
        Among("ïgueu", -1, 1),
        Among("àveu", -1, 1),
        Among("áveu", -1, 1),
        Among("itzeu", -1, 1),
        Among("ìeu", -1, 1),
        Among("irìeu", 253, 1),
        Among("íeu", -1, 1),
        Among("aríeu", 255, 1),
        Among("iríeu", 255, 1),
        Among("assiu", -1, 1),
        Among("issiu", -1, 1),
        Among("àssiu", -1, 1),
        Among("èssiu", -1, 1),
        Among("éssiu", -1, 1),
        Among("íssiu", -1, 1),
        Among("ïu", -1, 1),
        Among("ix", -1, 1),
        Among("eix", 265, 1),
        Among("ïx", -1, 1),
        Among("itz", -1, 1),
        Among("ià", -1, 1),
        Among("arà", -1, 1),
        Among("irà", -1, 1),
        Among("itzà", -1, 1),
        Among("ará", -1, 1),
        Among("erá", -1, 1),
        Among("irá", -1, 1),
        Among("irè", -1, 1),
        Among("aré", -1, 1),
        Among("eré", -1, 1),
        Among("iré", -1, 1),
        Among("í", -1, 1),
        Among("iï", -1, 1),
        Among("ió", -1, 1)
    ]

    a_4 = [
        Among("a", -1, 1),
        Among("e", -1, 1),
        Among("i", -1, 1),
        Among("ïn", -1, 1),
        Among("o", -1, 1),
        Among("ir", -1, 1),
        Among("s", -1, 1),
        Among("is", 6, 1),
        Among("os", 6, 1),
        Among("ïs", 6, 1),
        Among("it", -1, 1),
        Among("eu", -1, 1),
        Among("iu", -1, 1),
        Among("iqu", -1, 2),
        Among("itz", -1, 1),
        Among("à", -1, 1),
        Among("á", -1, 1),
        Among("é", -1, 1),
        Among("ì", -1, 1),
        Among("í", -1, 1),
        Among("ï", -1, 1),
        Among("ó", -1, 1)
    ]


class lab0(BaseException): pass


class lab1(BaseException): pass
