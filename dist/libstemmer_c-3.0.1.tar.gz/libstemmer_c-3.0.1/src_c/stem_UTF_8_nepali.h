/* Generated from nepali.sbl by Snowball 3.0.1 - https://snowballstem.org/ */

#ifdef __cplusplus
extern "C" {
#endif

extern struct SN_env * nepali_UTF_8_create_env(void);
extern void nepali_UTF_8_close_env(struct SN_env * z);

extern int nepali_UTF_8_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif

