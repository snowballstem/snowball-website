// Generated from sesotho.sbl by Snowball 3.1.1 - https://snowballstem.org/

#pragma warning disable 0164
#pragma warning disable 0162

namespace Snowball
{
    using System;
    using System.Text;

    ///<summary>
    ///  This class implements the stemming algorithm defined by a snowball script.
    ///  Generated from sesotho.sbl by Snowball 3.1.1 - https://snowballstem.org/
    ///</summary>
    ///
    [System.CodeDom.Compiler.GeneratedCode("Snowball", "3.1.1")]
    public partial class SesothoStemmer : Stemmer
    {
        private int I_pV;

        private const string g_v = "aeiou";

        private static readonly Among[] a_0 = new[]
        {
            new Among("ba", -1, -1, 0),
            new Among("boi", -1, -1, 0),
            new Among("le", -1, -1, 0),
            new Among("li", -1, -1, 0),
            new Among("ma", -1, -1, 0),
            new Among("me", -1, -1, 0),
            new Among("mo", -1, -1, 0),
            new Among("se", -1, -1, 0)
        };

        private static readonly Among[] a_1 = new[]
        {
            new Among("a", -1, 1, 0),
            new Among("ela", 0, 1, 0),
            new Among("isa", 0, 1, 0),
            new Among("wa", 0, 1, 0),
            new Among("ile", -1, 1, 0),
            new Among("etse", -1, 1, 0),
            new Among("ang", -1, 1, 0),
            new Among("eng", -1, 1, 0),
            new Among("ong", -1, 1, 0)
        };

        private static readonly Among[] a_2 = new[]
        {
            new Among("ana", -1, 1, 0),
            new Among("nyana", 0, 1, 0),
            new Among("oa", -1, 1, 0),
            new Among("i", -1, 1, 0),
            new Among("ano", -1, 1, 0)
        };


        private bool r_mark_regions()
        {
            {
                int c1 = cursor;
                {

                    int ret = out_grouping(g_v, 97, 117, true);
                    if (ret < 0)
                    {
                        return false;
                    }

                    cursor += ret;
                }
                I_pV = cursor;
                cursor = c1;
            }
            {
                int c2 = cursor;
                {
                    int c = cursor + 2;
                    if (c > limit)
                    {
                        return false;
                    }
                    cursor = c;
                }
                if (cursor <= I_pV)
                {
                    goto lab0;
                }
                I_pV = cursor;
            lab0: ;
                cursor = c2;
            }
            return true;
        }

        private bool r_remove_noun_prefixes()
        {
            bra = cursor;
            if (find_among(a_0, null) == 0)
            {
                return false;
            }
            ket = cursor;
            {
                int c1 = cursor;
                if (cursor >= limit)
                {
                    return false;
                }
                cursor++;
                if (cursor >= limit)
                {
                    return false;
                }
                cursor = c1;
            }
            {

                int ret = out_grouping(g_v, 97, 117, true);
                if (ret < 0)
                {
                    return false;
                }

                cursor += ret;
            }
            slice_del();
            return true;
        }

        private bool r_remove_verb_suffixes()
        {
            if (cursor < I_pV)
            {
                return false;
            }
            int c1 = limit_backward;
            limit_backward = I_pV;
            ket = cursor;
            if (find_among_b(a_1, null) == 0)
            {
                {
                    limit_backward = c1;
                    return false;
                }
            }
            bra = cursor;
            slice_del();
            limit_backward = c1;
            return true;
        }

        private bool r_remove_nominal_suffixes()
        {
            if (cursor < I_pV)
            {
                return false;
            }
            int c1 = limit_backward;
            limit_backward = I_pV;
            ket = cursor;
            if (find_among_b(a_2, null) == 0)
            {
                {
                    limit_backward = c1;
                    return false;
                }
            }
            bra = cursor;
            slice_del();
            limit_backward = c1;
            return true;
        }

        protected override bool stem()
        {
            if (!r_mark_regions())
                return false;
            limit_backward = cursor;
            cursor = limit;
            {
                int c1 = limit - cursor;
                r_remove_nominal_suffixes();
                cursor = limit - c1;
            }
            {
                int c2 = limit - cursor;
                r_remove_verb_suffixes();
                cursor = limit - c2;
            }
            cursor = limit_backward;
            {
                int c3 = cursor;
                r_remove_noun_prefixes();
                cursor = c3;
            }
            return true;
        }

    }
}

