// Generated from persian.sbl by Snowball 3.1.1 - https://snowballstem.org/

#pragma warning disable 0164
#pragma warning disable 0162

namespace Snowball
{
    using System;
    using System.Text;

    ///<summary>
    ///  This class implements the stemming algorithm defined by a snowball script.
    ///  Generated from persian.sbl by Snowball 3.1.1 - https://snowballstem.org/
    ///</summary>
    ///
    [System.CodeDom.Compiler.GeneratedCode("Snowball", "3.1.1")]
    public partial class PersianStemmer : Stemmer
    {
        private int I_p1;
        private bool B_remove_verb_person_endings;
        private bool B_saw_present_prefix;


        private static readonly Among[] a_0 = new[]
        {
            new Among("", -1, 7, 0),
            new Among(" ", 0, 6, 0),
            new Among("\u0623", 0, 4, 0),
            new Among("\u0624", 0, 5, 0),
            new Among("\u0625", 0, 4, 0),
            new Among("\u0626", 0, 2, 0),
            new Among("\u0629", 0, 3, 0),
            new Among("\u0643", 0, 1, 0),
            new Among("\u064A", 0, 2, 0),
            new Among("\u06C1", 0, 3, 0),
            new Among("\u200D", 0, 6, 0)
        };

        private static readonly Among[] a_1 = new[]
        {
            new Among("\u0645\u06CC\u200C", -1, 2, 0),
            new Among("\u0646\u0645\u06CC\u200C", -1, 1, 0)
        };

        private static readonly Among[] a_2 = new[]
        {
            new Among("\u0633\u062A\u0627\u0646", -1, -1, 0),
            new Among("\u0631\u0627\u0646", -1, -1, 0),
            new Among("\u0633\u0627\u0646", -1, -1, 0),
            new Among("\u0648\u0627\u0646", -1, -1, 0)
        };

        private static readonly Among[] a_3 = new[]
        {
            new Among("\u0622\u0630\u0631\u0628\u0627\u06CC\u062C\u0627\u0646", -1, 1, 0),
            new Among("\u0647\u0645\u062F\u0627\u0646", -1, 1, 0),
            new Among("\u062E\u0627\u0646\u062F\u0627\u0646", -1, 1, 0),
            new Among("\u0632\u0646\u062F\u0627\u0646", -1, 1, 0),
            new Among("\u0645\u06CC\u0632\u0627\u0646", -1, 1, 0),
            new Among("\u062F\u0631\u062E\u0634\u0627\u0646", -1, 1, 0),
            new Among("\u0622\u062A\u0634\u0641\u0634\u0627\u0646", -1, 1, 0),
            new Among("\u0646\u0634\u0627\u0646", -1, 1, 0),
            new Among("\u06A9\u0647\u06A9\u0634\u0627\u0646", -1, 1, 0),
            new Among("\u0627\u06CC\u0634\u0627\u0646", -1, 1, 0),
            new Among("\u067E\u0631\u06CC\u0634\u0627\u0646", -1, 1, 0),
            new Among("\u0633\u0644\u0637\u0627\u0646", -1, 1, 0),
            new Among("\u06AF\u06CC\u0644\u0627\u0646", -1, 1, 0),
            new Among("\u0633\u0627\u062E\u062A\u0645\u0627\u0646", -1, 1, 0),
            new Among("\u0631\u0645\u0627\u0646", -1, 1, 0),
            new Among("\u062F\u0631\u0645\u0627\u0646", 14, 1, 0),
            new Among("\u0642\u0647\u0631\u0645\u0627\u0646", 14, 1, 0),
            new Among("\u06A9\u0631\u0645\u0627\u0646", 14, 1, 0),
            new Among("\u0633\u0627\u0632\u0645\u0627\u0646", -1, 1, 0),
            new Among("\u0647\u0645\u0632\u0645\u0627\u0646", -1, 1, 0),
            new Among("\u0622\u0633\u0645\u0627\u0646", -1, 1, 0),
            new Among("\u0622\u0644\u0645\u0627\u0646", -1, 1, 0),
            new Among("\u0645\u0633\u0644\u0645\u0627\u0646", -1, 1, 0),
            new Among("\u0627\u06CC\u0645\u0627\u0646", -1, 1, 0),
            new Among("\u0633\u0644\u06CC\u0645\u0627\u0646", -1, 1, 0),
            new Among("\u067E\u06CC\u0645\u0627\u0646", -1, 1, 0),
            new Among("\u0644\u0628\u0646\u0627\u0646", -1, 1, 0),
            new Among("\u06CC\u0648\u0646\u0627\u0646", -1, 1, 0),
            new Among("\u0627\u0635\u0641\u0647\u0627\u0646", -1, 1, 0),
            new Among("\u0627\u0645\u06A9\u0627\u0646", -1, 1, 0),
            new Among("\u067E\u0627\u06CC\u0627\u0646", -1, 1, 0),
            new Among("\u0628\u06CC\u0627\u0646", -1, 1, 0),
            new Among("\u062C\u0631\u06CC\u0627\u0646", -1, 1, 0)
        };

        private static readonly Among[] a_4 = new[]
        {
            new Among("\u0627\u0633\u0627\u062A\u06CC\u062F", -1, 2, 0),
            new Among("\u0627\u062E\u0628\u0627\u0631", -1, 1, 0)
        };

        private static readonly Among[] a_5 = new[]
        {
            new Among("\u0647\u0627", -1, 1, 0),
            new Among("\u0627\u062A", -1, 1, 0),
            new Among("\u06CC\u062A", -1, 1, 0),
            new Among("\u0645\u0646\u062F", -1, 1, 0),
            new Among("\u0648\u0627\u0631", -1, 1, 0),
            new Among("\u06AF\u0627\u0631", -1, 1, 0),
            new Among("\u062A\u0631", -1, 2, 0),
            new Among("\u0627\u0634", -1, 1, 0),
            new Among("\u0627\u0645", -1, 1, 0),
            new Among("\u0627\u0646", -1, 1, 0),
            new Among("\u0628\u0627\u0646", 9, 1, 0),
            new Among("\u06AF\u0627\u0646", 9, 1, 0),
            new Among("\u06CC\u0627\u0646", 9, 1, 0),
            new Among("\u06CC\u0646", -1, 1, 0),
            new Among("\u062A\u0631\u06CC\u0646", 13, 1, 0),
            new Among("\u06AF\u0627\u0647", -1, 1, 0),
            new Among("\u0627\u0646\u0647", -1, 1, 0),
            new Among("\u0646\u0627\u06A9", -1, 1, 0),
            new Among("\u0647\u0627\u06CC", -1, 1, 0),
            new Among("\u0627\u0646\u06CC", -1, 1, 0),
            new Among("\u06AF\u06CC", -1, 1, 0),
            new Among("\u06CC\u06CC", -1, 1, 0)
        };

        private static readonly Among[] a_6 = new[]
        {
            new Among("\u0627\u0633\u062A", -1, 1, 0),
            new Among("\u0627\u0646\u062F", -1, 1, 0),
            new Among("\u06CC\u062F", -1, 1, 0),
            new Among("\u0627\u06CC\u062F", 2, 1, 0),
            new Among("\u0627\u0633", -1, 1, 0),
            new Among("\u06CC\u0645", -1, 1, 0),
            new Among("\u0627\u06CC\u0645", 5, 1, 0),
            new Among("\u0627\u06CC", -1, 1, 0)
        };

        private static readonly Among[] a_7 = new[]
        {
            new Among("\u062F", -1, 1, 0),
            new Among("\u0627\u0646\u062F", 0, 1, 0),
            new Among("\u0631\u0641\u062A\u0627\u0646\u062F", 1, 2, 0),
            new Among("\u06CC\u062F", 0, 1, 0),
            new Among("\u0631\u0641\u062A\u06CC\u062F", 3, 2, 0),
            new Among("\u0645", -1, 1, 0),
            new Among("\u0627\u0645", 5, 1, 0),
            new Among("\u0631\u0641\u062A\u0645", 5, 2, 0),
            new Among("\u06CC\u0645", 5, 1, 0),
            new Among("\u0631\u0641\u062A\u06CC\u0645", 8, 2, 0),
            new Among("\u0627\u0646", -1, 3, 0),
            new Among("\u062A\u0647", -1, 5, 0),
            new Among("\u062F\u0647", -1, 4, 0),
            new Among("\u0646\u062F\u0647", 12, 3, 0),
            new Among("\u0631\u0641\u062A\u06CC", -1, 2, 0)
        };


        private bool r_Normalize_Characters()
        {
            int among_var;
            while (true)
            {
                int c1 = cursor;
                bra = cursor;
                among_var = find_among(a_0, null);
                ket = cursor;
                switch (among_var) {
                    case 1: {
                        slice_from("\u06A9");
                        break;
                    }
                    case 2: {
                        slice_from("\u06CC");
                        break;
                    }
                    case 3: {
                        slice_from("\u0647");
                        break;
                    }
                    case 4: {
                        slice_from("\u0627");
                        break;
                    }
                    case 5: {
                        slice_from("\u0648");
                        break;
                    }
                    case 6: {
                        slice_del();
                        break;
                    }
                    case 7: {
                        if (cursor >= limit)
                        {
                            goto lab0;
                        }
                        cursor++;
                        break;
                    }
                }
                continue;
            lab0: ;
                cursor = c1;
                break;
            }
            return true;
        }

        private bool r_Prefixes()
        {
            int among_var;
            bra = cursor;
            among_var = find_among(a_1, null);
            if (among_var == 0)
            {
                return false;
            }
            ket = cursor;
            switch (among_var) {
                case 1: {
                    {
                        int c = cursor + 2;
                        if (c > limit)
                        {
                            return false;
                        }
                        cursor = c;
                    }
                    B_saw_present_prefix = true;
                    break;
                }
                case 2: {
                    {
                        int c = cursor + 2;
                        if (c > limit)
                        {
                            return false;
                        }
                        cursor = c;
                    }
                    slice_del();
                    B_saw_present_prefix = true;
                    break;
                }
            }
            return true;
        }

        private bool r_Delete_ZWNJ()
        {
            while (true)
            {
                int c1 = cursor;
                while (true)
                {
                    int c2 = cursor;
                    bra = cursor;
                    if (!(eq_s("\u200C")))
                    {
                        goto lab1;
                    }
                    ket = cursor;
                    slice_del();
                    cursor = c2;
                    break;
                lab1: ;
                    cursor = c2;
                    if (cursor >= limit)
                    {
                        goto lab0;
                    }
                    cursor++;
                }
                continue;
            lab0: ;
                cursor = c1;
                break;
            }
            return true;
        }

        private bool r_R1()
        {
            return I_p1 <= cursor;
        }

        private bool r_Protect_Lexical_AN()
        {
            {
                int c1 = limit - cursor;
                if (!r_AN_Exception())
                    goto lab0;
                return false;
            lab0: ;
                cursor = limit - c1;
            }
            {
                int c2 = limit - cursor;
                if (find_among_b(a_2, null) == 0)
                {
                    goto lab1;
                }
                return false;
            lab1: ;
                cursor = limit - c2;
            }
            return true;
        }

        private bool r_AN_Exception()
        {
            if (find_among_b(a_3, null) == 0)
            {
                return false;
            }
            if (cursor > limit_backward)
            {
                return false;
            }
            return true;
        }

        private bool r_Irregular_Noun()
        {
            int among_var;
            ket = cursor;
            among_var = find_among_b(a_4, null);
            if (among_var == 0)
            {
                return false;
            }
            bra = cursor;
            switch (among_var) {
                case 1: {
                    slice_from("\u062E\u0628\u0631");
                    break;
                }
                case 2: {
                    slice_from("\u0627\u0633\u062A\u0627\u062F");
                    break;
                }
            }
            return true;
        }

        private bool r_Stem_Noun_or_Adjective()
        {
            int among_var;
            {
                int c1 = limit - cursor;
                if (!r_Irregular_Noun())
                    goto lab1;
                goto lab0;
            lab1: ;
                cursor = limit - c1;
                if (cursor < I_p1)
                {
                    return false;
                }
                int c2 = limit_backward;
                limit_backward = I_p1;
                ket = cursor;
                among_var = find_among_b(a_5, null);
                if (among_var == 0)
                {
                    {
                        limit_backward = c2;
                        return false;
                    }
                }
                bra = cursor;
                switch (among_var) {
                    case 1: {
                        slice_del();
                        break;
                    }
                    case 2: {
                        if (cursor <= limit_backward)
                        {
                            {
                                limit_backward = c2;
                                return false;
                            }
                        }
                        slice_del();
                        break;
                    }
                }
                limit_backward = c2;
            }
        lab0: ;
            return true;
        }

        private bool r_Stem_Verb()
        {
            int among_var;
            {
                int c1 = limit - cursor;
                ket = cursor;
                if (find_among_b(a_6, null) == 0)
                {
                    goto lab1;
                }
                bra = cursor;
                if (!r_R1())
                    goto lab1;
                slice_del();
                goto lab0;
            lab1: ;
                cursor = limit - c1;
                ket = cursor;
                among_var = find_among_b(a_7, null);
                if (among_var == 0)
                {
                    return false;
                }
                bra = cursor;
                switch (among_var) {
                    case 1: {
                        if (!B_remove_verb_person_endings)
                        {
                            return false;
                        }
                        if (!r_R1())
                            return false;
                        slice_del();
                        break;
                    }
                    case 2: {
                        slice_from("\u0631\u0641\u062A");
                        break;
                    }
                    case 3: {
                        if (!r_R1())
                            return false;
                        slice_del();
                        B_remove_verb_person_endings = true;
                        break;
                    }
                    case 4: {
                        if (cursor <= limit_backward)
                        {
                            return false;
                        }
                        slice_from("\u062F");
                        B_remove_verb_person_endings = true;
                        break;
                    }
                    case 5: {
                        if (cursor <= limit_backward)
                        {
                            return false;
                        }
                        slice_from("\u062A");
                        B_remove_verb_person_endings = true;
                        break;
                    }
                }
            }
        lab0: ;
            return true;
        }

        protected override bool stem()
        {
            B_saw_present_prefix = false;
            {
                int c1 = cursor;
                r_Normalize_Characters();
                cursor = c1;
            }
            {
                int c2 = cursor;
                r_Prefixes();
                cursor = c2;
            }
            {
                int c3 = cursor;
                r_Delete_ZWNJ();
                cursor = c3;
            }
            I_p1 = limit;
            {
                int c4 = cursor;
                {
                    int c = cursor + 3;
                    if (c > limit)
                    {
                        goto lab0;
                    }
                    cursor = c;
                }
                I_p1 = cursor;
            lab0: ;
                cursor = c4;
            }
            limit_backward = cursor;
            cursor = limit;
            while (true)
            {
                int c5 = limit - cursor;
                {
                    int c6 = limit - cursor;
                    B_remove_verb_person_endings = false;
                    if (!B_saw_present_prefix)
                    {
                        goto lab2;
                    }
                    B_remove_verb_person_endings = true;
                lab2: ;
                    if (!r_Protect_Lexical_AN())
                        goto lab1;
                    {
                        int c7 = limit - cursor;
                        if (!r_Stem_Noun_or_Adjective())
                            goto lab4;
                        goto lab3;
                    lab4: ;
                        cursor = limit - c7;
                        if (!r_Stem_Verb())
                            goto lab1;
                    }
                lab3: ;
                    cursor = limit - c6;
                }
                continue;
            lab1: ;
                cursor = limit - c5;
                break;
            }
            cursor = limit_backward;
            return true;
        }

    }
}

