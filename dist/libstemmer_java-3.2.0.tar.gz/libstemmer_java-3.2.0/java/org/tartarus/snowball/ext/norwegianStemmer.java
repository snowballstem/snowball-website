// Generated from norwegian.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from norwegian.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class norwegianStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("", -1, 1),
        new Among("ind", 0, -1),
        new Among("kk", 0, -1),
        new Among("nk", 0, -1),
        new Among("amm", 0, -1),
        new Among("omm", 0, -1),
        new Among("kap", 0, -1),
        new Among("skap", 6, 1),
        new Among("pp", 0, -1),
        new Among("lt", 0, -1),
        new Among("ast", 0, -1),
        new Among("\u00F8st", 0, -1),
        new Among("v", 0, -1),
        new Among("hav", 12, 1),
        new Among("giv", 12, 1)
    };

    private final static Among[] a_1 = {
        new Among("a", -1, 1),
        new Among("e", -1, 1),
        new Among("ede", 1, 1),
        new Among("ande", 1, 1),
        new Among("ende", 1, 1),
        new Among("ane", 1, 1),
        new Among("ene", 1, 1),
        new Among("hetene", 6, 1),
        new Among("erte", 1, 4),
        new Among("en", -1, 1),
        new Among("heten", 9, 1),
        new Among("ar", -1, 1),
        new Among("er", -1, 1),
        new Among("heter", 12, 1),
        new Among("s", -1, 3),
        new Among("as", 14, 1),
        new Among("es", 14, 1),
        new Among("edes", 16, 1),
        new Among("endes", 16, 1),
        new Among("enes", 16, 1),
        new Among("hetenes", 19, 1),
        new Among("ens", 14, 1),
        new Among("hetens", 21, 1),
        new Among("ers", 14, 2),
        new Among("ets", 14, 1),
        new Among("et", -1, 1),
        new Among("het", 25, 1),
        new Among("ert", -1, 4),
        new Among("ast", -1, 1)
    };

    private final static Among[] a_2 = {
        new Among("dt", -1, -1),
        new Among("vt", -1, -1)
    };

    private final static Among[] a_3 = {
        new Among("leg", -1, 1),
        new Among("eleg", 0, 1),
        new Among("ig", -1, 1),
        new Among("eig", 2, 1),
        new Among("lig", 2, 1),
        new Among("elig", 4, 1),
        new Among("els", -1, 1),
        new Among("lov", -1, 1),
        new Among("elov", 7, 1),
        new Among("slov", 7, 1),
        new Among("hetslov", 9, 1)
    };

    private static final char[] g_v = {17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 2, 142 };

    private static final char[] g_s_ending = {119, 125, 148, 1 };


    @Override
    public boolean stem() {
        int among_var;
        int I_p1;
        I_p1 = limit;
        int v_1 = cursor;
        lab0: {
            lab1: {
                int v_2 = cursor;
                lab2: {
                    golab3: while (true)
                    {
                        lab4: {
                            if (!(eq_s("'")))
                            {
                                break lab4;
                            }
                            break golab3;
                        }
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    break lab1;
                }
                cursor = v_2;
                if (!go_out_grouping(g_v, 97, 248))
                {
                    break lab0;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 248))
                {
                    break lab0;
                }
                cursor++;
            }
            I_p1 = cursor;
        }
        cursor = v_1;
        int v_3 = cursor;
        {
            int c = cursor + 3;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        lab5: {
            if (I_p1 >= cursor)
            {
                break lab5;
            }
            I_p1 = cursor;
        }
        cursor = v_3;
        limit_backward = cursor;
        cursor = limit;
        int v_4 = limit - cursor;
        lab6: {
            if (cursor < I_p1)
            {
                break lab6;
            }
            int v_5 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            among_var = find_among_b(a_1);
            if (among_var == 0)
            {
                limit_backward = v_5;
                break lab6;
            }
            bra = cursor;
            limit_backward = v_5;
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    among_var = find_among_b(a_0);
                    switch (among_var) {
                        case 1:
                            slice_del();
                            break;
                    }
                    break;
                case 3:
                    lab7: {
                        int v_6 = limit - cursor;
                        lab8: {
                            if (!(in_grouping_b(g_s_ending, 98, 122)))
                            {
                                break lab8;
                            }
                            break lab7;
                        }
                        cursor = limit - v_6;
                        lab9: {
                            if (!(eq_s_b("r")))
                            {
                                break lab9;
                            }
                            lab10: {
                                if (!(eq_s_b("e")))
                                {
                                    break lab10;
                                }
                                break lab9;
                            }
                            break lab7;
                        }
                        cursor = limit - v_6;
                        if (!(eq_s_b("k")))
                        {
                            break lab6;
                        }
                        if (!(out_grouping_b(g_v, 97, 248)))
                        {
                            break lab6;
                        }
                    }
                    slice_del();
                    break;
                case 4:
                    slice_from("er");
                    break;
            }
        }
        cursor = limit - v_4;
        int v_7 = limit - cursor;
        lab11: {
            int v_8 = limit - cursor;
            if (cursor < I_p1)
            {
                break lab11;
            }
            int v_9 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            if (find_among_b(a_2) == 0)
            {
                limit_backward = v_9;
                break lab11;
            }
            bra = cursor;
            limit_backward = v_9;
            cursor = limit - v_8;
            if (cursor <= limit_backward)
            {
                break lab11;
            }
            cursor--;
            bra = cursor;
            slice_del();
        }
        cursor = limit - v_7;
        int v_10 = limit - cursor;
        lab12: {
            if (cursor < I_p1)
            {
                break lab12;
            }
            int v_11 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            if (find_among_b(a_3) == 0)
            {
                limit_backward = v_11;
                break lab12;
            }
            bra = cursor;
            limit_backward = v_11;
            slice_del();
        }
        cursor = limit - v_10;
        ket = cursor;
        if (!(eq_s_b("'")))
        {
            return false;
        }
        bra = cursor;
        slice_del();
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof norwegianStemmer;
    }

    @Override
    public int hashCode() {
        return norwegianStemmer.class.getName().hashCode();
    }

}
