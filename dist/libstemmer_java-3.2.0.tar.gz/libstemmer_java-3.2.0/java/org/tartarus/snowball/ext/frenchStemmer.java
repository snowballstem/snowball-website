// Generated from french.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from french.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class frenchStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("col", -1, -1),
        new Among("ni", -1, 1),
        new Among("par", -1, -1),
        new Among("tap", -1, -1)
    };

    private final static Among[] a_1 = {
        new Among("", -1, 7),
        new Among("H", 0, 6),
        new Among("He", 1, 4),
        new Among("Hi", 1, 5),
        new Among("I", 0, 1),
        new Among("U", 0, 2),
        new Among("Y", 0, 3)
    };

    private final static Among[] a_2 = {
        new Among("iqU", -1, 3),
        new Among("abl", -1, 3),
        new Among("I\u00E8r", -1, 4),
        new Among("i\u00E8r", -1, 4),
        new Among("eus", -1, 2),
        new Among("iv", -1, 1)
    };

    private final static Among[] a_3 = {
        new Among("ic", -1, 2),
        new Among("abil", -1, 1),
        new Among("iv", -1, 3)
    };

    private final static Among[] a_4 = {
        new Among("iqUe", -1, 1),
        new Among("atrice", -1, 2),
        new Among("ance", -1, 1),
        new Among("ence", -1, 5),
        new Among("logie", -1, 3),
        new Among("able", -1, 1),
        new Among("isme", -1, 1),
        new Among("euse", -1, 12),
        new Among("iste", -1, 1),
        new Among("ive", -1, 8),
        new Among("if", -1, 8),
        new Among("usion", -1, 4),
        new Among("ation", -1, 2),
        new Among("ution", -1, 4),
        new Among("ateur", -1, 2),
        new Among("iqUes", -1, 1),
        new Among("atrices", -1, 2),
        new Among("ances", -1, 1),
        new Among("ences", -1, 5),
        new Among("logies", -1, 3),
        new Among("ables", -1, 1),
        new Among("ismes", -1, 1),
        new Among("euses", -1, 12),
        new Among("istes", -1, 1),
        new Among("ives", -1, 8),
        new Among("ifs", -1, 8),
        new Among("usions", -1, 4),
        new Among("ations", -1, 2),
        new Among("utions", -1, 4),
        new Among("ateurs", -1, 2),
        new Among("ments", -1, 16),
        new Among("ements", 30, 6),
        new Among("issements", 31, 13),
        new Among("it\u00E9s", -1, 7),
        new Among("ment", -1, 16),
        new Among("ement", 34, 6),
        new Among("issement", 35, 13),
        new Among("amment", 34, 14),
        new Among("emment", 34, 15),
        new Among("aux", -1, 10),
        new Among("eaux", 39, 9),
        new Among("eux", -1, 1),
        new Among("oux", -1, 11),
        new Among("it\u00E9", -1, 7)
    };

    private final static Among[] a_5 = {
        new Among("ira", -1, 1),
        new Among("ie", -1, 1),
        new Among("isse", -1, 1),
        new Among("issante", -1, 1),
        new Among("i", -1, 1),
        new Among("irai", 4, 1),
        new Among("ir", -1, 1),
        new Among("iras", -1, 1),
        new Among("ies", -1, 1),
        new Among("\u00EEmes", -1, 1),
        new Among("isses", -1, 1),
        new Among("issantes", -1, 1),
        new Among("\u00EEtes", -1, 1),
        new Among("is", -1, 1),
        new Among("irais", 13, 1),
        new Among("issais", 13, 1),
        new Among("irions", -1, 1),
        new Among("issions", -1, 1),
        new Among("irons", -1, 1),
        new Among("issons", -1, 1),
        new Among("issants", -1, 1),
        new Among("it", -1, 1),
        new Among("irait", 21, 1),
        new Among("issait", 21, 1),
        new Among("issant", -1, 1),
        new Among("iraIent", -1, 1),
        new Among("issaIent", -1, 1),
        new Among("irent", -1, 1),
        new Among("issent", -1, 1),
        new Among("iront", -1, 1),
        new Among("\u00EEt", -1, 1),
        new Among("iriez", -1, 1),
        new Among("issiez", -1, 1),
        new Among("irez", -1, 1),
        new Among("issez", -1, 1)
    };

    private final static Among[] a_6 = {
        new Among("al", -1, 1),
        new Among("\u00E9pl", -1, -1),
        new Among("auv", -1, -1)
    };

    private final static Among[] a_7 = {
        new Among("a", -1, 3),
        new Among("era", 0, 2),
        new Among("aise", -1, 4),
        new Among("asse", -1, 3),
        new Among("ante", -1, 3),
        new Among("\u00E9e", -1, 2),
        new Among("ai", -1, 3),
        new Among("erai", 6, 2),
        new Among("er", -1, 2),
        new Among("as", -1, 3),
        new Among("eras", 9, 2),
        new Among("\u00E2mes", -1, 3),
        new Among("aises", -1, 4),
        new Among("asses", -1, 3),
        new Among("antes", -1, 3),
        new Among("\u00E2tes", -1, 3),
        new Among("\u00E9es", -1, 2),
        new Among("ais", -1, 4),
        new Among("eais", 17, 2),
        new Among("erais", 17, 2),
        new Among("ions", -1, 1),
        new Among("erions", 20, 2),
        new Among("assions", 20, 3),
        new Among("erons", -1, 2),
        new Among("ants", -1, 3),
        new Among("\u00E9s", -1, 2),
        new Among("ait", -1, 3),
        new Among("erait", 26, 2),
        new Among("ant", -1, 3),
        new Among("aIent", -1, 3),
        new Among("eraIent", 29, 2),
        new Among("\u00E8rent", -1, 2),
        new Among("assent", -1, 3),
        new Among("eront", -1, 2),
        new Among("\u00E2t", -1, 3),
        new Among("ez", -1, 2),
        new Among("iez", 35, 2),
        new Among("eriez", 36, 2),
        new Among("assiez", 36, 3),
        new Among("erez", 35, 2),
        new Among("\u00E9", -1, 2)
    };

    private final static Among[] a_8 = {
        new Among("e", -1, 3),
        new Among("I\u00E8re", 0, 2),
        new Among("i\u00E8re", 0, 2),
        new Among("ion", -1, 1),
        new Among("Ier", -1, 2),
        new Among("ier", -1, 2)
    };

    private final static Among[] a_9 = {
        new Among("ell", -1, -1),
        new Among("eill", -1, -1),
        new Among("enn", -1, -1),
        new Among("onn", -1, -1),
        new Among("ett", -1, -1)
    };

    private static final char[] g_v = {17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 130, 103, 8, 5 };

    private static final char[] g_oux_ending = {65, 85 };

    private static final char[] g_elision_char = {131, 14, 131 };

    private static final char[] g_keep_with_s = {1, 65, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };


    @Override
    public boolean stem() {
        int among_var;
        int I_p2;
        int I_p1;
        int I_pV;
        int v_1 = cursor;
        lab0: {
            bra = cursor;
            lab1: {
                lab2: {
                    if (!(in_grouping(g_elision_char, 99, 122)))
                    {
                        break lab2;
                    }
                    break lab1;
                }
                if (!(eq_s("qu")))
                {
                    break lab0;
                }
            }
            if (!(eq_s("'")))
            {
                break lab0;
            }
            ket = cursor;
            if (cursor >= limit)
            {
                break lab0;
            }
            slice_del();
        }
        cursor = v_1;
        int v_2 = cursor;
        lab3: {
            while (true)
            {
                int v_3 = cursor;
                lab4: {
                    golab5: while (true)
                    {
                        int v_4 = cursor;
                        lab6: {
                            lab7: {
                                int v_5 = cursor;
                                lab8: {
                                    if (!(in_grouping(g_v, 97, 251)))
                                    {
                                        break lab8;
                                    }
                                    bra = cursor;
                                    lab9: {
                                        int v_6 = cursor;
                                        lab10: {
                                            if (!(eq_s("u")))
                                            {
                                                break lab10;
                                            }
                                            ket = cursor;
                                            if (!(in_grouping(g_v, 97, 251)))
                                            {
                                                break lab10;
                                            }
                                            slice_from("U");
                                            break lab9;
                                        }
                                        cursor = v_6;
                                        lab11: {
                                            if (!(eq_s("i")))
                                            {
                                                break lab11;
                                            }
                                            ket = cursor;
                                            if (!(in_grouping(g_v, 97, 251)))
                                            {
                                                break lab11;
                                            }
                                            slice_from("I");
                                            break lab9;
                                        }
                                        cursor = v_6;
                                        if (!(eq_s("y")))
                                        {
                                            break lab8;
                                        }
                                        ket = cursor;
                                        slice_from("Y");
                                    }
                                    break lab7;
                                }
                                cursor = v_5;
                                lab12: {
                                    bra = cursor;
                                    if (!(eq_s("\u00EB")))
                                    {
                                        break lab12;
                                    }
                                    ket = cursor;
                                    slice_from("He");
                                    break lab7;
                                }
                                cursor = v_5;
                                lab13: {
                                    bra = cursor;
                                    if (!(eq_s("\u00EF")))
                                    {
                                        break lab13;
                                    }
                                    ket = cursor;
                                    slice_from("Hi");
                                    break lab7;
                                }
                                cursor = v_5;
                                lab14: {
                                    bra = cursor;
                                    if (!(eq_s("y")))
                                    {
                                        break lab14;
                                    }
                                    ket = cursor;
                                    if (!(in_grouping(g_v, 97, 251)))
                                    {
                                        break lab14;
                                    }
                                    slice_from("Y");
                                    break lab7;
                                }
                                cursor = v_5;
                                if (!(eq_s("q")))
                                {
                                    break lab6;
                                }
                                bra = cursor;
                                if (!(eq_s("u")))
                                {
                                    break lab6;
                                }
                                ket = cursor;
                                slice_from("U");
                            }
                            cursor = v_4;
                            break golab5;
                        }
                        cursor = v_4;
                        if (cursor >= limit)
                        {
                            break lab4;
                        }
                        cursor++;
                    }
                    continue;
                }
                cursor = v_3;
                break;
            }
        }
        cursor = v_2;
        lab15: {
            I_pV = limit;
            I_p1 = limit;
            I_p2 = limit;
            int v_7 = cursor;
            lab16: {
                lab17: {
                    int v_8 = cursor;
                    lab18: {
                        if (!(in_grouping(g_v, 97, 251)))
                        {
                            break lab18;
                        }
                        if (!(in_grouping(g_v, 97, 251)))
                        {
                            break lab18;
                        }
                        if (cursor >= limit)
                        {
                            break lab18;
                        }
                        cursor++;
                        break lab17;
                    }
                    cursor = v_8;
                    lab19: {
                        among_var = find_among(a_0);
                        if (among_var == 0)
                        {
                            break lab19;
                        }
                        switch (among_var) {
                            case 1:
                                if (!(in_grouping(g_v, 97, 251)))
                                {
                                    break lab19;
                                }
                                break;
                        }
                        break lab17;
                    }
                    cursor = v_8;
                    if (cursor >= limit)
                    {
                        break lab16;
                    }
                    cursor++;
                    if (!go_out_grouping(g_v, 97, 251))
                    {
                        break lab16;
                    }
                    cursor++;
                }
                I_pV = cursor;
            }
            cursor = v_7;
            int v_9 = cursor;
            lab20: {
                if (!go_out_grouping(g_v, 97, 251))
                {
                    break lab20;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 251))
                {
                    break lab20;
                }
                cursor++;
                I_p1 = cursor;
                if (!go_out_grouping(g_v, 97, 251))
                {
                    break lab20;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 251))
                {
                    break lab20;
                }
                cursor++;
                I_p2 = cursor;
            }
            cursor = v_9;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_10 = limit - cursor;
        lab21: {
            lab22: {
                int v_11 = limit - cursor;
                lab23: {
                    int v_12 = limit - cursor;
                    lab24: {
                        int v_13 = limit - cursor;
                        lab25: {
                            ket = cursor;
                            among_var = find_among_b(a_4);
                            if (among_var == 0)
                            {
                                break lab25;
                            }
                            bra = cursor;
                            switch (among_var) {
                                case 1:
                                    if (I_p2 > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_del();
                                    break;
                                case 2:
                                    if (I_p2 > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_del();
                                    int v_14 = limit - cursor;
                                    lab26: {
                                        ket = cursor;
                                        if (!(eq_s_b("ic")))
                                        {
                                            cursor = limit - v_14;
                                            break lab26;
                                        }
                                        bra = cursor;
                                        lab27: {
                                            int v_15 = limit - cursor;
                                            lab28: {
                                                if (I_p2 > cursor)
                                                {
                                                    break lab28;
                                                }
                                                slice_del();
                                                break lab27;
                                            }
                                            cursor = limit - v_15;
                                            slice_from("iqU");
                                        }
                                    }
                                    break;
                                case 3:
                                    if (I_p2 > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_from("log");
                                    break;
                                case 4:
                                    if (I_p2 > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_from("u");
                                    break;
                                case 5:
                                    if (I_p2 > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_from("ent");
                                    break;
                                case 6:
                                    if (I_pV > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_del();
                                    int v_16 = limit - cursor;
                                    lab29: {
                                        ket = cursor;
                                        among_var = find_among_b(a_2);
                                        if (among_var == 0)
                                        {
                                            cursor = limit - v_16;
                                            break lab29;
                                        }
                                        bra = cursor;
                                        switch (among_var) {
                                            case 1:
                                                if (I_p2 > cursor)
                                                {
                                                    cursor = limit - v_16;
                                                    break lab29;
                                                }
                                                slice_del();
                                                ket = cursor;
                                                if (!(eq_s_b("at")))
                                                {
                                                    cursor = limit - v_16;
                                                    break lab29;
                                                }
                                                bra = cursor;
                                                if (I_p2 > cursor)
                                                {
                                                    cursor = limit - v_16;
                                                    break lab29;
                                                }
                                                slice_del();
                                                break;
                                            case 2:
                                                lab30: {
                                                    int v_17 = limit - cursor;
                                                    lab31: {
                                                        if (I_p2 > cursor)
                                                        {
                                                            break lab31;
                                                        }
                                                        slice_del();
                                                        break lab30;
                                                    }
                                                    cursor = limit - v_17;
                                                    if (I_p1 > cursor)
                                                    {
                                                        cursor = limit - v_16;
                                                        break lab29;
                                                    }
                                                    slice_from("eux");
                                                }
                                                break;
                                            case 3:
                                                if (I_p2 > cursor)
                                                {
                                                    cursor = limit - v_16;
                                                    break lab29;
                                                }
                                                slice_del();
                                                break;
                                            case 4:
                                                if (I_pV > cursor)
                                                {
                                                    cursor = limit - v_16;
                                                    break lab29;
                                                }
                                                slice_from("i");
                                                break;
                                        }
                                    }
                                    break;
                                case 7:
                                    if (I_p2 > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_del();
                                    int v_18 = limit - cursor;
                                    lab32: {
                                        ket = cursor;
                                        among_var = find_among_b(a_3);
                                        if (among_var == 0)
                                        {
                                            cursor = limit - v_18;
                                            break lab32;
                                        }
                                        bra = cursor;
                                        switch (among_var) {
                                            case 1:
                                                lab33: {
                                                    int v_19 = limit - cursor;
                                                    lab34: {
                                                        if (I_p2 > cursor)
                                                        {
                                                            break lab34;
                                                        }
                                                        slice_del();
                                                        break lab33;
                                                    }
                                                    cursor = limit - v_19;
                                                    slice_from("abl");
                                                }
                                                break;
                                            case 2:
                                                lab35: {
                                                    int v_20 = limit - cursor;
                                                    lab36: {
                                                        if (I_p2 > cursor)
                                                        {
                                                            break lab36;
                                                        }
                                                        slice_del();
                                                        break lab35;
                                                    }
                                                    cursor = limit - v_20;
                                                    slice_from("iqU");
                                                }
                                                break;
                                            case 3:
                                                if (I_p2 > cursor)
                                                {
                                                    cursor = limit - v_18;
                                                    break lab32;
                                                }
                                                slice_del();
                                                break;
                                        }
                                    }
                                    break;
                                case 8:
                                    if (I_p2 > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_del();
                                    int v_21 = limit - cursor;
                                    lab37: {
                                        ket = cursor;
                                        if (!(eq_s_b("at")))
                                        {
                                            cursor = limit - v_21;
                                            break lab37;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_21;
                                            break lab37;
                                        }
                                        slice_del();
                                        ket = cursor;
                                        if (!(eq_s_b("ic")))
                                        {
                                            cursor = limit - v_21;
                                            break lab37;
                                        }
                                        bra = cursor;
                                        lab38: {
                                            int v_22 = limit - cursor;
                                            lab39: {
                                                if (I_p2 > cursor)
                                                {
                                                    break lab39;
                                                }
                                                slice_del();
                                                break lab38;
                                            }
                                            cursor = limit - v_22;
                                            slice_from("iqU");
                                        }
                                    }
                                    break;
                                case 9:
                                    slice_from("eau");
                                    break;
                                case 10:
                                    if (I_p1 > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_from("al");
                                    break;
                                case 11:
                                    if (!(in_grouping_b(g_oux_ending, 98, 112)))
                                    {
                                        break lab25;
                                    }
                                    slice_from("ou");
                                    break;
                                case 12:
                                    lab40: {
                                        int v_23 = limit - cursor;
                                        lab41: {
                                            if (I_p2 > cursor)
                                            {
                                                break lab41;
                                            }
                                            slice_del();
                                            break lab40;
                                        }
                                        cursor = limit - v_23;
                                        if (I_p1 > cursor)
                                        {
                                            break lab25;
                                        }
                                        slice_from("eux");
                                    }
                                    break;
                                case 13:
                                    if (I_p1 > cursor)
                                    {
                                        break lab25;
                                    }
                                    if (!(out_grouping_b(g_v, 97, 251)))
                                    {
                                        break lab25;
                                    }
                                    slice_del();
                                    break;
                                case 14:
                                    if (I_pV > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_from("ant");
                                    break lab25;
                                case 15:
                                    if (I_pV > cursor)
                                    {
                                        break lab25;
                                    }
                                    slice_from("ent");
                                    break lab25;
                                case 16:
                                    int v_24 = limit - cursor;
                                    if (!(in_grouping_b(g_v, 97, 251)))
                                    {
                                        break lab25;
                                    }
                                    if (I_pV > cursor)
                                    {
                                        break lab25;
                                    }
                                    cursor = limit - v_24;
                                    slice_del();
                                    break lab25;
                            }
                            break lab24;
                        }
                        cursor = limit - v_13;
                        lab42: {
                            if (cursor < I_pV)
                            {
                                break lab42;
                            }
                            int v_25 = limit_backward;
                            limit_backward = I_pV;
                            ket = cursor;
                            if (find_among_b(a_5) == 0)
                            {
                                limit_backward = v_25;
                                break lab42;
                            }
                            bra = cursor;
                            lab43: {
                                if (!(eq_s_b("H")))
                                {
                                    break lab43;
                                }
                                limit_backward = v_25;
                                break lab42;
                            }
                            if (!(out_grouping_b(g_v, 97, 251)))
                            {
                                limit_backward = v_25;
                                break lab42;
                            }
                            slice_del();
                            limit_backward = v_25;
                            break lab24;
                        }
                        cursor = limit - v_13;
                        if (cursor < I_pV)
                        {
                            break lab23;
                        }
                        int v_26 = limit_backward;
                        limit_backward = I_pV;
                        ket = cursor;
                        among_var = find_among_b(a_7);
                        if (among_var == 0)
                        {
                            limit_backward = v_26;
                            break lab23;
                        }
                        bra = cursor;
                        limit_backward = v_26;
                        switch (among_var) {
                            case 1:
                                if (I_p2 > cursor)
                                {
                                    break lab23;
                                }
                                slice_del();
                                break;
                            case 2:
                                slice_del();
                                break;
                            case 3:
                                int v_27 = limit - cursor;
                                lab44: {
                                    if (!(eq_s_b("e")))
                                    {
                                        cursor = limit - v_27;
                                        break lab44;
                                    }
                                    if (I_pV > cursor)
                                    {
                                        cursor = limit - v_27;
                                        break lab44;
                                    }
                                    bra = cursor;
                                }
                                slice_del();
                                break;
                            case 4:
                                {
                                    int v_28 = limit - cursor;
                                    lab45: {
                                        among_var = find_among_b(a_6);
                                        if (among_var == 0)
                                        {
                                            break lab45;
                                        }
                                        switch (among_var) {
                                            case 1:
                                                if (cursor <= limit_backward)
                                                {
                                                    break lab45;
                                                }
                                                cursor--;
                                                if (cursor > limit_backward)
                                                {
                                                    break lab45;
                                                }
                                                break;
                                        }
                                        break lab23;
                                    }
                                    cursor = limit - v_28;
                                }
                                slice_del();
                                break;
                        }
                    }
                    cursor = limit - v_12;
                    int v_29 = limit - cursor;
                    lab46: {
                        ket = cursor;
                        lab47: {
                            int v_30 = limit - cursor;
                            lab48: {
                                if (!(eq_s_b("Y")))
                                {
                                    break lab48;
                                }
                                bra = cursor;
                                slice_from("i");
                                break lab47;
                            }
                            cursor = limit - v_30;
                            if (!(eq_s_b("\u00E7")))
                            {
                                cursor = limit - v_29;
                                break lab46;
                            }
                            bra = cursor;
                            slice_from("c");
                        }
                    }
                    break lab22;
                }
                cursor = limit - v_11;
                int v_31 = limit - cursor;
                lab49: {
                    ket = cursor;
                    if (!(eq_s_b("s")))
                    {
                        cursor = limit - v_31;
                        break lab49;
                    }
                    bra = cursor;
                    int v_32 = limit - cursor;
                    lab50: {
                        lab51: {
                            if (!(eq_s_b("Hi")))
                            {
                                break lab51;
                            }
                            break lab50;
                        }
                        if (!(out_grouping_b(g_keep_with_s, 97, 232)))
                        {
                            cursor = limit - v_31;
                            break lab49;
                        }
                    }
                    cursor = limit - v_32;
                    slice_del();
                }
                if (cursor < I_pV)
                {
                    break lab21;
                }
                int v_33 = limit_backward;
                limit_backward = I_pV;
                ket = cursor;
                among_var = find_among_b(a_8);
                if (among_var == 0)
                {
                    limit_backward = v_33;
                    break lab21;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p2 > cursor)
                        {
                            limit_backward = v_33;
                            break lab21;
                        }
                        lab52: {
                            lab53: {
                                if (!(eq_s_b("s")))
                                {
                                    break lab53;
                                }
                                break lab52;
                            }
                            if (!(eq_s_b("t")))
                            {
                                limit_backward = v_33;
                                break lab21;
                            }
                        }
                        slice_del();
                        break;
                    case 2:
                        slice_from("i");
                        break;
                    case 3:
                        slice_del();
                        break;
                }
                limit_backward = v_33;
            }
        }
        cursor = limit - v_10;
        int v_34 = limit - cursor;
        lab54: {
            int v_35 = limit - cursor;
            if (find_among_b(a_9) == 0)
            {
                break lab54;
            }
            cursor = limit - v_35;
            ket = cursor;
            if (cursor <= limit_backward)
            {
                break lab54;
            }
            cursor--;
            bra = cursor;
            slice_del();
        }
        cursor = limit - v_34;
        int v_36 = limit - cursor;
        lab55: {
            {
                int v_37 = 1;
                while (true)
                {
                    lab56: {
                        if (!(out_grouping_b(g_v, 97, 251)))
                        {
                            break lab56;
                        }
                        v_37--;
                        continue;
                    }
                    break;
                }
                if (v_37 > 0)
                {
                    break lab55;
                }
            }
            ket = cursor;
            lab57: {
                lab58: {
                    if (!(eq_s_b("\u00E9")))
                    {
                        break lab58;
                    }
                    break lab57;
                }
                if (!(eq_s_b("\u00E8")))
                {
                    break lab55;
                }
            }
            bra = cursor;
            slice_from("e");
        }
        cursor = limit - v_36;
        cursor = limit_backward;
        int v_38 = cursor;
        lab59: {
            while (true)
            {
                int v_39 = cursor;
                lab60: {
                    bra = cursor;
                    among_var = find_among(a_1);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("i");
                            break;
                        case 2:
                            slice_from("u");
                            break;
                        case 3:
                            slice_from("y");
                            break;
                        case 4:
                            slice_from("\u00EB");
                            break;
                        case 5:
                            slice_from("\u00EF");
                            break;
                        case 6:
                            slice_del();
                            break;
                        case 7:
                            if (cursor >= limit)
                            {
                                break lab60;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_39;
                break;
            }
        }
        cursor = v_38;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof frenchStemmer;
    }

    @Override
    public int hashCode() {
        return frenchStemmer.class.getName().hashCode();
    }

}
