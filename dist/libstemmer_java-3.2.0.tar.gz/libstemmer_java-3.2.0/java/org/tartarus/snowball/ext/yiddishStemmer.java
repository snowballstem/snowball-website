// Generated from yiddish.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from yiddish.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class yiddishStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("\u05D5\u05D5", -1, 1),
        new Among("\u05D5\u05D9", -1, 2),
        new Among("\u05D9\u05D9", -1, 3),
        new Among("\u05DA", -1, 4),
        new Among("\u05DD", -1, 5),
        new Among("\u05DF", -1, 6),
        new Among("\u05E3", -1, 7),
        new Among("\u05E5", -1, 8)
    };

    private final static Among[] a_1 = {
        new Among("\u05D0\u05D3\u05D5\u05E8\u05DB", -1, 1),
        new Among("\u05D0\u05D4\u05D9\u05E0", -1, 1),
        new Among("\u05D0\u05D4\u05E2\u05E8", -1, 1),
        new Among("\u05D0\u05D4\u05F2\u05DE", -1, 1),
        new Among("\u05D0\u05D5\u05DE", -1, 1),
        new Among("\u05D0\u05D5\u05E0\u05D8\u05E2\u05E8", -1, 1),
        new Among("\u05D0\u05D9\u05D1\u05E2\u05E8", -1, 1),
        new Among("\u05D0\u05E0", -1, 1),
        new Among("\u05D0\u05E0\u05D8", 7, 1),
        new Among("\u05D0\u05E0\u05D8\u05E7\u05E2\u05D2\u05E0", 8, 1),
        new Among("\u05D0\u05E0\u05D9\u05D3\u05E2\u05E8", 7, 1),
        new Among("\u05D0\u05E4", -1, 1),
        new Among("\u05D0\u05E4\u05D9\u05E8", 11, 1),
        new Among("\u05D0\u05E7\u05E2\u05D2\u05E0", -1, 1),
        new Among("\u05D0\u05E8\u05D0\u05E4", -1, 1),
        new Among("\u05D0\u05E8\u05D5\u05DE", -1, 1),
        new Among("\u05D0\u05E8\u05D5\u05E0\u05D8\u05E2\u05E8", -1, 1),
        new Among("\u05D0\u05E8\u05D9\u05D1\u05E2\u05E8", -1, 1),
        new Among("\u05D0\u05E8\u05F1\u05E1", -1, 1),
        new Among("\u05D0\u05E8\u05F1\u05E4", -1, 1),
        new Among("\u05D0\u05E8\u05F2\u05E0", -1, 1),
        new Among("\u05D0\u05F0\u05E2\u05E7", -1, 1),
        new Among("\u05D0\u05F1\u05E1", -1, 1),
        new Among("\u05D0\u05F1\u05E4", -1, 1),
        new Among("\u05D0\u05F2\u05E0", -1, 1),
        new Among("\u05D1\u05D0", -1, 1),
        new Among("\u05D1\u05F2", -1, 1),
        new Among("\u05D3\u05D5\u05E8\u05DB", -1, 1),
        new Among("\u05D3\u05E2\u05E8", -1, 1),
        new Among("\u05DE\u05D9\u05D8", -1, 1),
        new Among("\u05E0\u05D0\u05DB", -1, 1),
        new Among("\u05E4\u05D0\u05E8", -1, 1),
        new Among("\u05E4\u05D0\u05E8\u05D1\u05F2", 31, 1),
        new Among("\u05E4\u05D0\u05E8\u05F1\u05E1", 31, 1),
        new Among("\u05E4\u05D5\u05E0\u05D0\u05E0\u05D3\u05E2\u05E8", -1, 1),
        new Among("\u05E6\u05D5", -1, 1),
        new Among("\u05E6\u05D5\u05D6\u05D0\u05DE\u05E2\u05E0", 35, 1),
        new Among("\u05E6\u05D5\u05E0\u05F1\u05E4", 35, 1),
        new Among("\u05E6\u05D5\u05E8\u05D9\u05E7", 35, 1),
        new Among("\u05E6\u05E2", -1, 1)
    };

    private final static Among[] a_2 = {
        new Among("\u05D3\u05D6\u05E9", -1, -1),
        new Among("\u05E9\u05D8\u05E8", -1, -1),
        new Among("\u05E9\u05D8\u05E9", -1, -1),
        new Among("\u05E9\u05E4\u05E8", -1, -1)
    };

    private final static Among[] a_3 = {
        new Among("\u05E7\u05DC\u05D9\u05D1", -1, 9),
        new Among("\u05E8\u05D9\u05D1", -1, 10),
        new Among("\u05D8\u05E8\u05D9\u05D1", 1, 7),
        new Among("\u05E9\u05E8\u05D9\u05D1", 1, 15),
        new Among("\u05D4\u05F1\u05D1", -1, 23),
        new Among("\u05E9\u05F0\u05D9\u05D2", -1, 12),
        new Among("\u05D2\u05D0\u05E0\u05D2", -1, 1),
        new Among("\u05D6\u05D5\u05E0\u05D2", -1, 18),
        new Among("\u05E9\u05DC\u05D5\u05E0\u05D2", -1, 21),
        new Among("\u05E6\u05F0\u05D5\u05E0\u05D2", -1, 20),
        new Among("\u05D1\u05F1\u05D2", -1, 22),
        new Among("\u05D1\u05D5\u05E0\u05D3", -1, 16),
        new Among("\u05F0\u05D9\u05D6", -1, 6),
        new Among("\u05D1\u05D9\u05D8", -1, 4),
        new Among("\u05DC\u05D9\u05D8", -1, 8),
        new Among("\u05DE\u05D9\u05D8", -1, 3),
        new Among("\u05E9\u05E0\u05D9\u05D8", -1, 14),
        new Among("\u05E0\u05D5\u05DE", -1, 2),
        new Among("\u05E9\u05D8\u05D0\u05E0", -1, 25),
        new Among("\u05D1\u05D9\u05E1", -1, 5),
        new Among("\u05E9\u05DE\u05D9\u05E1", -1, 13),
        new Among("\u05E8\u05D9\u05E1", -1, 11),
        new Among("\u05D8\u05E8\u05D5\u05E0\u05E7", -1, 19),
        new Among("\u05E4\u05D0\u05E8\u05DC\u05F1\u05E8", -1, 24),
        new Among("\u05E9\u05F0\u05F1\u05E8", -1, 26),
        new Among("\u05F0\u05D5\u05D8\u05E9", -1, 17)
    };

    private final static Among[] a_4 = {
        new Among("\u05D5\u05E0\u05D2", -1, 1),
        new Among("\u05E1\u05D8\u05D5", -1, 1),
        new Among("\u05D8", -1, 1),
        new Among("\u05D1\u05E8\u05D0\u05DB\u05D8", 2, 31),
        new Among("\u05E1\u05D8", 2, 1),
        new Among("\u05D9\u05E1\u05D8", 4, 33),
        new Among("\u05E2\u05D8", 2, 1),
        new Among("\u05E9\u05D0\u05E4\u05D8", 2, 1),
        new Among("\u05D4\u05F2\u05D8", 2, 1),
        new Among("\u05E7\u05F2\u05D8", 2, 1),
        new Among("\u05D9\u05E7\u05F2\u05D8", 9, 1),
        new Among("\u05DC\u05E2\u05DB", -1, 1),
        new Among("\u05E2\u05DC\u05E2\u05DB", 11, 1),
        new Among("\u05D9\u05D6\u05DE", -1, 1),
        new Among("\u05D9\u05DE", -1, 1),
        new Among("\u05E2\u05DE", -1, 1),
        new Among("\u05E2\u05E0\u05E2\u05DE", 15, 3),
        new Among("\u05D8\u05E2\u05E0\u05E2\u05DE", 16, 4),
        new Among("\u05E0", -1, 1),
        new Among("\u05E7\u05DC\u05D9\u05D1\u05E0", 18, 14),
        new Among("\u05E8\u05D9\u05D1\u05E0", 18, 15),
        new Among("\u05D8\u05E8\u05D9\u05D1\u05E0", 20, 12),
        new Among("\u05E9\u05E8\u05D9\u05D1\u05E0", 20, 7),
        new Among("\u05D4\u05F1\u05D1\u05E0", 18, 27),
        new Among("\u05E9\u05F0\u05D9\u05D2\u05E0", 18, 17),
        new Among("\u05D6\u05D5\u05E0\u05D2\u05E0", 18, 22),
        new Among("\u05E9\u05DC\u05D5\u05E0\u05D2\u05E0", 18, 25),
        new Among("\u05E6\u05F0\u05D5\u05E0\u05D2\u05E0", 18, 24),
        new Among("\u05D1\u05F1\u05D2\u05E0", 18, 26),
        new Among("\u05D1\u05D5\u05E0\u05D3\u05E0", 18, 20),
        new Among("\u05F0\u05D9\u05D6\u05E0", 18, 11),
        new Among("\u05D8\u05E0", 18, 4),
        new Among("GE\u05D1\u05D9\u05D8\u05E0", 31, 9),
        new Among("GE\u05DC\u05D9\u05D8\u05E0", 31, 13),
        new Among("GE\u05DE\u05D9\u05D8\u05E0", 31, 8),
        new Among("\u05E9\u05E0\u05D9\u05D8\u05E0", 31, 19),
        new Among("\u05E1\u05D8\u05E0", 31, 1),
        new Among("\u05D9\u05E1\u05D8\u05E0", 36, 1),
        new Among("\u05E2\u05D8\u05E0", 31, 1),
        new Among("GE\u05D1\u05D9\u05E1\u05E0", 18, 10),
        new Among("\u05E9\u05DE\u05D9\u05E1\u05E0", 18, 18),
        new Among("GE\u05E8\u05D9\u05E1\u05E0", 18, 16),
        new Among("\u05E2\u05E0", 18, 1),
        new Among("\u05D2\u05D0\u05E0\u05D2\u05E2\u05E0", 42, 5),
        new Among("\u05E2\u05DC\u05E2\u05E0", 42, 1),
        new Among("\u05E0\u05D5\u05DE\u05E2\u05E0", 42, 6),
        new Among("\u05D9\u05D6\u05DE\u05E2\u05E0", 42, 1),
        new Among("\u05E9\u05D8\u05D0\u05E0\u05E2\u05E0", 42, 29),
        new Among("\u05D8\u05E8\u05D5\u05E0\u05E7\u05E0", 18, 23),
        new Among("\u05E4\u05D0\u05E8\u05DC\u05F1\u05E8\u05E0", 18, 28),
        new Among("\u05E9\u05F0\u05F1\u05E8\u05E0", 18, 30),
        new Among("\u05F0\u05D5\u05D8\u05E9\u05E0", 18, 21),
        new Among("\u05D2\u05F2\u05E0", 18, 5),
        new Among("\u05E1", -1, 1),
        new Among("\u05D8\u05E1", 53, 4),
        new Among("\u05E2\u05D8\u05E1", 54, 1),
        new Among("\u05E0\u05E1", 53, 1),
        new Among("\u05D8\u05E0\u05E1", 56, 4),
        new Among("\u05E2\u05E0\u05E1", 56, 3),
        new Among("\u05E2\u05E1", 53, 1),
        new Among("\u05D9\u05E2\u05E1", 59, 2),
        new Among("\u05E2\u05DC\u05E2\u05E1", 59, 1),
        new Among("\u05E2\u05E8\u05E1", 53, 1),
        new Among("\u05E2\u05E0\u05E2\u05E8\u05E1", 62, 1),
        new Among("\u05E2", -1, 1),
        new Among("\u05D8\u05E2", 64, 4),
        new Among("\u05E1\u05D8\u05E2", 65, 1),
        new Among("\u05E2\u05D8\u05E2", 65, 1),
        new Among("\u05D9\u05E2", 64, -1),
        new Among("\u05E2\u05DC\u05E2", 64, 1),
        new Among("\u05E2\u05E0\u05E2", 64, 3),
        new Among("\u05D8\u05E2\u05E0\u05E2", 70, 4),
        new Among("\u05E2\u05E8", -1, 1),
        new Among("\u05D8\u05E2\u05E8", 72, 4),
        new Among("\u05E1\u05D8\u05E2\u05E8", 73, 1),
        new Among("\u05E2\u05D8\u05E2\u05E8", 73, 1),
        new Among("\u05E2\u05E0\u05E2\u05E8", 72, 3),
        new Among("\u05D8\u05E2\u05E0\u05E2\u05E8", 76, 4),
        new Among("\u05D5\u05EA", -1, 32)
    };

    private final static Among[] a_5 = {
        new Among("\u05D5\u05E0\u05D2", -1, 1),
        new Among("\u05E9\u05D0\u05E4\u05D8", -1, 1),
        new Among("\u05D4\u05F2\u05D8", -1, 1),
        new Among("\u05E7\u05F2\u05D8", -1, 1),
        new Among("\u05D9\u05E7\u05F2\u05D8", 3, 1),
        new Among("\u05DC", -1, 2)
    };

    private final static Among[] a_6 = {
        new Among("\u05D9\u05D2", -1, 1),
        new Among("\u05D9\u05E7", -1, 1),
        new Among("\u05D3\u05D9\u05E7", 1, 1),
        new Among("\u05E0\u05D3\u05D9\u05E7", 2, 1),
        new Among("\u05E2\u05E0\u05D3\u05D9\u05E7", 3, 1),
        new Among("\u05D1\u05DC\u05D9\u05E7", 1, -1),
        new Among("\u05D2\u05DC\u05D9\u05E7", 1, -1),
        new Among("\u05E0\u05D9\u05E7", 1, 1),
        new Among("\u05D9\u05E9", -1, 1)
    };

    private static final char[] g_niked = {255, 155, 6 };

    private static final char[] g_vowel = {33, 2, 4, 0, 6 };

    private static final char[] g_consonant = {239, 254, 253, 131 };


    @Override
    public boolean stem() {
        int among_var;
        int I_x;
        int I_p1;
        lab0: {
            int v_1 = cursor;
            lab1: {
                while (true)
                {
                    int v_2 = cursor;
                    lab2: {
                        golab3: while (true)
                        {
                            int v_3 = cursor;
                            lab4: {
                                bra = cursor;
                                among_var = find_among(a_0);
                                if (among_var == 0)
                                {
                                    break lab4;
                                }
                                ket = cursor;
                                switch (among_var) {
                                    case 1:
                                        lab5: {
                                            if (!(eq_s("\u05BC")))
                                            {
                                                break lab5;
                                            }
                                            break lab4;
                                        }
                                        slice_from("\u05F0");
                                        break;
                                    case 2:
                                        lab6: {
                                            if (!(eq_s("\u05B4")))
                                            {
                                                break lab6;
                                            }
                                            break lab4;
                                        }
                                        slice_from("\u05F1");
                                        break;
                                    case 3:
                                        lab7: {
                                            if (!(eq_s("\u05B4")))
                                            {
                                                break lab7;
                                            }
                                            break lab4;
                                        }
                                        slice_from("\u05F2");
                                        break;
                                    case 4:
                                        slice_from("\u05DB");
                                        break;
                                    case 5:
                                        slice_from("\u05DE");
                                        break;
                                    case 6:
                                        slice_from("\u05E0");
                                        break;
                                    case 7:
                                        slice_from("\u05E4");
                                        break;
                                    case 8:
                                        slice_from("\u05E6");
                                        break;
                                }
                                cursor = v_3;
                                break golab3;
                            }
                            cursor = v_3;
                            if (cursor >= limit)
                            {
                                break lab2;
                            }
                            cursor++;
                        }
                        continue;
                    }
                    cursor = v_2;
                    break;
                }
            }
            cursor = v_1;
            int v_4 = cursor;
            lab8: {
                while (true)
                {
                    int v_5 = cursor;
                    lab9: {
                        golab10: while (true)
                        {
                            int v_6 = cursor;
                            lab11: {
                                bra = cursor;
                                if (!(in_grouping(g_niked, 1456, 1474)))
                                {
                                    break lab11;
                                }
                                ket = cursor;
                                slice_del();
                                cursor = v_6;
                                break golab10;
                            }
                            cursor = v_6;
                            if (cursor >= limit)
                            {
                                break lab9;
                            }
                            cursor++;
                        }
                        continue;
                    }
                    cursor = v_5;
                    break;
                }
            }
            cursor = v_4;
        }
        int v_7 = cursor;
        lab12: {
            I_p1 = limit;
            int v_8 = cursor;
            lab13: {
                bra = cursor;
                if (!(eq_s("\u05D2\u05E2")))
                {
                    cursor = v_8;
                    break lab13;
                }
                ket = cursor;
                {
                    int v_9 = cursor;
                    lab14: {
                        lab15: {
                            lab16: {
                                if (!(eq_s("\u05DC\u05D8")))
                                {
                                    break lab16;
                                }
                                break lab15;
                            }
                            lab17: {
                                if (!(eq_s("\u05D1\u05E0")))
                                {
                                    break lab17;
                                }
                                break lab15;
                            }
                            if (cursor < limit)
                            {
                                break lab14;
                            }
                        }
                        cursor = v_8;
                        break lab13;
                    }
                    cursor = v_9;
                }
                slice_from("GE");
            }
            int v_10 = cursor;
            lab18: {
                if (find_among(a_1) == 0)
                {
                    cursor = v_10;
                    break lab18;
                }
                lab19: {
                    int v_11 = cursor;
                    lab20: {
                        int v_12 = cursor;
                        lab21: {
                            lab22: {
                                if (!(eq_s("\u05E6\u05D5\u05D2\u05E0")))
                                {
                                    break lab22;
                                }
                                break lab21;
                            }
                            lab23: {
                                if (!(eq_s("\u05E6\u05D5\u05E7\u05D8")))
                                {
                                    break lab23;
                                }
                                break lab21;
                            }
                            if (!(eq_s("\u05E6\u05D5\u05E7\u05E0")))
                            {
                                break lab20;
                            }
                        }
                        if (cursor < limit)
                        {
                            break lab20;
                        }
                        cursor = v_12;
                        break lab19;
                    }
                    cursor = v_11;
                    lab24: {
                        int v_13 = cursor;
                        if (!(eq_s("\u05D2\u05E2\u05D1\u05E0")))
                        {
                            break lab24;
                        }
                        cursor = v_13;
                        break lab19;
                    }
                    cursor = v_11;
                    lab25: {
                        bra = cursor;
                        if (!(eq_s("\u05D2\u05E2")))
                        {
                            break lab25;
                        }
                        ket = cursor;
                        slice_from("GE");
                        break lab19;
                    }
                    cursor = v_11;
                    bra = cursor;
                    if (!(eq_s("\u05E6\u05D5")))
                    {
                        cursor = v_10;
                        break lab18;
                    }
                    ket = cursor;
                    slice_from("TSU");
                }
            }
            int v_14 = cursor;
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab12;
                }
                cursor = c;
            }
            I_x = cursor;
            cursor = v_14;
            int v_15 = cursor;
            lab26: {
                if (find_among(a_2) == 0)
                {
                    cursor = v_15;
                    break lab26;
                }
            }
            {
                int v_16 = cursor;
                lab27: {
                    if (!(in_grouping(g_consonant, 1489, 1520)))
                    {
                        break lab27;
                    }
                    if (!(in_grouping(g_consonant, 1489, 1520)))
                    {
                        break lab27;
                    }
                    if (!(in_grouping(g_consonant, 1489, 1520)))
                    {
                        break lab27;
                    }
                    I_p1 = cursor;
                    break lab12;
                }
                cursor = v_16;
            }
            if (!go_out_grouping(g_vowel, 1488, 1522))
            {
                break lab12;
            }
            cursor++;
            if (!go_in_grouping(g_vowel, 1488, 1522))
            {
                break lab12;
            }
            I_p1 = cursor;
            lab28: {
                if (I_p1 >= I_x)
                {
                    break lab28;
                }
                I_p1 = I_x;
            }
        }
        cursor = v_7;
        limit_backward = cursor;
        cursor = limit;
        lab29: {
            int v_17 = limit - cursor;
            lab30: {
                ket = cursor;
                among_var = find_among_b(a_4);
                if (among_var == 0)
                {
                    break lab30;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p1 > cursor)
                        {
                            break lab30;
                        }
                        slice_del();
                        break;
                    case 2:
                        if (I_p1 > cursor)
                        {
                            break lab30;
                        }
                        slice_from("\u05D9\u05E2");
                        break;
                    case 3:
                        if (I_p1 > cursor)
                        {
                            break lab30;
                        }
                        slice_del();
                        ket = cursor;
                        among_var = find_among_b(a_3);
                        if (among_var == 0)
                        {
                            break lab30;
                        }
                        bra = cursor;
                        switch (among_var) {
                            case 1:
                                slice_from("\u05D2\u05F2");
                                break;
                            case 2:
                                slice_from("\u05E0\u05E2\u05DE");
                                break;
                            case 3:
                                slice_from("\u05DE\u05F2\u05D3");
                                break;
                            case 4:
                                slice_from("\u05D1\u05F2\u05D8");
                                break;
                            case 5:
                                slice_from("\u05D1\u05F2\u05E1");
                                break;
                            case 6:
                                slice_from("\u05F0\u05F2\u05D6");
                                break;
                            case 7:
                                slice_from("\u05D8\u05E8\u05F2\u05D1");
                                break;
                            case 8:
                                slice_from("\u05DC\u05F2\u05D8");
                                break;
                            case 9:
                                slice_from("\u05E7\u05DC\u05F2\u05D1");
                                break;
                            case 10:
                                slice_from("\u05E8\u05F2\u05D1");
                                break;
                            case 11:
                                slice_from("\u05E8\u05F2\u05E1");
                                break;
                            case 12:
                                slice_from("\u05E9\u05F0\u05F2\u05D2");
                                break;
                            case 13:
                                slice_from("\u05E9\u05DE\u05F2\u05E1");
                                break;
                            case 14:
                                slice_from("\u05E9\u05E0\u05F2\u05D3");
                                break;
                            case 15:
                                slice_from("\u05E9\u05E8\u05F2\u05D1");
                                break;
                            case 16:
                                slice_from("\u05D1\u05D9\u05E0\u05D3");
                                break;
                            case 17:
                                slice_from("\u05F0\u05D9\u05D8\u05E9");
                                break;
                            case 18:
                                slice_from("\u05D6\u05D9\u05E0\u05D2");
                                break;
                            case 19:
                                slice_from("\u05D8\u05E8\u05D9\u05E0\u05E7");
                                break;
                            case 20:
                                slice_from("\u05E6\u05F0\u05D9\u05E0\u05D2");
                                break;
                            case 21:
                                slice_from("\u05E9\u05DC\u05D9\u05E0\u05D2");
                                break;
                            case 22:
                                slice_from("\u05D1\u05F2\u05D2");
                                break;
                            case 23:
                                slice_from("\u05D4\u05F2\u05D1");
                                break;
                            case 24:
                                slice_from("\u05E4\u05D0\u05E8\u05DC\u05D9\u05E8");
                                break;
                            case 25:
                                slice_from("\u05E9\u05D8\u05F2");
                                break;
                            case 26:
                                slice_from("\u05E9\u05F0\u05E2\u05E8");
                                break;
                        }
                        break;
                    case 4:
                        lab31: {
                            int v_18 = limit - cursor;
                            lab32: {
                                if (I_p1 > cursor)
                                {
                                    break lab32;
                                }
                                slice_del();
                                break lab31;
                            }
                            cursor = limit - v_18;
                            slice_from("\u05D8");
                        }
                        ket = cursor;
                        if (!(eq_s_b("\u05D1\u05E8\u05D0\u05DB")))
                        {
                            break lab30;
                        }
                        int v_19 = limit - cursor;
                        lab33: {
                            if (!(eq_s_b("\u05D2\u05E2")))
                            {
                                cursor = limit - v_19;
                                break lab33;
                            }
                        }
                        bra = cursor;
                        slice_from("\u05D1\u05E8\u05E2\u05E0\u05D2");
                        break;
                    case 5:
                        slice_from("\u05D2\u05F2");
                        break;
                    case 6:
                        slice_from("\u05E0\u05E2\u05DE");
                        break;
                    case 7:
                        slice_from("\u05E9\u05E8\u05F2\u05D1");
                        break;
                    case 8:
                        slice_from("\u05DE\u05F2\u05D3");
                        break;
                    case 9:
                        slice_from("\u05D1\u05F2\u05D8");
                        break;
                    case 10:
                        slice_from("\u05D1\u05F2\u05E1");
                        break;
                    case 11:
                        slice_from("\u05F0\u05F2\u05D6");
                        break;
                    case 12:
                        slice_from("\u05D8\u05E8\u05F2\u05D1");
                        break;
                    case 13:
                        slice_from("\u05DC\u05F2\u05D8");
                        break;
                    case 14:
                        slice_from("\u05E7\u05DC\u05F2\u05D1");
                        break;
                    case 15:
                        slice_from("\u05E8\u05F2\u05D1");
                        break;
                    case 16:
                        slice_from("\u05E8\u05F2\u05E1");
                        break;
                    case 17:
                        slice_from("\u05E9\u05F0\u05F2\u05D2");
                        break;
                    case 18:
                        slice_from("\u05E9\u05DE\u05F2\u05E1");
                        break;
                    case 19:
                        slice_from("\u05E9\u05E0\u05F2\u05D3");
                        break;
                    case 20:
                        slice_from("\u05D1\u05D9\u05E0\u05D3");
                        break;
                    case 21:
                        slice_from("\u05F0\u05D9\u05D8\u05E9");
                        break;
                    case 22:
                        slice_from("\u05D6\u05D9\u05E0\u05D2");
                        break;
                    case 23:
                        slice_from("\u05D8\u05E8\u05D9\u05E0\u05E7");
                        break;
                    case 24:
                        slice_from("\u05E6\u05F0\u05D9\u05E0\u05D2");
                        break;
                    case 25:
                        slice_from("\u05E9\u05DC\u05D9\u05E0\u05D2");
                        break;
                    case 26:
                        slice_from("\u05D1\u05F2\u05D2");
                        break;
                    case 27:
                        slice_from("\u05D4\u05F2\u05D1");
                        break;
                    case 28:
                        slice_from("\u05E4\u05D0\u05E8\u05DC\u05D9\u05E8");
                        break;
                    case 29:
                        slice_from("\u05E9\u05D8\u05F2");
                        break;
                    case 30:
                        slice_from("\u05E9\u05F0\u05E2\u05E8");
                        break;
                    case 31:
                        slice_from("\u05D1\u05E8\u05E2\u05E0\u05D2");
                        break;
                    case 32:
                        if (I_p1 > cursor)
                        {
                            break lab30;
                        }
                        slice_from("\u05D4");
                        break;
                    case 33:
                        lab34: {
                            int v_20 = limit - cursor;
                            lab35: {
                                lab36: {
                                    lab37: {
                                        if (!(eq_s_b("\u05D2")))
                                        {
                                            break lab37;
                                        }
                                        break lab36;
                                    }
                                    if (!(eq_s_b("\u05E9")))
                                    {
                                        break lab35;
                                    }
                                }
                                int v_21 = limit - cursor;
                                lab38: {
                                    if (I_p1 > (cursor + 3))
                                    {
                                        cursor = limit - v_21;
                                        break lab38;
                                    }
                                    slice_from("\u05D9\u05E1");
                                }
                                break lab34;
                            }
                            cursor = limit - v_20;
                            if (I_p1 > cursor)
                            {
                                break lab30;
                            }
                            slice_del();
                        }
                        break;
                }
            }
            cursor = limit - v_17;
            int v_22 = limit - cursor;
            lab39: {
                ket = cursor;
                among_var = find_among_b(a_5);
                if (among_var == 0)
                {
                    break lab39;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p1 > cursor)
                        {
                            break lab39;
                        }
                        slice_del();
                        break;
                    case 2:
                        if (I_p1 > cursor)
                        {
                            break lab39;
                        }
                        if (!(in_grouping_b(g_consonant, 1489, 1520)))
                        {
                            break lab39;
                        }
                        slice_del();
                        break;
                }
            }
            cursor = limit - v_22;
            int v_23 = limit - cursor;
            lab40: {
                ket = cursor;
                among_var = find_among_b(a_6);
                if (among_var == 0)
                {
                    break lab40;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p1 > cursor)
                        {
                            break lab40;
                        }
                        slice_del();
                        break;
                }
            }
            cursor = limit - v_23;
            int v_24 = limit - cursor;
            lab41: {
                while (true)
                {
                    int v_25 = limit - cursor;
                    lab42: {
                        golab43: while (true)
                        {
                            int v_26 = limit - cursor;
                            lab44: {
                                ket = cursor;
                                lab45: {
                                    lab46: {
                                        if (!(eq_s_b("GE")))
                                        {
                                            break lab46;
                                        }
                                        break lab45;
                                    }
                                    if (!(eq_s_b("TSU")))
                                    {
                                        break lab44;
                                    }
                                }
                                bra = cursor;
                                slice_del();
                                cursor = limit - v_26;
                                break golab43;
                            }
                            cursor = limit - v_26;
                            if (cursor <= limit_backward)
                            {
                                break lab42;
                            }
                            cursor--;
                        }
                        continue;
                    }
                    cursor = limit - v_25;
                    break;
                }
            }
            cursor = limit - v_24;
        }
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof yiddishStemmer;
    }

    @Override
    public int hashCode() {
        return yiddishStemmer.class.getName().hashCode();
    }

}
