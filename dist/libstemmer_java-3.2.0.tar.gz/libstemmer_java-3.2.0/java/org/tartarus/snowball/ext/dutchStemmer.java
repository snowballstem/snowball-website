// Generated from dutch.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import java.util.Arrays;

import org.tartarus.snowball.Among;

import org.tartarus.snowball.CharArraySequence;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from dutch.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class dutchStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("a", -1, 1),
        new Among("e", -1, 2),
        new Among("o", -1, 1),
        new Among("u", -1, 1),
        new Among("\u00E0", -1, 1),
        new Among("\u00E1", -1, 1),
        new Among("\u00E2", -1, 1),
        new Among("\u00E4", -1, 1),
        new Among("\u00E8", -1, 2),
        new Among("\u00E9", -1, 2),
        new Among("\u00EA", -1, 2),
        new Among("e\u00EB", -1, 3),
        new Among("i\u00EB", -1, 4),
        new Among("\u00F2", -1, 1),
        new Among("\u00F3", -1, 1),
        new Among("\u00F4", -1, 1),
        new Among("\u00F6", -1, 1),
        new Among("\u00F9", -1, 1),
        new Among("\u00FA", -1, 1),
        new Among("\u00FB", -1, 1),
        new Among("\u00FC", -1, 1)
    };

    private final static Among[] a_1 = {
        new Among("nde", -1, 8),
        new Among("en", -1, 7),
        new Among("s", -1, 2),
        new Among("'s", 2, 1),
        new Among("es", 2, 4),
        new Among("ies", 4, 3),
        new Among("aus", 2, 6),
        new Among("\u00E9s", 2, 5)
    };

    private final static Among[] a_2 = {
        new Among("de", -1, 5),
        new Among("ge", -1, 2),
        new Among("ische", -1, 4),
        new Among("je", -1, 1),
        new Among("lijke", -1, 3),
        new Among("le", -1, 9),
        new Among("ene", -1, 10),
        new Among("re", -1, 8),
        new Among("se", -1, 7),
        new Among("te", -1, 6),
        new Among("ieve", -1, 11)
    };

    private final static Among[] a_3 = {
        new Among("heid", -1, 3),
        new Among("fie", -1, 7),
        new Among("gie", -1, 8),
        new Among("atie", -1, 1),
        new Among("isme", -1, 5),
        new Among("ing", -1, 5),
        new Among("arij", -1, 6),
        new Among("erij", -1, 5),
        new Among("sel", -1, 3),
        new Among("rder", -1, 4),
        new Among("ster", -1, 3),
        new Among("iteit", -1, 2),
        new Among("dst", -1, 10),
        new Among("tst", -1, 9)
    };

    private final static Among[] a_4 = {
        new Among("end", -1, 9),
        new Among("atief", -1, 2),
        new Among("erig", -1, 9),
        new Among("achtig", -1, 3),
        new Among("ioneel", -1, 1),
        new Among("baar", -1, 3),
        new Among("laar", -1, 5),
        new Among("naar", -1, 4),
        new Among("raar", -1, 6),
        new Among("eriger", -1, 9),
        new Among("achtiger", -1, 3),
        new Among("lijker", -1, 8),
        new Among("tant", -1, 7),
        new Among("erigst", -1, 9),
        new Among("achtigst", -1, 3),
        new Among("lijkst", -1, 8)
    };

    private final static Among[] a_5 = {
        new Among("ig", -1, 1),
        new Among("iger", -1, 1),
        new Among("igst", -1, 1)
    };

    private final static Among[] a_6 = {
        new Among("ft", -1, 2),
        new Among("kt", -1, 1),
        new Among("pt", -1, 3)
    };

    private final static Among[] a_7 = {
        new Among("bb", -1, 1),
        new Among("cc", -1, 2),
        new Among("dd", -1, 3),
        new Among("ff", -1, 4),
        new Among("gg", -1, 5),
        new Among("hh", -1, 6),
        new Among("jj", -1, 7),
        new Among("kk", -1, 8),
        new Among("ll", -1, 9),
        new Among("mm", -1, 10),
        new Among("nn", -1, 11),
        new Among("pp", -1, 12),
        new Among("qq", -1, 13),
        new Among("rr", -1, 14),
        new Among("ss", -1, 15),
        new Among("tt", -1, 16),
        new Among("v", -1, 4),
        new Among("vv", 16, 17),
        new Among("ww", -1, 18),
        new Among("xx", -1, 19),
        new Among("z", -1, 15),
        new Among("zz", 20, 20)
    };

    private final static Among[] a_8 = {
        new Among("d", -1, 1),
        new Among("t", -1, 2)
    };

    private final static Among[] a_9 = {
        new Among("", -1, -1),
        new Among("eft", 0, 1),
        new Among("vaa", 0, 1),
        new Among("val", 0, 1),
        new Among("vali", 3, -1),
        new Among("vare", 0, 1)
    };

    private final static Among[] a_10 = {
        new Among("\u00EB", -1, 1),
        new Among("\u00EF", -1, 2)
    };

    private final static Among[] a_11 = {
        new Among("\u00EB", -1, 1),
        new Among("\u00EF", -1, 2)
    };

    private static final char[] g_E = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120 };

    private static final char[] g_AIOU = {1, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 11, 120, 46, 15 };

    private static final char[] g_AEIOU = {17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 139, 127, 46, 15 };

    private static final char[] g_v = {17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 139, 127, 46, 15 };

    private static final char[] g_v_WX = {17, 65, 208, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 139, 127, 46, 15 };

    private int I_p2;
    private int I_p1;
    private char[] S_ch = new char[8];
    private int LS_ch = 0;


    private boolean r_V() {
        int v_1 = limit - cursor;
        lab0: {
            lab1: {
                if (!(in_grouping_b(g_v, 97, 252)))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("ij")))
            {
                return false;
            }
        }
        cursor = limit - v_1;
        return true;
    }

    private boolean r_C() {
        int v_1 = limit - cursor;
        lab0: {
            if (!(eq_s_b("ij")))
            {
                break lab0;
            }
            return false;
        }
        if (!(out_grouping_b(g_v, 97, 252)))
        {
            return false;
        }
        cursor = limit - v_1;
        return true;
    }

    private boolean r_lengthen_V() {
        int among_var;
        int v_1 = limit - cursor;
        lab0: {
            if (!(out_grouping_b(g_v_WX, 97, 252)))
            {
                break lab0;
            }
            ket = cursor;
            among_var = find_among_b(a_0);
            if (among_var == 0)
            {
                break lab0;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    int v_2 = limit - cursor;
                    lab1: {
                        lab2: {
                            if (!(out_grouping_b(g_AEIOU, 97, 252)))
                            {
                                break lab2;
                            }
                            break lab1;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab0;
                        }
                    }
                    cursor = limit - v_2;
                    slice_check();
                    if (S_ch.length < ket - bra) {
                        S_ch = Arrays.copyOfRange(current, bra, ket);
                    } else {
                        System.arraycopy(current, bra, S_ch, 0, ket - bra);
                    }
                    LS_ch = ket - bra;
                    {
                        int c = cursor;
                        insert(cursor, cursor, new CharArraySequence(S_ch, LS_ch));
                        cursor = c;
                    }
                    break;
                case 2:
                    int v_3 = limit - cursor;
                    lab3: {
                        lab4: {
                            if (!(out_grouping_b(g_AEIOU, 97, 252)))
                            {
                                break lab4;
                            }
                            break lab3;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab0;
                        }
                    }
                    {
                        int v_4 = limit - cursor;
                        lab5: {
                            lab6: {
                                lab7: {
                                    if (!(in_grouping_b(g_AIOU, 97, 252)))
                                    {
                                        break lab7;
                                    }
                                    break lab6;
                                }
                                if (!(in_grouping_b(g_E, 101, 235)))
                                {
                                    break lab5;
                                }
                                if (cursor > limit_backward)
                                {
                                    break lab5;
                                }
                            }
                            break lab0;
                        }
                        cursor = limit - v_4;
                    }
                    {
                        int v_5 = limit - cursor;
                        lab8: {
                            if (cursor <= limit_backward)
                            {
                                break lab8;
                            }
                            cursor--;
                            if (!(in_grouping_b(g_AIOU, 97, 252)))
                            {
                                break lab8;
                            }
                            if (!(out_grouping_b(g_AEIOU, 97, 252)))
                            {
                                break lab8;
                            }
                            break lab0;
                        }
                        cursor = limit - v_5;
                    }
                    cursor = limit - v_3;
                    slice_check();
                    if (S_ch.length < ket - bra) {
                        S_ch = Arrays.copyOfRange(current, bra, ket);
                    } else {
                        System.arraycopy(current, bra, S_ch, 0, ket - bra);
                    }
                    LS_ch = ket - bra;
                    {
                        int c = cursor;
                        insert(cursor, cursor, new CharArraySequence(S_ch, LS_ch));
                        cursor = c;
                    }
                    break;
                case 3:
                    slice_from("e\u00EBe");
                    break;
                case 4:
                    slice_from("iee");
                    break;
            }
        }
        cursor = limit - v_1;
        return true;
    }

    private boolean r_Step_1c() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_8);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        if (I_p1 > cursor)
        {
            return false;
        }
        if (!r_C())
        {
            return false;
        }
        switch (among_var) {
            case 1:
                {
                    int v_1 = limit - cursor;
                    lab0: {
                        if (!(eq_s_b("n")))
                        {
                            break lab0;
                        }
                        if (I_p1 > cursor)
                        {
                            break lab0;
                        }
                        return false;
                    }
                    cursor = limit - v_1;
                }
                lab1: {
                    int v_2 = limit - cursor;
                    lab2: {
                        if (!(eq_s_b("in")))
                        {
                            break lab2;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab2;
                        }
                        slice_from("n");
                        break lab1;
                    }
                    cursor = limit - v_2;
                    slice_del();
                }
                break;
            case 2:
                {
                    int v_3 = limit - cursor;
                    lab3: {
                        if (!(eq_s_b("h")))
                        {
                            break lab3;
                        }
                        if (I_p1 > cursor)
                        {
                            break lab3;
                        }
                        return false;
                    }
                    cursor = limit - v_3;
                }
                {
                    int v_4 = limit - cursor;
                    lab4: {
                        if (!(eq_s_b("en")))
                        {
                            break lab4;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        return false;
                    }
                    cursor = limit - v_4;
                }
                slice_del();
                break;
        }
        return true;
    }

    private boolean r_measure() {
        I_p1 = limit;
        I_p2 = limit;
        int v_1 = cursor;
        lab0: {
            while (true)
            {
                lab1: {
                    if (!(out_grouping(g_v, 97, 252)))
                    {
                        break lab1;
                    }
                    continue;
                }
                break;
            }
            {
                int v_2 = 1;
                while (true)
                {
                    int v_3 = cursor;
                    lab2: {
                        lab3: {
                            lab4: {
                                if (!(eq_s("ij")))
                                {
                                    break lab4;
                                }
                                break lab3;
                            }
                            if (!(in_grouping(g_v, 97, 252)))
                            {
                                break lab2;
                            }
                        }
                        v_2--;
                        continue;
                    }
                    cursor = v_3;
                    break;
                }
                if (v_2 > 0)
                {
                    break lab0;
                }
            }
            if (!(out_grouping(g_v, 97, 252)))
            {
                break lab0;
            }
            I_p1 = cursor;
            while (true)
            {
                lab5: {
                    if (!(out_grouping(g_v, 97, 252)))
                    {
                        break lab5;
                    }
                    continue;
                }
                break;
            }
            {
                int v_4 = 1;
                while (true)
                {
                    int v_5 = cursor;
                    lab6: {
                        lab7: {
                            lab8: {
                                if (!(eq_s("ij")))
                                {
                                    break lab8;
                                }
                                break lab7;
                            }
                            if (!(in_grouping(g_v, 97, 252)))
                            {
                                break lab6;
                            }
                        }
                        v_4--;
                        continue;
                    }
                    cursor = v_5;
                    break;
                }
                if (v_4 > 0)
                {
                    break lab0;
                }
            }
            if (!(out_grouping(g_v, 97, 252)))
            {
                break lab0;
            }
            I_p2 = cursor;
        }
        cursor = v_1;
        return true;
    }

    @Override
    public boolean stem() {
        int among_var;
        boolean B_GE_removed;
        boolean B_stemmed;
        B_stemmed = false;
        r_measure();
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        lab0: {
            ket = cursor;
            among_var = find_among_b(a_1);
            if (among_var == 0)
            {
                break lab0;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    if (I_p1 > cursor)
                    {
                        break lab0;
                    }
                    {
                        int v_2 = limit - cursor;
                        lab1: {
                            if (!(eq_s_b("t")))
                            {
                                break lab1;
                            }
                            if (I_p1 > cursor)
                            {
                                break lab1;
                            }
                            break lab0;
                        }
                        cursor = limit - v_2;
                    }
                    if (!r_C())
                    {
                        break lab0;
                    }
                    slice_del();
                    break;
                case 3:
                    if (I_p1 > cursor)
                    {
                        break lab0;
                    }
                    slice_from("ie");
                    break;
                case 4:
                    lab2: {
                        int v_3 = limit - cursor;
                        lab3: {
                            int v_4 = limit - cursor;
                            if (!(eq_s_b("ar")))
                            {
                                break lab3;
                            }
                            if (I_p1 > cursor)
                            {
                                break lab3;
                            }
                            if (!r_C())
                            {
                                break lab3;
                            }
                            cursor = limit - v_4;
                            slice_del();
                            r_lengthen_V();
                            break lab2;
                        }
                        cursor = limit - v_3;
                        lab4: {
                            int v_5 = limit - cursor;
                            if (!(eq_s_b("er")))
                            {
                                break lab4;
                            }
                            if (I_p1 > cursor)
                            {
                                break lab4;
                            }
                            if (!r_C())
                            {
                                break lab4;
                            }
                            cursor = limit - v_5;
                            slice_del();
                            break lab2;
                        }
                        cursor = limit - v_3;
                        if (I_p1 > cursor)
                        {
                            break lab0;
                        }
                        if (!r_C())
                        {
                            break lab0;
                        }
                        slice_from("e");
                    }
                    break;
                case 5:
                    if (I_p1 > cursor)
                    {
                        break lab0;
                    }
                    slice_from("\u00E9");
                    break;
                case 6:
                    if (I_p1 > cursor)
                    {
                        break lab0;
                    }
                    if (!r_V())
                    {
                        break lab0;
                    }
                    slice_from("au");
                    break;
                case 7:
                    lab5: {
                        int v_6 = limit - cursor;
                        lab6: {
                            if (!(eq_s_b("hed")))
                            {
                                break lab6;
                            }
                            if (I_p1 > cursor)
                            {
                                break lab6;
                            }
                            bra = cursor;
                            slice_from("heid");
                            break lab5;
                        }
                        cursor = limit - v_6;
                        lab7: {
                            if (!(eq_s_b("nd")))
                            {
                                break lab7;
                            }
                            slice_del();
                            break lab5;
                        }
                        cursor = limit - v_6;
                        lab8: {
                            if (!(eq_s_b("d")))
                            {
                                break lab8;
                            }
                            if (I_p1 > cursor)
                            {
                                break lab8;
                            }
                            if (!r_C())
                            {
                                break lab8;
                            }
                            bra = cursor;
                            slice_del();
                            break lab5;
                        }
                        cursor = limit - v_6;
                        lab9: {
                            lab10: {
                                lab11: {
                                    if (!(eq_s_b("i")))
                                    {
                                        break lab11;
                                    }
                                    break lab10;
                                }
                                if (!(eq_s_b("j")))
                                {
                                    break lab9;
                                }
                            }
                            if (!r_V())
                            {
                                break lab9;
                            }
                            slice_del();
                            break lab5;
                        }
                        cursor = limit - v_6;
                        if (I_p1 > cursor)
                        {
                            break lab0;
                        }
                        if (!r_C())
                        {
                            break lab0;
                        }
                        slice_del();
                        r_lengthen_V();
                    }
                    break;
                case 8:
                    slice_from("nd");
                    break;
            }
            B_stemmed = true;
        }
        cursor = limit - v_1;
        int v_7 = limit - cursor;
        lab12: {
            ket = cursor;
            among_var = find_among_b(a_2);
            if (among_var == 0)
            {
                break lab12;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    lab13: {
                        int v_8 = limit - cursor;
                        lab14: {
                            if (!(eq_s_b("'t")))
                            {
                                break lab14;
                            }
                            bra = cursor;
                            slice_del();
                            break lab13;
                        }
                        cursor = limit - v_8;
                        lab15: {
                            if (!(eq_s_b("et")))
                            {
                                break lab15;
                            }
                            bra = cursor;
                            if (I_p1 > cursor)
                            {
                                break lab15;
                            }
                            if (!r_C())
                            {
                                break lab15;
                            }
                            slice_del();
                            break lab13;
                        }
                        cursor = limit - v_8;
                        lab16: {
                            if (!(eq_s_b("rnt")))
                            {
                                break lab16;
                            }
                            bra = cursor;
                            slice_from("rn");
                            break lab13;
                        }
                        cursor = limit - v_8;
                        lab17: {
                            if (!(eq_s_b("t")))
                            {
                                break lab17;
                            }
                            bra = cursor;
                            if (I_p1 > cursor)
                            {
                                break lab17;
                            }
                            int v_9 = limit - cursor;
                            if (cursor <= limit_backward)
                            {
                                break lab17;
                            }
                            cursor--;
                            lab18: {
                                lab19: {
                                    if (!(in_grouping_b(g_v, 97, 252)))
                                    {
                                        break lab19;
                                    }
                                    break lab18;
                                }
                                if (!(eq_s_b("ij")))
                                {
                                    break lab17;
                                }
                            }
                            cursor = limit - v_9;
                            slice_del();
                            break lab13;
                        }
                        cursor = limit - v_8;
                        lab20: {
                            if (!(eq_s_b("ink")))
                            {
                                break lab20;
                            }
                            bra = cursor;
                            slice_from("ing");
                            break lab13;
                        }
                        cursor = limit - v_8;
                        lab21: {
                            if (!(eq_s_b("mp")))
                            {
                                break lab21;
                            }
                            bra = cursor;
                            slice_from("m");
                            break lab13;
                        }
                        cursor = limit - v_8;
                        lab22: {
                            if (!(eq_s_b("'")))
                            {
                                break lab22;
                            }
                            bra = cursor;
                            if (I_p1 > cursor)
                            {
                                break lab22;
                            }
                            slice_del();
                            break lab13;
                        }
                        cursor = limit - v_8;
                        bra = cursor;
                        if (I_p1 > cursor)
                        {
                            break lab12;
                        }
                        if (!r_C())
                        {
                            break lab12;
                        }
                        slice_del();
                    }
                    break;
                case 2:
                    if (I_p1 > cursor)
                    {
                        break lab12;
                    }
                    slice_from("g");
                    break;
                case 3:
                    if (I_p1 > cursor)
                    {
                        break lab12;
                    }
                    slice_from("lijk");
                    break;
                case 4:
                    if (I_p1 > cursor)
                    {
                        break lab12;
                    }
                    slice_from("isch");
                    break;
                case 5:
                    if (I_p1 > cursor)
                    {
                        break lab12;
                    }
                    if (!r_C())
                    {
                        break lab12;
                    }
                    slice_del();
                    break;
                case 6:
                    if (I_p1 > cursor)
                    {
                        break lab12;
                    }
                    slice_from("t");
                    break;
                case 7:
                    if (I_p1 > cursor)
                    {
                        break lab12;
                    }
                    slice_from("s");
                    break;
                case 8:
                    if (I_p1 > cursor)
                    {
                        break lab12;
                    }
                    slice_from("r");
                    break;
                case 9:
                    if (I_p1 > cursor)
                    {
                        break lab12;
                    }
                    slice_del();
                    insert(cursor, cursor, "l");
                    r_lengthen_V();
                    break;
                case 10:
                    if (I_p1 > cursor)
                    {
                        break lab12;
                    }
                    if (!r_C())
                    {
                        break lab12;
                    }
                    slice_del();
                    insert(cursor, cursor, "en");
                    r_lengthen_V();
                    break;
                case 11:
                    if (I_p1 > cursor)
                    {
                        break lab12;
                    }
                    if (!r_C())
                    {
                        break lab12;
                    }
                    slice_from("ief");
                    break;
            }
            B_stemmed = true;
        }
        cursor = limit - v_7;
        int v_10 = limit - cursor;
        lab23: {
            ket = cursor;
            among_var = find_among_b(a_3);
            if (among_var == 0)
            {
                break lab23;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    if (I_p1 > cursor)
                    {
                        break lab23;
                    }
                    slice_from("eer");
                    break;
                case 2:
                    if (I_p1 > cursor)
                    {
                        break lab23;
                    }
                    slice_del();
                    r_lengthen_V();
                    break;
                case 3:
                    if (I_p1 > cursor)
                    {
                        break lab23;
                    }
                    slice_del();
                    break;
                case 4:
                    slice_from("r");
                    break;
                case 5:
                    lab24: {
                        int v_11 = limit - cursor;
                        lab25: {
                            if (!(eq_s_b("ild")))
                            {
                                break lab25;
                            }
                            slice_from("er");
                            break lab24;
                        }
                        cursor = limit - v_11;
                        if (I_p1 > cursor)
                        {
                            break lab23;
                        }
                        slice_del();
                        r_lengthen_V();
                    }
                    break;
                case 6:
                    if (I_p1 > cursor)
                    {
                        break lab23;
                    }
                    if (!r_C())
                    {
                        break lab23;
                    }
                    slice_from("aar");
                    break;
                case 7:
                    if (I_p2 > cursor)
                    {
                        break lab23;
                    }
                    slice_del();
                    insert(cursor, cursor, "f");
                    r_lengthen_V();
                    break;
                case 8:
                    if (I_p2 > cursor)
                    {
                        break lab23;
                    }
                    slice_del();
                    insert(cursor, cursor, "g");
                    r_lengthen_V();
                    break;
                case 9:
                    if (I_p1 > cursor)
                    {
                        break lab23;
                    }
                    if (!r_C())
                    {
                        break lab23;
                    }
                    slice_from("t");
                    break;
                case 10:
                    if (I_p1 > cursor)
                    {
                        break lab23;
                    }
                    if (!r_C())
                    {
                        break lab23;
                    }
                    slice_from("d");
                    break;
            }
            B_stemmed = true;
        }
        cursor = limit - v_10;
        int v_12 = limit - cursor;
        lab26: {
            lab27: {
                int v_13 = limit - cursor;
                lab28: {
                    ket = cursor;
                    among_var = find_among_b(a_4);
                    if (among_var == 0)
                    {
                        break lab28;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            if (I_p1 > cursor)
                            {
                                break lab28;
                            }
                            slice_from("ie");
                            break;
                        case 2:
                            if (I_p1 > cursor)
                            {
                                break lab28;
                            }
                            slice_from("eer");
                            break;
                        case 3:
                            if (I_p1 > cursor)
                            {
                                break lab28;
                            }
                            slice_del();
                            break;
                        case 4:
                            if (I_p1 > cursor)
                            {
                                break lab28;
                            }
                            if (!r_V())
                            {
                                break lab28;
                            }
                            slice_from("n");
                            break;
                        case 5:
                            if (I_p1 > cursor)
                            {
                                break lab28;
                            }
                            if (!r_V())
                            {
                                break lab28;
                            }
                            slice_from("l");
                            break;
                        case 6:
                            if (I_p1 > cursor)
                            {
                                break lab28;
                            }
                            if (!r_V())
                            {
                                break lab28;
                            }
                            slice_from("r");
                            break;
                        case 7:
                            if (I_p1 > cursor)
                            {
                                break lab28;
                            }
                            slice_from("teer");
                            break;
                        case 8:
                            if (I_p1 > cursor)
                            {
                                break lab28;
                            }
                            slice_from("lijk");
                            break;
                        case 9:
                            if (I_p1 > cursor)
                            {
                                break lab28;
                            }
                            if (!r_C())
                            {
                                break lab28;
                            }
                            slice_del();
                            r_lengthen_V();
                            break;
                    }
                    break lab27;
                }
                cursor = limit - v_13;
                ket = cursor;
                if (find_among_b(a_5) == 0)
                {
                    break lab26;
                }
                bra = cursor;
                if (I_p1 > cursor)
                {
                    break lab26;
                }
                {
                    int v_14 = limit - cursor;
                    lab29: {
                        if (!(eq_s_b("inn")))
                        {
                            break lab29;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab29;
                        }
                        break lab26;
                    }
                    cursor = limit - v_14;
                }
                if (!r_C())
                {
                    break lab26;
                }
                slice_del();
                r_lengthen_V();
            }
            B_stemmed = true;
        }
        cursor = limit - v_12;
        cursor = limit_backward;
        B_GE_removed = false;
        int v_15 = cursor;
        lab30: {
            int v_16 = cursor;
            bra = cursor;
            if (!(eq_s("ge")))
            {
                break lab30;
            }
            ket = cursor;
            int v_17 = cursor;
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab30;
                }
                cursor = c;
            }
            cursor = v_17;
            int v_18 = cursor;
            golab31: while (true)
            {
                int v_19 = cursor;
                lab32: {
                    lab33: {
                        lab34: {
                            if (!(eq_s("ij")))
                            {
                                break lab34;
                            }
                            break lab33;
                        }
                        if (!(in_grouping(g_v, 97, 252)))
                        {
                            break lab32;
                        }
                    }
                    break golab31;
                }
                cursor = v_19;
                if (cursor >= limit)
                {
                    break lab30;
                }
                cursor++;
            }
            while (true)
            {
                int v_20 = cursor;
                lab35: {
                    lab36: {
                        lab37: {
                            if (!(eq_s("ij")))
                            {
                                break lab37;
                            }
                            break lab36;
                        }
                        if (!(in_grouping(g_v, 97, 252)))
                        {
                            break lab35;
                        }
                    }
                    continue;
                }
                cursor = v_20;
                break;
            }
            if (cursor >= limit)
            {
                break lab30;
            }
            cursor = v_18;
            among_var = find_among(a_9);
            switch (among_var) {
                case 1:
                    break lab30;
            }
            B_GE_removed = true;
            slice_del();
            int v_21 = cursor;
            lab38: {
                bra = cursor;
                among_var = find_among(a_10);
                if (among_var == 0)
                {
                    break lab38;
                }
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("e");
                        break;
                    case 2:
                        slice_from("i");
                        break;
                }
            }
            cursor = v_21;
            cursor = v_16;
            r_measure();
        }
        cursor = v_15;
        limit_backward = cursor;
        cursor = limit;
        int v_22 = limit - cursor;
        lab39: {
            if (!B_GE_removed)
            {
                break lab39;
            }
            B_stemmed = true;
            if (!r_Step_1c())
            {
                break lab39;
            }
        }
        cursor = limit - v_22;
        cursor = limit_backward;
        B_GE_removed = false;
        int v_23 = cursor;
        lab40: {
            int v_24 = cursor;
            if (cursor >= limit)
            {
                break lab40;
            }
            cursor++;
            golab41: while (true)
            {
                lab42: {
                    bra = cursor;
                    if (!(eq_s("ge")))
                    {
                        break lab42;
                    }
                    ket = cursor;
                    break golab41;
                }
                if (cursor >= limit)
                {
                    break lab40;
                }
                cursor++;
            }
            int v_25 = cursor;
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab40;
                }
                cursor = c;
            }
            cursor = v_25;
            int v_26 = cursor;
            golab43: while (true)
            {
                int v_27 = cursor;
                lab44: {
                    lab45: {
                        lab46: {
                            if (!(eq_s("ij")))
                            {
                                break lab46;
                            }
                            break lab45;
                        }
                        if (!(in_grouping(g_v, 97, 252)))
                        {
                            break lab44;
                        }
                    }
                    break golab43;
                }
                cursor = v_27;
                if (cursor >= limit)
                {
                    break lab40;
                }
                cursor++;
            }
            while (true)
            {
                int v_28 = cursor;
                lab47: {
                    lab48: {
                        lab49: {
                            if (!(eq_s("ij")))
                            {
                                break lab49;
                            }
                            break lab48;
                        }
                        if (!(in_grouping(g_v, 97, 252)))
                        {
                            break lab47;
                        }
                    }
                    continue;
                }
                cursor = v_28;
                break;
            }
            if (cursor >= limit)
            {
                break lab40;
            }
            cursor = v_26;
            B_GE_removed = true;
            slice_del();
            int v_29 = cursor;
            lab50: {
                bra = cursor;
                among_var = find_among(a_11);
                if (among_var == 0)
                {
                    break lab50;
                }
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("e");
                        break;
                    case 2:
                        slice_from("i");
                        break;
                }
            }
            cursor = v_29;
            cursor = v_24;
            r_measure();
        }
        cursor = v_23;
        limit_backward = cursor;
        cursor = limit;
        int v_30 = limit - cursor;
        lab51: {
            if (!B_GE_removed)
            {
                break lab51;
            }
            B_stemmed = true;
            if (!r_Step_1c())
            {
                break lab51;
            }
        }
        cursor = limit - v_30;
        cursor = limit_backward;
        limit_backward = cursor;
        cursor = limit;
        int v_31 = limit - cursor;
        lab52: {
            ket = cursor;
            among_var = find_among_b(a_6);
            if (among_var == 0)
            {
                break lab52;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_from("k");
                    break;
                case 2:
                    slice_from("f");
                    break;
                case 3:
                    slice_from("p");
                    break;
            }
            B_stemmed = true;
        }
        cursor = limit - v_31;
        int v_32 = limit - cursor;
        lab53: {
            if (!B_stemmed)
            {
                break lab53;
            }
            ket = cursor;
            among_var = find_among_b(a_7);
            if (among_var == 0)
            {
                break lab53;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_from("b");
                    break;
                case 2:
                    slice_from("c");
                    break;
                case 3:
                    slice_from("d");
                    break;
                case 4:
                    slice_from("f");
                    break;
                case 5:
                    slice_from("g");
                    break;
                case 6:
                    slice_from("h");
                    break;
                case 7:
                    slice_from("j");
                    break;
                case 8:
                    slice_from("k");
                    break;
                case 9:
                    slice_from("l");
                    break;
                case 10:
                    slice_from("m");
                    break;
                case 11:
                    {
                        int v_33 = limit - cursor;
                        lab54: {
                            if (!(eq_s_b("i")))
                            {
                                break lab54;
                            }
                            if (cursor > limit_backward)
                            {
                                break lab54;
                            }
                            break lab53;
                        }
                        cursor = limit - v_33;
                    }
                    slice_from("n");
                    break;
                case 12:
                    slice_from("p");
                    break;
                case 13:
                    slice_from("q");
                    break;
                case 14:
                    slice_from("r");
                    break;
                case 15:
                    slice_from("s");
                    break;
                case 16:
                    slice_from("t");
                    break;
                case 17:
                    slice_from("v");
                    break;
                case 18:
                    slice_from("w");
                    break;
                case 19:
                    slice_from("x");
                    break;
                case 20:
                    slice_from("z");
                    break;
            }
        }
        cursor = limit - v_32;
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof dutchStemmer;
    }

    @Override
    public int hashCode() {
        return dutchStemmer.class.getName().hashCode();
    }

}
