// Generated from finnish.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import java.util.Arrays;

import org.tartarus.snowball.Among;

import org.tartarus.snowball.CharArraySequence;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from finnish.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class finnishStemmer extends org.tartarus.snowball.SnowballStemmer {
    private static final java.lang.invoke.MethodHandles.Lookup methodObject = java.lang.invoke.MethodHandles.lookup();

    private final static Among[] a_0 = {
        new Among("pa", -1, 1),
        new Among("sti", -1, 2),
        new Among("kaan", -1, 1),
        new Among("han", -1, 1),
        new Among("kin", -1, 1),
        new Among("h\u00E4n", -1, 1),
        new Among("k\u00E4\u00E4n", -1, 1),
        new Among("ko", -1, 1),
        new Among("p\u00E4", -1, 1),
        new Among("k\u00F6", -1, 1)
    };

    private final static Among[] a_1 = {
        new Among("lla", -1, -1),
        new Among("na", -1, -1),
        new Among("ssa", -1, -1),
        new Among("ta", -1, -1),
        new Among("lta", 3, -1),
        new Among("sta", 3, -1)
    };

    private final static Among[] a_2 = {
        new Among("ll\u00E4", -1, -1),
        new Among("n\u00E4", -1, -1),
        new Among("ss\u00E4", -1, -1),
        new Among("t\u00E4", -1, -1),
        new Among("lt\u00E4", 3, -1),
        new Among("st\u00E4", 3, -1)
    };

    private final static Among[] a_3 = {
        new Among("lle", -1, -1),
        new Among("ine", -1, -1)
    };

    private final static Among[] a_4 = {
        new Among("nsa", -1, 3),
        new Among("mme", -1, 3),
        new Among("nne", -1, 3),
        new Among("ni", -1, 2),
        new Among("si", -1, 1),
        new Among("an", -1, 4),
        new Among("en", -1, 6),
        new Among("\u00E4n", -1, 5),
        new Among("ns\u00E4", -1, 3)
    };

    private final static Among[] a_5 = {
        new Among("aa", -1, -1),
        new Among("ee", -1, -1),
        new Among("ii", -1, -1),
        new Among("oo", -1, -1),
        new Among("uu", -1, -1),
        new Among("\u00E4\u00E4", -1, -1),
        new Among("\u00F6\u00F6", -1, -1)
    };

    private final static Among[] a_6 = {
        new Among("'", -1, -1),
        new Among("ai", -1, -1),
        new Among("ei", -1, -1),
        new Among("ii", -1, -1),
        new Among("oi", -1, -1),
        new Among("ui", -1, -1),
        new Among("\u00E4i", -1, -1),
        new Among("\u00F6i", -1, -1)
    };

    private final static Among[] a_7 = {
        new Among("a", -1, 2),
        new Among("lla", 0, -1),
        new Among("na", 0, -1),
        new Among("ssa", 0, -1),
        new Among("ta", 0, -1),
        new Among("lta", 4, -1),
        new Among("sta", 4, -1),
        new Among("tta", 4, 3),
        new Among("lle", -1, -1),
        new Among("ine", -1, -1),
        new Among("ksi", -1, -1),
        new Among("n", -1, 1),
        new Among("han", 11, -1, "r_A", methodObject),
        new Among("den", 11, -1, "r_VI", methodObject),
        new Among("seen", 11, -1, "r_LV", methodObject),
        new Among("hen", 11, -1, "r_E", methodObject),
        new Among("tten", 11, -1, "r_VI", methodObject),
        new Among("hin", 11, -1, "r_I", methodObject),
        new Among("siin", 11, -1, "r_VI", methodObject),
        new Among("hon", 11, -1, "r_O", methodObject),
        new Among("hun", 11, -1, "r_U", methodObject),
        new Among("h\u00E4n", 11, -1, "r_A_", methodObject),
        new Among("h\u00F6n", 11, -1, "r_O_", methodObject),
        new Among("\u00E4", -1, 2),
        new Among("ll\u00E4", 23, -1),
        new Among("n\u00E4", 23, -1),
        new Among("ss\u00E4", 23, -1),
        new Among("t\u00E4", 23, -1),
        new Among("lt\u00E4", 27, -1),
        new Among("st\u00E4", 27, -1),
        new Among("tt\u00E4", 27, 3)
    };

    private final static Among[] a_8 = {
        new Among("eja", -1, -1),
        new Among("mma", -1, 1),
        new Among("imma", 1, -1),
        new Among("mpa", -1, 1),
        new Among("impa", 3, -1),
        new Among("mmi", -1, 1),
        new Among("immi", 5, -1),
        new Among("mpi", -1, 1),
        new Among("impi", 7, -1),
        new Among("ej\u00E4", -1, -1),
        new Among("mm\u00E4", -1, 1),
        new Among("imm\u00E4", 10, -1),
        new Among("mp\u00E4", -1, 1),
        new Among("imp\u00E4", 12, -1)
    };

    private final static Among[] a_9 = {
        new Among("i", -1, -1),
        new Among("j", -1, -1)
    };

    private final static Among[] a_10 = {
        new Among("mma", -1, 1),
        new Among("imma", 0, -1)
    };

    private static final char[] g_AEI = {17, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8 };

    private static final char[] g_C = {119, 223, 119, 1 };

    private static final char[] g_v = {17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32 };

    private static final char[] g_particle_end = {17, 97, 24, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32 };

    private char[] S_x = new char[8];
    private int LS_x = 0;


    private boolean r_LV() {
        return find_among_b(a_5) != 0;
    }

    private boolean r_VI() {
        return find_among_b(a_6) != 0;
    }

    private boolean r_A() {
        lab0: {
            lab1: {
                if (!(eq_s_b("a")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
        }
        return true;
    }

    private boolean r_E() {
        lab0: {
            lab1: {
                if (!(eq_s_b("e")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
        }
        return true;
    }

    private boolean r_I() {
        lab0: {
            lab1: {
                if (!(eq_s_b("i")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
        }
        return true;
    }

    private boolean r_O() {
        lab0: {
            lab1: {
                if (!(eq_s_b("o")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
        }
        return true;
    }

    private boolean r_U() {
        lab0: {
            lab1: {
                if (!(eq_s_b("u")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
        }
        return true;
    }

    private boolean r_A_() {
        lab0: {
            lab1: {
                if (!(eq_s_b("\u00E4")))
                {
                    break lab1;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
        }
        return true;
    }

    private boolean r_O_() {
        lab0: {
            lab1: {
                if (!(eq_s_b("\u00F6")))
                {
                    break lab1;
                }
                break lab0;
            }
            lab2: {
                if (!(eq_s_b("\u00F8")))
                {
                    break lab2;
                }
                break lab0;
            }
            if (!(eq_s_b("'")))
            {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean stem() {
        int among_var;
        boolean B_ending_removed;
        int I_p2;
        int I_p1;
        int v_1 = cursor;
        lab0: {
            I_p1 = limit;
            I_p2 = limit;
            if (!go_out_grouping(g_v, 97, 246))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 246))
            {
                break lab0;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 246))
            {
                break lab0;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 246))
            {
                break lab0;
            }
            cursor++;
            I_p2 = cursor;
        }
        cursor = v_1;
        B_ending_removed = false;
        limit_backward = cursor;
        cursor = limit;
        int v_2 = limit - cursor;
        lab1: {
            if (cursor < I_p1)
            {
                break lab1;
            }
            int v_3 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            among_var = find_among_b(a_0);
            if (among_var == 0)
            {
                limit_backward = v_3;
                break lab1;
            }
            bra = cursor;
            limit_backward = v_3;
            switch (among_var) {
                case 1:
                    if (!(in_grouping_b(g_particle_end, 97, 246)))
                    {
                        break lab1;
                    }
                    break;
                case 2:
                    if (I_p2 > cursor)
                    {
                        break lab1;
                    }
                    break;
            }
            slice_del();
        }
        cursor = limit - v_2;
        int v_4 = limit - cursor;
        lab2: {
            if (cursor < I_p1)
            {
                break lab2;
            }
            int v_5 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            among_var = find_among_b(a_4);
            if (among_var == 0)
            {
                limit_backward = v_5;
                break lab2;
            }
            bra = cursor;
            limit_backward = v_5;
            switch (among_var) {
                case 1:
                    lab3: {
                        if (!(eq_s_b("k")))
                        {
                            break lab3;
                        }
                        break lab2;
                    }
                    slice_del();
                    break;
                case 2:
                    slice_del();
                    ket = cursor;
                    if (!(eq_s_b("kse")))
                    {
                        break lab2;
                    }
                    bra = cursor;
                    slice_from("ksi");
                    break;
                case 3:
                    slice_del();
                    break;
                case 4:
                    if (find_among_b(a_1) == 0)
                    {
                        break lab2;
                    }
                    slice_del();
                    break;
                case 5:
                    if (find_among_b(a_2) == 0)
                    {
                        break lab2;
                    }
                    slice_del();
                    break;
                case 6:
                    if (find_among_b(a_3) == 0)
                    {
                        break lab2;
                    }
                    slice_del();
                    break;
            }
        }
        cursor = limit - v_4;
        int v_6 = limit - cursor;
        lab4: {
            if (cursor < I_p1)
            {
                break lab4;
            }
            int v_7 = limit_backward;
            limit_backward = I_p1;
            ket = cursor;
            among_var = find_among_b(a_7);
            if (among_var == 0)
            {
                limit_backward = v_7;
                break lab4;
            }
            bra = cursor;
            limit_backward = v_7;
            switch (among_var) {
                case 1:
                    int v_8 = limit - cursor;
                    lab5: {
                        int v_9 = limit - cursor;
                        lab6: {
                            int v_10 = limit - cursor;
                            lab7: {
                                if (!r_LV())
                                {
                                    break lab7;
                                }
                                break lab6;
                            }
                            cursor = limit - v_10;
                            if (!(eq_s_b("ie")))
                            {
                                cursor = limit - v_8;
                                break lab5;
                            }
                        }
                        cursor = limit - v_9;
                        if (cursor <= limit_backward)
                        {
                            cursor = limit - v_8;
                            break lab5;
                        }
                        cursor--;
                        bra = cursor;
                    }
                    break;
                case 2:
                    if (!(in_grouping_b(g_v, 97, 246)))
                    {
                        break lab4;
                    }
                    if (!(in_grouping_b(g_C, 98, 122)))
                    {
                        break lab4;
                    }
                    break;
                case 3:
                    if (!(eq_s_b("e")))
                    {
                        break lab4;
                    }
                    break;
            }
            slice_del();
            B_ending_removed = true;
        }
        cursor = limit - v_6;
        int v_11 = limit - cursor;
        lab8: {
            if (cursor < I_p2)
            {
                break lab8;
            }
            int v_12 = limit_backward;
            limit_backward = I_p2;
            ket = cursor;
            among_var = find_among_b(a_8);
            if (among_var == 0)
            {
                limit_backward = v_12;
                break lab8;
            }
            bra = cursor;
            limit_backward = v_12;
            switch (among_var) {
                case 1:
                    lab9: {
                        if (!(eq_s_b("po")))
                        {
                            break lab9;
                        }
                        break lab8;
                    }
                    break;
            }
            slice_del();
        }
        cursor = limit - v_11;
        lab10: {
            lab11: {
                if (!B_ending_removed)
                {
                    break lab11;
                }
                int v_13 = limit - cursor;
                lab12: {
                    if (cursor < I_p1)
                    {
                        break lab12;
                    }
                    int v_14 = limit_backward;
                    limit_backward = I_p1;
                    ket = cursor;
                    if (find_among_b(a_9) == 0)
                    {
                        limit_backward = v_14;
                        break lab12;
                    }
                    bra = cursor;
                    limit_backward = v_14;
                    slice_del();
                }
                cursor = limit - v_13;
                break lab10;
            }
            int v_15 = limit - cursor;
            lab13: {
                if (cursor < I_p1)
                {
                    break lab13;
                }
                int v_16 = limit_backward;
                limit_backward = I_p1;
                ket = cursor;
                if (!(eq_s_b("t")))
                {
                    limit_backward = v_16;
                    break lab13;
                }
                bra = cursor;
                int v_17 = limit - cursor;
                if (!(in_grouping_b(g_v, 97, 246)))
                {
                    limit_backward = v_16;
                    break lab13;
                }
                cursor = limit - v_17;
                slice_del();
                limit_backward = v_16;
                if (cursor < I_p2)
                {
                    break lab13;
                }
                int v_18 = limit_backward;
                limit_backward = I_p2;
                ket = cursor;
                among_var = find_among_b(a_10);
                if (among_var == 0)
                {
                    limit_backward = v_18;
                    break lab13;
                }
                bra = cursor;
                limit_backward = v_18;
                switch (among_var) {
                    case 1:
                        lab14: {
                            if (!(eq_s_b("po")))
                            {
                                break lab14;
                            }
                            break lab13;
                        }
                        break;
                }
                slice_del();
            }
            cursor = limit - v_15;
        }
        int v_19 = limit - cursor;
        lab15: {
            if (cursor < I_p1)
            {
                break lab15;
            }
            int v_20 = limit_backward;
            limit_backward = I_p1;
            int v_21 = limit - cursor;
            lab16: {
                int v_22 = limit - cursor;
                if (!r_LV())
                {
                    break lab16;
                }
                cursor = limit - v_22;
                ket = cursor;
                if (cursor <= limit_backward)
                {
                    break lab16;
                }
                cursor--;
                bra = cursor;
                slice_del();
            }
            cursor = limit - v_21;
            int v_23 = limit - cursor;
            lab17: {
                ket = cursor;
                if (!(in_grouping_b(g_AEI, 97, 228)))
                {
                    break lab17;
                }
                bra = cursor;
                if (!(in_grouping_b(g_C, 98, 122)))
                {
                    break lab17;
                }
                slice_del();
            }
            cursor = limit - v_23;
            int v_24 = limit - cursor;
            lab18: {
                ket = cursor;
                if (!(eq_s_b("j")))
                {
                    break lab18;
                }
                bra = cursor;
                lab19: {
                    lab20: {
                        if (!(eq_s_b("o")))
                        {
                            break lab20;
                        }
                        break lab19;
                    }
                    if (!(eq_s_b("u")))
                    {
                        break lab18;
                    }
                }
                slice_del();
            }
            cursor = limit - v_24;
            int v_25 = limit - cursor;
            lab21: {
                ket = cursor;
                if (!(eq_s_b("o")))
                {
                    break lab21;
                }
                bra = cursor;
                if (!(eq_s_b("j")))
                {
                    break lab21;
                }
                slice_del();
            }
            cursor = limit - v_25;
            limit_backward = v_20;
            int v_26 = limit - cursor;
            lab22: {
                if (!go_in_grouping_b(g_v, 97, 246))
                {
                    break lab22;
                }
                ket = cursor;
                if (!(in_grouping_b(g_C, 98, 122)))
                {
                    break lab22;
                }
                bra = cursor;
                slice_check();
                if (S_x.length < ket - bra) {
                    S_x = Arrays.copyOfRange(current, bra, ket);
                } else {
                    System.arraycopy(current, bra, S_x, 0, ket - bra);
                }
                LS_x = ket - bra;
                if (!(eq_s_b(new CharArraySequence(S_x, LS_x))))
                {
                    break lab22;
                }
                slice_del();
            }
            cursor = limit - v_26;
            ket = cursor;
            if (!(eq_s_b("'")))
            {
                break lab15;
            }
            bra = cursor;
            slice_del();
        }
        cursor = limit - v_19;
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof finnishStemmer;
    }

    @Override
    public int hashCode() {
        return finnishStemmer.class.getName().hashCode();
    }

}
