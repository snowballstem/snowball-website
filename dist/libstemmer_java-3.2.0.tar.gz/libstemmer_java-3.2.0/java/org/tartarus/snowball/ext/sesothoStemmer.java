// Generated from sesotho.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from sesotho.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class sesothoStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("ba", -1, -1),
        new Among("boi", -1, -1),
        new Among("le", -1, -1),
        new Among("li", -1, -1),
        new Among("ma", -1, -1),
        new Among("me", -1, -1),
        new Among("mo", -1, -1),
        new Among("se", -1, -1)
    };

    private final static Among[] a_1 = {
        new Among("a", -1, 1),
        new Among("ela", 0, 1),
        new Among("isa", 0, 1),
        new Among("wa", 0, 1),
        new Among("ile", -1, 1),
        new Among("etse", -1, 1),
        new Among("ang", -1, 1),
        new Among("eng", -1, 1),
        new Among("ong", -1, 1)
    };

    private final static Among[] a_2 = {
        new Among("ana", -1, 1),
        new Among("nyana", 0, 1),
        new Among("oa", -1, 1),
        new Among("i", -1, 1),
        new Among("ano", -1, 1)
    };

    private static final char[] g_v = {17, 65, 16 };


    @Override
    public boolean stem() {
        int I_pV;
        int v_1 = cursor;
        if (!go_out_grouping(g_v, 97, 117))
        {
            return false;
        }
        cursor++;
        I_pV = cursor;
        cursor = v_1;
        int v_2 = cursor;
        {
            int c = cursor + 2;
            if (c > limit)
            {
                return false;
            }
            cursor = c;
        }
        lab0: {
            if (cursor <= I_pV)
            {
                break lab0;
            }
            I_pV = cursor;
        }
        cursor = v_2;
        limit_backward = cursor;
        cursor = limit;
        int v_3 = limit - cursor;
        lab1: {
            if (cursor < I_pV)
            {
                break lab1;
            }
            int v_4 = limit_backward;
            limit_backward = I_pV;
            ket = cursor;
            if (find_among_b(a_2) == 0)
            {
                limit_backward = v_4;
                break lab1;
            }
            bra = cursor;
            slice_del();
            limit_backward = v_4;
        }
        cursor = limit - v_3;
        int v_5 = limit - cursor;
        lab2: {
            if (cursor < I_pV)
            {
                break lab2;
            }
            int v_6 = limit_backward;
            limit_backward = I_pV;
            ket = cursor;
            if (find_among_b(a_1) == 0)
            {
                limit_backward = v_6;
                break lab2;
            }
            bra = cursor;
            slice_del();
            limit_backward = v_6;
        }
        cursor = limit - v_5;
        cursor = limit_backward;
        int v_7 = cursor;
        lab3: {
            bra = cursor;
            if (find_among(a_0) == 0)
            {
                break lab3;
            }
            ket = cursor;
            int v_8 = cursor;
            if (cursor >= limit)
            {
                break lab3;
            }
            cursor++;
            if (cursor >= limit)
            {
                break lab3;
            }
            cursor = v_8;
            if (!go_out_grouping(g_v, 97, 117))
            {
                break lab3;
            }
            cursor++;
            slice_del();
        }
        cursor = v_7;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof sesothoStemmer;
    }

    @Override
    public int hashCode() {
        return sesothoStemmer.class.getName().hashCode();
    }

}
