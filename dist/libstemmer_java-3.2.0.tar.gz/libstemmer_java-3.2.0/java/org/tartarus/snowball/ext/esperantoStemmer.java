// Generated from esperanto.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from esperanto.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class esperantoStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("", -1, 14),
        new Among("-", 0, 13),
        new Among("cx", 0, 1),
        new Among("gx", 0, 2),
        new Among("hx", 0, 3),
        new Among("jx", 0, 4),
        new Among("q", 0, 12),
        new Among("sx", 0, 5),
        new Among("ux", 0, 6),
        new Among("w", 0, 12),
        new Among("x", 0, 12),
        new Among("y", 0, 12),
        new Among("\u00E1", 0, 7),
        new Among("\u00E9", 0, 8),
        new Among("\u00ED", 0, 9),
        new Among("\u00F3", 0, 10),
        new Among("\u00FA", 0, 11)
    };

    private final static Among[] a_1 = {
        new Among("as", -1, -1),
        new Among("i", -1, -1),
        new Among("is", 1, -1),
        new Among("os", -1, -1),
        new Among("u", -1, -1),
        new Among("us", 4, -1)
    };

    private final static Among[] a_2 = {
        new Among("ci", -1, -1),
        new Among("gi", -1, -1),
        new Among("hi", -1, -1),
        new Among("li", -1, -1),
        new Among("ili", 3, -1),
        new Among("\u015Dli", 3, -1),
        new Among("mi", -1, -1),
        new Among("ni", -1, -1),
        new Among("oni", 7, -1),
        new Among("ri", -1, -1),
        new Among("si", -1, -1),
        new Among("vi", -1, -1),
        new Among("ivi", 11, -1),
        new Among("\u011Di", -1, -1),
        new Among("\u015Di", -1, -1),
        new Among("i\u015Di", 14, -1),
        new Among("mal\u015Di", 14, -1)
    };

    private final static Among[] a_3 = {
        new Among("amb", -1, -1),
        new Among("bald", -1, -1),
        new Among("malbald", 1, -1),
        new Among("morg", -1, -1),
        new Among("postmorg", 3, -1),
        new Among("adi", -1, -1),
        new Among("hodi", -1, -1),
        new Among("ank", -1, -1),
        new Among("\u0109irk", -1, -1),
        new Among("tut\u0109irk", 8, -1),
        new Among("presk", -1, -1),
        new Among("almen", -1, -1),
        new Among("apen", -1, -1),
        new Among("hier", -1, -1),
        new Among("anta\u016Dhier", 13, -1),
        new Among("malgr", -1, -1),
        new Among("ankor", -1, -1),
        new Among("kontr", -1, -1),
        new Among("anstat", -1, -1),
        new Among("kvaz", -1, -1)
    };

    private final static Among[] a_4 = {
        new Among("aliu", -1, -1),
        new Among("unu", -1, -1)
    };

    private final static Among[] a_5 = {
        new Among("aha", -1, -1),
        new Among("haha", 0, -1),
        new Among("haleluja", -1, -1),
        new Among("hola", -1, -1),
        new Among("hosana", -1, -1),
        new Among("maltra", -1, -1),
        new Among("hura", -1, -1),
        new Among("\u0125a\u0125a", -1, -1),
        new Among("ekde", -1, -1),
        new Among("elde", -1, -1),
        new Among("disde", -1, -1),
        new Among("ehe", -1, -1),
        new Among("maltre", -1, -1),
        new Among("dirlididi", -1, -1),
        new Among("malpli", -1, -1),
        new Among("mal\u0109i", -1, -1),
        new Among("malkaj", -1, -1),
        new Among("amen", -1, -1),
        new Among("tamen", 17, -1),
        new Among("oho", -1, -1),
        new Among("maltro", -1, -1),
        new Among("minus", -1, -1),
        new Among("uhu", -1, -1),
        new Among("muu", -1, -1)
    };

    private final static Among[] a_6 = {
        new Among("tri", -1, -1),
        new Among("du", -1, -1),
        new Among("unu", -1, -1)
    };

    private final static Among[] a_7 = {
        new Among("dek", -1, -1),
        new Among("cent", -1, -1)
    };

    private final static Among[] a_8 = {
        new Among("k", -1, -1),
        new Among("kelk", 0, -1),
        new Among("nen", -1, -1),
        new Among("t", -1, -1),
        new Among("mult", 3, -1),
        new Among("samt", 3, -1),
        new Among("\u0109", -1, -1)
    };

    private final static Among[] a_9 = {
        new Among("a", -1, -1),
        new Among("e", -1, -1),
        new Among("i", -1, -1),
        new Among("j", -1, 1),
        new Among("aj", 3, -1),
        new Among("oj", 3, -1),
        new Among("n", -1, 1),
        new Among("an", 6, -1),
        new Among("en", 6, -1),
        new Among("jn", 6, 1),
        new Among("ajn", 9, -1),
        new Among("ojn", 9, -1),
        new Among("on", 6, -1),
        new Among("o", -1, -1),
        new Among("as", -1, -1),
        new Among("is", -1, -1),
        new Among("os", -1, -1),
        new Among("us", -1, -1),
        new Among("u", -1, -1)
    };

    private static final char[] g_vowel = {17, 65, 16 };

    private static final char[] g_aou = {1, 64, 16 };

    private static final char[] g_digit = {255, 3 };


    @Override
    public boolean stem() {
        int among_var;
        boolean B_foreign;
        int v_1 = cursor;
        B_foreign = false;
        while (true)
        {
            int v_2 = cursor;
            lab0: {
                bra = cursor;
                among_var = find_among(a_0);
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("\u0109");
                        break;
                    case 2:
                        slice_from("\u011D");
                        break;
                    case 3:
                        slice_from("\u0125");
                        break;
                    case 4:
                        slice_from("\u0135");
                        break;
                    case 5:
                        slice_from("\u015D");
                        break;
                    case 6:
                        slice_from("\u016D");
                        break;
                    case 7:
                        slice_from("a");
                        B_foreign = true;
                        break;
                    case 8:
                        slice_from("e");
                        B_foreign = true;
                        break;
                    case 9:
                        slice_from("i");
                        B_foreign = true;
                        break;
                    case 10:
                        slice_from("o");
                        B_foreign = true;
                        break;
                    case 11:
                        slice_from("u");
                        B_foreign = true;
                        break;
                    case 12:
                        B_foreign = true;
                        break;
                    case 13:
                        B_foreign = false;
                        break;
                    case 14:
                        if (cursor >= limit)
                        {
                            break lab0;
                        }
                        cursor++;
                        break;
                }
                continue;
            }
            cursor = v_2;
            break;
        }
        if (B_foreign)
        {
            return false;
        }
        cursor = v_1;
        int v_3 = cursor;
        lab1: {
            bra = cursor;
            if (!(eq_s("'")))
            {
                break lab1;
            }
            ket = cursor;
            if (!(eq_s("st")))
            {
                break lab1;
            }
            if (find_among(a_1) == 0)
            {
                break lab1;
            }
            if (cursor < limit)
            {
                break lab1;
            }
            slice_from("e");
        }
        cursor = v_3;
        limit_backward = cursor;
        cursor = limit;
        {
            int v_4 = limit - cursor;
            lab2: {
                ket = cursor;
                int v_5 = limit - cursor;
                lab3: {
                    if (!(eq_s_b("n")))
                    {
                        cursor = limit - v_5;
                        break lab3;
                    }
                }
                bra = cursor;
                if (find_among_b(a_2) == 0)
                {
                    break lab2;
                }
                lab4: {
                    lab5: {
                        if (cursor > limit_backward)
                        {
                            break lab5;
                        }
                        break lab4;
                    }
                    if (!(eq_s_b("-")))
                    {
                        break lab2;
                    }
                }
                slice_del();
                return false;
            }
            cursor = limit - v_4;
        }
        int v_6 = limit - cursor;
        lab6: {
            ket = cursor;
            if (!(eq_s_b("'")))
            {
                break lab6;
            }
            bra = cursor;
            lab7: {
                int v_7 = limit - cursor;
                lab8: {
                    if (!(eq_s_b("l")))
                    {
                        break lab8;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab8;
                    }
                    slice_from("a");
                    break lab7;
                }
                cursor = limit - v_7;
                lab9: {
                    if (!(eq_s_b("un")))
                    {
                        break lab9;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab9;
                    }
                    slice_from("u");
                    break lab7;
                }
                cursor = limit - v_7;
                lab10: {
                    if (find_among_b(a_3) == 0)
                    {
                        break lab10;
                    }
                    lab11: {
                        lab12: {
                            if (cursor > limit_backward)
                            {
                                break lab12;
                            }
                            break lab11;
                        }
                        if (!(eq_s_b("-")))
                        {
                            break lab10;
                        }
                    }
                    slice_from("a\u016D");
                    break lab7;
                }
                cursor = limit - v_7;
                slice_from("o");
            }
        }
        cursor = limit - v_6;
        {
            int v_8 = limit - cursor;
            lab13: {
                ket = cursor;
                bra = cursor;
                int v_9 = limit - cursor;
                lab14: {
                    int v_10 = limit - cursor;
                    lab15: {
                        int v_11 = limit - cursor;
                        lab16: {
                            if (!(eq_s_b("n")))
                            {
                                cursor = limit - v_11;
                                break lab16;
                            }
                        }
                        bra = cursor;
                        if (!(eq_s_b("e")))
                        {
                            break lab15;
                        }
                        break lab14;
                    }
                    cursor = limit - v_10;
                    int v_12 = limit - cursor;
                    lab17: {
                        if (!(eq_s_b("n")))
                        {
                            cursor = limit - v_12;
                            break lab17;
                        }
                    }
                    int v_13 = limit - cursor;
                    lab18: {
                        if (!(eq_s_b("j")))
                        {
                            cursor = limit - v_13;
                            break lab18;
                        }
                    }
                    bra = cursor;
                    if (!(in_grouping_b(g_aou, 97, 117)))
                    {
                        break lab13;
                    }
                }
                if (!(eq_s_b("i")))
                {
                    break lab13;
                }
                int v_14 = limit - cursor;
                lab19: {
                    if (find_among_b(a_8) == 0)
                    {
                        cursor = limit - v_14;
                        break lab19;
                    }
                }
                lab20: {
                    lab21: {
                        if (cursor > limit_backward)
                        {
                            break lab21;
                        }
                        break lab20;
                    }
                    if (!(eq_s_b("-")))
                    {
                        break lab13;
                    }
                }
                cursor = limit - v_9;
                slice_del();
                return false;
            }
            cursor = limit - v_8;
        }
        {
            int v_15 = limit - cursor;
            lab22: {
                if (find_among_b(a_5) == 0)
                {
                    break lab22;
                }
                lab23: {
                    lab24: {
                        if (cursor > limit_backward)
                        {
                            break lab24;
                        }
                        break lab23;
                    }
                    if (!(eq_s_b("-")))
                    {
                        break lab22;
                    }
                }
                return false;
            }
            cursor = limit - v_15;
        }
        {
            int v_16 = limit - cursor;
            lab25: {
                if (find_among_b(a_6) == 0)
                {
                    break lab25;
                }
                if (find_among_b(a_7) == 0)
                {
                    break lab25;
                }
                return false;
            }
            cursor = limit - v_16;
        }
        {
            int v_17 = limit - cursor;
            lab26: {
                ket = cursor;
                int v_18 = limit - cursor;
                lab27: {
                    if (!(eq_s_b("n")))
                    {
                        cursor = limit - v_18;
                        break lab27;
                    }
                }
                int v_19 = limit - cursor;
                lab28: {
                    if (!(eq_s_b("j")))
                    {
                        cursor = limit - v_19;
                        break lab28;
                    }
                }
                bra = cursor;
                if (find_among_b(a_4) == 0)
                {
                    break lab26;
                }
                lab29: {
                    lab30: {
                        if (cursor > limit_backward)
                        {
                            break lab30;
                        }
                        break lab29;
                    }
                    if (!(eq_s_b("-")))
                    {
                        break lab26;
                    }
                }
                slice_del();
                return false;
            }
            cursor = limit - v_17;
        }
        int v_20 = limit - cursor;
        lab31: {
            int v_21 = limit - cursor;
            lab32: {
                for (int v_22 = 2; v_22 > 0; v_22--)
                {
                    if (!go_out_grouping_b(g_vowel, 97, 117))
                    {
                        break lab32;
                    }
                    cursor--;
                }
                break lab31;
            }
            cursor = limit - v_21;
            lab33: {
                golab34: while (true)
                {
                    lab35: {
                        if (!(eq_s_b("-")))
                        {
                            break lab35;
                        }
                        break golab34;
                    }
                    if (cursor <= limit_backward)
                    {
                        break lab33;
                    }
                    cursor--;
                }
                if (cursor <= limit_backward)
                {
                    break lab33;
                }
                cursor--;
                break lab31;
            }
            cursor = limit - v_21;
            if (!go_out_grouping_b(g_digit, 48, 57))
            {
                return false;
            }
            cursor--;
        }
        cursor = limit - v_20;
        ket = cursor;
        among_var = find_among_b(a_9);
        if (among_var == 0)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                int v_23 = limit - cursor;
                lab36: {
                    lab37: {
                        if (!(eq_s_b("-")))
                        {
                            break lab37;
                        }
                        break lab36;
                    }
                    if (!(in_grouping_b(g_digit, 48, 57)))
                    {
                        return false;
                    }
                }
                cursor = limit - v_23;
                break;
        }
        int v_24 = limit - cursor;
        lab38: {
            if (!(eq_s_b("-")))
            {
                cursor = limit - v_24;
                break lab38;
            }
        }
        bra = cursor;
        slice_del();
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof esperantoStemmer;
    }

    @Override
    public int hashCode() {
        return esperantoStemmer.class.getName().hashCode();
    }

}
