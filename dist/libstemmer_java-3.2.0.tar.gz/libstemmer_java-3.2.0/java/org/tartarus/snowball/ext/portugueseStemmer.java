// Generated from portuguese.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from portuguese.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class portugueseStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("", -1, 3),
        new Among("\u00E3", 0, 1),
        new Among("\u00F5", 0, 2)
    };

    private final static Among[] a_1 = {
        new Among("", -1, 3),
        new Among("a~", 0, 1),
        new Among("o~", 0, 2)
    };

    private final static Among[] a_2 = {
        new Among("ic", -1, -1),
        new Among("ad", -1, -1),
        new Among("os", -1, -1),
        new Among("iv", -1, 1)
    };

    private final static Among[] a_3 = {
        new Among("ante", -1, 1),
        new Among("avel", -1, 1),
        new Among("\u00EDvel", -1, 1)
    };

    private final static Among[] a_4 = {
        new Among("ic", -1, 1),
        new Among("abil", -1, 1),
        new Among("iv", -1, 1)
    };

    private final static Among[] a_5 = {
        new Among("ica", -1, 1),
        new Among("\u00E2ncia", -1, 1),
        new Among("\u00EAncia", -1, 4),
        new Among("logia", -1, 2),
        new Among("ira", -1, 9),
        new Among("adora", -1, 1),
        new Among("osa", -1, 1),
        new Among("ista", -1, 1),
        new Among("iva", -1, 8),
        new Among("eza", -1, 1),
        new Among("idade", -1, 7),
        new Among("ante", -1, 1),
        new Among("mente", -1, 6),
        new Among("amente", 12, 5),
        new Among("\u00E1vel", -1, 1),
        new Among("\u00EDvel", -1, 1),
        new Among("ico", -1, 1),
        new Among("ismo", -1, 1),
        new Among("oso", -1, 1),
        new Among("amento", -1, 1),
        new Among("imento", -1, 1),
        new Among("ivo", -1, 8),
        new Among("a\u00E7a~o", -1, 1),
        new Among("u\u00E7a~o", -1, 3),
        new Among("ador", -1, 1),
        new Among("icas", -1, 1),
        new Among("\u00EAncias", -1, 4),
        new Among("logias", -1, 2),
        new Among("iras", -1, 9),
        new Among("adoras", -1, 1),
        new Among("osas", -1, 1),
        new Among("istas", -1, 1),
        new Among("ivas", -1, 8),
        new Among("ezas", -1, 1),
        new Among("idades", -1, 7),
        new Among("adores", -1, 1),
        new Among("antes", -1, 1),
        new Among("a\u00E7o~es", -1, 1),
        new Among("u\u00E7o~es", -1, 3),
        new Among("icos", -1, 1),
        new Among("ismos", -1, 1),
        new Among("osos", -1, 1),
        new Among("amentos", -1, 1),
        new Among("imentos", -1, 1),
        new Among("ivos", -1, 8)
    };

    private final static Among[] a_6 = {
        new Among("ada", -1, 1),
        new Among("ida", -1, 1),
        new Among("ia", -1, 1),
        new Among("aria", 2, 1),
        new Among("eria", 2, 1),
        new Among("iria", 2, 1),
        new Among("ara", -1, 1),
        new Among("era", -1, 1),
        new Among("ira", -1, 1),
        new Among("ava", -1, 1),
        new Among("asse", -1, 1),
        new Among("esse", -1, 1),
        new Among("isse", -1, 1),
        new Among("aste", -1, 1),
        new Among("este", -1, 1),
        new Among("iste", -1, 1),
        new Among("ei", -1, 1),
        new Among("arei", 16, 1),
        new Among("erei", 16, 1),
        new Among("irei", 16, 1),
        new Among("am", -1, 1),
        new Among("iam", 20, 1),
        new Among("ariam", 21, 1),
        new Among("eriam", 21, 1),
        new Among("iriam", 21, 1),
        new Among("aram", 20, 1),
        new Among("eram", 20, 1),
        new Among("iram", 20, 1),
        new Among("avam", 20, 1),
        new Among("em", -1, 1),
        new Among("arem", 29, 1),
        new Among("erem", 29, 1),
        new Among("irem", 29, 1),
        new Among("assem", 29, 1),
        new Among("essem", 29, 1),
        new Among("issem", 29, 1),
        new Among("ado", -1, 1),
        new Among("ido", -1, 1),
        new Among("ando", -1, 1),
        new Among("endo", -1, 1),
        new Among("indo", -1, 1),
        new Among("ara~o", -1, 1),
        new Among("era~o", -1, 1),
        new Among("ira~o", -1, 1),
        new Among("ar", -1, 1),
        new Among("er", -1, 1),
        new Among("ir", -1, 1),
        new Among("as", -1, 1),
        new Among("adas", 47, 1),
        new Among("idas", 47, 1),
        new Among("ias", 47, 1),
        new Among("arias", 50, 1),
        new Among("erias", 50, 1),
        new Among("irias", 50, 1),
        new Among("aras", 47, 1),
        new Among("eras", 47, 1),
        new Among("iras", 47, 1),
        new Among("avas", 47, 1),
        new Among("es", -1, 1),
        new Among("ardes", 58, 1),
        new Among("erdes", 58, 1),
        new Among("irdes", 58, 1),
        new Among("ares", 58, 1),
        new Among("eres", 58, 1),
        new Among("ires", 58, 1),
        new Among("asses", 58, 1),
        new Among("esses", 58, 1),
        new Among("isses", 58, 1),
        new Among("astes", 58, 1),
        new Among("estes", 58, 1),
        new Among("istes", 58, 1),
        new Among("is", -1, 1),
        new Among("ais", 71, 1),
        new Among("eis", 71, 1),
        new Among("areis", 73, 1),
        new Among("ereis", 73, 1),
        new Among("ireis", 73, 1),
        new Among("\u00E1reis", 73, 1),
        new Among("\u00E9reis", 73, 1),
        new Among("\u00EDreis", 73, 1),
        new Among("\u00E1sseis", 73, 1),
        new Among("\u00E9sseis", 73, 1),
        new Among("\u00EDsseis", 73, 1),
        new Among("\u00E1veis", 73, 1),
        new Among("\u00EDeis", 73, 1),
        new Among("ar\u00EDeis", 84, 1),
        new Among("er\u00EDeis", 84, 1),
        new Among("ir\u00EDeis", 84, 1),
        new Among("ados", -1, 1),
        new Among("idos", -1, 1),
        new Among("amos", -1, 1),
        new Among("\u00E1ramos", 90, 1),
        new Among("\u00E9ramos", 90, 1),
        new Among("\u00EDramos", 90, 1),
        new Among("\u00E1vamos", 90, 1),
        new Among("\u00EDamos", 90, 1),
        new Among("ar\u00EDamos", 95, 1),
        new Among("er\u00EDamos", 95, 1),
        new Among("ir\u00EDamos", 95, 1),
        new Among("emos", -1, 1),
        new Among("aremos", 99, 1),
        new Among("eremos", 99, 1),
        new Among("iremos", 99, 1),
        new Among("\u00E1ssemos", 99, 1),
        new Among("\u00EAssemos", 99, 1),
        new Among("\u00EDssemos", 99, 1),
        new Among("imos", -1, 1),
        new Among("armos", -1, 1),
        new Among("ermos", -1, 1),
        new Among("irmos", -1, 1),
        new Among("\u00E1mos", -1, 1),
        new Among("ar\u00E1s", -1, 1),
        new Among("er\u00E1s", -1, 1),
        new Among("ir\u00E1s", -1, 1),
        new Among("eu", -1, 1),
        new Among("iu", -1, 1),
        new Among("ou", -1, 1),
        new Among("ar\u00E1", -1, 1),
        new Among("er\u00E1", -1, 1),
        new Among("ir\u00E1", -1, 1)
    };

    private final static Among[] a_7 = {
        new Among("a", -1, 1),
        new Among("i", -1, 1),
        new Among("o", -1, 1),
        new Among("os", -1, 1),
        new Among("\u00E1", -1, 1),
        new Among("\u00ED", -1, 1),
        new Among("\u00F3", -1, 1)
    };

    private final static Among[] a_8 = {
        new Among("e", -1, 1),
        new Among("\u00E7", -1, 2),
        new Among("\u00E9", -1, 1),
        new Among("\u00EA", -1, 1)
    };

    private static final char[] g_v = {17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 19, 12, 2 };


    @Override
    public boolean stem() {
        int among_var;
        int I_p2;
        int I_p1;
        int I_pV;
        int v_1 = cursor;
        lab0: {
            while (true)
            {
                int v_2 = cursor;
                lab1: {
                    bra = cursor;
                    among_var = find_among(a_0);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("a~");
                            break;
                        case 2:
                            slice_from("o~");
                            break;
                        case 3:
                            if (cursor >= limit)
                            {
                                break lab1;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_2;
                break;
            }
        }
        cursor = v_1;
        lab2: {
            I_pV = limit;
            I_p1 = limit;
            I_p2 = limit;
            int v_3 = cursor;
            lab3: {
                lab4: {
                    int v_4 = cursor;
                    lab5: {
                        if (!(in_grouping(g_v, 97, 250)))
                        {
                            break lab5;
                        }
                        lab6: {
                            int v_5 = cursor;
                            lab7: {
                                if (!(out_grouping(g_v, 97, 250)))
                                {
                                    break lab7;
                                }
                                if (!go_out_grouping(g_v, 97, 250))
                                {
                                    break lab7;
                                }
                                cursor++;
                                break lab6;
                            }
                            cursor = v_5;
                            if (!(in_grouping(g_v, 97, 250)))
                            {
                                break lab5;
                            }
                            if (!go_in_grouping(g_v, 97, 250))
                            {
                                break lab5;
                            }
                            cursor++;
                        }
                        break lab4;
                    }
                    cursor = v_4;
                    if (!(out_grouping(g_v, 97, 250)))
                    {
                        break lab3;
                    }
                    lab8: {
                        int v_6 = cursor;
                        lab9: {
                            if (!(out_grouping(g_v, 97, 250)))
                            {
                                break lab9;
                            }
                            if (!go_out_grouping(g_v, 97, 250))
                            {
                                break lab9;
                            }
                            cursor++;
                            break lab8;
                        }
                        cursor = v_6;
                        if (!(in_grouping(g_v, 97, 250)))
                        {
                            break lab3;
                        }
                        if (cursor >= limit)
                        {
                            break lab3;
                        }
                        cursor++;
                    }
                }
                I_pV = cursor;
            }
            cursor = v_3;
            int v_7 = cursor;
            lab10: {
                if (!go_out_grouping(g_v, 97, 250))
                {
                    break lab10;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 250))
                {
                    break lab10;
                }
                cursor++;
                I_p1 = cursor;
                if (!go_out_grouping(g_v, 97, 250))
                {
                    break lab10;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 250))
                {
                    break lab10;
                }
                cursor++;
                I_p2 = cursor;
            }
            cursor = v_7;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_8 = limit - cursor;
        lab11: {
            lab12: {
                int v_9 = limit - cursor;
                lab13: {
                    int v_10 = limit - cursor;
                    lab14: {
                        int v_11 = limit - cursor;
                        lab15: {
                            ket = cursor;
                            among_var = find_among_b(a_5);
                            if (among_var == 0)
                            {
                                break lab15;
                            }
                            bra = cursor;
                            switch (among_var) {
                                case 1:
                                    if (I_p2 > cursor)
                                    {
                                        break lab15;
                                    }
                                    slice_del();
                                    break;
                                case 2:
                                    if (I_p2 > cursor)
                                    {
                                        break lab15;
                                    }
                                    slice_from("log");
                                    break;
                                case 3:
                                    if (I_p2 > cursor)
                                    {
                                        break lab15;
                                    }
                                    slice_from("u");
                                    break;
                                case 4:
                                    if (I_p2 > cursor)
                                    {
                                        break lab15;
                                    }
                                    slice_from("ente");
                                    break;
                                case 5:
                                    if (I_p1 > cursor)
                                    {
                                        break lab15;
                                    }
                                    slice_del();
                                    int v_12 = limit - cursor;
                                    lab16: {
                                        ket = cursor;
                                        among_var = find_among_b(a_2);
                                        if (among_var == 0)
                                        {
                                            cursor = limit - v_12;
                                            break lab16;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_12;
                                            break lab16;
                                        }
                                        slice_del();
                                        switch (among_var) {
                                            case 1:
                                                ket = cursor;
                                                if (!(eq_s_b("at")))
                                                {
                                                    cursor = limit - v_12;
                                                    break lab16;
                                                }
                                                bra = cursor;
                                                if (I_p2 > cursor)
                                                {
                                                    cursor = limit - v_12;
                                                    break lab16;
                                                }
                                                slice_del();
                                                break;
                                        }
                                    }
                                    break;
                                case 6:
                                    if (I_p2 > cursor)
                                    {
                                        break lab15;
                                    }
                                    slice_del();
                                    int v_13 = limit - cursor;
                                    lab17: {
                                        ket = cursor;
                                        if (find_among_b(a_3) == 0)
                                        {
                                            cursor = limit - v_13;
                                            break lab17;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_13;
                                            break lab17;
                                        }
                                        slice_del();
                                    }
                                    break;
                                case 7:
                                    if (I_p2 > cursor)
                                    {
                                        break lab15;
                                    }
                                    slice_del();
                                    int v_14 = limit - cursor;
                                    lab18: {
                                        ket = cursor;
                                        if (find_among_b(a_4) == 0)
                                        {
                                            cursor = limit - v_14;
                                            break lab18;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_14;
                                            break lab18;
                                        }
                                        slice_del();
                                    }
                                    break;
                                case 8:
                                    if (I_p2 > cursor)
                                    {
                                        break lab15;
                                    }
                                    slice_del();
                                    int v_15 = limit - cursor;
                                    lab19: {
                                        ket = cursor;
                                        if (!(eq_s_b("at")))
                                        {
                                            cursor = limit - v_15;
                                            break lab19;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_15;
                                            break lab19;
                                        }
                                        slice_del();
                                    }
                                    break;
                                case 9:
                                    if (I_pV > cursor)
                                    {
                                        break lab15;
                                    }
                                    if (!(eq_s_b("e")))
                                    {
                                        break lab15;
                                    }
                                    slice_from("ir");
                                    break;
                            }
                            break lab14;
                        }
                        cursor = limit - v_11;
                        if (cursor < I_pV)
                        {
                            break lab13;
                        }
                        int v_16 = limit_backward;
                        limit_backward = I_pV;
                        ket = cursor;
                        if (find_among_b(a_6) == 0)
                        {
                            limit_backward = v_16;
                            break lab13;
                        }
                        bra = cursor;
                        slice_del();
                        limit_backward = v_16;
                    }
                    cursor = limit - v_10;
                    int v_17 = limit - cursor;
                    lab20: {
                        ket = cursor;
                        if (!(eq_s_b("i")))
                        {
                            break lab20;
                        }
                        bra = cursor;
                        int v_18 = limit - cursor;
                        if (!(eq_s_b("c")))
                        {
                            break lab20;
                        }
                        cursor = limit - v_18;
                        if (I_pV > cursor)
                        {
                            break lab20;
                        }
                        slice_del();
                    }
                    cursor = limit - v_17;
                    break lab12;
                }
                cursor = limit - v_9;
                ket = cursor;
                if (find_among_b(a_7) == 0)
                {
                    break lab11;
                }
                bra = cursor;
                if (I_pV > cursor)
                {
                    break lab11;
                }
                slice_del();
            }
        }
        cursor = limit - v_8;
        int v_19 = limit - cursor;
        lab21: {
            ket = cursor;
            among_var = find_among_b(a_8);
            if (among_var == 0)
            {
                break lab21;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    if (I_pV > cursor)
                    {
                        break lab21;
                    }
                    slice_del();
                    ket = cursor;
                    lab22: {
                        int v_20 = limit - cursor;
                        lab23: {
                            if (!(eq_s_b("u")))
                            {
                                break lab23;
                            }
                            bra = cursor;
                            int v_21 = limit - cursor;
                            if (!(eq_s_b("g")))
                            {
                                break lab23;
                            }
                            cursor = limit - v_21;
                            break lab22;
                        }
                        cursor = limit - v_20;
                        if (!(eq_s_b("i")))
                        {
                            break lab21;
                        }
                        bra = cursor;
                        int v_22 = limit - cursor;
                        if (!(eq_s_b("c")))
                        {
                            break lab21;
                        }
                        cursor = limit - v_22;
                    }
                    if (I_pV > cursor)
                    {
                        break lab21;
                    }
                    slice_del();
                    break;
                case 2:
                    slice_from("c");
                    break;
            }
        }
        cursor = limit - v_19;
        cursor = limit_backward;
        int v_23 = cursor;
        lab24: {
            while (true)
            {
                int v_24 = cursor;
                lab25: {
                    bra = cursor;
                    among_var = find_among(a_1);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("\u00E3");
                            break;
                        case 2:
                            slice_from("\u00F5");
                            break;
                        case 3:
                            if (cursor >= limit)
                            {
                                break lab25;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_24;
                break;
            }
        }
        cursor = v_23;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof portugueseStemmer;
    }

    @Override
    public int hashCode() {
        return portugueseStemmer.class.getName().hashCode();
    }

}
