// Generated from porter.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from porter.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class porterStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("s", -1, 3),
        new Among("ies", 0, 2),
        new Among("sses", 0, 1),
        new Among("ss", 0, -1)
    };

    private final static Among[] a_1 = {
        new Among("", -1, 3),
        new Among("bb", 0, 2),
        new Among("dd", 0, 2),
        new Among("ff", 0, 2),
        new Among("gg", 0, 2),
        new Among("bl", 0, 1),
        new Among("mm", 0, 2),
        new Among("nn", 0, 2),
        new Among("pp", 0, 2),
        new Among("rr", 0, 2),
        new Among("at", 0, 1),
        new Among("tt", 0, 2),
        new Among("iz", 0, 1)
    };

    private final static Among[] a_2 = {
        new Among("ed", -1, 2),
        new Among("eed", 0, 1),
        new Among("ing", -1, 2)
    };

    private final static Among[] a_3 = {
        new Among("anci", -1, 3),
        new Among("enci", -1, 2),
        new Among("abli", -1, 4),
        new Among("eli", -1, 6),
        new Among("alli", -1, 9),
        new Among("ousli", -1, 11),
        new Among("entli", -1, 5),
        new Among("aliti", -1, 9),
        new Among("biliti", -1, 13),
        new Among("iviti", -1, 12),
        new Among("tional", -1, 1),
        new Among("ational", 10, 8),
        new Among("alism", -1, 9),
        new Among("ation", -1, 8),
        new Among("ization", 13, 7),
        new Among("izer", -1, 7),
        new Among("ator", -1, 8),
        new Among("iveness", -1, 12),
        new Among("fulness", -1, 10),
        new Among("ousness", -1, 11)
    };

    private final static Among[] a_4 = {
        new Among("icate", -1, 2),
        new Among("ative", -1, 3),
        new Among("alize", -1, 1),
        new Among("iciti", -1, 2),
        new Among("ical", -1, 2),
        new Among("ful", -1, 3),
        new Among("ness", -1, 3)
    };

    private final static Among[] a_5 = {
        new Among("ic", -1, 1),
        new Among("ance", -1, 1),
        new Among("ence", -1, 1),
        new Among("able", -1, 1),
        new Among("ible", -1, 1),
        new Among("ate", -1, 1),
        new Among("ive", -1, 1),
        new Among("ize", -1, 1),
        new Among("iti", -1, 1),
        new Among("al", -1, 1),
        new Among("ism", -1, 1),
        new Among("ion", -1, 2),
        new Among("er", -1, 1),
        new Among("ous", -1, 1),
        new Among("ant", -1, 1),
        new Among("ent", -1, 1),
        new Among("ment", 15, 1),
        new Among("ement", 16, 1),
        new Among("ou", -1, 1)
    };

    private static final char[] g_v = {17, 65, 16, 1 };

    private static final char[] g_v_WXY = {1, 17, 65, 208, 1 };


    private boolean r_shortv() {
        if (!(out_grouping_b(g_v_WXY, 89, 121)))
        {
            return false;
        }
        if (!(in_grouping_b(g_v, 97, 121)))
        {
            return false;
        }
        return out_grouping_b(g_v, 97, 121);
    }

    @Override
    public boolean stem() {
        int among_var;
        boolean B_Y_found;
        int I_p2;
        int I_p1;
        B_Y_found = false;
        int v_1 = cursor;
        lab0: {
            bra = cursor;
            if (!(eq_s("y")))
            {
                break lab0;
            }
            ket = cursor;
            slice_from("Y");
            B_Y_found = true;
        }
        cursor = v_1;
        int v_2 = cursor;
        lab1: {
            while (true)
            {
                int v_3 = cursor;
                lab2: {
                    golab3: while (true)
                    {
                        int v_4 = cursor;
                        lab4: {
                            if (!(in_grouping(g_v, 97, 121)))
                            {
                                break lab4;
                            }
                            bra = cursor;
                            if (!(eq_s("y")))
                            {
                                break lab4;
                            }
                            ket = cursor;
                            cursor = v_4;
                            break golab3;
                        }
                        cursor = v_4;
                        if (cursor >= limit)
                        {
                            break lab2;
                        }
                        cursor++;
                    }
                    slice_from("Y");
                    B_Y_found = true;
                    continue;
                }
                cursor = v_3;
                break;
            }
        }
        cursor = v_2;
        I_p1 = limit;
        I_p2 = limit;
        int v_5 = cursor;
        lab5: {
            if (!go_out_grouping(g_v, 97, 121))
            {
                break lab5;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 121))
            {
                break lab5;
            }
            cursor++;
            I_p1 = cursor;
            if (!go_out_grouping(g_v, 97, 121))
            {
                break lab5;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 121))
            {
                break lab5;
            }
            cursor++;
            I_p2 = cursor;
        }
        cursor = v_5;
        limit_backward = cursor;
        cursor = limit;
        int v_6 = limit - cursor;
        lab6: {
            ket = cursor;
            among_var = find_among_b(a_0);
            if (among_var == 0)
            {
                break lab6;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_from("ss");
                    break;
                case 2:
                    slice_from("i");
                    break;
                case 3:
                    slice_del();
                    break;
            }
        }
        cursor = limit - v_6;
        int v_7 = limit - cursor;
        lab7: {
            ket = cursor;
            among_var = find_among_b(a_2);
            if (among_var == 0)
            {
                break lab7;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    if (I_p1 > cursor)
                    {
                        break lab7;
                    }
                    slice_from("ee");
                    break;
                case 2:
                    int v_8 = limit - cursor;
                    if (!go_out_grouping_b(g_v, 97, 121))
                    {
                        break lab7;
                    }
                    cursor--;
                    cursor = limit - v_8;
                    slice_del();
                    int v_9 = limit - cursor;
                    among_var = find_among_b(a_1);
                    cursor = limit - v_9;
                    switch (among_var) {
                        case 1:
                            {
                                int c = cursor;
                                insert(cursor, cursor, "e");
                                cursor = c;
                            }
                            break;
                        case 2:
                            ket = cursor;
                            if (cursor <= limit_backward)
                            {
                                break lab7;
                            }
                            cursor--;
                            bra = cursor;
                            slice_del();
                            break;
                        case 3:
                            if (cursor != I_p1)
                            {
                                break lab7;
                            }
                            int v_10 = limit - cursor;
                            if (!r_shortv())
                            {
                                break lab7;
                            }
                            cursor = limit - v_10;
                            {
                                int c = cursor;
                                insert(cursor, cursor, "e");
                                cursor = c;
                            }
                            break;
                    }
                    break;
            }
        }
        cursor = limit - v_7;
        int v_11 = limit - cursor;
        lab8: {
            ket = cursor;
            lab9: {
                lab10: {
                    if (!(eq_s_b("y")))
                    {
                        break lab10;
                    }
                    break lab9;
                }
                if (!(eq_s_b("Y")))
                {
                    break lab8;
                }
            }
            bra = cursor;
            if (!go_out_grouping_b(g_v, 97, 121))
            {
                break lab8;
            }
            cursor--;
            slice_from("i");
        }
        cursor = limit - v_11;
        int v_12 = limit - cursor;
        lab11: {
            ket = cursor;
            among_var = find_among_b(a_3);
            if (among_var == 0)
            {
                break lab11;
            }
            bra = cursor;
            if (I_p1 > cursor)
            {
                break lab11;
            }
            switch (among_var) {
                case 1:
                    slice_from("tion");
                    break;
                case 2:
                    slice_from("ence");
                    break;
                case 3:
                    slice_from("ance");
                    break;
                case 4:
                    slice_from("able");
                    break;
                case 5:
                    slice_from("ent");
                    break;
                case 6:
                    slice_from("e");
                    break;
                case 7:
                    slice_from("ize");
                    break;
                case 8:
                    slice_from("ate");
                    break;
                case 9:
                    slice_from("al");
                    break;
                case 10:
                    slice_from("ful");
                    break;
                case 11:
                    slice_from("ous");
                    break;
                case 12:
                    slice_from("ive");
                    break;
                case 13:
                    slice_from("ble");
                    break;
            }
        }
        cursor = limit - v_12;
        int v_13 = limit - cursor;
        lab12: {
            ket = cursor;
            among_var = find_among_b(a_4);
            if (among_var == 0)
            {
                break lab12;
            }
            bra = cursor;
            if (I_p1 > cursor)
            {
                break lab12;
            }
            switch (among_var) {
                case 1:
                    slice_from("al");
                    break;
                case 2:
                    slice_from("ic");
                    break;
                case 3:
                    slice_del();
                    break;
            }
        }
        cursor = limit - v_13;
        int v_14 = limit - cursor;
        lab13: {
            ket = cursor;
            among_var = find_among_b(a_5);
            if (among_var == 0)
            {
                break lab13;
            }
            bra = cursor;
            if (I_p2 > cursor)
            {
                break lab13;
            }
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    lab14: {
                        lab15: {
                            if (!(eq_s_b("s")))
                            {
                                break lab15;
                            }
                            break lab14;
                        }
                        if (!(eq_s_b("t")))
                        {
                            break lab13;
                        }
                    }
                    slice_del();
                    break;
            }
        }
        cursor = limit - v_14;
        int v_15 = limit - cursor;
        lab16: {
            ket = cursor;
            if (!(eq_s_b("e")))
            {
                break lab16;
            }
            bra = cursor;
            lab17: {
                lab18: {
                    if (I_p2 > cursor)
                    {
                        break lab18;
                    }
                    break lab17;
                }
                if (I_p1 > cursor)
                {
                    break lab16;
                }
                {
                    int v_16 = limit - cursor;
                    lab19: {
                        if (!r_shortv())
                        {
                            break lab19;
                        }
                        break lab16;
                    }
                    cursor = limit - v_16;
                }
            }
            slice_del();
        }
        cursor = limit - v_15;
        int v_17 = limit - cursor;
        lab20: {
            ket = cursor;
            if (!(eq_s_b("l")))
            {
                break lab20;
            }
            bra = cursor;
            if (I_p2 > cursor)
            {
                break lab20;
            }
            if (!(eq_s_b("l")))
            {
                break lab20;
            }
            slice_del();
        }
        cursor = limit - v_17;
        cursor = limit_backward;
        int v_18 = cursor;
        lab21: {
            if (!B_Y_found)
            {
                break lab21;
            }
            while (true)
            {
                int v_19 = cursor;
                lab22: {
                    golab23: while (true)
                    {
                        int v_20 = cursor;
                        lab24: {
                            bra = cursor;
                            if (!(eq_s("Y")))
                            {
                                break lab24;
                            }
                            ket = cursor;
                            cursor = v_20;
                            break golab23;
                        }
                        cursor = v_20;
                        if (cursor >= limit)
                        {
                            break lab22;
                        }
                        cursor++;
                    }
                    slice_from("y");
                    continue;
                }
                cursor = v_19;
                break;
            }
        }
        cursor = v_18;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof porterStemmer;
    }

    @Override
    public int hashCode() {
        return porterStemmer.class.getName().hashCode();
    }

}
