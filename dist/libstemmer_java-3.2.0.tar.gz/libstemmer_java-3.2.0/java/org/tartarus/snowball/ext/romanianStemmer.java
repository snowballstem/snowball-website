// Generated from romanian.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from romanian.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class romanianStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("\u015F", -1, 1),
        new Among("\u0163", -1, 2)
    };

    private final static Among[] a_1 = {
        new Among("", -1, 3),
        new Among("I", 0, 1),
        new Among("U", 0, 2)
    };

    private final static Among[] a_2 = {
        new Among("ea", -1, 3),
        new Among("a\u021Bia", -1, 7),
        new Among("aua", -1, 2),
        new Among("iua", -1, 4),
        new Among("a\u021Bie", -1, 7),
        new Among("ele", -1, 3),
        new Among("ile", -1, 5),
        new Among("iile", 6, 4),
        new Among("iei", -1, 4),
        new Among("atei", -1, 6),
        new Among("ii", -1, 4),
        new Among("ului", -1, 1),
        new Among("ul", -1, 1),
        new Among("elor", -1, 3),
        new Among("ilor", -1, 4),
        new Among("iilor", 14, 4)
    };

    private final static Among[] a_3 = {
        new Among("icala", -1, 4),
        new Among("iciva", -1, 4),
        new Among("ativa", -1, 5),
        new Among("itiva", -1, 6),
        new Among("icale", -1, 4),
        new Among("a\u021Biune", -1, 5),
        new Among("i\u021Biune", -1, 6),
        new Among("atoare", -1, 5),
        new Among("itoare", -1, 6),
        new Among("\u0103toare", -1, 5),
        new Among("icitate", -1, 4),
        new Among("abilitate", -1, 1),
        new Among("ibilitate", -1, 2),
        new Among("ivitate", -1, 3),
        new Among("icive", -1, 4),
        new Among("ative", -1, 5),
        new Among("itive", -1, 6),
        new Among("icali", -1, 4),
        new Among("atori", -1, 5),
        new Among("icatori", 18, 4),
        new Among("itori", -1, 6),
        new Among("\u0103tori", -1, 5),
        new Among("icitati", -1, 4),
        new Among("abilitati", -1, 1),
        new Among("ivitati", -1, 3),
        new Among("icivi", -1, 4),
        new Among("ativi", -1, 5),
        new Among("itivi", -1, 6),
        new Among("icit\u0103i", -1, 4),
        new Among("abilit\u0103i", -1, 1),
        new Among("ivit\u0103i", -1, 3),
        new Among("icit\u0103\u021Bi", -1, 4),
        new Among("abilit\u0103\u021Bi", -1, 1),
        new Among("ivit\u0103\u021Bi", -1, 3),
        new Among("ical", -1, 4),
        new Among("ator", -1, 5),
        new Among("icator", 35, 4),
        new Among("itor", -1, 6),
        new Among("\u0103tor", -1, 5),
        new Among("iciv", -1, 4),
        new Among("ativ", -1, 5),
        new Among("itiv", -1, 6),
        new Among("ical\u0103", -1, 4),
        new Among("iciv\u0103", -1, 4),
        new Among("ativ\u0103", -1, 5),
        new Among("itiv\u0103", -1, 6)
    };

    private final static Among[] a_4 = {
        new Among("ica", -1, 1),
        new Among("abila", -1, 1),
        new Among("ibila", -1, 1),
        new Among("oasa", -1, 1),
        new Among("ata", -1, 1),
        new Among("ita", -1, 1),
        new Among("anta", -1, 1),
        new Among("ista", -1, 3),
        new Among("uta", -1, 1),
        new Among("iva", -1, 1),
        new Among("ic", -1, 1),
        new Among("ice", -1, 1),
        new Among("abile", -1, 1),
        new Among("ibile", -1, 1),
        new Among("isme", -1, 3),
        new Among("iune", -1, 2),
        new Among("oase", -1, 1),
        new Among("ate", -1, 1),
        new Among("itate", 17, 1),
        new Among("ite", -1, 1),
        new Among("ante", -1, 1),
        new Among("iste", -1, 3),
        new Among("ute", -1, 1),
        new Among("ive", -1, 1),
        new Among("ici", -1, 1),
        new Among("abili", -1, 1),
        new Among("ibili", -1, 1),
        new Among("iuni", -1, 2),
        new Among("atori", -1, 1),
        new Among("osi", -1, 1),
        new Among("ati", -1, 1),
        new Among("itati", 30, 1),
        new Among("iti", -1, 1),
        new Among("anti", -1, 1),
        new Among("isti", -1, 3),
        new Among("uti", -1, 1),
        new Among("i\u0219ti", -1, 3),
        new Among("ivi", -1, 1),
        new Among("it\u0103i", -1, 1),
        new Among("o\u0219i", -1, 1),
        new Among("it\u0103\u021Bi", -1, 1),
        new Among("abil", -1, 1),
        new Among("ibil", -1, 1),
        new Among("ism", -1, 3),
        new Among("ator", -1, 1),
        new Among("os", -1, 1),
        new Among("at", -1, 1),
        new Among("it", -1, 1),
        new Among("ant", -1, 1),
        new Among("ist", -1, 3),
        new Among("ut", -1, 1),
        new Among("iv", -1, 1),
        new Among("ic\u0103", -1, 1),
        new Among("abil\u0103", -1, 1),
        new Among("ibil\u0103", -1, 1),
        new Among("oas\u0103", -1, 1),
        new Among("at\u0103", -1, 1),
        new Among("it\u0103", -1, 1),
        new Among("ant\u0103", -1, 1),
        new Among("ist\u0103", -1, 3),
        new Among("ut\u0103", -1, 1),
        new Among("iv\u0103", -1, 1)
    };

    private final static Among[] a_5 = {
        new Among("ea", -1, 1),
        new Among("ia", -1, 1),
        new Among("esc", -1, 1),
        new Among("\u0103sc", -1, 1),
        new Among("ind", -1, 1),
        new Among("\u00E2nd", -1, 1),
        new Among("are", -1, 1),
        new Among("ere", -1, 1),
        new Among("ire", -1, 1),
        new Among("\u00E2re", -1, 1),
        new Among("se", -1, 2),
        new Among("ase", 10, 1),
        new Among("sese", 10, 2),
        new Among("ise", 10, 1),
        new Among("use", 10, 1),
        new Among("\u00E2se", 10, 1),
        new Among("e\u0219te", -1, 1),
        new Among("\u0103\u0219te", -1, 1),
        new Among("eze", -1, 1),
        new Among("ai", -1, 1),
        new Among("eai", 19, 1),
        new Among("iai", 19, 1),
        new Among("sei", -1, 2),
        new Among("e\u0219ti", -1, 1),
        new Among("\u0103\u0219ti", -1, 1),
        new Among("ui", -1, 1),
        new Among("ezi", -1, 1),
        new Among("\u00E2i", -1, 1),
        new Among("a\u0219i", -1, 1),
        new Among("se\u0219i", -1, 2),
        new Among("ase\u0219i", 29, 1),
        new Among("sese\u0219i", 29, 2),
        new Among("ise\u0219i", 29, 1),
        new Among("use\u0219i", 29, 1),
        new Among("\u00E2se\u0219i", 29, 1),
        new Among("i\u0219i", -1, 1),
        new Among("u\u0219i", -1, 1),
        new Among("\u00E2\u0219i", -1, 1),
        new Among("a\u021Bi", -1, 2),
        new Among("ea\u021Bi", 38, 1),
        new Among("ia\u021Bi", 38, 1),
        new Among("e\u021Bi", -1, 2),
        new Among("i\u021Bi", -1, 2),
        new Among("\u00E2\u021Bi", -1, 2),
        new Among("ar\u0103\u021Bi", -1, 1),
        new Among("ser\u0103\u021Bi", -1, 2),
        new Among("aser\u0103\u021Bi", 45, 1),
        new Among("seser\u0103\u021Bi", 45, 2),
        new Among("iser\u0103\u021Bi", 45, 1),
        new Among("user\u0103\u021Bi", 45, 1),
        new Among("\u00E2ser\u0103\u021Bi", 45, 1),
        new Among("ir\u0103\u021Bi", -1, 1),
        new Among("ur\u0103\u021Bi", -1, 1),
        new Among("\u00E2r\u0103\u021Bi", -1, 1),
        new Among("am", -1, 1),
        new Among("eam", 54, 1),
        new Among("iam", 54, 1),
        new Among("em", -1, 2),
        new Among("asem", 57, 1),
        new Among("sesem", 57, 2),
        new Among("isem", 57, 1),
        new Among("usem", 57, 1),
        new Among("\u00E2sem", 57, 1),
        new Among("im", -1, 2),
        new Among("\u00E2m", -1, 2),
        new Among("\u0103m", -1, 2),
        new Among("ar\u0103m", 65, 1),
        new Among("ser\u0103m", 65, 2),
        new Among("aser\u0103m", 67, 1),
        new Among("seser\u0103m", 67, 2),
        new Among("iser\u0103m", 67, 1),
        new Among("user\u0103m", 67, 1),
        new Among("\u00E2ser\u0103m", 67, 1),
        new Among("ir\u0103m", 65, 1),
        new Among("ur\u0103m", 65, 1),
        new Among("\u00E2r\u0103m", 65, 1),
        new Among("au", -1, 1),
        new Among("eau", 76, 1),
        new Among("iau", 76, 1),
        new Among("indu", -1, 1),
        new Among("\u00E2ndu", -1, 1),
        new Among("ez", -1, 1),
        new Among("easc\u0103", -1, 1),
        new Among("ar\u0103", -1, 1),
        new Among("ser\u0103", -1, 2),
        new Among("aser\u0103", 84, 1),
        new Among("seser\u0103", 84, 2),
        new Among("iser\u0103", 84, 1),
        new Among("user\u0103", 84, 1),
        new Among("\u00E2ser\u0103", 84, 1),
        new Among("ir\u0103", -1, 1),
        new Among("ur\u0103", -1, 1),
        new Among("\u00E2r\u0103", -1, 1),
        new Among("eaz\u0103", -1, 1)
    };

    private final static Among[] a_6 = {
        new Among("a", -1, 1),
        new Among("e", -1, 1),
        new Among("ie", 1, 1),
        new Among("i", -1, 1),
        new Among("\u0103", -1, 1)
    };

    private static final char[] g_v = {17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 32, 0, 0, 4 };


    @Override
    public boolean stem() {
        int among_var;
        boolean B_standard_suffix_removed;
        int I_p2;
        int I_p1;
        int I_pV;
        lab0: {
            int v_1 = cursor;
            lab1: {
                while (true)
                {
                    int v_2 = cursor;
                    lab2: {
                        golab3: while (true)
                        {
                            int v_3 = cursor;
                            lab4: {
                                bra = cursor;
                                among_var = find_among(a_0);
                                if (among_var == 0)
                                {
                                    break lab4;
                                }
                                ket = cursor;
                                switch (among_var) {
                                    case 1:
                                        slice_from("\u0219");
                                        break;
                                    case 2:
                                        slice_from("\u021B");
                                        break;
                                }
                                cursor = v_3;
                                break golab3;
                            }
                            cursor = v_3;
                            if (cursor >= limit)
                            {
                                break lab2;
                            }
                            cursor++;
                        }
                        continue;
                    }
                    cursor = v_2;
                    break;
                }
            }
            cursor = v_1;
        }
        int v_4 = cursor;
        lab5: {
            while (true)
            {
                int v_5 = cursor;
                lab6: {
                    golab7: while (true)
                    {
                        int v_6 = cursor;
                        lab8: {
                            if (!(in_grouping(g_v, 97, 259)))
                            {
                                break lab8;
                            }
                            bra = cursor;
                            lab9: {
                                int v_7 = cursor;
                                lab10: {
                                    if (!(eq_s("u")))
                                    {
                                        break lab10;
                                    }
                                    ket = cursor;
                                    if (!(in_grouping(g_v, 97, 259)))
                                    {
                                        break lab10;
                                    }
                                    slice_from("U");
                                    break lab9;
                                }
                                cursor = v_7;
                                if (!(eq_s("i")))
                                {
                                    break lab8;
                                }
                                ket = cursor;
                                if (!(in_grouping(g_v, 97, 259)))
                                {
                                    break lab8;
                                }
                                slice_from("I");
                            }
                            cursor = v_6;
                            break golab7;
                        }
                        cursor = v_6;
                        if (cursor >= limit)
                        {
                            break lab6;
                        }
                        cursor++;
                    }
                    continue;
                }
                cursor = v_5;
                break;
            }
        }
        cursor = v_4;
        lab11: {
            I_pV = limit;
            I_p1 = limit;
            I_p2 = limit;
            int v_8 = cursor;
            lab12: {
                lab13: {
                    int v_9 = cursor;
                    lab14: {
                        if (!(in_grouping(g_v, 97, 259)))
                        {
                            break lab14;
                        }
                        lab15: {
                            int v_10 = cursor;
                            lab16: {
                                if (!(out_grouping(g_v, 97, 259)))
                                {
                                    break lab16;
                                }
                                if (!go_out_grouping(g_v, 97, 259))
                                {
                                    break lab16;
                                }
                                cursor++;
                                break lab15;
                            }
                            cursor = v_10;
                            if (!(in_grouping(g_v, 97, 259)))
                            {
                                break lab14;
                            }
                            if (!go_in_grouping(g_v, 97, 259))
                            {
                                break lab14;
                            }
                            cursor++;
                        }
                        break lab13;
                    }
                    cursor = v_9;
                    if (!(out_grouping(g_v, 97, 259)))
                    {
                        break lab12;
                    }
                    lab17: {
                        int v_11 = cursor;
                        lab18: {
                            if (!(out_grouping(g_v, 97, 259)))
                            {
                                break lab18;
                            }
                            if (!go_out_grouping(g_v, 97, 259))
                            {
                                break lab18;
                            }
                            cursor++;
                            break lab17;
                        }
                        cursor = v_11;
                        if (!(in_grouping(g_v, 97, 259)))
                        {
                            break lab12;
                        }
                        if (cursor >= limit)
                        {
                            break lab12;
                        }
                        cursor++;
                    }
                }
                I_pV = cursor;
            }
            cursor = v_8;
            int v_12 = cursor;
            lab19: {
                if (!go_out_grouping(g_v, 97, 259))
                {
                    break lab19;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 259))
                {
                    break lab19;
                }
                cursor++;
                I_p1 = cursor;
                if (!go_out_grouping(g_v, 97, 259))
                {
                    break lab19;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 259))
                {
                    break lab19;
                }
                cursor++;
                I_p2 = cursor;
            }
            cursor = v_12;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_13 = limit - cursor;
        lab20: {
            ket = cursor;
            among_var = find_among_b(a_2);
            if (among_var == 0)
            {
                break lab20;
            }
            bra = cursor;
            if (I_p1 > cursor)
            {
                break lab20;
            }
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    slice_from("a");
                    break;
                case 3:
                    slice_from("e");
                    break;
                case 4:
                    slice_from("i");
                    break;
                case 5:
                    lab21: {
                        if (!(eq_s_b("ab")))
                        {
                            break lab21;
                        }
                        break lab20;
                    }
                    slice_from("i");
                    break;
                case 6:
                    slice_from("at");
                    break;
                case 7:
                    slice_from("a\u021Bi");
                    break;
            }
        }
        cursor = limit - v_13;
        int v_14 = limit - cursor;
        lab22: {
            B_standard_suffix_removed = false;
            while (true)
            {
                int v_15 = limit - cursor;
                lab23: {
                    int v_16 = limit - cursor;
                    ket = cursor;
                    among_var = find_among_b(a_3);
                    if (among_var == 0)
                    {
                        break lab23;
                    }
                    bra = cursor;
                    if (I_p1 > cursor)
                    {
                        break lab23;
                    }
                    switch (among_var) {
                        case 1:
                            slice_from("abil");
                            break;
                        case 2:
                            slice_from("ibil");
                            break;
                        case 3:
                            slice_from("iv");
                            break;
                        case 4:
                            slice_from("ic");
                            break;
                        case 5:
                            slice_from("at");
                            break;
                        case 6:
                            slice_from("it");
                            break;
                    }
                    B_standard_suffix_removed = true;
                    cursor = limit - v_16;
                    continue;
                }
                cursor = limit - v_15;
                break;
            }
            ket = cursor;
            among_var = find_among_b(a_4);
            if (among_var == 0)
            {
                break lab22;
            }
            bra = cursor;
            if (I_p2 > cursor)
            {
                break lab22;
            }
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    if (!(eq_s_b("\u021B")))
                    {
                        break lab22;
                    }
                    bra = cursor;
                    slice_from("t");
                    break;
                case 3:
                    slice_from("ist");
                    break;
            }
            B_standard_suffix_removed = true;
        }
        cursor = limit - v_14;
        int v_17 = limit - cursor;
        lab24: {
            lab25: {
                lab26: {
                    if (!B_standard_suffix_removed)
                    {
                        break lab26;
                    }
                    break lab25;
                }
                if (cursor < I_pV)
                {
                    break lab24;
                }
                int v_18 = limit_backward;
                limit_backward = I_pV;
                ket = cursor;
                among_var = find_among_b(a_5);
                if (among_var == 0)
                {
                    limit_backward = v_18;
                    break lab24;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        lab27: {
                            lab28: {
                                if (!(out_grouping_b(g_v, 97, 259)))
                                {
                                    break lab28;
                                }
                                break lab27;
                            }
                            if (!(eq_s_b("u")))
                            {
                                limit_backward = v_18;
                                break lab24;
                            }
                        }
                        slice_del();
                        break;
                    case 2:
                        slice_del();
                        break;
                }
                limit_backward = v_18;
            }
        }
        cursor = limit - v_17;
        int v_19 = limit - cursor;
        lab29: {
            ket = cursor;
            if (find_among_b(a_6) == 0)
            {
                break lab29;
            }
            bra = cursor;
            if (I_pV > cursor)
            {
                break lab29;
            }
            slice_del();
        }
        cursor = limit - v_19;
        cursor = limit_backward;
        int v_20 = cursor;
        lab30: {
            while (true)
            {
                int v_21 = cursor;
                lab31: {
                    bra = cursor;
                    among_var = find_among(a_1);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("i");
                            break;
                        case 2:
                            slice_from("u");
                            break;
                        case 3:
                            if (cursor >= limit)
                            {
                                break lab31;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_21;
                break;
            }
        }
        cursor = v_20;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof romanianStemmer;
    }

    @Override
    public int hashCode() {
        return romanianStemmer.class.getName().hashCode();
    }

}
