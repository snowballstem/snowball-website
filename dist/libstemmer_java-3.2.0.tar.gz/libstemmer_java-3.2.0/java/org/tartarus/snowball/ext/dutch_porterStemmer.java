// Generated from dutch_porter.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from dutch_porter.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class dutch_porterStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("", -1, 6),
        new Among("\u00E1", 0, 1),
        new Among("\u00E4", 0, 1),
        new Among("\u00E9", 0, 2),
        new Among("\u00EB", 0, 2),
        new Among("\u00ED", 0, 3),
        new Among("\u00EF", 0, 3),
        new Among("\u00F3", 0, 4),
        new Among("\u00F6", 0, 4),
        new Among("\u00FA", 0, 5),
        new Among("\u00FC", 0, 5)
    };

    private final static Among[] a_1 = {
        new Among("", -1, 3),
        new Among("I", 0, 2),
        new Among("Y", 0, 1)
    };

    private final static Among[] a_2 = {
        new Among("dd", -1, -1),
        new Among("kk", -1, -1),
        new Among("tt", -1, -1)
    };

    private final static Among[] a_3 = {
        new Among("ene", -1, 2),
        new Among("se", -1, 3),
        new Among("en", -1, 2),
        new Among("heden", 2, 1),
        new Among("s", -1, 3)
    };

    private final static Among[] a_4 = {
        new Among("end", -1, 1),
        new Among("ig", -1, 2),
        new Among("ing", -1, 1),
        new Among("lijk", -1, 3),
        new Among("baar", -1, 4),
        new Among("bar", -1, 5)
    };

    private final static Among[] a_5 = {
        new Among("aa", -1, -1),
        new Among("ee", -1, -1),
        new Among("oo", -1, -1),
        new Among("uu", -1, -1)
    };

    private static final char[] g_v = {17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

    private static final char[] g_v_I = {1, 0, 0, 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

    private static final char[] g_v_j = {17, 67, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

    private int I_p1;
    private boolean B_e_found;


    private boolean r_undouble() {
        int v_1 = limit - cursor;
        if (find_among_b(a_2) == 0)
        {
            return false;
        }
        cursor = limit - v_1;
        ket = cursor;
        if (cursor <= limit_backward)
        {
            return false;
        }
        cursor--;
        bra = cursor;
        slice_del();
        return true;
    }

    private boolean r_e_ending() {
        B_e_found = false;
        ket = cursor;
        if (!(eq_s_b("e")))
        {
            return false;
        }
        bra = cursor;
        if (I_p1 > cursor)
        {
            return false;
        }
        int v_1 = limit - cursor;
        if (!(out_grouping_b(g_v, 97, 232)))
        {
            return false;
        }
        cursor = limit - v_1;
        slice_del();
        B_e_found = true;
        return r_undouble();
    }

    private boolean r_en_ending() {
        if (I_p1 > cursor)
        {
            return false;
        }
        int v_1 = limit - cursor;
        if (!(out_grouping_b(g_v, 97, 232)))
        {
            return false;
        }
        cursor = limit - v_1;
        lab0: {
            if (!(eq_s_b("gem")))
            {
                break lab0;
            }
            return false;
        }
        slice_del();
        return r_undouble();
    }

    @Override
    public boolean stem() {
        int among_var;
        int I_x;
        int I_p2;
        int v_1 = cursor;
        lab0: {
            int v_2 = cursor;
            while (true)
            {
                int v_3 = cursor;
                lab1: {
                    bra = cursor;
                    among_var = find_among(a_0);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("a");
                            break;
                        case 2:
                            slice_from("e");
                            break;
                        case 3:
                            slice_from("i");
                            break;
                        case 4:
                            slice_from("o");
                            break;
                        case 5:
                            slice_from("u");
                            break;
                        case 6:
                            if (cursor >= limit)
                            {
                                break lab1;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_3;
                break;
            }
            cursor = v_2;
            int v_4 = cursor;
            lab2: {
                bra = cursor;
                if (!(eq_s("y")))
                {
                    cursor = v_4;
                    break lab2;
                }
                ket = cursor;
                slice_from("Y");
            }
            while (true)
            {
                int v_5 = cursor;
                lab3: {
                    if (!go_out_grouping(g_v, 97, 232))
                    {
                        break lab3;
                    }
                    cursor++;
                    int v_6 = cursor;
                    lab4: {
                        bra = cursor;
                        lab5: {
                            int v_7 = cursor;
                            lab6: {
                                if (!(eq_s("i")))
                                {
                                    break lab6;
                                }
                                ket = cursor;
                                int v_8 = cursor;
                                lab7: {
                                    if (!(in_grouping(g_v, 97, 232)))
                                    {
                                        break lab7;
                                    }
                                    slice_from("I");
                                }
                                cursor = v_8;
                                break lab5;
                            }
                            cursor = v_7;
                            if (!(eq_s("y")))
                            {
                                cursor = v_6;
                                break lab4;
                            }
                            ket = cursor;
                            slice_from("Y");
                        }
                    }
                    continue;
                }
                cursor = v_5;
                break;
            }
        }
        cursor = v_1;
        int v_9 = cursor;
        lab8: {
            I_p1 = limit;
            I_p2 = limit;
            int v_10 = cursor;
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab8;
                }
                cursor = c;
            }
            I_x = cursor;
            cursor = v_10;
            if (!go_out_grouping(g_v, 97, 232))
            {
                break lab8;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 232))
            {
                break lab8;
            }
            cursor++;
            I_p1 = cursor;
            lab9: {
                if (I_p1 >= I_x)
                {
                    break lab9;
                }
                I_p1 = I_x;
            }
            if (!go_out_grouping(g_v, 97, 232))
            {
                break lab8;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 232))
            {
                break lab8;
            }
            cursor++;
            I_p2 = cursor;
        }
        cursor = v_9;
        limit_backward = cursor;
        cursor = limit;
        lab10: {
            int v_11 = limit - cursor;
            lab11: {
                ket = cursor;
                among_var = find_among_b(a_3);
                if (among_var == 0)
                {
                    break lab11;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p1 > cursor)
                        {
                            break lab11;
                        }
                        slice_from("heid");
                        break;
                    case 2:
                        if (!r_en_ending())
                        {
                            break lab11;
                        }
                        break;
                    case 3:
                        if (I_p1 > cursor)
                        {
                            break lab11;
                        }
                        if (!(out_grouping_b(g_v_j, 97, 232)))
                        {
                            break lab11;
                        }
                        slice_del();
                        break;
                }
            }
            cursor = limit - v_11;
            int v_12 = limit - cursor;
            r_e_ending();
            cursor = limit - v_12;
            int v_13 = limit - cursor;
            lab12: {
                ket = cursor;
                if (!(eq_s_b("heid")))
                {
                    break lab12;
                }
                bra = cursor;
                if (I_p2 > cursor)
                {
                    break lab12;
                }
                lab13: {
                    if (!(eq_s_b("c")))
                    {
                        break lab13;
                    }
                    break lab12;
                }
                slice_del();
                ket = cursor;
                if (!(eq_s_b("en")))
                {
                    break lab12;
                }
                bra = cursor;
                if (!r_en_ending())
                {
                    break lab12;
                }
            }
            cursor = limit - v_13;
            int v_14 = limit - cursor;
            lab14: {
                ket = cursor;
                among_var = find_among_b(a_4);
                if (among_var == 0)
                {
                    break lab14;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (I_p2 > cursor)
                        {
                            break lab14;
                        }
                        slice_del();
                        lab15: {
                            int v_15 = limit - cursor;
                            lab16: {
                                ket = cursor;
                                if (!(eq_s_b("ig")))
                                {
                                    break lab16;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    break lab16;
                                }
                                lab17: {
                                    if (!(eq_s_b("e")))
                                    {
                                        break lab17;
                                    }
                                    break lab16;
                                }
                                slice_del();
                                break lab15;
                            }
                            cursor = limit - v_15;
                            if (!r_undouble())
                            {
                                break lab14;
                            }
                        }
                        break;
                    case 2:
                        if (I_p2 > cursor)
                        {
                            break lab14;
                        }
                        lab18: {
                            if (!(eq_s_b("e")))
                            {
                                break lab18;
                            }
                            break lab14;
                        }
                        slice_del();
                        break;
                    case 3:
                        if (I_p2 > cursor)
                        {
                            break lab14;
                        }
                        slice_del();
                        if (!r_e_ending())
                        {
                            break lab14;
                        }
                        break;
                    case 4:
                        if (I_p2 > cursor)
                        {
                            break lab14;
                        }
                        slice_del();
                        break;
                    case 5:
                        if (I_p2 > cursor)
                        {
                            break lab14;
                        }
                        if (!B_e_found)
                        {
                            break lab14;
                        }
                        slice_del();
                        break;
                }
            }
            cursor = limit - v_14;
            int v_16 = limit - cursor;
            lab19: {
                if (!(out_grouping_b(g_v_I, 73, 232)))
                {
                    break lab19;
                }
                int v_17 = limit - cursor;
                if (find_among_b(a_5) == 0)
                {
                    break lab19;
                }
                if (!(out_grouping_b(g_v, 97, 232)))
                {
                    break lab19;
                }
                cursor = limit - v_17;
                ket = cursor;
                if (cursor <= limit_backward)
                {
                    break lab19;
                }
                cursor--;
                bra = cursor;
                slice_del();
            }
            cursor = limit - v_16;
        }
        cursor = limit_backward;
        int v_18 = cursor;
        lab20: {
            while (true)
            {
                int v_19 = cursor;
                lab21: {
                    bra = cursor;
                    among_var = find_among(a_1);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("y");
                            break;
                        case 2:
                            slice_from("i");
                            break;
                        case 3:
                            if (cursor >= limit)
                            {
                                break lab21;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_19;
                break;
            }
        }
        cursor = v_18;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof dutch_porterStemmer;
    }

    @Override
    public int hashCode() {
        return dutch_porterStemmer.class.getName().hashCode();
    }

}
