// Generated from greek.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from greek.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class greekStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("", -1, 25),
        new Among("\u0386", 0, 1),
        new Among("\u0388", 0, 5),
        new Among("\u0389", 0, 7),
        new Among("\u038A", 0, 9),
        new Among("\u038C", 0, 15),
        new Among("\u038E", 0, 20),
        new Among("\u038F", 0, 24),
        new Among("\u0390", 0, 7),
        new Among("\u0391", 0, 1),
        new Among("\u0392", 0, 2),
        new Among("\u0393", 0, 3),
        new Among("\u0394", 0, 4),
        new Among("\u0395", 0, 5),
        new Among("\u0396", 0, 6),
        new Among("\u0397", 0, 7),
        new Among("\u0398", 0, 8),
        new Among("\u0399", 0, 9),
        new Among("\u039A", 0, 10),
        new Among("\u039B", 0, 11),
        new Among("\u039C", 0, 12),
        new Among("\u039D", 0, 13),
        new Among("\u039E", 0, 14),
        new Among("\u039F", 0, 15),
        new Among("\u03A0", 0, 16),
        new Among("\u03A1", 0, 17),
        new Among("\u03A3", 0, 18),
        new Among("\u03A4", 0, 19),
        new Among("\u03A5", 0, 20),
        new Among("\u03A6", 0, 21),
        new Among("\u03A7", 0, 22),
        new Among("\u03A8", 0, 23),
        new Among("\u03A9", 0, 24),
        new Among("\u03AA", 0, 9),
        new Among("\u03AB", 0, 20),
        new Among("\u03AC", 0, 1),
        new Among("\u03AD", 0, 5),
        new Among("\u03AE", 0, 7),
        new Among("\u03AF", 0, 9),
        new Among("\u03B0", 0, 20),
        new Among("\u03C2", 0, 18),
        new Among("\u03CA", 0, 7),
        new Among("\u03CB", 0, 20),
        new Among("\u03CC", 0, 15),
        new Among("\u03CD", 0, 20),
        new Among("\u03CE", 0, 24)
    };

    private final static Among[] a_1 = {
        new Among("\u03C3\u03BA\u03B1\u03B3\u03B9\u03B1", -1, 2),
        new Among("\u03C6\u03B1\u03B3\u03B9\u03B1", -1, 1),
        new Among("\u03BF\u03BB\u03BF\u03B3\u03B9\u03B1", -1, 3),
        new Among("\u03C3\u03BF\u03B3\u03B9\u03B1", -1, 4),
        new Among("\u03C4\u03B1\u03C4\u03BF\u03B3\u03B9\u03B1", -1, 5),
        new Among("\u03BA\u03C1\u03B5\u03B1\u03C4\u03B1", -1, 6),
        new Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03B1", -1, 7),
        new Among("\u03C4\u03B5\u03C1\u03B1\u03C4\u03B1", -1, 8),
        new Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C4\u03B1", -1, 11),
        new Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C4\u03B1", -1, 10),
        new Among("\u03C6\u03C9\u03C4\u03B1", -1, 9),
        new Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03B7", -1, 7),
        new Among("\u03C3\u03BA\u03B1\u03B3\u03B9\u03C9\u03BD", -1, 2),
        new Among("\u03C6\u03B1\u03B3\u03B9\u03C9\u03BD", -1, 1),
        new Among("\u03BF\u03BB\u03BF\u03B3\u03B9\u03C9\u03BD", -1, 3),
        new Among("\u03C3\u03BF\u03B3\u03B9\u03C9\u03BD", -1, 4),
        new Among("\u03C4\u03B1\u03C4\u03BF\u03B3\u03B9\u03C9\u03BD", -1, 5),
        new Among("\u03BA\u03C1\u03B5\u03B1\u03C4\u03C9\u03BD", -1, 6),
        new Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03C9\u03BD", -1, 7),
        new Among("\u03C4\u03B5\u03C1\u03B1\u03C4\u03C9\u03BD", -1, 8),
        new Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C4\u03C9\u03BD", -1, 11),
        new Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C4\u03C9\u03BD", -1, 10),
        new Among("\u03C6\u03C9\u03C4\u03C9\u03BD", -1, 9),
        new Among("\u03BA\u03C1\u03B5\u03B1\u03C3", -1, 6),
        new Among("\u03C0\u03B5\u03C1\u03B1\u03C3", -1, 7),
        new Among("\u03C4\u03B5\u03C1\u03B1\u03C3", -1, 8),
        new Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C3", -1, 11),
        new Among("\u03BA\u03C1\u03B5\u03B1\u03C4\u03BF\u03C3", -1, 6),
        new Among("\u03C0\u03B5\u03C1\u03B1\u03C4\u03BF\u03C3", -1, 7),
        new Among("\u03C4\u03B5\u03C1\u03B1\u03C4\u03BF\u03C3", -1, 8),
        new Among("\u03B3\u03B5\u03B3\u03BF\u03BD\u03BF\u03C4\u03BF\u03C3", -1, 11),
        new Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C4\u03BF\u03C3", -1, 10),
        new Among("\u03C6\u03C9\u03C4\u03BF\u03C3", -1, 9),
        new Among("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4\u03C9\u03C3", -1, 10),
        new Among("\u03C6\u03C9\u03C3", -1, 9),
        new Among("\u03C3\u03BA\u03B1\u03B3\u03B9\u03BF\u03C5", -1, 2),
        new Among("\u03C6\u03B1\u03B3\u03B9\u03BF\u03C5", -1, 1),
        new Among("\u03BF\u03BB\u03BF\u03B3\u03B9\u03BF\u03C5", -1, 3),
        new Among("\u03C3\u03BF\u03B3\u03B9\u03BF\u03C5", -1, 4),
        new Among("\u03C4\u03B1\u03C4\u03BF\u03B3\u03B9\u03BF\u03C5", -1, 5)
    };

    private final static Among[] a_2 = {
        new Among("\u03C0\u03B1", -1, 1),
        new Among("\u03BE\u03B1\u03BD\u03B1\u03C0\u03B1", 0, 1),
        new Among("\u03B5\u03C0\u03B1", 0, 1),
        new Among("\u03C0\u03B5\u03C1\u03B9\u03C0\u03B1", 0, 1),
        new Among("\u03B1\u03BD\u03B1\u03BC\u03C0\u03B1", 0, 1),
        new Among("\u03B5\u03BC\u03C0\u03B1", 0, 1),
        new Among("\u03B2", -1, 2),
        new Among("\u03B4\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03B2\u03B1\u03B8\u03C5\u03C1\u03B9", -1, 2),
        new Among("\u03B2\u03B1\u03C1\u03BA", -1, 2),
        new Among("\u03BC\u03B1\u03C1\u03BA", -1, 2),
        new Among("\u03BB", -1, 2),
        new Among("\u03BC", -1, 2),
        new Among("\u03BA\u03BF\u03C1\u03BD", -1, 2),
        new Among("\u03B1\u03B8\u03C1\u03BF", -1, 1),
        new Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", 14, 1),
        new Among("\u03C0", -1, 2),
        new Among("\u03B9\u03BC\u03C0", 16, 2),
        new Among("\u03C1", -1, 2),
        new Among("\u03BC\u03B1\u03C1", 18, 2),
        new Among("\u03B1\u03BC\u03C0\u03B1\u03C1", 18, 2),
        new Among("\u03B3\u03BA\u03C1", 18, 2),
        new Among("\u03B2\u03BF\u03BB\u03B2\u03BF\u03C1", 18, 2),
        new Among("\u03B3\u03BB\u03C5\u03BA\u03BF\u03C1", 18, 2),
        new Among("\u03C0\u03B9\u03C0\u03B5\u03C1\u03BF\u03C1", 18, 2),
        new Among("\u03C0\u03C1", 18, 2),
        new Among("\u03BC\u03C0\u03C1", 25, 2),
        new Among("\u03B1\u03C1\u03C1", 18, 2),
        new Among("\u03B3\u03BB\u03C5\u03BA\u03C5\u03C1", 18, 2),
        new Among("\u03C0\u03BF\u03BB\u03C5\u03C1", 18, 2),
        new Among("\u03BB\u03BF\u03C5", -1, 2)
    };

    private final static Among[] a_3 = {
        new Among("\u03B9\u03B6\u03B1", -1, 1),
        new Among("\u03B9\u03B6\u03B5", -1, 1),
        new Among("\u03B9\u03B6\u03B1\u03BC\u03B5", -1, 1),
        new Among("\u03B9\u03B6\u03BF\u03C5\u03BC\u03B5", -1, 1),
        new Among("\u03B9\u03B6\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03B9\u03B6\u03BF\u03C5\u03BD\u03B5", -1, 1),
        new Among("\u03B9\u03B6\u03B1\u03C4\u03B5", -1, 1),
        new Among("\u03B9\u03B6\u03B5\u03C4\u03B5", -1, 1),
        new Among("\u03B9\u03B6\u03B5\u03B9", -1, 1),
        new Among("\u03B9\u03B6\u03B1\u03BD", -1, 1),
        new Among("\u03B9\u03B6\u03BF\u03C5\u03BD", -1, 1),
        new Among("\u03B9\u03B6\u03B5\u03C3", -1, 1),
        new Among("\u03B9\u03B6\u03B5\u03B9\u03C3", -1, 1),
        new Among("\u03B9\u03B6\u03C9", -1, 1)
    };

    private final static Among[] a_4 = {
        new Among("\u03B2\u03B9", -1, 1),
        new Among("\u03BB\u03B9", -1, 1),
        new Among("\u03B1\u03BB", -1, 1),
        new Among("\u03B5\u03BD", -1, 1),
        new Among("\u03C3", -1, 1),
        new Among("\u03C7", -1, 1),
        new Among("\u03C5\u03C8", -1, 1),
        new Among("\u03B6\u03C9", -1, 1)
    };

    private final static Among[] a_5 = {
        new Among("\u03C9\u03B8\u03B7\u03BA\u03B1", -1, 1),
        new Among("\u03C9\u03B8\u03B7\u03BA\u03B5", -1, 1),
        new Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03BC\u03B5", -1, 1),
        new Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03C4\u03B5", -1, 1),
        new Among("\u03C9\u03B8\u03B7\u03BA\u03B1\u03BD", -1, 1),
        new Among("\u03C9\u03B8\u03B7\u03BA\u03B5\u03C3", -1, 1)
    };

    private final static Among[] a_6 = {
        new Among("\u03BE\u03B1\u03BD\u03B1\u03C0\u03B1", -1, 1),
        new Among("\u03B5\u03C0\u03B1", -1, 1),
        new Among("\u03C0\u03B5\u03C1\u03B9\u03C0\u03B1", -1, 1),
        new Among("\u03B1\u03BD\u03B1\u03BC\u03C0\u03B1", -1, 1),
        new Among("\u03B5\u03BC\u03C0\u03B1", -1, 1),
        new Among("\u03C7\u03B1\u03C1\u03C4\u03BF\u03C0\u03B1", -1, 1),
        new Among("\u03B5\u03BE\u03B1\u03C1\u03C7\u03B1", -1, 1),
        new Among("\u03B3\u03B5", -1, 2),
        new Among("\u03B3\u03BA\u03B5", -1, 2),
        new Among("\u03BA\u03BB\u03B5", -1, 1),
        new Among("\u03B5\u03BA\u03BB\u03B5", 9, 1),
        new Among("\u03B1\u03C0\u03B5\u03BA\u03BB\u03B5", 10, 1),
        new Among("\u03B1\u03C0\u03BF\u03BA\u03BB\u03B5", 9, 1),
        new Among("\u03B5\u03C3\u03C9\u03BA\u03BB\u03B5", 9, 1),
        new Among("\u03B4\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03C0\u03B5", -1, 1),
        new Among("\u03B5\u03C0\u03B5", 15, 1),
        new Among("\u03BC\u03B5\u03C4\u03B5\u03C0\u03B5", 16, 1),
        new Among("\u03B5\u03C3\u03B5", -1, 1),
        new Among("\u03B3\u03BA", -1, 2),
        new Among("\u03BC", -1, 2),
        new Among("\u03C0\u03BF\u03C5\u03BA\u03B1\u03BC", 20, 2),
        new Among("\u03BA\u03BF\u03BC", 20, 2),
        new Among("\u03B1\u03BD", -1, 2),
        new Among("\u03BF\u03BB\u03BF", -1, 2),
        new Among("\u03B1\u03B8\u03C1\u03BF", -1, 1),
        new Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", 25, 1),
        new Among("\u03C0", -1, 2),
        new Among("\u03BB\u03B1\u03C1", -1, 2),
        new Among("\u03B4\u03B7\u03BC\u03BF\u03BA\u03C1\u03B1\u03C4", -1, 2),
        new Among("\u03B1\u03C6", -1, 2),
        new Among("\u03B3\u03B9\u03B3\u03B1\u03BD\u03C4\u03BF\u03B1\u03C6", 30, 2)
    };

    private final static Among[] a_7 = {
        new Among("\u03B9\u03C3\u03B1", -1, 1),
        new Among("\u03B9\u03C3\u03B1\u03BC\u03B5", -1, 1),
        new Among("\u03B9\u03C3\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03B9\u03C3\u03B5", -1, 1),
        new Among("\u03B9\u03C3\u03B1\u03C4\u03B5", -1, 1),
        new Among("\u03B9\u03C3\u03B1\u03BD", -1, 1),
        new Among("\u03B9\u03C3\u03B5\u03C3", -1, 1)
    };

    private final static Among[] a_8 = {
        new Among("\u03BE\u03B1\u03BD\u03B1\u03C0\u03B1", -1, 1),
        new Among("\u03B5\u03C0\u03B1", -1, 1),
        new Among("\u03C0\u03B5\u03C1\u03B9\u03C0\u03B1", -1, 1),
        new Among("\u03B1\u03BD\u03B1\u03BC\u03C0\u03B1", -1, 1),
        new Among("\u03B5\u03BC\u03C0\u03B1", -1, 1),
        new Among("\u03C7\u03B1\u03C1\u03C4\u03BF\u03C0\u03B1", -1, 1),
        new Among("\u03B5\u03BE\u03B1\u03C1\u03C7\u03B1", -1, 1),
        new Among("\u03BA\u03BB\u03B5", -1, 1),
        new Among("\u03B5\u03BA\u03BB\u03B5", 7, 1),
        new Among("\u03B1\u03C0\u03B5\u03BA\u03BB\u03B5", 8, 1),
        new Among("\u03B1\u03C0\u03BF\u03BA\u03BB\u03B5", 7, 1),
        new Among("\u03B5\u03C3\u03C9\u03BA\u03BB\u03B5", 7, 1),
        new Among("\u03B4\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03C0\u03B5", -1, 1),
        new Among("\u03B5\u03C0\u03B5", 13, 1),
        new Among("\u03BC\u03B5\u03C4\u03B5\u03C0\u03B5", 14, 1),
        new Among("\u03B5\u03C3\u03B5", -1, 1),
        new Among("\u03B1\u03B8\u03C1\u03BF", -1, 1),
        new Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", 17, 1)
    };

    private final static Among[] a_9 = {
        new Among("\u03B9\u03C3\u03BF\u03C5\u03BC\u03B5", -1, 1),
        new Among("\u03B9\u03C3\u03BF\u03C5\u03BD\u03B5", -1, 1),
        new Among("\u03B9\u03C3\u03B5\u03C4\u03B5", -1, 1),
        new Among("\u03B9\u03C3\u03B5\u03B9", -1, 1),
        new Among("\u03B9\u03C3\u03BF\u03C5\u03BD", -1, 1),
        new Among("\u03B9\u03C3\u03B5\u03B9\u03C3", -1, 1),
        new Among("\u03B9\u03C3\u03C9", -1, 1)
    };

    private final static Among[] a_10 = {
        new Among("\u03B1\u03C4\u03B1", -1, 2),
        new Among("\u03C6\u03B1", -1, 2),
        new Among("\u03B7\u03C6\u03B1", 1, 2),
        new Among("\u03BC\u03B5\u03B3", -1, 2),
        new Among("\u03BB\u03C5\u03B3", -1, 2),
        new Among("\u03B7\u03B4", -1, 2),
        new Among("\u03BA\u03BB\u03B5", -1, 1),
        new Among("\u03B5\u03C3\u03C9\u03BA\u03BB\u03B5", 6, 1),
        new Among("\u03C0\u03BB\u03B5", -1, 1),
        new Among("\u03B4\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03C3\u03B5", -1, 1),
        new Among("\u03B1\u03C3\u03B5", 10, 1),
        new Among("\u03BA\u03B1\u03B8", -1, 2),
        new Among("\u03B5\u03C7\u03B8", -1, 2),
        new Among("\u03BA\u03B1\u03BA", -1, 2),
        new Among("\u03BC\u03B1\u03BA", -1, 2),
        new Among("\u03C3\u03BA", -1, 2),
        new Among("\u03C6\u03B9\u03BB", -1, 2),
        new Among("\u03BA\u03C5\u03BB", -1, 2),
        new Among("\u03BC", -1, 2),
        new Among("\u03B3\u03B5\u03BC", 19, 2),
        new Among("\u03B1\u03C7\u03BD", -1, 2),
        new Among("\u03C3\u03C5\u03BD\u03B1\u03B8\u03C1\u03BF", -1, 1),
        new Among("\u03C0", -1, 2),
        new Among("\u03B1\u03C0", 23, 2),
        new Among("\u03B5\u03BC\u03C0", 23, 2),
        new Among("\u03B5\u03C5\u03C0", 23, 2),
        new Among("\u03B1\u03C1", -1, 2),
        new Among("\u03B1\u03BF\u03C1", -1, 2),
        new Among("\u03B3\u03C5\u03C1", -1, 2),
        new Among("\u03C7\u03C1", -1, 2),
        new Among("\u03C7\u03C9\u03C1", -1, 2),
        new Among("\u03BA\u03C4", -1, 2),
        new Among("\u03B1\u03BA\u03C4", 32, 2),
        new Among("\u03C7\u03C4", -1, 2),
        new Among("\u03B1\u03C7\u03C4", 34, 2),
        new Among("\u03C4\u03B1\u03C7", -1, 2),
        new Among("\u03C3\u03C7", -1, 2),
        new Among("\u03B1\u03C3\u03C7", 37, 2),
        new Among("\u03C5\u03C8", -1, 2)
    };

    private final static Among[] a_11 = {
        new Among("\u03B9\u03C3\u03C4\u03B1", -1, 1),
        new Among("\u03B9\u03C3\u03C4\u03B5", -1, 1),
        new Among("\u03B9\u03C3\u03C4\u03B7", -1, 1),
        new Among("\u03B9\u03C3\u03C4\u03BF\u03B9", -1, 1),
        new Among("\u03B9\u03C3\u03C4\u03C9\u03BD", -1, 1),
        new Among("\u03B9\u03C3\u03C4\u03BF", -1, 1),
        new Among("\u03B9\u03C3\u03C4\u03B5\u03C3", -1, 1),
        new Among("\u03B9\u03C3\u03C4\u03B7\u03C3", -1, 1),
        new Among("\u03B9\u03C3\u03C4\u03BF\u03C3", -1, 1),
        new Among("\u03B9\u03C3\u03C4\u03BF\u03C5\u03C3", -1, 1),
        new Among("\u03B9\u03C3\u03C4\u03BF\u03C5", -1, 1)
    };

    private final static Among[] a_12 = {
        new Among("\u03B5\u03B3\u03BA\u03BB\u03B5", -1, 1),
        new Among("\u03B1\u03C0\u03BF\u03BA\u03BB\u03B5", -1, 1),
        new Among("\u03B4\u03B1\u03BD\u03B5", -1, 2),
        new Among("\u03B1\u03BD\u03C4\u03B9\u03B4\u03B1\u03BD\u03B5", 2, 2),
        new Among("\u03C3\u03B5", -1, 1),
        new Among("\u03BC\u03B5\u03C4\u03B1\u03C3\u03B5", 4, 1),
        new Among("\u03BC\u03B9\u03BA\u03C1\u03BF\u03C3\u03B5", 4, 1)
    };

    private final static Among[] a_13 = {
        new Among("\u03B1\u03C4\u03BF\u03BC\u03B9\u03BA", -1, 2),
        new Among("\u03B5\u03B8\u03BD\u03B9\u03BA", -1, 4),
        new Among("\u03C4\u03BF\u03C0\u03B9\u03BA", -1, 7),
        new Among("\u03B5\u03BA\u03BB\u03B5\u03BA\u03C4\u03B9\u03BA", -1, 5),
        new Among("\u03C3\u03BA\u03B5\u03C0\u03C4\u03B9\u03BA", -1, 6),
        new Among("\u03B3\u03BD\u03C9\u03C3\u03C4\u03B9\u03BA", -1, 3),
        new Among("\u03B1\u03B3\u03BD\u03C9\u03C3\u03C4\u03B9\u03BA", 5, 1),
        new Among("\u03B1\u03BB\u03B5\u03BE\u03B1\u03BD\u03B4\u03C1\u03B9\u03BD", -1, 8),
        new Among("\u03B8\u03B5\u03B1\u03C4\u03C1\u03B9\u03BD", -1, 10),
        new Among("\u03B2\u03C5\u03B6\u03B1\u03BD\u03C4\u03B9\u03BD", -1, 9)
    };

    private final static Among[] a_14 = {
        new Among("\u03B9\u03C3\u03BC\u03BF\u03B9", -1, 1),
        new Among("\u03B9\u03C3\u03BC\u03C9\u03BD", -1, 1),
        new Among("\u03B9\u03C3\u03BC\u03BF", -1, 1),
        new Among("\u03B9\u03C3\u03BC\u03BF\u03C3", -1, 1),
        new Among("\u03B9\u03C3\u03BC\u03BF\u03C5\u03C3", -1, 1),
        new Among("\u03B9\u03C3\u03BC\u03BF\u03C5", -1, 1)
    };

    private final static Among[] a_15 = {
        new Among("\u03C3", -1, 1),
        new Among("\u03C7", -1, 1)
    };

    private final static Among[] a_16 = {
        new Among("\u03BF\u03C5\u03B4\u03B1\u03BA\u03B9\u03B1", -1, 1),
        new Among("\u03B1\u03C1\u03B1\u03BA\u03B9\u03B1", -1, 1),
        new Among("\u03BF\u03C5\u03B4\u03B1\u03BA\u03B9", -1, 1),
        new Among("\u03B1\u03C1\u03B1\u03BA\u03B9", -1, 1)
    };

    private final static Among[] a_17 = {
        new Among("\u03B2", -1, 2),
        new Among("\u03B2\u03B1\u03BC\u03B2", 0, 1),
        new Among("\u03C3\u03BB\u03BF\u03B2", 0, 1),
        new Among("\u03C4\u03C3\u03B5\u03C7\u03BF\u03C3\u03BB\u03BF\u03B2", 2, 1),
        new Among("\u03BA\u03B1\u03C1\u03B4", -1, 2),
        new Among("\u03B6", -1, 2),
        new Among("\u03C4\u03B6", 5, 1),
        new Among("\u03BA", -1, 1),
        new Among("\u03BA\u03B1\u03C0\u03B1\u03BA", 7, 1),
        new Among("\u03C3\u03BF\u03BA", 7, 1),
        new Among("\u03C3\u03BA", 7, 1),
        new Among("\u03B2\u03B1\u03BB", -1, 2),
        new Among("\u03BC\u03B1\u03BB", -1, 1),
        new Among("\u03B3\u03BB", -1, 2),
        new Among("\u03C4\u03C1\u03B9\u03C0\u03BF\u03BB", -1, 2),
        new Among("\u03C0\u03BB", -1, 1),
        new Among("\u03BB\u03BF\u03C5\u03BB", -1, 1),
        new Among("\u03C6\u03C5\u03BB", -1, 1),
        new Among("\u03BA\u03B1\u03B9\u03BC", -1, 1),
        new Among("\u03BA\u03BB\u03B9\u03BC", -1, 1),
        new Among("\u03C6\u03B1\u03C1\u03BC", -1, 1),
        new Among("\u03B3\u03B9\u03B1\u03BD", -1, 2),
        new Among("\u03C3\u03C0\u03B1\u03BD", -1, 1),
        new Among("\u03B7\u03B3\u03BF\u03C5\u03BC\u03B5\u03BD", -1, 2),
        new Among("\u03BA\u03BF\u03BD", -1, 1),
        new Among("\u03BC\u03B1\u03BA\u03C1\u03C5\u03BD", -1, 2),
        new Among("\u03C0", -1, 2),
        new Among("\u03BA\u03B1\u03C4\u03C1\u03B1\u03C0", 26, 1),
        new Among("\u03C1", -1, 1),
        new Among("\u03B2\u03C1", 28, 1),
        new Among("\u03BB\u03B1\u03B2\u03C1", 29, 1),
        new Among("\u03B1\u03BC\u03B2\u03C1", 29, 1),
        new Among("\u03BC\u03B5\u03C1", 28, 1),
        new Among("\u03C0\u03B1\u03C4\u03B5\u03C1", 28, 2),
        new Among("\u03B1\u03BD\u03B8\u03C1", 28, 1),
        new Among("\u03BA\u03BF\u03C1", 28, 1),
        new Among("\u03C3", -1, 1),
        new Among("\u03BD\u03B1\u03B3\u03BA\u03B1\u03C3", 36, 1),
        new Among("\u03C4\u03BF\u03C3", 36, 2),
        new Among("\u03BC\u03BF\u03C5\u03C3\u03C4", -1, 1),
        new Among("\u03C1\u03C5", -1, 1),
        new Among("\u03C6", -1, 1),
        new Among("\u03C3\u03C6", 41, 1),
        new Among("\u03B1\u03BB\u03B9\u03C3\u03C6", 42, 1),
        new Among("\u03BD\u03C5\u03C6", 41, 2),
        new Among("\u03C7", -1, 1)
    };

    private final static Among[] a_18 = {
        new Among("\u03B1\u03BA\u03B9\u03B1", -1, 1),
        new Among("\u03B1\u03C1\u03B1\u03BA\u03B9\u03B1", 0, 1),
        new Among("\u03B9\u03C4\u03C3\u03B1", -1, 1),
        new Among("\u03B1\u03BA\u03B9", -1, 1),
        new Among("\u03B1\u03C1\u03B1\u03BA\u03B9", 3, 1),
        new Among("\u03B9\u03C4\u03C3\u03C9\u03BD", -1, 1),
        new Among("\u03B9\u03C4\u03C3\u03B1\u03C3", -1, 1),
        new Among("\u03B9\u03C4\u03C3\u03B5\u03C3", -1, 1)
    };

    private final static Among[] a_19 = {
        new Among("\u03C8\u03B1\u03BB", -1, 1),
        new Among("\u03B1\u03B9\u03C6\u03BD", -1, 1),
        new Among("\u03BF\u03BB\u03BF", -1, 1),
        new Among("\u03B9\u03C1", -1, 1)
    };

    private final static Among[] a_20 = {
        new Among("\u03B5", -1, 1),
        new Among("\u03C0\u03B1\u03B9\u03C7\u03BD", -1, 1)
    };

    private final static Among[] a_21 = {
        new Among("\u03B9\u03B4\u03B9\u03B1", -1, 1),
        new Among("\u03B9\u03B4\u03B9\u03C9\u03BD", -1, 1),
        new Among("\u03B9\u03B4\u03B9\u03BF", -1, 1)
    };

    private final static Among[] a_22 = {
        new Among("\u03B9\u03B2", -1, 1),
        new Among("\u03B4", -1, 1),
        new Among("\u03C6\u03C1\u03B1\u03B3\u03BA", -1, 1),
        new Among("\u03BB\u03C5\u03BA", -1, 1),
        new Among("\u03BF\u03B2\u03B5\u03BB", -1, 1),
        new Among("\u03BC\u03B7\u03BD", -1, 1),
        new Among("\u03C1", -1, 1)
    };

    private final static Among[] a_23 = {
        new Among("\u03B9\u03C3\u03BA\u03B5", -1, 1),
        new Among("\u03B9\u03C3\u03BA\u03BF", -1, 1),
        new Among("\u03B9\u03C3\u03BA\u03BF\u03C3", -1, 1),
        new Among("\u03B9\u03C3\u03BA\u03BF\u03C5", -1, 1)
    };

    private final static Among[] a_24 = {
        new Among("\u03B1\u03B4\u03C9\u03BD", -1, 1),
        new Among("\u03B1\u03B4\u03B5\u03C3", -1, 1)
    };

    private final static Among[] a_25 = {
        new Among("\u03B3\u03B9\u03B1\u03B3\u03B9", -1, -1),
        new Among("\u03B8\u03B5\u03B9", -1, -1),
        new Among("\u03BF\u03BA", -1, -1),
        new Among("\u03BC\u03B1\u03BC", -1, -1),
        new Among("\u03BC\u03B1\u03BD", -1, -1),
        new Among("\u03BC\u03C0\u03B1\u03BC\u03C0", -1, -1),
        new Among("\u03C0\u03B5\u03B8\u03B5\u03C1", -1, -1),
        new Among("\u03C0\u03B1\u03C4\u03B5\u03C1", -1, -1),
        new Among("\u03BA\u03C5\u03C1", -1, -1),
        new Among("\u03BD\u03C4\u03B1\u03BD\u03C4", -1, -1)
    };

    private final static Among[] a_26 = {
        new Among("\u03B5\u03B4\u03C9\u03BD", -1, 1),
        new Among("\u03B5\u03B4\u03B5\u03C3", -1, 1)
    };

    private final static Among[] a_27 = {
        new Among("\u03BC\u03B9\u03BB", -1, 1),
        new Among("\u03B4\u03B1\u03C0", -1, 1),
        new Among("\u03B3\u03B7\u03C0", -1, 1),
        new Among("\u03B9\u03C0", -1, 1),
        new Among("\u03B5\u03BC\u03C0", -1, 1),
        new Among("\u03BF\u03C0", -1, 1),
        new Among("\u03BA\u03C1\u03B1\u03C3\u03C0", -1, 1),
        new Among("\u03C5\u03C0", -1, 1)
    };

    private final static Among[] a_28 = {
        new Among("\u03BF\u03C5\u03B4\u03C9\u03BD", -1, 1),
        new Among("\u03BF\u03C5\u03B4\u03B5\u03C3", -1, 1)
    };

    private final static Among[] a_29 = {
        new Among("\u03C4\u03C1\u03B1\u03B3", -1, 1),
        new Among("\u03C6\u03B5", -1, 1),
        new Among("\u03BA\u03B1\u03BB\u03B9\u03B1\u03BA", -1, 1),
        new Among("\u03B1\u03C1\u03BA", -1, 1),
        new Among("\u03C3\u03BA", -1, 1),
        new Among("\u03C0\u03B5\u03C4\u03B1\u03BB", -1, 1),
        new Among("\u03B2\u03B5\u03BB", -1, 1),
        new Among("\u03BB\u03BF\u03C5\u03BB", -1, 1),
        new Among("\u03C6\u03BB", -1, 1),
        new Among("\u03C7\u03BD", -1, 1),
        new Among("\u03C0\u03BB\u03B5\u03BE", -1, 1),
        new Among("\u03C3\u03C0", -1, 1),
        new Among("\u03C6\u03C1", -1, 1),
        new Among("\u03C3", -1, 1),
        new Among("\u03BB\u03B9\u03C7", -1, 1)
    };

    private final static Among[] a_30 = {
        new Among("\u03B5\u03C9\u03BD", -1, 1),
        new Among("\u03B5\u03C9\u03C3", -1, 1)
    };

    private final static Among[] a_31 = {
        new Among("\u03B4", -1, 1),
        new Among("\u03B9\u03B4", 0, 1),
        new Among("\u03B8", -1, 1),
        new Among("\u03B3\u03B1\u03BB", -1, 1),
        new Among("\u03B5\u03BB", -1, 1),
        new Among("\u03BD", -1, 1),
        new Among("\u03C0", -1, 1),
        new Among("\u03C0\u03B1\u03C1", -1, 1)
    };

    private final static Among[] a_32 = {
        new Among("\u03B9\u03B1", -1, 1),
        new Among("\u03B9\u03C9\u03BD", -1, 1),
        new Among("\u03B9\u03BF\u03C5", -1, 1)
    };

    private final static Among[] a_33 = {
        new Among("\u03B9\u03BA\u03B1", -1, 1),
        new Among("\u03B9\u03BA\u03C9\u03BD", -1, 1),
        new Among("\u03B9\u03BA\u03BF", -1, 1),
        new Among("\u03B9\u03BA\u03BF\u03C5", -1, 1)
    };

    private final static Among[] a_34 = {
        new Among("\u03B1\u03B4", -1, 1),
        new Among("\u03C3\u03C5\u03BD\u03B1\u03B4", 0, 1),
        new Among("\u03BA\u03B1\u03C4\u03B1\u03B4", 0, 1),
        new Among("\u03B1\u03BD\u03C4\u03B9\u03B4", -1, 1),
        new Among("\u03B5\u03BD\u03B4", -1, 1),
        new Among("\u03C6\u03C5\u03BB\u03BF\u03B4", -1, 1),
        new Among("\u03C5\u03C0\u03BF\u03B4", -1, 1),
        new Among("\u03C0\u03C1\u03C9\u03C4\u03BF\u03B4", -1, 1),
        new Among("\u03B5\u03BE\u03C9\u03B4", -1, 1),
        new Among("\u03B7\u03B8", -1, 1),
        new Among("\u03B1\u03BD\u03B7\u03B8", 9, 1),
        new Among("\u03BE\u03B9\u03BA", -1, 1),
        new Among("\u03B1\u03BB", -1, 1),
        new Among("\u03B1\u03BC\u03BC\u03BF\u03C7\u03B1\u03BB", 12, 1),
        new Among("\u03C3\u03C5\u03BD\u03BF\u03BC\u03B7\u03BB", -1, 1),
        new Among("\u03BC\u03C0\u03BF\u03BB", -1, 1),
        new Among("\u03BC\u03BF\u03C5\u03BB", -1, 1),
        new Among("\u03C4\u03C3\u03B1\u03BC", -1, 1),
        new Among("\u03B2\u03C1\u03C9\u03BC", -1, 1),
        new Among("\u03B1\u03BC\u03B1\u03BD", -1, 1),
        new Among("\u03BC\u03C0\u03B1\u03BD", -1, 1),
        new Among("\u03BA\u03B1\u03BB\u03BB\u03B9\u03BD", -1, 1),
        new Among("\u03C0\u03BF\u03C3\u03C4\u03B5\u03BB\u03BD", -1, 1),
        new Among("\u03C6\u03B9\u03BB\u03BF\u03BD", -1, 1),
        new Among("\u03BA\u03B1\u03BB\u03C0", -1, 1),
        new Among("\u03B3\u03B5\u03C1", -1, 1),
        new Among("\u03C7\u03B1\u03C3", -1, 1),
        new Among("\u03BC\u03C0\u03BF\u03C3", -1, 1),
        new Among("\u03C0\u03BB\u03B9\u03B1\u03C4\u03C3", -1, 1),
        new Among("\u03C0\u03B5\u03C4\u03C3", -1, 1),
        new Among("\u03C0\u03B9\u03C4\u03C3", -1, 1),
        new Among("\u03C6\u03C5\u03C3", -1, 1),
        new Among("\u03BC\u03C0\u03B1\u03B3\u03B9\u03B1\u03C4", -1, 1),
        new Among("\u03BD\u03B9\u03C4", -1, 1),
        new Among("\u03C0\u03B9\u03BA\u03B1\u03BD\u03C4", -1, 1),
        new Among("\u03C3\u03B5\u03C1\u03C4", -1, 1)
    };

    private final static Among[] a_35 = {
        new Among("\u03B1\u03B3\u03B1\u03BC\u03B5", -1, 1),
        new Among("\u03B7\u03BA\u03B1\u03BC\u03B5", -1, 1),
        new Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03BC\u03B5", 1, 1),
        new Among("\u03B7\u03C3\u03B1\u03BC\u03B5", -1, 1),
        new Among("\u03BF\u03C5\u03C3\u03B1\u03BC\u03B5", -1, 1)
    };

    private final static Among[] a_36 = {
        new Among("\u03B2\u03BF\u03C5\u03B2", -1, 1),
        new Among("\u03BE\u03B5\u03B8", -1, 1),
        new Among("\u03C0\u03B5\u03B8", -1, 1),
        new Among("\u03B1\u03C0\u03BF\u03B8", -1, 1),
        new Among("\u03B1\u03C0\u03BF\u03BA", -1, 1),
        new Among("\u03BF\u03C5\u03BB", -1, 1),
        new Among("\u03B1\u03BD\u03B1\u03C0", -1, 1),
        new Among("\u03C0\u03B9\u03BA\u03C1", -1, 1),
        new Among("\u03C0\u03BF\u03C4", -1, 1),
        new Among("\u03B1\u03C0\u03BF\u03C3\u03C4", -1, 1),
        new Among("\u03C7", -1, 1),
        new Among("\u03C3\u03B9\u03C7", 10, 1)
    };

    private final static Among[] a_37 = {
        new Among("\u03C4\u03C1", -1, 1),
        new Among("\u03C4\u03C3", -1, 1)
    };

    private final static Among[] a_38 = {
        new Among("\u03B1\u03B3\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03B7\u03BA\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03BD\u03B5", 1, 1),
        new Among("\u03B7\u03C3\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03BF\u03C5\u03C3\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03BF\u03BD\u03C4\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03B9\u03BF\u03BD\u03C4\u03B1\u03BD\u03B5", 5, 1),
        new Among("\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03B9\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD\u03B5", 7, 1),
        new Among("\u03BF\u03C4\u03B1\u03BD\u03B5", -1, 1),
        new Among("\u03B9\u03BF\u03C4\u03B1\u03BD\u03B5", 9, 1)
    };

    private final static Among[] a_39 = {
        new Among("\u03C4\u03B1\u03B2", -1, 1),
        new Among("\u03BD\u03C4\u03B1\u03B2", 0, 1),
        new Among("\u03C8\u03B7\u03BB\u03BF\u03C4\u03B1\u03B2", 0, 1),
        new Among("\u03BB\u03B9\u03B2", -1, 1),
        new Among("\u03BA\u03BB\u03B9\u03B2", 3, 1),
        new Among("\u03BE\u03B7\u03C1\u03BF\u03BA\u03BB\u03B9\u03B2", 4, 1),
        new Among("\u03B3", -1, 1),
        new Among("\u03B1\u03B3", 6, 1),
        new Among("\u03C4\u03C1\u03B1\u03B3", 7, 1),
        new Among("\u03C4\u03C3\u03B1\u03B3", 7, 1),
        new Among("\u03B1\u03B8\u03B9\u03B3\u03B3", 6, 1),
        new Among("\u03C4\u03C3\u03B9\u03B3\u03B3", 6, 1),
        new Among("\u03B1\u03C4\u03C3\u03B9\u03B3\u03B3", 11, 1),
        new Among("\u03C3\u03C4\u03B5\u03B3", 6, 1),
        new Among("\u03B1\u03C0\u03B7\u03B3", 6, 1),
        new Among("\u03C3\u03B9\u03B3", 6, 1),
        new Among("\u03B1\u03BD\u03BF\u03C1\u03B3", 6, 1),
        new Among("\u03B5\u03BD\u03BF\u03C1\u03B3", 6, 1),
        new Among("\u03BA\u03B1\u03BB\u03C0\u03BF\u03C5\u03B6", -1, 1),
        new Among("\u03B8", -1, 1),
        new Among("\u03BC\u03C9\u03B1\u03BC\u03B5\u03B8", 19, 1),
        new Among("\u03C0\u03B9\u03B8", 19, 1),
        new Among("\u03B1\u03C0\u03B9\u03B8", 21, 1),
        new Among("\u03B4\u03B5\u03BA", -1, 1),
        new Among("\u03C0\u03B5\u03BB\u03B5\u03BA", -1, 1),
        new Among("\u03B9\u03BA", -1, 1),
        new Among("\u03B1\u03BD\u03B9\u03BA", 25, 1),
        new Among("\u03B2\u03BF\u03C5\u03BB\u03BA", -1, 1),
        new Among("\u03B2\u03B1\u03C3\u03BA", -1, 1),
        new Among("\u03B2\u03C1\u03B1\u03C7\u03C5\u03BA", -1, 1),
        new Among("\u03B3\u03B1\u03BB", -1, 1),
        new Among("\u03BA\u03B1\u03C4\u03B1\u03B3\u03B1\u03BB", 30, 1),
        new Among("\u03BF\u03BB\u03BF\u03B3\u03B1\u03BB", 30, 1),
        new Among("\u03B2\u03B1\u03B8\u03C5\u03B3\u03B1\u03BB", 30, 1),
        new Among("\u03BC\u03B5\u03BB", -1, 1),
        new Among("\u03BA\u03B1\u03C3\u03C4\u03B5\u03BB", -1, 1),
        new Among("\u03C0\u03BF\u03C1\u03C4\u03BF\u03BB", -1, 1),
        new Among("\u03C0\u03BB", -1, 1),
        new Among("\u03B4\u03B9\u03C0\u03BB", 37, 1),
        new Among("\u03BB\u03B1\u03BF\u03C0\u03BB", 37, 1),
        new Among("\u03C8\u03C5\u03C7\u03BF\u03C0\u03BB", 37, 1),
        new Among("\u03BF\u03C5\u03BB", -1, 1),
        new Among("\u03BC", -1, 1),
        new Among("\u03BF\u03BB\u03B9\u03B3\u03BF\u03B4\u03B1\u03BC", 42, 1),
        new Among("\u03BC\u03BF\u03C5\u03C3\u03BF\u03C5\u03BB\u03BC", 42, 1),
        new Among("\u03B4\u03C1\u03B1\u03B4\u03BF\u03C5\u03BC", 42, 1),
        new Among("\u03B2\u03C1\u03B1\u03C7\u03BC", 42, 1),
        new Among("\u03BD", -1, 1),
        new Among("\u03B1\u03BC\u03B5\u03C1\u03B9\u03BA\u03B1\u03BD", 47, 1),
        new Among("\u03C0", -1, 1),
        new Among("\u03B1\u03B4\u03B1\u03C0", 49, 1),
        new Among("\u03C7\u03B1\u03BC\u03B7\u03BB\u03BF\u03B4\u03B1\u03C0", 49, 1),
        new Among("\u03C0\u03BF\u03BB\u03C5\u03B4\u03B1\u03C0", 49, 1),
        new Among("\u03BA\u03BF\u03C0", 49, 1),
        new Among("\u03C5\u03C0\u03BF\u03BA\u03BF\u03C0", 53, 1),
        new Among("\u03C4\u03C3\u03BF\u03C0", 49, 1),
        new Among("\u03C3\u03C0", 49, 1),
        new Among("\u03B5\u03C1", -1, 1),
        new Among("\u03B3\u03B5\u03C1", 57, 1),
        new Among("\u03B2\u03B5\u03C4\u03B5\u03C1", 57, 1),
        new Among("\u03BB\u03BF\u03C5\u03B8\u03B7\u03C1", -1, 1),
        new Among("\u03BA\u03BF\u03C1\u03BC\u03BF\u03C1", -1, 1),
        new Among("\u03C0\u03B5\u03C1\u03B9\u03C4\u03C1", -1, 1),
        new Among("\u03BF\u03C5\u03C1", -1, 1),
        new Among("\u03C3", -1, 1),
        new Among("\u03B2\u03B1\u03C3", 64, 1),
        new Among("\u03C0\u03BF\u03BB\u03B9\u03C3", 64, 1),
        new Among("\u03C3\u03B1\u03C1\u03B1\u03BA\u03B1\u03C4\u03C3", 64, 1),
        new Among("\u03B8\u03C5\u03C3", 64, 1),
        new Among("\u03B4\u03B9\u03B1\u03C4", -1, 1),
        new Among("\u03C0\u03BB\u03B1\u03C4", -1, 1),
        new Among("\u03C4\u03C3\u03B1\u03C1\u03BB\u03B1\u03C4", -1, 1),
        new Among("\u03C4\u03B5\u03C4", -1, 1),
        new Among("\u03C0\u03BF\u03C5\u03C1\u03B9\u03C4", -1, 1),
        new Among("\u03C3\u03BF\u03C5\u03BB\u03C4", -1, 1),
        new Among("\u03BC\u03B1\u03B9\u03BD\u03C4", -1, 1),
        new Among("\u03B6\u03C9\u03BD\u03C4", -1, 1),
        new Among("\u03BA\u03B1\u03C3\u03C4", -1, 1),
        new Among("\u03C6", -1, 1),
        new Among("\u03B4\u03B9\u03B1\u03C6", 78, 1),
        new Among("\u03C3\u03C4\u03B5\u03C6", 78, 1),
        new Among("\u03C6\u03C9\u03C4\u03BF\u03C3\u03C4\u03B5\u03C6", 80, 1),
        new Among("\u03C0\u03B5\u03C1\u03B7\u03C6", 78, 1),
        new Among("\u03C5\u03C0\u03B5\u03C1\u03B7\u03C6", 82, 1),
        new Among("\u03BA\u03BF\u03B9\u03BB\u03B1\u03C1\u03C6", 78, 1),
        new Among("\u03C0\u03B5\u03BD\u03C4\u03B1\u03C1\u03C6", 78, 1),
        new Among("\u03BF\u03C1\u03C6", 78, 1),
        new Among("\u03C7", -1, 1),
        new Among("\u03B1\u03BC\u03B7\u03C7", 87, 1),
        new Among("\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 87, 1),
        new Among("\u03BC\u03B5\u03B3\u03BB\u03BF\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 89, 1),
        new Among("\u03BA\u03B1\u03C0\u03BD\u03BF\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 89, 1),
        new Among("\u03BC\u03B9\u03BA\u03C1\u03BF\u03B2\u03B9\u03BF\u03BC\u03B7\u03C7", 89, 1),
        new Among("\u03C0\u03BF\u03BB\u03C5\u03BC\u03B7\u03C7", 87, 1),
        new Among("\u03BB\u03B9\u03C7", 87, 1)
    };

    private final static Among[] a_40 = {
        new Among("\u03B5\u03BD\u03B4", -1, 1),
        new Among("\u03C3\u03C5\u03BD\u03B4", -1, 1),
        new Among("\u03BF\u03B4", -1, 1),
        new Among("\u03B4\u03B9\u03B1\u03B8", -1, 1),
        new Among("\u03BA\u03B1\u03B8", -1, 1),
        new Among("\u03C1\u03B1\u03B8", -1, 1),
        new Among("\u03C4\u03B1\u03B8", -1, 1),
        new Among("\u03C4\u03B9\u03B8", -1, 1),
        new Among("\u03B5\u03BA\u03B8", -1, 1),
        new Among("\u03B5\u03BD\u03B8", -1, 1),
        new Among("\u03C3\u03C5\u03BD\u03B8", -1, 1),
        new Among("\u03C1\u03BF\u03B8", -1, 1),
        new Among("\u03C5\u03C0\u03B5\u03C1\u03B8", -1, 1),
        new Among("\u03C3\u03B8", -1, 1),
        new Among("\u03B5\u03C5\u03B8", -1, 1),
        new Among("\u03B1\u03C1\u03BA", -1, 1),
        new Among("\u03C9\u03C6\u03B5\u03BB", -1, 1),
        new Among("\u03B2\u03BF\u03BB", -1, 1),
        new Among("\u03B1\u03B9\u03BD", -1, 1),
        new Among("\u03C0\u03BF\u03BD", -1, 1),
        new Among("\u03C1\u03BF\u03BD", -1, 1),
        new Among("\u03C3\u03C5\u03BD", -1, 1),
        new Among("\u03B2\u03B1\u03C1", -1, 1),
        new Among("\u03B2\u03C1", -1, 1),
        new Among("\u03B1\u03B9\u03C1", -1, 1),
        new Among("\u03C6\u03BF\u03C1", -1, 1),
        new Among("\u03B5\u03C5\u03C1", -1, 1),
        new Among("\u03C0\u03C5\u03C1", -1, 1),
        new Among("\u03C7\u03C9\u03C1", -1, 1),
        new Among("\u03BD\u03B5\u03C4", -1, 1),
        new Among("\u03C3\u03C7", -1, 1)
    };

    private final static Among[] a_41 = {
        new Among("\u03C0\u03B1\u03B3", -1, 1),
        new Among("\u03B4", -1, 1),
        new Among("\u03B1\u03B4", 1, 1),
        new Among("\u03B8", -1, 1),
        new Among("\u03B1\u03B8", 3, 1),
        new Among("\u03C4\u03BF\u03BA", -1, 1),
        new Among("\u03C3\u03BA", -1, 1),
        new Among("\u03C0\u03B1\u03C1\u03B1\u03BA\u03B1\u03BB", -1, 1),
        new Among("\u03C3\u03BA\u03B5\u03BB", -1, 1),
        new Among("\u03B1\u03C0\u03BB", -1, 1),
        new Among("\u03B5\u03BC", -1, 1),
        new Among("\u03B1\u03BD", -1, 1),
        new Among("\u03B2\u03B5\u03BD", -1, 1),
        new Among("\u03B2\u03B1\u03C1\u03BF\u03BD", -1, 1),
        new Among("\u03BA\u03BF\u03C0", -1, 1),
        new Among("\u03C3\u03B5\u03C1\u03C0", -1, 1),
        new Among("\u03B1\u03B2\u03B1\u03C1", -1, 1),
        new Among("\u03B5\u03BD\u03B1\u03C1", -1, 1),
        new Among("\u03B1\u03B2\u03C1", -1, 1),
        new Among("\u03BC\u03C0\u03BF\u03C1", -1, 1),
        new Among("\u03B8\u03B1\u03C1\u03C1", -1, 1),
        new Among("\u03BD\u03C4\u03C1", -1, 1),
        new Among("\u03C5", -1, 1),
        new Among("\u03BD\u03B9\u03C6", -1, 1),
        new Among("\u03C3\u03C5\u03C1\u03C6", -1, 1)
    };

    private final static Among[] a_42 = {
        new Among("\u03BF\u03BD\u03C4\u03B1\u03C3", -1, 1),
        new Among("\u03C9\u03BD\u03C4\u03B1\u03C3", -1, 1)
    };

    private final static Among[] a_43 = {
        new Among("\u03BF\u03BC\u03B1\u03C3\u03C4\u03B5", -1, 1),
        new Among("\u03B9\u03BF\u03BC\u03B1\u03C3\u03C4\u03B5", 0, 1)
    };

    private final static Among[] a_44 = {
        new Among("\u03C0", -1, 1),
        new Among("\u03B1\u03C0", 0, 1),
        new Among("\u03B1\u03BA\u03B1\u03C4\u03B1\u03C0", 1, 1),
        new Among("\u03C3\u03C5\u03BC\u03C0", 0, 1),
        new Among("\u03B1\u03C3\u03C5\u03BC\u03C0", 3, 1),
        new Among("\u03B1\u03BC\u03B5\u03C4\u03B1\u03BC\u03C6", -1, 1)
    };

    private final static Among[] a_45 = {
        new Among("\u03B6", -1, 1),
        new Among("\u03B1\u03BB", -1, 1),
        new Among("\u03C0\u03B1\u03C1\u03B1\u03BA\u03B1\u03BB", 1, 1),
        new Among("\u03B5\u03BA\u03C4\u03B5\u03BB", -1, 1),
        new Among("\u03BC", -1, 1),
        new Among("\u03BE", -1, 1),
        new Among("\u03C0\u03C1\u03BF", -1, 1),
        new Among("\u03B1\u03C1", -1, 1),
        new Among("\u03BD\u03B9\u03C3", -1, 1)
    };

    private final static Among[] a_46 = {
        new Among("\u03B7\u03B8\u03B7\u03BA\u03B1", -1, 1),
        new Among("\u03B7\u03B8\u03B7\u03BA\u03B5", -1, 1),
        new Among("\u03B7\u03B8\u03B7\u03BA\u03B5\u03C3", -1, 1)
    };

    private final static Among[] a_47 = {
        new Among("\u03C0\u03B9\u03B8", -1, 1),
        new Among("\u03BF\u03B8", -1, 1),
        new Among("\u03BD\u03B1\u03C1\u03B8", -1, 1),
        new Among("\u03C3\u03BA\u03BF\u03C5\u03BB", -1, 1),
        new Among("\u03C3\u03BA\u03C9\u03BB", -1, 1),
        new Among("\u03C3\u03C6", -1, 1)
    };

    private final static Among[] a_48 = {
        new Among("\u03B8", -1, 1),
        new Among("\u03B4\u03B9\u03B1\u03B8", 0, 1),
        new Among("\u03C0\u03B1\u03C1\u03B1\u03BA\u03B1\u03C4\u03B1\u03B8", 0, 1),
        new Among("\u03C3\u03C5\u03BD\u03B8", 0, 1),
        new Among("\u03C0\u03C1\u03BF\u03C3\u03B8", 0, 1)
    };

    private final static Among[] a_49 = {
        new Among("\u03B7\u03BA\u03B1", -1, 1),
        new Among("\u03B7\u03BA\u03B5", -1, 1),
        new Among("\u03B7\u03BA\u03B5\u03C3", -1, 1)
    };

    private final static Among[] a_50 = {
        new Among("\u03C6\u03B1\u03B3", -1, 1),
        new Among("\u03BB\u03B7\u03B3", -1, 1),
        new Among("\u03C6\u03C1\u03C5\u03B4", -1, 1),
        new Among("\u03BC\u03B1\u03BD\u03C4\u03B9\u03BB", -1, 1),
        new Among("\u03BC\u03B1\u03BB\u03BB", -1, 1),
        new Among("\u03BF\u03BC", -1, 1),
        new Among("\u03B2\u03BB\u03B5\u03C0", -1, 1),
        new Among("\u03C0\u03BF\u03B4\u03B1\u03C1", -1, 1),
        new Among("\u03BA\u03C5\u03BC\u03B1\u03C4", -1, 1),
        new Among("\u03C0\u03C1\u03C9\u03C4", -1, 1),
        new Among("\u03BB\u03B1\u03C7", -1, 1),
        new Among("\u03C0\u03B1\u03BD\u03C4\u03B1\u03C7", -1, 1)
    };

    private final static Among[] a_51 = {
        new Among("\u03C4\u03C3\u03B1", -1, 1),
        new Among("\u03C7\u03B1\u03B4", -1, 1),
        new Among("\u03BC\u03B5\u03B4", -1, 1),
        new Among("\u03BB\u03B1\u03BC\u03C0\u03B9\u03B4", -1, 1),
        new Among("\u03B4\u03B5", -1, 1),
        new Among("\u03C0\u03BB\u03B5", -1, 1),
        new Among("\u03BC\u03B5\u03C3\u03B1\u03B6", -1, 1),
        new Among("\u03B4\u03B5\u03C3\u03C0\u03BF\u03B6", -1, 1),
        new Among("\u03B1\u03B9\u03B8", -1, 1),
        new Among("\u03C6\u03B1\u03C1\u03BC\u03B1\u03BA", -1, 1),
        new Among("\u03B1\u03B3\u03BA", -1, 1),
        new Among("\u03B1\u03BD\u03B7\u03BA", -1, 1),
        new Among("\u03BB", -1, 1),
        new Among("\u03BC", -1, 1),
        new Among("\u03B1\u03BC", 13, 1),
        new Among("\u03B2\u03C1\u03BF\u03BC", 13, 1),
        new Among("\u03C5\u03C0\u03BF\u03C4\u03B5\u03B9\u03BD", -1, 1),
        new Among("\u03B5\u03BA\u03BB\u03B9\u03C0", -1, 1),
        new Among("\u03C1", -1, 1),
        new Among("\u03B5\u03BD\u03B4\u03B9\u03B1\u03C6\u03B5\u03C1", 18, 1),
        new Among("\u03B1\u03BD\u03B1\u03C1\u03C1", 18, 1),
        new Among("\u03C0\u03B1\u03C4", -1, 1),
        new Among("\u03BA\u03B1\u03B8\u03B1\u03C1\u03B5\u03C5", -1, 1),
        new Among("\u03B4\u03B5\u03C5\u03C4\u03B5\u03C1\u03B5\u03C5", -1, 1),
        new Among("\u03BB\u03B5\u03C7", -1, 1)
    };

    private final static Among[] a_52 = {
        new Among("\u03BF\u03C5\u03C3\u03B1", -1, 1),
        new Among("\u03BF\u03C5\u03C3\u03B5", -1, 1),
        new Among("\u03BF\u03C5\u03C3\u03B5\u03C3", -1, 1)
    };

    private final static Among[] a_53 = {
        new Among("\u03C0\u03B5\u03BB", -1, 1),
        new Among("\u03BB\u03BB", -1, 1),
        new Among("\u03C3\u03BC\u03B7\u03BD", -1, 1),
        new Among("\u03C1\u03C0", -1, 1),
        new Among("\u03C0\u03C1", -1, 1),
        new Among("\u03C6\u03C1", -1, 1),
        new Among("\u03C7\u03BF\u03C1\u03C4", -1, 1),
        new Among("\u03BF\u03C6", -1, 1),
        new Among("\u03C8\u03BF\u03C6", 7, -1),
        new Among("\u03C3\u03C6", -1, 1),
        new Among("\u03BB\u03BF\u03C7", -1, 1),
        new Among("\u03BD\u03B1\u03C5\u03BB\u03BF\u03C7", 10, -1)
    };

    private final static Among[] a_54 = {
        new Among("\u03B1\u03BC\u03B1\u03BB\u03BB\u03B9", -1, 1),
        new Among("\u03BB", -1, 1),
        new Among("\u03B1\u03BC\u03B1\u03BB", 1, 1),
        new Among("\u03BC", -1, 1),
        new Among("\u03BF\u03C5\u03BB\u03B1\u03BC", 3, 1),
        new Among("\u03B5\u03BD", -1, 1),
        new Among("\u03B4\u03B5\u03C1\u03B2\u03B5\u03BD", 5, 1),
        new Among("\u03C0", -1, 1),
        new Among("\u03B1\u03B5\u03B9\u03C0", 7, 1),
        new Among("\u03B1\u03C1\u03C4\u03B9\u03C0", 7, 1),
        new Among("\u03C3\u03C5\u03BC\u03C0", 7, 1),
        new Among("\u03BD\u03B5\u03BF\u03C0", 7, 1),
        new Among("\u03BA\u03C1\u03BF\u03BA\u03B1\u03BB\u03BF\u03C0", 7, 1),
        new Among("\u03BF\u03BB\u03BF\u03C0", 7, 1),
        new Among("\u03C0\u03C1\u03BF\u03C3\u03C9\u03C0\u03BF\u03C0", 7, 1),
        new Among("\u03C3\u03B9\u03B4\u03B7\u03C1\u03BF\u03C0", 7, 1),
        new Among("\u03B4\u03C1\u03BF\u03C3\u03BF\u03C0", 7, 1),
        new Among("\u03B1\u03C3\u03C0", 7, 1),
        new Among("\u03B1\u03BD\u03C5\u03C0", 7, 1),
        new Among("\u03C1", -1, 1),
        new Among("\u03B1\u03C3\u03C0\u03B1\u03C1", 19, 1),
        new Among("\u03C7\u03B1\u03C1", 19, 1),
        new Among("\u03B1\u03C7\u03B1\u03C1", 21, 1),
        new Among("\u03B1\u03C0\u03B5\u03C1", 19, 1),
        new Among("\u03C4\u03C1", 19, 1),
        new Among("\u03BF\u03C5\u03C1", 19, 1),
        new Among("\u03C4", -1, 1),
        new Among("\u03B4\u03B9\u03B1\u03C4", 26, 1),
        new Among("\u03B5\u03C0\u03B9\u03C4", 26, 1),
        new Among("\u03C3\u03C5\u03BD\u03C4", 26, 1),
        new Among("\u03BF\u03BC\u03BF\u03C4", 26, 1),
        new Among("\u03BD\u03BF\u03BC\u03BF\u03C4", 30, 1),
        new Among("\u03B1\u03C0\u03BF\u03C4", 26, 1),
        new Among("\u03C5\u03C0\u03BF\u03C4", 26, 1),
        new Among("\u03B1\u03B2\u03B1\u03C3\u03C4", 26, 1),
        new Among("\u03B1\u03B9\u03BC\u03BF\u03C3\u03C4", 26, 1),
        new Among("\u03C0\u03C1\u03BF\u03C3\u03C4", 26, 1),
        new Among("\u03B1\u03BD\u03C5\u03C3\u03C4", 26, 1),
        new Among("\u03BD\u03B1\u03C5", -1, 1),
        new Among("\u03B1\u03C6", -1, 1),
        new Among("\u03BE\u03B5\u03C6", -1, 1),
        new Among("\u03B1\u03B4\u03B7\u03C6", -1, 1),
        new Among("\u03C0\u03B1\u03BC\u03C6", -1, 1),
        new Among("\u03C0\u03BF\u03BB\u03C5\u03C6", -1, 1)
    };

    private final static Among[] a_55 = {
        new Among("\u03B1\u03B3\u03B1", -1, 1),
        new Among("\u03B1\u03B3\u03B5", -1, 1),
        new Among("\u03B1\u03B3\u03B5\u03C3", -1, 1)
    };

    private final static Among[] a_56 = {
        new Among("\u03B7\u03C3\u03B1", -1, 1),
        new Among("\u03B7\u03C3\u03B5", -1, 1),
        new Among("\u03B7\u03C3\u03BF\u03C5", -1, 1)
    };

    private final static Among[] a_57 = {
        new Among("\u03BD", -1, 1),
        new Among("\u03B4\u03C9\u03B4\u03B5\u03BA\u03B1\u03BD", 0, 1),
        new Among("\u03B5\u03C0\u03C4\u03B1\u03BD", 0, 1),
        new Among("\u03BC\u03B5\u03B3\u03B1\u03BB\u03BF\u03BD", 0, 1),
        new Among("\u03B5\u03C1\u03B7\u03BC\u03BF\u03BD", 0, 1),
        new Among("\u03C7\u03B5\u03C1\u03C3\u03BF\u03BD", 0, 1)
    };

    private final static Among[] a_58 = {
        new Among("\u03C3\u03B2", -1, 1),
        new Among("\u03B1\u03C3\u03B2", 0, 1),
        new Among("\u03B1\u03C0\u03BB", -1, 1),
        new Among("\u03B1\u03B5\u03B9\u03BC\u03BD", -1, 1),
        new Among("\u03C7\u03C1", -1, 1),
        new Among("\u03B1\u03C7\u03C1", 4, 1),
        new Among("\u03BA\u03BF\u03B9\u03BD\u03BF\u03C7\u03C1", 4, 1),
        new Among("\u03B4\u03C5\u03C3\u03C7\u03C1", 4, 1),
        new Among("\u03B5\u03C5\u03C7\u03C1", 4, 1),
        new Among("\u03C0\u03B1\u03BB\u03B9\u03BC\u03C8", -1, 1)
    };

    private final static Among[] a_59 = {
        new Among("\u03BF\u03C5\u03BD\u03B5", -1, 1),
        new Among("\u03B7\u03B8\u03BF\u03C5\u03BD\u03B5", 0, 1),
        new Among("\u03B7\u03C3\u03BF\u03C5\u03BD\u03B5", 0, 1)
    };

    private final static Among[] a_60 = {
        new Among("\u03C3\u03C0\u03B9", -1, 1),
        new Among("\u03BD", -1, 1),
        new Among("\u03B5\u03BE\u03C9\u03BD", 1, 1),
        new Among("\u03C1", -1, 1),
        new Among("\u03C3\u03C4\u03C1\u03B1\u03B2\u03BF\u03BC\u03BF\u03C5\u03C4\u03C3", -1, 1),
        new Among("\u03BA\u03B1\u03BA\u03BF\u03BC\u03BF\u03C5\u03C4\u03C3", -1, 1)
    };

    private final static Among[] a_61 = {
        new Among("\u03BF\u03C5\u03BC\u03B5", -1, 1),
        new Among("\u03B7\u03B8\u03BF\u03C5\u03BC\u03B5", 0, 1),
        new Among("\u03B7\u03C3\u03BF\u03C5\u03BC\u03B5", 0, 1)
    };

    private final static Among[] a_62 = {
        new Among("\u03B1\u03B6", -1, 1),
        new Among("\u03C9\u03C1\u03B9\u03BF\u03C0\u03BB", -1, 1),
        new Among("\u03B1\u03C3\u03BF\u03C5\u03C3", -1, 1),
        new Among("\u03C0\u03B1\u03C1\u03B1\u03C3\u03BF\u03C5\u03C3", 2, 1),
        new Among("\u03B1\u03BB\u03BB\u03BF\u03C3\u03BF\u03C5\u03C3", -1, 1),
        new Among("\u03C6", -1, 1),
        new Among("\u03C7", -1, 1)
    };

    private final static Among[] a_63 = {
        new Among("\u03BC\u03B1\u03C4\u03B1", -1, 1),
        new Among("\u03BC\u03B1\u03C4\u03C9\u03BD", -1, 1),
        new Among("\u03BC\u03B1\u03C4\u03BF\u03C3", -1, 1)
    };

    private final static Among[] a_64 = {
        new Among("\u03B1", -1, 1),
        new Among("\u03B9\u03BF\u03C5\u03BC\u03B1", 0, 1),
        new Among("\u03BF\u03BC\u03BF\u03C5\u03BD\u03B1", 0, 1),
        new Among("\u03B9\u03BF\u03BC\u03BF\u03C5\u03BD\u03B1", 2, 1),
        new Among("\u03BF\u03C3\u03BF\u03C5\u03BD\u03B1", 0, 1),
        new Among("\u03B9\u03BF\u03C3\u03BF\u03C5\u03BD\u03B1", 4, 1),
        new Among("\u03B5", -1, 1),
        new Among("\u03B1\u03B3\u03B1\u03C4\u03B5", 6, 1),
        new Among("\u03B7\u03BA\u03B1\u03C4\u03B5", 6, 1),
        new Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03C4\u03B5", 8, 1),
        new Among("\u03B7\u03C3\u03B1\u03C4\u03B5", 6, 1),
        new Among("\u03BF\u03C5\u03C3\u03B1\u03C4\u03B5", 6, 1),
        new Among("\u03B5\u03B9\u03C4\u03B5", 6, 1),
        new Among("\u03B7\u03B8\u03B5\u03B9\u03C4\u03B5", 12, 1),
        new Among("\u03B9\u03B5\u03BC\u03B1\u03C3\u03C4\u03B5", 6, 1),
        new Among("\u03BF\u03C5\u03BC\u03B1\u03C3\u03C4\u03B5", 6, 1),
        new Among("\u03B9\u03BF\u03C5\u03BC\u03B1\u03C3\u03C4\u03B5", 15, 1),
        new Among("\u03B9\u03B5\u03C3\u03B1\u03C3\u03C4\u03B5", 6, 1),
        new Among("\u03BF\u03C3\u03B1\u03C3\u03C4\u03B5", 6, 1),
        new Among("\u03B9\u03BF\u03C3\u03B1\u03C3\u03C4\u03B5", 18, 1),
        new Among("\u03B7", -1, 1),
        new Among("\u03B9", -1, 1),
        new Among("\u03B1\u03BC\u03B1\u03B9", 21, 1),
        new Among("\u03B9\u03B5\u03BC\u03B1\u03B9", 21, 1),
        new Among("\u03BF\u03BC\u03B1\u03B9", 21, 1),
        new Among("\u03BF\u03C5\u03BC\u03B1\u03B9", 21, 1),
        new Among("\u03B1\u03C3\u03B1\u03B9", 21, 1),
        new Among("\u03B5\u03C3\u03B1\u03B9", 21, 1),
        new Among("\u03B9\u03B5\u03C3\u03B1\u03B9", 27, 1),
        new Among("\u03B1\u03C4\u03B1\u03B9", 21, 1),
        new Among("\u03B5\u03C4\u03B1\u03B9", 21, 1),
        new Among("\u03B9\u03B5\u03C4\u03B1\u03B9", 30, 1),
        new Among("\u03BF\u03BD\u03C4\u03B1\u03B9", 21, 1),
        new Among("\u03BF\u03C5\u03BD\u03C4\u03B1\u03B9", 21, 1),
        new Among("\u03B9\u03BF\u03C5\u03BD\u03C4\u03B1\u03B9", 33, 1),
        new Among("\u03B5\u03B9", 21, 1),
        new Among("\u03B1\u03B5\u03B9", 35, 1),
        new Among("\u03B7\u03B8\u03B5\u03B9", 35, 1),
        new Among("\u03B7\u03C3\u03B5\u03B9", 35, 1),
        new Among("\u03BF\u03B9", 21, 1),
        new Among("\u03B1\u03BD", -1, 1),
        new Among("\u03B1\u03B3\u03B1\u03BD", 40, 1),
        new Among("\u03B7\u03BA\u03B1\u03BD", 40, 1),
        new Among("\u03B7\u03B8\u03B7\u03BA\u03B1\u03BD", 42, 1),
        new Among("\u03B7\u03C3\u03B1\u03BD", 40, 1),
        new Among("\u03BF\u03C5\u03C3\u03B1\u03BD", 40, 1),
        new Among("\u03BF\u03BD\u03C4\u03BF\u03C5\u03C3\u03B1\u03BD", 45, 1),
        new Among("\u03B9\u03BF\u03BD\u03C4\u03BF\u03C5\u03C3\u03B1\u03BD", 46, 1),
        new Among("\u03BF\u03BD\u03C4\u03B1\u03BD", 40, 1),
        new Among("\u03B9\u03BF\u03BD\u03C4\u03B1\u03BD", 48, 1),
        new Among("\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD", 40, 1),
        new Among("\u03B9\u03BF\u03C5\u03BD\u03C4\u03B1\u03BD", 50, 1),
        new Among("\u03BF\u03C4\u03B1\u03BD", 40, 1),
        new Among("\u03B9\u03BF\u03C4\u03B1\u03BD", 52, 1),
        new Among("\u03BF\u03BC\u03B1\u03C3\u03C4\u03B1\u03BD", 40, 1),
        new Among("\u03B9\u03BF\u03BC\u03B1\u03C3\u03C4\u03B1\u03BD", 54, 1),
        new Among("\u03BF\u03C3\u03B1\u03C3\u03C4\u03B1\u03BD", 40, 1),
        new Among("\u03B9\u03BF\u03C3\u03B1\u03C3\u03C4\u03B1\u03BD", 56, 1),
        new Among("\u03BF\u03C5\u03BD", -1, 1),
        new Among("\u03B7\u03B8\u03BF\u03C5\u03BD", 58, 1),
        new Among("\u03BF\u03BC\u03BF\u03C5\u03BD", 58, 1),
        new Among("\u03B9\u03BF\u03BC\u03BF\u03C5\u03BD", 60, 1),
        new Among("\u03B7\u03C3\u03BF\u03C5\u03BD", 58, 1),
        new Among("\u03BF\u03C3\u03BF\u03C5\u03BD", 58, 1),
        new Among("\u03B9\u03BF\u03C3\u03BF\u03C5\u03BD", 63, 1),
        new Among("\u03C9\u03BD", -1, 1),
        new Among("\u03B7\u03B4\u03C9\u03BD", 65, 1),
        new Among("\u03BF", -1, 1),
        new Among("\u03B1\u03C3", -1, 1),
        new Among("\u03B5\u03C3", -1, 1),
        new Among("\u03B7\u03B4\u03B5\u03C3", 69, 1),
        new Among("\u03B7\u03C3\u03B5\u03C3", 69, 1),
        new Among("\u03B7\u03C3", -1, 1),
        new Among("\u03B5\u03B9\u03C3", -1, 1),
        new Among("\u03B7\u03B8\u03B5\u03B9\u03C3", 73, 1),
        new Among("\u03BF\u03C3", -1, 1),
        new Among("\u03C5\u03C3", -1, 1),
        new Among("\u03BF\u03C5\u03C3", 76, 1),
        new Among("\u03C5", -1, 1),
        new Among("\u03BF\u03C5", 78, 1),
        new Among("\u03C9", -1, 1),
        new Among("\u03B1\u03C9", 80, 1),
        new Among("\u03B7\u03B8\u03C9", 80, 1),
        new Among("\u03B7\u03C3\u03C9", 80, 1)
    };

    private final static Among[] a_65 = {
        new Among("\u03BF\u03C4\u03B5\u03C1", -1, 1),
        new Among("\u03B5\u03C3\u03C4\u03B5\u03C1", -1, 1),
        new Among("\u03C5\u03C4\u03B5\u03C1", -1, 1),
        new Among("\u03C9\u03C4\u03B5\u03C1", -1, 1),
        new Among("\u03BF\u03C4\u03B1\u03C4", -1, 1),
        new Among("\u03B5\u03C3\u03C4\u03B1\u03C4", -1, 1),
        new Among("\u03C5\u03C4\u03B1\u03C4", -1, 1),
        new Among("\u03C9\u03C4\u03B1\u03C4", -1, 1)
    };

    private static final char[] g_v = {81, 65, 16, 1 };

    private static final char[] g_v2 = {81, 65, 0, 1 };


    @Override
    public boolean stem() {
        int among_var;
        boolean B_test1;
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        lab0: {
            while (true)
            {
                int v_2 = limit - cursor;
                lab1: {
                    ket = cursor;
                    among_var = find_among_b(a_0);
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("\u03B1");
                            break;
                        case 2:
                            slice_from("\u03B2");
                            break;
                        case 3:
                            slice_from("\u03B3");
                            break;
                        case 4:
                            slice_from("\u03B4");
                            break;
                        case 5:
                            slice_from("\u03B5");
                            break;
                        case 6:
                            slice_from("\u03B6");
                            break;
                        case 7:
                            slice_from("\u03B7");
                            break;
                        case 8:
                            slice_from("\u03B8");
                            break;
                        case 9:
                            slice_from("\u03B9");
                            break;
                        case 10:
                            slice_from("\u03BA");
                            break;
                        case 11:
                            slice_from("\u03BB");
                            break;
                        case 12:
                            slice_from("\u03BC");
                            break;
                        case 13:
                            slice_from("\u03BD");
                            break;
                        case 14:
                            slice_from("\u03BE");
                            break;
                        case 15:
                            slice_from("\u03BF");
                            break;
                        case 16:
                            slice_from("\u03C0");
                            break;
                        case 17:
                            slice_from("\u03C1");
                            break;
                        case 18:
                            slice_from("\u03C3");
                            break;
                        case 19:
                            slice_from("\u03C4");
                            break;
                        case 20:
                            slice_from("\u03C5");
                            break;
                        case 21:
                            slice_from("\u03C6");
                            break;
                        case 22:
                            slice_from("\u03C7");
                            break;
                        case 23:
                            slice_from("\u03C8");
                            break;
                        case 24:
                            slice_from("\u03C9");
                            break;
                        case 25:
                            if (cursor <= limit_backward)
                            {
                                break lab1;
                            }
                            cursor--;
                            break;
                    }
                    continue;
                }
                cursor = limit - v_2;
                break;
            }
        }
        cursor = limit - v_1;
        if (length < 3)
        {
            return false;
        }
        B_test1 = true;
        int v_3 = limit - cursor;
        lab2: {
            ket = cursor;
            among_var = find_among_b(a_1);
            if (among_var == 0)
            {
                break lab2;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_from("\u03C6\u03B1");
                    break;
                case 2:
                    slice_from("\u03C3\u03BA\u03B1");
                    break;
                case 3:
                    slice_from("\u03BF\u03BB\u03BF");
                    break;
                case 4:
                    slice_from("\u03C3\u03BF");
                    break;
                case 5:
                    slice_from("\u03C4\u03B1\u03C4\u03BF");
                    break;
                case 6:
                    slice_from("\u03BA\u03C1\u03B5");
                    break;
                case 7:
                    slice_from("\u03C0\u03B5\u03C1");
                    break;
                case 8:
                    slice_from("\u03C4\u03B5\u03C1");
                    break;
                case 9:
                    slice_from("\u03C6\u03C9");
                    break;
                case 10:
                    slice_from("\u03BA\u03B1\u03B8\u03B5\u03C3\u03C4");
                    break;
                case 11:
                    slice_from("\u03B3\u03B5\u03B3\u03BF\u03BD");
                    break;
            }
            B_test1 = false;
        }
        cursor = limit - v_3;
        int v_4 = limit - cursor;
        lab3: {
            ket = cursor;
            if (find_among_b(a_3) == 0)
            {
                break lab3;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            among_var = find_among_b(a_2);
            if (among_var == 0)
            {
                break lab3;
            }
            if (cursor > limit_backward)
            {
                break lab3;
            }
            switch (among_var) {
                case 1:
                    slice_from("\u03B9");
                    break;
                case 2:
                    slice_from("\u03B9\u03B6");
                    break;
            }
        }
        cursor = limit - v_4;
        int v_5 = limit - cursor;
        lab4: {
            ket = cursor;
            if (find_among_b(a_5) == 0)
            {
                break lab4;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_4) == 0)
            {
                break lab4;
            }
            if (cursor > limit_backward)
            {
                break lab4;
            }
            slice_from("\u03C9\u03BD");
        }
        cursor = limit - v_5;
        int v_6 = limit - cursor;
        lab5: {
            lab6: {
                int v_7 = limit - cursor;
                lab7: {
                    ket = cursor;
                    if (!(eq_s_b("\u03B9\u03C3\u03B1")))
                    {
                        break lab7;
                    }
                    bra = cursor;
                    if (cursor > limit_backward)
                    {
                        break lab7;
                    }
                    slice_from("\u03B9\u03C3");
                    break lab6;
                }
                cursor = limit - v_7;
                ket = cursor;
            }
            if (find_among_b(a_7) == 0)
            {
                break lab5;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            among_var = find_among_b(a_6);
            if (among_var == 0)
            {
                break lab5;
            }
            if (cursor > limit_backward)
            {
                break lab5;
            }
            switch (among_var) {
                case 1:
                    slice_from("\u03B9");
                    break;
                case 2:
                    slice_from("\u03B9\u03C3");
                    break;
            }
        }
        cursor = limit - v_6;
        int v_8 = limit - cursor;
        lab8: {
            ket = cursor;
            if (find_among_b(a_9) == 0)
            {
                break lab8;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_8) == 0)
            {
                break lab8;
            }
            if (cursor > limit_backward)
            {
                break lab8;
            }
            slice_from("\u03B9");
        }
        cursor = limit - v_8;
        int v_9 = limit - cursor;
        lab9: {
            ket = cursor;
            if (find_among_b(a_11) == 0)
            {
                break lab9;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            among_var = find_among_b(a_10);
            if (among_var == 0)
            {
                break lab9;
            }
            if (cursor > limit_backward)
            {
                break lab9;
            }
            switch (among_var) {
                case 1:
                    slice_from("\u03B9");
                    break;
                case 2:
                    slice_from("\u03B9\u03C3\u03C4");
                    break;
            }
        }
        cursor = limit - v_9;
        int v_10 = limit - cursor;
        lab10: {
            ket = cursor;
            if (find_among_b(a_14) == 0)
            {
                break lab10;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab11: {
                int v_11 = limit - cursor;
                lab12: {
                    ket = cursor;
                    bra = cursor;
                    among_var = find_among_b(a_12);
                    if (among_var == 0)
                    {
                        break lab12;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab12;
                    }
                    switch (among_var) {
                        case 1:
                            slice_from("\u03B9\u03C3\u03BC");
                            break;
                        case 2:
                            slice_from("\u03B9");
                            break;
                    }
                    break lab11;
                }
                cursor = limit - v_11;
                ket = cursor;
                among_var = find_among_b(a_13);
                if (among_var == 0)
                {
                    break lab10;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("\u03B1\u03B3\u03BD\u03C9\u03C3\u03C4");
                        break;
                    case 2:
                        slice_from("\u03B1\u03C4\u03BF\u03BC");
                        break;
                    case 3:
                        slice_from("\u03B3\u03BD\u03C9\u03C3\u03C4");
                        break;
                    case 4:
                        slice_from("\u03B5\u03B8\u03BD");
                        break;
                    case 5:
                        slice_from("\u03B5\u03BA\u03BB\u03B5\u03BA\u03C4");
                        break;
                    case 6:
                        slice_from("\u03C3\u03BA\u03B5\u03C0\u03C4");
                        break;
                    case 7:
                        slice_from("\u03C4\u03BF\u03C0");
                        break;
                    case 8:
                        slice_from("\u03B1\u03BB\u03B5\u03BE\u03B1\u03BD\u03B4\u03C1");
                        break;
                    case 9:
                        slice_from("\u03B2\u03C5\u03B6\u03B1\u03BD\u03C4");
                        break;
                    case 10:
                        slice_from("\u03B8\u03B5\u03B1\u03C4\u03C1");
                        break;
                }
            }
        }
        cursor = limit - v_10;
        int v_12 = limit - cursor;
        lab13: {
            ket = cursor;
            if (find_among_b(a_16) == 0)
            {
                break lab13;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_15) == 0)
            {
                break lab13;
            }
            if (cursor > limit_backward)
            {
                break lab13;
            }
            slice_from("\u03B1\u03C1\u03B1\u03BA");
        }
        cursor = limit - v_12;
        int v_13 = limit - cursor;
        lab14: {
            ket = cursor;
            if (find_among_b(a_18) == 0)
            {
                break lab14;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab15: {
                int v_14 = limit - cursor;
                lab16: {
                    ket = cursor;
                    bra = cursor;
                    among_var = find_among_b(a_17);
                    if (among_var == 0)
                    {
                        break lab16;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab16;
                    }
                    switch (among_var) {
                        case 1:
                            slice_from("\u03B1\u03BA");
                            break;
                        case 2:
                            slice_from("\u03B9\u03C4\u03C3");
                            break;
                    }
                    break lab15;
                }
                cursor = limit - v_14;
                ket = cursor;
                bra = cursor;
                if (!(eq_s_b("\u03BA\u03BF\u03C1")))
                {
                    break lab14;
                }
                slice_from("\u03B9\u03C4\u03C3");
            }
        }
        cursor = limit - v_13;
        int v_15 = limit - cursor;
        lab17: {
            ket = cursor;
            if (find_among_b(a_21) == 0)
            {
                break lab17;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab18: {
                int v_16 = limit - cursor;
                lab19: {
                    ket = cursor;
                    bra = cursor;
                    if (find_among_b(a_19) == 0)
                    {
                        break lab19;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab19;
                    }
                    slice_from("\u03B9\u03B4");
                    break lab18;
                }
                cursor = limit - v_16;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_20) == 0)
                {
                    break lab17;
                }
                slice_from("\u03B9\u03B4");
            }
        }
        cursor = limit - v_15;
        int v_17 = limit - cursor;
        lab20: {
            ket = cursor;
            if (find_among_b(a_23) == 0)
            {
                break lab20;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_22) == 0)
            {
                break lab20;
            }
            if (cursor > limit_backward)
            {
                break lab20;
            }
            slice_from("\u03B9\u03C3\u03BA");
        }
        cursor = limit - v_17;
        int v_18 = limit - cursor;
        lab21: {
            ket = cursor;
            if (find_among_b(a_24) == 0)
            {
                break lab21;
            }
            bra = cursor;
            slice_del();
            {
                int v_19 = limit - cursor;
                lab22: {
                    if (find_among_b(a_25) == 0)
                    {
                        break lab22;
                    }
                    break lab21;
                }
                cursor = limit - v_19;
            }
            {
                int c = cursor;
                insert(cursor, cursor, "\u03B1\u03B4");
                cursor = c;
            }
        }
        cursor = limit - v_18;
        int v_20 = limit - cursor;
        lab23: {
            ket = cursor;
            if (find_among_b(a_26) == 0)
            {
                break lab23;
            }
            bra = cursor;
            slice_del();
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_27) == 0)
            {
                break lab23;
            }
            slice_from("\u03B5\u03B4");
        }
        cursor = limit - v_20;
        int v_21 = limit - cursor;
        lab24: {
            ket = cursor;
            if (find_among_b(a_28) == 0)
            {
                break lab24;
            }
            bra = cursor;
            slice_del();
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_29) == 0)
            {
                break lab24;
            }
            slice_from("\u03BF\u03C5\u03B4");
        }
        cursor = limit - v_21;
        int v_22 = limit - cursor;
        lab25: {
            ket = cursor;
            if (find_among_b(a_30) == 0)
            {
                break lab25;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_31) == 0)
            {
                break lab25;
            }
            if (cursor > limit_backward)
            {
                break lab25;
            }
            slice_from("\u03B5");
        }
        cursor = limit - v_22;
        int v_23 = limit - cursor;
        lab26: {
            ket = cursor;
            if (find_among_b(a_32) == 0)
            {
                break lab26;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (!(in_grouping_b(g_v, 945, 969)))
            {
                break lab26;
            }
            slice_from("\u03B9");
        }
        cursor = limit - v_23;
        int v_24 = limit - cursor;
        lab27: {
            ket = cursor;
            if (find_among_b(a_33) == 0)
            {
                break lab27;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab28: {
                int v_25 = limit - cursor;
                lab29: {
                    ket = cursor;
                    bra = cursor;
                    if (!(in_grouping_b(g_v, 945, 969)))
                    {
                        break lab29;
                    }
                    slice_from("\u03B9\u03BA");
                    break lab28;
                }
                cursor = limit - v_25;
                ket = cursor;
            }
            bra = cursor;
            if (find_among_b(a_34) == 0)
            {
                break lab27;
            }
            if (cursor > limit_backward)
            {
                break lab27;
            }
            slice_from("\u03B9\u03BA");
        }
        cursor = limit - v_24;
        int v_26 = limit - cursor;
        lab30: {
            int v_27 = limit - cursor;
            lab31: {
                ket = cursor;
                if (!(eq_s_b("\u03B1\u03B3\u03B1\u03BC\u03B5")))
                {
                    break lab31;
                }
                bra = cursor;
                if (cursor > limit_backward)
                {
                    break lab31;
                }
                slice_from("\u03B1\u03B3\u03B1\u03BC");
            }
            cursor = limit - v_27;
            int v_28 = limit - cursor;
            lab32: {
                ket = cursor;
                if (find_among_b(a_35) == 0)
                {
                    break lab32;
                }
                bra = cursor;
                slice_del();
                B_test1 = false;
            }
            cursor = limit - v_28;
            ket = cursor;
            if (!(eq_s_b("\u03B1\u03BC\u03B5")))
            {
                break lab30;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_36) == 0)
            {
                break lab30;
            }
            if (cursor > limit_backward)
            {
                break lab30;
            }
            slice_from("\u03B1\u03BC");
        }
        cursor = limit - v_26;
        int v_29 = limit - cursor;
        lab33: {
            int v_30 = limit - cursor;
            lab34: {
                ket = cursor;
                if (find_among_b(a_38) == 0)
                {
                    break lab34;
                }
                bra = cursor;
                slice_del();
                B_test1 = false;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_37) == 0)
                {
                    break lab34;
                }
                if (cursor > limit_backward)
                {
                    break lab34;
                }
                slice_from("\u03B1\u03B3\u03B1\u03BD");
            }
            cursor = limit - v_30;
            ket = cursor;
            if (!(eq_s_b("\u03B1\u03BD\u03B5")))
            {
                break lab33;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab35: {
                int v_31 = limit - cursor;
                lab36: {
                    ket = cursor;
                    bra = cursor;
                    if (!(in_grouping_b(g_v2, 945, 969)))
                    {
                        break lab36;
                    }
                    slice_from("\u03B1\u03BD");
                    break lab35;
                }
                cursor = limit - v_31;
                ket = cursor;
            }
            bra = cursor;
            if (find_among_b(a_39) == 0)
            {
                break lab33;
            }
            if (cursor > limit_backward)
            {
                break lab33;
            }
            slice_from("\u03B1\u03BD");
        }
        cursor = limit - v_29;
        int v_32 = limit - cursor;
        lab37: {
            int v_33 = limit - cursor;
            lab38: {
                ket = cursor;
                if (!(eq_s_b("\u03B7\u03C3\u03B5\u03C4\u03B5")))
                {
                    break lab38;
                }
                bra = cursor;
                slice_del();
                B_test1 = false;
            }
            cursor = limit - v_33;
            ket = cursor;
            if (!(eq_s_b("\u03B5\u03C4\u03B5")))
            {
                break lab37;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab39: {
                int v_34 = limit - cursor;
                lab40: {
                    ket = cursor;
                    bra = cursor;
                    if (!(in_grouping_b(g_v2, 945, 969)))
                    {
                        break lab40;
                    }
                    slice_from("\u03B5\u03C4");
                    break lab39;
                }
                cursor = limit - v_34;
                lab41: {
                    ket = cursor;
                    bra = cursor;
                    if (find_among_b(a_40) == 0)
                    {
                        break lab41;
                    }
                    slice_from("\u03B5\u03C4");
                    break lab39;
                }
                cursor = limit - v_34;
                ket = cursor;
            }
            bra = cursor;
            if (find_among_b(a_41) == 0)
            {
                break lab37;
            }
            if (cursor > limit_backward)
            {
                break lab37;
            }
            slice_from("\u03B5\u03C4");
        }
        cursor = limit - v_32;
        int v_35 = limit - cursor;
        lab42: {
            ket = cursor;
            if (find_among_b(a_42) == 0)
            {
                break lab42;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab43: {
                int v_36 = limit - cursor;
                lab44: {
                    ket = cursor;
                    bra = cursor;
                    if (!(eq_s_b("\u03B1\u03C1\u03C7")))
                    {
                        break lab44;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab44;
                    }
                    slice_from("\u03BF\u03BD\u03C4");
                    break lab43;
                }
                cursor = limit - v_36;
                ket = cursor;
                bra = cursor;
                if (!(eq_s_b("\u03BA\u03C1\u03B5")))
                {
                    break lab42;
                }
                slice_from("\u03C9\u03BD\u03C4");
            }
        }
        cursor = limit - v_35;
        int v_37 = limit - cursor;
        lab45: {
            ket = cursor;
            if (find_among_b(a_43) == 0)
            {
                break lab45;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (!(eq_s_b("\u03BF\u03BD")))
            {
                break lab45;
            }
            if (cursor > limit_backward)
            {
                break lab45;
            }
            slice_from("\u03BF\u03BC\u03B1\u03C3\u03C4");
        }
        cursor = limit - v_37;
        int v_38 = limit - cursor;
        lab46: {
            int v_39 = limit - cursor;
            lab47: {
                ket = cursor;
                if (!(eq_s_b("\u03B9\u03B5\u03C3\u03C4\u03B5")))
                {
                    break lab47;
                }
                bra = cursor;
                slice_del();
                B_test1 = false;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_44) == 0)
                {
                    break lab47;
                }
                if (cursor > limit_backward)
                {
                    break lab47;
                }
                slice_from("\u03B9\u03B5\u03C3\u03C4");
            }
            cursor = limit - v_39;
            ket = cursor;
            if (!(eq_s_b("\u03B5\u03C3\u03C4\u03B5")))
            {
                break lab46;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_45) == 0)
            {
                break lab46;
            }
            if (cursor > limit_backward)
            {
                break lab46;
            }
            slice_from("\u03B9\u03B5\u03C3\u03C4");
        }
        cursor = limit - v_38;
        int v_40 = limit - cursor;
        lab48: {
            int v_41 = limit - cursor;
            lab49: {
                ket = cursor;
                if (find_among_b(a_46) == 0)
                {
                    break lab49;
                }
                bra = cursor;
                slice_del();
                B_test1 = false;
            }
            cursor = limit - v_41;
            ket = cursor;
            if (find_among_b(a_49) == 0)
            {
                break lab48;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab50: {
                int v_42 = limit - cursor;
                lab51: {
                    ket = cursor;
                    bra = cursor;
                    if (find_among_b(a_47) == 0)
                    {
                        break lab51;
                    }
                    slice_from("\u03B7\u03BA");
                    break lab50;
                }
                cursor = limit - v_42;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_48) == 0)
                {
                    break lab48;
                }
                if (cursor > limit_backward)
                {
                    break lab48;
                }
                slice_from("\u03B7\u03BA");
            }
        }
        cursor = limit - v_40;
        int v_43 = limit - cursor;
        lab52: {
            ket = cursor;
            if (find_among_b(a_52) == 0)
            {
                break lab52;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab53: {
                int v_44 = limit - cursor;
                lab54: {
                    ket = cursor;
                    bra = cursor;
                    if (find_among_b(a_50) == 0)
                    {
                        break lab54;
                    }
                    slice_from("\u03BF\u03C5\u03C3");
                    break lab53;
                }
                cursor = limit - v_44;
                ket = cursor;
                bra = cursor;
                if (find_among_b(a_51) == 0)
                {
                    break lab52;
                }
                if (cursor > limit_backward)
                {
                    break lab52;
                }
                slice_from("\u03BF\u03C5\u03C3");
            }
        }
        cursor = limit - v_43;
        int v_45 = limit - cursor;
        lab55: {
            ket = cursor;
            if (find_among_b(a_56) == 0)
            {
                break lab55;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_57) == 0)
            {
                break lab55;
            }
            if (cursor > limit_backward)
            {
                break lab55;
            }
            slice_from("\u03B7\u03C3");
        }
        cursor = limit - v_45;
        int v_46 = limit - cursor;
        lab56: {
            ket = cursor;
            if (find_among_b(a_55) == 0)
            {
                break lab56;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            lab57: {
                int v_47 = limit - cursor;
                lab58: {
                    ket = cursor;
                    bra = cursor;
                    if (!(eq_s_b("\u03BA\u03BF\u03BB\u03BB")))
                    {
                        break lab58;
                    }
                    slice_from("\u03B1\u03B3");
                    break lab57;
                }
                cursor = limit - v_47;
                lab59: {
                    int v_48 = limit - cursor;
                    lab60: {
                        ket = cursor;
                        bra = cursor;
                        among_var = find_among_b(a_53);
                        if (among_var == 0)
                        {
                            break lab60;
                        }
                        switch (among_var) {
                            case 1:
                                slice_from("\u03B1\u03B3");
                                break;
                        }
                        break lab59;
                    }
                    cursor = limit - v_48;
                    ket = cursor;
                    bra = cursor;
                    if (find_among_b(a_54) == 0)
                    {
                        break lab56;
                    }
                    if (cursor > limit_backward)
                    {
                        break lab56;
                    }
                    slice_from("\u03B1\u03B3");
                }
            }
        }
        cursor = limit - v_46;
        int v_49 = limit - cursor;
        lab61: {
            ket = cursor;
            if (!(eq_s_b("\u03B7\u03C3\u03C4\u03B5")))
            {
                break lab61;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_58) == 0)
            {
                break lab61;
            }
            if (cursor > limit_backward)
            {
                break lab61;
            }
            slice_from("\u03B7\u03C3\u03C4");
        }
        cursor = limit - v_49;
        int v_50 = limit - cursor;
        lab62: {
            ket = cursor;
            if (find_among_b(a_59) == 0)
            {
                break lab62;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_60) == 0)
            {
                break lab62;
            }
            if (cursor > limit_backward)
            {
                break lab62;
            }
            slice_from("\u03BF\u03C5\u03BD");
        }
        cursor = limit - v_50;
        int v_51 = limit - cursor;
        lab63: {
            ket = cursor;
            if (find_among_b(a_61) == 0)
            {
                break lab63;
            }
            bra = cursor;
            slice_del();
            B_test1 = false;
            ket = cursor;
            bra = cursor;
            if (find_among_b(a_62) == 0)
            {
                break lab63;
            }
            if (cursor > limit_backward)
            {
                break lab63;
            }
            slice_from("\u03BF\u03C5\u03BC");
        }
        cursor = limit - v_51;
        int v_52 = limit - cursor;
        lab64: {
            int v_53 = limit - cursor;
            lab65: {
                ket = cursor;
                if (find_among_b(a_63) == 0)
                {
                    break lab65;
                }
                bra = cursor;
                slice_from("\u03BC\u03B1");
            }
            cursor = limit - v_53;
            if (!B_test1)
            {
                break lab64;
            }
            ket = cursor;
            if (find_among_b(a_64) == 0)
            {
                break lab64;
            }
            bra = cursor;
            slice_del();
        }
        cursor = limit - v_52;
        int v_54 = limit - cursor;
        lab66: {
            ket = cursor;
            if (find_among_b(a_65) == 0)
            {
                break lab66;
            }
            bra = cursor;
            slice_del();
        }
        cursor = limit - v_54;
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof greekStemmer;
    }

    @Override
    public int hashCode() {
        return greekStemmer.class.getName().hashCode();
    }

}
