// Generated from indonesian.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from indonesian.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class indonesianStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("kah", -1, 1),
        new Among("lah", -1, 1),
        new Among("pun", -1, 1)
    };

    private final static Among[] a_1 = {
        new Among("nya", -1, 1),
        new Among("ku", -1, 1),
        new Among("mu", -1, 1)
    };

    private final static Among[] a_2 = {
        new Among("i", -1, 2),
        new Among("an", -1, 1)
    };

    private final static Among[] a_3 = {
        new Among("di", -1, 1),
        new Among("ke", -1, 3),
        new Among("me", -1, 1),
        new Among("mem", 2, 5),
        new Among("men", 2, 2),
        new Among("meng", 4, 1),
        new Among("pem", -1, 6),
        new Among("pen", -1, 4),
        new Among("peng", 7, 3),
        new Among("ter", -1, 1)
    };

    private final static Among[] a_4 = {
        new Among("be", -1, 2),
        new Among("pe", -1, 1)
    };

    private static final char[] g_vowel = {17, 65, 16 };

    private int I_prefix;
    private int I_measure;


    private boolean r_remove_suffix() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_2);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                lab0: {
                    int v_1 = limit - cursor;
                    lab1: {
                        if (I_prefix == 3)
                        {
                            break lab1;
                        }
                        if (I_prefix == 2)
                        {
                            break lab1;
                        }
                        if (!(eq_s_b("k")))
                        {
                            break lab1;
                        }
                        bra = cursor;
                        break lab0;
                    }
                    cursor = limit - v_1;
                    if (I_prefix == 1)
                    {
                        return false;
                    }
                }
                break;
            case 2:
                if (I_prefix > 2)
                {
                    return false;
                }
                lab2: {
                    if (!(eq_s_b("s")))
                    {
                        break lab2;
                    }
                    return false;
                }
                break;
        }
        slice_del();
        I_measure -= 1;
        return true;
    }

    private boolean r_remove_second_order_prefix() {
        int among_var;
        bra = cursor;
        among_var = find_among(a_4);
        if (among_var == 0)
        {
            return false;
        }
        switch (among_var) {
            case 1:
                lab0: {
                    int v_1 = cursor;
                    lab1: {
                        if (!(eq_s("r")))
                        {
                            break lab1;
                        }
                        ket = cursor;
                        I_prefix = 2;
                        break lab0;
                    }
                    cursor = v_1;
                    lab2: {
                        if (!(eq_s("l")))
                        {
                            break lab2;
                        }
                        ket = cursor;
                        if (!(eq_s("ajar")))
                        {
                            break lab2;
                        }
                        break lab0;
                    }
                    cursor = v_1;
                    ket = cursor;
                    I_prefix = 2;
                }
                break;
            case 2:
                lab3: {
                    int v_2 = cursor;
                    lab4: {
                        if (!(eq_s("r")))
                        {
                            break lab4;
                        }
                        ket = cursor;
                        break lab3;
                    }
                    cursor = v_2;
                    lab5: {
                        if (!(eq_s("l")))
                        {
                            break lab5;
                        }
                        ket = cursor;
                        if (!(eq_s("ajar")))
                        {
                            break lab5;
                        }
                        break lab3;
                    }
                    cursor = v_2;
                    ket = cursor;
                    if (!(out_grouping(g_vowel, 97, 117)))
                    {
                        return false;
                    }
                    if (!(eq_s("er")))
                    {
                        return false;
                    }
                }
                I_prefix = 4;
                break;
        }
        I_measure -= 1;
        slice_del();
        return true;
    }

    @Override
    public boolean stem() {
        int among_var;
        I_measure = 0;
        int v_1 = cursor;
        lab0: {
            while (true)
            {
                int v_2 = cursor;
                lab1: {
                    if (!go_out_grouping(g_vowel, 97, 117))
                    {
                        break lab1;
                    }
                    cursor++;
                    I_measure += 1;
                    continue;
                }
                cursor = v_2;
                break;
            }
        }
        cursor = v_1;
        if (I_measure < 3)
        {
            return false;
        }
        I_prefix = 0;
        limit_backward = cursor;
        cursor = limit;
        int v_3 = limit - cursor;
        lab2: {
            ket = cursor;
            if (find_among_b(a_0) == 0)
            {
                break lab2;
            }
            bra = cursor;
            slice_del();
            I_measure -= 1;
        }
        cursor = limit - v_3;
        if (I_measure < 3)
        {
            return false;
        }
        int v_4 = limit - cursor;
        lab3: {
            ket = cursor;
            if (find_among_b(a_1) == 0)
            {
                break lab3;
            }
            bra = cursor;
            slice_del();
            I_measure -= 1;
        }
        cursor = limit - v_4;
        cursor = limit_backward;
        if (I_measure < 3)
        {
            return false;
        }
        lab4: {
            int v_5 = cursor;
            lab5: {
                int v_6 = cursor;
                bra = cursor;
                among_var = find_among(a_3);
                if (among_var == 0)
                {
                    break lab5;
                }
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_del();
                        I_prefix = 1;
                        I_measure -= 1;
                        break;
                    case 2:
                        lab6: {
                            int v_7 = cursor;
                            lab7: {
                                if (!(eq_s("y")))
                                {
                                    break lab7;
                                }
                                int v_8 = cursor;
                                if (!(in_grouping(g_vowel, 97, 117)))
                                {
                                    break lab7;
                                }
                                cursor = v_8;
                                ket = cursor;
                                slice_from("s");
                                I_prefix = 1;
                                I_measure -= 1;
                                break lab6;
                            }
                            cursor = v_7;
                            slice_del();
                            I_prefix = 1;
                            I_measure -= 1;
                        }
                        break;
                    case 3:
                        slice_del();
                        I_prefix = 3;
                        I_measure -= 1;
                        break;
                    case 4:
                        lab8: {
                            int v_9 = cursor;
                            lab9: {
                                if (!(eq_s("y")))
                                {
                                    break lab9;
                                }
                                int v_10 = cursor;
                                if (!(in_grouping(g_vowel, 97, 117)))
                                {
                                    break lab9;
                                }
                                cursor = v_10;
                                ket = cursor;
                                slice_from("s");
                                I_prefix = 3;
                                I_measure -= 1;
                                break lab8;
                            }
                            cursor = v_9;
                            slice_del();
                            I_prefix = 3;
                            I_measure -= 1;
                        }
                        break;
                    case 5:
                        I_prefix = 1;
                        I_measure -= 1;
                        lab10: {
                            int v_11 = cursor;
                            lab11: {
                                int v_12 = cursor;
                                if (!(in_grouping(g_vowel, 97, 117)))
                                {
                                    break lab11;
                                }
                                cursor = v_12;
                                slice_from("p");
                                break lab10;
                            }
                            cursor = v_11;
                            slice_del();
                        }
                        break;
                    case 6:
                        I_prefix = 3;
                        I_measure -= 1;
                        lab12: {
                            int v_13 = cursor;
                            lab13: {
                                int v_14 = cursor;
                                if (!(in_grouping(g_vowel, 97, 117)))
                                {
                                    break lab13;
                                }
                                cursor = v_14;
                                slice_from("p");
                                break lab12;
                            }
                            cursor = v_13;
                            slice_del();
                        }
                        break;
                }
                int v_15 = cursor;
                lab14: {
                    int v_16 = cursor;
                    if (I_measure < 3)
                    {
                        break lab14;
                    }
                    limit_backward = cursor;
                    cursor = limit;
                    if (!r_remove_suffix())
                    {
                        break lab14;
                    }
                    cursor = limit_backward;
                    cursor = v_16;
                    if (I_measure < 3)
                    {
                        break lab14;
                    }
                    if (!r_remove_second_order_prefix())
                    {
                        break lab14;
                    }
                }
                cursor = v_15;
                cursor = v_6;
                break lab4;
            }
            cursor = v_5;
            int v_17 = cursor;
            r_remove_second_order_prefix();
            cursor = v_17;
            int v_18 = cursor;
            lab15: {
                if (I_measure < 3)
                {
                    break lab15;
                }
                limit_backward = cursor;
                cursor = limit;
                if (!r_remove_suffix())
                {
                    break lab15;
                }
                cursor = limit_backward;
            }
            cursor = v_18;
        }
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof indonesianStemmer;
    }

    @Override
    public int hashCode() {
        return indonesianStemmer.class.getName().hashCode();
    }

}
