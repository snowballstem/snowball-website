// Generated from turkish.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from turkish.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class turkishStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("m", -1, -1),
        new Among("n", -1, -1),
        new Among("miz", -1, -1),
        new Among("niz", -1, -1),
        new Among("muz", -1, -1),
        new Among("nuz", -1, -1),
        new Among("m\u00FCz", -1, -1),
        new Among("n\u00FCz", -1, -1),
        new Among("m\u0131z", -1, -1),
        new Among("n\u0131z", -1, -1)
    };

    private final static Among[] a_1 = {
        new Among("leri", -1, -1),
        new Among("lar\u0131", -1, -1)
    };

    private final static Among[] a_2 = {
        new Among("ni", -1, -1),
        new Among("nu", -1, -1),
        new Among("n\u00FC", -1, -1),
        new Among("n\u0131", -1, -1)
    };

    private final static Among[] a_3 = {
        new Among("in", -1, -1),
        new Among("un", -1, -1),
        new Among("\u00FCn", -1, -1),
        new Among("\u0131n", -1, -1)
    };

    private final static Among[] a_4 = {
        new Among("a", -1, -1),
        new Among("e", -1, -1)
    };

    private final static Among[] a_5 = {
        new Among("na", -1, -1),
        new Among("ne", -1, -1)
    };

    private final static Among[] a_6 = {
        new Among("da", -1, -1),
        new Among("ta", -1, -1),
        new Among("de", -1, -1),
        new Among("te", -1, -1)
    };

    private final static Among[] a_7 = {
        new Among("nda", -1, -1),
        new Among("nde", -1, -1)
    };

    private final static Among[] a_8 = {
        new Among("dan", -1, -1),
        new Among("tan", -1, -1),
        new Among("den", -1, -1),
        new Among("ten", -1, -1)
    };

    private final static Among[] a_9 = {
        new Among("ndan", -1, -1),
        new Among("nden", -1, -1)
    };

    private final static Among[] a_10 = {
        new Among("la", -1, -1),
        new Among("le", -1, -1)
    };

    private final static Among[] a_11 = {
        new Among("ca", -1, -1),
        new Among("ce", -1, -1)
    };

    private final static Among[] a_12 = {
        new Among("im", -1, -1),
        new Among("um", -1, -1),
        new Among("\u00FCm", -1, -1),
        new Among("\u0131m", -1, -1)
    };

    private final static Among[] a_13 = {
        new Among("sin", -1, -1),
        new Among("sun", -1, -1),
        new Among("s\u00FCn", -1, -1),
        new Among("s\u0131n", -1, -1)
    };

    private final static Among[] a_14 = {
        new Among("iz", -1, -1),
        new Among("uz", -1, -1),
        new Among("\u00FCz", -1, -1),
        new Among("\u0131z", -1, -1)
    };

    private final static Among[] a_15 = {
        new Among("siniz", -1, -1),
        new Among("sunuz", -1, -1),
        new Among("s\u00FCn\u00FCz", -1, -1),
        new Among("s\u0131n\u0131z", -1, -1)
    };

    private final static Among[] a_16 = {
        new Among("lar", -1, -1),
        new Among("ler", -1, -1)
    };

    private final static Among[] a_17 = {
        new Among("niz", -1, -1),
        new Among("nuz", -1, -1),
        new Among("n\u00FCz", -1, -1),
        new Among("n\u0131z", -1, -1)
    };

    private final static Among[] a_18 = {
        new Among("dir", -1, -1),
        new Among("tir", -1, -1),
        new Among("dur", -1, -1),
        new Among("tur", -1, -1),
        new Among("d\u00FCr", -1, -1),
        new Among("t\u00FCr", -1, -1),
        new Among("d\u0131r", -1, -1),
        new Among("t\u0131r", -1, -1)
    };

    private final static Among[] a_19 = {
        new Among("cas\u0131na", -1, -1),
        new Among("cesine", -1, -1)
    };

    private final static Among[] a_20 = {
        new Among("di", -1, -1),
        new Among("ti", -1, -1),
        new Among("dik", -1, -1),
        new Among("tik", -1, -1),
        new Among("duk", -1, -1),
        new Among("tuk", -1, -1),
        new Among("d\u00FCk", -1, -1),
        new Among("t\u00FCk", -1, -1),
        new Among("d\u0131k", -1, -1),
        new Among("t\u0131k", -1, -1),
        new Among("dim", -1, -1),
        new Among("tim", -1, -1),
        new Among("dum", -1, -1),
        new Among("tum", -1, -1),
        new Among("d\u00FCm", -1, -1),
        new Among("t\u00FCm", -1, -1),
        new Among("d\u0131m", -1, -1),
        new Among("t\u0131m", -1, -1),
        new Among("din", -1, -1),
        new Among("tin", -1, -1),
        new Among("dun", -1, -1),
        new Among("tun", -1, -1),
        new Among("d\u00FCn", -1, -1),
        new Among("t\u00FCn", -1, -1),
        new Among("d\u0131n", -1, -1),
        new Among("t\u0131n", -1, -1),
        new Among("du", -1, -1),
        new Among("tu", -1, -1),
        new Among("d\u00FC", -1, -1),
        new Among("t\u00FC", -1, -1),
        new Among("d\u0131", -1, -1),
        new Among("t\u0131", -1, -1)
    };

    private final static Among[] a_21 = {
        new Among("sa", -1, -1),
        new Among("se", -1, -1),
        new Among("sak", -1, -1),
        new Among("sek", -1, -1),
        new Among("sam", -1, -1),
        new Among("sem", -1, -1),
        new Among("san", -1, -1),
        new Among("sen", -1, -1)
    };

    private final static Among[] a_22 = {
        new Among("mi\u015F", -1, -1),
        new Among("mu\u015F", -1, -1),
        new Among("m\u00FC\u015F", -1, -1),
        new Among("m\u0131\u015F", -1, -1)
    };

    private final static Among[] a_23 = {
        new Among("b", -1, 1),
        new Among("c", -1, 2),
        new Among("d", -1, 3),
        new Among("\u011F", -1, 4)
    };

    private static final char[] g_vowel = {17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 8, 0, 0, 0, 0, 0, 0, 1 };

    private static final char[] g_U = {1, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 1 };

    private static final char[] g_vowel1 = {1, 64, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

    private static final char[] g_vowel2 = {17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 130 };

    private static final char[] g_vowel3 = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

    private static final char[] g_vowel4 = {17 };

    private static final char[] g_vowel5 = {65 };

    private static final char[] g_vowel6 = {65 };


    private boolean r_check_vowel_harmony() {
        int v_1 = limit - cursor;
        if (!go_out_grouping_b(g_vowel, 97, 305))
        {
            return false;
        }
        lab0: {
            int v_2 = limit - cursor;
            lab1: {
                if (!(eq_s_b("a")))
                {
                    break lab1;
                }
                if (!go_out_grouping_b(g_vowel1, 97, 305))
                {
                    break lab1;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab2: {
                if (!(eq_s_b("e")))
                {
                    break lab2;
                }
                if (!go_out_grouping_b(g_vowel2, 101, 252))
                {
                    break lab2;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab3: {
                if (!(eq_s_b("\u0131")))
                {
                    break lab3;
                }
                if (!go_out_grouping_b(g_vowel3, 97, 305))
                {
                    break lab3;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab4: {
                if (!(eq_s_b("i")))
                {
                    break lab4;
                }
                if (!go_out_grouping_b(g_vowel4, 101, 105))
                {
                    break lab4;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab5: {
                if (!(eq_s_b("o")))
                {
                    break lab5;
                }
                if (!go_out_grouping_b(g_vowel5, 111, 117))
                {
                    break lab5;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab6: {
                if (!(eq_s_b("\u00F6")))
                {
                    break lab6;
                }
                if (!go_out_grouping_b(g_vowel6, 246, 252))
                {
                    break lab6;
                }
                break lab0;
            }
            cursor = limit - v_2;
            lab7: {
                if (!(eq_s_b("u")))
                {
                    break lab7;
                }
                if (!go_out_grouping_b(g_vowel5, 111, 117))
                {
                    break lab7;
                }
                break lab0;
            }
            cursor = limit - v_2;
            if (!(eq_s_b("\u00FC")))
            {
                return false;
            }
            if (!go_out_grouping_b(g_vowel6, 246, 252))
            {
                return false;
            }
        }
        cursor = limit - v_1;
        return true;
    }

    private boolean r_mark_suffix_with_optional_n_consonant() {
        lab0: {
            int v_1 = limit - cursor;
            lab1: {
                if (!(eq_s_b("n")))
                {
                    break lab1;
                }
                int v_2 = limit - cursor;
                if (!(in_grouping_b(g_vowel, 97, 305)))
                {
                    break lab1;
                }
                cursor = limit - v_2;
                break lab0;
            }
            cursor = limit - v_1;
            lab2: {
                if (!(eq_s_b("n")))
                {
                    break lab2;
                }
                return false;
            }
            int v_3 = limit - cursor;
            if (cursor <= limit_backward)
            {
                return false;
            }
            cursor--;
            if (!(in_grouping_b(g_vowel, 97, 305)))
            {
                return false;
            }
            cursor = limit - v_3;
        }
        return true;
    }

    private boolean r_mark_suffix_with_optional_y_consonant() {
        lab0: {
            int v_1 = limit - cursor;
            lab1: {
                if (!(eq_s_b("y")))
                {
                    break lab1;
                }
                int v_2 = limit - cursor;
                if (!(in_grouping_b(g_vowel, 97, 305)))
                {
                    break lab1;
                }
                cursor = limit - v_2;
                break lab0;
            }
            cursor = limit - v_1;
            lab2: {
                if (!(eq_s_b("y")))
                {
                    break lab2;
                }
                return false;
            }
            int v_3 = limit - cursor;
            if (cursor <= limit_backward)
            {
                return false;
            }
            cursor--;
            if (!(in_grouping_b(g_vowel, 97, 305)))
            {
                return false;
            }
            cursor = limit - v_3;
        }
        return true;
    }

    private boolean r_mark_possessives() {
        if (find_among_b(a_0) == 0)
        {
            return false;
        }
        lab0: {
            int v_1 = limit - cursor;
            lab1: {
                if (!(in_grouping_b(g_U, 105, 305)))
                {
                    break lab1;
                }
                int v_2 = limit - cursor;
                if (!(out_grouping_b(g_vowel, 97, 305)))
                {
                    break lab1;
                }
                cursor = limit - v_2;
                break lab0;
            }
            cursor = limit - v_1;
            lab2: {
                if (!(in_grouping_b(g_U, 105, 305)))
                {
                    break lab2;
                }
                return false;
            }
            int v_3 = limit - cursor;
            if (cursor <= limit_backward)
            {
                return false;
            }
            cursor--;
            if (!(out_grouping_b(g_vowel, 97, 305)))
            {
                return false;
            }
            cursor = limit - v_3;
        }
        return true;
    }

    private boolean r_mark_sU() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (!(in_grouping_b(g_U, 105, 305)))
        {
            return false;
        }
        lab0: {
            int v_1 = limit - cursor;
            lab1: {
                if (!(eq_s_b("s")))
                {
                    break lab1;
                }
                int v_2 = limit - cursor;
                if (!(in_grouping_b(g_vowel, 97, 305)))
                {
                    break lab1;
                }
                cursor = limit - v_2;
                break lab0;
            }
            cursor = limit - v_1;
            lab2: {
                if (!(eq_s_b("s")))
                {
                    break lab2;
                }
                return false;
            }
            int v_3 = limit - cursor;
            if (cursor <= limit_backward)
            {
                return false;
            }
            cursor--;
            if (!(in_grouping_b(g_vowel, 97, 305)))
            {
                return false;
            }
            cursor = limit - v_3;
        }
        return true;
    }

    private boolean r_mark_lArI() {
        return find_among_b(a_1) != 0;
    }

    private boolean r_mark_nUn() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (find_among_b(a_3) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_n_consonant();
    }

    private boolean r_mark_DA() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        return find_among_b(a_6) != 0;
    }

    private boolean r_mark_ndA() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        return find_among_b(a_7) != 0;
    }

    private boolean r_mark_yUm() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (find_among_b(a_12) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_y_consonant();
    }

    private boolean r_mark_sUn() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        return find_among_b(a_13) != 0;
    }

    private boolean r_mark_yUz() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (find_among_b(a_14) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_y_consonant();
    }

    private boolean r_mark_sUnUz() {
        return find_among_b(a_15) != 0;
    }

    private boolean r_mark_lAr() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        return find_among_b(a_16) != 0;
    }

    private boolean r_mark_DUr() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        return find_among_b(a_18) != 0;
    }

    private boolean r_mark_yDU() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (find_among_b(a_20) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_y_consonant();
    }

    private boolean r_mark_ysA() {
        if (find_among_b(a_21) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_y_consonant();
    }

    private boolean r_mark_ymUs_() {
        if (!r_check_vowel_harmony())
        {
            return false;
        }
        if (find_among_b(a_22) == 0)
        {
            return false;
        }
        return r_mark_suffix_with_optional_y_consonant();
    }

    private boolean r_stem_suffix_chain_before_ki() {
        ket = cursor;
        if (!(eq_s_b("ki")))
        {
            return false;
        }
        lab0: {
            int v_1 = limit - cursor;
            lab1: {
                if (!r_mark_DA())
                {
                    break lab1;
                }
                bra = cursor;
                slice_del();
                int v_2 = limit - cursor;
                lab2: {
                    ket = cursor;
                    lab3: {
                        int v_3 = limit - cursor;
                        lab4: {
                            if (!r_mark_lAr())
                            {
                                break lab4;
                            }
                            bra = cursor;
                            slice_del();
                            int v_4 = limit - cursor;
                            lab5: {
                                if (!r_stem_suffix_chain_before_ki())
                                {
                                    cursor = limit - v_4;
                                    break lab5;
                                }
                            }
                            break lab3;
                        }
                        cursor = limit - v_3;
                        if (!r_mark_possessives())
                        {
                            cursor = limit - v_2;
                            break lab2;
                        }
                        bra = cursor;
                        slice_del();
                        int v_5 = limit - cursor;
                        lab6: {
                            ket = cursor;
                            if (!r_mark_lAr())
                            {
                                cursor = limit - v_5;
                                break lab6;
                            }
                            bra = cursor;
                            slice_del();
                            if (!r_stem_suffix_chain_before_ki())
                            {
                                cursor = limit - v_5;
                                break lab6;
                            }
                        }
                    }
                }
                break lab0;
            }
            cursor = limit - v_1;
            lab7: {
                if (!r_mark_nUn())
                {
                    break lab7;
                }
                bra = cursor;
                slice_del();
                int v_6 = limit - cursor;
                lab8: {
                    ket = cursor;
                    lab9: {
                        int v_7 = limit - cursor;
                        lab10: {
                            if (!r_mark_lArI())
                            {
                                break lab10;
                            }
                            bra = cursor;
                            slice_del();
                            break lab9;
                        }
                        cursor = limit - v_7;
                        lab11: {
                            ket = cursor;
                            lab12: {
                                int v_8 = limit - cursor;
                                lab13: {
                                    if (!r_mark_possessives())
                                    {
                                        break lab13;
                                    }
                                    break lab12;
                                }
                                cursor = limit - v_8;
                                if (!r_mark_sU())
                                {
                                    break lab11;
                                }
                            }
                            bra = cursor;
                            slice_del();
                            int v_9 = limit - cursor;
                            lab14: {
                                ket = cursor;
                                if (!r_mark_lAr())
                                {
                                    cursor = limit - v_9;
                                    break lab14;
                                }
                                bra = cursor;
                                slice_del();
                                if (!r_stem_suffix_chain_before_ki())
                                {
                                    cursor = limit - v_9;
                                    break lab14;
                                }
                            }
                            break lab9;
                        }
                        cursor = limit - v_7;
                        if (!r_stem_suffix_chain_before_ki())
                        {
                            cursor = limit - v_6;
                            break lab8;
                        }
                    }
                }
                break lab0;
            }
            cursor = limit - v_1;
            if (!r_mark_ndA())
            {
                return false;
            }
            lab15: {
                int v_10 = limit - cursor;
                lab16: {
                    if (!r_mark_lArI())
                    {
                        break lab16;
                    }
                    bra = cursor;
                    slice_del();
                    break lab15;
                }
                cursor = limit - v_10;
                lab17: {
                    if (!r_mark_sU())
                    {
                        break lab17;
                    }
                    bra = cursor;
                    slice_del();
                    int v_11 = limit - cursor;
                    lab18: {
                        ket = cursor;
                        if (!r_mark_lAr())
                        {
                            cursor = limit - v_11;
                            break lab18;
                        }
                        bra = cursor;
                        slice_del();
                        if (!r_stem_suffix_chain_before_ki())
                        {
                            cursor = limit - v_11;
                            break lab18;
                        }
                    }
                    break lab15;
                }
                cursor = limit - v_10;
                if (!r_stem_suffix_chain_before_ki())
                {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public boolean stem() {
        int among_var;
        boolean B_continue_stemming_noun_suffixes;
        lab0: {
            int v_1 = cursor;
            lab1: {
                bra = cursor;
                golab2: while (true)
                {
                    int v_2 = cursor;
                    lab3: {
                        lab4: {
                            if (!(eq_s("'")))
                            {
                                break lab4;
                            }
                            break lab3;
                        }
                        cursor = v_2;
                        break golab2;
                    }
                    cursor = v_2;
                    if (cursor >= limit)
                    {
                        break lab1;
                    }
                    cursor++;
                }
                ket = cursor;
                slice_del();
            }
            cursor = v_1;
            int v_3 = cursor;
            lab5: {
                {
                    int c = cursor + 2;
                    if (c > limit)
                    {
                        break lab5;
                    }
                    cursor = c;
                }
                golab6: while (true)
                {
                    int v_4 = cursor;
                    lab7: {
                        if (!(eq_s("'")))
                        {
                            break lab7;
                        }
                        cursor = v_4;
                        break golab6;
                    }
                    cursor = v_4;
                    if (cursor >= limit)
                    {
                        break lab5;
                    }
                    cursor++;
                }
                bra = cursor;
                cursor = limit;
                ket = cursor;
                slice_del();
            }
            cursor = v_3;
        }
        int v_5 = cursor;
        for (int v_6 = 2; v_6 > 0; v_6--)
        {
            if (!go_out_grouping(g_vowel, 97, 305))
            {
                return false;
            }
            cursor++;
        }
        cursor = v_5;
        limit_backward = cursor;
        cursor = limit;
        int v_7 = limit - cursor;
        lab8: {
            ket = cursor;
            B_continue_stemming_noun_suffixes = true;
            lab9: {
                int v_8 = limit - cursor;
                lab10: {
                    lab11: {
                        int v_9 = limit - cursor;
                        lab12: {
                            if (!r_mark_ymUs_())
                            {
                                break lab12;
                            }
                            break lab11;
                        }
                        cursor = limit - v_9;
                        lab13: {
                            if (!r_mark_yDU())
                            {
                                break lab13;
                            }
                            break lab11;
                        }
                        cursor = limit - v_9;
                        lab14: {
                            if (!r_mark_ysA())
                            {
                                break lab14;
                            }
                            break lab11;
                        }
                        cursor = limit - v_9;
                        if (!(eq_s_b("ken")))
                        {
                            break lab10;
                        }
                        if (!r_mark_suffix_with_optional_y_consonant())
                        {
                            break lab10;
                        }
                    }
                    break lab9;
                }
                cursor = limit - v_8;
                lab15: {
                    if (find_among_b(a_19) == 0)
                    {
                        break lab15;
                    }
                    lab16: {
                        int v_10 = limit - cursor;
                        lab17: {
                            if (!r_mark_sUnUz())
                            {
                                break lab17;
                            }
                            break lab16;
                        }
                        cursor = limit - v_10;
                        lab18: {
                            if (!r_mark_lAr())
                            {
                                break lab18;
                            }
                            break lab16;
                        }
                        cursor = limit - v_10;
                        lab19: {
                            if (!r_mark_yUm())
                            {
                                break lab19;
                            }
                            break lab16;
                        }
                        cursor = limit - v_10;
                        lab20: {
                            if (!r_mark_sUn())
                            {
                                break lab20;
                            }
                            break lab16;
                        }
                        cursor = limit - v_10;
                        lab21: {
                            if (!r_mark_yUz())
                            {
                                break lab21;
                            }
                            break lab16;
                        }
                        cursor = limit - v_10;
                    }
                    if (!r_mark_ymUs_())
                    {
                        break lab15;
                    }
                    break lab9;
                }
                cursor = limit - v_8;
                lab22: {
                    if (!r_mark_lAr())
                    {
                        break lab22;
                    }
                    bra = cursor;
                    slice_del();
                    int v_11 = limit - cursor;
                    lab23: {
                        ket = cursor;
                        lab24: {
                            int v_12 = limit - cursor;
                            lab25: {
                                if (!r_mark_DUr())
                                {
                                    break lab25;
                                }
                                break lab24;
                            }
                            cursor = limit - v_12;
                            lab26: {
                                if (!r_mark_yDU())
                                {
                                    break lab26;
                                }
                                break lab24;
                            }
                            cursor = limit - v_12;
                            lab27: {
                                if (!r_mark_ysA())
                                {
                                    break lab27;
                                }
                                break lab24;
                            }
                            cursor = limit - v_12;
                            if (!r_mark_ymUs_())
                            {
                                cursor = limit - v_11;
                                break lab23;
                            }
                        }
                    }
                    B_continue_stemming_noun_suffixes = false;
                    break lab9;
                }
                cursor = limit - v_8;
                lab28: {
                    if (!r_check_vowel_harmony())
                    {
                        break lab28;
                    }
                    if (find_among_b(a_17) == 0)
                    {
                        break lab28;
                    }
                    lab29: {
                        int v_13 = limit - cursor;
                        lab30: {
                            if (!r_mark_yDU())
                            {
                                break lab30;
                            }
                            break lab29;
                        }
                        cursor = limit - v_13;
                        if (!r_mark_ysA())
                        {
                            break lab28;
                        }
                    }
                    break lab9;
                }
                cursor = limit - v_8;
                lab31: {
                    lab32: {
                        int v_14 = limit - cursor;
                        lab33: {
                            if (!r_mark_sUnUz())
                            {
                                break lab33;
                            }
                            break lab32;
                        }
                        cursor = limit - v_14;
                        lab34: {
                            if (!r_mark_yUz())
                            {
                                break lab34;
                            }
                            break lab32;
                        }
                        cursor = limit - v_14;
                        lab35: {
                            if (!r_mark_sUn())
                            {
                                break lab35;
                            }
                            break lab32;
                        }
                        cursor = limit - v_14;
                        if (!r_mark_yUm())
                        {
                            break lab31;
                        }
                    }
                    bra = cursor;
                    slice_del();
                    int v_15 = limit - cursor;
                    lab36: {
                        ket = cursor;
                        if (!r_mark_ymUs_())
                        {
                            cursor = limit - v_15;
                            break lab36;
                        }
                    }
                    break lab9;
                }
                cursor = limit - v_8;
                if (!r_mark_DUr())
                {
                    break lab8;
                }
                bra = cursor;
                slice_del();
                int v_16 = limit - cursor;
                lab37: {
                    ket = cursor;
                    lab38: {
                        int v_17 = limit - cursor;
                        lab39: {
                            if (!r_mark_sUnUz())
                            {
                                break lab39;
                            }
                            break lab38;
                        }
                        cursor = limit - v_17;
                        lab40: {
                            if (!r_mark_lAr())
                            {
                                break lab40;
                            }
                            break lab38;
                        }
                        cursor = limit - v_17;
                        lab41: {
                            if (!r_mark_yUm())
                            {
                                break lab41;
                            }
                            break lab38;
                        }
                        cursor = limit - v_17;
                        lab42: {
                            if (!r_mark_sUn())
                            {
                                break lab42;
                            }
                            break lab38;
                        }
                        cursor = limit - v_17;
                        lab43: {
                            if (!r_mark_yUz())
                            {
                                break lab43;
                            }
                            break lab38;
                        }
                        cursor = limit - v_17;
                    }
                    if (!r_mark_ymUs_())
                    {
                        cursor = limit - v_16;
                        break lab37;
                    }
                }
            }
            bra = cursor;
            slice_del();
        }
        cursor = limit - v_7;
        if (!B_continue_stemming_noun_suffixes)
        {
            return false;
        }
        int v_18 = limit - cursor;
        lab44: {
            lab45: {
                int v_19 = limit - cursor;
                lab46: {
                    ket = cursor;
                    if (!r_mark_lAr())
                    {
                        break lab46;
                    }
                    bra = cursor;
                    slice_del();
                    int v_20 = limit - cursor;
                    lab47: {
                        if (!r_stem_suffix_chain_before_ki())
                        {
                            cursor = limit - v_20;
                            break lab47;
                        }
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab48: {
                    ket = cursor;
                    if (!r_check_vowel_harmony())
                    {
                        break lab48;
                    }
                    if (find_among_b(a_11) == 0)
                    {
                        break lab48;
                    }
                    if (!r_mark_suffix_with_optional_n_consonant())
                    {
                        break lab48;
                    }
                    bra = cursor;
                    slice_del();
                    int v_21 = limit - cursor;
                    lab49: {
                        lab50: {
                            int v_22 = limit - cursor;
                            lab51: {
                                ket = cursor;
                                if (!r_mark_lArI())
                                {
                                    break lab51;
                                }
                                bra = cursor;
                                slice_del();
                                break lab50;
                            }
                            cursor = limit - v_22;
                            lab52: {
                                ket = cursor;
                                lab53: {
                                    int v_23 = limit - cursor;
                                    lab54: {
                                        if (!r_mark_possessives())
                                        {
                                            break lab54;
                                        }
                                        break lab53;
                                    }
                                    cursor = limit - v_23;
                                    if (!r_mark_sU())
                                    {
                                        break lab52;
                                    }
                                }
                                bra = cursor;
                                slice_del();
                                int v_24 = limit - cursor;
                                lab55: {
                                    ket = cursor;
                                    if (!r_mark_lAr())
                                    {
                                        cursor = limit - v_24;
                                        break lab55;
                                    }
                                    bra = cursor;
                                    slice_del();
                                    if (!r_stem_suffix_chain_before_ki())
                                    {
                                        cursor = limit - v_24;
                                        break lab55;
                                    }
                                }
                                break lab50;
                            }
                            cursor = limit - v_22;
                            ket = cursor;
                            if (!r_mark_lAr())
                            {
                                cursor = limit - v_21;
                                break lab49;
                            }
                            bra = cursor;
                            slice_del();
                            if (!r_stem_suffix_chain_before_ki())
                            {
                                cursor = limit - v_21;
                                break lab49;
                            }
                        }
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab56: {
                    ket = cursor;
                    lab57: {
                        int v_25 = limit - cursor;
                        lab58: {
                            if (!r_mark_ndA())
                            {
                                break lab58;
                            }
                            break lab57;
                        }
                        cursor = limit - v_25;
                        if (!r_check_vowel_harmony())
                        {
                            break lab56;
                        }
                        if (find_among_b(a_5) == 0)
                        {
                            break lab56;
                        }
                    }
                    lab59: {
                        int v_26 = limit - cursor;
                        lab60: {
                            if (!r_mark_lArI())
                            {
                                break lab60;
                            }
                            bra = cursor;
                            slice_del();
                            break lab59;
                        }
                        cursor = limit - v_26;
                        lab61: {
                            if (!r_mark_sU())
                            {
                                break lab61;
                            }
                            bra = cursor;
                            slice_del();
                            int v_27 = limit - cursor;
                            lab62: {
                                ket = cursor;
                                if (!r_mark_lAr())
                                {
                                    cursor = limit - v_27;
                                    break lab62;
                                }
                                bra = cursor;
                                slice_del();
                                if (!r_stem_suffix_chain_before_ki())
                                {
                                    cursor = limit - v_27;
                                    break lab62;
                                }
                            }
                            break lab59;
                        }
                        cursor = limit - v_26;
                        if (!r_stem_suffix_chain_before_ki())
                        {
                            break lab56;
                        }
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab63: {
                    ket = cursor;
                    lab64: {
                        int v_28 = limit - cursor;
                        lab65: {
                            if (!r_check_vowel_harmony())
                            {
                                break lab65;
                            }
                            if (find_among_b(a_9) == 0)
                            {
                                break lab65;
                            }
                            break lab64;
                        }
                        cursor = limit - v_28;
                        if (!r_check_vowel_harmony())
                        {
                            break lab63;
                        }
                        if (find_among_b(a_2) == 0)
                        {
                            break lab63;
                        }
                    }
                    lab66: {
                        int v_29 = limit - cursor;
                        lab67: {
                            if (!r_mark_sU())
                            {
                                break lab67;
                            }
                            bra = cursor;
                            slice_del();
                            int v_30 = limit - cursor;
                            lab68: {
                                ket = cursor;
                                if (!r_mark_lAr())
                                {
                                    cursor = limit - v_30;
                                    break lab68;
                                }
                                bra = cursor;
                                slice_del();
                                if (!r_stem_suffix_chain_before_ki())
                                {
                                    cursor = limit - v_30;
                                    break lab68;
                                }
                            }
                            break lab66;
                        }
                        cursor = limit - v_29;
                        if (!r_mark_lArI())
                        {
                            break lab63;
                        }
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab69: {
                    ket = cursor;
                    if (!r_check_vowel_harmony())
                    {
                        break lab69;
                    }
                    if (find_among_b(a_8) == 0)
                    {
                        break lab69;
                    }
                    bra = cursor;
                    slice_del();
                    int v_31 = limit - cursor;
                    lab70: {
                        ket = cursor;
                        lab71: {
                            int v_32 = limit - cursor;
                            lab72: {
                                if (!r_mark_possessives())
                                {
                                    break lab72;
                                }
                                bra = cursor;
                                slice_del();
                                int v_33 = limit - cursor;
                                lab73: {
                                    ket = cursor;
                                    if (!r_mark_lAr())
                                    {
                                        cursor = limit - v_33;
                                        break lab73;
                                    }
                                    bra = cursor;
                                    slice_del();
                                    if (!r_stem_suffix_chain_before_ki())
                                    {
                                        cursor = limit - v_33;
                                        break lab73;
                                    }
                                }
                                break lab71;
                            }
                            cursor = limit - v_32;
                            lab74: {
                                if (!r_mark_lAr())
                                {
                                    break lab74;
                                }
                                bra = cursor;
                                slice_del();
                                int v_34 = limit - cursor;
                                lab75: {
                                    if (!r_stem_suffix_chain_before_ki())
                                    {
                                        cursor = limit - v_34;
                                        break lab75;
                                    }
                                }
                                break lab71;
                            }
                            cursor = limit - v_32;
                            if (!r_stem_suffix_chain_before_ki())
                            {
                                cursor = limit - v_31;
                                break lab70;
                            }
                        }
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab76: {
                    ket = cursor;
                    lab77: {
                        int v_35 = limit - cursor;
                        lab78: {
                            if (!r_mark_nUn())
                            {
                                break lab78;
                            }
                            break lab77;
                        }
                        cursor = limit - v_35;
                        if (!r_check_vowel_harmony())
                        {
                            break lab76;
                        }
                        if (find_among_b(a_10) == 0)
                        {
                            break lab76;
                        }
                        if (!r_mark_suffix_with_optional_y_consonant())
                        {
                            break lab76;
                        }
                    }
                    bra = cursor;
                    slice_del();
                    int v_36 = limit - cursor;
                    lab79: {
                        lab80: {
                            int v_37 = limit - cursor;
                            lab81: {
                                ket = cursor;
                                if (!r_mark_lAr())
                                {
                                    break lab81;
                                }
                                bra = cursor;
                                slice_del();
                                if (!r_stem_suffix_chain_before_ki())
                                {
                                    break lab81;
                                }
                                break lab80;
                            }
                            cursor = limit - v_37;
                            lab82: {
                                ket = cursor;
                                lab83: {
                                    int v_38 = limit - cursor;
                                    lab84: {
                                        if (!r_mark_possessives())
                                        {
                                            break lab84;
                                        }
                                        break lab83;
                                    }
                                    cursor = limit - v_38;
                                    if (!r_mark_sU())
                                    {
                                        break lab82;
                                    }
                                }
                                bra = cursor;
                                slice_del();
                                int v_39 = limit - cursor;
                                lab85: {
                                    ket = cursor;
                                    if (!r_mark_lAr())
                                    {
                                        cursor = limit - v_39;
                                        break lab85;
                                    }
                                    bra = cursor;
                                    slice_del();
                                    if (!r_stem_suffix_chain_before_ki())
                                    {
                                        cursor = limit - v_39;
                                        break lab85;
                                    }
                                }
                                break lab80;
                            }
                            cursor = limit - v_37;
                            if (!r_stem_suffix_chain_before_ki())
                            {
                                cursor = limit - v_36;
                                break lab79;
                            }
                        }
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab86: {
                    ket = cursor;
                    if (!r_mark_lArI())
                    {
                        break lab86;
                    }
                    bra = cursor;
                    slice_del();
                    break lab45;
                }
                cursor = limit - v_19;
                lab87: {
                    if (!r_stem_suffix_chain_before_ki())
                    {
                        break lab87;
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                lab88: {
                    ket = cursor;
                    lab89: {
                        int v_40 = limit - cursor;
                        lab90: {
                            if (!r_mark_DA())
                            {
                                break lab90;
                            }
                            break lab89;
                        }
                        cursor = limit - v_40;
                        lab91: {
                            if (!r_check_vowel_harmony())
                            {
                                break lab91;
                            }
                            if (!(in_grouping_b(g_U, 105, 305)))
                            {
                                break lab91;
                            }
                            if (!r_mark_suffix_with_optional_y_consonant())
                            {
                                break lab91;
                            }
                            break lab89;
                        }
                        cursor = limit - v_40;
                        if (!r_check_vowel_harmony())
                        {
                            break lab88;
                        }
                        if (find_among_b(a_4) == 0)
                        {
                            break lab88;
                        }
                        if (!r_mark_suffix_with_optional_y_consonant())
                        {
                            break lab88;
                        }
                    }
                    bra = cursor;
                    slice_del();
                    int v_41 = limit - cursor;
                    lab92: {
                        ket = cursor;
                        lab93: {
                            int v_42 = limit - cursor;
                            lab94: {
                                if (!r_mark_possessives())
                                {
                                    break lab94;
                                }
                                bra = cursor;
                                slice_del();
                                int v_43 = limit - cursor;
                                lab95: {
                                    ket = cursor;
                                    if (!r_mark_lAr())
                                    {
                                        cursor = limit - v_43;
                                        break lab95;
                                    }
                                }
                                break lab93;
                            }
                            cursor = limit - v_42;
                            if (!r_mark_lAr())
                            {
                                cursor = limit - v_41;
                                break lab92;
                            }
                        }
                        bra = cursor;
                        slice_del();
                        ket = cursor;
                        if (!r_stem_suffix_chain_before_ki())
                        {
                            cursor = limit - v_41;
                            break lab92;
                        }
                    }
                    break lab45;
                }
                cursor = limit - v_19;
                ket = cursor;
                lab96: {
                    int v_44 = limit - cursor;
                    lab97: {
                        if (!r_mark_possessives())
                        {
                            break lab97;
                        }
                        break lab96;
                    }
                    cursor = limit - v_44;
                    if (!r_mark_sU())
                    {
                        break lab44;
                    }
                }
                bra = cursor;
                slice_del();
                int v_45 = limit - cursor;
                lab98: {
                    ket = cursor;
                    if (!r_mark_lAr())
                    {
                        cursor = limit - v_45;
                        break lab98;
                    }
                    bra = cursor;
                    slice_del();
                    if (!r_stem_suffix_chain_before_ki())
                    {
                        cursor = limit - v_45;
                        break lab98;
                    }
                }
            }
        }
        cursor = limit - v_18;
        cursor = limit_backward;
        limit_backward = cursor;
        cursor = limit;
        {
            int v_46 = limit - cursor;
            lab99: {
                if (!(eq_s_b("ad")))
                {
                    break lab99;
                }
                int v_47 = limit - cursor;
                lab100: {
                    if (!(eq_s_b("soy")))
                    {
                        cursor = limit - v_47;
                        break lab100;
                    }
                }
                if (cursor > limit_backward)
                {
                    break lab99;
                }
                return false;
            }
            cursor = limit - v_46;
        }
        int v_48 = limit - cursor;
        lab101: {
            ket = cursor;
            bra = cursor;
            lab102: {
                lab103: {
                    if (!(eq_s_b("d")))
                    {
                        break lab103;
                    }
                    break lab102;
                }
                if (!(eq_s_b("g")))
                {
                    break lab101;
                }
            }
            if (!go_out_grouping_b(g_vowel, 97, 305))
            {
                break lab101;
            }
            lab104: {
                int v_49 = limit - cursor;
                lab105: {
                    lab106: {
                        lab107: {
                            if (!(eq_s_b("a")))
                            {
                                break lab107;
                            }
                            break lab106;
                        }
                        if (!(eq_s_b("\u0131")))
                        {
                            break lab105;
                        }
                    }
                    slice_from("\u0131");
                    break lab104;
                }
                cursor = limit - v_49;
                lab108: {
                    lab109: {
                        lab110: {
                            if (!(eq_s_b("e")))
                            {
                                break lab110;
                            }
                            break lab109;
                        }
                        if (!(eq_s_b("i")))
                        {
                            break lab108;
                        }
                    }
                    slice_from("i");
                    break lab104;
                }
                cursor = limit - v_49;
                lab111: {
                    lab112: {
                        lab113: {
                            if (!(eq_s_b("o")))
                            {
                                break lab113;
                            }
                            break lab112;
                        }
                        if (!(eq_s_b("u")))
                        {
                            break lab111;
                        }
                    }
                    slice_from("u");
                    break lab104;
                }
                cursor = limit - v_49;
                lab114: {
                    lab115: {
                        if (!(eq_s_b("\u00F6")))
                        {
                            break lab115;
                        }
                        break lab114;
                    }
                    if (!(eq_s_b("\u00FC")))
                    {
                        break lab101;
                    }
                }
                slice_from("\u00FC");
            }
        }
        cursor = limit - v_48;
        int v_50 = limit - cursor;
        lab116: {
            ket = cursor;
            among_var = find_among_b(a_23);
            if (among_var == 0)
            {
                break lab116;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_from("p");
                    break;
                case 2:
                    slice_from("\u00E7");
                    break;
                case 3:
                    slice_from("t");
                    break;
                case 4:
                    slice_from("k");
                    break;
            }
        }
        cursor = limit - v_50;
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof turkishStemmer;
    }

    @Override
    public int hashCode() {
        return turkishStemmer.class.getName().hashCode();
    }

}
