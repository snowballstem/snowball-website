// Generated from spanish.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from spanish.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class spanishStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("", -1, 6),
        new Among("\u00E1", 0, 1),
        new Among("\u00E9", 0, 2),
        new Among("\u00ED", 0, 3),
        new Among("\u00F3", 0, 4),
        new Among("\u00FA", 0, 5)
    };

    private final static Among[] a_1 = {
        new Among("la", -1, -1),
        new Among("sela", 0, -1),
        new Among("le", -1, -1),
        new Among("me", -1, -1),
        new Among("se", -1, -1),
        new Among("lo", -1, -1),
        new Among("selo", 5, -1),
        new Among("las", -1, -1),
        new Among("selas", 7, -1),
        new Among("les", -1, -1),
        new Among("los", -1, -1),
        new Among("selos", 10, -1),
        new Among("nos", -1, -1)
    };

    private final static Among[] a_2 = {
        new Among("ando", -1, 6),
        new Among("iendo", -1, 6),
        new Among("yendo", -1, 7),
        new Among("\u00E1ndo", -1, 2),
        new Among("i\u00E9ndo", -1, 1),
        new Among("ar", -1, 6),
        new Among("er", -1, 6),
        new Among("ir", -1, 6),
        new Among("\u00E1r", -1, 3),
        new Among("\u00E9r", -1, 4),
        new Among("\u00EDr", -1, 5)
    };

    private final static Among[] a_3 = {
        new Among("ic", -1, -1),
        new Among("ad", -1, -1),
        new Among("os", -1, -1),
        new Among("iv", -1, 1)
    };

    private final static Among[] a_4 = {
        new Among("able", -1, 1),
        new Among("ible", -1, 1),
        new Among("ante", -1, 1)
    };

    private final static Among[] a_5 = {
        new Among("ic", -1, 1),
        new Among("abil", -1, 1),
        new Among("iv", -1, 1)
    };

    private final static Among[] a_6 = {
        new Among("ica", -1, 1),
        new Among("ancia", -1, 2),
        new Among("encia", -1, 5),
        new Among("adora", -1, 2),
        new Among("osa", -1, 1),
        new Among("ista", -1, 1),
        new Among("iva", -1, 9),
        new Among("anza", -1, 1),
        new Among("log\u00EDa", -1, 3),
        new Among("idad", -1, 8),
        new Among("able", -1, 1),
        new Among("ible", -1, 1),
        new Among("ante", -1, 2),
        new Among("mente", -1, 7),
        new Among("amente", 13, 6),
        new Among("acion", -1, 2),
        new Among("ucion", -1, 4),
        new Among("aci\u00F3n", -1, 2),
        new Among("uci\u00F3n", -1, 4),
        new Among("ico", -1, 1),
        new Among("ismo", -1, 1),
        new Among("oso", -1, 1),
        new Among("amiento", -1, 1),
        new Among("imiento", -1, 1),
        new Among("ivo", -1, 9),
        new Among("ador", -1, 2),
        new Among("icas", -1, 1),
        new Among("ancias", -1, 2),
        new Among("encias", -1, 5),
        new Among("adoras", -1, 2),
        new Among("osas", -1, 1),
        new Among("istas", -1, 1),
        new Among("ivas", -1, 9),
        new Among("anzas", -1, 1),
        new Among("log\u00EDas", -1, 3),
        new Among("idades", -1, 8),
        new Among("ables", -1, 1),
        new Among("ibles", -1, 1),
        new Among("aciones", -1, 2),
        new Among("uciones", -1, 4),
        new Among("adores", -1, 2),
        new Among("antes", -1, 2),
        new Among("icos", -1, 1),
        new Among("ismos", -1, 1),
        new Among("osos", -1, 1),
        new Among("amientos", -1, 1),
        new Among("imientos", -1, 1),
        new Among("ivos", -1, 9)
    };

    private final static Among[] a_7 = {
        new Among("ya", -1, 1),
        new Among("ye", -1, 1),
        new Among("yan", -1, 1),
        new Among("yen", -1, 1),
        new Among("yeron", -1, 1),
        new Among("yendo", -1, 1),
        new Among("yo", -1, 1),
        new Among("yas", -1, 1),
        new Among("yes", -1, 1),
        new Among("yais", -1, 1),
        new Among("yamos", -1, 1),
        new Among("y\u00F3", -1, 1)
    };

    private final static Among[] a_8 = {
        new Among("aba", -1, 2),
        new Among("ada", -1, 2),
        new Among("ida", -1, 2),
        new Among("ara", -1, 2),
        new Among("iera", -1, 2),
        new Among("\u00EDa", -1, 2),
        new Among("ar\u00EDa", 5, 2),
        new Among("er\u00EDa", 5, 2),
        new Among("ir\u00EDa", 5, 2),
        new Among("ad", -1, 2),
        new Among("ed", -1, 2),
        new Among("id", -1, 2),
        new Among("ase", -1, 2),
        new Among("iese", -1, 2),
        new Among("aste", -1, 2),
        new Among("iste", -1, 2),
        new Among("an", -1, 2),
        new Among("aban", 16, 2),
        new Among("aran", 16, 2),
        new Among("ieran", 16, 2),
        new Among("\u00EDan", 16, 2),
        new Among("ar\u00EDan", 20, 2),
        new Among("er\u00EDan", 20, 2),
        new Among("ir\u00EDan", 20, 2),
        new Among("en", -1, 1),
        new Among("asen", 24, 2),
        new Among("iesen", 24, 2),
        new Among("aron", -1, 2),
        new Among("ieron", -1, 2),
        new Among("ar\u00E1n", -1, 2),
        new Among("er\u00E1n", -1, 2),
        new Among("ir\u00E1n", -1, 2),
        new Among("ado", -1, 2),
        new Among("ido", -1, 2),
        new Among("ando", -1, 2),
        new Among("iendo", -1, 2),
        new Among("ar", -1, 2),
        new Among("er", -1, 2),
        new Among("ir", -1, 2),
        new Among("as", -1, 2),
        new Among("abas", 39, 2),
        new Among("adas", 39, 2),
        new Among("idas", 39, 2),
        new Among("aras", 39, 2),
        new Among("ieras", 39, 2),
        new Among("\u00EDas", 39, 2),
        new Among("ar\u00EDas", 45, 2),
        new Among("er\u00EDas", 45, 2),
        new Among("ir\u00EDas", 45, 2),
        new Among("es", -1, 1),
        new Among("ases", 49, 2),
        new Among("ieses", 49, 2),
        new Among("abais", -1, 2),
        new Among("arais", -1, 2),
        new Among("ierais", -1, 2),
        new Among("\u00EDais", -1, 2),
        new Among("ar\u00EDais", 55, 2),
        new Among("er\u00EDais", 55, 2),
        new Among("ir\u00EDais", 55, 2),
        new Among("aseis", -1, 2),
        new Among("ieseis", -1, 2),
        new Among("asteis", -1, 2),
        new Among("isteis", -1, 2),
        new Among("\u00E1is", -1, 2),
        new Among("\u00E9is", -1, 1),
        new Among("ar\u00E9is", 64, 2),
        new Among("er\u00E9is", 64, 2),
        new Among("ir\u00E9is", 64, 2),
        new Among("ados", -1, 2),
        new Among("idos", -1, 2),
        new Among("amos", -1, 2),
        new Among("\u00E1bamos", 70, 2),
        new Among("\u00E1ramos", 70, 2),
        new Among("i\u00E9ramos", 70, 2),
        new Among("\u00EDamos", 70, 2),
        new Among("ar\u00EDamos", 74, 2),
        new Among("er\u00EDamos", 74, 2),
        new Among("ir\u00EDamos", 74, 2),
        new Among("emos", -1, 1),
        new Among("aremos", 78, 2),
        new Among("eremos", 78, 2),
        new Among("iremos", 78, 2),
        new Among("\u00E1semos", 78, 2),
        new Among("i\u00E9semos", 78, 2),
        new Among("imos", -1, 2),
        new Among("ar\u00E1s", -1, 2),
        new Among("er\u00E1s", -1, 2),
        new Among("ir\u00E1s", -1, 2),
        new Among("\u00EDs", -1, 2),
        new Among("ar\u00E1", -1, 2),
        new Among("er\u00E1", -1, 2),
        new Among("ir\u00E1", -1, 2),
        new Among("ar\u00E9", -1, 2),
        new Among("er\u00E9", -1, 2),
        new Among("ir\u00E9", -1, 2),
        new Among("i\u00F3", -1, 2)
    };

    private final static Among[] a_9 = {
        new Among("a", -1, 1),
        new Among("e", -1, 2),
        new Among("o", -1, 1),
        new Among("os", -1, 1),
        new Among("\u00E1", -1, 1),
        new Among("\u00E9", -1, 2),
        new Among("\u00ED", -1, 1),
        new Among("\u00F3", -1, 1)
    };

    private static final char[] g_v = {17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 17, 4, 10 };


    @Override
    public boolean stem() {
        int among_var;
        int I_p2;
        int I_p1;
        int I_pV;
        lab0: {
            I_pV = limit;
            I_p1 = limit;
            I_p2 = limit;
            int v_1 = cursor;
            lab1: {
                lab2: {
                    int v_2 = cursor;
                    lab3: {
                        if (!(in_grouping(g_v, 97, 252)))
                        {
                            break lab3;
                        }
                        lab4: {
                            int v_3 = cursor;
                            lab5: {
                                if (!(out_grouping(g_v, 97, 252)))
                                {
                                    break lab5;
                                }
                                if (!go_out_grouping(g_v, 97, 252))
                                {
                                    break lab5;
                                }
                                cursor++;
                                break lab4;
                            }
                            cursor = v_3;
                            if (!(in_grouping(g_v, 97, 252)))
                            {
                                break lab3;
                            }
                            if (!go_in_grouping(g_v, 97, 252))
                            {
                                break lab3;
                            }
                            cursor++;
                        }
                        break lab2;
                    }
                    cursor = v_2;
                    if (!(out_grouping(g_v, 97, 252)))
                    {
                        break lab1;
                    }
                    lab6: {
                        int v_4 = cursor;
                        lab7: {
                            if (!(out_grouping(g_v, 97, 252)))
                            {
                                break lab7;
                            }
                            if (!go_out_grouping(g_v, 97, 252))
                            {
                                break lab7;
                            }
                            cursor++;
                            break lab6;
                        }
                        cursor = v_4;
                        if (!(in_grouping(g_v, 97, 252)))
                        {
                            break lab1;
                        }
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                    }
                }
                I_pV = cursor;
            }
            cursor = v_1;
            int v_5 = cursor;
            lab8: {
                if (!go_out_grouping(g_v, 97, 252))
                {
                    break lab8;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 252))
                {
                    break lab8;
                }
                cursor++;
                I_p1 = cursor;
                if (!go_out_grouping(g_v, 97, 252))
                {
                    break lab8;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 252))
                {
                    break lab8;
                }
                cursor++;
                I_p2 = cursor;
            }
            cursor = v_5;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_6 = limit - cursor;
        lab9: {
            ket = cursor;
            if (find_among_b(a_1) == 0)
            {
                break lab9;
            }
            bra = cursor;
            among_var = find_among_b(a_2);
            if (among_var == 0)
            {
                break lab9;
            }
            if (I_pV > cursor)
            {
                break lab9;
            }
            switch (among_var) {
                case 1:
                    bra = cursor;
                    slice_from("iendo");
                    break;
                case 2:
                    bra = cursor;
                    slice_from("ando");
                    break;
                case 3:
                    bra = cursor;
                    slice_from("ar");
                    break;
                case 4:
                    bra = cursor;
                    slice_from("er");
                    break;
                case 5:
                    bra = cursor;
                    slice_from("ir");
                    break;
                case 6:
                    slice_del();
                    break;
                case 7:
                    if (!(eq_s_b("u")))
                    {
                        break lab9;
                    }
                    slice_del();
                    break;
            }
        }
        cursor = limit - v_6;
        int v_7 = limit - cursor;
        lab10: {
            lab11: {
                int v_8 = limit - cursor;
                lab12: {
                    ket = cursor;
                    among_var = find_among_b(a_6);
                    if (among_var == 0)
                    {
                        break lab12;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            break;
                        case 2:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            int v_9 = limit - cursor;
                            lab13: {
                                ket = cursor;
                                if (!(eq_s_b("ic")))
                                {
                                    cursor = limit - v_9;
                                    break lab13;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_9;
                                    break lab13;
                                }
                                slice_del();
                            }
                            break;
                        case 3:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_from("log");
                            break;
                        case 4:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_from("u");
                            break;
                        case 5:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_from("ente");
                            break;
                        case 6:
                            if (I_p1 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            int v_10 = limit - cursor;
                            lab14: {
                                ket = cursor;
                                among_var = find_among_b(a_3);
                                if (among_var == 0)
                                {
                                    cursor = limit - v_10;
                                    break lab14;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_10;
                                    break lab14;
                                }
                                slice_del();
                                switch (among_var) {
                                    case 1:
                                        ket = cursor;
                                        if (!(eq_s_b("at")))
                                        {
                                            cursor = limit - v_10;
                                            break lab14;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_10;
                                            break lab14;
                                        }
                                        slice_del();
                                        break;
                                }
                            }
                            break;
                        case 7:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            int v_11 = limit - cursor;
                            lab15: {
                                ket = cursor;
                                if (find_among_b(a_4) == 0)
                                {
                                    cursor = limit - v_11;
                                    break lab15;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_11;
                                    break lab15;
                                }
                                slice_del();
                            }
                            break;
                        case 8:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            int v_12 = limit - cursor;
                            lab16: {
                                ket = cursor;
                                if (find_among_b(a_5) == 0)
                                {
                                    cursor = limit - v_12;
                                    break lab16;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_12;
                                    break lab16;
                                }
                                slice_del();
                            }
                            break;
                        case 9:
                            if (I_p2 > cursor)
                            {
                                break lab12;
                            }
                            slice_del();
                            int v_13 = limit - cursor;
                            lab17: {
                                ket = cursor;
                                if (!(eq_s_b("at")))
                                {
                                    cursor = limit - v_13;
                                    break lab17;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_13;
                                    break lab17;
                                }
                                slice_del();
                            }
                            break;
                    }
                    break lab11;
                }
                cursor = limit - v_8;
                lab18: {
                    if (cursor < I_pV)
                    {
                        break lab18;
                    }
                    int v_14 = limit_backward;
                    limit_backward = I_pV;
                    ket = cursor;
                    if (find_among_b(a_7) == 0)
                    {
                        limit_backward = v_14;
                        break lab18;
                    }
                    bra = cursor;
                    limit_backward = v_14;
                    if (!(eq_s_b("u")))
                    {
                        break lab18;
                    }
                    slice_del();
                    break lab11;
                }
                cursor = limit - v_8;
                if (cursor < I_pV)
                {
                    break lab10;
                }
                int v_15 = limit_backward;
                limit_backward = I_pV;
                ket = cursor;
                among_var = find_among_b(a_8);
                if (among_var == 0)
                {
                    limit_backward = v_15;
                    break lab10;
                }
                bra = cursor;
                limit_backward = v_15;
                switch (among_var) {
                    case 1:
                        int v_16 = limit - cursor;
                        lab19: {
                            if (!(eq_s_b("u")))
                            {
                                cursor = limit - v_16;
                                break lab19;
                            }
                            int v_17 = limit - cursor;
                            if (!(eq_s_b("g")))
                            {
                                cursor = limit - v_16;
                                break lab19;
                            }
                            cursor = limit - v_17;
                        }
                        bra = cursor;
                        slice_del();
                        break;
                    case 2:
                        slice_del();
                        break;
                }
            }
        }
        cursor = limit - v_7;
        int v_18 = limit - cursor;
        lab20: {
            ket = cursor;
            among_var = find_among_b(a_9);
            if (among_var == 0)
            {
                break lab20;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    if (I_pV > cursor)
                    {
                        break lab20;
                    }
                    slice_del();
                    break;
                case 2:
                    if (I_pV > cursor)
                    {
                        break lab20;
                    }
                    slice_del();
                    int v_19 = limit - cursor;
                    lab21: {
                        ket = cursor;
                        if (!(eq_s_b("u")))
                        {
                            cursor = limit - v_19;
                            break lab21;
                        }
                        bra = cursor;
                        int v_20 = limit - cursor;
                        if (!(eq_s_b("g")))
                        {
                            cursor = limit - v_19;
                            break lab21;
                        }
                        cursor = limit - v_20;
                        if (I_pV > cursor)
                        {
                            cursor = limit - v_19;
                            break lab21;
                        }
                        slice_del();
                    }
                    break;
            }
        }
        cursor = limit - v_18;
        cursor = limit_backward;
        int v_21 = cursor;
        lab22: {
            while (true)
            {
                int v_22 = cursor;
                lab23: {
                    bra = cursor;
                    among_var = find_among(a_0);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("a");
                            break;
                        case 2:
                            slice_from("e");
                            break;
                        case 3:
                            slice_from("i");
                            break;
                        case 4:
                            slice_from("o");
                            break;
                        case 5:
                            slice_from("u");
                            break;
                        case 6:
                            if (cursor >= limit)
                            {
                                break lab23;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_22;
                break;
            }
        }
        cursor = v_21;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof spanishStemmer;
    }

    @Override
    public int hashCode() {
        return spanishStemmer.class.getName().hashCode();
    }

}
