// Generated from german.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from german.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class germanStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("", -1, 5),
        new Among("ae", 0, 2),
        new Among("oe", 0, 3),
        new Among("qu", 0, -1),
        new Among("ue", 0, 4),
        new Among("\u00DF", 0, 1)
    };

    private final static Among[] a_1 = {
        new Among("", -1, 5),
        new Among("U", 0, 2),
        new Among("Y", 0, 1),
        new Among("\u00E4", 0, 3),
        new Among("\u00F6", 0, 4),
        new Among("\u00FC", 0, 2)
    };

    private final static Among[] a_2 = {
        new Among("e", -1, 3),
        new Among("em", -1, 1),
        new Among("en", -1, 3),
        new Among("erinnen", 2, 2),
        new Among("erin", -1, 2),
        new Among("ln", -1, 5),
        new Among("ern", -1, 2),
        new Among("er", -1, 2),
        new Among("s", -1, 4),
        new Among("es", 8, 3),
        new Among("lns", 8, 5)
    };

    private final static Among[] a_3 = {
        new Among("tick", -1, -1),
        new Among("plan", -1, -1),
        new Among("geordn", -1, -1),
        new Among("intern", -1, -1),
        new Among("tr", -1, -1)
    };

    private final static Among[] a_4 = {
        new Among("en", -1, 1),
        new Among("er", -1, 1),
        new Among("et", -1, 3),
        new Among("st", -1, 2),
        new Among("est", 3, 1)
    };

    private final static Among[] a_5 = {
        new Among("ig", -1, 1),
        new Among("lich", -1, 1)
    };

    private final static Among[] a_6 = {
        new Among("end", -1, 1),
        new Among("ig", -1, 2),
        new Among("ung", -1, 1),
        new Among("lich", -1, 3),
        new Among("isch", -1, 2),
        new Among("ik", -1, 2),
        new Among("heit", -1, 3),
        new Among("keit", -1, 4)
    };

    private final static Among[] a_7 = {
        new Among("'", -1, 1),
        new Among("'sch", -1, 1),
        new Among("'s", -1, 1)
    };

    private static final char[] g_v = {17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 32, 8 };

    private static final char[] g_et_ending = {1, 128, 198, 227, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

    private static final char[] g_s_ending = {117, 30, 5 };

    private static final char[] g_st_ending = {117, 30, 4 };


    @Override
    public boolean stem() {
        int among_var;
        int I_x;
        int I_p2;
        int I_p1;
        int v_1 = cursor;
        lab0: {
            int v_2 = cursor;
            while (true)
            {
                int v_3 = cursor;
                lab1: {
                    golab2: while (true)
                    {
                        int v_4 = cursor;
                        lab3: {
                            if (!(in_grouping(g_v, 97, 252)))
                            {
                                break lab3;
                            }
                            bra = cursor;
                            lab4: {
                                int v_5 = cursor;
                                lab5: {
                                    if (!(eq_s("u")))
                                    {
                                        break lab5;
                                    }
                                    ket = cursor;
                                    if (!(in_grouping(g_v, 97, 252)))
                                    {
                                        break lab5;
                                    }
                                    slice_from("U");
                                    break lab4;
                                }
                                cursor = v_5;
                                if (!(eq_s("y")))
                                {
                                    break lab3;
                                }
                                ket = cursor;
                                if (!(in_grouping(g_v, 97, 252)))
                                {
                                    break lab3;
                                }
                                slice_from("Y");
                            }
                            cursor = v_4;
                            break golab2;
                        }
                        cursor = v_4;
                        if (cursor >= limit)
                        {
                            break lab1;
                        }
                        cursor++;
                    }
                    continue;
                }
                cursor = v_3;
                break;
            }
            cursor = v_2;
            while (true)
            {
                int v_6 = cursor;
                lab6: {
                    bra = cursor;
                    among_var = find_among(a_0);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("ss");
                            break;
                        case 2:
                            slice_from("\u00E4");
                            break;
                        case 3:
                            slice_from("\u00F6");
                            break;
                        case 4:
                            slice_from("\u00FC");
                            break;
                        case 5:
                            if (cursor >= limit)
                            {
                                break lab6;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_6;
                break;
            }
        }
        cursor = v_1;
        int v_7 = cursor;
        lab7: {
            I_p1 = limit;
            I_p2 = limit;
            int v_8 = cursor;
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab7;
                }
                cursor = c;
            }
            I_x = cursor;
            cursor = v_8;
            if (!go_out_grouping(g_v, 97, 252))
            {
                break lab7;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 252))
            {
                break lab7;
            }
            cursor++;
            I_p1 = cursor;
            lab8: {
                if (I_p1 >= I_x)
                {
                    break lab8;
                }
                I_p1 = I_x;
            }
            if (!go_out_grouping(g_v, 97, 252))
            {
                break lab7;
            }
            cursor++;
            if (!go_in_grouping(g_v, 97, 252))
            {
                break lab7;
            }
            cursor++;
            I_p2 = cursor;
        }
        cursor = v_7;
        limit_backward = cursor;
        cursor = limit;
        lab9: {
            int v_9 = limit - cursor;
            lab10: {
                ket = cursor;
                among_var = find_among_b(a_2);
                if (among_var == 0)
                {
                    break lab10;
                }
                bra = cursor;
                if (I_p1 > cursor)
                {
                    break lab10;
                }
                switch (among_var) {
                    case 1:
                        lab11: {
                            if (!(eq_s_b("syst")))
                            {
                                break lab11;
                            }
                            break lab10;
                        }
                        slice_del();
                        break;
                    case 2:
                        slice_del();
                        break;
                    case 3:
                        slice_del();
                        int v_10 = limit - cursor;
                        lab12: {
                            ket = cursor;
                            if (!(eq_s_b("s")))
                            {
                                cursor = limit - v_10;
                                break lab12;
                            }
                            bra = cursor;
                            if (!(eq_s_b("nis")))
                            {
                                cursor = limit - v_10;
                                break lab12;
                            }
                            slice_del();
                        }
                        break;
                    case 4:
                        if (!(in_grouping_b(g_s_ending, 98, 116)))
                        {
                            break lab10;
                        }
                        slice_del();
                        break;
                    case 5:
                        slice_from("l");
                        break;
                }
            }
            cursor = limit - v_9;
            int v_11 = limit - cursor;
            lab13: {
                ket = cursor;
                among_var = find_among_b(a_4);
                if (among_var == 0)
                {
                    break lab13;
                }
                bra = cursor;
                if (I_p1 > cursor)
                {
                    break lab13;
                }
                switch (among_var) {
                    case 1:
                        slice_del();
                        break;
                    case 2:
                        if (!(in_grouping_b(g_st_ending, 98, 116)))
                        {
                            break lab13;
                        }
                        {
                            int c = cursor - 3;
                            if (c < limit_backward)
                            {
                                break lab13;
                            }
                            cursor = c;
                        }
                        slice_del();
                        break;
                    case 3:
                        int v_12 = limit - cursor;
                        if (!(in_grouping_b(g_et_ending, 85, 228)))
                        {
                            break lab13;
                        }
                        cursor = limit - v_12;
                        {
                            int v_13 = limit - cursor;
                            lab14: {
                                if (find_among_b(a_3) == 0)
                                {
                                    break lab14;
                                }
                                break lab13;
                            }
                            cursor = limit - v_13;
                        }
                        slice_del();
                        break;
                }
            }
            cursor = limit - v_11;
            int v_14 = limit - cursor;
            lab15: {
                ket = cursor;
                among_var = find_among_b(a_6);
                if (among_var == 0)
                {
                    break lab15;
                }
                bra = cursor;
                if (I_p2 > cursor)
                {
                    break lab15;
                }
                switch (among_var) {
                    case 1:
                        slice_del();
                        int v_15 = limit - cursor;
                        lab16: {
                            ket = cursor;
                            if (!(eq_s_b("ig")))
                            {
                                cursor = limit - v_15;
                                break lab16;
                            }
                            bra = cursor;
                            lab17: {
                                if (!(eq_s_b("e")))
                                {
                                    break lab17;
                                }
                                cursor = limit - v_15;
                                break lab16;
                            }
                            if (I_p2 > cursor)
                            {
                                cursor = limit - v_15;
                                break lab16;
                            }
                            slice_del();
                        }
                        break;
                    case 2:
                        lab18: {
                            if (!(eq_s_b("e")))
                            {
                                break lab18;
                            }
                            break lab15;
                        }
                        slice_del();
                        break;
                    case 3:
                        slice_del();
                        int v_16 = limit - cursor;
                        lab19: {
                            ket = cursor;
                            lab20: {
                                lab21: {
                                    if (!(eq_s_b("er")))
                                    {
                                        break lab21;
                                    }
                                    break lab20;
                                }
                                if (!(eq_s_b("en")))
                                {
                                    cursor = limit - v_16;
                                    break lab19;
                                }
                            }
                            bra = cursor;
                            if (I_p1 > cursor)
                            {
                                cursor = limit - v_16;
                                break lab19;
                            }
                            slice_del();
                        }
                        break;
                    case 4:
                        slice_del();
                        int v_17 = limit - cursor;
                        lab22: {
                            ket = cursor;
                            if (find_among_b(a_5) == 0)
                            {
                                cursor = limit - v_17;
                                break lab22;
                            }
                            bra = cursor;
                            if (I_p2 > cursor)
                            {
                                cursor = limit - v_17;
                                break lab22;
                            }
                            slice_del();
                        }
                        break;
                }
            }
            cursor = limit - v_14;
            int v_18 = limit - cursor;
            lab23: {
                ket = cursor;
                if (find_among_b(a_7) == 0)
                {
                    break lab23;
                }
                bra = cursor;
                if (cursor <= limit_backward)
                {
                    break lab23;
                }
                cursor--;
                if (cursor <= limit_backward)
                {
                    break lab23;
                }
                slice_del();
            }
            cursor = limit - v_18;
        }
        cursor = limit_backward;
        int v_19 = cursor;
        lab24: {
            while (true)
            {
                int v_20 = cursor;
                lab25: {
                    bra = cursor;
                    among_var = find_among(a_1);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("y");
                            break;
                        case 2:
                            slice_from("u");
                            break;
                        case 3:
                            slice_from("a");
                            break;
                        case 4:
                            slice_from("o");
                            break;
                        case 5:
                            if (cursor >= limit)
                            {
                                break lab25;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_20;
                break;
            }
        }
        cursor = v_19;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof germanStemmer;
    }

    @Override
    public int hashCode() {
        return germanStemmer.class.getName().hashCode();
    }

}
