// Generated from earlymodernenglish.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from earlymodernenglish.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class earlymodernenglishStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("", -1, 4),
        new Among("\u00E6", 0, 1),
        new Among("\u0153", 0, 2),
        new Among("\u017F", 0, 3)
    };

    private final static Among[] a_1 = {
        new Among("o'er", -1, 1),
        new Among("t'", -1, 2),
        new Among("th'", -1, 2)
    };

    private final static Among[] a_2 = {
        new Among("arsen", -1, -1),
        new Among("commun", -1, -1),
        new Among("emerg", -1, -1),
        new Among("gener", -1, -1),
        new Among("inter", -1, -1),
        new Among("later", -1, -1),
        new Among("organ", -1, -1),
        new Among("past", -1, -1),
        new Among("univers", -1, -1)
    };

    private final static Among[] a_3 = {
        new Among("'", -1, 1),
        new Among("'s'", 0, 1),
        new Among("'s", -1, 1)
    };

    private final static Among[] a_4 = {
        new Among("ied", -1, 2),
        new Among("lie", -1, 5),
        new Among("e'er", -1, 4),
        new Among("s", -1, 3),
        new Among("ies", 3, 2),
        new Among("sses", 3, 1),
        new Among("ss", 3, -1),
        new Among("us", 3, -1)
    };

    private final static Among[] a_5 = {
        new Among("succ", -1, 1),
        new Among("proc", -1, 1),
        new Among("exc", -1, 1)
    };

    private final static Among[] a_6 = {
        new Among("even", -1, 2),
        new Among("cann", -1, 2),
        new Among("inn", -1, 2),
        new Among("earr", -1, 2),
        new Among("herr", -1, 2),
        new Among("out", -1, 2),
        new Among("y", -1, 1)
    };

    private final static Among[] a_7 = {
        new Among("", -1, -1),
        new Among("'d", 0, 2),
        new Among("ed", 0, 2),
        new Among("eed", 2, 1),
        new Among("ing", 0, 3),
        new Among("eth", 0, 2),
        new Among("'t", 0, 2),
        new Among("'st", 0, 2),
        new Among("'dst", 0, 2),
        new Among("edst", 0, 2),
        new Among("est", 0, 2),
        new Among("'dly", 0, 2),
        new Among("edly", 0, 2),
        new Among("eedly", 12, 1),
        new Among("ingly", 0, 2)
    };

    private final static Among[] a_8 = {
        new Among("", -1, 3),
        new Among("bb", 0, 2),
        new Among("dd", 0, 2),
        new Among("ff", 0, 2),
        new Among("gg", 0, 2),
        new Among("bl", 0, 1),
        new Among("mm", 0, 2),
        new Among("nn", 0, 2),
        new Among("pp", 0, 2),
        new Among("rr", 0, 2),
        new Among("at", 0, 1),
        new Among("tt", 0, 2),
        new Among("iz", 0, 1)
    };

    private final static Among[] a_9 = {
        new Among("anci", -1, 3),
        new Among("enci", -1, 2),
        new Among("ogi", -1, 14),
        new Among("li", -1, 16),
        new Among("bli", 3, 12),
        new Among("abli", 4, 4),
        new Among("alli", 3, 8),
        new Among("fulli", 3, 9),
        new Among("lessli", 3, 15),
        new Among("ousli", 3, 10),
        new Among("entli", 3, 5),
        new Among("aliti", -1, 8),
        new Among("biliti", -1, 12),
        new Among("iviti", -1, 11),
        new Among("tional", -1, 1),
        new Among("ational", 14, 7),
        new Among("alism", -1, 8),
        new Among("ation", -1, 7),
        new Among("ization", 17, 6),
        new Among("izer", -1, 6),
        new Among("ator", -1, 7),
        new Among("iveness", -1, 11),
        new Among("fulness", -1, 9),
        new Among("ousness", -1, 10),
        new Among("ogist", -1, 13)
    };

    private final static Among[] a_10 = {
        new Among("icate", -1, 4),
        new Among("ative", -1, 6),
        new Among("alize", -1, 3),
        new Among("iciti", -1, 4),
        new Among("ical", -1, 4),
        new Among("tional", -1, 1),
        new Among("ational", 5, 2),
        new Among("ful", -1, 5),
        new Among("ness", -1, 5)
    };

    private final static Among[] a_11 = {
        new Among("ic", -1, 1),
        new Among("ance", -1, 1),
        new Among("ence", -1, 1),
        new Among("able", -1, 1),
        new Among("ible", -1, 1),
        new Among("ate", -1, 1),
        new Among("ive", -1, 1),
        new Among("ize", -1, 1),
        new Among("iti", -1, 1),
        new Among("al", -1, 1),
        new Among("ism", -1, 1),
        new Among("ion", -1, 2),
        new Among("er", -1, 1),
        new Among("ous", -1, 1),
        new Among("ant", -1, 1),
        new Among("ent", -1, 1),
        new Among("ment", 15, 1),
        new Among("ement", 16, 1)
    };

    private final static Among[] a_12 = {
        new Among("'nd", -1, 3),
        new Among("e", -1, 1),
        new Among("'li", -1, 6),
        new Among("'ri", -1, 5),
        new Among("l", -1, 2),
        new Among("'n", -1, 3),
        new Among("'r", -1, 4),
        new Among("'rous", -1, 4)
    };

    private final static Among[] a_13 = {
        new Among("andes", -1, -1),
        new Among("atlas", -1, -1),
        new Among("bias", -1, -1),
        new Among("cosmos", -1, -1),
        new Among("early", -1, 6),
        new Among("gently", -1, 4),
        new Among("howe", -1, -1),
        new Among("idly", -1, 3),
        new Among("news", -1, -1),
        new Among("only", -1, 7),
        new Among("singly", -1, 8),
        new Among("skies", -1, 2),
        new Among("skis", -1, 1),
        new Among("sky", -1, -1),
        new Among("ugly", -1, 5)
    };

    private static final char[] g_aeo = {17, 64 };

    private static final char[] g_v = {17, 65, 16, 1 };

    private static final char[] g_v_WXY = {1, 17, 65, 208, 1 };

    private static final char[] g_valid_LI = {55, 141, 2 };


    private boolean r_shortv() {
        lab0: {
            int v_1 = limit - cursor;
            lab1: {
                if (!(out_grouping_b(g_v_WXY, 89, 121)))
                {
                    break lab1;
                }
                if (!(in_grouping_b(g_v, 97, 121)))
                {
                    break lab1;
                }
                if (!(out_grouping_b(g_v, 97, 121)))
                {
                    break lab1;
                }
                break lab0;
            }
            cursor = limit - v_1;
            lab2: {
                if (!(out_grouping_b(g_v, 97, 121)))
                {
                    break lab2;
                }
                if (!(in_grouping_b(g_v, 97, 121)))
                {
                    break lab2;
                }
                if (cursor > limit_backward)
                {
                    break lab2;
                }
                break lab0;
            }
            cursor = limit - v_1;
            if (!(eq_s_b("past")))
            {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean stem() {
        int among_var;
        boolean B_Y_found;
        int I_p2;
        int I_p1;
        lab0: {
            int v_1 = cursor;
            lab1: {
                bra = cursor;
                among_var = find_among(a_13);
                if (among_var == 0)
                {
                    break lab1;
                }
                ket = cursor;
                if (cursor < limit)
                {
                    break lab1;
                }
                switch (among_var) {
                    case 1:
                        slice_from("ski");
                        break;
                    case 2:
                        slice_from("sky");
                        break;
                    case 3:
                        slice_from("idl");
                        break;
                    case 4:
                        slice_from("gentl");
                        break;
                    case 5:
                        slice_from("ugli");
                        break;
                    case 6:
                        slice_from("earli");
                        break;
                    case 7:
                        slice_from("onli");
                        break;
                    case 8:
                        slice_from("singl");
                        break;
                }
                break lab0;
            }
            cursor = v_1;
            lab2: {
                lab3: {
                    {
                        int c = cursor + 3;
                        if (c > limit)
                        {
                            break lab3;
                        }
                        cursor = c;
                    }
                    break lab2;
                }
                break lab0;
            }
            cursor = v_1;
            lab4: {
                int v_2 = cursor;
                lab5: {
                    while (true)
                    {
                        int v_3 = cursor;
                        lab6: {
                            bra = cursor;
                            among_var = find_among(a_0);
                            ket = cursor;
                            switch (among_var) {
                                case 1:
                                    slice_from("ae");
                                    break;
                                case 2:
                                    slice_from("oe");
                                    break;
                                case 3:
                                    slice_from("s");
                                    break;
                                case 4:
                                    if (cursor >= limit)
                                    {
                                        break lab6;
                                    }
                                    cursor++;
                                    break;
                            }
                            continue;
                        }
                        cursor = v_3;
                        break;
                    }
                }
                cursor = v_2;
                B_Y_found = false;
                int v_4 = cursor;
                lab7: {
                    bra = cursor;
                    if (!(eq_s("'")))
                    {
                        break lab7;
                    }
                    ket = cursor;
                    slice_del();
                }
                cursor = v_4;
                int v_5 = cursor;
                lab8: {
                    bra = cursor;
                    if (!(eq_s("y")))
                    {
                        break lab8;
                    }
                    ket = cursor;
                    slice_from("Y");
                    B_Y_found = true;
                }
                cursor = v_5;
                int v_6 = cursor;
                lab9: {
                    while (true)
                    {
                        int v_7 = cursor;
                        lab10: {
                            golab11: while (true)
                            {
                                int v_8 = cursor;
                                lab12: {
                                    if (!(in_grouping(g_v, 97, 121)))
                                    {
                                        break lab12;
                                    }
                                    bra = cursor;
                                    if (!(eq_s("y")))
                                    {
                                        break lab12;
                                    }
                                    ket = cursor;
                                    cursor = v_8;
                                    break golab11;
                                }
                                cursor = v_8;
                                if (cursor >= limit)
                                {
                                    break lab10;
                                }
                                cursor++;
                            }
                            slice_from("Y");
                            B_Y_found = true;
                            continue;
                        }
                        cursor = v_7;
                        break;
                    }
                }
                cursor = v_6;
            }
            int v_9 = cursor;
            lab13: {
                bra = cursor;
                among_var = find_among(a_1);
                if (among_var == 0)
                {
                    break lab13;
                }
                ket = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("over");
                        break;
                    case 2:
                        if (cursor >= limit)
                        {
                            break lab13;
                        }
                        slice_del();
                        break;
                }
            }
            cursor = v_9;
            lab14: {
                I_p1 = limit;
                I_p2 = limit;
                int v_10 = cursor;
                lab15: {
                    lab16: {
                        int v_11 = cursor;
                        lab17: {
                            if (find_among(a_2) == 0)
                            {
                                break lab17;
                            }
                            break lab16;
                        }
                        cursor = v_11;
                        if (!go_out_grouping(g_v, 97, 121))
                        {
                            break lab15;
                        }
                        cursor++;
                        if (!go_in_grouping(g_v, 97, 121))
                        {
                            break lab15;
                        }
                        cursor++;
                    }
                    I_p1 = cursor;
                    if (!go_out_grouping(g_v, 97, 121))
                    {
                        break lab15;
                    }
                    cursor++;
                    if (!go_in_grouping(g_v, 97, 121))
                    {
                        break lab15;
                    }
                    cursor++;
                    I_p2 = cursor;
                }
                cursor = v_10;
            }
            limit_backward = cursor;
            cursor = limit;
            int v_12 = limit - cursor;
            lab18: {
                int v_13 = limit - cursor;
                lab19: {
                    ket = cursor;
                    if (find_among_b(a_3) == 0)
                    {
                        cursor = limit - v_13;
                        break lab19;
                    }
                    bra = cursor;
                    slice_del();
                }
                ket = cursor;
                among_var = find_among_b(a_4);
                if (among_var == 0)
                {
                    break lab18;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("ss");
                        break;
                    case 2:
                        lab20: {
                            int v_14 = limit - cursor;
                            lab21: {
                                {
                                    int c = cursor - 2;
                                    if (c < limit_backward)
                                    {
                                        break lab21;
                                    }
                                    cursor = c;
                                }
                                slice_from("i");
                                break lab20;
                            }
                            cursor = limit - v_14;
                            slice_from("ie");
                        }
                        break;
                    case 3:
                        if (cursor <= limit_backward)
                        {
                            break lab18;
                        }
                        cursor--;
                        if (!go_out_grouping_b(g_v, 97, 121))
                        {
                            break lab18;
                        }
                        cursor--;
                        slice_del();
                        break;
                    case 4:
                        slice_from("ever");
                        break;
                    case 5:
                        if (I_p1 > cursor)
                        {
                            break lab18;
                        }
                        slice_from("ly");
                        break;
                }
            }
            cursor = limit - v_12;
            int v_15 = limit - cursor;
            lab22: {
                ket = cursor;
                among_var = find_among_b(a_7);
                bra = cursor;
                lab23: {
                    int v_16 = limit - cursor;
                    lab24: {
                        switch (among_var) {
                            case 1:
                                int v_17 = limit - cursor;
                                lab25: {
                                    if (I_p1 > cursor)
                                    {
                                        break lab25;
                                    }
                                    lab26: {
                                        int v_18 = limit - cursor;
                                        lab27: {
                                            if (find_among_b(a_5) == 0)
                                            {
                                                break lab27;
                                            }
                                            if (cursor > limit_backward)
                                            {
                                                break lab27;
                                            }
                                            break lab26;
                                        }
                                        cursor = limit - v_18;
                                        slice_from("ee");
                                    }
                                }
                                cursor = limit - v_17;
                                break;
                            case 2:
                                break lab24;
                            case 3:
                                among_var = find_among_b(a_6);
                                if (among_var == 0)
                                {
                                    break lab24;
                                }
                                switch (among_var) {
                                    case 1:
                                        int v_19 = limit - cursor;
                                        if (!(out_grouping_b(g_v, 97, 121)))
                                        {
                                            break lab24;
                                        }
                                        if (cursor > limit_backward)
                                        {
                                            break lab24;
                                        }
                                        cursor = limit - v_19;
                                        bra = cursor;
                                        slice_from("ie");
                                        break;
                                    case 2:
                                        if (cursor > limit_backward)
                                        {
                                            break lab24;
                                        }
                                        break;
                                }
                                break;
                        }
                        break lab23;
                    }
                    cursor = limit - v_16;
                    int v_20 = limit - cursor;
                    if (!go_out_grouping_b(g_v, 97, 121))
                    {
                        break lab22;
                    }
                    cursor--;
                    cursor = limit - v_20;
                    slice_del();
                    ket = cursor;
                    bra = cursor;
                    int v_21 = limit - cursor;
                    among_var = find_among_b(a_8);
                    switch (among_var) {
                        case 1:
                            slice_from("e");
                            break lab22;
                        case 2:
                            {
                                int v_22 = limit - cursor;
                                lab28: {
                                    if (!(in_grouping_b(g_aeo, 97, 111)))
                                    {
                                        break lab28;
                                    }
                                    if (cursor > limit_backward)
                                    {
                                        break lab28;
                                    }
                                    break lab22;
                                }
                                cursor = limit - v_22;
                            }
                            break;
                        case 3:
                            if (cursor != I_p1)
                            {
                                break lab22;
                            }
                            int v_23 = limit - cursor;
                            if (!r_shortv())
                            {
                                break lab22;
                            }
                            cursor = limit - v_23;
                            slice_from("e");
                            break lab22;
                    }
                    cursor = limit - v_21;
                    ket = cursor;
                    if (cursor <= limit_backward)
                    {
                        break lab22;
                    }
                    cursor--;
                    bra = cursor;
                    slice_del();
                }
            }
            cursor = limit - v_15;
            int v_24 = limit - cursor;
            lab29: {
                ket = cursor;
                lab30: {
                    lab31: {
                        if (!(eq_s_b("y")))
                        {
                            break lab31;
                        }
                        break lab30;
                    }
                    if (!(eq_s_b("Y")))
                    {
                        break lab29;
                    }
                }
                bra = cursor;
                if (!(out_grouping_b(g_v, 97, 121)))
                {
                    break lab29;
                }
                if (cursor <= limit_backward)
                {
                    break lab29;
                }
                slice_from("i");
            }
            cursor = limit - v_24;
            int v_25 = limit - cursor;
            lab32: {
                ket = cursor;
                among_var = find_among_b(a_9);
                if (among_var == 0)
                {
                    break lab32;
                }
                bra = cursor;
                if (I_p1 > cursor)
                {
                    break lab32;
                }
                switch (among_var) {
                    case 1:
                        slice_from("tion");
                        break;
                    case 2:
                        slice_from("ence");
                        break;
                    case 3:
                        slice_from("ance");
                        break;
                    case 4:
                        slice_from("able");
                        break;
                    case 5:
                        slice_from("ent");
                        break;
                    case 6:
                        slice_from("ize");
                        break;
                    case 7:
                        slice_from("ate");
                        break;
                    case 8:
                        slice_from("al");
                        break;
                    case 9:
                        slice_from("ful");
                        break;
                    case 10:
                        slice_from("ous");
                        break;
                    case 11:
                        slice_from("ive");
                        break;
                    case 12:
                        slice_from("ble");
                        break;
                    case 13:
                        slice_from("og");
                        break;
                    case 14:
                        if (!(eq_s_b("l")))
                        {
                            break lab32;
                        }
                        slice_from("og");
                        break;
                    case 15:
                        slice_from("less");
                        break;
                    case 16:
                        if (!(in_grouping_b(g_valid_LI, 99, 116)))
                        {
                            break lab32;
                        }
                        slice_del();
                        break;
                }
            }
            cursor = limit - v_25;
            int v_26 = limit - cursor;
            lab33: {
                ket = cursor;
                among_var = find_among_b(a_10);
                if (among_var == 0)
                {
                    break lab33;
                }
                bra = cursor;
                if (I_p1 > cursor)
                {
                    break lab33;
                }
                switch (among_var) {
                    case 1:
                        slice_from("tion");
                        break;
                    case 2:
                        slice_from("ate");
                        break;
                    case 3:
                        slice_from("al");
                        break;
                    case 4:
                        slice_from("ic");
                        break;
                    case 5:
                        slice_del();
                        break;
                    case 6:
                        if (I_p2 > cursor)
                        {
                            break lab33;
                        }
                        slice_del();
                        break;
                }
            }
            cursor = limit - v_26;
            int v_27 = limit - cursor;
            lab34: {
                ket = cursor;
                among_var = find_among_b(a_11);
                if (among_var == 0)
                {
                    break lab34;
                }
                bra = cursor;
                if (I_p2 > cursor)
                {
                    break lab34;
                }
                switch (among_var) {
                    case 1:
                        slice_del();
                        break;
                    case 2:
                        lab35: {
                            lab36: {
                                if (!(eq_s_b("s")))
                                {
                                    break lab36;
                                }
                                break lab35;
                            }
                            if (!(eq_s_b("t")))
                            {
                                break lab34;
                            }
                        }
                        slice_del();
                        break;
                }
            }
            cursor = limit - v_27;
            int v_28 = limit - cursor;
            lab37: {
                ket = cursor;
                among_var = find_among_b(a_12);
                if (among_var == 0)
                {
                    break lab37;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        lab38: {
                            lab39: {
                                if (I_p2 > cursor)
                                {
                                    break lab39;
                                }
                                break lab38;
                            }
                            if (I_p1 > cursor)
                            {
                                break lab37;
                            }
                            {
                                int v_29 = limit - cursor;
                                lab40: {
                                    if (!r_shortv())
                                    {
                                        break lab40;
                                    }
                                    break lab37;
                                }
                                cursor = limit - v_29;
                            }
                        }
                        slice_del();
                        break;
                    case 2:
                        if (I_p2 > cursor)
                        {
                            break lab37;
                        }
                        if (!(eq_s_b("l")))
                        {
                            break lab37;
                        }
                        slice_del();
                        break;
                    case 3:
                        slice_from("en");
                        break;
                    case 4:
                        slice_from("er");
                        break;
                    case 5:
                        slice_from("eri");
                        break;
                    case 6:
                        slice_from("ili");
                        break;
                }
            }
            cursor = limit - v_28;
            cursor = limit_backward;
            int v_30 = cursor;
            lab41: {
                if (!B_Y_found)
                {
                    break lab41;
                }
                while (true)
                {
                    int v_31 = cursor;
                    lab42: {
                        golab43: while (true)
                        {
                            int v_32 = cursor;
                            lab44: {
                                bra = cursor;
                                if (!(eq_s("Y")))
                                {
                                    break lab44;
                                }
                                ket = cursor;
                                cursor = v_32;
                                break golab43;
                            }
                            cursor = v_32;
                            if (cursor >= limit)
                            {
                                break lab42;
                            }
                            cursor++;
                        }
                        slice_from("y");
                        continue;
                    }
                    cursor = v_31;
                    break;
                }
            }
            cursor = v_30;
        }
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof earlymodernenglishStemmer;
    }

    @Override
    public int hashCode() {
        return earlymodernenglishStemmer.class.getName().hashCode();
    }

}
