// Generated from italian.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from italian.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class italianStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("all'", -1, -1),
        new Among("d'", -1, -1),
        new Among("dall'", -1, -1),
        new Among("dell'", -1, -1),
        new Among("gl'", -1, -1),
        new Among("l'", -1, -1),
        new Among("m'", -1, -1),
        new Among("nell'", -1, -1),
        new Among("quell'", -1, -1),
        new Among("quest'", -1, -1),
        new Among("s'", -1, -1),
        new Among("sull'", -1, -1),
        new Among("t'", -1, -1),
        new Among("tutt'", -1, -1),
        new Among("un'", -1, -1),
        new Among("v'", -1, -1)
    };

    private final static Among[] a_1 = {
        new Among("", -1, 7),
        new Among("qu", 0, 6),
        new Among("\u00E1", 0, 1),
        new Among("\u00E9", 0, 2),
        new Among("\u00ED", 0, 3),
        new Among("\u00F3", 0, 4),
        new Among("\u00FA", 0, 5)
    };

    private final static Among[] a_2 = {
        new Among("", -1, 3),
        new Among("I", 0, 1),
        new Among("U", 0, 2)
    };

    private final static Among[] a_3 = {
        new Among("la", -1, -1),
        new Among("cela", 0, -1),
        new Among("gliela", 0, -1),
        new Among("mela", 0, -1),
        new Among("tela", 0, -1),
        new Among("vela", 0, -1),
        new Among("le", -1, -1),
        new Among("cele", 6, -1),
        new Among("gliele", 6, -1),
        new Among("mele", 6, -1),
        new Among("tele", 6, -1),
        new Among("vele", 6, -1),
        new Among("ne", -1, -1),
        new Among("cene", 12, -1),
        new Among("gliene", 12, -1),
        new Among("mene", 12, -1),
        new Among("sene", 12, -1),
        new Among("tene", 12, -1),
        new Among("vene", 12, -1),
        new Among("ci", -1, -1),
        new Among("li", -1, -1),
        new Among("celi", 20, -1),
        new Among("glieli", 20, -1),
        new Among("meli", 20, -1),
        new Among("teli", 20, -1),
        new Among("veli", 20, -1),
        new Among("gli", 20, -1),
        new Among("mi", -1, -1),
        new Among("si", -1, -1),
        new Among("ti", -1, -1),
        new Among("vi", -1, -1),
        new Among("lo", -1, -1),
        new Among("celo", 31, -1),
        new Among("glielo", 31, -1),
        new Among("melo", 31, -1),
        new Among("telo", 31, -1),
        new Among("velo", 31, -1)
    };

    private final static Among[] a_4 = {
        new Among("ando", -1, 1),
        new Among("endo", -1, 1),
        new Among("ar", -1, 2),
        new Among("er", -1, 2),
        new Among("ir", -1, 2)
    };

    private final static Among[] a_5 = {
        new Among("ic", -1, -1),
        new Among("abil", -1, -1),
        new Among("os", -1, -1),
        new Among("iv", -1, 1)
    };

    private final static Among[] a_6 = {
        new Among("ic", -1, 1),
        new Among("abil", -1, 1),
        new Among("iv", -1, 1)
    };

    private final static Among[] a_7 = {
        new Among("ica", -1, 1),
        new Among("logia", -1, 3),
        new Among("osa", -1, 1),
        new Among("ista", -1, 1),
        new Among("iva", -1, 9),
        new Among("anza", -1, 1),
        new Among("enza", -1, 5),
        new Among("ice", -1, 1),
        new Among("atrice", 7, 1),
        new Among("iche", -1, 1),
        new Among("logie", -1, 3),
        new Among("abile", -1, 1),
        new Among("ibile", -1, 1),
        new Among("usione", -1, 4),
        new Among("azione", -1, 2),
        new Among("uzione", -1, 4),
        new Among("atore", -1, 2),
        new Among("ose", -1, 1),
        new Among("ante", -1, 1),
        new Among("mente", -1, 1),
        new Among("amente", 19, 7),
        new Among("iste", -1, 1),
        new Among("ive", -1, 9),
        new Among("anze", -1, 1),
        new Among("enze", -1, 5),
        new Among("ici", -1, 1),
        new Among("atrici", 25, 1),
        new Among("ichi", -1, 1),
        new Among("abili", -1, 1),
        new Among("ibili", -1, 1),
        new Among("ismi", -1, 1),
        new Among("usioni", -1, 4),
        new Among("azioni", -1, 2),
        new Among("uzioni", -1, 4),
        new Among("atori", -1, 2),
        new Among("osi", -1, 1),
        new Among("anti", -1, 1),
        new Among("amenti", -1, 6),
        new Among("imenti", -1, 6),
        new Among("isti", -1, 1),
        new Among("ivi", -1, 9),
        new Among("ico", -1, 1),
        new Among("ismo", -1, 1),
        new Among("oso", -1, 1),
        new Among("amento", -1, 6),
        new Among("imento", -1, 6),
        new Among("ivo", -1, 9),
        new Among("it\u00E0", -1, 8),
        new Among("ist\u00E0", -1, 1),
        new Among("ist\u00E8", -1, 1),
        new Among("ist\u00EC", -1, 1)
    };

    private final static Among[] a_8 = {
        new Among("isca", -1, 1),
        new Among("enda", -1, 1),
        new Among("ata", -1, 1),
        new Among("ita", -1, 1),
        new Among("uta", -1, 1),
        new Among("ava", -1, 1),
        new Among("eva", -1, 1),
        new Among("iva", -1, 1),
        new Among("erebbe", -1, 1),
        new Among("irebbe", -1, 1),
        new Among("isce", -1, 1),
        new Among("ende", -1, 1),
        new Among("are", -1, 1),
        new Among("ere", -1, 1),
        new Among("ire", -1, 1),
        new Among("asse", -1, 1),
        new Among("ate", -1, 1),
        new Among("avate", 16, 1),
        new Among("evate", 16, 1),
        new Among("ivate", 16, 1),
        new Among("ete", -1, 1),
        new Among("erete", 20, 1),
        new Among("irete", 20, 1),
        new Among("ite", -1, 1),
        new Among("ereste", -1, 1),
        new Among("ireste", -1, 1),
        new Among("ute", -1, 1),
        new Among("erai", -1, 1),
        new Among("irai", -1, 1),
        new Among("isci", -1, 1),
        new Among("endi", -1, 1),
        new Among("erei", -1, 1),
        new Among("irei", -1, 1),
        new Among("assi", -1, 1),
        new Among("ati", -1, 1),
        new Among("iti", -1, 1),
        new Among("eresti", -1, 1),
        new Among("iresti", -1, 1),
        new Among("uti", -1, 1),
        new Among("avi", -1, 1),
        new Among("evi", -1, 1),
        new Among("ivi", -1, 1),
        new Among("isco", -1, 1),
        new Among("ando", -1, 1),
        new Among("endo", -1, 1),
        new Among("Yamo", -1, 1),
        new Among("iamo", -1, 1),
        new Among("avamo", -1, 1),
        new Among("evamo", -1, 1),
        new Among("ivamo", -1, 1),
        new Among("eremo", -1, 1),
        new Among("iremo", -1, 1),
        new Among("assimo", -1, 1),
        new Among("ammo", -1, 1),
        new Among("emmo", -1, 1),
        new Among("eremmo", 54, 1),
        new Among("iremmo", 54, 1),
        new Among("immo", -1, 1),
        new Among("ano", -1, 1),
        new Among("iscano", 58, 1),
        new Among("avano", 58, 1),
        new Among("evano", 58, 1),
        new Among("ivano", 58, 1),
        new Among("eranno", -1, 1),
        new Among("iranno", -1, 1),
        new Among("ono", -1, 1),
        new Among("iscono", 65, 1),
        new Among("arono", 65, 1),
        new Among("erono", 65, 1),
        new Among("irono", 65, 1),
        new Among("erebbero", -1, 1),
        new Among("irebbero", -1, 1),
        new Among("assero", -1, 1),
        new Among("essero", -1, 1),
        new Among("issero", -1, 1),
        new Among("ato", -1, 1),
        new Among("ito", -1, 1),
        new Among("uto", -1, 1),
        new Among("avo", -1, 1),
        new Among("evo", -1, 1),
        new Among("ivo", -1, 1),
        new Among("ar", -1, 1),
        new Among("ir", -1, 1),
        new Among("er\u00E0", -1, 1),
        new Among("ir\u00E0", -1, 1),
        new Among("er\u00F2", -1, 1),
        new Among("ir\u00F2", -1, 1)
    };

    private static final char[] g_v = {17, 65, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 128, 8, 2, 1 };

    private static final char[] g_AEIO = {17, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 128, 8, 2 };

    private static final char[] g_CG = {17 };


    @Override
    public boolean stem() {
        int among_var;
        int I_p2;
        int I_p1;
        int I_pV;
        int v_1 = cursor;
        lab0: {
            bra = cursor;
            if (find_among(a_0) == 0)
            {
                break lab0;
            }
            ket = cursor;
            if (cursor >= limit)
            {
                break lab0;
            }
            slice_del();
        }
        cursor = v_1;
        int v_2 = cursor;
        lab1: {
            int v_3 = cursor;
            while (true)
            {
                int v_4 = cursor;
                lab2: {
                    bra = cursor;
                    among_var = find_among(a_1);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("\u00E0");
                            break;
                        case 2:
                            slice_from("\u00E8");
                            break;
                        case 3:
                            slice_from("\u00EC");
                            break;
                        case 4:
                            slice_from("\u00F2");
                            break;
                        case 5:
                            slice_from("\u00F9");
                            break;
                        case 6:
                            slice_from("qU");
                            break;
                        case 7:
                            if (cursor >= limit)
                            {
                                break lab2;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_4;
                break;
            }
            cursor = v_3;
            while (true)
            {
                int v_5 = cursor;
                lab3: {
                    golab4: while (true)
                    {
                        int v_6 = cursor;
                        lab5: {
                            if (!(in_grouping(g_v, 97, 249)))
                            {
                                break lab5;
                            }
                            bra = cursor;
                            lab6: {
                                int v_7 = cursor;
                                lab7: {
                                    if (!(eq_s("u")))
                                    {
                                        break lab7;
                                    }
                                    ket = cursor;
                                    if (!(in_grouping(g_v, 97, 249)))
                                    {
                                        break lab7;
                                    }
                                    slice_from("U");
                                    break lab6;
                                }
                                cursor = v_7;
                                if (!(eq_s("i")))
                                {
                                    break lab5;
                                }
                                ket = cursor;
                                if (!(in_grouping(g_v, 97, 249)))
                                {
                                    break lab5;
                                }
                                slice_from("I");
                            }
                            cursor = v_6;
                            break golab4;
                        }
                        cursor = v_6;
                        if (cursor >= limit)
                        {
                            break lab3;
                        }
                        cursor++;
                    }
                    continue;
                }
                cursor = v_5;
                break;
            }
        }
        cursor = v_2;
        lab8: {
            I_pV = limit;
            I_p1 = limit;
            I_p2 = limit;
            int v_8 = cursor;
            lab9: {
                lab10: {
                    int v_9 = cursor;
                    lab11: {
                        if (!(in_grouping(g_v, 97, 249)))
                        {
                            break lab11;
                        }
                        lab12: {
                            int v_10 = cursor;
                            lab13: {
                                if (!(out_grouping(g_v, 97, 249)))
                                {
                                    break lab13;
                                }
                                if (!go_out_grouping(g_v, 97, 249))
                                {
                                    break lab13;
                                }
                                cursor++;
                                break lab12;
                            }
                            cursor = v_10;
                            if (!(in_grouping(g_v, 97, 249)))
                            {
                                break lab11;
                            }
                            if (!go_in_grouping(g_v, 97, 249))
                            {
                                break lab11;
                            }
                            cursor++;
                        }
                        break lab10;
                    }
                    cursor = v_9;
                    lab14: {
                        if (!(eq_s("divan")))
                        {
                            break lab14;
                        }
                        break lab10;
                    }
                    cursor = v_9;
                    if (!(out_grouping(g_v, 97, 249)))
                    {
                        break lab9;
                    }
                    lab15: {
                        int v_11 = cursor;
                        lab16: {
                            if (!(out_grouping(g_v, 97, 249)))
                            {
                                break lab16;
                            }
                            if (!go_out_grouping(g_v, 97, 249))
                            {
                                break lab16;
                            }
                            cursor++;
                            break lab15;
                        }
                        cursor = v_11;
                        if (!(in_grouping(g_v, 97, 249)))
                        {
                            break lab9;
                        }
                        if (cursor >= limit)
                        {
                            break lab9;
                        }
                        cursor++;
                    }
                }
                I_pV = cursor;
            }
            cursor = v_8;
            int v_12 = cursor;
            lab17: {
                if (!go_out_grouping(g_v, 97, 249))
                {
                    break lab17;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 249))
                {
                    break lab17;
                }
                cursor++;
                I_p1 = cursor;
                if (!go_out_grouping(g_v, 97, 249))
                {
                    break lab17;
                }
                cursor++;
                if (!go_in_grouping(g_v, 97, 249))
                {
                    break lab17;
                }
                cursor++;
                I_p2 = cursor;
            }
            cursor = v_12;
        }
        limit_backward = cursor;
        cursor = limit;
        int v_13 = limit - cursor;
        lab18: {
            ket = cursor;
            if (find_among_b(a_3) == 0)
            {
                break lab18;
            }
            bra = cursor;
            among_var = find_among_b(a_4);
            if (among_var == 0)
            {
                break lab18;
            }
            if (I_pV > cursor)
            {
                break lab18;
            }
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    slice_from("e");
                    break;
            }
        }
        cursor = limit - v_13;
        int v_14 = limit - cursor;
        lab19: {
            lab20: {
                int v_15 = limit - cursor;
                lab21: {
                    ket = cursor;
                    among_var = find_among_b(a_7);
                    if (among_var == 0)
                    {
                        break lab21;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            if (I_p2 > cursor)
                            {
                                break lab21;
                            }
                            slice_del();
                            break;
                        case 2:
                            if (I_p2 > cursor)
                            {
                                break lab21;
                            }
                            slice_del();
                            int v_16 = limit - cursor;
                            lab22: {
                                ket = cursor;
                                if (!(eq_s_b("ic")))
                                {
                                    cursor = limit - v_16;
                                    break lab22;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_16;
                                    break lab22;
                                }
                                slice_del();
                            }
                            break;
                        case 3:
                            if (I_p2 > cursor)
                            {
                                break lab21;
                            }
                            slice_from("log");
                            break;
                        case 4:
                            if (I_p2 > cursor)
                            {
                                break lab21;
                            }
                            slice_from("u");
                            break;
                        case 5:
                            if (I_p2 > cursor)
                            {
                                break lab21;
                            }
                            slice_from("ente");
                            break;
                        case 6:
                            if (I_pV > cursor)
                            {
                                break lab21;
                            }
                            slice_del();
                            break;
                        case 7:
                            if (I_p1 > cursor)
                            {
                                break lab21;
                            }
                            slice_del();
                            int v_17 = limit - cursor;
                            lab23: {
                                ket = cursor;
                                among_var = find_among_b(a_5);
                                if (among_var == 0)
                                {
                                    cursor = limit - v_17;
                                    break lab23;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_17;
                                    break lab23;
                                }
                                slice_del();
                                switch (among_var) {
                                    case 1:
                                        ket = cursor;
                                        if (!(eq_s_b("at")))
                                        {
                                            cursor = limit - v_17;
                                            break lab23;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            cursor = limit - v_17;
                                            break lab23;
                                        }
                                        slice_del();
                                        break;
                                }
                            }
                            break;
                        case 8:
                            if (I_p2 > cursor)
                            {
                                break lab21;
                            }
                            slice_del();
                            int v_18 = limit - cursor;
                            lab24: {
                                ket = cursor;
                                if (find_among_b(a_6) == 0)
                                {
                                    cursor = limit - v_18;
                                    break lab24;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_18;
                                    break lab24;
                                }
                                slice_del();
                            }
                            break;
                        case 9:
                            if (I_p2 > cursor)
                            {
                                break lab21;
                            }
                            slice_del();
                            int v_19 = limit - cursor;
                            lab25: {
                                ket = cursor;
                                if (!(eq_s_b("at")))
                                {
                                    cursor = limit - v_19;
                                    break lab25;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_19;
                                    break lab25;
                                }
                                slice_del();
                                ket = cursor;
                                if (!(eq_s_b("ic")))
                                {
                                    cursor = limit - v_19;
                                    break lab25;
                                }
                                bra = cursor;
                                if (I_p2 > cursor)
                                {
                                    cursor = limit - v_19;
                                    break lab25;
                                }
                                slice_del();
                            }
                            break;
                    }
                    break lab20;
                }
                cursor = limit - v_15;
                if (cursor < I_pV)
                {
                    break lab19;
                }
                int v_20 = limit_backward;
                limit_backward = I_pV;
                ket = cursor;
                if (find_among_b(a_8) == 0)
                {
                    limit_backward = v_20;
                    break lab19;
                }
                bra = cursor;
                slice_del();
                limit_backward = v_20;
            }
        }
        cursor = limit - v_14;
        int v_21 = limit - cursor;
        lab26: {
            int v_22 = limit - cursor;
            lab27: {
                ket = cursor;
                if (!(in_grouping_b(g_AEIO, 97, 242)))
                {
                    cursor = limit - v_22;
                    break lab27;
                }
                bra = cursor;
                if (I_pV > cursor)
                {
                    cursor = limit - v_22;
                    break lab27;
                }
                slice_del();
                ket = cursor;
                if (!(eq_s_b("i")))
                {
                    cursor = limit - v_22;
                    break lab27;
                }
                bra = cursor;
                if (I_pV > cursor)
                {
                    cursor = limit - v_22;
                    break lab27;
                }
                slice_del();
            }
            int v_23 = limit - cursor;
            lab28: {
                ket = cursor;
                if (!(eq_s_b("h")))
                {
                    cursor = limit - v_23;
                    break lab28;
                }
                bra = cursor;
                if (!(in_grouping_b(g_CG, 99, 103)))
                {
                    cursor = limit - v_23;
                    break lab28;
                }
                if (I_pV > cursor)
                {
                    cursor = limit - v_23;
                    break lab28;
                }
                slice_del();
            }
        }
        cursor = limit - v_21;
        cursor = limit_backward;
        int v_24 = cursor;
        lab29: {
            while (true)
            {
                int v_25 = cursor;
                lab30: {
                    bra = cursor;
                    among_var = find_among(a_2);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("i");
                            break;
                        case 2:
                            slice_from("u");
                            break;
                        case 3:
                            if (cursor >= limit)
                            {
                                break lab30;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_25;
                break;
            }
        }
        cursor = v_24;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof italianStemmer;
    }

    @Override
    public int hashCode() {
        return italianStemmer.class.getName().hashCode();
    }

}
