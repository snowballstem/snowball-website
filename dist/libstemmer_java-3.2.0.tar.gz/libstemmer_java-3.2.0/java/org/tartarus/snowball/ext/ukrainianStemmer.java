// Generated from ukrainian.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from ukrainian.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class ukrainianStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("\u0430\u0447\u0438", -1, 3),
        new Among("\u0443\u0447\u0438", -1, 3),
        new Among("\u0430\u044E\u0447\u0438", -1, 3),
        new Among("\u0443\u044E\u0447\u0438", -1, 4),
        new Among("\u044E\u044E\u0447\u0438", -1, 5),
        new Among("\u044F\u044E\u0447\u0438", -1, 3),
        new Among("\u0456\u044E\u0447\u0438", -1, 3),
        new Among("\u044F\u0447\u0438", -1, 3),
        new Among("\u0432\u0448\u0438", -1, 1),
        new Among("\u0438\u0432\u0448\u0438", 8, 2),
        new Among("\u0432\u0448\u0438\u0441\u044C", -1, 1),
        new Among("\u0438\u0432\u0448\u0438\u0441\u044C", 10, 2)
    };

    private final static Among[] a_1 = {
        new Among("\u0435\u0442\u044C\u0441\u044F", -1, 1),
        new Among("\u0438\u0442\u044C\u0441\u044F", -1, 1),
        new Among("\u0430\u044E\u0442\u044C\u0441\u044F", -1, 1),
        new Among("\u0443\u044E\u0442\u044C\u0441\u044F", -1, 2),
        new Among("\u044E\u044E\u0442\u044C\u0441\u044F", -1, 3),
        new Among("\u044F\u044E\u0442\u044C\u0441\u044F", -1, 1),
        new Among("\u0454\u0442\u044C\u0441\u044F", -1, 1),
        new Among("\u0430\u0454\u0442\u044C\u0441\u044F", 6, 1),
        new Among("\u0443\u0454\u0442\u044C\u0441\u044F", 6, 2),
        new Among("\u044E\u0454\u0442\u044C\u0441\u044F", 6, 3),
        new Among("\u044F\u0454\u0442\u044C\u0441\u044F", 6, 1)
    };

    private final static Among[] a_2 = {
        new Among("\u0441\u044C", -1, 1),
        new Among("\u043B\u0430\u0441\u044C", 0, 1),
        new Among("\u0432\u0441\u044C", 0, 1),
        new Among("\u0442\u0438\u0441\u044C", 0, 1),
        new Among("\u0441\u044F", -1, 1),
        new Among("\u0432\u0441\u044F", 4, 1),
        new Among("\u0442\u0438\u0441\u044F", 4, 1)
    };

    private final static Among[] a_3 = {
        new Among("\u0456\u0439\u043D\u0430", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0430", 0, 1),
        new Among("\u0438\u0447\u043D\u0430", -1, 1),
        new Among("\u0456\u0447\u043D\u0430", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0430", -1, 1),
        new Among("\u0456\u0430", -1, 1),
        new Among("\u0456\u0439\u043D\u0435", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0435", 6, 1),
        new Among("\u0438\u0447\u043D\u0435", -1, 1),
        new Among("\u0456\u0447\u043D\u0435", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0435", -1, 1),
        new Among("\u0456\u0439\u043D\u0438\u043C\u0438", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0438\u043C\u0438", 11, 1),
        new Among("\u0438\u0447\u043D\u0438\u043C\u0438", -1, 1),
        new Among("\u0456\u0447\u043D\u0438\u043C\u0438", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0438\u043C\u0438", -1, 1),
        new Among("\u0456\u044F\u043C\u0438", -1, 1),
        new Among("\u0430\u0446\u0456\u044F\u043C\u0438", 16, 1),
        new Among("\u0438\u0447\u043D\u043E\u0441\u0442\u0435\u0439", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0435\u0439", -1, 1),
        new Among("\u0456\u0439\u043D\u0438\u0439", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0438\u0439", 20, 1),
        new Among("\u0438\u0447\u043D\u0438\u0439", -1, 1),
        new Among("\u0456\u0447\u043D\u0438\u0439", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0438\u0439", -1, 1),
        new Among("\u0456\u0439", -1, 1),
        new Among("\u0456\u0439\u043D\u0456\u0439", 25, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0456\u0439", 26, 1),
        new Among("\u0438\u0447\u043D\u0456\u0439", 25, 1),
        new Among("\u0456\u0447\u043D\u0456\u0439", 25, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0456\u0439", 25, 1),
        new Among("\u0430\u0446\u0456\u0439", 25, 1),
        new Among("\u0456\u0439\u043D\u0438\u043C", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0438\u043C", 32, 1),
        new Among("\u0438\u0447\u043D\u0438\u043C", -1, 1),
        new Among("\u0456\u0447\u043D\u0438\u043C", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0438\u043C", -1, 1),
        new Among("\u0456\u044F\u043C", -1, 1),
        new Among("\u0430\u0446\u0456\u044F\u043C", 37, 1),
        new Among("\u0456\u0454\u043C", -1, 1),
        new Among("\u0456\u0439\u043D\u043E\u0433\u043E", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u043E\u0433\u043E", 40, 1),
        new Among("\u0438\u0447\u043D\u043E\u0433\u043E", -1, 1),
        new Among("\u0456\u0447\u043D\u043E\u0433\u043E", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u043E\u0433\u043E", -1, 1),
        new Among("\u0456\u0439\u043D\u043E", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u043E", 45, 1),
        new Among("\u0438\u0447\u043D\u043E", -1, 1),
        new Among("\u0456\u0447\u043D\u043E", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u043E", -1, 1),
        new Among("\u0456\u0439\u043D\u043E\u043C\u0443", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u043E\u043C\u0443", 50, 1),
        new Among("\u0438\u0447\u043D\u043E\u043C\u0443", -1, 1),
        new Among("\u0456\u0447\u043D\u043E\u043C\u0443", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u043E\u043C\u0443", -1, 1),
        new Among("\u0456\u0439\u043D\u0443", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0443", 55, 1),
        new Among("\u0438\u0447\u043D\u0443", -1, 1),
        new Among("\u0456\u0447\u043D\u0443", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0443", -1, 1),
        new Among("\u0456\u0439\u043D\u0438\u0445", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0438\u0445", 60, 1),
        new Among("\u0438\u0447\u043D\u0438\u0445", -1, 1),
        new Among("\u0456\u0447\u043D\u0438\u0445", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0438\u0445", -1, 1),
        new Among("\u0456\u044F\u0445", -1, 1),
        new Among("\u0430\u0446\u0456\u044F\u0445", 65, 1),
        new Among("\u0456\u0439\u043D\u0456\u0441\u0442\u044C", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0456\u0441\u0442\u044C", 67, 1),
        new Among("\u0438\u0447\u043D\u0456\u0441\u0442\u044C", -1, 1),
        new Among("\u0456\u0447\u043D\u0456\u0441\u0442\u044C", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0456\u0441\u0442\u044C", -1, 1),
        new Among("\u0456\u0439\u043D\u043E\u044E", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u043E\u044E", 72, 1),
        new Among("\u0438\u0447\u043D\u043E\u044E", -1, 1),
        new Among("\u0456\u0447\u043D\u043E\u044E", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u043E\u044E", -1, 1),
        new Among("\u0456\u0439\u043D\u0456\u0441\u0442\u044E", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0456\u0441\u0442\u044E", 77, 1),
        new Among("\u0438\u0447\u043D\u0456\u0441\u0442\u044E", -1, 1),
        new Among("\u0456\u0447\u043D\u0456\u0441\u0442\u044E", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0456\u0441\u0442\u044E", -1, 1),
        new Among("\u0456\u0454\u044E", -1, 1),
        new Among("\u0430\u0446\u0456\u0454\u044E", 82, 1),
        new Among("\u0456\u044E", -1, 1),
        new Among("\u0430\u0446\u0456\u044E", 84, 1),
        new Among("\u0456\u044F", -1, 1),
        new Among("\u0430\u0446\u0456\u044F", 86, 1),
        new Among("\u0456\u0439\u043D\u0456", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u0456", 88, 1),
        new Among("\u0438\u0447\u043D\u0456", -1, 1),
        new Among("\u0456\u0447\u043D\u0456", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u0456", -1, 1),
        new Among("\u0456\u0439\u043D\u043E\u0441\u0442\u0456", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u043E\u0441\u0442\u0456", 93, 1),
        new Among("\u0438\u0447\u043D\u043E\u0441\u0442\u0456", -1, 1),
        new Among("\u0456\u0447\u043D\u043E\u0441\u0442\u0456", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0456", -1, 1),
        new Among("\u0456\u0439\u043D\u043E\u0457", -1, 1),
        new Among("\u0430\u0446\u0456\u0439\u043D\u043E\u0457", 98, 1),
        new Among("\u0438\u0447\u043D\u043E\u0457", -1, 1),
        new Among("\u0456\u0447\u043D\u043E\u0457", -1, 1),
        new Among("\u0443\u0430\u043B\u044C\u043D\u043E\u0457", -1, 1),
        new Among("\u0456\u0457", -1, 1),
        new Among("\u0430\u0446\u0456\u0457", 103, 1)
    };

    private final static Among[] a_4 = {
        new Among("\u043E\u0432\u0430\u043D\u0430", -1, 1),
        new Among("\u0443\u0432\u0430\u043D\u0430", -1, 1),
        new Among("\u0443\u0447\u0430", -1, 1),
        new Among("\u044E\u0447\u0430", -1, 1),
        new Among("\u043E\u0432\u0430\u043D\u0435", -1, 1),
        new Among("\u0443\u0432\u0430\u043D\u0435", -1, 1),
        new Among("\u0443\u0447\u0435", -1, 1),
        new Among("\u044E\u0447\u0435", -1, 1),
        new Among("\u0438\u043C\u0438", -1, 1),
        new Among("\u0456\u043C\u0438", -1, 1),
        new Among("\u0457\u043C\u0438", -1, 1),
        new Among("\u0438\u0439", -1, 1),
        new Among("\u043E\u0432\u0430\u043D\u0438\u0439", 11, 1),
        new Among("\u0443\u0432\u0430\u043D\u0438\u0439", 11, 1),
        new Among("\u0443\u0447\u0438\u0439", 11, 1),
        new Among("\u044E\u0447\u0438\u0439", 11, 1),
        new Among("\u0456\u0439", -1, 1),
        new Among("\u0438\u043C", -1, 1),
        new Among("\u0456\u043C", -1, 1),
        new Among("\u0457\u043C", -1, 1),
        new Among("\u043E\u0433\u043E", -1, 1),
        new Among("\u044C\u043E\u0433\u043E", 20, 1),
        new Among("\u043E\u0432\u0430\u043D\u043E", -1, 1),
        new Among("\u0443\u0432\u0430\u043D\u043E", -1, 1),
        new Among("\u043E\u043C\u0443", -1, 1),
        new Among("\u044C\u043E\u043C\u0443", 24, 1),
        new Among("\u0456\u0448\u0443", -1, 1),
        new Among("\u0438\u0445", -1, 1),
        new Among("\u0456\u0445", -1, 1),
        new Among("\u0457\u0445", -1, 1),
        new Among("\u0435\u044E", -1, 2),
        new Among("\u043E\u044E", -1, 1),
        new Among("\u044C\u043E\u044E", 31, 1),
        new Among("\u0454\u044E", -1, 1),
        new Among("\u043E\u0432\u0430\u043D\u0456", -1, 1),
        new Among("\u0443\u0432\u0430\u043D\u0456", -1, 1),
        new Among("\u0443\u0447\u0456", -1, 1),
        new Among("\u044E\u0447\u0456", -1, 1),
        new Among("\u043E\u0457", -1, 1),
        new Among("\u044C\u043E\u0457", 38, 1)
    };

    private final static Among[] a_5 = {
        new Among("\u043B\u0430", -1, 10),
        new Among("\u0430\u043B\u0430", 0, 4),
        new Among("\u0438\u043B\u0430", 0, 1),
        new Among("\u044F\u043B\u0430", 0, 1),
        new Among("\u0456\u043B\u0430", 0, 1),
        new Among("\u0432", -1, 8),
        new Among("\u0430\u0432", 5, 3),
        new Among("\u0438\u0432", 5, 3),
        new Among("\u044F\u0432", 5, 1),
        new Among("\u0456\u0432", 5, 3),
        new Among("\u0430\u0442\u0438\u043C\u0435", -1, 1),
        new Among("\u0438\u0442\u0438\u043C\u0435", -1, 1),
        new Among("\u044F\u0442\u0438\u043C\u0435", -1, 1),
        new Among("\u0456\u0442\u0438\u043C\u0435", -1, 1),
        new Among("\u0435\u0442\u0435", -1, 1),
        new Among("\u0438\u0442\u0435", -1, 1),
        new Among("\u0439\u0442\u0435", -1, 1),
        new Among("\u0454\u0442\u0435", -1, 1),
        new Among("\u0430\u0454\u0442\u0435", 17, 1),
        new Among("\u0443\u0454\u0442\u0435", 17, 6),
        new Among("\u044E\u0454\u0442\u0435", 17, 7),
        new Among("\u044F\u0454\u0442\u0435", 17, 1),
        new Among("\u0456\u0442\u0435", -1, 1),
        new Among("\u043B\u0438", -1, 10),
        new Among("\u0430\u043B\u0438", 23, 4),
        new Among("\u0438\u043B\u0438", 23, 1),
        new Among("\u044F\u043B\u0438", 23, 1),
        new Among("\u0456\u043B\u0438", 23, 1),
        new Among("\u0442\u0438", -1, 12),
        new Among("\u0430\u0442\u0438", 28, 1),
        new Among("\u0438\u0442\u0438", 28, 1),
        new Among("\u044F\u0442\u0438", 28, 5),
        new Among("\u0456\u0442\u0438", 28, 1),
        new Among("\u0439", -1, 1),
        new Among("\u0435\u0439", 33, 2),
        new Among("\u0454\u043C", -1, 1),
        new Among("\u043B\u043E", -1, 10),
        new Among("\u0430\u043B\u043E", 36, 4),
        new Among("\u0438\u043B\u043E", 36, 1),
        new Among("\u044F\u043B\u043E", 36, 1),
        new Among("\u0456\u043B\u043E", 36, 1),
        new Among("\u0435\u043C\u043E", -1, 1),
        new Among("\u0430\u0442\u0438\u043C\u0435\u043C\u043E", 41, 1),
        new Among("\u0438\u043C\u043E", -1, 1),
        new Among("\u0454\u043C\u043E", -1, 1),
        new Among("\u0430\u0454\u043C\u043E", 44, 1),
        new Among("\u0443\u0454\u043C\u043E", 44, 6),
        new Among("\u044E\u0454\u043C\u043E", 44, 7),
        new Among("\u044F\u0454\u043C\u043E", 44, 1),
        new Among("\u0456\u043C\u043E", -1, 1),
        new Among("\u0443", -1, 9),
        new Among("\u0430\u0442\u0438\u043C\u0443", 50, 1),
        new Among("\u0438\u0442\u0438\u043C\u0443", 50, 1),
        new Among("\u0435\u0448", -1, 1),
        new Among("\u0438\u0448", -1, 1),
        new Among("\u0454\u0448", -1, 1),
        new Among("\u0430\u0454\u0448", 55, 1),
        new Among("\u0443\u0454\u0448", 55, 6),
        new Among("\u044E\u0454\u0448", 55, 7),
        new Among("\u044F\u0454\u0448", 55, 1),
        new Among("\u0438\u0442\u044C", -1, 1),
        new Among("\u0443\u0442\u044C", -1, 1),
        new Among("\u0430\u0442\u0438\u043C\u0443\u0442\u044C", 61, 1),
        new Among("\u0438\u0442\u0438\u043C\u0443\u0442\u044C", 61, 1),
        new Among("\u044F\u0442\u0438\u043C\u0443\u0442\u044C", 61, 1),
        new Among("\u044E\u0442\u044C", -1, 1),
        new Among("\u0430\u044E\u0442\u044C", 65, 1),
        new Among("\u0443\u044E\u0442\u044C", 65, 6),
        new Among("\u044E\u044E\u0442\u044C", 65, 7),
        new Among("\u044F\u044E\u0442\u044C", 65, 1),
        new Among("\u044F\u0442\u044C", -1, 5),
        new Among("\u0457\u0442\u044C", -1, 1),
        new Among("\u044E", -1, 11),
        new Among("\u0430\u044E", 72, 1),
        new Among("\u0454", -1, 1),
        new Among("\u0430\u0454", 74, 1),
        new Among("\u0443\u0454", 74, 6),
        new Among("\u044E\u0454", 74, 7),
        new Among("\u044F\u0454", 74, 1)
    };

    private final static Among[] a_6 = {
        new Among("\u0456\u0441\u0442\u044C", -1, 1),
        new Among("\u0456\u0441\u0442\u044E", -1, 1),
        new Among("\u043E\u0441\u0442\u0456", -1, 1),
        new Among("\u0456\u0441\u0442\u0456", -1, 1)
    };

    private final static Among[] a_7 = {
        new Among("\u0430", -1, 3),
        new Among("\u0441\u0442\u0432\u0430", 0, 3),
        new Among("\u0446\u0442\u0432\u0430", 0, 2),
        new Among("\u0441\u0442\u0432", -1, 3),
        new Among("\u0446\u0442\u0432", -1, 2),
        new Among("\u0435", -1, 3),
        new Among("\u0438", -1, 3),
        new Among("\u0430\u043C\u0438", 6, 3),
        new Among("\u0441\u0442\u0432\u0430\u043C\u0438", 7, 3),
        new Among("\u0446\u0442\u0432\u0430\u043C\u0438", 7, 2),
        new Among("\u044F\u043C\u0438", 6, 3),
        new Among("\u0430\u043C", -1, 3),
        new Among("\u0441\u0442\u0432\u0430\u043C", 11, 3),
        new Among("\u0446\u0442\u0432\u0430\u043C", 11, 2),
        new Among("\u0435\u043C", -1, 3),
        new Among("\u043E\u043C", -1, 3),
        new Among("\u0441\u0442\u0432\u043E\u043C", 15, 3),
        new Among("\u0446\u0442\u0432\u043E\u043C", 15, 2),
        new Among("\u044F\u043C", -1, 3),
        new Among("\u043E", -1, 3),
        new Among("\u0442\u0432\u043E", 19, 3),
        new Among("\u0441\u0442\u0432\u043E", 20, 3),
        new Among("\u0441\u0442\u0432\u0443", -1, 3),
        new Among("\u0446\u0442\u0432\u0443", -1, 2),
        new Among("\u0430\u0445", -1, 3),
        new Among("\u0441\u0442\u0432\u0430\u0445", 24, 3),
        new Among("\u0446\u0442\u0432\u0430\u0445", 24, 2),
        new Among("\u044F\u0445", -1, 3),
        new Among("\u0435\u0446\u044C", -1, 2),
        new Among("\u0456\u0441\u0442\u044E", -1, 1),
        new Among("\u044F", -1, 3),
        new Among("\u0456", -1, 3),
        new Among("\u0435\u0432\u0456", 31, 3),
        new Among("\u043E\u0432\u0456", 31, 3),
        new Among("\u0441\u0442\u0432\u0456", 31, 3),
        new Among("\u0446\u0442\u0432\u0456", 31, 2),
        new Among("\u0457", -1, 3)
    };

    private final static Among[] a_8 = {
        new Among("\u043D\u0438\u043A", -1, 1),
        new Among("\u0456\u0432\u043D\u0438\u043A", 0, 1),
        new Among("\u0430\u043B\u044C\u043D\u0438\u043A", 0, 1),
        new Among("\u0435\u043B\u044C\u043D\u0438\u043A", 0, 1),
        new Among("\u0430\u0440", -1, 2),
        new Among("\u044F\u0440", -1, 1),
        new Among("\u0430\u0447", -1, 1)
    };

    private final static Among[] a_9 = {
        new Among("\u0435\u0447\u043A\u0430", -1, 1),
        new Among("\u043E\u0447\u0435\u0447\u043A\u0430", 0, 1),
        new Among("\u043E\u0447\u043A\u0430", -1, 1),
        new Among("\u0456\u0447\u043A\u0430", -1, 1),
        new Among("\u0435\u043D\u044C\u043A\u0430", -1, 1),
        new Among("\u0435\u0441\u0435\u043D\u044C\u043A\u0430", 4, 1),
        new Among("\u043E\u043D\u044C\u043A\u0430", -1, 1),
        new Among("\u0456\u043D\u044C\u043A\u0430", -1, 1),
        new Among("\u044E\u0441\u0456\u043D\u044C\u043A\u0430", 7, 1),
        new Among("\u0456\u0441\u0456\u043D\u044C\u043A\u0430", 7, 1),
        new Among("\u0435\u0447\u043A\u0438", -1, 1),
        new Among("\u043E\u0447\u0435\u0447\u043A\u0438", 10, 1),
        new Among("\u043E\u0447\u043A\u0438", -1, 1),
        new Among("\u0456\u0447\u043A\u0438", -1, 1),
        new Among("\u0435\u043D\u044C\u043A\u0438", -1, 1),
        new Among("\u0435\u0441\u0435\u043D\u044C\u043A\u0438", 14, 1),
        new Among("\u043E\u043D\u044C\u043A\u0438", -1, 1),
        new Among("\u0456\u043D\u044C\u043A\u0438", -1, 1),
        new Among("\u044E\u0441\u0456\u043D\u044C\u043A\u0438", 17, 1),
        new Among("\u0456\u0441\u0456\u043D\u044C\u043A\u0438", 17, 1),
        new Among("\u043E\u043A", -1, 2),
        new Among("\u0435\u0447\u043E\u043A", 20, 1),
        new Among("\u043E\u0447\u0435\u0447\u043E\u043A", 21, 1),
        new Among("\u043E\u0447\u043E\u043A", 20, 1),
        new Among("\u0456\u0447\u043E\u043A", 20, 1),
        new Among("\u0430\u0442\u043A\u043E", -1, 1),
        new Among("\u044F\u0442\u043A\u043E", -1, 1),
        new Among("\u0456\u0442\u043A\u043E", -1, 1),
        new Among("\u0435\u0447\u043A\u043E", -1, 1),
        new Among("\u043E\u0447\u0435\u0447\u043A\u043E", 28, 1),
        new Among("\u043E\u0447\u043A\u043E", -1, 1),
        new Among("\u0456\u0447\u043A\u043E", -1, 1),
        new Among("\u0435\u043D\u044C\u043A\u043E", -1, 1),
        new Among("\u0435\u0441\u0435\u043D\u044C\u043A\u043E", 32, 1),
        new Among("\u043E\u043D\u044C\u043A\u043E", -1, 1),
        new Among("\u0456\u043D\u044C\u043A\u043E", -1, 1),
        new Among("\u044E\u0441\u0456\u043D\u044C\u043A\u043E", 35, 1),
        new Among("\u0456\u0441\u0456\u043D\u044C\u043A\u043E", 35, 1),
        new Among("\u0435\u043D\u044C\u043A\u0443", -1, 1),
        new Among("\u0443\u043D\u044C", -1, 1),
        new Among("\u0435\u0447\u043A\u0456", -1, 1),
        new Among("\u043E\u0447\u0435\u0447\u043A\u0456", 40, 1),
        new Among("\u043E\u0447\u043A\u0456", -1, 1),
        new Among("\u0456\u0447\u043A\u0456", -1, 1),
        new Among("\u0435\u043D\u044C\u043A\u0456", -1, 1),
        new Among("\u0435\u0441\u0435\u043D\u044C\u043A\u0456", 44, 1),
        new Among("\u043E\u043D\u044C\u043A\u0456", -1, 1),
        new Among("\u0456\u043D\u044C\u043A\u0456", -1, 1),
        new Among("\u044E\u0441\u0456\u043D\u044C\u043A\u0456", 47, 1),
        new Among("\u0456\u0441\u0456\u043D\u044C\u043A\u0456", 47, 1)
    };

    private final static Among[] a_10 = {
        new Among("\u0435\u043D\u044C\u043A", -1, 1),
        new Among("\u0435\u0441\u0435\u043D\u044C\u043A", 0, 1),
        new Among("\u043E\u043D\u044C\u043A", -1, 1),
        new Among("\u0456\u043D\u044C\u043A", -1, 1),
        new Among("\u044E\u0441\u0456\u043D\u044C\u043A", 3, 1),
        new Among("\u0456\u0441\u0456\u043D\u044C\u043A", 3, 1)
    };

    private final static Among[] a_11 = {
        new Among("\u0456\u043D\u043D\u044F\u043C\u0438", -1, 1),
        new Among("\u0456\u043D\u043D\u044F\u043C", -1, 1),
        new Among("\u0456\u043D\u043D\u044F\u0445", -1, 1),
        new Among("\u0456\u043D\u044C", -1, 1),
        new Among("\u0456\u043D\u043D\u044E", -1, 1),
        new Among("\u0456\u043D\u043D\u044F", -1, 1),
        new Among("\u0456\u043D\u043D\u0456", -1, 1)
    };

    private final static Among[] a_12 = {
        new Among("\u0430\u043D\u043D\u044F\u043C\u0438", -1, 1),
        new Among("\u0435\u043D\u043D\u044F\u043C\u0438", -1, 1),
        new Among("\u044F\u043D\u043D\u044F\u043C\u0438", -1, 1),
        new Among("\u0430\u043D\u043D\u044F\u043C", -1, 1),
        new Among("\u0435\u043D\u043D\u044F\u043C", -1, 1),
        new Among("\u044F\u043D\u043D\u044F\u043C", -1, 1),
        new Among("\u0430\u043D\u043D\u044F\u0445", -1, 1),
        new Among("\u0435\u043D\u043D\u044F\u0445", -1, 1),
        new Among("\u044F\u043D\u043D\u044F\u0445", -1, 1),
        new Among("\u0430\u043D\u044C", -1, 1),
        new Among("\u0435\u043D\u044C", -1, 1),
        new Among("\u044F\u043D\u044C", -1, 1),
        new Among("\u0430\u043D\u043D\u044E", -1, 1),
        new Among("\u0435\u043D\u043D\u044E", -1, 1),
        new Among("\u044F\u043D\u043D\u044E", -1, 1),
        new Among("\u0430\u043D\u043D\u044F", -1, 1),
        new Among("\u0435\u043D\u043D\u044F", -1, 1),
        new Among("\u044F\u043D\u043D\u044F", -1, 1),
        new Among("\u0430\u043D\u043D\u0456", -1, 1),
        new Among("\u0435\u043D\u043D\u0456", -1, 1),
        new Among("\u044F\u043D\u043D\u0456", -1, 1)
    };

    private final static Among[] a_13 = {
        new Among("\u043E\u0432", -1, 1),
        new Among("\u0443\u0432", -1, 1),
        new Among("\u043E\u0432\u0443\u0432", 1, 1),
        new Among("\u044E\u0432", -1, 1),
        new Among("\u0437\u044C\u043A", -1, 1),
        new Among("\u0441\u044C\u043A", -1, 1),
        new Among("\u0456\u0437\u043C", -1, 1),
        new Among("\u0430\u043D", -1, 4),
        new Among("\u043E\u0432\u0430\u043D", 7, 1),
        new Among("\u0443\u0432\u0430\u043D", 7, 1),
        new Among("\u044E\u0432\u0430\u043D", 7, 1),
        new Among("\u0456\u0432\u043D", -1, 1),
        new Among("\u044C\u043D", -1, 1),
        new Among("\u0430\u043B\u044C\u043D", 12, 3),
        new Among("\u0435\u043B\u044C\u043D", 12, 2),
        new Among("\u044F\u043D", -1, 1),
        new Among("\u0443\u0432\u0430\u0442", -1, 1),
        new Among("\u0456\u0441\u0442", -1, 1),
        new Among("\u0438\u0449", -1, 1)
    };

    private final static Among[] a_14 = {
        new Among("\u043B", -1, 2),
        new Among("\u043D", -1, 3),
        new Among("\u0456\u0448", -1, 1),
        new Among("\u044C", -1, 4)
    };

    private final static Among[] a_15 = {
        new Among("\u0430\u0433\u0440\u0435\u0433\u0430\u0442\u0438", -1, 96),
        new Among("\u0430\u0433\u0440\u043E\u043D\u043E\u043C", -1, 49),
        new Among("\u0430\u0434\u043C\u0456\u0440\u0430\u043B\u0430", -1, 17),
        new Among("\u0430\u0435\u0440\u043E\u0434\u0440\u043E\u043C", -1, 46),
        new Among("\u0430\u0435\u0440\u043E\u0434\u0440\u043E\u043C\u0443", 3, 46),
        new Among("\u0430\u043B\u044C\u0431\u043E\u043C", -1, 39),
        new Among("\u0430\u043B\u044C\u0431\u043E\u043C\u0443", 5, 39),
        new Among("\u0430\u043C\u0435\u0440\u0438\u0446\u0456", -1, 188),
        new Among("\u0430\u043C\u0441\u0442\u0435\u0440\u0434\u0430\u043C", -1, 60),
        new Among("\u0430\u043F\u0430\u0440\u0430\u0442\u0438", -1, 79),
        new Among("\u0430\u0440\u0442\u0435\u043C", -1, 57),
        new Among("\u0430\u0440\u0445\u0456\u0432", -1, -1),
        new Among("\u0430\u0441\u0442\u0440\u0430\u0445\u0430\u043D\u044C", -1, 155),
        new Among("\u0430\u0441\u0442\u0440\u043E\u043D\u043E\u043C", -1, 48),
        new Among("\u0430\u0444\u0440\u0438\u0446\u0456", -1, 191),
        new Among("\u0431\u0430\u0440\u0430\u0431\u0430\u043D\u043D\u0456", -1, 182),
        new Among("\u0431\u0435\u0440\u0435\u0437\u0430\u043D\u044C", -1, 154),
        new Among("\u0431\u0435\u0440\u0435\u0437\u0435\u043D\u044C", -1, 123),
        new Among("\u0431\u043E\u0440\u0438\u0441\u043F\u0456\u043B\u044C", -1, 153),
        new Among("\u0431\u043E\u0442\u043E\u0448\u0430\u043D\u044C", -1, 156),
        new Among("\u0431\u0440\u0435\u0442\u0430\u043D\u044C", -1, 166),
        new Among("\u0431\u0440\u0443\u043D\u0435\u0439", -1, 112),
        new Among("\u0431\u0443\u0434\u0456\u0432\u0435\u043B\u044C", -1, 144),
        new Among("\u0431\u0456\u0431\u043B\u0456\u043E\u0442\u0435\u0446\u0456", -1, 194),
        new Among("\u0431\u0456\u043B\u044F", -1, -1),
        new Among("\u0432'\u0454\u0442\u043D\u0430\u043C", -1, 59),
        new Among("\u0432\u0430\u0434\u0438\u043C", -1, 56),
        new Among("\u0432\u0430\u0437\u0456", -1, 200),
        new Among("\u0432\u0430\u0440\u0442\u043E\u0441\u0442\u0435\u0439", -1, 1),
        new Among("\u0432\u0430\u0440\u0442\u043E\u0441\u0442\u0456", -1, 1),
        new Among("\u0432\u0430\u0440\u0442\u0456\u0441\u0442\u044C", -1, 1),
        new Among("\u0432\u0430\u0440\u0442\u0456\u0441\u0442\u044E", -1, 1),
        new Among("\u0432\u0434\u0435\u0440\u043B\u0438\u0441\u044F", -1, 37),
        new Among("\u0432\u0435\u0440\u0435\u0441\u0435\u043D\u044C", -1, 129),
        new Among("\u0432\u0435\u0440\u0441\u0442\u0432", -1, 29),
        new Among("\u0432\u0435\u0440\u0441\u0442\u0432\u0430", 34, 29),
        new Among("\u0432\u0435\u0440\u0441\u0442\u0432\u0438", 34, 29),
        new Among("\u0432\u0435\u0440\u0441\u0442\u0432\u043E\u044E", 34, 29),
        new Among("\u0432\u0435\u0440\u0441\u0442\u0432\u0443", 34, 29),
        new Among("\u0432\u0435\u0440\u0441\u0442\u0432\u0456", 34, 29),
        new Among("\u0432\u0435\u0441\u044C", -1, -1),
        new Among("\u0432\u0438\u043C\u0435\u0440\u043B\u0430", -1, 36),
        new Among("\u0432\u0438\u043C\u0435\u0440\u043B\u0438", -1, 36),
        new Among("\u0432\u0438\u043F\u043B\u0430\u0442\u0438", -1, 86),
        new Among("\u0432\u0438\u0441\u0442\u0430\u0432\u0446\u0456", -1, 201),
        new Among("\u0432\u0438\u0442\u0440\u0430\u0442\u0438", -1, 67),
        new Among("\u0432\u043F\u043B\u0438\u0432", -1, -1),
        new Among("\u0432\u0442\u0435\u043A\u0442\u0438", -1, 33),
        new Among("\u0432\u0442\u0440\u0430\u0442\u0438", -1, 63),
        new Among("\u0432\u0456\u0434\u0430\u043D\u043D\u044F", -1, 177),
        new Among("\u0432\u0456\u0434\u0430\u043D\u043D\u0456", -1, 177),
        new Among("\u0432\u0456\u0434\u0441\u0442\u0430\u043D\u043D\u044E", -1, 163),
        new Among("\u0432\u0456\u0434\u0441\u0442\u0430\u043D\u044C", -1, 163),
        new Among("\u0432\u0456\u0434\u0442\u043E\u0434\u0456", -1, -1),
        new Among("\u0432\u0456\u043B\u044C\u044F\u043C", -1, 54),
        new Among("\u0432\u0456\u0446\u0456", -1, 185),
        new Among("\u0433\u0430\u0432\u0430\u043D\u044C", -1, 165),
        new Among("\u0433\u0430\u043B\u0456\u043B\u0435\u0439", -1, 120),
        new Among("\u0433\u0430\u0440\u043C\u0430\u0442\u0438", -1, 65),
        new Among("\u0433\u0435\u043D\u0435\u0440\u0430\u043B\u0430", -1, 16),
        new Among("\u0433\u0435\u043D\u0435\u0440\u0430\u043B\u0438", -1, 16),
        new Among("\u0433\u0435\u043D\u043E\u043C", -1, 41),
        new Among("\u0433\u0435\u043D\u043E\u043C\u0443", 61, 41),
        new Among("\u0433\u043E\u043B\u0456\u0432", -1, 145),
        new Among("\u0433\u043E\u043D\u0446\u0456", -1, 211),
        new Among("\u0433\u043E\u0440\u0431\u0430\u043D\u044C", -1, 173),
        new Among("\u0433\u0440\u0430\u043D\u0430\u0442\u0438", -1, 91),
        new Among("\u0433\u0440\u0443\u0434\u0435\u043D\u044C", -1, 131),
        new Among("\u0434\u0430\u043B\u0456", -1, -1),
        new Among("\u0434\u0430\u043D\u0438\u043B\u0430", -1, 9),
        new Among("\u0434\u0430\u043D\u0438\u043B\u043E", -1, 9),
        new Among("\u0434\u0430\u043D\u0438\u043B\u043E\u043C", 70, 9),
        new Among("\u0434\u0430\u043D\u0438\u043B\u0443", -1, 9),
        new Among("\u0434\u0430\u043D\u0438\u043B\u0456", -1, 9),
        new Among("\u0434\u0435\u0432'\u044F\u0442\u0438", -1, 139),
        new Among("\u0434\u0435\u043C\u043E\u043A\u0440\u0430\u0442\u0438", -1, 94),
        new Among("\u0434\u0435\u043D\u044C", -1, 142),
        new Among("\u0434\u0435\u043F\u0443\u0442\u0430\u0442\u0438", -1, 66),
        new Among("\u0434\u0435\u0440\u0436\u0430\u0432", -1, -1),
        new Among("\u0434\u0435\u0441\u044C", -1, -1),
        new Among("\u0434\u0435\u0441\u044F\u0442\u0438", -1, 121),
        new Among("\u0434\u0435\u0441\u044F\u0442\u044C", -1, 121),
        new Among("\u0434\u0436\u043E\u0432\u0430\u043D\u043D\u0456", -1, 161),
        new Among("\u0434\u0438\u043F\u043B\u043E\u043C", -1, 42),
        new Among("\u0434\u0438\u0441\u043F\u043B\u0435\u0439", -1, 119),
        new Among("\u0434\u0438\u0442\u0438\u043D\u0430", -1, 141),
        new Among("\u0434\u0438\u0442\u0438\u043D\u0438", -1, 141),
        new Among("\u0434\u0438\u0442\u0438\u043D\u043E\u044E", -1, 141),
        new Among("\u0434\u0438\u0442\u0438\u043D\u0443", -1, 141),
        new Among("\u0434\u0438\u0442\u0438\u043D\u0456", -1, 141),
        new Among("\u0434\u043D\u0435\u043C", -1, 142),
        new Among("\u0434\u043D\u044E", -1, 142),
        new Among("\u0434\u043D\u044F", -1, 142),
        new Among("\u0434\u043D\u044F\u043C", 92, 142),
        new Among("\u0434\u043D\u044F\u043C\u0438", 93, 142),
        new Among("\u0434\u043D\u044F\u0445", 92, 142),
        new Among("\u0434\u043D\u0456", -1, 142),
        new Among("\u0434\u043D\u0456\u0432", 96, 142),
        new Among("\u0434\u043E\u0432\u0433\u0430\u043D\u044C", -1, 174),
        new Among("\u0434\u043E\u043C\u0435\u043D\u043D\u0456", -1, 176),
        new Among("\u0434\u043E\u0440\u043E\u0433\u043E\u0446\u0456\u043D\u043D\u0456", -1, 180),
        new Among("\u0434\u043E\u0440\u043E\u0437\u0456", -1, 196),
        new Among("\u0434\u043E\u0441\u0438\u0442\u044C", -1, 32),
        new Among("\u0434\u043E\u0441\u043A\u043E\u043D\u0430\u043B\u043E", -1, 15),
        new Among("\u0434\u043E\u0441\u0456", -1, -1),
        new Among("\u0434\u043E\u0442\u0435\u043F\u0435\u0440", -1, -1),
        new Among("\u0434\u0443\u0436\u0435", -1, -1),
        new Among("\u0434\u0456\u043B\u044F\u043D\u0446\u0456", -1, 197),
        new Among("\u0434\u0456\u0441\u043D\u0435\u0439", -1, 111),
        new Among("\u0435\u043A\u043E\u043D\u043E\u043C\u0456\u0446\u0456", -1, 219),
        new Among("\u0435\u043A\u0441\u043F\u043E\u043D\u0430\u0442\u0438", -1, 87),
        new Among("\u0435\u043B\u0456\u0442\u0438", -1, 81),
        new Among("\u0435\u043D\u0435\u0439", -1, 113),
        new Among("\u0436\u043E\u0432\u0442\u0435\u043D\u044C", -1, 130),
        new Among("\u0436\u0443\u0440\u043D\u0430\u043B\u0438", -1, 23),
        new Among("\u0437\u0430\u0432\u0436\u0434\u0438", -1, -1),
        new Among("\u0437\u0430\u043C\u0430\u043B\u043E", -1, 12),
        new Among("\u0437\u0430\u043C\u0456\u0441\u0442\u044C", -1, -1),
        new Among("\u0437\u0430\u043F\u0438\u0442\u0438", -1, 93),
        new Among("\u0437\u0430\u0442\u043E\u0446\u0456", -1, 205),
        new Among("\u0437\u0431\u0456\u0440\u0446\u0456", -1, 222),
        new Among("\u0437\u0432\u0456\u0434\u043A\u0438", -1, -1),
        new Among("\u0437\u0432\u0456\u0434\u0441\u0438", -1, -1),
        new Among("\u0437\u0432\u0456\u0434\u0442\u0438", -1, -1),
        new Among("\u0437\u0432\u0456\u0442\u0438", -1, 82),
        new Among("\u0437\u0433\u043E\u0434\u043E\u043C", -1, -1),
        new Among("\u0437\u0435\u043C\u0435\u043B\u044C", -1, 143),
        new Among("\u0437\u043D\u043E\u0432\u0443", -1, -1),
        new Among("\u043A\u0430\u043C\u0456\u043D\u044C", -1, 136),
        new Among("\u043A\u0430\u043D\u0430\u043B\u0438", -1, 22),
        new Among("\u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442\u0438", -1, 76),
        new Among("\u043A\u0430\u0440\u0434\u0438\u043D\u0430\u043B\u0430", -1, 19),
        new Among("\u043A\u0432\u0430\u0440\u0442\u0430\u043B\u0438", -1, 28),
        new Among("\u043A\u0432\u0456\u0442\u0435\u043D\u044C", -1, 124),
        new Among("\u043A\u0438\u0440\u0438\u043B\u0430", -1, 8),
        new Among("\u043A\u0438\u0440\u0438\u043B\u043E", -1, 8),
        new Among("\u043A\u0438\u0440\u0438\u043B\u043E\u043C", 135, 8),
        new Among("\u043A\u0438\u0440\u0438\u043B\u0443", -1, 8),
        new Among("\u043A\u0438\u0457\u0432", -1, 4),
        new Among("\u043A\u043B\u0430\u0434\u0446\u0456", -1, 218),
        new Among("\u043A\u043B\u0435\u0439", -1, 117),
        new Among("\u043A\u043D\u0438\u0437\u0456", -1, 190),
        new Among("\u043A\u043E\u0433\u043E", -1, -1),
        new Among("\u043A\u043E\u043B\u0438", -1, -1),
        new Among("\u043A\u043E\u043B\u0438\u0441\u044C", 143, -1),
        new Among("\u043A\u043E\u043C\u0443", -1, -1),
        new Among("\u043A\u043E\u043E\u0440\u0434\u0438\u043D\u0430\u0442\u0438", -1, 74),
        new Among("\u043A\u043E\u0440\u0456\u043D\u044C", -1, 137),
        new Among("\u043A\u0440\u0438\u0441\u0442\u0430\u043B\u0430", -1, 26),
        new Among("\u043A\u0440\u0438\u0441\u0442\u0430\u043B\u0438", -1, 26),
        new Among("\u043A\u0440\u0438\u0442\u0438\u0446\u0456", -1, 224),
        new Among("\u043A\u0443\u0431\u0430\u043D\u044C", -1, 167),
        new Among("\u043A\u0443\u0434\u0438", -1, -1),
        new Among("\u043A\u0456\u043C\u043D\u0430\u0442\u0438", -1, 71),
        new Among("\u043B\u0430\u0443\u0440\u0435\u0430\u0442\u0438", -1, 75),
        new Among("\u043B\u0435\u0434\u044C", -1, -1),
        new Among("\u043B\u0438\u043F\u0435\u043D\u044C", -1, 127),
        new Among("\u043B\u0438\u0448\u0435", -1, -1),
        new Among("\u043B\u043E\u0437\u0430\u043D\u043D\u0456", -1, 162),
        new Among("\u043B\u044C\u0432\u0456\u0432", -1, 148),
        new Among("\u043B\u044E\u0434\u0435\u0439", -1, 6),
        new Among("\u043B\u044E\u0434\u0438\u043D\u0430", -1, 6),
        new Among("\u043B\u044E\u0434\u0438\u043D\u0438", -1, 6),
        new Among("\u043B\u044E\u0434\u0438\u043D\u043E\u044E", -1, 6),
        new Among("\u043B\u044E\u0434\u0438\u043D\u0443", -1, 6),
        new Among("\u043B\u044E\u0434\u0438\u043D\u0456", -1, 6),
        new Among("\u043B\u0456\u0437\u0456", -1, 187),
        new Among("\u043B\u0456\u0446\u0435\u0439", -1, 100),
        new Among("\u043C\u0430\u0432\u0437\u043E\u043B\u0435\u0439", -1, 118),
        new Among("\u043C\u0430\u0434\u0430\u043C", -1, 53),
        new Among("\u043C\u0430\u0439\u0436\u0435", -1, -1),
        new Among("\u043C\u0430\u043A\u0441\u0438\u043C", -1, 55),
        new Among("\u043C\u0430\u043B\u043E", -1, -1),
        new Among("\u043C\u0430\u0440\u0433\u0430\u0440\u0438\u0442\u0438", -1, 90),
        new Among("\u043C\u0430\u0440\u0448\u0430\u043B\u0430", -1, 18),
        new Among("\u043C\u0430\u0441\u0438\u0432", -1, -1),
        new Among("\u043C\u0430\u0442\u0435\u0439", -1, 108),
        new Among("\u043C\u0430\u0442\u0435\u0440\u0456\u044E", -1, 31),
        new Among("\u043C\u0430\u0442\u0435\u0440\u0456\u044F", -1, 31),
        new Among("\u043C\u0430\u0442\u0435\u0440\u0456\u0454\u044E", -1, 31),
        new Among("\u043C\u0430\u0442\u0435\u0440\u0456\u0457", -1, 31),
        new Among("\u043C\u0430\u0446\u0435\u0439", -1, 106),
        new Among("\u043C\u0435\u043A\u0441\u0438\u0446\u0456", -1, 202),
        new Among("\u043C\u0435\u043B\u044C\u043D\u0438\u043A", -1, 30),
        new Among("\u043C\u0435\u043B\u044C\u043D\u0438\u043A\u0430", 183, 30),
        new Among("\u043C\u0435\u043B\u044C\u043D\u0438\u043A\u0438", 183, 30),
        new Among("\u043C\u0435\u043B\u044C\u043D\u0438\u043A\u043E\u043C", 183, 30),
        new Among("\u043C\u0435\u043B\u044C\u043D\u0438\u043A\u0443", 183, 30),
        new Among("\u043C\u0435\u043B\u044C\u043D\u0438\u043A\u0456\u0432", 183, 30),
        new Among("\u043C\u0435\u0442\u0430\u043B\u0438", -1, 27),
        new Among("\u043C\u0438\u043A\u043E\u043B\u0430\u0457\u0432", -1, 151),
        new Among("\u043C\u043E\u0433\u0438\u043B\u0430", -1, 7),
        new Among("\u043C\u043E\u0433\u0438\u043B\u0438", -1, 7),
        new Among("\u043C\u043E\u0433\u0438\u043B\u043E\u044E", -1, 7),
        new Among("\u043C\u043E\u0433\u0438\u043B\u0443", -1, 7),
        new Among("\u043C\u043E\u0433\u0438\u043B\u0456", -1, 7),
        new Among("\u043C\u0443\u0437\u0435\u0439", -1, 99),
        new Among("\u043C\u0443\u0437\u0438\u0446\u0456", -1, 208),
        new Among("\u043C\u0456\u043D\u0435\u0440\u0430\u043B\u0438", -1, 25),
        new Among("\u043C\u0456\u043D\u0456\u0430\u043B\u044C\u0431\u043E\u043C", -1, 40),
        new Among("\u043C\u0456\u043D\u0456\u0430\u043B\u044C\u0431\u043E\u043C\u0443", 199, 40),
        new Among("\u043C\u0456\u0448\u0435\u043D\u043D\u044E", -1, 175),
        new Among("\u043C\u0456\u0448\u0435\u043D\u044C", -1, 175),
        new Among("\u043D\u0430\u043F\u0440\u044F\u043C", -1, 51),
        new Among("\u043D\u0430\u043F\u0440\u044F\u043C\u0438", 203, 51),
        new Among("\u043D\u0430\u0443\u0446\u0456", -1, 214),
        new Among("\u043D\u0435\u0432\u0434\u0430\u043B\u043E", -1, 14),
        new Among("\u043D\u0435\u043C\u0430\u043B\u043E", -1, 13),
        new Among("\u043D\u0435\u0441\u043A\u0456\u043D\u0447\u0435\u043D\u043D\u0456", -1, 181),
        new Among("\u043D\u0435\u0447\u0438\u0441\u043B\u0435\u043D\u043D\u0456", -1, 179),
        new Among("\u043D\u0438\u0437\u0446\u0456", -1, 217),
        new Among("\u043D\u043E\u0432\u0435\u043B\u0430", -1, 38),
        new Among("\u043D\u043E\u0432\u0435\u043B\u0438", -1, 38),
        new Among("\u043D\u0456\u0447\u043E\u0433\u043E", -1, -1),
        new Among("\u043E\u0431\u043A\u043B\u0430\u0434\u0438\u043D\u0446\u0456", -1, 226),
        new Among("\u043E\u043A\u0440\u0443\u0437\u0456", -1, 186),
        new Among("\u043E\u043A\u0440\u0456\u043C", -1, -1),
        new Among("\u043E\u043F\u043B\u0430\u0442\u0438", -1, 83),
        new Among("\u043E\u0440\u0431\u0456\u0442\u0438", -1, 70),
        new Among("\u043E\u0440\u0444\u0435\u0439", -1, 104),
        new Among("\u043E\u0441\u0432\u0456\u0442\u0438", -1, 61),
        new Among("\u043E\u0441\u0442\u0430\u043D\u043D\u044E", -1, 157),
        new Among("\u043E\u0441\u0442\u0430\u043D\u043D\u044F", -1, 157),
        new Among("\u043E\u0441\u0442\u0430\u043D\u043D\u0456", -1, 157),
        new Among("\u043E\u0441\u0456\u0431", -1, 5),
        new Among("\u043E\u0441\u0456\u043D\u044C", -1, 147),
        new Among("\u043F'\u044F\u0442\u0438", -1, 138),
        new Among("\u043F\u0430\u043B\u0430\u0442\u0438", -1, 64),
        new Among("\u043F\u043B\u0438\u0442\u0438", -1, 78),
        new Among("\u043F\u043E\u0432\u043D\u043E\u0446\u0456\u043D\u043D\u0456", -1, 184),
        new Among("\u043F\u043E\u0432\u0456\u0442\u0438", -1, 92),
        new Among("\u043F\u043E\u0437\u043D\u0430\u043D\u044C", -1, 169),
        new Among("\u043F\u043E\u043A\u0438", -1, -1),
        new Among("\u043F\u043E\u043B\u0456\u0442\u0438\u0446\u0456", -1, 207),
        new Among("\u043F\u043E\u043C\u0435\u0440\u043B\u0430", -1, 35),
        new Among("\u043F\u043E\u043C\u0435\u0440\u043B\u0438", -1, 35),
        new Among("\u043F\u043E\u043C\u0435\u0440\u043B\u043E", -1, 35),
        new Among("\u043F\u043E\u043C\u0435\u0440\u0442\u0438", -1, 35),
        new Among("\u043F\u043E\u0441\u0456\u0432", -1, -1),
        new Among("\u043F\u043E\u0442\u0456\u043C", -1, -1),
        new Among("\u043F\u0440\u0430\u0437\u0456", -1, 203),
        new Among("\u043F\u0440\u0430\u043A\u0442\u0438\u0446\u0456", -1, 198),
        new Among("\u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442\u0438", -1, 80),
        new Among("\u043F\u0440\u0438\u0432\u0456\u043B\u0435\u0439", -1, 116),
        new Among("\u043F\u0440\u0438\u0439\u043E\u043C", -1, 43),
        new Among("\u043F\u0440\u0438\u0439\u043E\u043C\u0443", 244, 43),
        new Among("\u043F\u0440\u0438\u0441\u0442\u0430\u043D\u044C", -1, 168),
        new Among("\u043F\u0440\u0438\u0441\u044F\u0437\u0456", -1, 195),
        new Among("\u043F\u0440\u0438\u0442\u0430\u043C\u0430\u043D\u043D\u0456", -1, 178),
        new Among("\u043F\u0440\u043E\u043C\u0435\u0442\u0435\u0439", -1, 107),
        new Among("\u043F\u0440\u043E\u043C\u0456\u043D\u044C", -1, 135),
        new Among("\u043F\u0440\u043E\u0440\u043E\u043A", -1, 140),
        new Among("\u043F\u0440\u043E\u0440\u043E\u043A\u0430", 251, 140),
        new Among("\u043F\u0440\u043E\u0440\u043E\u043A\u0438", 251, 140),
        new Among("\u043F\u0440\u043E\u0440\u043E\u043A\u043E\u043C", 251, 140),
        new Among("\u043F\u0440\u043E\u0440\u043E\u043A\u0443", 251, 140),
        new Among("\u043F\u0440\u043E\u0440\u043E\u043A\u0456\u0432", 251, 140),
        new Among("\u043F\u0440\u043E\u0441\u0432\u0456\u0442\u0438", -1, 72),
        new Among("\u043F\u0440\u043E\u0442\u0438", -1, -1),
        new Among("\u043F\u0442\u043E\u043B\u0435\u043C\u0435\u0439", -1, 109),
        new Among("\u043F\u0456\u0432\u0434\u0435\u043D\u043D\u0456", -1, 158),
        new Among("\u043F\u0456\u0432\u0444\u0456\u043D\u0430\u043B\u0438", -1, 21),
        new Among("\u043F\u0456\u0434\u0433\u043E\u0442\u043E\u0432\u0446\u0456", -1, 210),
        new Among("\u043F\u0456\u0434\u0439\u043E\u043C", -1, 44),
        new Among("\u043F\u0456\u0434\u0439\u043E\u043C\u0443", 263, 44),
        new Among("\u043F\u0456\u0434\u0442\u0440\u0438\u043C\u0446\u0456", -1, 215),
        new Among("\u0440\u0430\u0437\u043E\u043C", -1, -1),
        new Among("\u0440\u0435\u0436\u0438\u043C", -1, 50),
        new Among("\u0440\u0435\u0436\u0438\u043C\u0438", 267, 50),
        new Among("\u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0438", -1, 62),
        new Among("\u0440\u0435\u0441\u043F\u0443\u0431\u043B\u0456\u0446\u0456", -1, 192),
        new Among("\u0440\u0438\u0437\u0456", -1, 227),
        new Among("\u0440\u043E\u0437\u0440\u043E\u0431\u0446\u0456", -1, 204),
        new Among("\u0440\u043E\u0446\u0456", -1, 3),
        new Among("\u0440\u0443\u0446\u0456", -1, 221),
        new Among("\u0440\u044F\u0437\u0430\u043D\u044C", -1, 170),
        new Among("\u0440\u0456\u0432\u0435\u043D\u044C", -1, 132),
        new Among("\u0440\u0456\u043A", -1, 3),
        new Among("\u0440\u0456\u0447\u0446\u0456", -1, 189),
        new Among("\u0441\u0430\u043C\u0435", -1, -1),
        new Among("\u0441\u0432\u044F\u0449\u0435\u043D\u043D\u0456", -1, 160),
        new Among("\u0441\u0432\u0456\u0442\u0438", -1, 84),
        new Among("\u0441\u0435\u0431\u0435", -1, -1),
        new Among("\u0441\u0435\u0440\u043F\u0435\u043D\u044C", -1, 128),
        new Among("\u0441\u0438\u0431\u0456\u0440", -1, -1),
        new Among("\u0441\u0438\u0433\u043D\u0430\u043B\u0438", -1, 24),
        new Among("\u0441\u0438\u043D\u0434\u0440\u043E\u043C", -1, 45),
        new Among("\u0441\u0438\u043D\u0434\u0440\u043E\u043C\u0443", 286, 45),
        new Among("\u0441\u043C\u0443\u0437\u0456", -1, 193),
        new Among("\u0441\u043E\u0432\u0456\u0441\u0442\u044C", -1, 2),
        new Among("\u0441\u043E\u0432\u0456\u0441\u0442\u044E", -1, 2),
        new Among("\u0441\u043E\u0432\u0456\u0441\u0442\u0456", -1, 2),
        new Among("\u0441\u043E\u043B\u0434\u0430\u0442\u0438", -1, 68),
        new Among("\u0441\u043F\u043B\u0430\u0442\u0438", -1, 85),
        new Among("\u0441\u043F\u0440\u0430\u0432", -1, -1),
        new Among("\u0441\u043F\u0440\u0430\u0432\u0434\u0456", 294, -1),
        new Among("\u0441\u0442\u0430\u0442\u0435\u0439", -1, 97),
        new Among("\u0441\u0442\u043E\u0440\u0456\u043D\u0446\u0456", -1, 213),
        new Among("\u0441\u0442\u0440\u0430\u0442\u0438", -1, 73),
        new Among("\u0441\u0442\u0440\u0456\u0447\u0446\u0456", -1, 220),
        new Among("\u0441\u0442\u0443\u043F\u0456\u043D\u044C", -1, 134),
        new Among("\u0441\u044C\u043E\u0433\u043E\u0434\u043D\u0456", -1, -1),
        new Among("\u0441\u0456\u0434\u043D\u0435\u0439", -1, 110),
        new Among("\u0441\u0456\u043C\u0435\u0439", -1, 98),
        new Among("\u0441\u0456\u0447\u0435\u043D\u044C", -1, 122),
        new Among("\u0442\u0430\u0434\u0435\u0439", -1, 105),
        new Among("\u0442\u0430\u0439\u0432\u0430\u043D\u044C", -1, 164),
        new Among("\u0442\u0435\u0431\u0435", -1, -1),
        new Among("\u0442\u0435\u0440\u043D\u043E\u043F\u0456\u043B\u044C", -1, 152),
        new Among("\u0442\u0435\u0445\u043D\u0456\u0446\u0456", -1, 216),
        new Among("\u0442\u043E\u0434\u0456", -1, -1),
        new Among("\u0442\u043E\u043B\u0441\u0442\u043E\u0439", -1, 10),
        new Among("\u0442\u043E\u043C\u0443", -1, -1),
        new Among("\u0442\u043E\u0447\u0446\u0456", -1, 206),
        new Among("\u0442\u0440\u0430\u0432\u0435\u043D\u044C", -1, 125),
        new Among("\u0442\u0440\u0435\u0431\u0430", -1, -1),
        new Among("\u0442\u0440\u0456\u0439\u0446\u0456", -1, 212),
        new Among("\u0442\u0443\u0434\u0438", -1, -1),
        new Among("\u0443\u0432\u0430\u0437\u0456", -1, 209),
        new Among("\u0443\u0432\u0435\u0441\u044C", -1, -1),
        new Among("\u0443\u0442\u0435\u043A\u0442\u0438", -1, 34),
        new Among("\u0443\u0447\u0435\u043D\u044C", -1, 133),
        new Among("\u0444\u0430\u0431\u0440\u0438\u0446\u0456", -1, 225),
        new Among("\u0444\u043E\u0440\u043C\u0430\u0442\u0438", -1, 95),
        new Among("\u0444\u043E\u0440\u0442\u0435\u043F\u0456\u0430\u043D\u043D\u0456", -1, 183),
        new Among("\u0444\u0443\u0442\u0431\u043E\u043B\u0446\u0456", -1, 199),
        new Among("\u0444\u0456\u043D\u0430\u043B\u0438", -1, 20),
        new Among("\u0445\u0430\u0439\u043D\u0430\u043D\u044C", -1, 172),
        new Among("\u0445\u0430\u0440\u043A\u0456\u0432", -1, 149),
        new Among("\u0445\u043E\u043A\u0435\u0439", -1, 101),
        new Among("\u0446\u0438\u0442\u0430\u0442\u0438", -1, 89),
        new Among("\u0447\u0435\u043C\u043F\u0456\u043E\u043D\u0430\u0442\u0438", -1, 77),
        new Among("\u0447\u0435\u0440\u0432\u0435\u043D\u044C", -1, 126),
        new Among("\u0447\u0435\u0440\u0437\u0456", -1, 223),
        new Among("\u0447\u0435\u0440\u043D\u0456\u0433\u0456\u0432", -1, 150),
        new Among("\u0447\u0438\u043C\u0430\u043B\u043E", -1, 11),
        new Among("\u0447\u043E\u043C\u0443", -1, -1),
        new Among("\u0448\u043E\u043B\u043E\u043C", -1, 47),
        new Among("\u0448\u0442\u0430\u0442\u0438", -1, 69),
        new Among("\u0449\u043E\u0434\u0435\u043D\u043D\u0456", -1, 159),
        new Among("\u0449\u043E\u0439\u043D\u043E", -1, -1),
        new Among("\u044E\u0432\u0456\u043B\u0435\u0439", -1, 115),
        new Among("\u044E\u043D\u044C\u043D\u0430\u043D\u044C", -1, 171),
        new Among("\u0454\u0432\u0430\u043D\u0433\u0435\u043B\u0456\u0454", -1, 146),
        new Among("\u0454\u0432\u0440\u0435\u0439", -1, 102),
        new Among("\u0454\u0440\u0443\u0441\u0430\u043B\u0438\u043C", -1, 58),
        new Among("\u0456\u043D\u0430\u043A\u0448\u0435", -1, -1),
        new Among("\u0456\u043D\u043A\u043E\u043B\u0438", -1, -1),
        new Among("\u0456\u043D\u043E\u0434\u0456", -1, -1),
        new Among("\u0456\u0440\u0438\u043D\u0435\u0439", -1, 114),
        new Among("\u0456\u0441\u043B\u0430\u043C", -1, 52),
        new Among("\u0456\u0441\u043F\u0438\u0442\u0438", -1, 88),
        new Among("\u0456\u0454\u0440\u0435\u0439", -1, 103)
    };

    private final static Among[] a_16 = {
        new Among("\u0440\u0456\u0433", -1, 15),
        new Among("\u043F\u043B\u0456\u0434", -1, 11),
        new Among("\u0440\u0456\u0434", -1, 12),
        new Among("\u0445\u0456\u0434", -1, 1),
        new Among("\u0431\u0456\u043A", -1, 13),
        new Among("\u0441\u0456\u043A", -1, 16),
        new Among("\u0441\u0442\u0456\u043B", -1, 6),
        new Among("\u0434\u0456\u043C", -1, 5),
        new Among("\u0431\u0456\u0440", -1, 2),
        new Among("\u0440\u0456\u0441\u0442", -1, 3),
        new Among("\u043A\u0456\u0442", -1, 14),
        new Among("\u043D\u0456\u0447", -1, 4),
        new Among("\u043F\u0456\u0447", -1, 7),
        new Among("\u0441\u0456\u043B\u044C", -1, 8),
        new Among("\u043A\u0456\u043D\u044C", -1, 9),
        new Among("\u0433\u0456\u0441\u0442\u044C", -1, 10)
    };

    private final static Among[] a_17 = {
        new Among("\u0441\u044C", -1, -1),
        new Among("\u043B\u0430\u0441\u044C", 0, -1),
        new Among("\u0432\u0441\u044C", 0, -1),
        new Among("\u0442\u0438\u0441\u044C", 0, -1),
        new Among("\u0441\u044F", -1, -1),
        new Among("\u0432\u0441\u044F", 4, -1),
        new Among("\u0442\u0438\u0441\u044F", 4, -1)
    };

    private static final char[] g_v = {33, 65, 8, 192, 208 };


    private boolean r_professional() {
        int among_var;
        ket = cursor;
        among_var = find_among_b(a_8);
        if (among_var == 0)
        {
            return false;
        }
        bra = cursor;
        switch (among_var) {
            case 1:
                slice_del();
                break;
            case 2:
                if (!(eq_s_b("\u043A")))
                {
                    return false;
                }
                slice_del();
                break;
        }
        return true;
    }

    @Override
    public boolean stem() {
        int among_var;
        boolean B_found_ty_noun;
        boolean B_found_la_noun;
        boolean B_found_verb;
        boolean B_found_ia;
        boolean B_found_professional;
        boolean B_found_diminutive;
        int I_p2;
        int I_pV;
        int v_1 = cursor;
        lab0: {
            bra = cursor;
            if (!(eq_s("\u043D\u0430\u0439")))
            {
                break lab0;
            }
            ket = cursor;
            if (cursor >= limit)
            {
                break lab0;
            }
            slice_del();
        }
        cursor = v_1;
        lab1: {
            int v_2 = cursor;
            lab2: {
                int v_3 = cursor;
                if (!(eq_s("\u043E\u043A\u0440\u0435\u043C\u043E")))
                {
                    break lab2;
                }
                if (cursor < limit)
                {
                    break lab2;
                }
                cursor = v_3;
                limit_backward = cursor;
                cursor = limit;
                ket = cursor;
                if (!(eq_s_b("\u043E")))
                {
                    break lab2;
                }
                bra = cursor;
                slice_del();
                cursor = limit_backward;
                break lab1;
            }
            cursor = v_2;
            lab3: {
                bra = cursor;
                among_var = find_among(a_15);
                if (among_var == 0)
                {
                    break lab3;
                }
                ket = cursor;
                if (cursor < limit)
                {
                    break lab3;
                }
                switch (among_var) {
                    case 1:
                        slice_from("\u0432\u0430\u0440\u0442\u043E\u0441\u0442");
                        break;
                    case 2:
                        slice_from("\u0441\u043E\u0432\u0456\u0441\u0442");
                        break;
                    case 3:
                        slice_from("\u0440\u043E\u043A");
                        break;
                    case 4:
                        slice_from("\u043A\u0438\u0454\u0432");
                        break;
                    case 5:
                        slice_from("\u043E\u0441\u043E\u0431");
                        break;
                    case 6:
                        slice_from("\u043B\u044E\u0434");
                        break;
                    case 7:
                        slice_from("\u043C\u043E\u0433\u0438\u043B");
                        break;
                    case 8:
                        slice_from("\u043A\u0438\u0440\u0438\u043B");
                        break;
                    case 9:
                        slice_from("\u0434\u0430\u043D\u0438\u043B");
                        break;
                    case 10:
                        slice_from("\u0442\u043E\u043B\u0441\u0442");
                        break;
                    case 11:
                        slice_from("\u0447\u0438\u043C\u0430\u043B\u043E");
                        break;
                    case 12:
                        slice_from("\u0437\u0430\u043C\u0430\u043B");
                        break;
                    case 13:
                        slice_from("\u043D\u0435\u043C\u0430\u043B");
                        break;
                    case 14:
                        slice_from("\u043D\u0435\u0432\u0434\u0430\u043B");
                        break;
                    case 15:
                        slice_from("\u0434\u043E\u0441\u043A\u043E\u043D\u0430\u043B");
                        break;
                    case 16:
                        slice_from("\u0433\u0435\u043D\u0435\u0440\u0430\u043B");
                        break;
                    case 17:
                        slice_from("\u0430\u0434\u043C\u0456\u0440\u0430\u043B");
                        break;
                    case 18:
                        slice_from("\u043C\u0430\u0440\u0448\u0430\u043B");
                        break;
                    case 19:
                        slice_from("\u043A\u0430\u0440\u0434\u0438\u043D\u0430\u043B");
                        break;
                    case 20:
                        slice_from("\u0444\u0456\u043D\u0430\u043B");
                        break;
                    case 21:
                        slice_from("\u043F\u0456\u0432\u0444\u0456\u043D\u0430\u043B");
                        break;
                    case 22:
                        slice_from("\u043A\u0430\u043D\u0430\u043B");
                        break;
                    case 23:
                        slice_from("\u0436\u0443\u0440\u043D\u0430\u043B");
                        break;
                    case 24:
                        slice_from("\u0441\u0438\u0433\u043D\u0430\u043B");
                        break;
                    case 25:
                        slice_from("\u043C\u0456\u043D\u0435\u0440\u0430\u043B");
                        break;
                    case 26:
                        slice_from("\u043A\u0440\u0438\u0441\u0442\u0430\u043B");
                        break;
                    case 27:
                        slice_from("\u043C\u0435\u0442\u0430\u043B");
                        break;
                    case 28:
                        slice_from("\u043A\u0432\u0430\u0440\u0442\u0430\u043B");
                        break;
                    case 29:
                        slice_from("\u0432\u0435\u0440\u0441\u0442\u0432");
                        break;
                    case 30:
                        slice_from("\u043C\u0435\u043B\u044C\u043D\u0438\u043A");
                        break;
                    case 31:
                        slice_from("\u043C\u0430\u0442\u0435\u0440\u0456");
                        break;
                    case 32:
                        slice_from("\u0434\u043E\u0441\u0438\u0442\u044C");
                        break;
                    case 33:
                        slice_from("\u0432\u0442\u0435\u043A");
                        break;
                    case 34:
                        slice_from("\u0443\u0442\u0435\u043A");
                        break;
                    case 35:
                        slice_from("\u043F\u043E\u043C\u0435\u0440");
                        break;
                    case 36:
                        slice_from("\u0432\u0438\u043C\u0435\u0440");
                        break;
                    case 37:
                        slice_from("\u0432\u0434\u0435\u0440");
                        break;
                    case 38:
                        slice_from("\u043D\u043E\u0432\u0435\u043B");
                        break;
                    case 39:
                        slice_from("\u0430\u043B\u044C\u0431\u043E\u043C");
                        break;
                    case 40:
                        slice_from("\u043C\u0456\u043D\u0456\u0430\u043B\u044C\u0431\u043E\u043C");
                        break;
                    case 41:
                        slice_from("\u0433\u0435\u043D\u043E\u043C");
                        break;
                    case 42:
                        slice_from("\u0434\u0438\u043F\u043B\u043E\u043C");
                        break;
                    case 43:
                        slice_from("\u043F\u0440\u0438\u0439\u043E\u043C");
                        break;
                    case 44:
                        slice_from("\u043F\u0456\u0434\u0439\u043E\u043C");
                        break;
                    case 45:
                        slice_from("\u0441\u0438\u043D\u0434\u0440\u043E\u043C");
                        break;
                    case 46:
                        slice_from("\u0430\u0435\u0440\u043E\u0434\u0440\u043E\u043C");
                        break;
                    case 47:
                        slice_from("\u0448\u043E\u043B\u043E\u043C");
                        break;
                    case 48:
                        slice_from("\u0430\u0441\u0442\u0440\u043E\u043D\u043E\u043C");
                        break;
                    case 49:
                        slice_from("\u0430\u0433\u0440\u043E\u043D\u043E\u043C");
                        break;
                    case 50:
                        slice_from("\u0440\u0435\u0436\u0438\u043C");
                        break;
                    case 51:
                        slice_from("\u043D\u0430\u043F\u0440\u044F\u043C");
                        break;
                    case 52:
                        slice_from("\u0456\u0441\u043B\u0430\u043C");
                        break;
                    case 53:
                        slice_from("\u043C\u0430\u0434\u0430\u043C");
                        break;
                    case 54:
                        slice_from("\u0432\u0456\u043B\u044C\u044F\u043C");
                        break;
                    case 55:
                        slice_from("\u043C\u0430\u043A\u0441\u0438\u043C");
                        break;
                    case 56:
                        slice_from("\u0432\u0430\u0434\u0438\u043C");
                        break;
                    case 57:
                        slice_from("\u0430\u0440\u0442\u0435\u043C");
                        break;
                    case 58:
                        slice_from("\u0454\u0440\u0443\u0441\u0430\u043B\u0438\u043C");
                        break;
                    case 59:
                        slice_from("\u0432'\u0454\u0442\u043D\u0430\u043C");
                        break;
                    case 60:
                        slice_from("\u0430\u043C\u0441\u0442\u0435\u0440\u0434\u0430\u043C");
                        break;
                    case 61:
                        slice_from("\u043E\u0441\u0432\u0456\u0442");
                        break;
                    case 62:
                        slice_from("\u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442");
                        break;
                    case 63:
                        slice_from("\u0432\u0442\u0440\u0430\u0442");
                        break;
                    case 64:
                        slice_from("\u043F\u0430\u043B\u0430\u0442");
                        break;
                    case 65:
                        slice_from("\u0433\u0430\u0440\u043C\u0430\u0442");
                        break;
                    case 66:
                        slice_from("\u0434\u0435\u043F\u0443\u0442\u0430\u0442");
                        break;
                    case 67:
                        slice_from("\u0432\u0438\u0442\u0440\u0430\u0442");
                        break;
                    case 68:
                        slice_from("\u0441\u043E\u043B\u0434\u0430\u0442");
                        break;
                    case 69:
                        slice_from("\u0448\u0442\u0430\u0442");
                        break;
                    case 70:
                        slice_from("\u043E\u0440\u0431\u0456\u0442");
                        break;
                    case 71:
                        slice_from("\u043A\u0456\u043C\u043D\u0430\u0442");
                        break;
                    case 72:
                        slice_from("\u043F\u0440\u043E\u0441\u0432\u0456\u0442");
                        break;
                    case 73:
                        slice_from("\u0441\u0442\u0440\u0430\u0442");
                        break;
                    case 74:
                        slice_from("\u043A\u043E\u043E\u0440\u0434\u0438\u043D\u0430\u0442");
                        break;
                    case 75:
                        slice_from("\u043B\u0430\u0443\u0440\u0435\u0430\u0442");
                        break;
                    case 76:
                        slice_from("\u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442");
                        break;
                    case 77:
                        slice_from("\u0447\u0435\u043C\u043F\u0456\u043E\u043D\u0430\u0442");
                        break;
                    case 78:
                        slice_from("\u043F\u043B\u0438\u0442");
                        break;
                    case 79:
                        slice_from("\u0430\u043F\u0430\u0440\u0430\u0442");
                        break;
                    case 80:
                        slice_from("\u043F\u0440\u0435\u043F\u0430\u0440\u0430\u0442");
                        break;
                    case 81:
                        slice_from("\u0435\u043B\u0456\u0442");
                        break;
                    case 82:
                        slice_from("\u0437\u0432\u0456\u0442");
                        break;
                    case 83:
                        slice_from("\u043E\u043F\u043B\u0430\u0442");
                        break;
                    case 84:
                        slice_from("\u0441\u0432\u0456\u0442");
                        break;
                    case 85:
                        slice_from("\u0441\u043F\u043B\u0430\u0442");
                        break;
                    case 86:
                        slice_from("\u0432\u0438\u043F\u043B\u0430\u0442");
                        break;
                    case 87:
                        slice_from("\u0435\u043A\u0441\u043F\u043E\u043D\u0430\u0442");
                        break;
                    case 88:
                        slice_from("\u0456\u0441\u043F\u0438\u0442");
                        break;
                    case 89:
                        slice_from("\u0446\u0438\u0442\u0430\u0442");
                        break;
                    case 90:
                        slice_from("\u043C\u0430\u0440\u0433\u0430\u0440\u0438\u0442");
                        break;
                    case 91:
                        slice_from("\u0433\u0440\u0430\u043D\u0430\u0442");
                        break;
                    case 92:
                        slice_from("\u043F\u043E\u0432\u0456\u0442");
                        break;
                    case 93:
                        slice_from("\u0437\u0430\u043F\u0438\u0442");
                        break;
                    case 94:
                        slice_from("\u0434\u0435\u043C\u043E\u043A\u0440\u0430\u0442");
                        break;
                    case 95:
                        slice_from("\u0444\u043E\u0440\u043C\u0430\u0442");
                        break;
                    case 96:
                        slice_from("\u0430\u0433\u0440\u0435\u0433\u0430\u0442");
                        break;
                    case 97:
                        slice_from("\u0441\u0442\u0430\u0442\u0442");
                        break;
                    case 98:
                        slice_from("\u0441\u0456\u043C'");
                        break;
                    case 99:
                        slice_from("\u043C\u0443\u0437\u0435");
                        break;
                    case 100:
                        slice_from("\u043B\u0456\u0446\u0435");
                        break;
                    case 101:
                        slice_from("\u0445\u043E\u043A\u0435");
                        break;
                    case 102:
                        slice_from("\u0454\u0432\u0440\u0435");
                        break;
                    case 103:
                        slice_from("\u0456\u0454\u0440\u0435");
                        break;
                    case 104:
                        slice_from("\u043E\u0440\u0444\u0435");
                        break;
                    case 105:
                        slice_from("\u0442\u0430\u0434\u0435");
                        break;
                    case 106:
                        slice_from("\u043C\u0430\u0446\u0435");
                        break;
                    case 107:
                        slice_from("\u043F\u0440\u043E\u043C\u0435\u0442\u0435");
                        break;
                    case 108:
                        slice_from("\u043C\u0430\u0442\u0435");
                        break;
                    case 109:
                        slice_from("\u043F\u0442\u043E\u043B\u0435\u043C\u0435");
                        break;
                    case 110:
                        slice_from("\u0441\u0456\u0434\u043D\u0435");
                        break;
                    case 111:
                        slice_from("\u0434\u0456\u0441\u043D\u0435");
                        break;
                    case 112:
                        slice_from("\u0431\u0440\u0443\u043D\u0435");
                        break;
                    case 113:
                        slice_from("\u0435\u043D\u0435");
                        break;
                    case 114:
                        slice_from("\u0456\u0440\u0438\u043D\u0435");
                        break;
                    case 115:
                        slice_from("\u044E\u0432\u0456\u043B\u0435");
                        break;
                    case 116:
                        slice_from("\u043F\u0440\u0438\u0432\u0456\u043B\u0435");
                        break;
                    case 117:
                        slice_from("\u043A\u043B\u0435");
                        break;
                    case 118:
                        slice_from("\u043C\u0430\u0432\u0437\u043E\u043B\u0435");
                        break;
                    case 119:
                        slice_from("\u0434\u0438\u0441\u043F\u043B\u0435");
                        break;
                    case 120:
                        slice_from("\u0433\u0430\u043B\u0456\u043B\u0435");
                        break;
                    case 121:
                        slice_from("\u0434\u0435\u0441\u044F\u0442");
                        break;
                    case 122:
                        slice_from("\u0441\u0456\u0447\u043D");
                        break;
                    case 123:
                        slice_from("\u0431\u0435\u0440\u0435\u0437\u043D");
                        break;
                    case 124:
                        slice_from("\u043A\u0432\u0456\u0442\u043D");
                        break;
                    case 125:
                        slice_from("\u0442\u0440\u0430\u0432\u043D");
                        break;
                    case 126:
                        slice_from("\u0447\u0435\u0440\u0432\u043D");
                        break;
                    case 127:
                        slice_from("\u043B\u0438\u043F\u043D");
                        break;
                    case 128:
                        slice_from("\u0441\u0435\u0440\u043F\u043D");
                        break;
                    case 129:
                        slice_from("\u0432\u0435\u0440\u0435\u0441\u043D");
                        break;
                    case 130:
                        slice_from("\u0436\u043E\u0432\u0442\u043D");
                        break;
                    case 131:
                        slice_from("\u0433\u0440\u0443\u0434\u043D");
                        break;
                    case 132:
                        slice_from("\u0440\u0456\u0432\u043D");
                        break;
                    case 133:
                        slice_from("\u0443\u0447\u043D");
                        break;
                    case 134:
                        slice_from("\u0441\u0442\u0443\u043F\u0435\u043D");
                        break;
                    case 135:
                        slice_from("\u043F\u0440\u043E\u043C\u0435\u043D");
                        break;
                    case 136:
                        slice_from("\u043A\u0430\u043C\u0435\u043D");
                        break;
                    case 137:
                        slice_from("\u043A\u043E\u0440\u0435\u043D");
                        break;
                    case 138:
                        slice_from("\u043F'\u044F\u0442");
                        break;
                    case 139:
                        slice_from("\u0434\u0435\u0432'\u044F\u0442");
                        break;
                    case 140:
                        slice_from("\u043F\u0440\u043E\u0440\u043E\u043A");
                        break;
                    case 141:
                        slice_from("\u0434\u0456\u0442");
                        break;
                    case 142:
                        slice_from("\u0434\u043D");
                        break;
                    case 143:
                        slice_from("\u0437\u0435\u043C\u043B");
                        break;
                    case 144:
                        slice_from("\u0431\u0443\u0434\u0456\u0432");
                        break;
                    case 145:
                        slice_from("\u0433\u043E\u043B\u043E\u0432");
                        break;
                    case 146:
                        slice_from("\u0454\u0432\u0430\u043D\u0433\u0435\u043B");
                        break;
                    case 147:
                        slice_from("\u043E\u0441\u0435\u043D");
                        break;
                    case 148:
                        slice_from("\u043B\u044C\u0432\u043E\u0432");
                        break;
                    case 149:
                        slice_from("\u0445\u0430\u0440\u043A\u043E\u0432");
                        break;
                    case 150:
                        slice_from("\u0447\u0435\u0440\u043D\u0456\u0433");
                        break;
                    case 151:
                        slice_from("\u043C\u0438\u043A\u043E\u043B\u0430\u0454\u0432");
                        break;
                    case 152:
                        slice_from("\u0442\u0435\u0440\u043D\u043E\u043F\u043E\u043B");
                        break;
                    case 153:
                        slice_from("\u0431\u043E\u0440\u0438\u0441\u043F\u043E\u043B");
                        break;
                    case 154:
                        slice_from("\u0431\u0435\u0440\u0435\u0437\u0430\u043D");
                        break;
                    case 155:
                        slice_from("\u0430\u0441\u0442\u0440\u0430\u0445\u0430\u043D");
                        break;
                    case 156:
                        slice_from("\u0431\u043E\u0442\u043E\u0448\u0430\u043D");
                        break;
                    case 157:
                        slice_from("\u043E\u0441\u0442\u0430\u043D");
                        break;
                    case 158:
                        slice_from("\u043F\u0456\u0432\u0434\u0435\u043D");
                        break;
                    case 159:
                        slice_from("\u0449\u043E\u0434\u0435\u043D");
                        break;
                    case 160:
                        slice_from("\u0441\u0432\u044F\u0449\u0435\u043D");
                        break;
                    case 161:
                        slice_from("\u0434\u0436\u043E\u0432\u0430\u043D");
                        break;
                    case 162:
                        slice_from("\u043B\u043E\u0437\u0430\u043D");
                        break;
                    case 163:
                        slice_from("\u0432\u0456\u0434\u0441\u0442\u0430\u043D");
                        break;
                    case 164:
                        slice_from("\u0442\u0430\u0439\u0432\u0430\u043D");
                        break;
                    case 165:
                        slice_from("\u0433\u0430\u0432\u0430\u043D");
                        break;
                    case 166:
                        slice_from("\u0431\u0440\u0435\u0442\u0430\u043D");
                        break;
                    case 167:
                        slice_from("\u043A\u0443\u0431\u0430\u043D");
                        break;
                    case 168:
                        slice_from("\u043F\u0440\u0438\u0441\u0442\u0430\u043D");
                        break;
                    case 169:
                        slice_from("\u043F\u043E\u0437\u043D\u0430\u043D");
                        break;
                    case 170:
                        slice_from("\u0440\u044F\u0437\u0430\u043D");
                        break;
                    case 171:
                        slice_from("\u044E\u043D\u044C\u043D\u0430\u043D");
                        break;
                    case 172:
                        slice_from("\u0445\u0430\u0439\u043D\u0430\u043D");
                        break;
                    case 173:
                        slice_from("\u0433\u043E\u0440\u0431\u0430\u043D");
                        break;
                    case 174:
                        slice_from("\u0434\u043E\u0432\u0433\u0430\u043D");
                        break;
                    case 175:
                        slice_from("\u043C\u0456\u0448\u0435\u043D");
                        break;
                    case 176:
                        slice_from("\u0434\u043E\u043C\u0435\u043D");
                        break;
                    case 177:
                        slice_from("\u0432\u0456\u0434\u0430\u043D");
                        break;
                    case 178:
                        slice_from("\u043F\u0440\u0438\u0442\u0430\u043C\u0430\u043D");
                        break;
                    case 179:
                        slice_from("\u043D\u0435\u0447\u0438\u0441\u043B\u0435\u043D");
                        break;
                    case 180:
                        slice_from("\u0434\u043E\u0440\u043E\u0433\u043E\u0446\u0456\u043D");
                        break;
                    case 181:
                        slice_from("\u043D\u0435\u0441\u043A\u0456\u043D\u0447\u0435\u043D");
                        break;
                    case 182:
                        slice_from("\u0431\u0430\u0440\u0430\u0431\u0430\u043D");
                        break;
                    case 183:
                        slice_from("\u0444\u043E\u0440\u0442\u0435\u043F\u0456\u0430\u043D");
                        break;
                    case 184:
                        slice_from("\u043F\u043E\u0432\u043D\u043E\u0446\u0456\u043D");
                        break;
                    case 185:
                        slice_from("\u0432\u0456\u043A");
                        break;
                    case 186:
                        slice_from("\u043E\u043A\u0440\u0443\u0433");
                        break;
                    case 187:
                        slice_from("\u043B\u0456\u0433");
                        break;
                    case 188:
                        slice_from("\u0430\u043C\u0435\u0440\u0438\u043A");
                        break;
                    case 189:
                        slice_from("\u0440\u0456\u0447\u043A");
                        break;
                    case 190:
                        slice_from("\u043A\u043D\u0438\u0433");
                        break;
                    case 191:
                        slice_from("\u0430\u0444\u0440\u0438\u043A");
                        break;
                    case 192:
                        slice_from("\u0440\u0435\u0441\u043F\u0443\u0431\u043B\u0456\u043A");
                        break;
                    case 193:
                        slice_from("\u0441\u043C\u0443\u0433");
                        break;
                    case 194:
                        slice_from("\u0431\u0456\u0431\u043B\u0456\u043E\u0442\u0435\u043A");
                        break;
                    case 195:
                        slice_from("\u043F\u0440\u0438\u0441\u044F\u0433");
                        break;
                    case 196:
                        slice_from("\u0434\u043E\u0440\u043E\u0433");
                        break;
                    case 197:
                        slice_from("\u0434\u0456\u043B\u044F\u043D\u043A");
                        break;
                    case 198:
                        slice_from("\u043F\u0440\u0430\u043A\u0442\u0438\u043A");
                        break;
                    case 199:
                        slice_from("\u0444\u0443\u0442\u0431\u043E\u043B\u043A");
                        break;
                    case 200:
                        slice_from("\u0432\u0430\u0433");
                        break;
                    case 201:
                        slice_from("\u0432\u0438\u0441\u0442\u0430\u0432\u043A");
                        break;
                    case 202:
                        slice_from("\u043C\u0435\u043A\u0441\u0438\u043A");
                        break;
                    case 203:
                        slice_from("\u043F\u0440\u0430\u0433");
                        break;
                    case 204:
                        slice_from("\u0440\u043E\u0437\u0440\u043E\u0431\u043A");
                        break;
                    case 205:
                        slice_from("\u0437\u0430\u0442\u043E\u043A");
                        break;
                    case 206:
                        slice_from("\u0442\u043E\u0447\u043A");
                        break;
                    case 207:
                        slice_from("\u043F\u043E\u043B\u0456\u0442\u0438\u043A");
                        break;
                    case 208:
                        slice_from("\u043C\u0443\u0437\u0438\u043A");
                        break;
                    case 209:
                        slice_from("\u0443\u0432\u0430\u0433");
                        break;
                    case 210:
                        slice_from("\u043F\u0456\u0434\u0433\u043E\u0442\u043E\u0432\u043A");
                        break;
                    case 211:
                        slice_from("\u0433\u043E\u043D\u043A");
                        break;
                    case 212:
                        slice_from("\u0442\u0440\u0456\u0439\u043A");
                        break;
                    case 213:
                        slice_from("\u0441\u0442\u043E\u0440\u0456\u043D\u043A");
                        break;
                    case 214:
                        slice_from("\u043D\u0430\u0443\u043A");
                        break;
                    case 215:
                        slice_from("\u043F\u0456\u0434\u0442\u0440\u0438\u043C\u043A");
                        break;
                    case 216:
                        slice_from("\u0442\u0435\u0445\u043D\u0456\u043A");
                        break;
                    case 217:
                        slice_from("\u043D\u0438\u0437\u043A");
                        break;
                    case 218:
                        slice_from("\u043A\u043B\u0430\u0434\u043A");
                        break;
                    case 219:
                        slice_from("\u0435\u043A\u043E\u043D\u043E\u043C\u0456\u043A");
                        break;
                    case 220:
                        slice_from("\u0441\u0442\u0440\u0456\u0447\u043A");
                        break;
                    case 221:
                        slice_from("\u0440\u0443\u043A");
                        break;
                    case 222:
                        slice_from("\u0437\u0431\u0456\u0440\u043A");
                        break;
                    case 223:
                        slice_from("\u0447\u0435\u0440\u0433");
                        break;
                    case 224:
                        slice_from("\u043A\u0440\u0438\u0442\u0438\u043A");
                        break;
                    case 225:
                        slice_from("\u0444\u0430\u0431\u0440\u0438\u043A");
                        break;
                    case 226:
                        slice_from("\u043E\u0431\u043A\u043B\u0430\u0434\u0438\u043D\u043A");
                        break;
                    case 227:
                        slice_from("\u0440\u0438\u0433");
                        break;
                }
                break lab1;
            }
            cursor = v_2;
            int v_4 = cursor;
            lab4: {
                limit_backward = cursor;
                cursor = limit;
                ket = cursor;
                among_var = find_among_b(a_16);
                if (among_var == 0)
                {
                    break lab4;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        slice_from("\u0445\u043E\u0434");
                        break;
                    case 2:
                        slice_from("\u0431\u043E\u0440");
                        break;
                    case 3:
                        slice_from("\u0440\u043E\u0441\u0442");
                        break;
                    case 4:
                        slice_from("\u043D\u043E\u0447");
                        break;
                    case 5:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u0434\u043E\u043C");
                        break;
                    case 6:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u0441\u0442\u043E\u043B");
                        break;
                    case 7:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u043F\u0435\u0447");
                        break;
                    case 8:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u0441\u043E\u043B");
                        break;
                    case 9:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u043A\u043E\u043D");
                        break;
                    case 10:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u0433\u043E\u0441\u0442");
                        break;
                    case 11:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u043F\u043B\u043E\u0434");
                        break;
                    case 12:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u0440\u043E\u0434");
                        break;
                    case 13:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u0431\u043E\u043A");
                        break;
                    case 14:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u043A\u043E\u0442");
                        break;
                    case 15:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u0440\u043E\u0433");
                        break;
                    case 16:
                        if (cursor > limit_backward)
                        {
                            break lab4;
                        }
                        slice_from("\u0441\u043E\u043A");
                        break;
                }
                cursor = limit_backward;
            }
            cursor = v_4;
            B_found_la_noun = false;
            B_found_ty_noun = false;
            int v_5 = cursor;
            lab5: {
                limit_backward = cursor;
                cursor = limit;
                int v_6 = limit - cursor;
                lab6: {
                    if (find_among_b(a_17) == 0)
                    {
                        cursor = limit - v_6;
                        break lab6;
                    }
                }
                lab7: {
                    int v_7 = limit - cursor;
                    lab8: {
                        lab9: {
                            lab10: {
                                if (!(eq_s_b("\u043B\u0430")))
                                {
                                    break lab10;
                                }
                                break lab9;
                            }
                            lab11: {
                                if (!(eq_s_b("\u043B\u0438")))
                                {
                                    break lab11;
                                }
                                break lab9;
                            }
                            if (!(eq_s_b("\u043B\u043E")))
                            {
                                break lab8;
                            }
                        }
                        lab12: {
                            int v_8 = limit - cursor;
                            lab13: {
                                if (!(eq_s_b("\u043E")))
                                {
                                    break lab13;
                                }
                                lab14: {
                                    if (!(eq_s_b("\u0440")))
                                    {
                                        break lab14;
                                    }
                                    break lab13;
                                }
                                break lab12;
                            }
                            cursor = limit - v_8;
                            lab15: {
                                if (!(eq_s_b("\u043B")))
                                {
                                    break lab15;
                                }
                                break lab12;
                            }
                            cursor = limit - v_8;
                            lab16: {
                                if (!(eq_s_b("\u0442")))
                                {
                                    break lab16;
                                }
                                {
                                    int v_9 = limit - cursor;
                                    lab17: {
                                        if (!(eq_s_b("\u0441")))
                                        {
                                            break lab17;
                                        }
                                        if (cursor > limit_backward)
                                        {
                                            break lab17;
                                        }
                                        break lab16;
                                    }
                                    cursor = limit - v_9;
                                }
                                break lab12;
                            }
                            cursor = limit - v_8;
                            lab18: {
                                if (!(eq_s_b("\u0434")))
                                {
                                    break lab18;
                                }
                                break lab12;
                            }
                            cursor = limit - v_8;
                            lab19: {
                                if (!(eq_s_b("\u0432")))
                                {
                                    break lab19;
                                }
                                break lab12;
                            }
                            cursor = limit - v_8;
                            lab20: {
                                if (!(eq_s_b("\u0439")))
                                {
                                    break lab20;
                                }
                                break lab12;
                            }
                            cursor = limit - v_8;
                            lab21: {
                                if (!(eq_s_b("\u0431")))
                                {
                                    break lab21;
                                }
                                break lab12;
                            }
                            cursor = limit - v_8;
                            lab22: {
                                if (!(eq_s_b("\u043F")))
                                {
                                    break lab22;
                                }
                                break lab12;
                            }
                            cursor = limit - v_8;
                            lab23: {
                                if (!(eq_s_b("\u0440")))
                                {
                                    break lab23;
                                }
                                break lab12;
                            }
                            cursor = limit - v_8;
                            if (!(eq_s_b("\u0435")))
                            {
                                break lab8;
                            }
                            lab24: {
                                if (!(eq_s_b("\u0432")))
                                {
                                    break lab24;
                                }
                                break lab8;
                            }
                        }
                        B_found_la_noun = true;
                        break lab7;
                    }
                    cursor = limit - v_7;
                    if (!(eq_s_b("\u0442\u0438")))
                    {
                        break lab5;
                    }
                    lab25: {
                        lab26: {
                            if (!(eq_s_b("\u043D")))
                            {
                                break lab26;
                            }
                            break lab25;
                        }
                        lab27: {
                            if (!(eq_s_b("\u0435")))
                            {
                                break lab27;
                            }
                            break lab25;
                        }
                        lab28: {
                            if (!(eq_s_b("\u043E")))
                            {
                                break lab28;
                            }
                            break lab25;
                        }
                        lab29: {
                            if (!(eq_s_b("\u0456\u0441")))
                            {
                                break lab29;
                            }
                            break lab25;
                        }
                        lab30: {
                            if (!(eq_s_b("\u0438\u0441")))
                            {
                                break lab30;
                            }
                            break lab25;
                        }
                        lab31: {
                            if (!(eq_s_b("\u043A")))
                            {
                                break lab31;
                            }
                            break lab25;
                        }
                        lab32: {
                            if (!(eq_s_b("\u0440")))
                            {
                                break lab32;
                            }
                            break lab25;
                        }
                        lab33: {
                            if (!(eq_s_b("\u0448")))
                            {
                                break lab33;
                            }
                            break lab25;
                        }
                        lab34: {
                            if (!(eq_s_b("\u0444")))
                            {
                                break lab34;
                            }
                            break lab25;
                        }
                        lab35: {
                            if (!(eq_s_b("\u0445")))
                            {
                                break lab35;
                            }
                            break lab25;
                        }
                        lab36: {
                            if (!(eq_s_b("\u043F")))
                            {
                                break lab36;
                            }
                            break lab25;
                        }
                        lab37: {
                            if (!(eq_s_b("\u0431")))
                            {
                                break lab37;
                            }
                            break lab25;
                        }
                        lab38: {
                            if (!(eq_s_b("\u0432")))
                            {
                                break lab38;
                            }
                            break lab25;
                        }
                        lab39: {
                            if (!(eq_s_b("\u043B")))
                            {
                                break lab39;
                            }
                            break lab25;
                        }
                        lab40: {
                            if (!(eq_s_b("\u043C")))
                            {
                                break lab40;
                            }
                            break lab25;
                        }
                        lab41: {
                            if (!(eq_s_b("\u0442")))
                            {
                                break lab41;
                            }
                            break lab25;
                        }
                        lab42: {
                            if (!(eq_s_b("\u044C")))
                            {
                                break lab42;
                            }
                            break lab25;
                        }
                        lab43: {
                            if (!(eq_s_b("\u044E")))
                            {
                                break lab43;
                            }
                            break lab25;
                        }
                        if (!(eq_s_b("\u0454")))
                        {
                            break lab5;
                        }
                    }
                    B_found_ty_noun = true;
                }
                cursor = limit_backward;
            }
            cursor = v_5;
            B_found_diminutive = false;
            B_found_professional = false;
            B_found_ia = false;
            B_found_verb = false;
            I_pV = limit;
            I_p2 = limit;
            int v_10 = cursor;
            lab44: {
                if (!go_out_grouping(g_v, 1072, 1111))
                {
                    break lab44;
                }
                cursor++;
                I_pV = cursor;
                if (!go_in_grouping(g_v, 1072, 1111))
                {
                    break lab44;
                }
                cursor++;
                if (!go_out_grouping(g_v, 1072, 1111))
                {
                    break lab44;
                }
                cursor++;
                if (!go_in_grouping(g_v, 1072, 1111))
                {
                    break lab44;
                }
                cursor++;
                I_p2 = cursor;
            }
            cursor = v_10;
            int v_11 = cursor;
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    return false;
                }
                cursor = c;
            }
            lab45: {
                if (I_pV >= cursor)
                {
                    break lab45;
                }
                I_pV = cursor;
            }
            cursor = v_11;
            limit_backward = cursor;
            cursor = limit;
            if (cursor < I_pV)
            {
                return false;
            }
            int v_12 = limit_backward;
            limit_backward = I_pV;
            int v_13 = limit - cursor;
            lab46: {
                lab47: {
                    int v_14 = limit - cursor;
                    lab48: {
                        ket = cursor;
                        among_var = find_among_b(a_0);
                        if (among_var == 0)
                        {
                            break lab48;
                        }
                        bra = cursor;
                        switch (among_var) {
                            case 1:
                                lab49: {
                                    lab50: {
                                        if (!(eq_s_b("\u0430")))
                                        {
                                            break lab50;
                                        }
                                        break lab49;
                                    }
                                    if (!(eq_s_b("\u044F")))
                                    {
                                        break lab48;
                                    }
                                }
                                slice_del();
                                break;
                            case 2:
                                slice_del();
                                break;
                            case 3:
                                B_found_verb = true;
                                slice_del();
                                break;
                            case 4:
                                B_found_verb = true;
                                slice_from("\u0443\u0432");
                                break;
                            case 5:
                                B_found_verb = true;
                                slice_from("\u044E\u0432");
                                break;
                        }
                        break lab47;
                    }
                    cursor = limit - v_14;
                    lab51: {
                        ket = cursor;
                        among_var = find_among_b(a_1);
                        if (among_var == 0)
                        {
                            break lab51;
                        }
                        bra = cursor;
                        switch (among_var) {
                            case 1:
                                slice_del();
                                break;
                            case 2:
                                slice_from("\u0443\u0432");
                                break;
                            case 3:
                                slice_from("\u044E\u0432");
                                break;
                        }
                        B_found_verb = true;
                        break lab47;
                    }
                    cursor = limit - v_14;
                    int v_15 = limit - cursor;
                    lab52: {
                        ket = cursor;
                        if (find_among_b(a_2) == 0)
                        {
                            cursor = limit - v_15;
                            break lab52;
                        }
                        bra = cursor;
                        slice_del();
                        B_found_verb = true;
                    }
                    lab53: {
                        int v_16 = limit - cursor;
                        lab54: {
                            lab55: {
                                int v_17 = limit - cursor;
                                lab56: {
                                    if (cursor < I_p2)
                                    {
                                        break lab56;
                                    }
                                    int v_18 = limit_backward;
                                    limit_backward = I_p2;
                                    ket = cursor;
                                    if (find_among_b(a_11) == 0)
                                    {
                                        limit_backward = v_18;
                                        break lab56;
                                    }
                                    bra = cursor;
                                    limit_backward = v_18;
                                    B_found_ia = true;
                                    B_found_verb = true;
                                    slice_del();
                                    break lab55;
                                }
                                cursor = limit - v_17;
                                ket = cursor;
                                if (find_among_b(a_12) == 0)
                                {
                                    break lab54;
                                }
                                bra = cursor;
                                B_found_ia = true;
                                B_found_verb = true;
                                slice_del();
                            }
                            break lab53;
                        }
                        cursor = limit - v_16;
                        int v_19 = limit - cursor;
                        lab57: {
                            lab58: {
                                int v_20 = limit - cursor;
                                lab59: {
                                    if (!r_professional())
                                    {
                                        break lab59;
                                    }
                                    B_found_professional = true;
                                    break lab58;
                                }
                                cursor = limit - v_20;
                                ket = cursor;
                                among_var = find_among_b(a_9);
                                if (among_var == 0)
                                {
                                    break lab57;
                                }
                                bra = cursor;
                                switch (among_var) {
                                    case 1:
                                        slice_del();
                                        break;
                                    case 2:
                                        slice_from("\u043A");
                                        break;
                                }
                                B_found_diminutive = true;
                            }
                        }
                        cursor = limit - v_19;
                        if (B_found_professional)
                        {
                            break lab46;
                        }
                        lab60: {
                            int v_21 = limit - cursor;
                            lab61: {
                                lab62: {
                                    int v_22 = limit - cursor;
                                    lab63: {
                                        ket = cursor;
                                        if (find_among_b(a_3) == 0)
                                        {
                                            break lab63;
                                        }
                                        bra = cursor;
                                        if (I_p2 > cursor)
                                        {
                                            break lab63;
                                        }
                                        B_found_ia = true;
                                        slice_del();
                                        break lab62;
                                    }
                                    cursor = limit - v_22;
                                    ket = cursor;
                                    among_var = find_among_b(a_4);
                                    if (among_var == 0)
                                    {
                                        break lab61;
                                    }
                                    bra = cursor;
                                    switch (among_var) {
                                        case 1:
                                            slice_del();
                                            break;
                                        case 2:
                                            lab64: {
                                                lab65: {
                                                    if (!(eq_s_b("\u0436")))
                                                    {
                                                        break lab65;
                                                    }
                                                    break lab64;
                                                }
                                                lab66: {
                                                    if (!(eq_s_b("\u0447")))
                                                    {
                                                        break lab66;
                                                    }
                                                    break lab64;
                                                }
                                                lab67: {
                                                    if (!(eq_s_b("\u0448")))
                                                    {
                                                        break lab67;
                                                    }
                                                    break lab64;
                                                }
                                                if (!(eq_s_b("\u0449")))
                                                {
                                                    break lab61;
                                                }
                                            }
                                            slice_del();
                                            break;
                                    }
                                }
                                break lab60;
                            }
                            cursor = limit - v_21;
                            lab68: {
                                lab69: {
                                    int v_23 = limit - cursor;
                                    lab70: {
                                        ket = cursor;
                                        if (!(eq_s_b("\u043E\u0441\u0442\u0435\u0439")))
                                        {
                                            break lab70;
                                        }
                                        bra = cursor;
                                        if (cursor <= limit_backward)
                                        {
                                            break lab70;
                                        }
                                        slice_del();
                                        break lab69;
                                    }
                                    cursor = limit - v_23;
                                    ket = cursor;
                                    among_var = find_among_b(a_5);
                                    if (among_var == 0)
                                    {
                                        break lab68;
                                    }
                                    bra = cursor;
                                    switch (among_var) {
                                        case 1:
                                            B_found_ia = true;
                                            slice_del();
                                            break;
                                        case 2:
                                            B_found_ia = true;
                                            lab71: {
                                                int v_24 = limit - cursor;
                                                lab72: {
                                                    lab73: {
                                                        lab74: {
                                                            if (cursor > limit_backward)
                                                            {
                                                                break lab74;
                                                            }
                                                            break lab73;
                                                        }
                                                        lab75: {
                                                            if (!(eq_s_b("\u0442")))
                                                            {
                                                                break lab75;
                                                            }
                                                            break lab73;
                                                        }
                                                        lab76: {
                                                            if (!(eq_s_b("\u0447")))
                                                            {
                                                                break lab76;
                                                            }
                                                            break lab73;
                                                        }
                                                        lab77: {
                                                            if (!(eq_s_b("\u0448")))
                                                            {
                                                                break lab77;
                                                            }
                                                            break lab73;
                                                        }
                                                        lab78: {
                                                            if (!(eq_s_b("\u0449")))
                                                            {
                                                                break lab78;
                                                            }
                                                            break lab73;
                                                        }
                                                        lab79: {
                                                            if (!(eq_s_b("\u043C")))
                                                            {
                                                                break lab79;
                                                            }
                                                            break lab73;
                                                        }
                                                        lab80: {
                                                            if (!(eq_s_b("\u043D")))
                                                            {
                                                                break lab80;
                                                            }
                                                            break lab73;
                                                        }
                                                        if (!(eq_s_b("\u043B")))
                                                        {
                                                            break lab72;
                                                        }
                                                    }
                                                    slice_del();
                                                    break lab71;
                                                }
                                                cursor = limit - v_24;
                                                slice_from("\u0435");
                                            }
                                            break;
                                        case 3:
                                            slice_del();
                                            break;
                                        case 4:
                                            lab81: {
                                                if (!(in_grouping_b(g_v, 1072, 1111)))
                                                {
                                                    break lab81;
                                                }
                                                break lab68;
                                            }
                                            B_found_ia = true;
                                            slice_del();
                                            break;
                                        case 5:
                                            {
                                                int v_25 = limit - cursor;
                                                lab82: {
                                                    lab83: {
                                                        lab84: {
                                                            if (!(eq_s_b("\u0441")))
                                                            {
                                                                break lab84;
                                                            }
                                                            break lab83;
                                                        }
                                                        lab85: {
                                                            if (!(eq_s_b("\u0446")))
                                                            {
                                                                break lab85;
                                                            }
                                                            break lab83;
                                                        }
                                                        if (!(eq_s_b("'")))
                                                        {
                                                            break lab82;
                                                        }
                                                    }
                                                    break lab68;
                                                }
                                                cursor = limit - v_25;
                                            }
                                            B_found_ia = true;
                                            slice_del();
                                            break;
                                        case 6:
                                            slice_from("\u0443\u0432");
                                            break;
                                        case 7:
                                            slice_from("\u044E\u0432");
                                            break;
                                        case 8:
                                            lab86: {
                                                if (!(eq_s_b("\u043E")))
                                                {
                                                    break lab86;
                                                }
                                                break lab68;
                                            }
                                            lab87: {
                                                lab88: {
                                                    if (cursor > limit_backward)
                                                    {
                                                        break lab88;
                                                    }
                                                    break lab87;
                                                }
                                                if (!(in_grouping_b(g_v, 1072, 1111)))
                                                {
                                                    break lab68;
                                                }
                                            }
                                            slice_del();
                                            break;
                                        case 9:
                                            {
                                                int v_26 = limit - cursor;
                                                lab89: {
                                                    lab90: {
                                                        lab91: {
                                                            if (!(eq_s_b("\u0441\u0442\u0432")))
                                                            {
                                                                break lab91;
                                                            }
                                                            break lab90;
                                                        }
                                                        if (!(eq_s_b("\u0446\u0442\u0432")))
                                                        {
                                                            break lab89;
                                                        }
                                                    }
                                                    break lab68;
                                                }
                                                cursor = limit - v_26;
                                            }
                                            slice_del();
                                            break;
                                        case 10:
                                            if (B_found_la_noun)
                                            {
                                                break lab68;
                                            }
                                            slice_del();
                                            break;
                                        case 11:
                                            lab92: {
                                                if (!(eq_s_b("\u0456\u0441\u0442")))
                                                {
                                                    break lab92;
                                                }
                                                break lab68;
                                            }
                                            slice_del();
                                            break;
                                        case 12:
                                            if (B_found_ty_noun)
                                            {
                                                break lab68;
                                            }
                                            slice_del();
                                            break;
                                    }
                                }
                                B_found_verb = true;
                                break lab60;
                            }
                            cursor = limit - v_21;
                            lab93: {
                                int v_27 = limit - cursor;
                                lab94: {
                                    ket = cursor;
                                    if (find_among_b(a_6) == 0)
                                    {
                                        break lab94;
                                    }
                                    bra = cursor;
                                    if (cursor <= limit_backward)
                                    {
                                        break lab94;
                                    }
                                    slice_del();
                                    break lab93;
                                }
                                cursor = limit - v_27;
                                ket = cursor;
                                among_var = find_among_b(a_7);
                                if (among_var == 0)
                                {
                                    break lab46;
                                }
                                bra = cursor;
                                switch (among_var) {
                                    case 1:
                                        slice_from("\u0456\u0441\u0442\u044C");
                                        break;
                                    case 2:
                                        slice_from("\u0446");
                                        break;
                                    case 3:
                                        slice_del();
                                        break;
                                }
                            }
                        }
                    }
                }
            }
            cursor = limit - v_13;
            int v_28 = limit - cursor;
            lab95: {
                ket = cursor;
                if (find_among_b(a_10) == 0)
                {
                    cursor = limit - v_28;
                    break lab95;
                }
                bra = cursor;
                slice_del();
                B_found_diminutive = true;
            }
            int v_29 = limit - cursor;
            lab96: {
                if (B_found_diminutive)
                {
                    break lab96;
                }
                if (B_found_professional)
                {
                    break lab96;
                }
                if (B_found_ia)
                {
                    break lab96;
                }
                if (!r_professional())
                {
                    break lab96;
                }
            }
            cursor = limit - v_29;
            int v_30 = limit - cursor;
            lab97: {
                if (B_found_verb)
                {
                    break lab97;
                }
                ket = cursor;
                if (!(eq_s_b("\u0456\u0448")))
                {
                    break lab97;
                }
                bra = cursor;
                slice_del();
            }
            cursor = limit - v_30;
            int v_31 = limit - cursor;
            lab98: {
                if (cursor < I_p2)
                {
                    break lab98;
                }
                int v_32 = limit_backward;
                limit_backward = I_p2;
                ket = cursor;
                among_var = find_among_b(a_13);
                if (among_var == 0)
                {
                    limit_backward = v_32;
                    break lab98;
                }
                bra = cursor;
                limit_backward = v_32;
                switch (among_var) {
                    case 1:
                        slice_del();
                        break;
                    case 2:
                        lab99: {
                            int v_33 = limit - cursor;
                            lab100: {
                                if (!(eq_s_b("\u0432")))
                                {
                                    break lab100;
                                }
                                slice_del();
                                break lab99;
                            }
                            cursor = limit - v_33;
                            slice_from("\u0435\u043B");
                        }
                        break;
                    case 3:
                        lab101: {
                            int v_34 = limit - cursor;
                            lab102: {
                                lab103: {
                                    lab104: {
                                        if (!(eq_s_b("\u0443\u0432")))
                                        {
                                            break lab104;
                                        }
                                        break lab103;
                                    }
                                    if (!(eq_s_b("\u044E\u0432")))
                                    {
                                        break lab102;
                                    }
                                }
                                slice_del();
                                break lab101;
                            }
                            cursor = limit - v_34;
                            slice_from("\u0430\u043B");
                        }
                        break;
                    case 4:
                        lab105: {
                            lab106: {
                                if (!(eq_s_b("\u0443\u0432")))
                                {
                                    break lab106;
                                }
                                break lab105;
                            }
                            if (!(eq_s_b("\u044E\u0432")))
                            {
                                break lab98;
                            }
                        }
                        slice_del();
                        break;
                }
            }
            cursor = limit - v_31;
            int v_35 = limit - cursor;
            lab107: {
                ket = cursor;
                among_var = find_among_b(a_14);
                if (among_var == 0)
                {
                    break lab107;
                }
                bra = cursor;
                switch (among_var) {
                    case 1:
                        if (B_found_verb)
                        {
                            break lab107;
                        }
                        slice_del();
                        ket = cursor;
                        if (!(eq_s_b("\u043D")))
                        {
                            break lab107;
                        }
                        bra = cursor;
                        if (!(eq_s_b("\u043D")))
                        {
                            break lab107;
                        }
                        slice_del();
                        break;
                    case 2:
                        lab108: {
                            lab109: {
                                if (!(eq_s_b("\u0431")))
                                {
                                    break lab109;
                                }
                                break lab108;
                            }
                            lab110: {
                                if (!(eq_s_b("\u043F")))
                                {
                                    break lab110;
                                }
                                break lab108;
                            }
                            lab111: {
                                if (!(eq_s_b("\u0432")))
                                {
                                    break lab111;
                                }
                                break lab108;
                            }
                            if (!(eq_s_b("\u043C")))
                            {
                                break lab107;
                            }
                        }
                        slice_del();
                        break;
                    case 3:
                        if (!(eq_s_b("\u043D")))
                        {
                            break lab107;
                        }
                        slice_del();
                        break;
                    case 4:
                        slice_del();
                        break;
                }
            }
            cursor = limit - v_35;
            limit_backward = v_12;
            cursor = limit_backward;
        }
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof ukrainianStemmer;
    }

    @Override
    public int hashCode() {
        return ukrainianStemmer.class.getName().hashCode();
    }

}
