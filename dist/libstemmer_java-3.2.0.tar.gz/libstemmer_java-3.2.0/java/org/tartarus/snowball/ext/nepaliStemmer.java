// Generated from nepali.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from nepali.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class nepaliStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("\u0932\u093E\u0907", -1, 1),
        new Among("\u0932\u093E\u0908", -1, 1),
        new Among("\u0938\u0901\u0917", -1, 1),
        new Among("\u0938\u0902\u0917", -1, 1),
        new Among("\u092E\u093E\u0930\u094D\u092B\u0924", -1, 1),
        new Among("\u0930\u0924", -1, 1),
        new Among("\u0915\u093E", -1, 2),
        new Among("\u092E\u093E", -1, 1),
        new Among("\u0926\u094D\u0935\u093E\u0930\u093E", -1, 1),
        new Among("\u0915\u093F", -1, 2),
        new Among("\u092A\u091B\u093F", -1, 1),
        new Among("\u0915\u0940", -1, 2),
        new Among("\u0932\u0947", -1, 1),
        new Among("\u0915\u0948", -1, 2),
        new Among("\u0938\u0901\u0917\u0948", -1, 1),
        new Among("\u092E\u0948", -1, 1),
        new Among("\u0915\u094B", -1, 2)
    };

    private final static Among[] a_1 = {
        new Among("\u0901", -1, 1),
        new Among("\u0902", -1, 1),
        new Among("\u0948", -1, 2)
    };

    private final static Among[] a_2 = {
        new Among("\u0925\u093F\u090F", -1, 1),
        new Among("\u091B", -1, 1),
        new Among("\u0907\u091B", 1, 1),
        new Among("\u090F\u091B", 1, 1),
        new Among("\u093F\u091B", 1, 1),
        new Among("\u0947\u091B", 1, 1),
        new Among("\u0928\u0947\u091B", 5, 1),
        new Among("\u0939\u0941\u0928\u0947\u091B", 6, 1),
        new Among("\u0907\u0928\u094D\u091B", 1, 1),
        new Among("\u093F\u0928\u094D\u091B", 1, 1),
        new Among("\u0939\u0941\u0928\u094D\u091B", 1, 1),
        new Among("\u090F\u0915\u093E", -1, 1),
        new Among("\u0907\u090F\u0915\u093E", 11, 1),
        new Among("\u093F\u090F\u0915\u093E", 11, 1),
        new Among("\u0947\u0915\u093E", -1, 1),
        new Among("\u0928\u0947\u0915\u093E", 14, 1),
        new Among("\u0926\u093E", -1, 1),
        new Among("\u0907\u0926\u093E", 16, 1),
        new Among("\u093F\u0926\u093E", 16, 1),
        new Among("\u0926\u0947\u0916\u093F", -1, 1),
        new Among("\u092E\u093E\u0925\u093F", -1, 1),
        new Among("\u090F\u0915\u0940", -1, 1),
        new Among("\u0907\u090F\u0915\u0940", 21, 1),
        new Among("\u093F\u090F\u0915\u0940", 21, 1),
        new Among("\u0947\u0915\u0940", -1, 1),
        new Among("\u0926\u0947\u0916\u0940", -1, 1),
        new Among("\u0925\u0940", -1, 1),
        new Among("\u0926\u0940", -1, 1),
        new Among("\u091B\u0941", -1, 1),
        new Among("\u090F\u091B\u0941", 28, 1),
        new Among("\u0947\u091B\u0941", 28, 1),
        new Among("\u0928\u0947\u091B\u0941", 30, 1),
        new Among("\u0928\u0941", -1, 1),
        new Among("\u0939\u0930\u0941", -1, 1),
        new Among("\u0939\u0930\u0942", -1, 1),
        new Among("\u091B\u0947", -1, 1),
        new Among("\u0925\u0947", -1, 1),
        new Among("\u0928\u0947", -1, 1),
        new Among("\u090F\u0915\u0948", -1, 1),
        new Among("\u0947\u0915\u0948", -1, 1),
        new Among("\u0928\u0947\u0915\u0948", 39, 1),
        new Among("\u0926\u0948", -1, 1),
        new Among("\u0907\u0926\u0948", 41, 1),
        new Among("\u093F\u0926\u0948", 41, 1),
        new Among("\u090F\u0915\u094B", -1, 1),
        new Among("\u0907\u090F\u0915\u094B", 44, 1),
        new Among("\u093F\u090F\u0915\u094B", 44, 1),
        new Among("\u0947\u0915\u094B", -1, 1),
        new Among("\u0928\u0947\u0915\u094B", 47, 1),
        new Among("\u0926\u094B", -1, 1),
        new Among("\u0907\u0926\u094B", 49, 1),
        new Among("\u093F\u0926\u094B", 49, 1),
        new Among("\u092F\u094B", -1, 1),
        new Among("\u0907\u092F\u094B", 52, 1),
        new Among("\u092D\u092F\u094B", 52, 1),
        new Among("\u093F\u092F\u094B", 52, 1),
        new Among("\u0925\u093F\u092F\u094B", 55, 1),
        new Among("\u0926\u093F\u092F\u094B", 55, 1),
        new Among("\u0925\u094D\u092F\u094B", 52, 1),
        new Among("\u091B\u094C", -1, 1),
        new Among("\u0907\u091B\u094C", 59, 1),
        new Among("\u090F\u091B\u094C", 59, 1),
        new Among("\u093F\u091B\u094C", 59, 1),
        new Among("\u0947\u091B\u094C", 59, 1),
        new Among("\u0928\u0947\u091B\u094C", 63, 1),
        new Among("\u092F\u094C", -1, 1),
        new Among("\u0925\u093F\u092F\u094C", 65, 1),
        new Among("\u091B\u094D\u092F\u094C", 65, 1),
        new Among("\u0925\u094D\u092F\u094C", 65, 1),
        new Among("\u091B\u0928\u094D", -1, 1),
        new Among("\u0907\u091B\u0928\u094D", 69, 1),
        new Among("\u090F\u091B\u0928\u094D", 69, 1),
        new Among("\u093F\u091B\u0928\u094D", 69, 1),
        new Among("\u0947\u091B\u0928\u094D", 69, 1),
        new Among("\u0928\u0947\u091B\u0928\u094D", 73, 1),
        new Among("\u0932\u093E\u0928\u094D", -1, 1),
        new Among("\u091B\u093F\u0928\u094D", -1, 1),
        new Among("\u0925\u093F\u0928\u094D", -1, 1),
        new Among("\u092A\u0930\u094D", -1, 1),
        new Among("\u0907\u0938\u094D", -1, 1),
        new Among("\u0925\u093F\u0907\u0938\u094D", 79, 1),
        new Among("\u091B\u0938\u094D", -1, 1),
        new Among("\u0907\u091B\u0938\u094D", 81, 1),
        new Among("\u090F\u091B\u0938\u094D", 81, 1),
        new Among("\u093F\u091B\u0938\u094D", 81, 1),
        new Among("\u0947\u091B\u0938\u094D", 81, 1),
        new Among("\u0928\u0947\u091B\u0938\u094D", 85, 1),
        new Among("\u093F\u0938\u094D", -1, 1),
        new Among("\u0925\u093F\u0938\u094D", 87, 1),
        new Among("\u091B\u0947\u0938\u094D", -1, 1),
        new Among("\u0939\u094B\u0938\u094D", -1, 1)
    };


    @Override
    public boolean stem() {
        int among_var;
        limit_backward = cursor;
        cursor = limit;
        int v_1 = limit - cursor;
        lab0: {
            ket = cursor;
            among_var = find_among_b(a_0);
            if (among_var == 0)
            {
                break lab0;
            }
            bra = cursor;
            switch (among_var) {
                case 1:
                    slice_del();
                    break;
                case 2:
                    lab1: {
                        lab2: {
                            if (!(eq_s_b("\u090F")))
                            {
                                break lab2;
                            }
                            break lab1;
                        }
                        lab3: {
                            if (!(eq_s_b("\u0947")))
                            {
                                break lab3;
                            }
                            break lab1;
                        }
                        slice_del();
                    }
                    break;
            }
        }
        cursor = limit - v_1;
        while (true)
        {
            int v_2 = limit - cursor;
            lab4: {
                int v_3 = limit - cursor;
                lab5: {
                    ket = cursor;
                    among_var = find_among_b(a_1);
                    if (among_var == 0)
                    {
                        break lab5;
                    }
                    bra = cursor;
                    switch (among_var) {
                        case 1:
                            lab6: {
                                lab7: {
                                    if (!(eq_s_b("\u092F\u094C")))
                                    {
                                        break lab7;
                                    }
                                    break lab6;
                                }
                                lab8: {
                                    if (!(eq_s_b("\u091B\u094C")))
                                    {
                                        break lab8;
                                    }
                                    break lab6;
                                }
                                lab9: {
                                    if (!(eq_s_b("\u0928\u094C")))
                                    {
                                        break lab9;
                                    }
                                    break lab6;
                                }
                                if (!(eq_s_b("\u0925\u0947")))
                                {
                                    break lab5;
                                }
                            }
                            slice_del();
                            break;
                        case 2:
                            if (!(eq_s_b("\u0924\u094D\u0930")))
                            {
                                break lab5;
                            }
                            slice_del();
                            break;
                    }
                }
                cursor = limit - v_3;
                ket = cursor;
                if (find_among_b(a_2) == 0)
                {
                    break lab4;
                }
                bra = cursor;
                slice_del();
                continue;
            }
            cursor = limit - v_2;
            break;
        }
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof nepaliStemmer;
    }

    @Override
    public int hashCode() {
        return nepaliStemmer.class.getName().hashCode();
    }

}
