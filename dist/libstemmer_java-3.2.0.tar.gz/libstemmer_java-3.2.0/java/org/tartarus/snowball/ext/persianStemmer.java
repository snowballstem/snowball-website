// Generated from persian.sbl by Snowball 3.2.0 - https://snowballstem.org/

package org.tartarus.snowball.ext;

import org.tartarus.snowball.Among;

/**
 * This class implements the stemming algorithm defined by a snowball script.
 * <p>
 * Generated from persian.sbl by Snowball 3.2.0 - https://snowballstem.org/
 * </p>
 */
@SuppressWarnings("unused")
public class persianStemmer extends org.tartarus.snowball.SnowballStemmer {

    private final static Among[] a_0 = {
        new Among("", -1, 7),
        new Among(" ", 0, 6),
        new Among("\u0623", 0, 4),
        new Among("\u0624", 0, 5),
        new Among("\u0625", 0, 4),
        new Among("\u0626", 0, 2),
        new Among("\u0629", 0, 3),
        new Among("\u0643", 0, 1),
        new Among("\u064A", 0, 2),
        new Among("\u06C1", 0, 3),
        new Among("\u200D", 0, 6)
    };

    private final static Among[] a_1 = {
        new Among("\u0645\u06CC\u200C", -1, 2),
        new Among("\u0646\u0645\u06CC\u200C", -1, 1)
    };

    private final static Among[] a_2 = {
        new Among("\u0633\u062A\u0627\u0646", -1, -1),
        new Among("\u0631\u0627\u0646", -1, -1),
        new Among("\u0633\u0627\u0646", -1, -1),
        new Among("\u0648\u0627\u0646", -1, -1)
    };

    private final static Among[] a_3 = {
        new Among("\u0622\u0630\u0631\u0628\u0627\u06CC\u062C\u0627\u0646", -1, 1),
        new Among("\u0647\u0645\u062F\u0627\u0646", -1, 1),
        new Among("\u062E\u0627\u0646\u062F\u0627\u0646", -1, 1),
        new Among("\u0632\u0646\u062F\u0627\u0646", -1, 1),
        new Among("\u0645\u06CC\u0632\u0627\u0646", -1, 1),
        new Among("\u062F\u0631\u062E\u0634\u0627\u0646", -1, 1),
        new Among("\u0622\u062A\u0634\u0641\u0634\u0627\u0646", -1, 1),
        new Among("\u0646\u0634\u0627\u0646", -1, 1),
        new Among("\u06A9\u0647\u06A9\u0634\u0627\u0646", -1, 1),
        new Among("\u0627\u06CC\u0634\u0627\u0646", -1, 1),
        new Among("\u067E\u0631\u06CC\u0634\u0627\u0646", -1, 1),
        new Among("\u0633\u0644\u0637\u0627\u0646", -1, 1),
        new Among("\u06AF\u06CC\u0644\u0627\u0646", -1, 1),
        new Among("\u0633\u0627\u062E\u062A\u0645\u0627\u0646", -1, 1),
        new Among("\u0631\u0645\u0627\u0646", -1, 1),
        new Among("\u062F\u0631\u0645\u0627\u0646", 14, 1),
        new Among("\u0642\u0647\u0631\u0645\u0627\u0646", 14, 1),
        new Among("\u06A9\u0631\u0645\u0627\u0646", 14, 1),
        new Among("\u0633\u0627\u0632\u0645\u0627\u0646", -1, 1),
        new Among("\u0647\u0645\u0632\u0645\u0627\u0646", -1, 1),
        new Among("\u0622\u0633\u0645\u0627\u0646", -1, 1),
        new Among("\u0622\u0644\u0645\u0627\u0646", -1, 1),
        new Among("\u0645\u0633\u0644\u0645\u0627\u0646", -1, 1),
        new Among("\u0627\u06CC\u0645\u0627\u0646", -1, 1),
        new Among("\u0633\u0644\u06CC\u0645\u0627\u0646", -1, 1),
        new Among("\u067E\u06CC\u0645\u0627\u0646", -1, 1),
        new Among("\u0644\u0628\u0646\u0627\u0646", -1, 1),
        new Among("\u06CC\u0648\u0646\u0627\u0646", -1, 1),
        new Among("\u0627\u0635\u0641\u0647\u0627\u0646", -1, 1),
        new Among("\u0627\u0645\u06A9\u0627\u0646", -1, 1),
        new Among("\u067E\u0627\u06CC\u0627\u0646", -1, 1),
        new Among("\u0628\u06CC\u0627\u0646", -1, 1),
        new Among("\u062C\u0631\u06CC\u0627\u0646", -1, 1)
    };

    private final static Among[] a_4 = {
        new Among("\u0627\u0633\u0627\u062A\u06CC\u062F", -1, 2),
        new Among("\u0627\u062E\u0628\u0627\u0631", -1, 1)
    };

    private final static Among[] a_5 = {
        new Among("\u0647\u0627", -1, 1),
        new Among("\u0627\u062A", -1, 1),
        new Among("\u06CC\u062A", -1, 1),
        new Among("\u0645\u0646\u062F", -1, 1),
        new Among("\u0648\u0627\u0631", -1, 1),
        new Among("\u06AF\u0627\u0631", -1, 1),
        new Among("\u062A\u0631", -1, 2),
        new Among("\u0627\u0634", -1, 1),
        new Among("\u0627\u0645", -1, 1),
        new Among("\u0627\u0646", -1, 1),
        new Among("\u0628\u0627\u0646", 9, 1),
        new Among("\u06AF\u0627\u0646", 9, 1),
        new Among("\u06CC\u0627\u0646", 9, 1),
        new Among("\u06CC\u0646", -1, 1),
        new Among("\u062A\u0631\u06CC\u0646", 13, 1),
        new Among("\u06AF\u0627\u0647", -1, 1),
        new Among("\u0627\u0646\u0647", -1, 1),
        new Among("\u0646\u0627\u06A9", -1, 1),
        new Among("\u0647\u0627\u06CC", -1, 1),
        new Among("\u0627\u0646\u06CC", -1, 1),
        new Among("\u06AF\u06CC", -1, 1),
        new Among("\u06CC\u06CC", -1, 1)
    };

    private final static Among[] a_6 = {
        new Among("\u0627\u0633\u062A", -1, 1),
        new Among("\u0627\u0646\u062F", -1, 1),
        new Among("\u06CC\u062F", -1, 1),
        new Among("\u0627\u06CC\u062F", 2, 1),
        new Among("\u0627\u0633", -1, 1),
        new Among("\u06CC\u0645", -1, 1),
        new Among("\u0627\u06CC\u0645", 5, 1),
        new Among("\u0627\u06CC", -1, 1)
    };

    private final static Among[] a_7 = {
        new Among("\u062F", -1, 1),
        new Among("\u0627\u0646\u062F", 0, 1),
        new Among("\u0631\u0641\u062A\u0627\u0646\u062F", 1, 2),
        new Among("\u06CC\u062F", 0, 1),
        new Among("\u0631\u0641\u062A\u06CC\u062F", 3, 2),
        new Among("\u0645", -1, 1),
        new Among("\u0627\u0645", 5, 1),
        new Among("\u0631\u0641\u062A\u0645", 5, 2),
        new Among("\u06CC\u0645", 5, 1),
        new Among("\u0631\u0641\u062A\u06CC\u0645", 8, 2),
        new Among("\u0627\u0646", -1, 3),
        new Among("\u062A\u0647", -1, 5),
        new Among("\u062F\u0647", -1, 4),
        new Among("\u0646\u062F\u0647", 12, 3),
        new Among("\u0631\u0641\u062A\u06CC", -1, 2)
    };


    @Override
    public boolean stem() {
        int among_var;
        int I_p1;
        boolean B_remove_verb_person_endings;
        boolean B_saw_present_prefix;
        B_saw_present_prefix = false;
        int v_1 = cursor;
        lab0: {
            while (true)
            {
                int v_2 = cursor;
                lab1: {
                    bra = cursor;
                    among_var = find_among(a_0);
                    ket = cursor;
                    switch (among_var) {
                        case 1:
                            slice_from("\u06A9");
                            break;
                        case 2:
                            slice_from("\u06CC");
                            break;
                        case 3:
                            slice_from("\u0647");
                            break;
                        case 4:
                            slice_from("\u0627");
                            break;
                        case 5:
                            slice_from("\u0648");
                            break;
                        case 6:
                            slice_del();
                            break;
                        case 7:
                            if (cursor >= limit)
                            {
                                break lab1;
                            }
                            cursor++;
                            break;
                    }
                    continue;
                }
                cursor = v_2;
                break;
            }
        }
        cursor = v_1;
        int v_3 = cursor;
        lab2: {
            bra = cursor;
            among_var = find_among(a_1);
            if (among_var == 0)
            {
                break lab2;
            }
            ket = cursor;
            switch (among_var) {
                case 1:
                    {
                        int c = cursor + 2;
                        if (c > limit)
                        {
                            break lab2;
                        }
                        cursor = c;
                    }
                    B_saw_present_prefix = true;
                    break;
                case 2:
                    {
                        int c = cursor + 2;
                        if (c > limit)
                        {
                            break lab2;
                        }
                        cursor = c;
                    }
                    slice_del();
                    B_saw_present_prefix = true;
                    break;
            }
        }
        cursor = v_3;
        int v_4 = cursor;
        lab3: {
            while (true)
            {
                int v_5 = cursor;
                lab4: {
                    golab5: while (true)
                    {
                        int v_6 = cursor;
                        lab6: {
                            bra = cursor;
                            if (!(eq_s("\u200C")))
                            {
                                break lab6;
                            }
                            ket = cursor;
                            slice_del();
                            cursor = v_6;
                            break golab5;
                        }
                        cursor = v_6;
                        if (cursor >= limit)
                        {
                            break lab4;
                        }
                        cursor++;
                    }
                    continue;
                }
                cursor = v_5;
                break;
            }
        }
        cursor = v_4;
        I_p1 = limit;
        int v_7 = cursor;
        lab7: {
            {
                int c = cursor + 3;
                if (c > limit)
                {
                    break lab7;
                }
                cursor = c;
            }
            I_p1 = cursor;
        }
        cursor = v_7;
        limit_backward = cursor;
        cursor = limit;
        while (true)
        {
            int v_8 = limit - cursor;
            lab8: {
                int v_9 = limit - cursor;
                B_remove_verb_person_endings = false;
                lab9: {
                    if (!B_saw_present_prefix)
                    {
                        break lab9;
                    }
                    B_remove_verb_person_endings = true;
                }
                {
                    int v_10 = limit - cursor;
                    lab10: {
                        if (find_among_b(a_3) == 0)
                        {
                            break lab10;
                        }
                        if (cursor > limit_backward)
                        {
                            break lab10;
                        }
                        break lab8;
                    }
                    cursor = limit - v_10;
                }
                {
                    int v_11 = limit - cursor;
                    lab11: {
                        if (find_among_b(a_2) == 0)
                        {
                            break lab11;
                        }
                        break lab8;
                    }
                    cursor = limit - v_11;
                }
                lab12: {
                    int v_12 = limit - cursor;
                    lab13: {
                        lab14: {
                            int v_13 = limit - cursor;
                            lab15: {
                                ket = cursor;
                                among_var = find_among_b(a_4);
                                if (among_var == 0)
                                {
                                    break lab15;
                                }
                                bra = cursor;
                                switch (among_var) {
                                    case 1:
                                        slice_from("\u062E\u0628\u0631");
                                        break;
                                    case 2:
                                        slice_from("\u0627\u0633\u062A\u0627\u062F");
                                        break;
                                }
                                break lab14;
                            }
                            cursor = limit - v_13;
                            if (cursor < I_p1)
                            {
                                break lab13;
                            }
                            int v_14 = limit_backward;
                            limit_backward = I_p1;
                            ket = cursor;
                            among_var = find_among_b(a_5);
                            if (among_var == 0)
                            {
                                limit_backward = v_14;
                                break lab13;
                            }
                            bra = cursor;
                            switch (among_var) {
                                case 1:
                                    slice_del();
                                    break;
                                case 2:
                                    if (cursor <= limit_backward)
                                    {
                                        limit_backward = v_14;
                                        break lab13;
                                    }
                                    slice_del();
                                    break;
                            }
                            limit_backward = v_14;
                        }
                        break lab12;
                    }
                    cursor = limit - v_12;
                    lab16: {
                        int v_15 = limit - cursor;
                        lab17: {
                            ket = cursor;
                            if (find_among_b(a_6) == 0)
                            {
                                break lab17;
                            }
                            bra = cursor;
                            if (I_p1 > cursor)
                            {
                                break lab17;
                            }
                            slice_del();
                            break lab16;
                        }
                        cursor = limit - v_15;
                        ket = cursor;
                        among_var = find_among_b(a_7);
                        if (among_var == 0)
                        {
                            break lab8;
                        }
                        bra = cursor;
                        switch (among_var) {
                            case 1:
                                if (!B_remove_verb_person_endings)
                                {
                                    break lab8;
                                }
                                if (I_p1 > cursor)
                                {
                                    break lab8;
                                }
                                slice_del();
                                break;
                            case 2:
                                slice_from("\u0631\u0641\u062A");
                                break;
                            case 3:
                                if (I_p1 > cursor)
                                {
                                    break lab8;
                                }
                                slice_del();
                                B_remove_verb_person_endings = true;
                                break;
                            case 4:
                                if (cursor <= limit_backward)
                                {
                                    break lab8;
                                }
                                slice_from("\u062F");
                                B_remove_verb_person_endings = true;
                                break;
                            case 5:
                                if (cursor <= limit_backward)
                                {
                                    break lab8;
                                }
                                slice_from("\u062A");
                                B_remove_verb_person_endings = true;
                                break;
                        }
                    }
                }
                cursor = limit - v_9;
                continue;
            }
            cursor = limit - v_8;
            break;
        }
        cursor = limit_backward;
        return true;
    }

    @Override
    public boolean equals( Object o ) {
        return o instanceof persianStemmer;
    }

    @Override
    public int hashCode() {
        return persianStemmer.class.getName().hashCode();
    }

}
