<?php
// Generated from persian.sbl by Snowball 3.1.0 - https://snowballstem.org/

class SnowballPersianStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["", -1, 7],
        [" ", 0, 6],
        ["\u{0623}", 0, 4],
        ["\u{0624}", 0, 5],
        ["\u{0625}", 0, 4],
        ["\u{0626}", 0, 2],
        ["\u{0629}", 0, 3],
        ["\u{0643}", 0, 1],
        ["\u{064A}", 0, 2],
        ["\u{06C1}", 0, 3],
        ["\u{200D}", 0, 6]
    ];

    private const array A_1 = [
        ["\u{0645}\u{06CC}\u{200C}", -1, 2],
        ["\u{0646}\u{0645}\u{06CC}\u{200C}", -1, 1]
    ];

    private const array A_2 = [
        ["\u{0648}\u{0627}\u{0646}", -1, -1],
        ["\u{0633}\u{062A}\u{0627}\u{0646}", -1, -1],
        ["\u{0631}\u{0627}\u{0646}", -1, -1],
        ["\u{0633}\u{0627}\u{0646}", -1, -1]
    ];

    private const array A_3 = [
        ["\u{06AF}\u{06CC}\u{0644}\u{0627}\u{0646}", -1, 1],
        ["\u{0622}\u{0644}\u{0645}\u{0627}\u{0646}", -1, 1],
        ["\u{0645}\u{0633}\u{0644}\u{0645}\u{0627}\u{0646}", -1, 1],
        ["\u{0633}\u{0644}\u{06CC}\u{0645}\u{0627}\u{0646}", -1, 1],
        ["\u{0627}\u{06CC}\u{0645}\u{0627}\u{0646}", -1, 1],
        ["\u{067E}\u{06CC}\u{0645}\u{0627}\u{0646}", -1, 1],
        ["\u{0633}\u{0627}\u{062E}\u{062A}\u{0645}\u{0627}\u{0646}", -1, 1],
        ["\u{0631}\u{0645}\u{0627}\u{0646}", -1, 1],
        ["\u{0642}\u{0647}\u{0631}\u{0645}\u{0627}\u{0646}", 7, 1],
        ["\u{06A9}\u{0631}\u{0645}\u{0627}\u{0646}", 7, 1],
        ["\u{062F}\u{0631}\u{0645}\u{0627}\u{0646}", 7, 1],
        ["\u{0647}\u{0645}\u{0632}\u{0645}\u{0627}\u{0646}", -1, 1],
        ["\u{0633}\u{0627}\u{0632}\u{0645}\u{0627}\u{0646}", -1, 1],
        ["\u{0622}\u{0633}\u{0645}\u{0627}\u{0646}", -1, 1],
        ["\u{06CC}\u{0648}\u{0646}\u{0627}\u{0646}", -1, 1],
        ["\u{0644}\u{0628}\u{0646}\u{0627}\u{0646}", -1, 1],
        ["\u{0627}\u{0635}\u{0641}\u{0647}\u{0627}\u{0646}", -1, 1],
        ["\u{067E}\u{0627}\u{06CC}\u{0627}\u{0646}", -1, 1],
        ["\u{0628}\u{06CC}\u{0627}\u{0646}", -1, 1],
        ["\u{062C}\u{0631}\u{06CC}\u{0627}\u{0646}", -1, 1],
        ["\u{0627}\u{0645}\u{06A9}\u{0627}\u{0646}", -1, 1],
        ["\u{0622}\u{0630}\u{0631}\u{0628}\u{0627}\u{06CC}\u{062C}\u{0627}\u{0646}", -1, 1],
        ["\u{0647}\u{0645}\u{062F}\u{0627}\u{0646}", -1, 1],
        ["\u{062E}\u{0627}\u{0646}\u{062F}\u{0627}\u{0646}", -1, 1],
        ["\u{0632}\u{0646}\u{062F}\u{0627}\u{0646}", -1, 1],
        ["\u{0645}\u{06CC}\u{0632}\u{0627}\u{0646}", -1, 1],
        ["\u{0622}\u{062A}\u{0634}\u{0641}\u{0634}\u{0627}\u{0646}", -1, 1],
        ["\u{0646}\u{0634}\u{0627}\u{0646}", -1, 1],
        ["\u{0627}\u{06CC}\u{0634}\u{0627}\u{0646}", -1, 1],
        ["\u{067E}\u{0631}\u{06CC}\u{0634}\u{0627}\u{0646}", -1, 1],
        ["\u{06A9}\u{0647}\u{06A9}\u{0634}\u{0627}\u{0646}", -1, 1],
        ["\u{062F}\u{0631}\u{062E}\u{0634}\u{0627}\u{0646}", -1, 1],
        ["\u{0633}\u{0644}\u{0637}\u{0627}\u{0646}", -1, 1]
    ];

    private const array A_4 = [
        ["\u{0627}\u{0633}\u{0627}\u{062A}\u{06CC}\u{062F}", -1, 2],
        ["\u{0627}\u{062E}\u{0628}\u{0627}\u{0631}", -1, 1]
    ];

    private const array AS_4 = ["\u{062E}\u{0628}\u{0631}", "\u{0627}\u{0633}\u{062A}\u{0627}\u{062F}"];

    private const array A_5 = [
        ["\u{0627}\u{0645}", -1, 1],
        ["\u{06CC}\u{0646}", -1, 1],
        ["\u{062A}\u{0631}\u{06CC}\u{0646}", 1, 1],
        ["\u{0627}\u{0646}", -1, 1],
        ["\u{06CC}\u{0627}\u{0646}", 3, 1],
        ["\u{0628}\u{0627}\u{0646}", 3, 1],
        ["\u{06AF}\u{0627}\u{0646}", 3, 1],
        ["\u{0627}\u{0646}\u{0647}", -1, 1],
        ["\u{06AF}\u{0627}\u{0647}", -1, 1],
        ["\u{0627}\u{0646}\u{06CC}", -1, 1],
        ["\u{06CC}\u{06CC}", -1, 1],
        ["\u{0647}\u{0627}\u{06CC}", -1, 1],
        ["\u{06AF}\u{06CC}", -1, 1],
        ["\u{0647}\u{0627}", -1, 1],
        ["\u{0646}\u{0627}\u{06A9}", -1, 1],
        ["\u{06CC}\u{062A}", -1, 1],
        ["\u{0627}\u{062A}", -1, 1],
        ["\u{0645}\u{0646}\u{062F}", -1, 1],
        ["\u{0648}\u{0627}\u{0631}", -1, 1],
        ["\u{06AF}\u{0627}\u{0631}", -1, 1],
        ["\u{062A}\u{0631}", -1, 2],
        ["\u{0627}\u{0634}", -1, 1]
    ];

    private const array A_6 = [
        ["\u{06CC}\u{0645}", -1, 1],
        ["\u{0627}\u{06CC}\u{0645}", 0, 1],
        ["\u{0627}\u{06CC}", -1, 1],
        ["\u{0627}\u{0633}\u{062A}", -1, 1],
        ["\u{0627}\u{0646}\u{062F}", -1, 1],
        ["\u{06CC}\u{062F}", -1, 1],
        ["\u{0627}\u{06CC}\u{062F}", 5, 1],
        ["\u{0627}\u{0633}", -1, 1]
    ];

    private const array A_7 = [
        ["\u{0645}", -1, 1],
        ["\u{06CC}\u{0645}", 0, 1],
        ["\u{0631}\u{0641}\u{062A}\u{06CC}\u{0645}", 1, 2],
        ["\u{0627}\u{0645}", 0, 1],
        ["\u{0631}\u{0641}\u{062A}\u{0645}", 0, 2],
        ["\u{0627}\u{0646}", -1, 3],
        ["\u{062A}\u{0647}", -1, 5],
        ["\u{062F}\u{0647}", -1, 4],
        ["\u{0646}\u{062F}\u{0647}", 7, 3],
        ["\u{0631}\u{0641}\u{062A}\u{06CC}", -1, 2],
        ["\u{062F}", -1, 1],
        ["\u{0627}\u{0646}\u{062F}", 10, 1],
        ["\u{0631}\u{0641}\u{062A}\u{0627}\u{0646}\u{062F}", 11, 2],
        ["\u{06CC}\u{062F}", 10, 1],
        ["\u{0631}\u{0641}\u{062A}\u{06CC}\u{062F}", 13, 2]
    ];

    private int $I_p1 = 0;
    private bool $B_remove_verb_person_endings = false;
    private bool $B_saw_present_prefix = false;



    protected function r_Normalize_Characters(): bool
    {
        while (true) {
            $v_1 = $this->cursor;
            $this->bra = $this->cursor;
            $among_var = $this->find_among(self::A_0);
            $this->ket = $this->cursor;
            switch ($among_var) {
                case 1:
                    $this->slice_from("\u{06A9}");
                    break;
                case 2:
                    $this->slice_from("\u{06CC}");
                    break;
                case 3:
                    $this->slice_from("\u{0647}");
                    break;
                case 4:
                    $this->slice_from("\u{0627}");
                    break;
                case 5:
                    $this->slice_from("\u{0648}");
                    break;
                case 6:
                    $this->slice_del();
                    break;
                case 7:
                    if ($this->cursor >= $this->limit) {
                        goto lab0;
                    }
                    $this->inc_cursor();
                    break;
            }
            continue;
        lab0:
            $this->cursor = $v_1;
            break;
        }
        return true;
    }


    protected function r_Prefixes(): bool
    {
        $this->bra = $this->cursor;
        $among_var = $this->find_among(self::A_1);
        if (0 === $among_var) {
            return false;
        }
        $this->ket = $this->cursor;
        switch ($among_var) {
            case 1:
                if (!$this->hop(2)) {
                    return false;
                }
                $this->B_saw_present_prefix = true;
                break;
            case 2:
                if (!$this->hop(2)) {
                    return false;
                }
                $this->slice_del();
                $this->B_saw_present_prefix = true;
                break;
        }
        return true;
    }


    protected function r_Delete_ZWNJ(): bool
    {
        while (true) {
            $v_1 = $this->cursor;
            while (true) {
                $v_2 = $this->cursor;
                $this->bra = $this->cursor;
                if (!($this->eq_s("\u{200C}"))) {
                    goto lab1;
                }
                $this->ket = $this->cursor;
                $this->slice_del();
                $this->cursor = $v_2;
                break;
            lab1:
                $this->cursor = $v_2;
                if ($this->cursor >= $this->limit) {
                    goto lab0;
                }
                $this->inc_cursor();
            }
            continue;
        lab0:
            $this->cursor = $v_1;
            break;
        }
        return true;
    }


    protected function r_R1(): bool
    {
        return $this->I_p1 <= $this->cursor;
    }


    protected function r_Protect_Lexical_AN(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        if (!$this->r_AN_Exception()) {
            goto lab0;
        }
        return false;
    lab0:
        $this->cursor = $this->limit - $v_1;
        $v_2 = $this->limit - $this->cursor;
        if ($this->find_among_b(self::A_2) === 0) {
            goto lab1;
        }
        return false;
    lab1:
        $this->cursor = $this->limit - $v_2;
        return true;
    }


    protected function r_AN_Exception(): bool
    {
        if ($this->find_among_b(self::A_3) === 0) {
            return false;
        }
        if ($this->cursor > $this->limit_backward) {
            return false;
        }
        return true;
    }


    protected function r_Irregular_Noun(): bool
    {
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_4);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        $this->slice_from(self::AS_4[$among_var - 1]);
        return true;
    }


    protected function r_Stem_Noun_or_Adjective(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        if (!$this->r_Irregular_Noun()) {
            goto lab0;
        }
        goto lab1;
    lab0:
        $this->cursor = $this->limit - $v_1;
        if ($this->cursor < $this->I_p1) {
            return false;
        }
        $v_2 = $this->limit_backward;
        $this->limit_backward = $this->I_p1;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_5);
        if (0 === $among_var) {
            $this->limit_backward = $v_2;
            return false;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                if ($this->cursor > $this->limit_backward) {
                    goto lab2;
                }
                $this->limit_backward = $v_2;
                return false;
            lab2:
                $this->slice_del();
                break;
        }
        $this->limit_backward = $v_2;
    lab1:
        return true;
    }


    protected function r_Stem_Verb(): bool
    {
        $v_1 = $this->limit - $this->cursor;
        $this->ket = $this->cursor;
        if ($this->find_among_b(self::A_6) === 0) {
            goto lab0;
        }
        $this->bra = $this->cursor;
        if (!$this->r_R1()) {
            goto lab0;
        }
        $this->slice_del();
        goto lab1;
    lab0:
        $this->cursor = $this->limit - $v_1;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_7);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        switch ($among_var) {
            case 1:
                if (!$this->B_remove_verb_person_endings) {
                    return false;
                }
                if (!$this->r_R1()) {
                    return false;
                }
                $this->slice_del();
                break;
            case 2:
                $this->slice_from("\u{0631}\u{0641}\u{062A}");
                break;
            case 3:
                if (!$this->r_R1()) {
                    return false;
                }
                $this->slice_del();
                $this->B_remove_verb_person_endings = true;
                break;
            case 4:
                if ($this->cursor > $this->limit_backward) {
                    goto lab2;
                }
                return false;
            lab2:
                $this->slice_from("\u{062F}");
                $this->B_remove_verb_person_endings = true;
                break;
            case 5:
                if ($this->cursor > $this->limit_backward) {
                    goto lab3;
                }
                return false;
            lab3:
                $this->slice_from("\u{062A}");
                $this->B_remove_verb_person_endings = true;
                break;
        }
    lab1:
        return true;
    }


    public function stem(): bool
    {
        $this->B_saw_present_prefix = false;
        $v_1 = $this->cursor;
        $this->r_Normalize_Characters();
        $this->cursor = $v_1;
        $v_2 = $this->cursor;
        $this->r_Prefixes();
        $this->cursor = $v_2;
        $v_3 = $this->cursor;
        $this->r_Delete_ZWNJ();
        $this->cursor = $v_3;
        $this->I_p1 = $this->limit;
        $v_4 = $this->cursor;
        if (!$this->hop(3)) {
            goto lab0;
        }
        $this->I_p1 = $this->cursor;
    lab0:
        $this->cursor = $v_4;
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        while (true) {
            $v_5 = $this->limit - $this->cursor;
            $v_6 = $this->limit - $this->cursor;
            $this->B_remove_verb_person_endings = false;
            if (!$this->B_saw_present_prefix) {
                goto lab2;
            }
            $this->B_remove_verb_person_endings = true;
        lab2:
            if (!$this->r_Protect_Lexical_AN()) {
                goto lab1;
            }
            $v_7 = $this->limit - $this->cursor;
            if (!$this->r_Stem_Noun_or_Adjective()) {
                goto lab3;
            }
            goto lab4;
        lab3:
            $this->cursor = $this->limit - $v_7;
            if (!$this->r_Stem_Verb()) {
                goto lab1;
            }
        lab4:
            $this->cursor = $this->limit - $v_6;
            continue;
        lab1:
            $this->cursor = $this->limit - $v_5;
            break;
        }
        $this->cursor = $this->limit_backward;
        return true;
    }
}
