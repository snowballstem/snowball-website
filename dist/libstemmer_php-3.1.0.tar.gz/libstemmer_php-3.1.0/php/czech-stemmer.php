<?php
// Generated from czech.sbl by Snowball 3.1.0 - https://snowballstem.org/

class SnowballCzechStemmer extends SnowballStemmer
{
    private const array A_0 = [
        ["c", -1, 1],
        ["nc", 0, -1],
        ["\u{00ED}nc", 1, 2],
        ["avc", 0, -1],
        ["ovc", 0, -1]
    ];

    private const array AS_0 = ["k", "\u{00ED}nk"];

    private const array A_1 = [
        ["c", -1, 1],
        ["nc", 0, -1],
        ["\u{00ED}nc", 1, 2],
        ["avc", 0, -1],
        ["ovc", 0, -1],
        ["\u{010D}t", -1, 3],
        ["\u{0161}t", -1, 4],
        ["de\u{0161}t", 6, -1],
        ["le\u{0161}t", 6, -1],
        ["i\u{0161}t", 6, -1],
        ["pou\u{0161}t", 6, -1],
        ["\u{00E1}\u{0161}t", 6, -1],
        ["\u{00ED}\u{0161}t", 6, -1]
    ];

    private const array AS_1 = ["k", "\u{00ED}nk", "ck", "sk"];

    private const array A_2 = [
        ["in", -1, 2],
        ["ov", -1, 1],
        ["\u{016F}v", -1, 1]
    ];

    private const array A_3 = [
        ["", -1, 2],
        ["l", 0, 1],
        ["tl", 1, 2],
        ["s", 0, 1],
        ["es", 3, 2],
        ["\u{010D}", 0, 1],
        ["e\u{010D}", 5, 2],
        ["\u{0159}", 0, 1],
        ["\u{017E}", 0, 1]
    ];

    private const array A_4 = [
        ["obl", -1, -1],
        ["sn", -1, -1],
        ["dot", -1, -1]
    ];

    private const array A_5 = [
        ["uc", -1, -1],
        ["h", -1, -1],
        ["ok", -1, -1],
        ["kar", -1, -1],
        ["\u{010D}", -1, -1]
    ];

    private const array A_6 = [
        ["a", -1, 1],
        ["ama", 0, 1],
        ["ata", 0, 1],
        ["eb", -1, 4],
        ["ec", -1, 5],
        ["e", -1, 2],
        ["ete", 5, 3],
        ["\u{011B}te", 5, 1],
        ["ech", -1, 2],
        ["atech", 8, 1],
        ["\u{00E1}ch", -1, 1],
        ["\u{00ED}ch", -1, 12],
        ["\u{00FD}ch", -1, 1],
        ["i", -1, 12],
        ["mi", 13, 1],
        ["ami", 14, 1],
        ["emi", 14, 2],
        ["\u{011B}mi", 14, 1],
        ["\u{0165}mi", 14, 11],
        ["\u{00ED}mi", 14, 12],
        ["\u{00FD}mi", 14, 1],
        ["eti", 13, 3],
        ["\u{011B}ti", 13, 1],
        ["ovi", 13, 1],
        ["ek", -1, 6],
        ["\u{011B}k", -1, 7],
        ["em", -1, 2],
        ["etem", 26, 3],
        ["\u{011B}tem", 26, 1],
        ["\u{011B}m", -1, 1],
        ["\u{00E1}m", -1, 1],
        ["\u{00E9}m", -1, 1],
        ["\u{00ED}m", -1, 12],
        ["\u{016F}m", -1, 1],
        ["at\u{016F}m", 33, 1],
        ["\u{00FD}m", -1, 1],
        ["o", -1, 1],
        ["\u{00E9}ho", 36, 1],
        ["\u{00ED}ho", 36, 12],
        ["us", -1, 1],
        ["at", -1, 1],
        ["et", -1, 9],
        ["u", -1, 1],
        ["\u{00E9}mu", 42, 1],
        ["\u{00ED}mu", 42, 12],
        ["ou", 42, 1],
        ["ev", -1, 10],
        ["y", -1, 1],
        ["aty", 47, 1],
        ["e\u{0148}", -1, 8],
        ["\u{011B}", -1, 1],
        ["\u{00E1}", -1, 1],
        ["\u{0165}", -1, 11],
        ["\u{00E9}", -1, 1],
        ["ov\u{00E9}", 53, 1],
        ["\u{00ED}", -1, 12],
        ["\u{016F}", -1, 1],
        ["\u{00FD}", -1, 1]
    ];

    private const array G_v = ["a"=>true, "e"=>true, "i"=>true, "o"=>true, "u"=>true, "y"=>true, "\u{00E1}"=>true, "\u{00E9}"=>true, "\u{00ED}"=>true, "\u{00F3}"=>true, "\u{00FA}"=>true, "\u{00FD}"=>true, "\u{011B}"=>true, "\u{016F}"=>true];

    private const array G_v_or_syllabic_c = ["a"=>true, "e"=>true, "i"=>true, "l"=>true, "o"=>true, "r"=>true, "u"=>true, "y"=>true, "\u{00E1}"=>true, "\u{00E9}"=>true, "\u{00ED}"=>true, "\u{00F3}"=>true, "\u{00FA}"=>true, "\u{00FD}"=>true, "\u{011B}"=>true, "\u{016F}"=>true];

    private const array G_ev_ending = ["h"=>true, "k"=>true, "n"=>true, "r"=>true, "t"=>true, "z"=>true];

    private const array G_env_ending = ["b"=>true, "c"=>true, "d"=>true, "h"=>true, "k"=>true, "p"=>true, "r"=>true, "s"=>true, "t"=>true, "v"=>true, "z"=>true, "\u{010D}"=>true, "\u{0161}"=>true, "\u{017E}"=>true];

    private int $I_p1 = 0;



    protected function r_mark_regions(): bool
    {
        $v_1 = $this->cursor;
        if (!$this->hop(3)) {
            return false;
        }
        $I_x = $this->cursor;
        $this->cursor = $v_1;
        $this->I_p1 = $this->limit;
        $v_2 = $this->cursor;
        if (!($this->in_grouping(self::G_v))) {
            goto lab1;
        }
        goto lab2;
    lab1:
        if ($this->cursor >= $this->limit) {
            goto lab0;
        }
        $this->inc_cursor();
        if (!$this->go_out_grouping(self::G_v_or_syllabic_c)) {
            goto lab0;
        }
        $this->inc_cursor();
    lab2:
        if (!$this->go_in_grouping(self::G_v)) {
            goto lab0;
        }
        $this->inc_cursor();
        $this->I_p1 = $this->cursor;
        if ($this->I_p1 >= $I_x) {
            goto lab3;
        }
        $this->I_p1 = $I_x;
    lab3:
    lab0:
        $this->cursor = $v_2;
        return true;
    }


    protected function r_R1(): bool
    {
        return $this->I_p1 <= $this->cursor;
    }


    protected function r_palatalise_e(): bool
    {
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_0);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        if ($among_var > 0) {
            $this->slice_from(self::AS_0[$among_var - 1]);
        }
        return true;
    }


    protected function r_palatalise_i(): bool
    {
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_1);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        if ($among_var > 0) {
            $this->slice_from(self::AS_1[$among_var - 1]);
        }
        return true;
    }


    protected function r_possessive_suffix(): bool
    {
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_2);
        if (0 === $among_var) {
            return false;
        }
        $this->bra = $this->cursor;
        if (!$this->r_R1()) {
            return false;
        }
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                $v_1 = $this->limit - $this->cursor;
                if (!$this->r_palatalise_i()) {
                    $this->cursor = $this->limit - $v_1;
                    goto lab0;
                }
            lab0:
                break;
        }
        return true;
    }


    protected function r_case_suffix(): bool
    {
        if ($this->cursor < $this->I_p1) {
            return false;
        }
        $v_1 = $this->limit_backward;
        $this->limit_backward = $this->I_p1;
        $this->ket = $this->cursor;
        $among_var = $this->find_among_b(self::A_6);
        if (0 === $among_var) {
            $this->limit_backward = $v_1;
            return false;
        }
        $this->bra = $this->cursor;
        $this->limit_backward = $v_1;
        switch ($among_var) {
            case 1:
                $this->slice_del();
                break;
            case 2:
                $this->slice_del();
                $v_2 = $this->limit - $this->cursor;
                if (!$this->r_palatalise_e()) {
                    $this->cursor = $this->limit - $v_2;
                    goto lab0;
                }
            lab0:
                break;
            case 3:
                $among_var = $this->find_among_b(self::A_3);
                switch ($among_var) {
                    case 1:
                        $this->slice_del();
                        break;
                    case 2:
                        $this->slice_from("et");
                        break;
                }
                break;
            case 4:
                $v_3 = $this->limit - $this->cursor;
                if (!($this->out_grouping_b(self::G_v))) {
                    return false;
                }
                $this->cursor = $this->limit - $v_3;
                if (!($this->eq_s_b("t\u{0159}"))) {
                    goto lab1;
                }
                return false;
            lab1:
                $this->slice_from("b");
                break;
            case 5:
                $v_4 = $this->limit - $this->cursor;
                if (!($this->out_grouping_b(self::G_v))) {
                    return false;
                }
                $this->cursor = $this->limit - $v_4;
                $this->slice_del();
                $this->insert($this->cursor, $this->cursor, "c");
                $v_5 = $this->limit - $this->cursor;
                if (!$this->r_palatalise_e()) {
                    $this->cursor = $this->limit - $v_5;
                    goto lab2;
                }
            lab2:
                break;
            case 6:
                $v_6 = $this->limit - $this->cursor;
                if (!($this->out_grouping_b(self::G_v))) {
                    return false;
                }
                $this->cursor = $this->limit - $v_6;
                $v_7 = $this->limit - $this->cursor;
                if ($this->find_among_b(self::A_4) === 0) {
                    goto lab3;
                }
                return false;
            lab3:
                $this->cursor = $this->limit - $v_7;
                $this->slice_from("k");
                break;
            case 7:
                if (!($this->eq_s_b("n"))) {
                    return false;
                }
                $this->bra = $this->cursor;
                $this->slice_from("\u{0148}k");
                break;
            case 8:
                $v_8 = $this->limit - $this->cursor;
                if (!($this->in_grouping_b(self::G_env_ending))) {
                    return false;
                }
                $this->cursor = $this->limit - $v_8;
                $this->slice_from("n");
                break;
            case 9:
                if ($this->find_among_b(self::A_5) === 0) {
                    return false;
                }
                $this->slice_from("t");
                break;
            case 10:
                if (!($this->in_grouping_b(self::G_ev_ending))) {
                    return false;
                }
                $this->slice_from("v");
                break;
            case 11:
                $this->slice_from("t");
                break;
            case 12:
                $this->slice_del();
                $v_9 = $this->limit - $this->cursor;
                if (!$this->r_palatalise_i()) {
                    $this->cursor = $this->limit - $v_9;
                    goto lab4;
                }
            lab4:
                break;
        }
        return true;
    }


    public function stem(): bool
    {
        if (!$this->r_mark_regions()) {
            return false;
        }
        $this->limit_backward = $this->cursor;
        $this->cursor = $this->limit;
        $v_1 = $this->limit - $this->cursor;
        $this->r_case_suffix();
        $this->cursor = $this->limit - $v_1;
        $v_2 = $this->limit - $this->cursor;
        $this->r_possessive_suffix();
        $this->cursor = $this->limit - $v_2;
        $this->cursor = $this->limit_backward;
        return true;
    }
}
